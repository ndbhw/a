--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Register, type WO (MPI component)                             --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MPI_REG_WO is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;                            -- 1-pulse@CLK
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end MPI_REG_WO;

architecture BEHAVE of MPI_REG_WO is

begin

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            DATA_OUT <= REG_DATA(BIT_WIDTH-1 downto 0);
        elsif (CLK'event and CLK = '1') then
            if (EN = '1') and (ADDR = REG_ADDR) then
                DATA_OUT <= DATA_IN;
            end if;
        end if;
    end process;

end BEHAVE;