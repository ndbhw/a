--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   1. Performance measurement
--   2. Only for SCS 15kHz
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_O_RAN.ALL;

entity MEASUREMENT is
    generic (
        NUM_TX                      : natural := 1
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_UL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_UL_CP_RX            : in  std_logic_vector(21 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        DL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        DL_UP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        DL_UP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        DL_UP_RX_EARLY              : out std_logic_vector(63 downto 0);
        DL_UP_RX_LATE               : out std_logic_vector(63 downto 0);
        DL_UP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_CP_RX_CNT_CLEAR          : in  std_logic_vector(3 downto 0);
        UL_CP_RX_ON_TIME            : out std_logic_vector(63 downto 0);
        UL_CP_RX_EARLY              : out std_logic_vector(63 downto 0);
        UL_CP_RX_LATE               : out std_logic_vector(63 downto 0);
        UL_CP_RX_OUT_OF_RANGE       : out std_logic_vector(63 downto 0);

        UL_UP_TX_CNT_CLEAR          : in  std_logic_vector(7 downto 0);
        UL_UP_TX_TOTAL              : out std_logic_array64(7 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp for RX
--------------------------------------------------------------------------------

        RX_PACKET_CLK               : in  std_logic;
        UPDATE_EN_OUT               : out std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_CP_UL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp for TX
--------------------------------------------------------------------------------

        TX_PACKET_CLK               : in  std_logic;

        TX_PACKET_EXIST             : in  std_logic_vector(NUM_TX-1 downto 0)
    );
end MEASUREMENT;

architecture BEHAVE of MEASUREMENT is

    signal prev_period              : std_logic_vector(7 downto 0);
    signal condi_reset              : std_logic;

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal rst_245p76mhz            : std_logic;

    component REF_GEN is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        IN_10msec                   : in  std_logic;
        IN_SFN                      : in  std_logic_vector(7 downto 0);

        OUT_10msec                  : out std_logic;
        OUT_SFN                     : out std_logic_vector(7 downto 0)
    );
    end component;

    signal ref_rx_window            : std_logic;
    signal ref_rx_sfn               : std_logic_vector(7 downto 0);
    signal ref_tx_window            : std_logic;
    signal ref_tx_sfn               : std_logic_vector(7 downto 0);

    component RX_WINDOW is
    generic (
        SCS_CONFIG_0                : boolean := true;
        SCS_CONFIG_1                : boolean := true;
        SCS_CONFIG_2                : boolean := true;
        SCS_CONFIG_3                : boolean := true;
        SCS_CONFIG_4                : boolean := true
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        WINDOW_START                : in  std_logic_vector(21 downto 0);
        WINDOW_END                  : in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   : in  std_logic_vector(3 downto 0);

        CNT_ON_TIME                 : out std_logic_vector(63 downto 0);
        CNT_EARLY                   : out std_logic_vector(63 downto 0);
        CNT_LATE                    : out std_logic_vector(63 downto 0);
        CNT_OUT_OF_RANGE            : out std_logic_vector(63 downto 0);

        CLK_PACKET                  : in  std_logic;
        UPDATE_EN_OUT               : out std_logic;

        PACKET_EN                   : in  std_logic;
        PACKET_SCS                  : in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : in  std_logic_vector(5 downto 0)
    );
    end component;

    component TX_STAT is
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

        REF_10msec                  : in  std_logic;

        CNT_CLEAR                   : in  std_logic_vector(0 downto 0);

        CNT_TOTAL                   : out std_logic_vector(63 downto 0);

        CLK_PACKET                  : in  std_logic;

        PACKET_EN                   : in  std_logic_vector(0 downto 0)
    );
    end component;

begin

--------------------------------------------------------------------------------
-- Conditional reset control
--------------------------------------------------------------------------------

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            prev_period <= CAPTURE_PERIOD;
        end if;
    end process;

    process (RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            condi_reset <= '1';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (CAPTURE_PERIOD = prev_period) then
                condi_reset <= '0';
            else
                condi_reset <= '1';
            end if;
        end if;
    end process;

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => condi_reset                             ,--: in  std_logic;
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST_OUT                     => rst_245p76mhz                            --: out std_logic
    );

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RX_10msec : REF_GEN
    port map(
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST                         => rst_245p76mhz                           ,--: in  std_logic;

        N_TA_OFFSET                 => (others => '0')                         ,--: in  std_logic_vector(15 downto 0);

        IN_10msec                   => REF_10msec                              ,--: in  std_logic;
        IN_SFN                      => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        OUT_10msec                  => ref_rx_window                           ,--: out std_logic;
        OUT_SFN                     => ref_rx_sfn                               --: out std_logic_vector(7 downto 0)

    );

    u_TX_10msec : REF_GEN
    port map(
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST                         => rst_245p76mhz                           ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET                             ,--: in  std_logic_vector(15 downto 0);

        IN_10msec                   => REF_10msec                              ,--: in  std_logic;
        IN_SFN                      => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        OUT_10msec                  => ref_tx_window                           ,--: out std_logic;
        OUT_SFN                     => ref_tx_sfn                               --: out std_logic_vector(7 downto 0)
    );

    u_CP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => DL_CP_RX_CNT_CLEAR                      ,--: in  std_logic_vector(3 downto 0);

        CNT_ON_TIME                 => DL_CP_RX_ON_TIME                        ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_CP_RX_EARLY                          ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_CP_RX_LATE                           ,--: out std_logic_vector(63 downto 0);
        CNT_OUT_OF_RANGE            => DL_CP_RX_OUT_OF_RANGE                   ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => UPDATE_EN_OUT                           ,--: out std_logic;

        PACKET_EN                   => RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_UP_DL : RX_WINDOW
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => DL_UP_RX_CNT_CLEAR                      ,--: in  std_logic_vector(3 downto 0);

        CNT_ON_TIME                 => DL_UP_RX_ON_TIME                        ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => DL_UP_RX_EARLY                          ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => DL_UP_RX_LATE                           ,--: out std_logic_vector(63 downto 0);
        CNT_OUT_OF_RANGE            => DL_UP_RX_OUT_OF_RANGE                   ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open                                    ,--: out std_logic;
        PACKET_EN                   => RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_CP_UL : RX_WINDOW
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_UL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_UL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_tx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CNT_CLEAR                   => UL_CP_RX_CNT_CLEAR                      ,--: in  std_logic_vector(3 downto 0);

        CNT_ON_TIME                 => UL_CP_RX_ON_TIME                        ,--: out std_logic_vector(63 downto 0);
        CNT_EARLY                   => UL_CP_RX_EARLY                          ,--: out std_logic_vector(63 downto 0);
        CNT_LATE                    => UL_CP_RX_LATE                           ,--: out std_logic_vector(63 downto 0);
        CNT_OUT_OF_RANGE            => UL_CP_RX_OUT_OF_RANGE                   ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;
        UPDATE_EN_OUT               => open                                    ,--: out std_logic;
        PACKET_EN                   => RX_PACKET_IS_CP_UL                      ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                      --: in  std_logic_vector(5 downto 0)
    );

    u_TX_STAT : for i in NUM_TX-1 downto 0 generate
    u_TX0 : TX_STAT
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_tx_window                           ,--: in  std_logic;

        CNT_CLEAR                   => UL_UP_TX_CNT_CLEAR(i downto i)          ,--: in  std_logic_vector(0 downto 0);

        CNT_TOTAL                   => UL_UP_TX_TOTAL(i)                       ,--: out std_logic_vector(63 downto 0);

        CLK_PACKET                  => TX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => TX_PACKET_EXIST(i downto i)              --: in  std_logic_vector(0 downto 0)
    );
    end generate;

end BEHAVE;