--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com) / nhu.dong
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   1. Performance MEASUREMENT_SHORT
--   2. Only for SCS 15kHz
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_O_RAN.ALL;

entity MEASUREMENT_SHORT is
    generic (
        NUM_TX                      : natural := 1;
        MAX_SECTIONID_PER_PKT       : natural := 5
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz
        
--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp for RX
--------------------------------------------------------------------------------
        RX_VLD_IN                   : in std_logic;
        RX_PACKET_CLK               : in  std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : in  std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
        
        DL_CP_DETECT_ON_TIME        : out std_logic;
        DL_CP_DETECT_EARLY          : out std_logic;
        DL_CP_DETECT_LATE           : out std_logic;
        DL_CP_DETECT_OOR            : out std_logic;
          
        DL_UP_DETECT_ON_TIME        : out std_logic;      
        DL_UP_DETECT_EARLY          : out std_logic;
        DL_UP_DETECT_LATE           : out std_logic;
        DL_UP_DETECT_OOR            : out std_logic        
        
    );
end MEASUREMENT_SHORT;

architecture BEHAVE of MEASUREMENT_SHORT is

    signal prev_period              : std_logic_vector(7 downto 0);
    signal condi_reset              : std_logic;

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal rst_245p76mhz            : std_logic;

    component REF_GEN is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        IN_10msec                   : in  std_logic;
        IN_SFN                      : in  std_logic_vector(7 downto 0);

        OUT_10msec                  : out std_logic;
        OUT_SFN                     : out std_logic_vector(7 downto 0)
    );
    end component;

    signal ref_rx_window            : std_logic;
    signal ref_rx_sfn               : std_logic_vector(7 downto 0);

    component RX_WINDOW_SHORT is
    generic (
        SCS_CONFIG_0                : boolean := true;
        SCS_CONFIG_1                : boolean := true;
        SCS_CONFIG_2                : boolean := true;
        SCS_CONFIG_3                : boolean := true;
        SCS_CONFIG_4                : boolean := true
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        WINDOW_START                : in  std_logic_vector(21 downto 0);
        WINDOW_END                  : in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CLK_PACKET                  : in  std_logic;

        PACKET_EN                   : in  std_logic;
        PACKET_SCS                  : in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : in  std_logic_vector(5 downto 0);
    
        DETECT_ON_TIME              : out std_logic;
        DETECT_EARLY                : out std_logic;
        DETECT_LATE                 : out std_logic;
        DETECT_OOR                  : out std_logic
    
    );
    end component;
    
    signal rx_pkt_is_cp_dl          : std_logic;
    signal rx_pkt_is_up_dl          : std_logic;
    
    signal dl_cp_det_on_time              : std_logic := '0';
    signal dl_cp_det_early                : std_logic := '0';
    signal dl_cp_det_late                 : std_logic := '0';
    signal dl_cp_det_oor                  : std_logic := '0';

    signal dl_up_det_on_time              : std_logic := '0';
    signal dl_up_det_early                : std_logic := '0';
    signal dl_up_det_late                 : std_logic := '0';
    signal dl_up_det_oor                  : std_logic := '0';    
    
begin
    
--    DL_CP_DETECT_ON_TIME    <= dl_cp_det_on_time;
--    DL_CP_DETECT_EARLY      <= dl_cp_det_early  ;
--    DL_CP_DETECT_LATE       <= dl_cp_det_late   ;
--    DL_CP_DETECT_OOR        <= dl_cp_det_oor    ;
                         
--    DL_UP_DETECT_ON_TIME    <= dl_up_det_on_time;
--    DL_UP_DETECT_EARLY      <= dl_up_det_early  ;
--    DL_UP_DETECT_LATE       <= dl_up_det_late   ;
--    DL_UP_DETECT_OOR        <= dl_up_det_oor    ;
    
--------------------------------------------------------------------------------
-- Conditional reset control
--------------------------------------------------------------------------------

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            prev_period <= CAPTURE_PERIOD;
        end if;
    end process;

    process (RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            condi_reset <= '1';
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (CAPTURE_PERIOD = prev_period) then
                condi_reset <= '0';
            else
                condi_reset <= '1';
            end if;
        end if;
    end process;

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => condi_reset                             ,--: in  std_logic;
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST_OUT                     => rst_245p76mhz                            --: out std_logic
    );

    process (CLK_245p76MHz)
    begin
        if (CLK_245p76MHz'event and CLK_245p76MHz = '1') then
            if (RX_VLD_IN = '1') then
                rx_pkt_is_cp_dl <= RX_PACKET_IS_CP_DL;
                rx_pkt_is_up_dl <= RX_PACKET_IS_UP_DL;
            else
                rx_pkt_is_cp_dl <= '0';
                rx_pkt_is_up_dl <= '0';               
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RX_10msec : REF_GEN
    port map(
        CLK                         => CLK_245p76MHz                           ,--: in  std_logic;
        RST                         => rst_245p76mhz                           ,--: in  std_logic;

        N_TA_OFFSET                 => (others => '0')                         ,--: in  std_logic_vector(15 downto 0);

        IN_10msec                   => REF_10msec                              ,--: in  std_logic;
        IN_SFN                      => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        OUT_10msec                  => ref_rx_window                           ,--: out std_logic;
        OUT_SFN                     => ref_rx_sfn                               --: out std_logic_vector(7 downto 0)

    );

    u_CP_DL : RX_WINDOW_SHORT
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => rx_pkt_is_cp_dl, --RX_PACKET_IS_CP_DL                      ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                     , --: in  std_logic_vector(5 downto 0)
        
        DETECT_ON_TIME              => DL_CP_DETECT_ON_TIME, --dl_cp_det_on_time   ,
        DETECT_EARLY                => DL_CP_DETECT_EARLY, --dl_cp_det_early     ,
        DETECT_LATE                 => DL_CP_DETECT_LATE, --dl_cp_det_late      ,
        DETECT_OOR                  => DL_CP_DETECT_OOR --dl_cp_det_oor       
               
    );

    u_UP_DL : RX_WINDOW_SHORT
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => condi_reset                             ,--: in  std_logic;

        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;

        WINDOW_START                => T2A_MAX_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_END                  => T2A_MIN_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        REF_10msec                  => ref_rx_window                           ,--: in  std_logic;
        REF_SFN                     => ref_rx_sfn                              ,--: in  std_logic_vector(7 downto 0);

        CLK_PACKET                  => RX_PACKET_CLK                           ,--: in  std_logic;

        PACKET_EN                   => rx_pkt_is_up_dl, --RX_PACKET_IS_UP_DL                      ,--: in  std_logic;
        PACKET_SCS                  => RX_PACKET_SCS                           ,--: in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => RX_PACKET_FRAME_ID                      ,--: in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => RX_PACKET_SUBFRAME_ID                   ,--: in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => RX_PACKET_SLOT_ID                       ,--: in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => RX_PACKET_SYMBOL_ID                     , --: in  std_logic_vector(5 downto 0)
        
        DETECT_ON_TIME              => DL_UP_DETECT_ON_TIME, --dl_up_det_on_time   , 
        DETECT_EARLY                => DL_UP_DETECT_EARLY, --dl_up_det_early     , 
        DETECT_LATE                 => DL_UP_DETECT_LATE, --dl_up_det_late      , 
        DETECT_OOR                  => DL_UP_DETECT_OOR --dl_up_det_oor         
    );


end BEHAVE;