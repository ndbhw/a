--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com) / nhu.dong
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   1. Performance sectionid_coupling_validation
--   2. Only for SCS 15kHz
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.numeric_std.all;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_O_RAN.ALL;

entity sectionid_coupling_validation is
    generic (
        MAX_SECTIONID_PER_PKT       : natural := 5;
        MU                          : natural := 6  -- numerology: 0 -> 6 
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK                         : in  std_logic;                            -- 245.76-MHz
        
--------------------------------------------------------------------------------
-- Packet stamp for RX
--------------------------------------------------------------------------------        
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : in  std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
        
        DL_CP_DETECT_ON_TIME        : in std_logic;          
        DL_UP_DETECT_ON_TIME        : in std_logic;

        RX_CORRUPT_SECTIONID        : out std_logic                
    );
end sectionid_coupling_validation;

architecture BEHAVE of sectionid_coupling_validation is
    
    constant SLOT_NUM : natural range 0 to 2**MU := 2**MU;
    constant SUBFRAME_NUM : natural range 0 to 4 := 4;
    
    type std_logic_array98                      is array(natural range <>) of std_logic_vector( MAX_SECTIONID_PER_PKT-1 downto 0);
    type std_logic_array98_array13               is array(natural range <>) of std_logic_array13( MAX_SECTIONID_PER_PKT-1 downto 0);

--    type subframes_slots_sectionids_array is array(natural range <>) of std_logic_array5_array13(SLOT_NUM-1 downto 0);
    type subframes_slots_sectionids_array is array(natural range <>) of std_logic_array98_array13(SLOT_NUM-1 downto 0);

--    signal subframes_slots_sectionids_table : subframes_slots_sectionids_array(SUBFRAME_NUM-1 downto 0) := (others => (others => (others => (others => '0')))); -- sectionid: 13 bit width / 5 sectionids per pkt(slot) / SLOT_NUM slots per subframe / 2 consecutive subframes 
    
    signal subframes_slots_sectionids_table : subframes_slots_sectionids_array(SUBFRAME_NUM-1 downto 0) := (others => (others => (others => ("1000000000000")))); -- sectionid: 13 bit width / 5 sectionids per pkt(slot) / SLOT_NUM slots per subframe / 2 consecutive subframes 

--    signal pkt_section_ids                  : std_logic_array5_array13(SLOT_NUM-1 downto 0) := (others => (others => ("1000000000000"))); --"1000000000000"; -- 4096: never reachable
    
    signal pkt_section_ids                  : std_logic_array98_array13(SLOT_NUM-1 downto 0) := (others => (others => ("1000000000000"))); --"1000000000000"; -- 4096: never reachable

    
    signal dl_up_det_on_time_d              : std_logic_vector(MAX_SECTIONID_PER_PKT-1 downto 0)  := (others => '0');    
--    signal dl_up_section_id_coupling_result : std_logic_array5(SLOT_NUM -1 downto 0) := (others => (others => '0')); -- 0:
--    signal dl_cp_section_id_updated_check     : std_logic_array5(SLOT_NUM -1 downto 0) := (others => (others => '0')); -- 0:
    signal dl_up_section_id_coupling_result : std_logic_array98(SLOT_NUM -1 downto 0) := (others => (others => '0')); -- 0:
    signal dl_cp_section_id_updated_check     : std_logic_array98(SLOT_NUM -1 downto 0) := (others => (others => '0')); -- 0: 
    
    signal dl_up_excluded_rx_corrupt : std_logic := '0';
    signal dl_up_rx_corrupt_happened : std_logic := '0';
    signal tmp : std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
    signal tmp2 : std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
    signal addr : integer := 0;
    
    signal s_rx_corrupt_sectionid   : std_logic_vector(3 downto 0) := (others => '0');
    
begin

   process (CLK)
   begin
        if (CLK'event and CLK = '1') then
            dl_up_det_on_time_d <= dl_up_det_on_time_d(MAX_SECTIONID_PER_PKT-2 downto 0) & DL_UP_DETECT_ON_TIME;
        end if;
   end process;
           
   u_SLOT : for i_slot in SLOT_NUM-1 downto 0 generate
       u_SECTIONID : for i_section in MAX_SECTIONID_PER_PKT-1 downto 0 generate
       
           process (CLK)
           begin
                if (CLK'event and CLK = '1') then
                                        
                        case RX_PACKET_SUBFRAME_ID(1 downto 0) is 
                        when "00" =>  
                            if (DL_UP_DETECT_ON_TIME = '1') then
                            
                                if (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) then
                                    pkt_section_ids(i_slot)(i_section) <= subframes_slots_sectionids_table(0)(i_slot)(i_section);
                                end if;                                
                            
                                subframes_slots_sectionids_table(2)(i_slot)(i_section) <= ("1000000000000");
                                subframes_slots_sectionids_table(3)(i_slot)(i_section) <= ("1000000000000");
                                
                            else                                                                                          
                            
                                if ((DL_CP_DETECT_ON_TIME = '1') and (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) ) then                    
                                    subframes_slots_sectionids_table(0)(i_slot)(i_section) <= PACKET_SECTION_ID(i_section);
                                end if;
                                
                            end if;
                        when "01" =>                              
                            if (DL_UP_DETECT_ON_TIME = '1') then
                            
                                if (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) then
                                    pkt_section_ids(i_slot)(i_section) <= subframes_slots_sectionids_table(1)(i_slot)(i_section);
                                end if;    
                                                            
                                if (RX_PACKET_SUBFRAME_ID = 9) then
                                    subframes_slots_sectionids_table(3)(i_slot)(i_section) <= ("1000000000000");
                                else
                                    subframes_slots_sectionids_table(3)(i_slot)(i_section) <= ("1000000000000");
                                    subframes_slots_sectionids_table(0)(i_slot)(i_section) <= ("1000000000000");
                                end if;
                                
                            else                                                                                          
                            
                                if ((DL_CP_DETECT_ON_TIME = '1') and (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) ) then                    
                                    subframes_slots_sectionids_table(1)(i_slot)(i_section) <= PACKET_SECTION_ID(i_section);
                                end if;
                                
                            end if;                                                    
                        when "10" =>                              
                            if (DL_UP_DETECT_ON_TIME = '1') then
                            
                                if (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) then
                                    pkt_section_ids(i_slot)(i_section) <= subframes_slots_sectionids_table(2)(i_slot)(i_section);
                                end if;                                
                            
                                subframes_slots_sectionids_table(0)(i_slot)(i_section) <= ("1000000000000");
                                subframes_slots_sectionids_table(1)(i_slot)(i_section) <= ("1000000000000");
                                
                            else                                                                                          
                            
                                if ((DL_CP_DETECT_ON_TIME = '1') and (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) ) then                    
                                    subframes_slots_sectionids_table(2)(i_slot)(i_section) <= PACKET_SECTION_ID(i_section);
                                end if;
                                
                            end if;                    
                        when "11" =>                              
                            if (DL_UP_DETECT_ON_TIME = '1') then
                            
                                if (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) then
                                    pkt_section_ids(i_slot)(i_section) <= subframes_slots_sectionids_table(3)(i_slot)(i_section);
                                end if;                                
                            
                                subframes_slots_sectionids_table(1)(i_slot)(i_section) <= ("1000000000000");
                                subframes_slots_sectionids_table(2)(i_slot)(i_section) <= ("1000000000000");
                                
                            else                                                                                          
                            
                                if ((DL_CP_DETECT_ON_TIME = '1') and (to_integer(unsigned(RX_PACKET_SLOT_ID)) = i_slot) ) then                    
                                    subframes_slots_sectionids_table(3)(i_slot)(i_section) <= PACKET_SECTION_ID(i_section);
                                end if;
                                
                            end if;
                        when others => 
                            NULL;        
                        end case;                                                                

                end if;
            end process; 
        end generate;
    
    end generate;
    
    u_SLOT_CHECK : for i_slot in SLOT_NUM-1 downto 0 generate

        u_COUPLING : for i_section in MAX_SECTIONID_PER_PKT-1 downto 0 generate
            process (CLK)
            begin
                if (CLK'event and CLK = '1') then
                   if (dl_up_det_on_time_d(0) = '1') then 
                       if (pkt_section_ids(i_slot)(i_section) = "1000000000000") then   -- section id = default => not updated
                           dl_cp_section_id_updated_check(i_slot)(i_section) <= '0';
                           dl_up_section_id_coupling_result(i_slot)(i_section) <= '0';                        
                       else                                                     -- section id != default => just been updated
                           dl_cp_section_id_updated_check(i_slot)(i_section) <= '1';
                       
                           if (pkt_section_ids(i_slot)(i_section)(12 downto 0) = PACKET_SECTION_ID(i_section)) then
                               dl_up_section_id_coupling_result(i_slot)(i_section) <= '1';
                           else                    
                               dl_up_section_id_coupling_result(i_slot)(i_section) <= '0';
                           end if;
                       end if;
                   end if;           
                end if;
            end process;
        end generate;
        
    end generate;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
           addr <= to_integer(unsigned(RX_PACKET_SLOT_ID));
           
           if (dl_cp_section_id_updated_check(addr) = 0) then           
               dl_up_excluded_rx_corrupt <= '1';
           else
               dl_up_excluded_rx_corrupt <= '0';
               
               if (dl_up_section_id_coupling_result(addr) = 0) then                   
                   dl_up_rx_corrupt_happened <= '1';         
               else
                   dl_up_rx_corrupt_happened <= '0';
               end if;                         
           end if;
        end if;
    end process;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            s_rx_corrupt_sectionid(0) <= dl_up_rx_corrupt_happened and dl_up_det_on_time_d(2);
            s_rx_corrupt_sectionid(3 downto 1) <= s_rx_corrupt_sectionid(2 downto 0);
        end if;
    end process;
    
    RX_CORRUPT_SECTIONID <= s_rx_corrupt_sectionid(0) or s_rx_corrupt_sectionid(1) or s_rx_corrupt_sectionid(2) or s_rx_corrupt_sectionid(3);

end BEHAVE;