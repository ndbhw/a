--------------------------------------------------------------------------------
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com) / nhu.dong
-- Date     : 2022.02.16
--------------------------------------------------------------------------------
-- Function description
--   1. Performance measurement component
--   2. RX window monitoring
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2022.02.16) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity RX_WINDOW_SHORT is
    generic (
        SCS_CONFIG_0                : boolean := true;
        SCS_CONFIG_1                : boolean := true;
        SCS_CONFIG_2                : boolean := true;
        SCS_CONFIG_3                : boolean := true;
        SCS_CONFIG_4                : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        WINDOW_START                : in  std_logic_vector(21 downto 0);
        WINDOW_END                  : in  std_logic_vector(21 downto 0);
        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        CLK_PACKET                  : in  std_logic;

        PACKET_EN                   : in  std_logic;
        PACKET_SCS                  : in  std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : in  std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : in  std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : in  std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : in  std_logic_vector(5 downto 0);
        
        DETECT_ON_TIME              : out std_logic;
        DETECT_EARLY                : out std_logic;
        DETECT_LATE                 : out std_logic;
        DETECT_OOR                  : out std_logic
    );
end RX_WINDOW_SHORT;

architecture BEHAVE of RX_WINDOW_SHORT is

    signal update_long_pulse        : std_logic_vector(15 downto 0) := (others => '0');
    signal update_buf               : std_logic_vector(2 downto 0) := (others => '0');
    signal update_cnt_sec           : std_logic_vector(6 downto 0) := (others => '0');
    signal update_cnt               : std_logic_vector(7 downto 0) := (others => '0');
    signal update_en                : std_logic := '0';

    signal cnt_detect_on_time       : std_logic_vector(63 downto 0) := (others => '0');
    signal cnt_detect_early         : std_logic_vector(63 downto 0) := (others => '0');
    signal cnt_detect_late          : std_logic_vector(63 downto 0) := (others => '0');
    signal cnt_detect_oor           : std_logic_vector(63 downto 0) := (others => '0');

    component ADV_TIMER is
    generic (
        SCS_CONFIG_0                : boolean := true;
        SCS_CONFIG_1                : boolean := true;
        SCS_CONFIG_2                : boolean := true;
        SCS_CONFIG_3                : boolean := true;
        SCS_CONFIG_4                : boolean := true
    );
    port (
        CLK_245p76MHz               : in  std_logic;
        CLK_CDC                     : in  std_logic;

        START_VALUE                 : in  std_logic_vector(21 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        FRAME_ID                    : out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : out std_logic_vector(3 downto 0);
        SLOT_ID                     : out std_logic_vector(19 downto 0);
        SYMBOL_ID                   : out std_logic_vector(19 downto 0)
    );
    end component;

    type std_logic_array6           is array(natural range <>) of std_logic_vector(5 downto 0);
    signal early_frame_id           : std_logic_vector(7 downto 0);
    signal early_subframe_id        : std_logic_vector(3 downto 0);
    signal early_slot_id_raw        : std_logic_vector(19 downto 0);
    signal early_slot_id            : std_logic_array6(4 downto 0);
    signal early_symbol_id_raw      : std_logic_vector(19 downto 0);
    signal early_symbol_id          : std_logic_array6(4 downto 0);
    signal late_frame_id            : std_logic_vector(7 downto 0);
    signal late_subframe_id         : std_logic_vector(3 downto 0);
    signal late_slot_id_raw         : std_logic_vector(19 downto 0);
    signal late_slot_id             : std_logic_array6(4 downto 0) := (others => (others => '0'));
    signal late_symbol_id_raw       : std_logic_vector(19 downto 0);
    signal late_symbol_id           : std_logic_array6(4 downto 0) := (others => (others => '0'));

    signal later_than_early         : std_logic_vector(2 downto 0) := (others => '0');
    signal earlier_than_late        : std_logic_vector(2 downto 0) := (others => '0');
    signal check                    : std_logic := '0';
    signal det_on_time              : std_logic := '0';
    signal det_early                : std_logic := '0';
    signal det_late                 : std_logic := '0';
    signal det_oor                  : std_logic := '0';


begin
---- test
--    DETECT_ON_TIME   <=   det_late or det_oor;  --det_on_time  ;
--    DETECT_EARLY     <=   det_early    ;
--    DETECT_LATE      <=   '0'; --det_late     ;
--    DETECT_OOR       <=   '0'; --det_oor      ;

--    DETECT_ON_TIME   <=   det_on_time  ;
--    DETECT_EARLY     <=   det_early    ;
--    DETECT_LATE      <=   det_late     ;
--    DETECT_OOR       <=   det_oor      ;

--------------------------------------------------------------------------------
-- Window check
--------------------------------------------------------------------------------

    u_EARLY_TIMER : ADV_TIMER
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;
        CLK_CDC                     => CLK_PACKET                              ,--: in  std_logic;

        START_VALUE                 => WINDOW_START                            ,--: in  std_logic_vector(21 downto 0);

        REF_10msec                  => REF_10msec                              ,--: in  std_logic;
        REF_SFN                     => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        FRAME_ID                    => early_frame_id                          ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => early_subframe_id                       ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => early_slot_id_raw                       ,--: out std_logic_vector(19 downto 0);
        SYMBOL_ID                   => early_symbol_id_raw                      --: out std_logic_vector(19 downto 0)
    );

    u_LATE_TIMER : ADV_TIMER
    generic map(
        SCS_CONFIG_0                => SCS_CONFIG_0                            ,--: boolean := true;
        SCS_CONFIG_1                => SCS_CONFIG_1                            ,--: boolean := true;
        SCS_CONFIG_2                => SCS_CONFIG_2                            ,--: boolean := true;
        SCS_CONFIG_3                => SCS_CONFIG_3                            ,--: boolean := true;
        SCS_CONFIG_4                => SCS_CONFIG_4                             --: boolean := true
    )
    port map(
        CLK_245p76MHz               => CLK_245p76MHz                           ,--: in  std_logic;
        CLK_CDC                     => CLK_PACKET                              ,--: in  std_logic;

        START_VALUE                 => WINDOW_END                              ,--: in  std_logic_vector(21 downto 0);

        REF_10msec                  => REF_10msec                              ,--: in  std_logic;
        REF_SFN                     => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        FRAME_ID                    => late_frame_id                           ,--: out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => late_subframe_id                        ,--: out std_logic_vector(3 downto 0);
        SLOT_ID                     => late_slot_id_raw                        ,--: out std_logic_vector(19 downto 0);
        SYMBOL_ID                   => late_symbol_id_raw                       --: out std_logic_vector(19 downto 0)
    );

    u_MAPPING : for i in 4 downto 0 generate
    early_slot_id(0)    <= "00" & early_slot_id_raw(3 downto 0);
    early_slot_id(1)    <= "00" & early_slot_id_raw(7 downto 4);
    early_slot_id(2)    <= "00" & early_slot_id_raw(11 downto 8);
    early_slot_id(3)    <= "00" & early_slot_id_raw(15 downto 12);
    early_slot_id(4)    <= "00" & early_slot_id_raw(19 downto 16);
    late_slot_id(0)     <= "00" & late_slot_id_raw(3 downto 0);
    late_slot_id(1)     <= "00" & late_slot_id_raw(7 downto 4);
    late_slot_id(2)     <= "00" & late_slot_id_raw(11 downto 8);
    late_slot_id(3)     <= "00" & late_slot_id_raw(15 downto 12);
    late_slot_id(4)     <= "00" & late_slot_id_raw(19 downto 16);

    early_symbol_id(0)  <= "00" & early_symbol_id_raw(3 downto 0);
    early_symbol_id(1)  <= "00" & early_symbol_id_raw(7 downto 4);
    early_symbol_id(2)  <= "00" & early_symbol_id_raw(11 downto 8);
    early_symbol_id(3)  <= "00" & early_symbol_id_raw(15 downto 12);
    early_symbol_id(4)  <= "00" & early_symbol_id_raw(19 downto 16);
    late_symbol_id(0)   <= "00" & late_symbol_id_raw(3 downto 0);
    late_symbol_id(1)   <= "00" & late_symbol_id_raw(7 downto 4);
    late_symbol_id(2)   <= "00" & late_symbol_id_raw(11 downto 8);
    late_symbol_id(3)   <= "00" & late_symbol_id_raw(15 downto 12);
    late_symbol_id(4)   <= "00" & late_symbol_id_raw(19 downto 16);
    end generate;

    -- detect whether packet is arrived later than start of RX window (frameId & subframeId)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if (PACKET_FRAME_ID = early_frame_id) then
--                    if (PACKET_SUBFRAME_ID <= early_subframe_id) then
                        later_than_early(0) <= '1';
--                    else
--                        later_than_early(0) <= '0';
--                    end if;
                else
                    if (early_frame_id - PACKET_FRAME_ID = 1) then
                        later_than_early(0) <= '1';
                    else
                        later_than_early(0) <= '0';
                    end if;
                end if;
            else
                later_than_early(0) <= '0';
            end if;
        end if;
    end process;

    -- detect whether packet is arrived later than start of RX window (subframeId & slotId)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if (PACKET_SUBFRAME_ID = early_subframe_id) then
                    if    (SCS_CONFIG_0 = true) and (PACKET_SCS = 0) then
--                        if (PACKET_SLOT_ID <= early_slot_id(0)) then
                            later_than_early(1) <= '1';
--                        else
--                            later_than_early(1) <= '0';
--                        end if;
                    elsif (SCS_CONFIG_1 = true) and (PACKET_SCS = 1) then
                        if (PACKET_SLOT_ID <= early_slot_id(1)) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_2 = true) and (PACKET_SCS = 2) then
                        if (PACKET_SLOT_ID <= early_slot_id(2)) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_3 = true) and (PACKET_SCS = 3) then
                        if (PACKET_SLOT_ID <= early_slot_id(3)) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_4 = true) and (PACKET_SCS = 4) then
                        if (PACKET_SLOT_ID <= early_slot_id(4)) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    else
                        later_than_early(1) <= '0';
                    end if;
                else
                    if (PACKET_SUBFRAME_ID = 9) then
                        if (early_subframe_id = 0) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    else
                        if (early_subframe_id - PACKET_SUBFRAME_ID = 1) then
                            later_than_early(1) <= '1';
                        else
                            later_than_early(1) <= '0';
                        end if;
                    end if;
                end if;
            else
                later_than_early(1) <= '0';
            end if;
        end if;
    end process;

    -- detect whether packet is arrived later than start of RX window (slotId & symbolid)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if    (SCS_CONFIG_0 = true) and (PACKET_SCS = 0) then
--                    if (PACKET_SLOT_ID = early_slot_id(0)) then
                    if (PACKET_SUBFRAME_ID = early_subframe_id) then
                        if (PACKET_SYMBOL_ID <= early_symbol_id(0)) then
                            later_than_early(2) <= '1';
                        else
                            later_than_early(2) <= '0';
                        end if;
                    else
                        later_than_early(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_1 = true) and (PACKET_SCS = 1) then
                    if (PACKET_SLOT_ID = early_slot_id(1)) then
                        if (PACKET_SYMBOL_ID <= early_symbol_id(1)) then
                            later_than_early(2) <= '1';
                        else
                            later_than_early(2) <= '0';
                        end if;
                    else
                        later_than_early(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_2 = true) and (PACKET_SCS = 2) then
                    if (PACKET_SLOT_ID = early_slot_id(2)) then
                        if (PACKET_SYMBOL_ID <= early_symbol_id(2)) then
                            later_than_early(2) <= '1';
                        else
                            later_than_early(2) <= '0';
                        end if;
                    else
                        later_than_early(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_3 = true) and (PACKET_SCS = 3) then
                    if (PACKET_SLOT_ID = early_slot_id(3)) then
                        if (PACKET_SYMBOL_ID <= early_symbol_id(3)) then
                            later_than_early(2) <= '1';
                        else
                            later_than_early(2) <= '0';
                        end if;
                    else
                        later_than_early(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_4 = true) and (PACKET_SCS = 4) then
                    if (PACKET_SLOT_ID = early_slot_id(4)) then
                        if (PACKET_SYMBOL_ID <= early_symbol_id(4)) then
                            later_than_early(2) <= '1';
                        else
                            later_than_early(2) <= '0';
                        end if;
                    else
                        later_than_early(2) <= '1';
                    end if;
                else
                    later_than_early(2) <= '0';
                end if;
            else
                later_than_early(2) <= '0';
            end if;
        end if;
    end process;

    -- detect whether packet is arrived earlier than end of RX window (frameId & subframeId)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if (PACKET_FRAME_ID = late_frame_id) then
--                    if (PACKET_SUBFRAME_ID >= late_subframe_id) then
                        earlier_than_late(0) <= '1';
--                    else
--                        earlier_than_late(0) <= '0';
--                    end if;
                else
                    if (PACKET_FRAME_ID - late_frame_id = 1) then
                        earlier_than_late(0) <= '1';
                    else
                        earlier_than_late(0) <= '0';
                    end if;
                end if;
            else
                earlier_than_late(0) <= '0';
            end if;
        end if;
    end process;

    -- detect whether packet is arrived earlier than end of RX window (subframeId & slotId)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if (PACKET_SUBFRAME_ID = late_subframe_id) then
                    if    (SCS_CONFIG_0 = true) and (PACKET_SCS = 0) then
--                        if (PACKET_SLOT_ID >= late_slot_id(0)) then
                            earlier_than_late(1) <= '1';
--                        else
--                            earlier_than_late(1) <= '0';
--                        end if;
                    elsif (SCS_CONFIG_1 = true) and (PACKET_SCS = 1) then
                        if (PACKET_SLOT_ID >= late_slot_id(1)) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_2 = true) and (PACKET_SCS = 2) then
                        if (PACKET_SLOT_ID >= late_slot_id(2)) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_3 = true) and (PACKET_SCS = 3) then
                        if (PACKET_SLOT_ID >= late_slot_id(3)) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    elsif (SCS_CONFIG_4 = true) and (PACKET_SCS = 4) then
                        if (PACKET_SLOT_ID >= late_slot_id(4)) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    else
                        earlier_than_late(1) <= '0';
                    end if;
                else
                    if (late_subframe_id = 9) then
                        if (PACKET_SUBFRAME_ID = 0) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    else
                        if (PACKET_SUBFRAME_ID - late_subframe_id = 1) then
                            earlier_than_late(1) <= '1';
                        else
                            earlier_than_late(1) <= '0';
                        end if;
                    end if;
                end if;
            else
                earlier_than_late(1) <= '0';
            end if;
        end if;
    end process;

    -- detect whether packet is arrived earlier than end of RX window (slotId & symbolid)
    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = '1') then
                if    (SCS_CONFIG_0 = true) and (PACKET_SCS = 0) then
--                    if (PACKET_SLOT_ID = late_slot_id(0)) then
                    if (PACKET_SUBFRAME_ID = late_subframe_id) then
                        if (PACKET_SYMBOL_ID > late_symbol_id(0)) then
                            earlier_than_late(2) <= '1';
                        else
                            earlier_than_late(2) <= '0';
                        end if;
                    else
                        earlier_than_late(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_1 = true) and (PACKET_SCS = 1) then
                    if (PACKET_SLOT_ID = late_slot_id(1)) then
                        if (PACKET_SYMBOL_ID > late_symbol_id(1)) then
                            earlier_than_late(2) <= '1';
                        else
                            earlier_than_late(2) <= '0';
                        end if;
                    else
                        earlier_than_late(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_2 = true) and (PACKET_SCS = 2) then
                    if (PACKET_SLOT_ID = late_slot_id(2)) then
                        if (PACKET_SYMBOL_ID > late_symbol_id(2)) then
                            earlier_than_late(2) <= '1';
                        else
                            earlier_than_late(2) <= '0';
                        end if;
                    else
                        earlier_than_late(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_3 = true) and (PACKET_SCS = 3) then
                    if (PACKET_SLOT_ID = late_slot_id(3)) then
                        if (PACKET_SYMBOL_ID > late_symbol_id(3)) then
                            earlier_than_late(2) <= '1';
                        else
                            earlier_than_late(2) <= '0';
                        end if;
                    else
                        earlier_than_late(2) <= '1';
                    end if;
                elsif (SCS_CONFIG_4 = true) and (PACKET_SCS = 4) then
                    if (PACKET_SLOT_ID = late_slot_id(4)) then
                        if (PACKET_SYMBOL_ID > late_symbol_id(4)) then
                            earlier_than_late(2) <= '1';
                        else
                            earlier_than_late(2) <= '0';
                        end if;
                    else
                        earlier_than_late(2) <= '1';
                    end if;
                else
                    earlier_than_late(2) <= '0';
                end if;
            else
                earlier_than_late(2) <= '0';
            end if;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            check <= PACKET_EN;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (check = '1') then
                if    (later_than_early = "111") and (earlier_than_late = "111") then
                    DETECT_ON_TIME <= '1';
                else
                    DETECT_ON_TIME <= '0';
                end if;
            else
                DETECT_ON_TIME <= '0';
            end if;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (check = '1') then
                if (later_than_early /= "111") and (earlier_than_late = "111") then
                    DETECT_EARLY <= '1';
                else
                    DETECT_EARLY <= '0';
                end if;
            else
                DETECT_EARLY <= '0';
            end if;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (check = '1') then
                if (later_than_early = "111") and (earlier_than_late /= "111") then
                    DETECT_LATE <= '1';
                else
                    DETECT_LATE <= '0';
                end if;
            else
                DETECT_LATE <= '0';
            end if;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (check = '1') then
                if (later_than_early /= "111") and (earlier_than_late /= "111") then
                    DETECT_OOR <= '1';
                else
                    DETECT_OOR <= '0';
                end if;
            else
                DETECT_OOR <= '0';
            end if;
        end if;
    end process;

    
end BEHAVE;