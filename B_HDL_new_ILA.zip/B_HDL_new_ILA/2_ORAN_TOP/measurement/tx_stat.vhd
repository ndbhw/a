--------------------------------------------------------------------------------
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2022.02.16
--------------------------------------------------------------------------------
-- Function description
--   1. Performance measurement component
--   2. TX monitoring
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2022.02.16) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity TX_STAT is
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        WINDOW_PERIOD               : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_CLEAR                   : in  std_logic_vector(0 downto 0);

        CNT_TOTAL                   : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        CLK_PACKET                  : in  std_logic;

        PACKET_EN                   : in  std_logic_vector(0 downto 0)
    );
end TX_STAT;

architecture BEHAVE of TX_STAT is

    constant PORT_WIDTH             : natural := 1;

    signal update_long_pulse        : std_logic_vector(15 downto 0) := (others => '0');
    signal update_buf               : std_logic_vector(2 downto 0) := (others => '0');
    signal update_cnt_sec           : std_logic_vector(6 downto 0) := (others => '0');
    signal update_cnt               : std_logic_vector(7 downto 0) := (others => '0');
    signal update_en                : std_logic := '0';

    signal cnt_detect               : std_logic_vector(63 downto 0) := (others => '0');

    component TIMESTAMP is
    generic (
        FIFO_WIDTH                  : natural := 16
    );
    port (
        RST                         : in  std_logic;
        WR_CLK                      : in  std_logic;
        RD_CLK                      : in  std_logic;
        DIN                         : in  std_logic_vector(FIFO_WIDTH-1 downto 0);
        WR_EN                       : in  std_logic;
        RD_EN                       : in  std_logic;
        DOUT                        : out std_logic_vector(FIFO_WIDTH-1 downto 0);
        FULL                        : out std_logic;
        EMPTY                       : out std_logic;
        WR_DATA_COUNT               : out std_logic_vector(3 downto 0)
    );
    end component;

    signal din                      : std_logic_vector(PORT_WIDTH-1 downto 0);
    signal wr_en                    : std_logic;
    signal rd_en                    : std_logic;
--    signal dout                     : std_logic_vector(PORT_WIDTH-1 downto 0);
    signal full                     : std_logic;
    signal empty                    : std_logic;

    signal check                    : std_logic := '0';

begin

--------------------------------------------------------------------------------
-- Update counters per its period
--------------------------------------------------------------------------------

    process (CLK_245p76MHz)
    begin
        if (CLK_245p76MHz'event and CLK_245p76MHz = '1') then
            if (REF_10msec = '1') then
                update_long_pulse <= (others => '1');
            else
                update_long_pulse <= update_long_pulse(14 downto 0) & '0';
            end if;
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            update_buf <= update_buf(1 downto 0) & update_long_pulse(15);
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (update_buf(2 downto 1) = "01") then
                if (update_cnt_sec = 99) then
                    update_cnt_sec <= (others => '0');
                else
                    update_cnt_sec <= update_cnt_sec + 1;
                end if;
            end if;
        end if;
    end process;

    process (RST_CPUIF, CLK_CPUIF)
    begin
        if (RST_CPUIF = '1') then
            update_cnt <= (others => '0');
        elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (update_buf(2 downto 1) = "01") and (update_cnt_sec = 99) then
                if (update_cnt = WINDOW_PERIOD) then
                    update_cnt <= (others => '0');
                else
                    update_cnt <= update_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (update_buf(2 downto 1) = "01") and (update_cnt_sec = 99) and (update_cnt = WINDOW_PERIOD) then
                update_en <= '1';
            else
                update_en <= '0';
            end if;
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (update_en = '1') then
                CNT_TOTAL <= cnt_detect;
            elsif (CNT_CLEAR = "1") then
                CNT_TOTAL <= (others => '0');
            end if;
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            din <= "1";
        end if;
    end process;

    process (CLK_PACKET)
    begin
        if (CLK_PACKET'event and CLK_PACKET = '1') then
            if (PACKET_EN = "1") then
                wr_en <= not full;
            else
                wr_en <= '0';
            end if;
        end if;
    end process;

    u_TIMESTAMP : TIMESTAMP
    generic map(
        FIFO_WIDTH                  => PORT_WIDTH                               --: natural := 16
    )
    port map(
        RST                         => RST_CPUIF                               ,--: in  std_logic;
        WR_CLK                      => CLK_PACKET                              ,--: in  std_logic;
        RD_CLK                      => CLK_CPUIF                               ,--: in  std_logic;
        DIN                         => din                                     ,--: in  std_logic_vector(FIFO_WIDTH-1 downto 0);
        WR_EN                       => wr_en                                   ,--: in  std_logic;
        RD_EN                       => rd_en                                   ,--: in  std_logic;
        DOUT                        => open                                    ,--: out std_logic_vector(FIFO_WIDTH-1 downto 0);
        FULL                        => full                                    ,--: out std_logic;
        EMPTY                       => empty                                   ,--: out std_logic;
        WR_DATA_COUNT               => open                                     --: out std_logic_vector(3 downto 0)
    );

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            rd_en <= not empty;
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            check <= rd_en and (not empty);
        end if;
    end process;

    process (CLK_CPUIF)
    begin
        if (CLK_CPUIF'event and CLK_CPUIF = '1') then
            if (update_en = '1') then
                if (check = '1') then
                    cnt_detect <= x"0000000000000000" + 1;
                else
                    cnt_detect <= x"0000000000000000";
                end if;
            else
                if (check = '1') then
                    cnt_detect <= cnt_detect + 1;
                end if;
            end if;
        end if;
    end process;

end BEHAVE;