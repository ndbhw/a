--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Packet filter (Max 8-CHs multiplexing)                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity PKT_FILTER is
    generic (
        MAX_CH                      : natural := 8;
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CLK_BUS                     : in  std_logic;
--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_MAC                   : in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_0_EN           : in  std_logic;
        PARAM_ID_CH0_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_1_EN           : in  std_logic;
        PARAM_ID_CH0_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_2_EN           : in  std_logic;
        PARAM_ID_CH0_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_3_EN           : in  std_logic;
        PARAM_ID_CH0_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_0_EN           : in  std_logic;
        PARAM_ID_CH1_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_1_EN           : in  std_logic;
        PARAM_ID_CH1_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_2_EN           : in  std_logic;
        PARAM_ID_CH1_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_3_EN           : in  std_logic;
        PARAM_ID_CH1_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_0_EN           : in  std_logic;
        PARAM_ID_CH2_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_1_EN           : in  std_logic;
        PARAM_ID_CH2_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_2_EN           : in  std_logic;
        PARAM_ID_CH2_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_3_EN           : in  std_logic;
        PARAM_ID_CH2_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_0_EN           : in  std_logic;
        PARAM_ID_CH3_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_1_EN           : in  std_logic;
        PARAM_ID_CH3_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_2_EN           : in  std_logic;
        PARAM_ID_CH3_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_3_EN           : in  std_logic;
        PARAM_ID_CH3_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_0_EN           : in  std_logic;
        PARAM_ID_CH4_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_1_EN           : in  std_logic;
        PARAM_ID_CH4_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_2_EN           : in  std_logic;
        PARAM_ID_CH4_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_3_EN           : in  std_logic;
        PARAM_ID_CH4_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_0_EN           : in  std_logic;
        PARAM_ID_CH5_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_1_EN           : in  std_logic;
        PARAM_ID_CH5_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_2_EN           : in  std_logic;
        PARAM_ID_CH5_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_3_EN           : in  std_logic;
        PARAM_ID_CH5_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_0_EN           : in  std_logic;
        PARAM_ID_CH6_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_1_EN           : in  std_logic;
        PARAM_ID_CH6_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_2_EN           : in  std_logic;
        PARAM_ID_CH6_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_3_EN           : in  std_logic;
        PARAM_ID_CH6_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_0_EN           : in  std_logic;
        PARAM_ID_CH7_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_1_EN           : in  std_logic;
        PARAM_ID_CH7_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_2_EN           : in  std_logic;
        PARAM_ID_CH7_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_3_EN           : in  std_logic;
        PARAM_ID_CH7_3              : in  std_logic_vector(15 downto 0);

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_INVALID_DST_MAC         : out std_logic_vector(31 downto 0);
        CNT_INVALID_ETHERTYPE       : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriVersion    : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriC          : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriMessage    : out std_logic_vector(31 downto 0);
        CNT_C_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_C_PLANE_DROPPED         : out std_logic_vector(31 downto 0);
        CNT_U_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         : out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         : out std_logic_vector(31 downto 0);

        C_PLANE_EXIST               : out std_logic_vector(31 downto 0);
        U_PLANE_EXIST               : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_FULL                    : in  std_logic;

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_DEST                    : out std_logic_vector(0 downto 0);
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_SUB                  : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Data bus (Bypass)
--------------------------------------------------------------------------------

        BYPASS_OUT_VALID            : out std_logic;
        BYPASS_OUT_LAST             : out std_logic;
        BYPASS_OUT_KEEP             : out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        
        MAC_HEADER_REMOVED_OUT_VALID        : out std_logic_vector(2 downto 0);         -- [0] : CP, [1] : UP, [2] : Others
        MAC_HEADER_REMOVED_OUT_LAST         : out std_logic;
        MAC_HEADER_REMOVED_OUT_KEEP         : out std_logic_vector(7 downto 0);
        MAC_HEADER_REMOVED_OUT_DATA         : out std_logic_vector(63 downto 0);
        
        RX_CORRUPT_SECTIONID        : out std_logic                

    );
end PKT_FILTER;

architecture BEHAVE of PKT_FILTER is

    type std_logic_array3           is array(natural range <>) of std_logic_vector(2 downto 0);
    type std_logic_array8           is array(natural range <>) of std_logic_vector(7 downto 0);
    type std_logic_array64          is array(natural range <>) of std_logic_vector(63 downto 0);

    signal valid_in_reg             : std_logic := '0';
    signal last_in_reg              : std_logic := '0';
    signal keep_in_reg              : std_logic_vector(7 downto 0) := (others => '0');
    signal data_in_reg              : std_logic_vector(63 downto 0) := (others => '0');

    constant MAX_SECTIONID_PER_PKT  :  natural range 0 to 100 := 98;
    
    component MAC_FILTER is
    generic (
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true
    );
    port (

        CLK                         : in  std_logic;

        PARAM_MAC                   : in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             : in  std_logic_vector(15 downto 0);

        CNT_INVALID_DST_MAC         : out std_logic_vector(31 downto 0);
        CNT_INVALID_ETHERTYPE       : out std_logic_vector(31 downto 0);

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);

        OUT_VLAN_MODE               : out std_logic_vector(1 downto 0)
    );
    end component;

    signal mac_filter_valid         : std_logic;
    signal mac_filter_last          : std_logic;
    signal mac_filter_keep          : std_logic_vector(7 downto 0);
    signal mac_filter_data          : std_logic_vector(63 downto 0);
    signal mac_filter_vlan_mode     : std_logic_vector(1 downto 0);

    component MAC_HEADER_REMOVE is
    port (
        CLK                         : in  std_logic;

        CNT_INVALID_ecpriVersion    : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriC          : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriMessage    : out std_logic_vector(31 downto 0);

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        IN_VLAN_MODE                : in  std_logic_vector(1 downto 0);

        OUT_VALID                   : out std_logic_vector(2 downto 0);
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0)
    );
    end component;

    signal mac_out_valid            : std_logic_vector(2 downto 0);
    signal mac_out_last             : std_logic;
    signal mac_out_keep             : std_logic_vector(7 downto 0);
    signal mac_out_data             : std_logic_vector(63 downto 0);

    component ORAN_FILTER_CORE is
    generic (
        DIRECTION                   : string := "DL";
        MAX_ID                      : natural := 8;
        USAGE_ID                    : std_logic_vector(7 downto 0) := "11111111"
    );
    port (
        CLK                         : in  std_logic;

        PARAM_ID0_EN                : in  std_logic;
        PARAM_ID0                   : in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                : in  std_logic;
        PARAM_ID1                   : in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                : in  std_logic;
        PARAM_ID2                   : in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                : in  std_logic;
        PARAM_ID3                   : in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                : in  std_logic;
        PARAM_ID4                   : in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                : in  std_logic;
        PARAM_ID5                   : in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                : in  std_logic;
        PARAM_ID6                   : in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                : in  std_logic;
        PARAM_ID7                   : in  std_logic_vector(15 downto 0);

        CNT_C_PLANE_DROPPED         : out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         : out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         : out std_logic_vector(31 downto 0);

        IN_VALID                    : in  std_logic_vector(1 downto 0);
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_FULL                    : in  std_logic;

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_DEST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);
        OUT_STAMP                   : out std_logic;
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  : out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION: out std_logic
    );
    end component;

    signal buf_valid                : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_last                 : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_dest                 : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_keep                 : std_logic_array8(3 downto 0) := (others => (others => '0'));
    signal buf_data                 : std_logic_array64(3 downto 0) := (others => (others => '0'));
    signal buf_stamp                : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_ch                   : std_logic_array3(3 downto 0) := (others => (others => '0'));
    signal buf_ch_bit               : std_logic_array8(3 downto 0) := (others => (others => '0'));

    signal filtered_valid           : std_logic := '0';
    signal filtered_last            : std_logic := '0';
    signal filtered_dest            : std_logic := '0';
    signal filtered_keep            : std_logic_vector(7 downto 0) := (others => '0');
    signal filtered_data            : std_logic_vector(63 downto 0) := (others => '0');
    signal filtered_stamp           : std_logic := '0';
    signal filtered_ch              : std_logic_vector(2 downto 0) := (others => '0');
    signal filtered_ch_sub          : std_logic_vector(3 downto 0) := (others => '0');

    signal corrupt_dl_cu_filtered_last            : std_logic := '0';
    signal corrupt_dl_cu_filtered_keep            : std_logic_vector(7 downto 0) := (others => '0');
    signal corrupt_dl_cu_filtered_data            : std_logic_vector(63 downto 0) := (others => '0');
    signal corrupt_dl_cu_filtered_stamp           : std_logic := '0';
    
    signal s_64_to_32_o_tvalid        : std_logic;
    signal s_64_to_32_o_tlast         : std_logic;    
    signal s_64_to_32_o_tkeep         : std_logic_vector(3 downto 0);
    signal s_64_to_32_o_tdata         : std_logic_vector(31 downto 0);
    
    signal s_64_to_32_o_tvalid_d        : std_logic;
    signal s_64_to_32_o_tlast_d         : std_logic;    
    signal s_64_to_32_o_tkeep_swap      : std_logic_vector(3 downto 0);
    signal s_64_to_32_o_tdata_swap      : std_logic_vector(31 downto 0);

    component ORAN_STAMPING is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0)
    );
    end component;

    signal c_plane_exist_buf        : std_logic_vector(31 downto 0) := (others => '0');
    signal u_plane_exist_buf        : std_logic_vector(31 downto 0) := (others => '0');

    signal rx_c_plane_cnt           : std_logic_vector(15 downto 0) := (others => '0');
    signal rx_u_plane_cnt           : std_logic_vector(15 downto 0) := (others => '0');

    component FROM_64_TO_32 is
    port (
        ARESET                      : in  std_logic;

        IN_CLK                      : in  std_logic;

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);
        IN_USER                     : in  std_logic_vector(6 downto 0);

        OUT_CLK                     : in  std_logic;

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(3 downto 0);
        OUT_DATA                    : out std_logic_vector(31 downto 0);
        OUT_USER                    : out std_logic_vector(6 downto 0)
    );
    end component;

    component oran_stamping_32x8 is
    generic (
        USAGE_TYPE0                 : boolean := false;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := false;
        USAGE_TYPE7                 : boolean := false;
        MAX_ID                      : natural := 8;
        USAGE_ID                    : std_logic_vector(7 downto 0) := "11111111";
        MAX_SECTIONID_PER_PKT       : natural := 5
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 245.76-MHz
        RST                         : in  std_logic;                            -- CLK

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_ID0_EN                : in  std_logic;
        PARAM_ID0                   : in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                : in  std_logic;
        PARAM_ID1                   : in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                : in  std_logic;
        PARAM_ID2                   : in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                : in  std_logic;
        PARAM_ID3                   : in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                : in  std_logic;
        PARAM_ID4                   : in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                : in  std_logic;
        PARAM_ID5                   : in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                : in  std_logic;
        PARAM_ID6                   : in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                : in  std_logic;
        PARAM_ID7                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- C-U-Plane
--------------------------------------------------------------------------------

        CP32_VALID                  : in  std_logic;
        CP32_LAST                   : in  std_logic;
        CP32_DATA                   : in  std_logic_vector(31 downto 0);
        CP32_DATA_MAP               : in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             : in  std_logic_vector(2 downto 0);
		
--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;

        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : out std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
        
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  : out std_logic_vector(7 downto 0)
		
    );
    end component;

    signal pkt_section_ids           : std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);


    component MEASUREMENT_SHORT is
    generic (
        NUM_TX                      : natural := 1;
        MAX_SECTIONID_PER_PKT       : natural := 5
    );
    port (
        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK_245p76MHz               : in  std_logic;

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;
        REF_SFN                     : in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        
        RX_PACKET_CLK               : in  std_logic;
        RX_VLD_IN                   : in std_logic;

        RX_PACKET_IS_CP_DL          : in  std_logic;        
        RX_PACKET_IS_UP_DL          : in  std_logic;
        RX_PACKET_SCS               : in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : in std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
        
        DL_CP_DETECT_ON_TIME        : out std_logic; 
        DL_CP_DETECT_EARLY          : out std_logic; 
        DL_CP_DETECT_LATE           : out std_logic; 
        DL_CP_DETECT_OOR            : out std_logic; 
                                                     
        DL_UP_DETECT_ON_TIME        : out std_logic; 
        DL_UP_DETECT_EARLY          : out std_logic; 
        DL_UP_DETECT_LATE           : out std_logic; 
        DL_UP_DETECT_OOR            : out std_logic  

    );
    end component;

    signal rx_packet_is_cp_dl       : std_logic;                    
    signal rx_packet_is_cp_ul       : std_logic;                    
    signal rx_packet_is_up_dl       : std_logic;                    
    signal rx_packet_scs            : std_logic_vector(3 downto 0); 
    signal rx_packet_frame_id       : std_logic_vector(7 downto 0); 
    signal rx_packet_subframe_id    : std_logic_vector(3 downto 0); 
    signal rx_packet_slot_id        : std_logic_vector(5 downto 0); 
    signal rx_packet_symbol_id      : std_logic_vector(5 downto 0);

    signal buf_ch_32x8              : std_logic_vector(2 downto 0) := (others => '0');
    signal buf_ch_bit_32x8          : std_logic_vector(7 downto 0) := (others => '0');
    
    signal pkt_msr_valid_by_eaxcid  : std_logic_vector(3 downto 0) := (others => '0');
    
    component sectionid_coupling_validation is
    generic (
        MAX_SECTIONID_PER_PKT       : natural := 5;
        MU                          : natural := 6  -- numerology: 0 -> 6 

    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

        CLK                         : in  std_logic;                            -- 245.76-MHz
        
--------------------------------------------------------------------------------
-- Packet stamp for RX
--------------------------------------------------------------------------------        
        RX_PACKET_FRAME_ID          : in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       : in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           : in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         : in  std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : in  std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);
        
        DL_CP_DETECT_ON_TIME        : in std_logic;          
        DL_UP_DETECT_ON_TIME        : in std_logic;
        
        RX_CORRUPT_SECTIONID        : out std_logic            
    );
    end component;
    
    signal dl_cp_det_on_time              : std_logic_vector(3 downto 0) := (others => '0');    
    signal dl_up_det_on_time              : std_logic_vector(3 downto 0) := (others => '0');
    
--    signal s_rx_corrupt_ecpriversion_payloadversion_pcid : std_logic_vector(3 downto 0) := (others => '0');
    signal s_rx_corrupt_sectionid : std_logic_vector(3 downto 0) := (others => '0');
        
begin

--------------------------------------------------------------------------------
-- In/out port registering
--------------------------------------------------------------------------------

    IN_READY <= '1';

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            valid_in_reg <= IN_VALID;
            last_in_reg  <= IN_LAST;
            keep_in_reg  <= IN_KEEP;
            data_in_reg  <= IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            OUT_VALID   <= filtered_valid;
            OUT_LAST    <= filtered_last;
            OUT_DEST(0) <= filtered_dest;
            OUT_KEEP    <= filtered_keep;
            OUT_DATA    <= filtered_data;
            OUT_CH      <= filtered_ch;
            OUT_CH_SUB  <= filtered_ch_sub;
        end if;
    end process;

--------------------------------------------------------------------------------
-- MAC layer
--------------------------------------------------------------------------------

    u_MAC : MAC_FILTER
    generic map(
        FILTER_MAC                  => FILTER_MAC                              ,--: boolean := true;
        FILTER_ETHERTYPE            => FILTER_ETHERTYPE                         --: boolean := true
    )
    port map(

        CLK                         => CLK                                     ,--: in  std_logic;

        PARAM_MAC                   => PARAM_MAC                               ,--: in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             => PARAM_ETHERTYPE                         ,--: in  std_logic_vector(15 downto 0);

        CNT_INVALID_DST_MAC         => CNT_INVALID_DST_MAC                     ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ETHERTYPE       => CNT_INVALID_ETHERTYPE                   ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => valid_in_reg                            ,--: in  std_logic;
        IN_LAST                     => last_in_reg                             ,--: in  std_logic;
        IN_KEEP                     => keep_in_reg                             ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => data_in_reg                             ,--: in  std_logic_vector(63 downto 0);

        OUT_VALID                   => mac_filter_valid                        ,--: out std_logic;
        OUT_LAST                    => mac_filter_last                         ,--: out std_logic;
        OUT_KEEP                    => mac_filter_keep                         ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => mac_filter_data                         ,--: out std_logic_vector(63 downto 0);

        OUT_VLAN_MODE               => mac_filter_vlan_mode                     --: out std_logic_vector(1 downto 0)
    );

    u_CONV_eCPRI : MAC_HEADER_REMOVE
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        CNT_INVALID_ecpriVersion    => CNT_INVALID_ecpriVersion                ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriC          => CNT_INVALID_ecpriC                      ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriMessage    => CNT_INVALID_ecpriMessage                ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => mac_filter_valid                        ,--: in  std_logic;
        IN_LAST                     => mac_filter_last                         ,--: in  std_logic;
        IN_KEEP                     => mac_filter_keep                         ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => mac_filter_data                         ,--: in  std_logic_vector(63 downto 0);

        IN_VLAN_MODE                => mac_filter_vlan_mode                    ,--: in  std_logic_vector(1 downto 0);

        OUT_VALID                   => mac_out_valid                           ,--: out std_logic_vector(2 downto 0);
        OUT_LAST                    => mac_out_last                            ,--: out std_logic;
        OUT_KEEP                    => mac_out_keep                            ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => mac_out_data                             --: out std_logic_vector(63 downto 0)
    );

    MAC_HEADER_REMOVED_OUT_VALID    <= mac_out_valid;
    MAC_HEADER_REMOVED_OUT_LAST     <= mac_out_last;
    MAC_HEADER_REMOVED_OUT_KEEP     <= mac_out_keep;
    MAC_HEADER_REMOVED_OUT_DATA     <= mac_out_data;
--------------------------------------------------------------------------------
-- eCPRI/ORAN layer
--------------------------------------------------------------------------------

    u_FILTER0 : ORAN_FILTER_CORE
    generic map(
        DIRECTION                   => "DL"                                    ,--: string := "DL";
        MAX_ID                      => MAX_CH                                  ,--: natural := 8;
        USAGE_ID                    => (others => '1')                          --: std_logic_vector(3 downto 0) := "11111111"
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        PARAM_ID0_EN                => PARAM_ID_CH0_0_EN                       ,--: in  std_logic;
        PARAM_ID0                   => PARAM_ID_CH0_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => PARAM_ID_CH1_0_EN                       ,--: in  std_logic;
        PARAM_ID1                   => PARAM_ID_CH1_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => PARAM_ID_CH2_0_EN                       ,--: in  std_logic;
        PARAM_ID2                   => PARAM_ID_CH2_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => PARAM_ID_CH3_0_EN                       ,--: in  std_logic;
        PARAM_ID3                   => PARAM_ID_CH3_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => PARAM_ID_CH4_0_EN                       ,--: in  std_logic;
        PARAM_ID4                   => PARAM_ID_CH4_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => PARAM_ID_CH5_0_EN                       ,--: in  std_logic;
        PARAM_ID5                   => PARAM_ID_CH5_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => PARAM_ID_CH6_0_EN                       ,--: in  std_logic;
        PARAM_ID6                   => PARAM_ID_CH6_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => PARAM_ID_CH7_0_EN                       ,--: in  std_logic;
        PARAM_ID7                   => PARAM_ID_CH7_0                          ,--: in  std_logic_vector(15 downto 0);

        CNT_C_PLANE_DROPPED         => CNT_C_PLANE_DROPPED                     ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         => CNT_U_PLANE_DROPPED                     ,--: out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        => CNT_LENGTH_IS_NORMAL                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          => CNT_LENGTH_IS_LONG                      ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         => CNT_LENGTH_IS_SHORT                     ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => mac_out_valid(1 downto 0)               ,--: in  std_logic_vector(1 downto 0);
        IN_LAST                     => mac_out_last                            ,--: in  std_logic;
        IN_KEEP                     => mac_out_keep                            ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => mac_out_data                            ,--: in  std_logic_vector(63 downto 0);

        OUT_FULL                    => OUT_FULL                                ,--: in  std_logic;

        OUT_VALID                   => buf_valid(0)                            ,--: out std_logic;
        OUT_LAST                    => buf_last(0)                             ,--: out std_logic;
        OUT_DEST                    => buf_dest(0)                             ,--: out std_logic;
        OUT_KEEP                    => buf_keep(0)                             ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => buf_data(0)                             ,--: out std_logic_vector(63 downto 0);
        OUT_STAMP                   => buf_stamp(0)                            ,--: out std_logic;
        OUT_CH                      => buf_ch(0)                               ,--: out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  => buf_ch_bit(0)                            --: out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION => s_rx_corrupt_ecpriversion_payloadversion_pcid(0)
    );

    u_FILTER1 : ORAN_FILTER_CORE
    generic map(
        DIRECTION                   => "DL"                                    ,--: string := "DL";
        MAX_ID                      => MAX_CH                                  ,--: natural := 8;
        USAGE_ID                    => (others => '1')                          --: std_logic_vector(3 downto 0) := "11111111"
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        PARAM_ID0_EN                => PARAM_ID_CH0_1_EN                       ,--: in  std_logic;
        PARAM_ID0                   => PARAM_ID_CH0_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => PARAM_ID_CH1_1_EN                       ,--: in  std_logic;
        PARAM_ID1                   => PARAM_ID_CH1_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => PARAM_ID_CH2_1_EN                       ,--: in  std_logic;
        PARAM_ID2                   => PARAM_ID_CH2_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => PARAM_ID_CH3_1_EN                       ,--: in  std_logic;
        PARAM_ID3                   => PARAM_ID_CH3_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => PARAM_ID_CH4_1_EN                       ,--: in  std_logic;
        PARAM_ID4                   => PARAM_ID_CH4_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => PARAM_ID_CH5_1_EN                       ,--: in  std_logic;
        PARAM_ID5                   => PARAM_ID_CH5_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => PARAM_ID_CH6_1_EN                       ,--: in  std_logic;
        PARAM_ID6                   => PARAM_ID_CH6_1                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => PARAM_ID_CH7_1_EN                       ,--: in  std_logic;
        PARAM_ID7                   => PARAM_ID_CH7_1                          ,--: in  std_logic_vector(15 downto 0);

        CNT_C_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         => open                                    ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => mac_out_valid(1 downto 0)               ,--: in  std_logic_vector(1 downto 0);
        IN_LAST                     => mac_out_last                            ,--: in  std_logic;
        IN_KEEP                     => mac_out_keep                            ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => mac_out_data                            ,--: in  std_logic_vector(63 downto 0);

        OUT_FULL                    => OUT_FULL                                ,--: in  std_logic;

        OUT_VALID                   => buf_valid(1)                            ,--: out std_logic;
        OUT_LAST                    => buf_last(1)                             ,--: out std_logic;
        OUT_DEST                    => buf_dest(1)                             ,--: out std_logic;
        OUT_KEEP                    => buf_keep(1)                             ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => buf_data(1)                             ,--: out std_logic_vector(63 downto 0);
        OUT_STAMP                   => buf_stamp(1)                            ,--: out std_logic;
        OUT_CH                      => buf_ch(1)                               ,--: out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  => buf_ch_bit(1)                            --: out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION => s_rx_corrupt_ecpriversion_payloadversion_pcid(1)
    );

    u_FILTER2 : ORAN_FILTER_CORE
    generic map(
        DIRECTION                   => "UL"                                    ,--: string := "DL";
        MAX_ID                      => MAX_CH                                  ,--: natural := 8;
        USAGE_ID                    => (others => '1')                          --: std_logic_vector(3 downto 0) := "11111111"
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        PARAM_ID0_EN                => PARAM_ID_CH0_2_EN                       ,--: in  std_logic;
        PARAM_ID0                   => PARAM_ID_CH0_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => PARAM_ID_CH1_2_EN                       ,--: in  std_logic;
        PARAM_ID1                   => PARAM_ID_CH1_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => PARAM_ID_CH2_2_EN                       ,--: in  std_logic;
        PARAM_ID2                   => PARAM_ID_CH2_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => PARAM_ID_CH3_2_EN                       ,--: in  std_logic;
        PARAM_ID3                   => PARAM_ID_CH3_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => PARAM_ID_CH4_2_EN                       ,--: in  std_logic;
        PARAM_ID4                   => PARAM_ID_CH4_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => PARAM_ID_CH5_2_EN                       ,--: in  std_logic;
        PARAM_ID5                   => PARAM_ID_CH5_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => PARAM_ID_CH6_2_EN                       ,--: in  std_logic;
        PARAM_ID6                   => PARAM_ID_CH6_2                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => PARAM_ID_CH7_2_EN                       ,--: in  std_logic;
        PARAM_ID7                   => PARAM_ID_CH7_2                          ,--: in  std_logic_vector(15 downto 0);

        CNT_C_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         => open                                    ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => mac_out_valid(1 downto 0)               ,--: in  std_logic_vector(1 downto 0);
        IN_LAST                     => mac_out_last                            ,--: in  std_logic;
        IN_KEEP                     => mac_out_keep                            ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => mac_out_data                            ,--: in  std_logic_vector(63 downto 0);

        OUT_FULL                    => OUT_FULL                                ,--: in  std_logic;

        OUT_VALID                   => buf_valid(2)                            ,--: out std_logic;
        OUT_LAST                    => buf_last(2)                             ,--: out std_logic;
        OUT_DEST                    => buf_dest(2)                             ,--: out std_logic;
        OUT_KEEP                    => buf_keep(2)                             ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => buf_data(2)                             ,--: out std_logic_vector(63 downto 0);
        OUT_STAMP                   => buf_stamp(2)                            ,--: out std_logic;
        OUT_CH                      => buf_ch(2)                               ,--: out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  => buf_ch_bit(2)                            --: out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION => open
    );

    u_FILTER3 : ORAN_FILTER_CORE
    generic map(
        DIRECTION                   => "UL"                                    ,--: string := "DL";
        MAX_ID                      => MAX_CH                                  ,--: natural := 8;
        USAGE_ID                    => (others => '1')                          --: std_logic_vector(3 downto 0) := "11111111"
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        PARAM_ID0_EN                => PARAM_ID_CH0_3_EN                       ,--: in  std_logic;
        PARAM_ID0                   => PARAM_ID_CH0_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => PARAM_ID_CH1_3_EN                       ,--: in  std_logic;
        PARAM_ID1                   => PARAM_ID_CH1_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => PARAM_ID_CH2_3_EN                       ,--: in  std_logic;
        PARAM_ID2                   => PARAM_ID_CH2_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => PARAM_ID_CH3_3_EN                       ,--: in  std_logic;
        PARAM_ID3                   => PARAM_ID_CH3_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => PARAM_ID_CH4_3_EN                       ,--: in  std_logic;
        PARAM_ID4                   => PARAM_ID_CH4_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => PARAM_ID_CH5_3_EN                       ,--: in  std_logic;
        PARAM_ID5                   => PARAM_ID_CH5_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => PARAM_ID_CH6_3_EN                       ,--: in  std_logic;
        PARAM_ID6                   => PARAM_ID_CH6_3                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => PARAM_ID_CH7_3_EN                       ,--: in  std_logic;
        PARAM_ID7                   => PARAM_ID_CH7_3                          ,--: in  std_logic_vector(15 downto 0);

        CNT_C_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         => open                                    ,--: out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         => open                                    ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => mac_out_valid(1 downto 0)               ,--: in  std_logic_vector(1 downto 0);
        IN_LAST                     => mac_out_last                            ,--: in  std_logic;
        IN_KEEP                     => mac_out_keep                            ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => mac_out_data                            ,--: in  std_logic_vector(63 downto 0);

        OUT_FULL                    => OUT_FULL                                ,--: in  std_logic;

        OUT_VALID                   => buf_valid(3)                            ,--: out std_logic;
        OUT_LAST                    => buf_last(3)                             ,--: out std_logic;
        OUT_DEST                    => buf_dest(3)                             ,--: out std_logic;
        OUT_KEEP                    => buf_keep(3)                             ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => buf_data(3)                             ,--: out std_logic_vector(63 downto 0);
        OUT_STAMP                   => buf_stamp(3)                            ,--: out std_logic;
        OUT_CH                      => buf_ch(3)                               ,--: out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  => buf_ch_bit(3)                            --: out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION => open
    );

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            filtered_valid   <=  buf_valid(0) or  buf_valid(1) or  buf_valid(2) or  buf_valid(3);
            filtered_last    <=  buf_last(0) or   buf_last(1) or   buf_last(2) or   buf_last(3);
            filtered_dest    <=  buf_dest(0) or   buf_dest(1) or   buf_dest(2) or   buf_dest(3);
            filtered_keep    <=  buf_keep(0) or   buf_keep(1) or   buf_keep(2) or   buf_keep(3);
            filtered_data    <=  buf_data(0) or   buf_data(1) or   buf_data(2) or   buf_data(3);
            filtered_stamp   <=  buf_stamp(0) or  buf_stamp(1) or  buf_stamp(2) or  buf_stamp(3);
            filtered_ch      <=  buf_ch(0) or     buf_ch(1) or     buf_ch(2) or     buf_ch(3);
            filtered_ch_sub  <=  buf_valid(3) &   buf_valid(2) &   buf_valid(1) &   buf_valid(0);
        end if;
    end process;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then            
            corrupt_dl_cu_filtered_last    <=  buf_last(0) or   buf_last(1);
            corrupt_dl_cu_filtered_keep    <=  buf_keep(0) or   buf_keep(1);
            corrupt_dl_cu_filtered_data    <=  buf_data(0) or   buf_data(1);
            corrupt_dl_cu_filtered_stamp   <=  buf_stamp(0) or  buf_stamp(1);
        end if;
    end process;
        
    u_CU_PLANE_CONV : FROM_64_TO_32
    port map(
        ARESET                      => RST                                     ,--: in  std_logic;

        IN_CLK                      => CLK                                     ,--: in  std_logic;

        IN_READY                    => open                                    ,--defram_c_ready                          ,--: out std_logic;
        IN_VALID                    => corrupt_dl_cu_filtered_stamp                          ,--defram_c_valid                          ,--: in  std_logic;
        IN_LAST                     => corrupt_dl_cu_filtered_last                           ,--defram_c_last                           ,--: in  std_logic;
        IN_KEEP                     => corrupt_dl_cu_filtered_keep                           ,--defram_c_keep                           ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => corrupt_dl_cu_filtered_data                           ,--defram_c_data                           ,--: in  std_logic_vector(63 downto 0);
        IN_USER                     => (others => '0')                         ,--defram_c_user(9 downto 3)               ,--: in  std_logic_vector(6 downto 0);

        OUT_CLK                     => CLK_BUS                                 ,--: in  std_logic;

        OUT_READY                   => '1'                                     ,--OUT_C_READY                             ,--: in  std_logic;
        OUT_VALID                   => s_64_to_32_o_tvalid                     ,--OUT_C_VALID                             ,--: out std_logic;
        OUT_LAST                    => s_64_to_32_o_tlast                      ,--OUT_C_LAST                              ,--: out std_logic;
        OUT_KEEP                    => s_64_to_32_o_tkeep                      ,--out_c_keep_rev                          ,--: out std_logic_vector(3 downto 0);
        OUT_DATA                    => s_64_to_32_o_tdata                      ,--out_c_data_rev                          ,--: out std_logic_vector(31 downto 0);
        OUT_USER                    => open                                     --out_c_user                               --: out std_logic_vector(6 downto 0)
    );        
    
    process (CLK_BUS)
    begin
        if (CLK_BUS'event and CLK_BUS = '1') then
            s_64_to_32_o_tvalid_d       <= s_64_to_32_o_tvalid;
            s_64_to_32_o_tlast_d        <= s_64_to_32_o_tlast ;
            s_64_to_32_o_tkeep_swap     <= s_64_to_32_o_tkeep(0) & s_64_to_32_o_tkeep(1) & s_64_to_32_o_tkeep(2) & s_64_to_32_o_tkeep(3);
            s_64_to_32_o_tdata_swap     <= s_64_to_32_o_tdata(7 downto 0) & s_64_to_32_o_tdata(15 downto 8) & s_64_to_32_o_tdata(23 downto 16) & s_64_to_32_o_tdata(31 downto 24);
                        
        end if;    
    end process;

    u_oran_stamping_32x8 : oran_stamping_32x8
    generic map(
        USAGE_TYPE0                 => false                                   , --: boolean := false;
        USAGE_TYPE1                 => true                                    , --: boolean := true;
        USAGE_TYPE3                 => false                                   , --: boolean := true;
        USAGE_TYPE5                 => false                                   , --: boolean := true;
        USAGE_TYPE6                 => false                                   , --: boolean := false;
        USAGE_TYPE7                 => false                                   , --: boolean := false
        MAX_ID                      => MAX_CH                                  , --: natural := 8;
        USAGE_ID                    => (others => '1')                         , --: std_logic_vector(3 downto 0) := "11111111"
        MAX_SECTIONID_PER_PKT       => 98 --5                                         --: natural := 5
    )    
    port map(

        CLK                         => CLK_BUS                                 ,--: in  std_logic;                            -- 245.76-MHz
        RST                         => RST                                     ,--: in  std_logic;                            -- CLK

        PARAM_ID0_EN                => PARAM_ID_CH0_0_EN                       ,--: in  std_logic;
        PARAM_ID0                   => PARAM_ID_CH0_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                => PARAM_ID_CH1_0_EN                       ,--: in  std_logic;
        PARAM_ID1                   => PARAM_ID_CH1_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                => PARAM_ID_CH2_0_EN                       ,--: in  std_logic;
        PARAM_ID2                   => PARAM_ID_CH2_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                => PARAM_ID_CH3_0_EN                       ,--: in  std_logic;
        PARAM_ID3                   => PARAM_ID_CH3_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                => PARAM_ID_CH4_0_EN                       ,--: in  std_logic;
        PARAM_ID4                   => PARAM_ID_CH4_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                => PARAM_ID_CH5_0_EN                       ,--: in  std_logic;
        PARAM_ID5                   => PARAM_ID_CH5_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                => PARAM_ID_CH6_0_EN                       ,--: in  std_logic;
        PARAM_ID6                   => PARAM_ID_CH6_0                          ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                => PARAM_ID_CH7_0_EN                       ,--: in  std_logic;
        PARAM_ID7                   => PARAM_ID_CH7_0                          ,--: in  std_logic_vector(15 downto 0);

        CP32_VALID                  => s_64_to_32_o_tvalid_d                   , --: in  std_logic;
        CP32_LAST                   => s_64_to_32_o_tlast_d                    , --: in  std_logic;
        CP32_DATA                   => s_64_to_32_o_tdata_swap                 , --: in  std_logic_vector(31 downto 0);
        CP32_DATA_MAP               => (others => '0')                         , --: in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             => (others => '0')                         , --: in  std_logic_vector(2 downto 0);
	
        SCS_CONFIG                  => SCS_CONFIG                              , --: in  std_logic_vector(3 downto 0);

        PACKET_IS_CP_DL             => rx_packet_is_cp_dl                      , --: out std_logic;
        PACKET_IS_UP_DL             => rx_packet_is_up_dl                      , --: out std_logic;
        PACKET_SCS                  => rx_packet_scs                           , --: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => rx_packet_frame_id                      , --: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => rx_packet_subframe_id                   , --: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => rx_packet_slot_id                       , --: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => rx_packet_symbol_id                     , --: out std_logic_vector(5 downto 0)
        OUT_CH                      => buf_ch_32x8                             , --; out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  => buf_ch_bit_32x8                         , --; out std_logic_vector(7 downto 0)
        PACKET_SECTION_ID           => pkt_section_ids                           --: out std_logic_array12(MAX_SECTIONID_PER_PKT-1 downto 0);

    );
    
    u_sectionId_validation_by_eaxcid: for i in 3 downto 0 generate
    
    process (CLK_BUS)
    begin
        if (CLK_BUS'event and CLK_BUS = '1') then
            if (buf_ch_32x8 = i) then
                pkt_msr_valid_by_eaxcid(i) <= '1';
            else
                pkt_msr_valid_by_eaxcid(i) <= '0';
            end if;
        end if;
    end process;  
    
    
    -- ontime pkt C-U validation
    u_MEASUREMENT_SHORT : MEASUREMENT_SHORT
    generic map(
        NUM_TX                      => 2                                        ,--: natural := 1
        MAX_SECTIONID_PER_PKT       => 98 --5
    )
    port map(
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        CLK_245p76MHz               => CLK_BUS                                 ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET                             ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => REF_10msec                              ,--: in  std_logic;
        REF_SFN                     => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => T2A_MAX_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            => T2A_MIN_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            => T2A_MAX_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            => T2A_MIN_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        
        RX_PACKET_CLK               => CLK_BUS                                  , --CLK_MAC_RX                              ,--: in  std_logic;
        RX_VLD_IN                   => pkt_msr_valid_by_eaxcid(i)               ,--: in std_logic;
        RX_PACKET_IS_CP_DL          => rx_packet_is_cp_dl                       ,--: in  std_logic;
        RX_PACKET_IS_UP_DL          => rx_packet_is_up_dl                       ,--: in  std_logic;
        RX_PACKET_SCS               => rx_packet_scs                            ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_FRAME_ID          => rx_packet_frame_id                       ,--: in  std_logic_vector(7 downto 0);
        RX_PACKET_SUBFRAME_ID       => rx_packet_subframe_id                    ,--: in  std_logic_vector(3 downto 0);
        RX_PACKET_SLOT_ID           => rx_packet_slot_id                        ,--: in  std_logic_vector(5 downto 0);
        RX_PACKET_SYMBOL_ID         => rx_packet_symbol_id                      , --: in  std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           => pkt_section_ids                          ,
        
        DL_CP_DETECT_ON_TIME        => dl_cp_det_on_time(i), 
        DL_CP_DETECT_EARLY          => open, 
        DL_CP_DETECT_LATE           => open, 
        DL_CP_DETECT_OOR            => open, 
                                    
        DL_UP_DETECT_ON_TIME        => dl_up_det_on_time(i), 
        DL_UP_DETECT_EARLY          => open, 
        DL_UP_DETECT_LATE           => open, 
        DL_UP_DETECT_OOR            => open 
    );

    -- section id validate instances for ontine pkt C-U
    u_sectionid_check: sectionid_coupling_validation
    generic map (
        MAX_SECTIONID_PER_PKT       => 98 ,--5,
        MU                          => 1
    )
    port map (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   =>  CLK_CPUIF,
        RST_CPUIF                   =>  RST_CPUIF,
                                    
        CLK                         =>  CLK_BUS,                           
                                     
---------------------------------------------------------------------------
-- Packet stamp for RX              
---------------------------------------------------------------------------        
        RX_PACKET_FRAME_ID          =>  rx_packet_frame_id    ,
        RX_PACKET_SUBFRAME_ID       =>  rx_packet_subframe_id ,
        RX_PACKET_SLOT_ID           =>  rx_packet_slot_id     ,
        RX_PACKET_SYMBOL_ID         =>  rx_packet_symbol_id   ,
        PACKET_SECTION_ID           =>  pkt_section_ids       ,
                                     
        DL_CP_DETECT_ON_TIME        =>  dl_cp_det_on_time(i),          
        DL_UP_DETECT_ON_TIME        =>  dl_up_det_on_time(i),
        RX_CORRUPT_SECTIONID        =>  s_rx_corrupt_sectionid(i)            
    );
       
    end generate;

    -- 
    process (CLK_BUS)
    begin
        if (CLK_BUS'event and CLK_BUS = '1') then
            RX_CORRUPT_SECTIONID   <= s_rx_corrupt_sectionid(0) or s_rx_corrupt_sectionid(1) or s_rx_corrupt_sectionid(2) or s_rx_corrupt_sectionid(3);                     
        end if;    
    end process;

    u_TIMESTAMP : ORAN_STAMPING
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        SCS_CONFIG                  => SCS_CONFIG                              ,--: in  std_logic_vector(3 downto 0);

        IN_VALID                    => filtered_stamp                          ,--: in  std_logic;
        IN_LAST                     => filtered_last                           ,--: in  std_logic;
        IN_KEEP                     => filtered_keep                           ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => filtered_data                           ,--: in  std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             => PACKET_IS_CP_DL                         ,--: out std_logic;
        PACKET_IS_CP_UL             => PACKET_IS_CP_UL                         ,--: out std_logic;
        PACKET_IS_UP_DL             => PACKET_IS_UP_DL                         ,--: out std_logic;
        PACKET_IS_UP_UL             => PACKET_IS_UP_UL                         ,--: out std_logic;
        PACKET_SCS                  => PACKET_SCS                              ,--: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => PACKET_FRAME_ID                         ,--: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => PACKET_SUBFRAME_ID                      ,--: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => PACKET_SLOT_ID                          ,--: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => PACKET_SYMBOL_ID                         --: out std_logic_vector(5 downto 0)
    );

--------------------------------------------------------------------------------
-- Data bus (Bypass)
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            BYPASS_OUT_VALID <= IN_VALID;
            BYPASS_OUT_LAST  <= IN_LAST;
            BYPASS_OUT_KEEP  <= IN_KEEP;
            BYPASS_OUT_DATA  <= IN_DATA;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    C_PLANE_EXIST <= c_plane_exist_buf;
    U_PLANE_EXIST <= u_plane_exist_buf;

    u_PACKET_EXIST : for i in 3 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (buf_valid(i) = '1') and (buf_last(i) = '1') then
            if (buf_valid(i) = '1') then
                if (buf_dest(i) = '0') then
                    c_plane_exist_buf(i+0)  <= buf_ch_bit(i)(0);
                    c_plane_exist_buf(i+4)  <= buf_ch_bit(i)(1);
                    c_plane_exist_buf(i+8)  <= buf_ch_bit(i)(2);
                    c_plane_exist_buf(i+12) <= buf_ch_bit(i)(3);
                    c_plane_exist_buf(i+16) <= buf_ch_bit(i)(4);
                    c_plane_exist_buf(i+20) <= buf_ch_bit(i)(5);
                    c_plane_exist_buf(i+24) <= buf_ch_bit(i)(6);
                    c_plane_exist_buf(i+28) <= buf_ch_bit(i)(7);
                    u_plane_exist_buf(i+0)  <= '0';
                    u_plane_exist_buf(i+4)  <= '0';
                    u_plane_exist_buf(i+8)  <= '0';
                    u_plane_exist_buf(i+12) <= '0';
                    u_plane_exist_buf(i+16) <= '0';
                    u_plane_exist_buf(i+20) <= '0';
                    u_plane_exist_buf(i+24) <= '0';
                    u_plane_exist_buf(i+28) <= '0';
                else
                    c_plane_exist_buf(i+0)  <= '0';
                    c_plane_exist_buf(i+4)  <= '0';
                    c_plane_exist_buf(i+8)  <= '0';
                    c_plane_exist_buf(i+12) <= '0';
                    c_plane_exist_buf(i+16) <= '0';
                    c_plane_exist_buf(i+20) <= '0';
                    c_plane_exist_buf(i+24) <= '0';
                    c_plane_exist_buf(i+28) <= '0';
                    u_plane_exist_buf(i+0)  <= buf_ch_bit(i)(0);
                    u_plane_exist_buf(i+4)  <= buf_ch_bit(i)(1);
                    u_plane_exist_buf(i+8)  <= buf_ch_bit(i)(2);
                    u_plane_exist_buf(i+12) <= buf_ch_bit(i)(3);
                    u_plane_exist_buf(i+16) <= buf_ch_bit(i)(4);
                    u_plane_exist_buf(i+20) <= buf_ch_bit(i)(5);
                    u_plane_exist_buf(i+24) <= buf_ch_bit(i)(6);
                    u_plane_exist_buf(i+28) <= buf_ch_bit(i)(7);
                end if;
            else
                c_plane_exist_buf(i+0)  <= '0';
                c_plane_exist_buf(i+4)  <= '0';
                c_plane_exist_buf(i+8)  <= '0';
                c_plane_exist_buf(i+12) <= '0';
                c_plane_exist_buf(i+16) <= '0';
                c_plane_exist_buf(i+20) <= '0';
                c_plane_exist_buf(i+24) <= '0';
                c_plane_exist_buf(i+28) <= '0';
                u_plane_exist_buf(i+0)  <= '0';
                u_plane_exist_buf(i+4)  <= '0';
                u_plane_exist_buf(i+8)  <= '0';
                u_plane_exist_buf(i+12) <= '0';
                u_plane_exist_buf(i+16) <= '0';
                u_plane_exist_buf(i+20) <= '0';
                u_plane_exist_buf(i+24) <= '0';
                u_plane_exist_buf(i+28) <= '0';
            end if;
        end if;
    end process;
    end generate;

    CNT_C_PLANE <= x"0000" & rx_c_plane_cnt;
    CNT_U_PLANE <= x"0000" & rx_u_plane_cnt;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (filtered_last = '1') and (filtered_dest = '0') then
                rx_c_plane_cnt <= rx_c_plane_cnt + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (filtered_last = '1') and (filtered_dest = '1') then
                rx_u_plane_cnt <= rx_u_plane_cnt + 1;
            end if;
        end if;
    end process;

end BEHAVE;