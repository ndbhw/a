--------------------------------------------------------------------------------
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2022.02.16
--------------------------------------------------------------------------------
-- Function description
--   1. MAC interconnect component
--   2. Perform packet filtering
--   3. Condition : Destination MAC address, EtherType
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2022.02.16) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity MAC_FILTER is
    generic (
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 156.25/390.625-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_MAC                   : in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_INVALID_DST_MAC         : out std_logic_vector(31 downto 0);        -- CLK
        CNT_INVALID_ETHERTYPE       : out std_logic_vector(31 downto 0);        -- CLK

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);

        OUT_VLAN_MODE               : out std_logic_vector(1 downto 0)
    );
end MAC_FILTER;

architecture BEHAVE of MAC_FILTER is

    type std_logic_array8           is array(natural range <>) of std_logic_vector(7 downto 0);
    type std_logic_array64          is array(natural range <>) of std_logic_vector(63 downto 0);

    signal valid_in_reg             : std_logic_vector(4 downto 0) := (others => '0');
    signal last_in_reg              : std_logic_vector(4 downto 0) := (others => '0');
    signal keep_in_reg              : std_logic_array8(4 downto 0) := (others => (others => '0'));
    signal data_in_reg              : std_logic_array64(4 downto 0) := (others => (others => '0'));

    signal cnt                      : std_logic_vector(2 downto 0) := (others => '0');

    signal matched_mac              : std_logic := '0';
    signal matched_vlan             : std_logic_vector(2 downto 0) := "000";
    signal matched_type             : std_logic_vector(2 downto 0) := (others => '0');
    signal vlan_detected            : std_logic_vector(1 downto 0) := (others => '0');

    signal condition                : std_logic_vector(2 downto 0) := (others => '0');

    signal mac                      : std_logic_vector(47 downto 0);
    signal vlan_tpid0               : std_logic_vector(15 downto 0);
    signal vlan_tpid1               : std_logic_vector(15 downto 0);
    signal ethertype0               : std_logic_vector(15 downto 0);
    signal ethertype1               : std_logic_vector(15 downto 0);
    signal output_enable            : std_logic := '0';

    signal invalid_dst_mac_cnt      : std_logic_vector(15 downto 0) := (others => '0');
    signal invalid_ethertype_cnt    : std_logic_vector(15 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Parameters
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') then
                if (IN_LAST = '1') then
                    cnt <= (others => '0');
                else
                    if (cnt = 7) then
                        cnt <= cnt;
                    else
                        cnt <= cnt + 1;
                    end if;
                end if;
--            else
--                cnt <= (others => '0');
            end if;
        end if;
    end process;

    mac                <= IN_DATA(7 downto 0) & IN_DATA(15 downto 8) & IN_DATA(23 downto 16) & IN_DATA(31 downto 24) & IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    vlan_tpid0         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    vlan_tpid1         <= IN_DATA(7 downto 0) & IN_DATA(15 downto 8);
    ethertype0         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    ethertype1         <= IN_DATA(7 downto 0) & IN_DATA(15 downto 8);

--------------------------------------------------------------------------------
-- Destination MAC (Ethernet layer)
--------------------------------------------------------------------------------

    u_MAC_FILTER_USED : if FILTER_MAC = true generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                matched_mac <= '0';
            else
                if (cnt = 0) then
                    if (mac = PARAM_MAC) then
                        matched_mac <= '1';
                    else
                        matched_mac <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
    end generate;

    u_MAC_FILTER_UNUSED : if FILTER_MAC = false generate
    matched_mac <= '1';
    end generate;

--------------------------------------------------------------------------------
-- VLAN/EtherType (Ethernet layer)
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                matched_vlan(0) <= '0';
            else
                if (cnt = 1) then
                    if (vlan_tpid0 = PARAM_ETHERTYPE) then
                        matched_vlan(0) <= matched_mac;
                    else
                        matched_vlan(0) <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                matched_vlan(1) <= '0';
                matched_vlan(2) <= '0';
            else
                if (cnt = 1) then
                    if (vlan_tpid0 = x"88A8") or (vlan_tpid0 = x"8100") then
                        matched_vlan(1) <= matched_mac;
                        matched_vlan(2) <= '0';
                    else
                        matched_vlan(1) <= '0';
                        matched_vlan(2) <= '0';
                    end if;
                end if;
                if (cnt = 2) then
                    if (vlan_tpid1 = x"8100") then
                        if (matched_vlan(1) = '1') then
                            matched_vlan(1) <= '0';
                            matched_vlan(2) <= matched_mac;
                        else
                            matched_vlan(1) <= '0';
                            matched_vlan(2) <= '0';
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end process;

    u_TYPE_FILTER_USED : if FILTER_ETHERTYPE = true generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                matched_type <= (others => '0');
            else
                if (cnt = 1) then                                               -- No VLAN tag
                    if (ethertype0 = PARAM_ETHERTYPE) then
                        matched_type(0) <= '1';
                    else
                        matched_type(0) <= '0';
                    end if;
                end if;
                if (cnt = 2) then                                               -- Single-tagged
                    if (ethertype1 = PARAM_ETHERTYPE) then
                        matched_type(1) <= '1';
                    else
                        matched_type(1) <= '0';
                    end if;
                end if;
                if (cnt = 2) then                                               -- Double-tagged
                    if (ethertype0 = PARAM_ETHERTYPE) then
                        matched_type(2) <= '1';
                    else
                        matched_type(2) <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
    end generate;

    u_TYPE_FILTER_UNUSED : if FILTER_ETHERTYPE = false generate
    matched_type <= (others => '1');
    end generate;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            condition <= matched_vlan and matched_type;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Output control
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            valid_in_reg <= valid_in_reg(3 downto 0) & IN_VALID;
            last_in_reg  <= last_in_reg(3 downto 0) & IN_LAST;
            keep_in_reg  <= keep_in_reg(3 downto 0) & IN_KEEP;
            data_in_reg  <= data_in_reg(3 downto 0) & IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = 4) then
                if (condition(0) = '1') then
                    output_enable <= '1';
                elsif (condition(1) = '1') then
                    output_enable <= '1';
                elsif (condition(2) = '1') then
                    output_enable <= '1';
                else
                    output_enable <= '0';
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = 4) then
                vlan_detected <= condition(2 downto 1);
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (output_enable = '1') and (valid_in_reg(4) = '1') then
                OUT_VALID     <= '1';
                OUT_LAST      <= last_in_reg(4);
                OUT_KEEP      <= keep_in_reg(4);
                OUT_DATA      <= data_in_reg(4);
                OUT_VLAN_MODE <= vlan_detected;
            else
                OUT_VALID     <= '0';
                OUT_LAST      <= '0';
                OUT_KEEP      <= (others => '0');
                OUT_DATA      <= (others => '0');
                OUT_VLAN_MODE <= (others => '0');
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    CNT_INVALID_DST_MAC      <= x"0000" & invalid_dst_mac_cnt;
    CNT_INVALID_ETHERTYPE    <= x"0000" & invalid_ethertype_cnt;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                if (matched_mac = '0') then
                    invalid_dst_mac_cnt <= invalid_dst_mac_cnt + 1;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID = '1') and (IN_LAST = '1') then
                if ((matched_vlan and matched_type) = "000") then
                    invalid_ethertype_cnt <= invalid_ethertype_cnt + 1;
                end if;
            end if;
        end if;
    end process;

end BEHAVE;