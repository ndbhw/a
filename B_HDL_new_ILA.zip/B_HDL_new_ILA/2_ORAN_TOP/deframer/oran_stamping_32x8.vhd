--------------------------------------------------------------------------------
--
-- Copyright (C) 2024, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com) / nhu.dong
-- Date     : 2024.03.11
--------------------------------------------------------------------------------
-- Function description
--   -. ORAN C-Plane processing (without sectionType 6)
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2024.03.11) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.all;

use WORK.ARRAY_TYPE.ALL;

entity oran_stamping_32x8 is
    generic (
        USAGE_TYPE0                 : boolean := false;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := false;
        USAGE_TYPE7                 : boolean := false;
        MAX_ID                      : natural := 8;
        USAGE_ID                    : std_logic_vector(7 downto 0) := "11111111";
        MAX_SECTIONID_PER_PKT       : natural := 5
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 245.76-MHz
        RST                         : in  std_logic;                            -- CLK

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_ID0_EN                : in  std_logic;
        PARAM_ID0                   : in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                : in  std_logic;
        PARAM_ID1                   : in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                : in  std_logic;
        PARAM_ID2                   : in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                : in  std_logic;
        PARAM_ID3                   : in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                : in  std_logic;
        PARAM_ID4                   : in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                : in  std_logic;
        PARAM_ID5                   : in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                : in  std_logic;
        PARAM_ID6                   : in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                : in  std_logic;
        PARAM_ID7                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- C-U-Plane
--------------------------------------------------------------------------------

        CP32_VALID                  : in  std_logic;
        CP32_LAST                   : in  std_logic;
        CP32_DATA                   : in  std_logic_vector(31 downto 0);
        CP32_DATA_MAP               : in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             : in  std_logic_vector(2 downto 0);
		
--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        PACKET_SECTION_ID           : out std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0);

        
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  : out std_logic_vector(7 downto 0)
		
    );
end oran_stamping_32x8;

architecture BEHAVE of oran_stamping_32x8 is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal srst                     : std_logic;

    signal buf_valid                : std_logic := '0';
    signal buf_last                 : std_logic := '0';
    signal buf_data                 : std_logic_vector(31 downto 0) := (others => '0');
    signal buf_data_map             : std_logic_vector(3 downto 0) := (others => '0');
    signal buf_link_index           : std_logic_vector(2 downto 0) := (others => '0');

    type fsm_c_plane                is (HDR0, HDR1, DEC0, DEC1, DEC2, SEC0, SEC1, SEC2, EXT0, EXT1, DUMMY);
    signal fsm_dec                  : fsm_c_plane;
    signal cnt_dec_state            : std_logic_vector(7 downto 0) := (others => '0');
    signal cnt_sec                  : std_logic_vector(7 downto 0) := (others => '0');
    
    signal field_data_direction     : std_logic := '0';
    signal field_frame_id           : std_logic_vector(7 downto 0) := (others => '0');
    signal field_subframe_id        : std_logic_vector(3 downto 0) := (others => '0');
    signal field_slot_id            : std_logic_vector(5 downto 0) := (others => '0');
    signal field_symbol_id          : std_logic_vector(5 downto 0) := (others => '0');
    signal field_num_section        : std_logic_vector(7 downto 0) := (others => '0');
    signal field_section_type       : std_logic_vector(7 downto 0) := (others => '0');
    signal field_section_id         : std_logic_vector(11 downto 0) := (others => '0');
    signal field_num_prb            : std_logic_vector(7 downto 0) := (others => '0');
    signal field_ef                 : std_logic := '0';
    signal field_ext_ef             : std_logic := '0';
    signal field_ext_len            : std_logic_vector(7 downto 0) := (others => '0');
    signal field_ext_type           : std_logic_vector(6 downto 0) := (others => '0');

    signal en                       : std_logic;
    signal c_plane                  : std_logic;
    signal u_plane                  : std_logic;
    signal dl_direction             : std_logic;
    signal ul_direction             : std_logic;
    signal frame_id                 : std_logic_vector(7 downto 0) := (others => '0');
    signal subframe_id              : std_logic_vector(3 downto 0) := (others => '0');
    signal slot_id                  : std_logic_vector(5 downto 0) := (others => '0');
    signal symbol_id                : std_logic_vector(5 downto 0) := (others => '0');
    signal section_type             : std_logic_vector(7 downto 0) := (others => '0');
    signal scs                      : std_logic_vector(3 downto 0) := (others => '0');

    signal matched_id               : std_logic_vector(7 downto 0) := (others => '0');
    signal sub_channel_bit          : std_logic_vector(7 downto 0) := (others => '0');
    signal sub_channel_value        : std_logic_vector(2 downto 0) := (others => '0');
    signal eaxc_id                  : std_logic_array16(7 downto 0);
    signal param_id                 : std_logic_array16(7 downto 0);
    signal param_id_enable          : std_logic_vector(7 downto 0);
--    signal cnt                      : std_logic_vector(2 downto 0) := (others => '0');

    signal pkt_is_cp_dl             : std_logic;
    signal pkt_is_up_dl             : std_logic;
    
    signal pkt_is_cp_dl_d           : std_logic;
    signal pkt_is_up_dl_d           : std_logic;
    
    signal pkt_is_cp_dl_fpl         : std_logic;
    signal pkt_is_up_dl_fpl         : std_logic;
    signal packet_sectionids        : std_logic_array13(MAX_SECTIONID_PER_PKT-1 downto 0) := (others => ("1000000000000"));

    
begin

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            if (CP32_VALID /= '0') then
--                if (CP32_LAST = '1') then
--                    cnt <= (others => '0');
--                else
--                    if (cnt = 7) then
--                        cnt <= cnt;
--                    else
--                        cnt <= cnt + 1;
--                    end if;
--                end if;
----            else
----                cnt <= (others => '0');
--            end if;
--        end if;
--    end process;

    param_id(0)        <= PARAM_ID0;
    param_id(1)        <= PARAM_ID1;
    param_id(2)        <= PARAM_ID2;
    param_id(3)        <= PARAM_ID3;
    param_id(4)        <= PARAM_ID4;
    param_id(5)        <= PARAM_ID5;
    param_id(6)        <= PARAM_ID6;
    param_id(7)        <= PARAM_ID7;

    param_id_enable(0) <= PARAM_ID0_EN and USAGE_ID(0);
    param_id_enable(1) <= PARAM_ID1_EN and USAGE_ID(1);
    param_id_enable(2) <= PARAM_ID2_EN and USAGE_ID(2);
    param_id_enable(3) <= PARAM_ID3_EN and USAGE_ID(3);
    param_id_enable(4) <= PARAM_ID4_EN and USAGE_ID(4);
    param_id_enable(5) <= PARAM_ID5_EN and USAGE_ID(5);
    param_id_enable(6) <= PARAM_ID6_EN and USAGE_ID(6);
    param_id_enable(7) <= PARAM_ID7_EN and USAGE_ID(7);
    
    u_PORT : for i in MAX_ID-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (CP32_VALID /= '0') and (CP32_LAST = '1') then
                matched_id(i) <= '0';
            else
                if (fsm_dec = DEC0) then
                    if (eaxc_id(i) = param_id(i)) then
                        matched_id(i) <= param_id_enable(i);
                    else
                        matched_id(i) <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
    end generate;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (fsm_dec = DEC1) then
                sub_channel_bit <= matched_id;
            end if;
        end if;
    end process;

    process (sub_channel_bit)
    begin
        case sub_channel_bit is
        when "00000010" => sub_channel_value <= "001";
        when "00000100" => sub_channel_value <= "010";
        when "00001000" => sub_channel_value <= "011";
        when "00010000" => sub_channel_value <= "100";
        when "00100000" => sub_channel_value <= "101";
        when "01000000" => sub_channel_value <= "110";
        when "10000000" => sub_channel_value <= "111";
        when others     => sub_channel_value <= "000";
        end case;
    end process;

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => srst                                     --: out std_logic
    );

--------------------------------------------------------------------------------
-- FSM for C-Plane and U-plane decoding
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            buf_valid      <= CP32_VALID;
            buf_last       <= CP32_LAST;
            buf_data       <= CP32_DATA;
            buf_data_map   <= CP32_DATA_MAP;
            buf_link_index <= CP32_LINK_INDEX;
        end if;
    end process;
    
    pkt_is_cp_dl_fpl <= pkt_is_cp_dl_d and not pkt_is_cp_dl;
    pkt_is_up_dl_fpl <= pkt_is_up_dl_d and not pkt_is_up_dl;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then            
            pkt_is_cp_dl <= en and dl_direction and c_plane;
            pkt_is_up_dl <= en and dl_direction and u_plane;
            
            pkt_is_cp_dl_d <= pkt_is_cp_dl;
            pkt_is_up_dl_d <= pkt_is_up_dl;
            
            PACKET_IS_CP_DL <= pkt_is_cp_dl_fpl; --pkt_is_cp_dl; --en and dl_direction and c_plane;
            PACKET_IS_UP_DL <= pkt_is_up_dl_fpl; --pkt_is_up_dl; --en and dl_direction and u_plane;
        end if;
    end process;

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
            PACKET_SCS         <= scs;
            PACKET_FRAME_ID    <= frame_id;
            PACKET_SUBFRAME_ID <= subframe_id;
--            PACKET_SLOT_ID     <= slot_id;
--            PACKET_SYMBOL_ID   <= symbol_id;
            PACKET_SLOT_ID     <= "00" & slot_id(3 downto 0);
            PACKET_SYMBOL_ID   <= "00" & symbol_id(3 downto 0);
            
--        end if;
--    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            OUT_CH          <= sub_channel_value;
            OUT_CH_BIT      <= sub_channel_bit;            
        end if;
    end process;

    -- FSM
    process (srst, CLK)
    begin
        if (srst = '1') then
            fsm_dec <= HDR0;
        elsif (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR0   =>
                if (buf_valid = '1') then
                    fsm_dec <= HDR1;
                else
                    fsm_dec <= HDR0;
                end if;
            when HDR1   =>
                fsm_dec <= DEC0;
            when DEC0   =>
                fsm_dec <= DEC1;
            when DEC1   =>
                if    (USAGE_TYPE0 = true) and (buf_data(23 downto 16) = 0) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE1 = true) and (buf_data(23 downto 16) = 1) then
                    fsm_dec <= SEC0;
                elsif (USAGE_TYPE3 = true) and (buf_data(23 downto 16) = 3) then
                    fsm_dec <= DEC2;
                elsif (USAGE_TYPE5 = true) and (buf_data(23 downto 16) = 5) then
                    fsm_dec <= SEC0;
                elsif (USAGE_TYPE6 = true) and (buf_data(23 downto 16) = 6) then
                    fsm_dec <= DUMMY;
                elsif (USAGE_TYPE7 = true) and (buf_data(23 downto 16) = 7) then
                    fsm_dec <= DUMMY;
                else
                    fsm_dec <= DUMMY;
                end if;
            when DEC2   =>
                fsm_dec <= SEC0;
            when SEC0   =>
                fsm_dec <= SEC1;
            when SEC1   =>
                if (c_plane = '1') then -- C plane continue checking section id of sections if any
                    if    (USAGE_TYPE1 = true) and (field_section_type = 1) then
                        if (buf_data(15) = '1') then
                            fsm_dec <= EXT0;
                        else
                            if (cnt_sec = field_num_section) then
                                if (buf_last = '1') then
                                    fsm_dec <= HDR0;
                                else
                                    fsm_dec <= DUMMY;
                                end if;
                            else
                                fsm_dec <= SEC0;
                            end if;
                        end if;
                    elsif (USAGE_TYPE3 = true) and (field_section_type = 3) then
                        fsm_dec <= SEC2;
                    elsif (USAGE_TYPE5 = true) and (field_section_type = 5) then
                        if (buf_data(15) = '1') then
                            fsm_dec <= EXT0;
                        else
                            if (cnt_sec = field_num_section) then
                                if (buf_last = '1') then
                                    fsm_dec <= HDR0;
                                else
                                    fsm_dec <= DUMMY;
                                end if;
                            else
                                fsm_dec <= SEC0;
                            end if;
                        end if;
                    else
                        fsm_dec <= DUMMY;
                    end if;
                else      -- Uplane end checking after got section id
                    fsm_dec <= DUMMY;
                end if;
            when SEC2   =>
                if (field_ef = '1') then
                    fsm_dec <= EXT0;
                else
                    if (cnt_sec = field_num_section) then
                        if (buf_last = '1') then
                            fsm_dec <= HDR0;
                        else
                            fsm_dec <= DUMMY;
                        end if;
                    else
                        fsm_dec <= SEC0;
                    end if;
                end if;
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    if (buf_data(31) = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    if (field_ext_ef = '1') then
                        fsm_dec <= EXT0;
                    else
                        if (cnt_sec = field_num_section) then
                            if (buf_last = '1') then
                                fsm_dec <= HDR0;
                            else
                                fsm_dec <= DUMMY;
                            end if;
                        else
                            fsm_dec <= SEC0;
                        end if;
                    end if;
                else
                    fsm_dec <= EXT1;
                end if;
            when DUMMY  =>
                if (buf_last = '1') then
                    fsm_dec <= HDR0;
                else
                    fsm_dec <= DUMMY;
                end if;
            when others =>
                fsm_dec <= HDR0;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR0   =>
                if (buf_data(23 downto 16) = x"02") then -- message_type C
                    c_plane <= '1';
                else
                    c_plane <= '0';
                end if;
                if (buf_data(23 downto 16) = x"00") then -- U
                    u_plane <= '1';
                else
                    u_plane <= '0';
                end if;                                
            when others =>
                NULL;
            end case;
        end if;
    end process;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                en <= '1';
            when HDR0   =>
                en <= '0';
            when DUMMY   =>
                en <= '0';
            when others =>
                NULL;
            end case;
        end if;
    end process;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR1   =>
                eaxc_id(0)         <= buf_data(31 downto 16);
                eaxc_id(1)         <= buf_data(31 downto 16);
                eaxc_id(2)         <= buf_data(31 downto 16);
                eaxc_id(3)         <= buf_data(31 downto 16);
                eaxc_id(4)         <= buf_data(31 downto 16);
                eaxc_id(5)         <= buf_data(31 downto 16);
                eaxc_id(6)         <= buf_data(31 downto 16);
                eaxc_id(7)         <= buf_data(31 downto 16);
            when others =>
                eaxc_id(0)         <= (others => '0');
                eaxc_id(1)         <= (others => '0');
                eaxc_id(2)         <= (others => '0');
                eaxc_id(3)         <= (others => '0');
                eaxc_id(4)         <= (others => '0');
                eaxc_id(5)         <= (others => '0');
                eaxc_id(6)         <= (others => '0');
                eaxc_id(7)         <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when EXT0   =>
                if (buf_data(23 downto 16) = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when EXT1   =>
                if (field_ext_len = cnt_dec_state) then
                    cnt_dec_state <= "00000001";
                else
                    cnt_dec_state <= cnt_dec_state + 1;
                end if;
            when others =>
                cnt_dec_state <= "00000001";
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when DEC0   =>
                cnt_sec <= (others => '0');
            when SEC0   =>
                cnt_sec <= cnt_sec + 1;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    -- 1st word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when HDR1   => 
                dl_direction <= '0';
                ul_direction <= '0';
            when DEC0   =>
                dl_direction <= buf_data(31);
                ul_direction <= not (buf_data(31));
                
                frame_id        <= buf_data(23 downto 16);
                subframe_id     <= buf_data(15 downto 12);
                slot_id         <= buf_data(11 downto 6);
                symbol_id       <= buf_data(5 downto 0);
                
--                field_data_direction  <= buf_data(31);
--                field_frame_id        <= buf_data(23 downto 16);
--                field_subframe_id     <= buf_data(15 downto 12);
--                field_slot_id         <= buf_data(11 downto 6);
--                field_symbol_id       <= buf_data(5 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;


    -- 2nd word (O-RAN header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is

            when DEC1   =>
                field_num_section     <= buf_data(31 downto 24);
                field_section_type    <= buf_data(23 downto 16);
                
				section_type          <= buf_data(23 downto 16);
            when others =>
                NULL;
            end case;
        end if;
    end process;
    
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            case fsm_dec is
--            when HDR2   =>
--                if (c_plane = '1') and (section_type = x"03") then
--                    if (data_in_reg(3) = '1') then
--                        scs <= (others => '0');
--                    else
--                        scs <= data_in_reg(3 downto 0);
--                    end if;
--                else
                    scs <= SCS_CONFIG; -- correct DL U and DL C  
--                end if;
--            when others =>
--                NULL;
--            end case;
        end if;
    end process;

    -- 1st word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
                if (c_plane = '1') then
                    packet_sectionids   <= packet_sectionids(MAX_SECTIONID_PER_PKT-2 downto 0) & ('0' & buf_data(31 downto 20));
                end if;
                
            when DEC1   =>
                if (u_plane = '1') then
                    field_section_id    <= buf_data(31 downto 20);
                    packet_sectionids   <= packet_sectionids(MAX_SECTIONID_PER_PKT-2 downto 0) & ('0' & buf_data(31 downto 20));
                end if;
                   
            when HDR1   => 
                 packet_sectionids   <= (others => ("1000000000000"));
                 
            when others =>
                NULL;
            end case;
        end if;
    end process;

    PACKET_SECTION_ID <= packet_sectionids;

    -- 2nd word (Section header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is 
            when SEC1   =>
--                field_num_symbol      <= buf_data(19 downto 16);
                field_ef              <= buf_data(15);
--                field_beamid          <= buf_data(14 downto 0);
            when others =>
                NULL;
            end case;
        end if;
    end process;
    
    -- 1st word (Section extension header)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_dec is
            when SEC0   =>
                field_ext_ef          <= '0';
                field_ext_len         <= (others => '0');
            when EXT0   =>
                field_ext_ef          <= buf_data(31);
                field_ext_type        <= buf_data(30 downto 24);
                field_ext_len         <= buf_data(23 downto 16);				
            when others =>
                NULL;
            end case;
        end if;
    end process;
   

end BEHAVE;