--------------------------------------------------------------------------------
--
-- Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Author   : jaekyu.no (jaekyu.no@samsung.com)
-- Date     : 2022.02.16
--------------------------------------------------------------------------------
-- Function description
--   1. O-RAN interconnect component
--   2. Perform packet filtering
--   3. Condition : ecpriRtcid/ecpriPcid, dataDirection
--------------------------------------------------------------------------------
-- Change log
--   Rev 1 (2022.02.16) - initial release
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;

entity ORAN_FILTER_CORE is
    generic (
        DIRECTION                   : string := "DL";                           -- "DL", "UL", "BOTH"
        MAX_ID                      : natural := 8;
        USAGE_ID                    : std_logic_vector(7 downto 0) := "11111111"
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 156.25/390.625-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        PARAM_ID0_EN                : in  std_logic;
        PARAM_ID0                   : in  std_logic_vector(15 downto 0);
        PARAM_ID1_EN                : in  std_logic;
        PARAM_ID1                   : in  std_logic_vector(15 downto 0);
        PARAM_ID2_EN                : in  std_logic;
        PARAM_ID2                   : in  std_logic_vector(15 downto 0);
        PARAM_ID3_EN                : in  std_logic;
        PARAM_ID3                   : in  std_logic_vector(15 downto 0);
        PARAM_ID4_EN                : in  std_logic;
        PARAM_ID4                   : in  std_logic_vector(15 downto 0);
        PARAM_ID5_EN                : in  std_logic;
        PARAM_ID5                   : in  std_logic_vector(15 downto 0);
        PARAM_ID6_EN                : in  std_logic;
        PARAM_ID6                   : in  std_logic_vector(15 downto 0);
        PARAM_ID7_EN                : in  std_logic;
        PARAM_ID7                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_C_PLANE_DROPPED         : out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         : out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_VALID                    : in  std_logic_vector(1 downto 0);
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_FULL                    : in  std_logic;

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_DEST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);
        OUT_STAMP                   : out std_logic;
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_BIT                  : out std_logic_vector(7 downto 0)
        
--        RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION: out std_logic
    );
end ORAN_FILTER_CORE;

architecture BEHAVE of ORAN_FILTER_CORE is

    type std_logic_array4           is array(natural range <>) of std_logic_vector(3 downto 0);
    type std_logic_array16          is array(natural range <>) of std_logic_vector(15 downto 0);
    type std_logic_array64          is array(natural range <>) of std_logic_vector(63 downto 0);

    signal valid_in_reg             : std_logic_vector(4 downto 0) := (others => '0');
    signal last_in_reg              : std_logic_vector(4 downto 0) := (others => '0');
    signal dest_in_reg              : std_logic_vector(4 downto 0) := (others => '0');
--    signal keep_in_reg              : std_logic_array8(4 downto 0) := (others => (others => '0'));
    signal empty_in_reg             : std_logic_array4(4 downto 0) := (others => (others => '0'));
    signal data_in_reg              : std_logic_array64(4 downto 0) := (others => (others => '0'));

    signal cnt                      : std_logic_vector(2 downto 0) := (others => '0');

    signal matched_version          : std_logic := '0';
    signal matched_c                : std_logic := '0';
    signal matched_id               : std_logic_vector(7 downto 0) := (others => '0');
    signal matched_direction        : std_logic := '0';
    signal matched_payload_version  : std_logic := '0';
    signal sub_channel_bit          : std_logic_vector(7 downto 0) := (others => '0');
    signal sub_channel_value        : std_logic_vector(2 downto 0) := (others => '0');

    signal version                  : std_logic_vector(3 downto 0);
    signal c                        : std_logic_vector(0 downto 0);
    signal payload                  : std_logic_vector(15 downto 0);
    signal datadirection            : std_logic_vector(0 downto 0);
    signal payload_version           : std_logic_vector(2 downto 0);
    signal eaxc_id                  : std_logic_array16(7 downto 0);
    signal param_id                 : std_logic_array16(7 downto 0);
    signal param_id_enable          : std_logic_vector(7 downto 0);
    signal length                   : std_logic_vector(15 downto 0) := (others => '1');
    signal packet_is_valid          : std_logic := '0';
    signal packet_is_end            : std_logic := '0';

    signal condition0               : std_logic := '0';
    signal condition1               : std_logic_vector(7 downto 0) := (others => '0');
    signal condition2               : std_logic := '0';
    signal condition3               : std_logic := '0';

    signal output_enable            : std_logic := '0';

    signal keep_to_empty            : std_logic_vector(2 downto 0) := (others => '0');
    signal left_length              : std_logic_vector(15 downto 0) := (others => '0');

    signal check_normality          : std_logic := '0';
    signal inc_normal               : std_logic := '0';
    signal inc_long                 : std_logic := '0';
    signal inc_short                : std_logic := '0';

    signal dropped_cp               : std_logic_vector(15 downto 0) := (others => '0');
    signal dropped_up               : std_logic_vector(15 downto 0) := (others => '0');
    signal length_is_normal         : std_logic_vector(15 downto 0) := (others => '0');
    signal length_is_long           : std_logic_vector(15 downto 0) := (others => '0');
    signal length_is_short          : std_logic_vector(15 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Parameters
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) then
                if (IN_LAST = '1') then
                    cnt <= (others => '0');
                else
                    if (cnt = 7) then
                        cnt <= cnt;
                    else
                        cnt <= cnt + 1;
                    end if;
                end if;
--            else
--                cnt <= (others => '0');
            end if;
        end if;
    end process;

    version            <= IN_DATA(7 downto 4);
    c                  <= IN_DATA(0 downto 0);
    payload            <= IN_DATA(23 downto 16) & IN_DATA(31 downto 24);
    datadirection      <= IN_DATA(7 downto 7);
    payload_version    <= IN_DATA(6 downto 4);

    eaxc_id(0)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(1)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(2)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(3)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(4)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(5)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(6)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);
    eaxc_id(7)         <= IN_DATA(39 downto 32) & IN_DATA(47 downto 40);

    param_id(0)        <= PARAM_ID0;
    param_id(1)        <= PARAM_ID1;
    param_id(2)        <= PARAM_ID2;
    param_id(3)        <= PARAM_ID3;
    param_id(4)        <= PARAM_ID4;
    param_id(5)        <= PARAM_ID5;
    param_id(6)        <= PARAM_ID6;
    param_id(7)        <= PARAM_ID7;

    param_id_enable(0) <= PARAM_ID0_EN and USAGE_ID(0);
    param_id_enable(1) <= PARAM_ID1_EN and USAGE_ID(1);
    param_id_enable(2) <= PARAM_ID2_EN and USAGE_ID(2);
    param_id_enable(3) <= PARAM_ID3_EN and USAGE_ID(3);
    param_id_enable(4) <= PARAM_ID4_EN and USAGE_ID(4);
    param_id_enable(5) <= PARAM_ID5_EN and USAGE_ID(5);
    param_id_enable(6) <= PARAM_ID6_EN and USAGE_ID(6);
    param_id_enable(7) <= PARAM_ID7_EN and USAGE_ID(7);

----------------------------------------------------------------------------------
---- RX_Corrupt: eCPRIversion, payloadversion, pcid
----------------------------------------------------------------------------------

--    process (CLK)
--    begin
--        if (CLK'event and CLK = '1') then
--            if (IN_VALID /= 0) and (IN_LAST = '1') then                
----                RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION <= not (matched_version and (matched_id(0) 
----                                                                                      or matched_id(1) 
----                                                                                      or matched_id(2) 
----                                                                                      or matched_id(3) 
----                                                                                      or matched_id(4) 
----                                                                                      or matched_id(5) 
----                                                                                      or matched_id(6) 
----                                                                                      or matched_id(7)) 
----                                                                                    and matched_payload_version); 
--                RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION <= not (matched_version and matched_payload_version); 
--            else
--                RX_CORRUPT_PCID_eCPRIVERSION_PAYLOADVERSION <= '0';            
--            end if;
--        end if;
--    end process;

--------------------------------------------------------------------------------
-- ecpriVersion, ecpriConcatenate, ecpriRtcid/ecpriPcid (eCPRI layer)
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                matched_version <= '0';
            else
                if (cnt = 0) then
                    if (version = "0001") then
                        matched_version <= '1';
                    else
                        matched_version <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                matched_c <= '0';
            else
                if (cnt = 0) then
                    if (c = "0") then
                        matched_c <= '1';
                    else
                        matched_c <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            condition0 <= matched_version and matched_c;
        end if;
    end process;

    u_PORT : for i in MAX_ID-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                matched_id(i) <= '0';
            else
                if (cnt = 0) then
                    if (eaxc_id(i) = param_id(i)) then
                        matched_id(i) <= param_id_enable(i);
                    else
                        matched_id(i) <= '0';
                    end if;
                end if;
                                
            end if;
        end if;
    end process;
    end generate;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            condition1 <= matched_id;
        end if;
    end process;

--------------------------------------------------------------------------------
-- ecpriPayload (eCPRI layer)
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
--            if (IN_VALID /= 0) and (IN_LAST = '1') then
--                length <= (others => '0');
--            else
                if (IN_VALID /= 0) and (cnt = 0) then
--                    length <= payload + 4;
                    length <= payload + 3;
                else
                    if (valid_in_reg(0) = '1') then
                        length <= length - empty_in_reg(0);
                    end if;
                end if;
--            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (valid_in_reg(0) = '1') then
                if (length(15) = '1') then
                    packet_is_valid <= '0';
                else
                    packet_is_valid <= '1';
                end if;
            else
                packet_is_valid <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (valid_in_reg(0) = '1') then
                if (length(15 downto 3) = 0) then
                    packet_is_end <= '1';
                else
                    packet_is_end <= '0';
                end if;
            else
                packet_is_end <= '0';
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- dataDirection (O-RAN layer)
--------------------------------------------------------------------------------

    u_DL_ONLY : if DIRECTION = "DL" generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                matched_direction <= '0';
                matched_payload_version <= '0';
            else
                if (cnt = 1) then
                    if (datadirection = "1") then
                        matched_direction <= '1';
                    else
                        matched_direction <= '0';
                    end if;
                    
                    if (payload_version = "001") then
                        matched_payload_version <= '1';
                    else
                        matched_payload_version <= '0';
                    end if;
                    
                    
                end if;
            end if;
        end if;
    end process;
    end generate;


    u_UL_ONLY : if DIRECTION = "UL" generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                matched_direction <= '0';
                matched_payload_version <= '0';

            else
                if (cnt = 1) then
                    if (datadirection = "0") then
                        matched_direction <= '1';
                    else
                        matched_direction <= '0';
                    end if;
                    
                    if (payload_version = "001") then
                        matched_payload_version <= '1';
                    else
                        matched_payload_version <= '0';
                    end if;
                    
                    
                end if;
            end if;
        end if;
    end process;
    end generate;

    u_BOTH : if DIRECTION = "BOTH" generate
        matched_direction <= '1';
        matched_payload_version <= '1';
    end generate;


    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            condition2 <= matched_direction and matched_payload_version;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Monitor FIFO
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IN_VALID /= 0) and (IN_LAST = '1') then
                condition3 <= '1';
            else
                if (cnt = 2) then
                    if (OUT_FULL = '1') then
                        condition3 <= '0';
                    else
                        condition3 <= '1';
                    end if;
                end if;
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Output control
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            valid_in_reg(1 downto 0) <= valid_in_reg(0) & (IN_VALID(0) or IN_VALID(1));
            last_in_reg(1 downto 0)  <= last_in_reg(0) & IN_LAST;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            valid_in_reg(2) <= valid_in_reg(1) and packet_is_valid;
            last_in_reg(2)  <= last_in_reg(1) or packet_is_end;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            valid_in_reg(4 downto 3) <= valid_in_reg(3 downto 2);
            last_in_reg(4 downto 3)  <= last_in_reg(3 downto 2);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dest_in_reg(0)  <= IN_VALID(1);
            empty_in_reg(0) <= KEEP_TO_EMPTY_LSB(IN_KEEP);
            data_in_reg(0)  <= IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (length(15 downto 3) = 0) then
                if (length(2 downto 0) < empty_in_reg(0)) then
                    empty_in_reg(1) <= ('0' & length(2 downto 0)) + 1;
                else
                    empty_in_reg(1) <= empty_in_reg(0);
                end if;
            else
                empty_in_reg(1) <= "1000";
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            dest_in_reg(4 downto 1)  <= dest_in_reg(3 downto 0);
            empty_in_reg(4 downto 2) <= empty_in_reg(3 downto 1);
            data_in_reg(4 downto 1)  <= data_in_reg(3 downto 0);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = 3) then
                if (condition0 = '1') and (condition1 /= 0) and (condition2 = '1') then
                    output_enable <= '1';
                else
                    output_enable <= '0';
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = 3) then
                sub_channel_bit <= condition1;
            end if;
        end if;
    end process;

    process (sub_channel_bit)
    begin
        case sub_channel_bit is
        when "00000010" => sub_channel_value <= "001";
        when "00000100" => sub_channel_value <= "010";
        when "00001000" => sub_channel_value <= "011";
        when "00010000" => sub_channel_value <= "100";
        when "00100000" => sub_channel_value <= "101";
        when "01000000" => sub_channel_value <= "110";
        when "10000000" => sub_channel_value <= "111";
        when others     => sub_channel_value <= "000";
        end case;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (output_enable = '1') and (valid_in_reg(3) = '1') and (condition3 = '1') then
                OUT_VALID       <= '1';
            else
                OUT_VALID       <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (output_enable = '1') and (valid_in_reg(3) = '1') then
                OUT_LAST        <= last_in_reg(3);
                OUT_DEST        <= dest_in_reg(3);
                OUT_KEEP        <= EMPTY_TO_KEEP_LSB(empty_in_reg(3));
                OUT_DATA        <= data_in_reg(3);
                OUT_STAMP       <= '1';
                OUT_CH          <= sub_channel_value;
                OUT_CH_BIT      <= sub_channel_bit;
            else
                OUT_LAST        <= '0';
                OUT_DEST        <= '0';
                OUT_KEEP        <= (others => '0');
                OUT_DATA        <= (others => '0');
                OUT_STAMP       <= '0';
                OUT_CH          <= (others => '0');
                OUT_CH_BIT      <= (others => '0');
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    CNT_C_PLANE_DROPPED             <= x"0000" & dropped_cp;
    CNT_U_PLANE_DROPPED             <= x"0000" & dropped_up;
    CNT_LENGTH_IS_NORMAL            <= x"0000" & length_is_normal;
    CNT_LENGTH_IS_LONG              <= x"0000" & length_is_long;
    CNT_LENGTH_IS_SHORT             <= x"0000" & length_is_short;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (cnt = 2) then
                if (OUT_FULL = '1') then
                    if (valid_in_reg(1) = '1') and (dest_in_reg(1) = '0') then
                        dropped_cp <= dropped_cp + 1;
                    end if;
                    if (valid_in_reg(1) = '1') and (dest_in_reg(1) = '1') then
                        dropped_up <= dropped_up + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case IN_KEEP is
            when "00000001" => keep_to_empty <= "000";
            when "00000011" => keep_to_empty <= "001";
            when "00000111" => keep_to_empty <= "010";
            when "00001111" => keep_to_empty <= "011";
            when "00011111" => keep_to_empty <= "100";
            when "00111111" => keep_to_empty <= "101";
            when "01111111" => keep_to_empty <= "110";
            when "11111111" => keep_to_empty <= "111";
            when others     => keep_to_empty <= "111";
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (valid_in_reg(0) = '1') and (last_in_reg(0) = '1') then
--                if (packet_is_end = '1') then
--                    left_length <= (others => '1');
--                else
                    left_length <= length - keep_to_empty;
--                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (valid_in_reg(0) = '1') and (last_in_reg(0) = '1') then
                check_normality <= '1';
            else
                check_normality <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (check_normality = '1') and (left_length = 0) then
                inc_normal <= '1';
            else
                inc_normal <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (check_normality = '1') and (left_length(15) = '0') and (left_length(14 downto 0) /= 0) then
                inc_long <= '1';
            else
                inc_long <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (check_normality = '1') and (left_length(15) = '1') then
                inc_short <= '1';
            else
                inc_short <= '0';
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (inc_normal = '1') then
                length_is_normal <= length_is_normal + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (inc_long = '1') then
                length_is_long <= length_is_long + 1;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (inc_short = '1') then
                length_is_short <= length_is_short + 1;
            end if;
        end if;
    end process;

end BEHAVE;