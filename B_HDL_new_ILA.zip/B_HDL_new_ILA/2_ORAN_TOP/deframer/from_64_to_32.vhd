--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : 64bits@390.625MHz -> 32bits@245.76MHz                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity FROM_64_TO_32 is
    port (
--------------------------------------------------------------------------------
-- Clock
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

--------------------------------------------------------------------------------
-- AXI input (64bits x 390.625MHz)
--------------------------------------------------------------------------------

        IN_CLK                      : in  std_logic;

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);
        IN_USER                     : in  std_logic_vector(6 downto 0);

--------------------------------------------------------------------------------
-- AXI output (32bits x 245.76MHz)
--------------------------------------------------------------------------------

        OUT_CLK                     : in  std_logic;

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(3 downto 0);
        OUT_DATA                    : out std_logic_vector(31 downto 0);
        OUT_USER                    : out std_logic_vector(6 downto 0)
    );
end FROM_64_TO_32;

architecture BEHAVE of FROM_64_TO_32 is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal sreset_in                : std_logic;
    signal sreset_in_n              : std_logic;
    signal sreset_out               : std_logic;
    signal sreset_out_n             : std_logic;

    component AXIS_CLOCK_DOWN is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        M_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(6 downto 0);
        M_AXIS_ACLK                 : in  std_logic;
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(6 downto 0)
    );
    end component;

    signal clock_axis_tvalid        : std_logic;
    signal clock_axis_tready        : std_logic;
    signal clock_axis_tdata         : std_logic_vector(63 downto 0);
    signal clock_axis_tkeep         : std_logic_vector(7 downto 0);
    signal clock_axis_tlast         : std_logic;
    signal clock_axis_tuser         : std_logic_vector(6 downto 0);

    component AXIS_REG_64 is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(6 downto 0)
    );
    end component;

    signal clock_reg_axis_tvalid    : std_logic;
    signal clock_reg_axis_tready    : std_logic;
    signal clock_reg_axis_tdata     : std_logic_vector(63 downto 0);
    signal clock_reg_axis_tkeep     : std_logic_vector(7 downto 0);
    signal clock_reg_axis_tlast     : std_logic;
    signal clock_reg_axis_tuser     : std_logic_vector(15 downto 0) := (others => '0');

    component AXIS_WIDTH_DOWN is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(15 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(7 downto 0)
    );
    end component;

    signal width_axis_tvalid        : std_logic;
    signal width_axis_tready        : std_logic;
    signal width_axis_tdata         : std_logic_vector(31 downto 0);
    signal width_axis_tkeep         : std_logic_vector(3 downto 0);
    signal width_axis_tlast         : std_logic;
    signal width_axis_tuser         : std_logic_vector(7 downto 0);

    component AXIS_REG_32 is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(6 downto 0)
    );
    end component;

begin

--------------------------------------------------------------------------------
-- Synchronous reset
--------------------------------------------------------------------------------

    u_RST_IN : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => ARESET                                  ,--: in  std_logic;
        CLK                         => IN_CLK                                  ,--: in  std_logic;
        RST_OUT                     => sreset_in                                --: out std_logic
    );

    u_RST_OUT : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => ARESET                                  ,--: in  std_logic;
        CLK                         => OUT_CLK                                 ,--: in  std_logic;
        RST_OUT                     => sreset_out                               --: out std_logic
    );

    sreset_in_n                     <= not sreset_in;
    sreset_out_n                    <= not sreset_out;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_CLOCK : AXIS_CLOCK_DOWN
    port map(
        S_AXIS_ARESETN              => sreset_in_n                             ,--: in  std_logic;
        M_AXIS_ARESETN              => sreset_out_n                            ,--: in  std_logic;
        S_AXIS_ACLK                 => IN_CLK                                  ,--: in  std_logic;
        S_AXIS_TVALID               => IN_VALID                                ,--: in  std_logic;
        S_AXIS_TREADY               => IN_READY                                ,--: out std_logic;
        S_AXIS_TDATA                => IN_DATA                                 ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                => IN_KEEP                                 ,--: in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                => IN_LAST                                 ,--: in  std_logic;
        S_AXIS_TUSER                => IN_USER                                 ,--: in  std_logic_vector(6 downto 0);
        M_AXIS_ACLK                 => OUT_CLK                                 ,--: in  std_logic;
        M_AXIS_TVALID               => clock_axis_tvalid                       ,--: out std_logic;
        M_AXIS_TREADY               => clock_axis_tready                       ,--: in  std_logic;
        M_AXIS_TDATA                => clock_axis_tdata                        ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                => clock_axis_tkeep                        ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                => clock_axis_tlast                        ,--: out std_logic;
        M_AXIS_TUSER                => clock_axis_tuser                         --: out std_logic_vector(6 downto 0)
    );

    u_CLOCK_REG : AXIS_REG_64
    port map(
        ACLK                        => OUT_CLK                                 ,--: in  std_logic;
        ARESETN                     => sreset_out_n                            ,--: in  std_logic;
        S_AXIS_TVALID               => clock_axis_tvalid                       ,--: in  std_logic;
        S_AXIS_TREADY               => clock_axis_tready                       ,--: out std_logic;
        S_AXIS_TDATA                => clock_axis_tdata                        ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                => clock_axis_tkeep                        ,--: in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                => clock_axis_tlast                        ,--: in  std_logic;
        S_AXIS_TUSER                => clock_axis_tuser                        ,--: in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               => clock_reg_axis_tvalid                   ,--: out std_logic;
        M_AXIS_TREADY               => clock_reg_axis_tready                   ,--: in  std_logic;
        M_AXIS_TDATA                => clock_reg_axis_tdata                    ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                => clock_reg_axis_tkeep                    ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                => clock_reg_axis_tlast                    ,--: out std_logic;
        M_AXIS_TUSER                => clock_reg_axis_tuser(6 downto 0)         --: out std_logic_vector(6 downto 0)
    );

    clock_reg_axis_tuser(14 downto 8) <= clock_reg_axis_tuser(6 downto 0);

    u_WIDTH : AXIS_WIDTH_DOWN
    port map(
        ACLK                        => OUT_CLK                                 ,--: in  std_logic;
        ARESETN                     => sreset_out_n                            ,--: in  std_logic;
        S_AXIS_TVALID               => clock_reg_axis_tvalid                   ,--: in  std_logic;
        S_AXIS_TREADY               => clock_reg_axis_tready                   ,--: out std_logic;
        S_AXIS_TDATA                => clock_reg_axis_tdata                    ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                => clock_reg_axis_tkeep                    ,--: in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                => clock_reg_axis_tlast                    ,--: in  std_logic;
        S_AXIS_TUSER                => clock_reg_axis_tuser                    ,--: in  std_logic_vector(15 downto 0);
        M_AXIS_TVALID               => width_axis_tvalid                       ,--: out std_logic;
        M_AXIS_TREADY               => width_axis_tready                       ,--: in  std_logic;
        M_AXIS_TDATA                => width_axis_tdata                        ,--: out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                => width_axis_tkeep                        ,--: out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                => width_axis_tlast                        ,--: out std_logic;
        M_AXIS_TUSER                => width_axis_tuser                         --: out std_logic_vector(7 downto 0)
    );

    u_WIDTH_REG : AXIS_REG_32
    port map(
        ACLK                        => OUT_CLK                                 ,--: in  std_logic;
        ARESETN                     => sreset_out_n                            ,--: in  std_logic;
        S_AXIS_TVALID               => width_axis_tvalid                       ,--: in  std_logic;
        S_AXIS_TREADY               => width_axis_tready                       ,--: out std_logic;
        S_AXIS_TDATA                => width_axis_tdata                        ,--: in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                => width_axis_tkeep                        ,--: in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                => width_axis_tlast                        ,--: in  std_logic;
        S_AXIS_TUSER                => width_axis_tuser(6 downto 0)            ,--: in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               => OUT_VALID                               ,--: out std_logic;
        M_AXIS_TREADY               => OUT_READY                               ,--: in  std_logic;
        M_AXIS_TDATA                => OUT_DATA                                ,--: out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                => OUT_KEEP                                ,--: out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                => OUT_LAST                                ,--: out std_logic;
        M_AXIS_TUSER                => OUT_USER                                 --: out std_logic_vector(6 downto 0)
    );

end BEHAVE;