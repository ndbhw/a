--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN Deframer                                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;
use WORK.PKG_O_RAN.ALL;

entity O_RAN_DEFRAMER is
    generic (
        MAX_CH_PER_UNIT             : natural := 8;
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true;
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        RST                         : in  std_logic;                            -- ASYNC

        CLK_MAC                     : in  std_logic;                            -- 390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        RX_PARAM_MAC                : in  std_logic_vector(47 downto 0);
        RX_PARAM_ETHERTYPE          : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_0_EN        : in  std_logic;
        RX_PARAM_ID_CH0_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_1_EN        : in  std_logic;
        RX_PARAM_ID_CH0_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_2_EN        : in  std_logic;
        RX_PARAM_ID_CH0_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH0_3_EN        : in  std_logic;
        RX_PARAM_ID_CH0_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_0_EN        : in  std_logic;
        RX_PARAM_ID_CH1_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_1_EN        : in  std_logic;
        RX_PARAM_ID_CH1_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_2_EN        : in  std_logic;
        RX_PARAM_ID_CH1_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH1_3_EN        : in  std_logic;
        RX_PARAM_ID_CH1_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_0_EN        : in  std_logic;
        RX_PARAM_ID_CH2_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_1_EN        : in  std_logic;
        RX_PARAM_ID_CH2_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_2_EN        : in  std_logic;
        RX_PARAM_ID_CH2_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH2_3_EN        : in  std_logic;
        RX_PARAM_ID_CH2_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_0_EN        : in  std_logic;
        RX_PARAM_ID_CH3_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_1_EN        : in  std_logic;
        RX_PARAM_ID_CH3_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_2_EN        : in  std_logic;
        RX_PARAM_ID_CH3_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH3_3_EN        : in  std_logic;
        RX_PARAM_ID_CH3_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_0_EN        : in  std_logic;
        RX_PARAM_ID_CH4_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_1_EN        : in  std_logic;
        RX_PARAM_ID_CH4_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_2_EN        : in  std_logic;
        RX_PARAM_ID_CH4_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH4_3_EN        : in  std_logic;
        RX_PARAM_ID_CH4_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_0_EN        : in  std_logic;
        RX_PARAM_ID_CH5_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_1_EN        : in  std_logic;
        RX_PARAM_ID_CH5_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_2_EN        : in  std_logic;
        RX_PARAM_ID_CH5_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH5_3_EN        : in  std_logic;
        RX_PARAM_ID_CH5_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_0_EN        : in  std_logic;
        RX_PARAM_ID_CH6_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_1_EN        : in  std_logic;
        RX_PARAM_ID_CH6_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_2_EN        : in  std_logic;
        RX_PARAM_ID_CH6_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH6_3_EN        : in  std_logic;
        RX_PARAM_ID_CH6_3           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_0_EN        : in  std_logic;
        RX_PARAM_ID_CH7_0           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_1_EN        : in  std_logic;
        RX_PARAM_ID_CH7_1           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_2_EN        : in  std_logic;
        RX_PARAM_ID_CH7_2           : in  std_logic_vector(15 downto 0);
        RX_PARAM_ID_CH7_3_EN        : in  std_logic;
        RX_PARAM_ID_CH7_3           : in  std_logic_vector(15 downto 0);

        RX_COMP_MODE                : in  std_logic;
        RX_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        RX_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        RX_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        RX_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        RX_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);
        RX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        USAGE_RX_DATA_BUFFER        : out std_logic_vector(31 downto 0);

        RX_INVALID_DST_MAC          : out std_logic_vector(31 downto 0);
        RX_INVALID_ETHERTYPE        : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriVersion     : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriC           : out std_logic_vector(31 downto 0);
        RX_INVALID_ecpriMessage     : out std_logic_vector(31 downto 0);
        RX_C_PLANE                  : out std_logic_vector(31 downto 0);
        RX_C_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_U_PLANE                  : out std_logic_vector(31 downto 0);
        RX_U_PLANE_DROPPED          : out std_logic_vector(31 downto 0);
        RX_LOST                     : out std_logic_vector(31 downto 0);

        RX_LENGTH_IS_NORMAL         : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_LONG           : out std_logic_vector(31 downto 0);
        RX_LENGTH_IS_SHORT          : out std_logic_vector(31 downto 0);

        RX_C_PLANE_EXIST            : out std_logic_vector(31 downto 0);
        RX_U_PLANE_EXIST            : out std_logic_vector(31 downto 0);

        RX_FAULT_ID_31_CH0          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- MAC (RX)
--------------------------------------------------------------------------------

        MAC_RX_READY                : out std_logic;
        MAC_RX_VALID                : in  std_logic;
        MAC_RX_LAST                 : in  std_logic;
        MAC_RX_KEEP                 : in  std_logic_vector(7 downto 0);
        MAC_RX_DATA                 : in  std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);

--------------------------------------------------------------------------------
-- Bypassed C/U-Plane
--------------------------------------------------------------------------------

        BYPASS_OUT_VALID            : out std_logic;
        BYPASS_OUT_LAST             : out std_logic;
        BYPASS_OUT_KEEP             : out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- DL/UL C-Plane (Not decoded)
--------------------------------------------------------------------------------

        eCPRI_RX_C_VALID            : out std_logic;
        eCPRI_RX_C_LAST             : out std_logic;
        eCPRI_RX_C_KEEP             : out std_logic_vector(3 downto 0);
        eCPRI_RX_C_DATA             : out std_logic_vector(31 downto 0);
        eCPRI_RX_C_CH               : out std_logic_vector(2 downto 0);
        eCPRI_RX_C_CH_SUB           : out std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- DL U-Plane (Decoded)
--------------------------------------------------------------------------------

        ADV_RB_CHANNEL_ID           : out std_logic_vector(2 downto 0);         -- 4-clocks advanced
        ADV_RB_FRAME_ID             : out std_logic_vector(7 downto 0);         -- 4-clocks advanced
        ADV_RB_SUBFRAME_ID          : out std_logic_vector(3 downto 0);         -- 4-clocks advanced
        ADV_RB_SLOT_ID              : out std_logic_vector(5 downto 0);         -- 4-clocks advanced
        ADV_RB_SYMBOL_ID            : out std_logic_vector(5 downto 0);         -- 4-clocks advanced
        ADV_RB_START                : out std_logic;                            -- 4-clocks advanced

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               : out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 : out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              : out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  : out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                : out std_logic_vector(5 downto 0);
        RB_SECTION_ID               : out std_logic_vector(11 downto 0);
        RB_NUMBER                   : out std_logic_vector(9 downto 0);
        RE_NUMBER                   : out std_logic_vector(11 downto 0);

        RB_VALID                    : out std_logic;
        RB_START                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_LAST                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);

        MAC_HEADER_REMOVED_OUT_VALID        : out std_logic_vector(2 downto 0);
        MAC_HEADER_REMOVED_OUT_LAST         : out std_logic;                   
        MAC_HEADER_REMOVED_OUT_KEEP         : out std_logic_vector(7 downto 0);
        MAC_HEADER_REMOVED_OUT_DATA         : out std_logic_vector(63 downto 0);
        
        RX_CORRUPT_SECTIONID        : out std_logic                
        
        
    );
end O_RAN_DEFRAMER;

architecture BEHAVE of O_RAN_DEFRAMER is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal srst                     : std_logic;

    component PKT_FILTER is
    generic (
        MAX_CH                      : natural := 8;
        FILTER_MAC                  : boolean := true;
        FILTER_ETHERTYPE            : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CLK_BUS                     : in  std_logic;
        
        PARAM_MAC                   : in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_0_EN           : in  std_logic;
        PARAM_ID_CH0_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_1_EN           : in  std_logic;
        PARAM_ID_CH0_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_2_EN           : in  std_logic;
        PARAM_ID_CH0_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_3_EN           : in  std_logic;
        PARAM_ID_CH0_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_0_EN           : in  std_logic;
        PARAM_ID_CH1_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_1_EN           : in  std_logic;
        PARAM_ID_CH1_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_2_EN           : in  std_logic;
        PARAM_ID_CH1_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_3_EN           : in  std_logic;
        PARAM_ID_CH1_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_0_EN           : in  std_logic;
        PARAM_ID_CH2_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_1_EN           : in  std_logic;
        PARAM_ID_CH2_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_2_EN           : in  std_logic;
        PARAM_ID_CH2_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_3_EN           : in  std_logic;
        PARAM_ID_CH2_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_0_EN           : in  std_logic;
        PARAM_ID_CH3_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_1_EN           : in  std_logic;
        PARAM_ID_CH3_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_2_EN           : in  std_logic;
        PARAM_ID_CH3_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_3_EN           : in  std_logic;
        PARAM_ID_CH3_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_0_EN           : in  std_logic;
        PARAM_ID_CH4_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_1_EN           : in  std_logic;
        PARAM_ID_CH4_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_2_EN           : in  std_logic;
        PARAM_ID_CH4_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_3_EN           : in  std_logic;
        PARAM_ID_CH4_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_0_EN           : in  std_logic;
        PARAM_ID_CH5_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_1_EN           : in  std_logic;
        PARAM_ID_CH5_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_2_EN           : in  std_logic;
        PARAM_ID_CH5_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_3_EN           : in  std_logic;
        PARAM_ID_CH5_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_0_EN           : in  std_logic;
        PARAM_ID_CH6_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_1_EN           : in  std_logic;
        PARAM_ID_CH6_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_2_EN           : in  std_logic;
        PARAM_ID_CH6_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_3_EN           : in  std_logic;
        PARAM_ID_CH6_3              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_0_EN           : in  std_logic;
        PARAM_ID_CH7_0              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_1_EN           : in  std_logic;
        PARAM_ID_CH7_1              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_2_EN           : in  std_logic;
        PARAM_ID_CH7_2              : in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_3_EN           : in  std_logic;
        PARAM_ID_CH7_3              : in  std_logic_vector(15 downto 0);

        SCS_CONFIG                  : in  std_logic_vector(3 downto 0);

        CNT_INVALID_DST_MAC         : out std_logic_vector(31 downto 0);
        CNT_INVALID_ETHERTYPE       : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriVersion    : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriC          : out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriMessage    : out std_logic_vector(31 downto 0);
        CNT_C_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_C_PLANE_DROPPED         : out std_logic_vector(31 downto 0);
        CNT_U_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         : out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          : out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         : out std_logic_vector(31 downto 0);

        C_PLANE_EXIST               : out std_logic_vector(31 downto 0);
        U_PLANE_EXIST               : out std_logic_vector(31 downto 0);

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

        OUT_FULL                    : in  std_logic;

        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_DEST                    : out std_logic_vector(0 downto 0);
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0);
        OUT_CH                      : out std_logic_vector(2 downto 0);
        OUT_CH_SUB                  : out std_logic_vector(3 downto 0);

        BYPASS_OUT_VALID            : out std_logic;
        BYPASS_OUT_LAST             : out std_logic;
        BYPASS_OUT_KEEP             : out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             : out std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_SCS                  : out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             : out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          : out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            : out std_logic_vector(5 downto 0);
        
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- Synchronization
--------------------------------------------------------------------------------

        N_TA_OFFSET                 : in  std_logic_vector(15 downto 0);

        REF_10msec                  : in  std_logic;                            -- Longer than 1-clocks@245.76-MHz
        REF_SFN                     : in  std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        CAPTURE_PERIOD              : in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            : in  std_logic_vector(21 downto 0);
        
        MAC_HEADER_REMOVED_OUT_VALID        : out std_logic_vector(2 downto 0);         -- [0] : CP, [1] : UP, [2] : Others
        MAC_HEADER_REMOVED_OUT_LAST         : out std_logic;
        MAC_HEADER_REMOVED_OUT_KEEP         : out std_logic_vector(7 downto 0);
        MAC_HEADER_REMOVED_OUT_DATA         : out std_logic_vector(63 downto 0);
        
        RX_CORRUPT_SECTIONID        : out std_logic                
    );
    end component;

    signal rx_filtered_valid        : std_logic;
    signal rx_filtered_last         : std_logic;
    signal rx_filtered_dest         : std_logic_vector(0 downto 0);
    signal rx_filtered_keep         : std_logic_vector(7 downto 0);
    signal rx_filtered_data         : std_logic_vector(63 downto 0);
    signal rx_filtered_ch           : std_logic_vector(2 downto 0);
    signal rx_filtered_ch_sub       : std_logic_vector(3 downto 0);

    component PKT_RX is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        RST                         : in  std_logic;

        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        PROG_FULL                   : out std_logic;

        USAGE_DATA_BUFFER           : out std_logic_vector(31 downto 0);

        CNT_LOST                    : out std_logic_vector(31 downto 0);

        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_DEST                     : in  std_logic_vector(0 downto 0);
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);
        IN_CH                       : in  std_logic_vector(2 downto 0);
        IN_CH_SUB                   : in  std_logic_vector(3 downto 0);

        OUT_C_READY                 : in  std_logic;
        OUT_C_VALID                 : out std_logic;
        OUT_C_LAST                  : out std_logic;
        OUT_C_KEEP                  : out std_logic_vector(3 downto 0);
        OUT_C_DATA                  : out std_logic_vector(31 downto 0);
        OUT_C_CH                    : out std_logic_vector(2 downto 0);
        OUT_C_CH_SUB                : out std_logic_vector(3 downto 0);

        OUT_U_READY                 : in  std_logic;
        OUT_U_VALID                 : out std_logic;
        OUT_U_LAST                  : out std_logic;
        OUT_U_KEEP                  : out std_logic_vector(3 downto 0);
        OUT_U_DATA                  : out std_logic_vector(31 downto 0);
        OUT_U_CH                    : out std_logic_vector(2 downto 0);
        OUT_U_CH_SUB                : out std_logic_vector(3 downto 0)
    );
    end component;

    signal rx_prog_full             : std_logic;

--    signal ecpri_rx_cp_ready        : std_logic;
    signal ecpri_rx_cp_valid        : std_logic;
    signal ecpri_rx_cp_last         : std_logic;
    signal ecpri_rx_cp_keep         : std_logic_vector(3 downto 0);
    signal ecpri_rx_cp_data         : std_logic_vector(31 downto 0);
    signal ecpri_rx_cp_ch           : std_logic_vector(2 downto 0);
    signal ecpri_rx_cp_ch_sub       : std_logic_vector(3 downto 0);
    signal ecpri_rx_up_ready        : std_logic;
    signal ecpri_rx_up_valid        : std_logic;
    signal ecpri_rx_up_last         : std_logic;
    signal ecpri_rx_up_keep         : std_logic_vector(3 downto 0);
    signal ecpri_rx_up_data         : std_logic_vector(31 downto 0);
    signal ecpri_rx_up_ch           : std_logic_vector(2 downto 0);
    signal ecpri_rx_up_ch_sub       : std_logic_vector(3 downto 0);

    component FAULT_ID_31 is
    generic (
        USAGE_TYPE0                 : boolean := false;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := false;
        USAGE_TYPE7                 : boolean := false
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        RX_FAULT_ID_31_CH0          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          : out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          : out std_logic_vector(3 downto 0);

        CP32_VALID                  : in  std_logic;
        CP32_LAST                   : in  std_logic;
        CP32_DATA                   : in  std_logic_vector(31 downto 0);
        CP32_DATA_MAP               : in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             : in  std_logic_vector(2 downto 0)
    );
    end component;

    signal cp_fault_id_31_ch0       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch1       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch2       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch3       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch4       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch5       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch6       : std_logic_vector(3 downto 0);
    signal cp_fault_id_31_ch7       : std_logic_vector(3 downto 0);

    component PRB_UNPACKER is
    generic (
        LINK_DIRECTION              : std_logic := '0'
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        COMP_MODE                   : in  std_logic;
        IQ_WIDTH                    : in  std_logic_vector(3 downto 0);
        COMP_METHOD                 : in  std_logic_vector(3 downto 0);

        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);

        CNTUP_FAULT_ID_31           : out std_logic_vector(7 downto 0);

        U_PLANE_READY               : out std_logic;
        U_PLANE_VALID               : in  std_logic;
        U_PLANE_LAST                : in  std_logic;
        U_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        U_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        U_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        U_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        COMP_FRAME_ID               : out std_logic_vector(7 downto 0);
        COMP_SUBFRAME_ID            : out std_logic_vector(3 downto 0);
        COMP_SLOT_ID                : out std_logic_vector(5 downto 0);
        COMP_SYMBOL_ID              : out std_logic_vector(5 downto 0);
        COMP_USER                   : out std_logic_vector(61 downto 0);

        COMP_HDR                    : out std_logic_vector(7 downto 0);
        COMP_PARAM                  : out std_logic_vector(7 downto 0);

        COMP_VALID                  : out std_logic;
        COMP_TICK                   : out std_logic;
        COMP_DATA_I                 : out std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : out std_logic_vector(15 downto 0)
    );
    end component;

    signal cntup_fault_id_31        : std_logic_vector(7 downto 0) := (others => '0');
--    signal cnt_up_fault_id_31       : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal comp_frame_id            : std_logic_vector(7 downto 0);
    signal comp_subframe_id         : std_logic_vector(3 downto 0);
    signal comp_slot_id             : std_logic_vector(5 downto 0);
    signal comp_symbol_id           : std_logic_vector(5 downto 0);
    signal comp_user                : std_logic_vector(61 downto 0) := (others => '0');
    signal comp_hdr                 : std_logic_vector(7 downto 0);
    signal comp_param               : std_logic_vector(7 downto 0);
    signal comp_valid               : std_logic;
    signal comp_tick                : std_logic;
    signal comp_data_i              : std_logic_vector(15 downto 0);
    signal comp_data_q              : std_logic_vector(15 downto 0);

    component PRB_DECOMP is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        COMP_EXP_OFFSET             : in  std_logic_vector(4 downto 0);

        COMP_FRAME_ID               : in  std_logic_vector(7 downto 0);
        COMP_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        COMP_SLOT_ID                : in  std_logic_vector(5 downto 0);
        COMP_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        COMP_USER                   : in  std_logic_vector(61 downto 0);

        COMP_HDR                    : in  std_logic_vector(7 downto 0);
        COMP_PARAM                  : in  std_logic_vector(7 downto 0);

        COMP_VALID                  : in  std_logic;
        COMP_TICK                   : in  std_logic;
        COMP_DATA_I                 : in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : in  std_logic_vector(15 downto 0);

        IQ_FRAME_ID                 : out std_logic_vector(7 downto 0);
        IQ_SUBFRAME_ID              : out std_logic_vector(3 downto 0);
        IQ_SLOT_ID                  : out std_logic_vector(5 downto 0);
        IQ_SYMBOL_ID                : out std_logic_vector(5 downto 0);
        IQ_USER                     : out std_logic_vector(61 downto 0);

        IQ_VALID                    : out std_logic;
        IQ_TICK                     : out std_logic;
        IQ_DATA_I                   : out std_logic_vector(15 downto 0);
        IQ_DATA_Q                   : out std_logic_vector(15 downto 0)
    );
    end component;

    signal iq_frame_id              : std_logic_vector(7 downto 0);
    signal iq_subframe_id           : std_logic_vector(3 downto 0);
    signal iq_slot_id               : std_logic_vector(5 downto 0);
    signal iq_symbol_id             : std_logic_vector(5 downto 0);
    signal iq_user                  : std_logic_vector(61 downto 0);
    signal iq_valid                 : std_logic;
    signal iq_tick                  : std_logic;
    signal iq_data_i                : std_logic_vector(15 downto 0);
    signal iq_data_q                : std_logic_vector(15 downto 0);

    component CONV_IF is
    port (
        CLK                         : in  std_logic;

        IQ_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        IQ_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        IQ_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        IQ_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        IQ_USER                     : in  std_logic_vector(61 downto 0);

        IQ_VALID                    : in  std_logic;
        IQ_TICK                     : in  std_logic;
        IQ_DATA_I                   : in  std_logic_vector(15 downto 0);
        IQ_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               : out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 : out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              : out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  : out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                : out std_logic_vector(5 downto 0);
        RB_SECTION_ID               : out std_logic_vector(11 downto 0);
        RB_NUMBER                   : out std_logic_vector(9 downto 0);
        RE_NUMBER                   : out std_logic_vector(11 downto 0);

        RB_VALID                    : out std_logic;
        RB_START                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_LAST                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0)
    );
    end component;

begin

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST_OUT                     => srst                                     --: out std_logic
    );
    
    u_PKT_FILTER : PKT_FILTER
    generic map(
        MAX_CH                      => MAX_CH_PER_UNIT                         ,--: natural := 8;
        FILTER_MAC                  => FILTER_MAC                              ,--: boolean := true;
        FILTER_ETHERTYPE            => FILTER_ETHERTYPE                         --: boolean := true
    )
    port map(
        CLK                         => CLK_MAC                                 ,--: in  std_logic;
        RST                         => srst                                    ,--: in  std_logic;

        CLK_BUS                     => CLK_BUS,

        PARAM_MAC                   => RX_PARAM_MAC                            ,--: in  std_logic_vector(47 downto 0);
        PARAM_ETHERTYPE             => RX_PARAM_ETHERTYPE                      ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_0_EN           => RX_PARAM_ID_CH0_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH0_0              => RX_PARAM_ID_CH0_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_1_EN           => RX_PARAM_ID_CH0_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH0_1              => RX_PARAM_ID_CH0_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_2_EN           => RX_PARAM_ID_CH0_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH0_2              => RX_PARAM_ID_CH0_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH0_3_EN           => RX_PARAM_ID_CH0_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH0_3              => RX_PARAM_ID_CH0_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_0_EN           => RX_PARAM_ID_CH1_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH1_0              => RX_PARAM_ID_CH1_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_1_EN           => RX_PARAM_ID_CH1_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH1_1              => RX_PARAM_ID_CH1_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_2_EN           => RX_PARAM_ID_CH1_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH1_2              => RX_PARAM_ID_CH1_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH1_3_EN           => RX_PARAM_ID_CH1_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH1_3              => RX_PARAM_ID_CH1_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_0_EN           => RX_PARAM_ID_CH2_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH2_0              => RX_PARAM_ID_CH2_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_1_EN           => RX_PARAM_ID_CH2_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH2_1              => RX_PARAM_ID_CH2_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_2_EN           => RX_PARAM_ID_CH2_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH2_2              => RX_PARAM_ID_CH2_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH2_3_EN           => RX_PARAM_ID_CH2_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH2_3              => RX_PARAM_ID_CH2_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_0_EN           => RX_PARAM_ID_CH3_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH3_0              => RX_PARAM_ID_CH3_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_1_EN           => RX_PARAM_ID_CH3_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH3_1              => RX_PARAM_ID_CH3_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_2_EN           => RX_PARAM_ID_CH3_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH3_2              => RX_PARAM_ID_CH3_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH3_3_EN           => RX_PARAM_ID_CH3_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH3_3              => RX_PARAM_ID_CH3_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_0_EN           => RX_PARAM_ID_CH4_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH4_0              => RX_PARAM_ID_CH4_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_1_EN           => RX_PARAM_ID_CH4_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH4_1              => RX_PARAM_ID_CH4_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_2_EN           => RX_PARAM_ID_CH4_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH4_2              => RX_PARAM_ID_CH4_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH4_3_EN           => RX_PARAM_ID_CH4_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH4_3              => RX_PARAM_ID_CH4_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_0_EN           => RX_PARAM_ID_CH5_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH5_0              => RX_PARAM_ID_CH5_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_1_EN           => RX_PARAM_ID_CH5_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH5_1              => RX_PARAM_ID_CH5_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_2_EN           => RX_PARAM_ID_CH5_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH5_2              => RX_PARAM_ID_CH5_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH5_3_EN           => RX_PARAM_ID_CH5_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH5_3              => RX_PARAM_ID_CH5_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_0_EN           => RX_PARAM_ID_CH6_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH6_0              => RX_PARAM_ID_CH6_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_1_EN           => RX_PARAM_ID_CH6_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH6_1              => RX_PARAM_ID_CH6_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_2_EN           => RX_PARAM_ID_CH6_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH6_2              => RX_PARAM_ID_CH6_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH6_3_EN           => RX_PARAM_ID_CH6_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH6_3              => RX_PARAM_ID_CH6_3                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_0_EN           => RX_PARAM_ID_CH7_0_EN                    ,--: in  std_logic;
        PARAM_ID_CH7_0              => RX_PARAM_ID_CH7_0                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_1_EN           => RX_PARAM_ID_CH7_1_EN                    ,--: in  std_logic;
        PARAM_ID_CH7_1              => RX_PARAM_ID_CH7_1                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_2_EN           => RX_PARAM_ID_CH7_2_EN                    ,--: in  std_logic;
        PARAM_ID_CH7_2              => RX_PARAM_ID_CH7_2                       ,--: in  std_logic_vector(15 downto 0);
        PARAM_ID_CH7_3_EN           => RX_PARAM_ID_CH7_3_EN                    ,--: in  std_logic;
        PARAM_ID_CH7_3              => RX_PARAM_ID_CH7_3                       ,--: in  std_logic_vector(15 downto 0);

        SCS_CONFIG                  => RX_SCS_CONFIG                           ,--: in  std_logic_vector(3 downto 0);

        CNT_INVALID_DST_MAC         => RX_INVALID_DST_MAC                      ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ETHERTYPE       => RX_INVALID_ETHERTYPE                    ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriVersion    => RX_INVALID_ecpriVersion                 ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriC          => RX_INVALID_ecpriC                       ,--: out std_logic_vector(31 downto 0);
        CNT_INVALID_ecpriMessage    => RX_INVALID_ecpriMessage                 ,--: out std_logic_vector(31 downto 0);
        CNT_C_PLANE                 => RX_C_PLANE                              ,--: out std_logic_vector(31 downto 0);
        CNT_C_PLANE_DROPPED         => RX_C_PLANE_DROPPED                      ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE                 => RX_U_PLANE                              ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_DROPPED         => RX_U_PLANE_DROPPED                      ,--: out std_logic_vector(31 downto 0);

        CNT_LENGTH_IS_NORMAL        => RX_LENGTH_IS_NORMAL                     ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_LONG          => RX_LENGTH_IS_LONG                       ,--: out std_logic_vector(31 downto 0);
        CNT_LENGTH_IS_SHORT         => RX_LENGTH_IS_SHORT                      ,--: out std_logic_vector(31 downto 0);

        C_PLANE_EXIST               => RX_C_PLANE_EXIST                        ,--: out std_logic_vector(31 downto 0);
        U_PLANE_EXIST               => RX_U_PLANE_EXIST                        ,--: out std_logic_vector(31 downto 0);

        IN_READY                    => MAC_RX_READY                            ,--: out std_logic;
        IN_VALID                    => MAC_RX_VALID                            ,--: in  std_logic;
        IN_LAST                     => MAC_RX_LAST                             ,--: in  std_logic;
        IN_KEEP                     => MAC_RX_KEEP                             ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => MAC_RX_DATA                             ,--: in  std_logic_vector(63 downto 0);

        OUT_FULL                    => rx_prog_full                            ,--: in  std_logic;

        OUT_VALID                   => rx_filtered_valid                       ,--: out std_logic;
        OUT_LAST                    => rx_filtered_last                        ,--: out std_logic;
        OUT_DEST                    => rx_filtered_dest                        ,--: out std_logic_vector(0 downto 0);
        OUT_KEEP                    => rx_filtered_keep                        ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => rx_filtered_data                        ,--: out std_logic_vector(63 downto 0);
        OUT_CH                      => rx_filtered_ch                          ,--: out std_logic_vector(2 downto 0);
        OUT_CH_SUB                  => rx_filtered_ch_sub                      ,--: out std_logic_vector(3 downto 0);

        BYPASS_OUT_VALID            => BYPASS_OUT_VALID                        ,--: out std_logic;
        BYPASS_OUT_LAST             => BYPASS_OUT_LAST                         ,--: out std_logic;
        BYPASS_OUT_KEEP             => BYPASS_OUT_KEEP                         ,--: out std_logic_vector(7 downto 0);
        BYPASS_OUT_DATA             => BYPASS_OUT_DATA                         ,--: out std_logic_vector(63 downto 0);

        PACKET_IS_CP_DL             => PACKET_IS_CP_DL                         ,--: out std_logic;
        PACKET_IS_CP_UL             => PACKET_IS_CP_UL                         ,--: out std_logic;
        PACKET_IS_UP_DL             => PACKET_IS_UP_DL                         ,--: out std_logic;
        PACKET_IS_UP_UL             => PACKET_IS_UP_UL                         ,--: out std_logic;
        PACKET_SCS                  => PACKET_SCS                              ,--: out std_logic_vector(3 downto 0);
        PACKET_FRAME_ID             => PACKET_FRAME_ID                         ,--: out std_logic_vector(7 downto 0);
        PACKET_SUBFRAME_ID          => PACKET_SUBFRAME_ID                      ,--: out std_logic_vector(3 downto 0);
        PACKET_SLOT_ID              => PACKET_SLOT_ID                          ,--: out std_logic_vector(5 downto 0);
        PACKET_SYMBOL_ID            => PACKET_SYMBOL_ID                        ,--: out std_logic_vector(5 downto 0)
        
        CLK_CPUIF                   => CLK_CPUIF                               ,--: in  std_logic;
        RST_CPUIF                   => RST_CPUIF                               ,--: in  std_logic;

        N_TA_OFFSET                 => N_TA_OFFSET                             ,--: in  std_logic_vector(15 downto 0);

        REF_10msec                  => REF_10msec                              ,--: in  std_logic;
        REF_SFN                     => REF_SFN                                 ,--: in  std_logic_vector(7 downto 0);

        CAPTURE_PERIOD              => CAPTURE_PERIOD                          ,--: in  std_logic_vector(7 downto 0);

        T2A_MAX_DL_CP_RX            => T2A_MAX_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_CP_RX            => T2A_MIN_DL_CP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MAX_DL_UP_RX            => T2A_MAX_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        T2A_MIN_DL_UP_RX            => T2A_MIN_DL_UP_RX                        ,--: in  std_logic_vector(21 downto 0);
        
        MAC_HEADER_REMOVED_OUT_VALID => MAC_HEADER_REMOVED_OUT_VALID           ,
        MAC_HEADER_REMOVED_OUT_LAST  => MAC_HEADER_REMOVED_OUT_LAST            ,                       
        MAC_HEADER_REMOVED_OUT_KEEP  => MAC_HEADER_REMOVED_OUT_KEEP            ,
        MAC_HEADER_REMOVED_OUT_DATA  => MAC_HEADER_REMOVED_OUT_DATA            ,
        
        RX_CORRUPT_SECTIONID         => RX_CORRUPT_SECTIONID                

    );

    u_PKT_RX : PKT_RX
    generic map(
        USAGE_C_PLANE               => USAGE_C_PLANE                           ,--: boolean := true;
        USAGE_U_PLANE               => USAGE_U_PLANE                            --: boolean := true
    )
    port map(
        RST                         => RST                                     ,--: in  std_logic;

        CLK_MAC                     => CLK_MAC                                 ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        PROG_FULL                   => rx_prog_full                            ,--: out std_logic;

        USAGE_DATA_BUFFER           => USAGE_RX_DATA_BUFFER                    ,--: out std_logic_vector(31 downto 0);

        CNT_LOST                    => RX_LOST                                 ,--: out std_logic_vector(31 downto 0);

        IN_VALID                    => rx_filtered_valid                       ,--: in  std_logic;
        IN_LAST                     => rx_filtered_last                        ,--: in  std_logic;
        IN_DEST                     => rx_filtered_dest                        ,--: in  std_logic_vector(0 downto 0);
        IN_KEEP                     => rx_filtered_keep                        ,--: in  std_logic_vector(7 downto 0);
        IN_DATA                     => rx_filtered_data                        ,--: in  std_logic_vector(63 downto 0);
        IN_CH                       => rx_filtered_ch                          ,--: in  std_logic_vector(2 downto 0);
        IN_CH_SUB                   => rx_filtered_ch_sub                      ,--: in  std_logic_vector(3 downto 0);

        OUT_C_READY                 => '1'                                     ,--: in  std_logic;
        OUT_C_VALID                 => ecpri_rx_cp_valid                       ,--: out std_logic;
        OUT_C_LAST                  => ecpri_rx_cp_last                        ,--: out std_logic;
        OUT_C_KEEP                  => ecpri_rx_cp_keep                        ,--: out std_logic_vector(3 downto 0);
        OUT_C_DATA                  => ecpri_rx_cp_data                        ,--: out std_logic_vector(31 downto 0);
        OUT_C_CH                    => ecpri_rx_cp_ch                          ,--: out std_logic_vector(2 downto 0);
        OUT_C_CH_SUB                => ecpri_rx_cp_ch_sub                      ,--: out std_logic_vector(3 downto 0);

        OUT_U_READY                 => ecpri_rx_up_ready                       ,--: in  std_logic;
        OUT_U_VALID                 => ecpri_rx_up_valid                       ,--: out std_logic;
        OUT_U_LAST                  => ecpri_rx_up_last                        ,--: out std_logic;
        OUT_U_KEEP                  => ecpri_rx_up_keep                        ,--: out std_logic_vector(3 downto 0);
        OUT_U_DATA                  => ecpri_rx_up_data                        ,--: out std_logic_vector(31 downto 0);
        OUT_U_CH                    => ecpri_rx_up_ch                          ,--: out std_logic_vector(2 downto 0);
        OUT_U_CH_SUB                => ecpri_rx_up_ch_sub                       --: out std_logic_vector(3 downto 0)
    );

    eCPRI_RX_C_VALID                <= ecpri_rx_cp_valid;
    eCPRI_RX_C_LAST                 <= ecpri_rx_cp_last;
    eCPRI_RX_C_KEEP                 <= ecpri_rx_cp_keep;
    eCPRI_RX_C_DATA                 <= ecpri_rx_cp_data;
    eCPRI_RX_C_CH                   <= ecpri_rx_cp_ch;
    eCPRI_RX_C_CH_SUB               <= ecpri_rx_cp_ch_sub;

    u_CP_FAULT_ID_31 : FAULT_ID_31
    generic map(
        USAGE_TYPE0                 => false                                   ,--: boolean := false;
        USAGE_TYPE1                 => true                                    ,--: boolean := true;
        USAGE_TYPE3                 => true                                    ,--: boolean := true;
        USAGE_TYPE5                 => false                                   ,--: boolean := true;
        USAGE_TYPE6                 => false                                   ,--: boolean := false;
        USAGE_TYPE7                 => false                                    --: boolean := false
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => srst                                    ,--: in  std_logic;

        RX_FAULT_ID_31_CH0          => cp_fault_id_31_ch0                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH1          => cp_fault_id_31_ch1                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH2          => cp_fault_id_31_ch2                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH3          => cp_fault_id_31_ch3                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH4          => cp_fault_id_31_ch4                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH5          => cp_fault_id_31_ch5                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH6          => cp_fault_id_31_ch6                      ,--: out std_logic_vector(3 downto 0);
        RX_FAULT_ID_31_CH7          => cp_fault_id_31_ch7                      ,--: out std_logic_vector(3 downto 0);

        CP32_VALID                  => ecpri_rx_cp_valid                       ,--: in  std_logic;
        CP32_LAST                   => ecpri_rx_cp_last                        ,--: in  std_logic;
        CP32_DATA                   => ecpri_rx_cp_data                        ,--: in  std_logic_vector(31 downto 0);
        CP32_DATA_map               => ecpri_rx_cp_ch_sub                      ,--: in  std_logic_vector(3 downto 0);
        CP32_LINK_INDEX             => ecpri_rx_cp_ch                           --: in  std_logic_vector(2 downto 0)
    );

    RX_FAULT_ID_31_CH0              <= cp_fault_id_31_ch0(3 downto 1) & (cp_fault_id_31_ch0(0) or cntup_fault_id_31(0));
    RX_FAULT_ID_31_CH1              <= cp_fault_id_31_ch1(3 downto 1) & (cp_fault_id_31_ch1(0) or cntup_fault_id_31(1));
    RX_FAULT_ID_31_CH2              <= cp_fault_id_31_ch2(3 downto 1) & (cp_fault_id_31_ch2(0) or cntup_fault_id_31(2));
    RX_FAULT_ID_31_CH3              <= cp_fault_id_31_ch3(3 downto 1) & (cp_fault_id_31_ch3(0) or cntup_fault_id_31(3));
    RX_FAULT_ID_31_CH4              <= cp_fault_id_31_ch4(3 downto 1) & (cp_fault_id_31_ch4(0) or cntup_fault_id_31(4));
    RX_FAULT_ID_31_CH5              <= cp_fault_id_31_ch5(3 downto 1) & (cp_fault_id_31_ch5(0) or cntup_fault_id_31(5));
    RX_FAULT_ID_31_CH6              <= cp_fault_id_31_ch6(3 downto 1) & (cp_fault_id_31_ch6(0) or cntup_fault_id_31(6));
    RX_FAULT_ID_31_CH7              <= cp_fault_id_31_ch7(3 downto 1) & (cp_fault_id_31_ch7(0) or cntup_fault_id_31(7));

    u_U_PLANE_USED : if USAGE_U_PLANE = true generate
    ADV_RB_CHANNEL_ID  <= comp_user(61 downto 59);
    ADV_RB_FRAME_ID    <= comp_frame_id;
    ADV_RB_SUBFRAME_ID <= comp_subframe_id;
    ADV_RB_SLOT_ID     <= comp_slot_id;
    ADV_RB_SYMBOL_ID   <= comp_symbol_id;
    ADV_RB_START       <= comp_tick and comp_user(0);

    u_UNPACKER : PRB_UNPACKER
    generic map(
        LINK_DIRECTION              => RX_LINK_DIRECTION                        --: std_logic := '0'
    )
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => srst                                    ,--: in  std_logic;

        COMP_MODE                   => RX_COMP_MODE                            ,--: in  std_logic;
        IQ_WIDTH                    => RX_IQ_WIDTH                             ,--: in  std_logic_vector(3 downto 0);
        COMP_METHOD                 => RX_COMP_METHOD                          ,--: in  std_logic_vector(3 downto 0);

        PRB_PER_SYMBOL              => RX_PRB_PER_SYMBOL                       ,--: in  std_logic_vector(9 downto 0);

        CNTUP_FAULT_ID_31           => open, --cntup_fault_id_31                       ,--: out std_logic_vector(7 downto 0);

        U_PLANE_READY               => ecpri_rx_up_ready                       ,--: out std_logic;
        U_PLANE_VALID               => ecpri_rx_up_valid                       ,--: in  std_logic;
        U_PLANE_LAST                => ecpri_rx_up_last                        ,--: in  std_logic;
        U_PLANE_KEEP                => ecpri_rx_up_keep                        ,--: in  std_logic_vector(3 downto 0);
        U_PLANE_DATA                => ecpri_rx_up_data                        ,--: in  std_logic_vector(31 downto 0);
        U_PLANE_CH                  => ecpri_rx_up_ch                          ,--: in  std_logic_vector(2 downto 0);
        U_PLANE_CH_SUB              => ecpri_rx_up_ch_sub                      ,--: in  std_logic_vector(3 downto 0);

        COMP_FRAME_ID               => comp_frame_id                           ,--: out std_logic_vector(7 downto 0);
        COMP_SUBFRAME_ID            => comp_subframe_id                        ,--: out std_logic_vector(3 downto 0);
        COMP_SLOT_ID                => comp_slot_id                            ,--: out std_logic_vector(5 downto 0);
        COMP_SYMBOL_ID              => comp_symbol_id                          ,--: out std_logic_vector(5 downto 0);
        COMP_USER                   => comp_user                               ,--: out std_logic_vector(61 downto 0);

        COMP_HDR                    => comp_hdr                                ,--: out std_logic_vector(7 downto 0);
        COMP_PARAM                  => comp_param                              ,--: out std_logic_vector(7 downto 0);

        COMP_VALID                  => comp_valid                              ,--: out std_logic;
        COMP_TICK                   => comp_tick                               ,--: out std_logic;
        COMP_DATA_I                 => comp_data_i                             ,--: out std_logic_vector(15 downto 0);
        COMP_DATA_Q                 => comp_data_q                              --: out std_logic_vector(15 downto 0)
    );

--    u_CNT_DL_UP_FAULT_ID_31 : for i in MAX_CH_PER_UNIT-1 downto 0 generate
--    RX_FAULT_ID_31_UP_DL(i)         <= cnt_up_fault_id_31(i);
--
--    process (CLK_BUS)
--    begin
--        if (CLK_BUS'event and CLK_BUS = '1') then
--            if (cntup_fault_id_31(i) = '1') then
--                cnt_up_fault_id_31(i) <= cnt_up_fault_id_31(i) + 1;
--            end if;
--        end if;
--    end process;
--    end generate;

    u_DECOMP : PRB_DECOMP
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => srst                                    ,--: in  std_logic;

        COMP_EXP_OFFSET             => RX_COMP_EXP_OFFSET                      ,--: in  std_logic_vector(4 downto 0);

        COMP_FRAME_ID               => comp_frame_id                           ,--: in  std_logic_vector(7 downto 0);
        COMP_SUBFRAME_ID            => comp_subframe_id                        ,--: in  std_logic_vector(3 downto 0);
        COMP_SLOT_ID                => comp_slot_id                            ,--: in  std_logic_vector(5 downto 0);
        COMP_SYMBOL_ID              => comp_symbol_id                          ,--: in  std_logic_vector(5 downto 0);
        COMP_USER                   => comp_user                               ,--: in  std_logic_vector(61 downto 0);

        COMP_HDR                    => comp_hdr                                ,--: in  std_logic_vector(7 downto 0);
        COMP_PARAM                  => comp_param                              ,--: in  std_logic_vector(7 downto 0);

        COMP_VALID                  => comp_valid                              ,--: in  std_logic;
        COMP_TICK                   => comp_tick                               ,--: in  std_logic;
        COMP_DATA_I                 => comp_data_i                             ,--: in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 => comp_data_q                             ,--: in  std_logic_vector(15 downto 0);

        IQ_FRAME_ID                 => iq_frame_id                             ,--: out std_logic_vector(7 downto 0);
        IQ_SUBFRAME_ID              => iq_subframe_id                          ,--: out std_logic_vector(3 downto 0);
        IQ_SLOT_ID                  => iq_slot_id                              ,--: out std_logic_vector(5 downto 0);
        IQ_SYMBOL_ID                => iq_symbol_id                            ,--: out std_logic_vector(5 downto 0);
        IQ_USER                     => iq_user                                 ,--: out std_logic_vector(61 downto 0);

        IQ_VALID                    => iq_valid                                ,--: out std_logic;
        IQ_TICK                     => iq_tick                                 ,--: out std_logic;
        IQ_DATA_I                   => iq_data_i                               ,--: out std_logic_vector(15 downto 0);
        IQ_DATA_Q                   => iq_data_q                                --: out std_logic_vector(15 downto 0)
    );

    u_CONV : CONV_IF
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;

        IQ_FRAME_ID                 => iq_frame_id                             ,--: in  std_logic_vector(7 downto 0);
        IQ_SUBFRAME_ID              => iq_subframe_id                          ,--: in  std_logic_vector(3 downto 0);
        IQ_SLOT_ID                  => iq_slot_id                              ,--: in  std_logic_vector(5 downto 0);
        IQ_SYMBOL_ID                => iq_symbol_id                            ,--: in  std_logic_vector(5 downto 0);
        IQ_USER                     => iq_user                                 ,--: in  std_logic_vector(61 downto 0);

        IQ_VALID                    => iq_valid                                ,--: in  std_logic;
        IQ_TICK                     => iq_tick                                 ,--: in  std_logic;
        IQ_DATA_I                   => iq_data_i                               ,--: in  std_logic_vector(15 downto 0);
        IQ_DATA_Q                   => iq_data_q                               ,--: in  std_logic_vector(15 downto 0);

        RB_eAxC_ID                  => RB_eAxC_ID                              ,--: out std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => RB_SEQUENCE_ID                          ,--: out std_logic_vector(15 downto 0);
        RB_CHANNEL_ID               => RB_CHANNEL_ID                           ,--: out std_logic_vector(2 downto 0);
        RB_FRAME_ID                 => RB_FRAME_ID                             ,--: out std_logic_vector(7 downto 0);
        RB_SUBFRAME_ID              => RB_SUBFRAME_ID                          ,--: out std_logic_vector(3 downto 0);
        RB_SLOT_ID                  => RB_SLOT_ID                              ,--: out std_logic_vector(5 downto 0);
        RB_SYMBOL_ID                => RB_SYMBOL_ID                            ,--: out std_logic_vector(5 downto 0);
        RB_SECTION_ID               => RB_SECTION_ID                           ,--: out std_logic_vector(11 downto 0);
        RB_NUMBER                   => RB_NUMBER                               ,--: out std_logic_vector(9 downto 0);
        RE_NUMBER                   => RE_NUMBER                               ,--: out std_logic_vector(11 downto 0);

        RB_VALID                    => RB_VALID                                ,--: out std_logic;
        RB_START                    => RB_START                                ,--: out std_logic;
        RB_TICK                     => RB_TICK                                 ,--: out std_logic;
        RB_LAST                     => RB_LAST                                 ,--: out std_logic;
        RB_DATA_I                   => RB_DATA_I                               ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => RB_DATA_Q                                --: out std_logic_vector(15 downto 0)
    );
    end generate;

    u_U_PLANE_UNUSED : if USAGE_U_PLANE = false generate
    ADV_RB_CHANNEL_ID               <= (others => '0');
    ADV_RB_FRAME_ID                 <= (others => '0');
    ADV_RB_SUBFRAME_ID              <= (others => '0');
    ADV_RB_SLOT_ID                  <= (others => '0');
    ADV_RB_SYMBOL_ID                <= (others => '0');
    ADV_RB_START                    <= '0';

    RB_eAxC_ID                      <= (others => '0');
    RB_SEQUENCE_ID                  <= (others => '0');
    RB_CHANNEL_ID                   <= (others => '0');
    RB_FRAME_ID                     <= (others => '0');
    RB_SUBFRAME_ID                  <= (others => '0');
    RB_SLOT_ID                      <= (others => '0');
    RB_SYMBOL_ID                    <= (others => '0');
    RB_SECTION_ID                   <= (others => '0');
    RB_NUMBER                       <= (others => '0');
    RE_NUMBER                       <= (others => '0');

    RB_VALID                        <= '0';
    RB_START                        <= '0';
    RB_TICK                         <= '0';
    RB_LAST                         <= '0';
    RB_DATA_I                       <= (others => '0');
    RB_DATA_Q                       <= (others => '0');
    end generate;

end BEHAVE;