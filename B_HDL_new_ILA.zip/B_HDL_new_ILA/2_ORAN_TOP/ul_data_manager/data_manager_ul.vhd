--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN UL data manager                                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;
use WORK.ARRAY_TYPE.ALL;

entity DATA_MANAGER_UL is
    generic (
        MAX_CH                      : natural := 8;
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        LONG_PRACH                  : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;                            -- 245.76-MHz
        RST                         : in  std_logic;                            -- ASYNC

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        UL_PUxCH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PUxCH_ID                 : in  std_logic_array16(7 downto 0);
        UL_PRACH_EN                 : in  std_logic_vector(7 downto 0);
        UL_PRACH_ID                 : in  std_logic_array16(7 downto 0);

        UL_COMP_MODE                : in  std_logic;
        UL_IQ_WIDTH                 : in  std_logic_vector(3 downto 0);
        UL_COMP_METHOD              : in  std_logic_vector(3 downto 0);
        UL_SCS_CONFIG               : in  std_logic_vector(3 downto 0);
        UL_FFT_SIZE                 : in  std_logic_vector(3 downto 0);
        UL_PRB_PER_MTU              : in  std_logic_vector(9 downto 0);
        UL_PRB_PER_SYMBOL           : in  std_logic_vector(9 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_UPPKT_SYMBOL13    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- DL/UL C-Plane (Not decoded)
--------------------------------------------------------------------------------

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- ULFE
--------------------------------------------------------------------------------

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        ULFE_START_RE               : in  std_logic_vector(15 downto 0);

        ULFE_VALID                  : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_START                  : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_LAST                   : in  std_logic_vector(MAX_CH-1 downto 0);
        ULFE_DATA_I                 : in  std_logic_array16(MAX_CH-1 downto 0);
        ULFE_DATA_Q                 : in  std_logic_array16(MAX_CH-1 downto 0);

--------------------------------------------------------------------------------
-- RAFE
--------------------------------------------------------------------------------

        RAFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        RAFE_START_RE               : in  std_logic_vector(15 downto 0);

        RAFE_VALID                  : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_START                  : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_LAST                   : in  std_logic_vector(MAX_CH-1 downto 0);
        RAFE_DATA_I                 : in  std_logic_array16(MAX_CH-1 downto 0);
        RAFE_DATA_Q                 : in  std_logic_array16(MAX_CH-1 downto 0);

--------------------------------------------------------------------------------
-- UL U-Plane (Not encoded)
--------------------------------------------------------------------------------

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PUxCH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PUxCH_RB_VALID              : out std_logic;
        PUxCH_RB_TICK               : out std_logic;
        PUxCH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PUxCH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PUxCH_RB_USER               : out std_logic_vector(15 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_RB_COMP_HDR           : out std_logic_vector(7 downto 0);

        PRACH_RB_VALID              : out std_logic;
        PRACH_RB_TICK               : out std_logic;
        PRACH_RB_DATA_I             : out std_logic_vector(15 downto 0);
        PRACH_RB_DATA_Q             : out std_logic_vector(15 downto 0);
        PRACH_RB_USER               : out std_logic_vector(15 downto 0)
    );
end DATA_MANAGER_UL;

architecture BEHAVE of DATA_MANAGER_UL is

    signal rafe_valid_buf           : std_logic_vector(7 downto 0) := (others => '0');
    signal rafe_last_buf            : std_logic_vector(7 downto 0) := (others => '0');

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset                    : std_logic;

    component UL_SCHEDULER is
    generic (
        MAX_CH                      : natural := 8;
        LINK_DIRECTION              : std_logic := '0';
        MAX_SECTION_PUxCH           : natural := 256;
        MAX_SECTION_PRACH           : natural := 16;
        USAGE_TYPE0                 : boolean := true;
        USAGE_TYPE1                 : boolean := true;
        USAGE_TYPE3                 : boolean := true;
        USAGE_TYPE5                 : boolean := true;
        USAGE_TYPE6                 : boolean := true;
        USAGE_TYPE7                 : boolean := false
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    : out std_logic_vector(7 downto 0);

        PUxCH_ID                    : in  std_logic_array16(MAX_CH-1 downto 0);
        PRACH_ID                    : in  std_logic_array16(MAX_CH-1 downto 0);

        COMP_MODE                   : in  std_logic;
        IQ_WIDTH                    : in  std_logic_vector(3 downto 0);
        COMP_METHOD                 : in  std_logic_vector(3 downto 0);
        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               : out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PUxCH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PUxCH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       : out std_logic_vector(31 downto 0);

        CNT_PRACH_CPSEC_SYMBOL0     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    : out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    : out std_logic_vector(31 downto 0);

        CNT_PRACH_CQ_FULL_SYMBOL0   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  : out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  : out std_logic_vector(31 downto 0);

        USAGE_PRACH_CQ_SYMBOL0      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     : out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     : out std_logic_vector(31 downto 0);

        C_PLANE_VALID               : in  std_logic;
        C_PLANE_LAST                : in  std_logic;
        C_PLANE_KEEP                : in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                : in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  : in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              : in  std_logic_vector(3 downto 0);

        ULFE_UPDATE                 : in  std_logic;

        ULFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);

        PUxCH_INIT                  : out std_logic;
        PUxCH_PACKING_TICK          : out std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : out std_logic;
        PUxCH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : out std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_SECTION_LAST          : out std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_SECTION_DONE          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : out std_logic;
        PUxCH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PUxCH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PUxCH_UD_COMP_HDR           : out std_logic_vector(7 downto 0);

        RAFE_UPDATE                 : in  std_logic;

        RAFE_FRAME_ID               : in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                : in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        RAFE_CHANNEL_ID             : in  std_logic_vector(2 downto 0);

        PRACH_INIT                  : out std_logic;
        PRACH_PACKING_TICK          : out std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              : out std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : out std_logic;
        PRACH_PAYLOAD_VERSION       : out std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : out std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : out std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : out std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : out std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : out std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : out std_logic_vector(MAX_CH-1 downto 0);
        PRACH_SECTION_LAST          : out std_logic_vector(MAX_CH-1 downto 0);
        PRACH_SECTION_DONE          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            : out std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : out std_logic;
        PRACH_START_OF_PRB          : out std_logic_vector(9 downto 0);
        PRACH_OFFSET_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : out std_logic_vector(9 downto 0);
        PRACH_UD_COMP_HDR           : out std_logic_vector(7 downto 0)
    );
    end component;

    signal puxch_update             : std_logic;
    signal puxch_init               : std_logic;
    signal puxch_packing_tick       : std_logic_vector(MAX_CH-1 downto 0);
    signal puxch_rtcpc_id           : std_logic_vector(15 downto 0);
    signal puxch_data_direction     : std_logic;
    signal puxch_payload_version    : std_logic_vector(2 downto 0);
    signal puxch_filter_index       : std_logic_vector(3 downto 0);
    signal puxch_frame_id           : std_logic_vector(7 downto 0);
    signal puxch_subframe_id        : std_logic_vector(3 downto 0);
    signal puxch_slot_id            : std_logic_vector(5 downto 0);
    signal puxch_symbol_id          : std_logic_vector(5 downto 0);
    signal puxch_section_tick       : std_logic_vector(MAX_CH-1 downto 0);
    signal puxch_section_last       : std_logic_vector(MAX_CH-1 downto 0);
    signal puxch_section_done       : std_logic_vector(MAX_CH-1 downto 0);
    signal puxch_section_id         : std_logic_vector(11 downto 0);
    signal puxch_use_every_prb      : std_logic;
    signal puxch_start_of_prb       : std_logic_vector(9 downto 0);
--    signal puxch_offset_of_prb      : std_logic_vector(9 downto 0);
    signal puxch_number_of_prb      : std_logic_vector(9 downto 0);
    signal puxch_ud_comp_hdr        : std_logic_vector(7 downto 0);

    signal prach_update             : std_logic;
    signal prach_init               : std_logic;
    signal prach_channel_id         : std_logic_vector(2 downto 0);
    signal prach_packing_tick       : std_logic_vector(MAX_CH-1 downto 0);
    signal prach_rtcpc_id           : std_logic_vector(15 downto 0);
    signal prach_data_direction     : std_logic;
    signal prach_payload_version    : std_logic_vector(2 downto 0);
    signal prach_filter_index       : std_logic_vector(3 downto 0);
    signal prach_frame_id           : std_logic_vector(7 downto 0);
    signal prach_subframe_id        : std_logic_vector(3 downto 0);
    signal prach_slot_id            : std_logic_vector(5 downto 0);
    signal prach_symbol_id          : std_logic_vector(5 downto 0);
    signal prach_section_tick       : std_logic_vector(MAX_CH-1 downto 0);
    signal prach_section_last       : std_logic_vector(MAX_CH-1 downto 0);
    signal prach_section_done       : std_logic_vector(MAX_CH-1 downto 0);
    signal prach_section_id         : std_logic_vector(11 downto 0);
    signal prach_use_every_prb      : std_logic;
    signal prach_start_of_prb       : std_logic_vector(9 downto 0);
    signal prach_offset_of_prb      : std_logic_vector(9 downto 0);
    signal prach_number_of_prb      : std_logic_vector(9 downto 0);
    signal prach_ud_comp_hdr        : std_logic_vector(7 downto 0);

    component UL_PARAM is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        EN_MULTI_SEQUENCE           : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_INIT                  : in  std_logic;
        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : in  std_logic;
        PUxCH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : in  std_logic;
        PUxCH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

        PRACH_INIT                  : in  std_logic;
        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : in  std_logic;
        PRACH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : in  std_logic;
        PRACH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic
    );
    end component;

    signal en_multi_sequence        : std_logic_vector(MAX_CH-1 downto 0);

    component UL_TX_WINDOW is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_PACKET_SYMBOL0          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         : out std_logic_vector(31 downto 0);

        PACKING_TICK                : in  std_logic;

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic;
        SECTION_LAST                : in  std_logic;
        SECTION_DONE                : out std_logic;

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        UL_START_RE                 : in  std_logic_vector(15 downto 0);

        UL_VALID                    : in  std_logic;
        UL_START                    : in  std_logic;
        UL_LAST                     : in  std_logic;
        UL_DATA_I                   : in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 : out std_logic_vector(7 downto 0);

        RB_VALID                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        RB_USER                     : out std_logic_vector(15 downto 0)
    );
    end component;

    component UL_TX_WINDOW_RACH is
    generic (
        LONG_PRACH                  : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        CNT_PACKET_SYMBOL0          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         : out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         : out std_logic_vector(31 downto 0);

        PACKING_TICK                : in  std_logic;

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic;
        SECTION_LAST                : in  std_logic;
        SECTION_DONE                : out std_logic;

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 : in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              : in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  : in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                : in  std_logic_vector(5 downto 0);
        UL_START_RE                 : in  std_logic_vector(15 downto 0);

        UL_VALID                    : in  std_logic;
        UL_START                    : in  std_logic;
        UL_LAST                     : in  std_logic;
        UL_DATA_I                   : in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   : in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 : out std_logic_vector(7 downto 0);

        RB_VALID                    : out std_logic;
        RB_TICK                     : out std_logic;
        RB_DATA_I                   : out std_logic_vector(15 downto 0);
        RB_DATA_Q                   : out std_logic_vector(15 downto 0);
        RB_USER                     : out std_logic_vector(15 downto 0)
    );
    end component;

    signal puxch_comp_hdr           : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal puxch_valid              : std_logic_vector(7 downto 0) := (others => '0');
    signal puxch_tick               : std_logic_vector(7 downto 0) := (others => '0');
    signal puxch_data_i             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal puxch_data_q             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal puxch_user               : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach_comp_hdr           : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal prach_valid              : std_logic_vector(7 downto 0) := (others => '0');
    signal prach_tick               : std_logic_vector(7 downto 0) := (others => '0');
    signal prach_data_i             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach_data_q             : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal prach_user               : std_logic_array16(7 downto 0) := (others => (others => '0'));

    signal dbg_cnt_puxch_rb         : std_logic_vector(31 downto 0) := (others => '0');
    signal dbg_cnt_puxch_rpt        : std_logic_vector(3 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- Interrupt masking
--------------------------------------------------------------------------------

    rafe_valid_buf(MAX_CH-1 downto 0) <= RAFE_VALID;
    rafe_last_buf(MAX_CH-1 downto 0)  <= RAFE_LAST;

    puxch_update <= ULFE_VALID(MAX_CH-1) and ULFE_LAST(MAX_CH-1);
    prach_update <= '1' when (rafe_valid_buf and rafe_last_buf) /= 0 else '0';

    prach_channel_id  <= "001" when rafe_valid_buf(1) = '1' else
                         "010" when rafe_valid_buf(2) = '1' else
                         "011" when rafe_valid_buf(3) = '1' else
                         "100" when rafe_valid_buf(4) = '1' else
                         "101" when rafe_valid_buf(5) = '1' else
                         "110" when rafe_valid_buf(6) = '1' else
                         "111" when rafe_valid_buf(7) = '1' else
                         "000";

    u_MULTI_SEQUENCE : for i in MAX_CH-1 downto 0 generate
    en_multi_sequence(i) <= '0' when UL_PUxCH_ID(i) = UL_PRACH_ID(i) else '1';
    end generate;

--------------------------------------------------------------------------------
-- Port/signal mapping
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PUxCH_RB_COMP_HDR <= puxch_comp_hdr(0) or puxch_comp_hdr(1) or puxch_comp_hdr(2) or puxch_comp_hdr(3) or puxch_comp_hdr(4) or puxch_comp_hdr(5) or puxch_comp_hdr(6) or puxch_comp_hdr(7);
            PUxCH_RB_VALID    <= puxch_valid(0)    or puxch_valid(1)    or puxch_valid(2)    or puxch_valid(3)    or puxch_valid(4)    or puxch_valid(5)    or puxch_valid(6)    or puxch_valid(7);
            PUxCH_RB_TICK     <= puxch_tick(0)     or puxch_tick(1)     or puxch_tick(2)     or puxch_tick(3)     or puxch_tick(4)     or puxch_tick(5)     or puxch_tick(6)     or puxch_tick(7);
            PUxCH_RB_DATA_I   <= puxch_data_i(0)   or puxch_data_i(1)   or puxch_data_i(2)   or puxch_data_i(3)   or puxch_data_i(4)   or puxch_data_i(5)   or puxch_data_i(6)   or puxch_data_i(7);
            PUxCH_RB_DATA_Q   <= puxch_data_q(0)   or puxch_data_q(1)   or puxch_data_q(2)   or puxch_data_q(3)   or puxch_data_q(4)   or puxch_data_q(5)   or puxch_data_q(6)   or puxch_data_q(7);
            PUxCH_RB_USER     <= puxch_user(0)     or puxch_user(1)     or puxch_user(2)     or puxch_user(3)     or puxch_user(4)     or puxch_user(5)     or puxch_user(6)     or puxch_user(7);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PRACH_RB_COMP_HDR <= prach_comp_hdr(0) or prach_comp_hdr(1) or prach_comp_hdr(2) or prach_comp_hdr(3) or prach_comp_hdr(4) or prach_comp_hdr(5) or prach_comp_hdr(6) or prach_comp_hdr(7);
            PRACH_RB_VALID    <= prach_valid(0)    or prach_valid(1)    or prach_valid(2)    or prach_valid(3)    or prach_valid(4)    or prach_valid(5)    or prach_valid(6)    or prach_valid(7);
            PRACH_RB_TICK     <= prach_tick(0)     or prach_tick(1)     or prach_tick(2)     or prach_tick(3)     or prach_tick(4)     or prach_tick(5)     or prach_tick(6)     or prach_tick(7);
            PRACH_RB_DATA_I   <= prach_data_i(0)   or prach_data_i(1)   or prach_data_i(2)   or prach_data_i(3)   or prach_data_i(4)   or prach_data_i(5)   or prach_data_i(6)   or prach_data_i(7);
            PRACH_RB_DATA_Q   <= prach_data_q(0)   or prach_data_q(1)   or prach_data_q(2)   or prach_data_q(3)   or prach_data_q(4)   or prach_data_q(5)   or prach_data_q(6)   or prach_data_q(7);
            PRACH_RB_USER     <= prach_user(0)     or prach_user(1)     or prach_user(2)     or prach_user(3)     or prach_user(4)     or prach_user(5)     or prach_user(6)     or prach_user(7);
        end if;
    end process;

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

--    CNT_PUxCH_UPPKT_SYMBOL0     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL1     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL2     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL3     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL4     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL5     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL6     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL7     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL8     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL9     <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL10    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL11    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL12    <= (others => '0');
--    CNT_PUxCH_UPPKT_SYMBOL13    <= (others => '0');

    CNT_PRACH_UPPKT_SYMBOL0     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL1     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL2     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL3     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL4     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL5     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL6     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL7     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL8     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL9     <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL10    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL11    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL12    <= (others => '0');
    CNT_PRACH_UPPKT_SYMBOL13    <= (others => '0');

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_init = '1') then
                dbg_cnt_puxch_rb <= (others => '0');
            else
                if (puxch_section_tick(0) = '1') then
                    dbg_cnt_puxch_rb <= dbg_cnt_puxch_rb + puxch_number_of_prb;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_init = '1') then
                if (dbg_cnt_puxch_rb > UL_PRB_PER_SYMBOL) then
                    if (dbg_cnt_puxch_rpt = 13) then
                        dbg_cnt_puxch_rpt <= (others => '0');
                    else
                        dbg_cnt_puxch_rpt <= dbg_cnt_puxch_rpt + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (dbg_cnt_puxch_rpt = 0) then     CNT_PUxCH_UPPKT_SYMBOL0  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 1) then     CNT_PUxCH_UPPKT_SYMBOL1  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 2) then     CNT_PUxCH_UPPKT_SYMBOL2  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 3) then     CNT_PUxCH_UPPKT_SYMBOL3  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 4) then     CNT_PUxCH_UPPKT_SYMBOL4  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 5) then     CNT_PUxCH_UPPKT_SYMBOL5  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 6) then     CNT_PUxCH_UPPKT_SYMBOL6  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 7) then     CNT_PUxCH_UPPKT_SYMBOL7  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 8) then     CNT_PUxCH_UPPKT_SYMBOL8  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 9) then     CNT_PUxCH_UPPKT_SYMBOL9  <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 10) then    CNT_PUxCH_UPPKT_SYMBOL10 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 11) then    CNT_PUxCH_UPPKT_SYMBOL11 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 12) then    CNT_PUxCH_UPPKT_SYMBOL12 <= dbg_cnt_puxch_rb;   end if;
            if (dbg_cnt_puxch_rpt = 13) then    CNT_PUxCH_UPPKT_SYMBOL13 <= dbg_cnt_puxch_rb;   end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_RST : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_OUT                     => reset                                    --: out std_logic
    );

    u_SCHEDULER : UL_SCHEDULER
    generic map(
        MAX_CH                      => MAX_CH                                  ,--: natural := 8;
        LINK_DIRECTION              => TX_LINK_DIRECTION                       ,--: std_logic := '0';
        MAX_SECTION_PUxCH           => MAX_SECTION_PUxCH                       ,--: natural := 256;
        MAX_SECTION_PRACH           => MAX_SECTION_PRACH                       ,--: natural := 16;
        USAGE_TYPE0                 => false                                   ,--: boolean := true;
        USAGE_TYPE1                 => true                                    ,--: boolean := true;
        USAGE_TYPE3                 => true                                    ,--: boolean := true;
        USAGE_TYPE5                 => false                                   ,--: boolean := true;
        USAGE_TYPE6                 => false                                   ,--: boolean := true;
        USAGE_TYPE7                 => false                                    --: boolean := false
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => reset                                   ,--: in  std_logic;

        IGNORE_FRAME_ID             => IGNORE_FRAME_ID                         ,--: in  std_logic;
        IGNORE_FRAME_ID_PUxCH_RX    => IGNORE_FRAME_ID_PUxCH_RX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PUxCH_TX    => IGNORE_FRAME_ID_PUxCH_TX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_RX    => IGNORE_FRAME_ID_PRACH_RX                ,--: out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_PRACH_TX    => IGNORE_FRAME_ID_PRACH_TX                ,--: out std_logic_vector(7 downto 0);

        PUxCH_ID                    => UL_PUxCH_ID(MAX_CH-1 downto 0)          ,--: in  std_logic_array16(MAX_CH-1 downto 0);
        PRACH_ID                    => UL_PRACH_ID(MAX_CH-1 downto 0)          ,--: in  std_logic_array16(MAX_CH-1 downto 0);

        COMP_MODE                   => UL_COMP_MODE                            ,--: in  std_logic;
        IQ_WIDTH                    => UL_IQ_WIDTH                             ,--: in  std_logic_vector(3 downto 0);
        COMP_METHOD                 => UL_COMP_METHOD                          ,--: in  std_logic_vector(3 downto 0);
        PRB_PER_SYMBOL              => UL_PRB_PER_SYMBOL                       ,--: in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 => UL_PRB_PER_MTU                          ,--: in  std_logic_vector(9 downto 0);

        CNT_FIFO_FULL               => CNT_FIFO_FULL                           ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_TERMINATION       => CNT_PUxCH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_CPSEC_SYMBOL0     => CNT_PUxCH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL1     => CNT_PUxCH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL2     => CNT_PUxCH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL3     => CNT_PUxCH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL4     => CNT_PUxCH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL5     => CNT_PUxCH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL6     => CNT_PUxCH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL7     => CNT_PUxCH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL8     => CNT_PUxCH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL9     => CNT_PUxCH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL10    => CNT_PUxCH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL11    => CNT_PUxCH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL12    => CNT_PUxCH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CPSEC_SYMBOL13    => CNT_PUxCH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_PUxCH_CQ_FULL_SYMBOL0   => CNT_PUxCH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL1   => CNT_PUxCH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL2   => CNT_PUxCH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL3   => CNT_PUxCH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL4   => CNT_PUxCH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL5   => CNT_PUxCH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL6   => CNT_PUxCH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL7   => CNT_PUxCH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL8   => CNT_PUxCH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL9   => CNT_PUxCH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL10  => CNT_PUxCH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL11  => CNT_PUxCH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL12  => CNT_PUxCH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_PUxCH_CQ_FULL_SYMBOL13  => CNT_PUxCH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_PUxCH_CQ_SYMBOL0      => USAGE_PUxCH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL1      => USAGE_PUxCH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL2      => USAGE_PUxCH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL3      => USAGE_PUxCH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL4      => USAGE_PUxCH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL5      => USAGE_PUxCH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL6      => USAGE_PUxCH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL7      => USAGE_PUxCH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL8      => USAGE_PUxCH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL9      => USAGE_PUxCH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL10     => USAGE_PUxCH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL11     => USAGE_PUxCH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL12     => USAGE_PUxCH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PUxCH_CQ_SYMBOL13     => USAGE_PUxCH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_TERMINATION       => CNT_PRACH_TERMINATION                   ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_CPSEC_SYMBOL0     => CNT_PRACH_CPSEC_SYMBOL0                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL1     => CNT_PRACH_CPSEC_SYMBOL1                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL2     => CNT_PRACH_CPSEC_SYMBOL2                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL3     => CNT_PRACH_CPSEC_SYMBOL3                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL4     => CNT_PRACH_CPSEC_SYMBOL4                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL5     => CNT_PRACH_CPSEC_SYMBOL5                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL6     => CNT_PRACH_CPSEC_SYMBOL6                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL7     => CNT_PRACH_CPSEC_SYMBOL7                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL8     => CNT_PRACH_CPSEC_SYMBOL8                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL9     => CNT_PRACH_CPSEC_SYMBOL9                 ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL10    => CNT_PRACH_CPSEC_SYMBOL10                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL11    => CNT_PRACH_CPSEC_SYMBOL11                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL12    => CNT_PRACH_CPSEC_SYMBOL12                ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CPSEC_SYMBOL13    => CNT_PRACH_CPSEC_SYMBOL13                ,--: out std_logic_vector(31 downto 0);

        CNT_PRACH_CQ_FULL_SYMBOL0   => CNT_PRACH_CQ_FULL_SYMBOL0               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL1   => CNT_PRACH_CQ_FULL_SYMBOL1               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL2   => CNT_PRACH_CQ_FULL_SYMBOL2               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL3   => CNT_PRACH_CQ_FULL_SYMBOL3               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL4   => CNT_PRACH_CQ_FULL_SYMBOL4               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL5   => CNT_PRACH_CQ_FULL_SYMBOL5               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL6   => CNT_PRACH_CQ_FULL_SYMBOL6               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL7   => CNT_PRACH_CQ_FULL_SYMBOL7               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL8   => CNT_PRACH_CQ_FULL_SYMBOL8               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL9   => CNT_PRACH_CQ_FULL_SYMBOL9               ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL10  => CNT_PRACH_CQ_FULL_SYMBOL10              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL11  => CNT_PRACH_CQ_FULL_SYMBOL11              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL12  => CNT_PRACH_CQ_FULL_SYMBOL12              ,--: out std_logic_vector(31 downto 0);
        CNT_PRACH_CQ_FULL_SYMBOL13  => CNT_PRACH_CQ_FULL_SYMBOL13              ,--: out std_logic_vector(31 downto 0);

        USAGE_PRACH_CQ_SYMBOL0      => USAGE_PRACH_CQ_SYMBOL0                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL1      => USAGE_PRACH_CQ_SYMBOL1                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL2      => USAGE_PRACH_CQ_SYMBOL2                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL3      => USAGE_PRACH_CQ_SYMBOL3                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL4      => USAGE_PRACH_CQ_SYMBOL4                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL5      => USAGE_PRACH_CQ_SYMBOL5                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL6      => USAGE_PRACH_CQ_SYMBOL6                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL7      => USAGE_PRACH_CQ_SYMBOL7                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL8      => USAGE_PRACH_CQ_SYMBOL8                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL9      => USAGE_PRACH_CQ_SYMBOL9                  ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL10     => USAGE_PRACH_CQ_SYMBOL10                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL11     => USAGE_PRACH_CQ_SYMBOL11                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL12     => USAGE_PRACH_CQ_SYMBOL12                 ,--: out std_logic_vector(31 downto 0);
        USAGE_PRACH_CQ_SYMBOL13     => USAGE_PRACH_CQ_SYMBOL13                 ,--: out std_logic_vector(31 downto 0);

        C_PLANE_VALID               => C_PLANE_VALID                           ,--: in  std_logic;
        C_PLANE_LAST                => C_PLANE_LAST                            ,--: in  std_logic;
        C_PLANE_KEEP                => C_PLANE_KEEP                            ,--: in  std_logic_vector(3 downto 0);
        C_PLANE_DATA                => C_PLANE_DATA                            ,--: in  std_logic_vector(31 downto 0);
        C_PLANE_CH                  => C_PLANE_CH                              ,--: in  std_logic_vector(2 downto 0);
        C_PLANE_CH_SUB              => C_PLANE_CH_SUB                          ,--: in  std_logic_vector(3 downto 0);

        ULFE_UPDATE                 => puxch_update                            ,--: in  std_logic;

        ULFE_FRAME_ID               => ULFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        ULFE_SUBFRAME_ID            => ULFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        ULFE_SLOT_ID                => ULFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        ULFE_SYMBOL_ID              => ULFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);

        PUxCH_INIT                  => puxch_init                              ,--: out std_logic;
        PUxCH_PACKING_TICK          => puxch_packing_tick                      ,--: out std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              => puxch_rtcpc_id                          ,--: out std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        => puxch_data_direction                    ,--: out std_logic;
        PUxCH_PAYLOAD_VERSION       => puxch_payload_version                   ,--: out std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          => puxch_filter_index                      ,--: out std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              => puxch_frame_id                          ,--: out std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           => puxch_subframe_id                       ,--: out std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               => puxch_slot_id                           ,--: out std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             => puxch_symbol_id                         ,--: out std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          => puxch_section_tick                      ,--: out std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_SECTION_LAST          => puxch_section_last                      ,--: out std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_SECTION_DONE          => puxch_section_done                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            => puxch_section_id                        ,--: out std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         => puxch_use_every_prb                     ,--: out std_logic;
        PUxCH_START_OF_PRB          => puxch_start_of_prb                      ,--: out std_logic_vector(9 downto 0);
        PUxCH_OFFSET_OF_PRB         => open                                    ,--: std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         => puxch_number_of_prb                     ,--: out std_logic_vector(9 downto 0);
        PUxCH_UD_COMP_HDR           => puxch_ud_comp_hdr                       ,--: out std_logic_vector(7 downto 0);

        RAFE_UPDATE                 => prach_update                            ,--: in  std_logic;

        RAFE_FRAME_ID               => RAFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        RAFE_SUBFRAME_ID            => RAFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        RAFE_SLOT_ID                => RAFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        RAFE_SYMBOL_ID              => RAFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        RAFE_CHANNEL_ID             => prach_channel_id                        ,--: in  std_logic_vector(2 downto 0);

        PRACH_INIT                  => prach_init                              ,--: out std_logic;
        PRACH_PACKING_TICK          => prach_packing_tick                      ,--: out std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              => prach_rtcpc_id                          ,--: out std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        => prach_data_direction                    ,--: out std_logic;
        PRACH_PAYLOAD_VERSION       => prach_payload_version                   ,--: out std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          => prach_filter_index                      ,--: out std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              => prach_frame_id                          ,--: out std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           => prach_subframe_id                       ,--: out std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               => prach_slot_id                           ,--: out std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             => prach_symbol_id                         ,--: out std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          => prach_section_tick                      ,--: out std_logic_vector(MAX_CH-1 downto 0);
        PRACH_SECTION_LAST          => prach_section_last                      ,--: out std_logic_vector(MAX_CH-1 downto 0);
        PRACH_SECTION_DONE          => prach_section_done                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            => prach_section_id                        ,--: out std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         => prach_use_every_prb                     ,--: out std_logic;
        PRACH_START_OF_PRB          => prach_start_of_prb                      ,--: out std_logic_vector(9 downto 0);
        PRACH_OFFSET_OF_PRB         => prach_offset_of_prb                     ,--: std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         => prach_number_of_prb                     ,--: out std_logic_vector(9 downto 0);
        PRACH_UD_COMP_HDR           => prach_ud_comp_hdr                        --: out std_logic_vector(7 downto 0)
    );

    u_PARAMETER : UL_PARAM
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => reset                                   ,--: in  std_logic;

        EN_MULTI_SEQUENCE           => en_multi_sequence                       ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_INIT                  => puxch_init                              ,--: in  std_logic;
        PUxCH_PACKING_TICK          => puxch_packing_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              => puxch_rtcpc_id                          ,--: in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        => puxch_data_direction                    ,--: in  std_logic;
        PUxCH_PAYLOAD_VERSION       => puxch_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          => puxch_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              => puxch_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           => puxch_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               => puxch_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             => puxch_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          => puxch_section_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            => puxch_section_id                        ,--: in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         => puxch_use_every_prb                     ,--: in  std_logic;
        PUxCH_START_OF_PRB          => puxch_start_of_prb                      ,--: in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         => puxch_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               => PUxCH_RB_INIT                           ,--: out std_logic;
        PUxCH_RB_eAxC_ID            => PUxCH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        => PUxCH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         => PUxCH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PUxCH_RB_HEADER_SEC         => PUxCH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     => PUxCH_RB_HEADER_SEC_ACK                 ,--: in  std_logic;

        PRACH_INIT                  => prach_init                              ,--: in  std_logic;
        PRACH_PACKING_TICK          => prach_packing_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              => prach_rtcpc_id                          ,--: in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        => prach_data_direction                    ,--: in  std_logic;
        PRACH_PAYLOAD_VERSION       => prach_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          => prach_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              => prach_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           => prach_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               => prach_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             => prach_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          => prach_section_tick                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            => prach_section_id                        ,--: in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         => prach_use_every_prb                     ,--: in  std_logic;
        PRACH_START_OF_PRB          => prach_start_of_prb                      ,--: in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         => prach_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               => PRACH_RB_INIT                           ,--: out std_logic;
        PRACH_RB_eAxC_ID            => PRACH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        => PRACH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         => PRACH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PRACH_RB_HEADER_SEC         => PRACH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     => PRACH_RB_HEADER_SEC_ACK                  --: in  std_logic
    );

    u_PATH : for i in MAX_CH-1 downto 0 generate
    u_TX_WINDOW_PUxCH : UL_TX_WINDOW
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => puxch_init                              ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => puxch_packing_tick(i)                   ,--: in  std_logic;

        DATA_DIRECTION              => puxch_data_direction                    ,--: in  std_logic;
        PAYLOAD_VERSION             => puxch_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => puxch_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => puxch_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => puxch_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => puxch_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => puxch_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => puxch_section_tick(i)                   ,--: in  std_logic;
        SECTION_LAST                => puxch_section_last(i)                   ,--: in  std_logic;
        SECTION_DONE                => puxch_section_done(i)                   ,--: out std_logic;

        SECTION_ID                  => puxch_section_id                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => puxch_use_every_prb                     ,--: in  std_logic;
        START_OF_PRB                => puxch_start_of_prb                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => puxch_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => puxch_ud_comp_hdr                       ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => ULFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => ULFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => ULFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => ULFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => ULFE_START_RE                           ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => ULFE_VALID(i)                           ,--: in  std_logic;
        UL_START                    => ULFE_START(i)                           ,--: in  std_logic;
        UL_LAST                     => ULFE_LAST(i)                            ,--: in  std_logic;
        UL_DATA_I                   => ULFE_DATA_I(i)                          ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => ULFE_DATA_Q(i)                          ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => puxch_comp_hdr(i)                       ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => puxch_valid(i)                          ,--: out std_logic;
        RB_TICK                     => puxch_tick(i)                           ,--: out std_logic;
        RB_DATA_I                   => puxch_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => puxch_data_q(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => puxch_user(i)                            --: out std_logic_vector(15 downto 0)
    );

    u_TX_WINDOW_PRACH : UL_TX_WINDOW_RACH
    generic map(
        LONG_PRACH                  => LONG_PRACH                               --: boolean := true
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => prach_init                              ,--: in  std_logic;

        CNT_PACKET_SYMBOL0          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL1          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL2          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL3          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL4          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL5          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL6          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL7          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL8          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL9          => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL10         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL11         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL12         => open                                    ,--: out std_logic_vector(31 downto 0);
        CNT_PACKET_SYMBOL13         => open                                    ,--: out std_logic_vector(31 downto 0);

        PACKING_TICK                => prach_packing_tick(i)                   ,--: in  std_logic;

        DATA_DIRECTION              => prach_data_direction                    ,--: in  std_logic;
        PAYLOAD_VERSION             => prach_payload_version                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => prach_filter_index                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => prach_frame_id                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => prach_subframe_id                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => prach_slot_id                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => prach_symbol_id                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => prach_section_tick(i)                   ,--: in  std_logic;
        SECTION_LAST                => prach_section_last(i)                   ,--: in  std_logic;
        SECTION_DONE                => prach_section_done(i)                   ,--: out std_logic;

        SECTION_ID                  => prach_section_id                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => prach_use_every_prb                     ,--: in  std_logic;
        START_OF_PRB                => prach_offset_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => prach_number_of_prb                     ,--: in  std_logic_vector(9 downto 0);
        UD_COMP_HDR                 => prach_ud_comp_hdr                       ,--: in  std_logic_vector(7 downto 0);

        UL_FRAME_ID                 => RAFE_FRAME_ID                           ,--: in  std_logic_vector(7 downto 0);
        UL_SUBFRAME_ID              => RAFE_SUBFRAME_ID                        ,--: in  std_logic_vector(3 downto 0);
        UL_SLOT_ID                  => RAFE_SLOT_ID                            ,--: in  std_logic_vector(5 downto 0);
        UL_SYMBOL_ID                => RAFE_SYMBOL_ID                          ,--: in  std_logic_vector(5 downto 0);
        UL_START_RE                 => RAFE_START_RE                           ,--: in  std_logic_vector(15 downto 0);

        UL_VALID                    => RAFE_VALID(i)                           ,--: in  std_logic;
        UL_START                    => RAFE_START(i)                           ,--: in  std_logic;
        UL_LAST                     => RAFE_LAST(i)                            ,--: in  std_logic;
        UL_DATA_I                   => RAFE_DATA_I(i)                          ,--: in  std_logic_vector(15 downto 0);
        UL_DATA_Q                   => RAFE_DATA_Q(i)                          ,--: in  std_logic_vector(15 downto 0);

        RB_COMP_HDR                 => prach_comp_hdr(i)                       ,--: out std_logic_vector(7 downto 0);

        RB_VALID                    => prach_valid(i)                          ,--: out std_logic;
        RB_TICK                     => prach_tick(i)                           ,--: out std_logic;
        RB_DATA_I                   => prach_data_i(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_DATA_Q                   => prach_data_q(i)                         ,--: out std_logic_vector(15 downto 0);
        RB_USER                     => prach_user(i)                            --: out std_logic_vector(15 downto 0)
    );
    end generate;

    u_PATH_UNUSED : if MAX_CH /= 8 generate
    u_PATH : for i in 7 downto MAX_CH generate
    puxch_comp_hdr(i)               <= (others => '0');
    puxch_valid(i)                  <= '0';
    puxch_tick(i)                   <= '0';
    puxch_data_i(i)                 <= (others => '0');
    puxch_data_q(i)                 <= (others => '0');
    puxch_user(i)                   <= (others => '0');
    prach_comp_hdr(i)               <= (others => '0');
    prach_valid(i)                  <= '0';
    prach_tick(i)                   <= '0';
    prach_data_i(i)                 <= (others => '0');
    prach_data_q(i)                 <= (others => '0');
    prach_user(i)                   <= (others => '0');
    end generate;
    end generate;

end BEHAVE;