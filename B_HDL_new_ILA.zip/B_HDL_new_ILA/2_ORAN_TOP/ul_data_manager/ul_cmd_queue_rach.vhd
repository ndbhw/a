--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL Scheduler (O-RAN component)                                --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.ARRAY_TYPE.ALL;

entity UL_CMD_QUEUE_RACH is
    generic (
        MAX_CH                      : natural := 8;
        LINK_DIRECTION              : std_logic := '0';                         -- '0' : Uplink, '1' : Downlink
        CMD_QUEUE_MEMORY_TYPE       : string := "auto";                         -- Allowed values: auto, block, distributed. Default value = auto.
        CMD_QUEUE_DEPTH             : integer := 2048
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Debug
--------------------------------------------------------------------------------

        IGNORE_FRAME_ID             : in  std_logic;
        IGNORE_FRAME_ID_RX          : out std_logic_vector(7 downto 0);
        IGNORE_FRAME_ID_TX          : out std_logic_vector(7 downto 0);

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        ID                          : in  std_logic_array16(MAX_CH-1 downto 0);

        PRB_PER_SYMBOL              : in  std_logic_vector(9 downto 0);
        PRB_PER_MTU                 : in  std_logic_vector(9 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        CNT_ABNORMAL_TERMINATION    : out std_logic_vector(31 downto 0);

        CNT_SECTION_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_SECTION_SYMBOL13        : out std_logic_vector(31 downto 0);

        CNT_CQ_FULL_SYMBOL0         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL1         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL2         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL3         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL4         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL5         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL6         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL7         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL8         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL9         : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL10        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL11        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL12        : out std_logic_vector(31 downto 0);
        CNT_CQ_FULL_SYMBOL13        : out std_logic_vector(31 downto 0);

        USAGE_CQ_SYMBOL0            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL1            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL2            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL3            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL4            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL5            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL6            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL7            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL8            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL9            : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL10           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL11           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL12           : out std_logic_vector(31 downto 0);
        USAGE_CQ_SYMBOL13           : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- Scheduler timer
--------------------------------------------------------------------------------

        INFO_UPDATE                 : in  std_logic;

        INFO_FRAME_ID               : in  std_logic_vector(7 downto 0);
        INFO_SUBFRAME_ID            : in  std_logic_vector(3 downto 0);
        INFO_SLOT_ID                : in  std_logic_vector(5 downto 0);
        INFO_SYMBOL_ID              : in  std_logic_vector(5 downto 0);
        INFO_CHANNEL_ID             : in  std_logic_vector(2 downto 0);

--------------------------------------------------------------------------------
-- Command bus
--------------------------------------------------------------------------------

        CMD_EN                      : in  std_logic_vector(MAX_CH-1 downto 0);
        CMD_IN                      : in  std_logic_array72(MAX_CH-1 downto 0);
        CMD_STOP                    : out std_logic_vector(MAX_CH-1 downto 0);

--------------------------------------------------------------------------------
-- PRB Packer
--------------------------------------------------------------------------------

        INIT_SESSION                : out std_logic;

        PACKING_TICK                : out std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    : out std_logic_vector(15 downto 0);

        DATA_DIRECTION              : out std_logic;
        PAYLOAD_VERSION             : out std_logic_vector(2 downto 0);
        FILTER_INDEX                : out std_logic_vector(3 downto 0);
        FRAME_ID                    : out std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : out std_logic_vector(3 downto 0);
        SLOT_ID                     : out std_logic_vector(5 downto 0);
        SYMBOL_ID                   : out std_logic_vector(5 downto 0);

        SECTION_TICK                : out std_logic_vector(MAX_CH-1 downto 0);
        SECTION_LAST                : out std_logic_vector(MAX_CH-1 downto 0);
        SECTION_DONE                : in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  : out std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : out std_logic;
        START_OF_PRB                : out std_logic_vector(9 downto 0);
        OFFSET_OF_PRB               : out std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : out std_logic_vector(9 downto 0);
        UD_COMP_HDR                 : out std_logic_vector(7 downto 0)
    );
end UL_CMD_QUEUE_RACH;

architecture BEHAVE of UL_CMD_QUEUE_RACH is

    component CQ_UL_SYMBOL is
    generic (
        MEMORY_TYPE                 : string := "auto";                         -- Allowed values: auto, block, distributed. Default value = auto.
        WRITE_DEPTH                 : integer := 2048
    );
    port (
        CLK                         : in  std_logic;
        SRST                        : in  std_logic;
        DIN                         : in  std_logic_vector(71 downto 0);
        WR_EN                       : in  std_logic;
        RD_EN                       : in  std_logic;
        DOUT                        : out std_logic_vector(71 downto 0);
        FULL                        : out std_logic;
        EMPTY                       : out std_logic;
        DATA_COUNT                  : out std_logic_vector(31 downto 0);
        WR_RST_BUSY                 : out std_logic;
        RD_RST_BUSY                 : out std_logic
    );
    end component;

    constant LATENCY_FIFO           : natural := 1+1;                           -- FIFO + User

    signal din                      : std_logic_array72(MAX_CH-1 downto 0) := (others => (others => '0'));
    signal wr_en                    : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal rd_en                    : std_logic_vector(MAX_CH-1 downto 0);
    signal dout_buf                 : std_logic_array72(MAX_CH-1 downto 0);
    signal dout                     : std_logic_vector(71 downto 0) := (others => '0');
    signal full                     : std_logic_vector(MAX_CH-1 downto 0);
    signal empty                    : std_logic_vector(MAX_CH-1 downto 0);
    signal data_count               : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal wr_rst_busy              : std_logic_vector(MAX_CH-1 downto 0);
    signal wr_stop                  : std_logic_vector(MAX_CH-1 downto 0);

    signal slot_lost                : std_logic_array2(MAX_CH-1 downto 0) := (others => (others => '1'));
    signal ref_frame_id             : std_logic_vector(7 downto 0) := (others => '0');
    signal ref_frame_id_sh          : std_logic_vector(7 downto 0) := (others => '0');
    signal ref_subframe_id          : std_logic_vector(3 downto 0) := (others => '0');
    signal ref_subframe_id_sh       : std_logic_vector(3 downto 0) := (others => '0');
    signal ref_slot_id              : std_logic_vector(5 downto 0) := (others => '0');
    signal ref_slot_id_sh           : std_logic_vector(5 downto 0) := (others => '0');
    signal ref_symbol_id            : std_logic_vector(5 downto 0) := (others => '0');
    signal ref_symbol_id_sh         : std_logic_vector(5 downto 0) := (others => '0');
    signal ref_channel_id           : std_logic_vector(2 downto 0) := (others => '0');
    signal channel_index            : std_logic_vector(7 downto 0):= (others => '0');

--    signal cmd_channel_id           : std_logic_vector(2 downto 0) := (others => '0');
    signal cmd_filter_index         : std_logic_vector(3 downto 0) := (others => '0');
    signal cmd_frame_id             : std_logic_vector(7 downto 0) := (others => '0');
    signal cmd_subframe_id          : std_logic_vector(3 downto 0) := (others => '0');
    signal cmd_slot_id              : std_logic_vector(5 downto 0) := (others => '0');
    signal cmd_ud_comp_hdr          : std_logic_vector(7 downto 0) := (others => '0');
    signal cmd_section_id           : std_logic_vector(11 downto 0) := (others => '0');
    signal cmd_use_every_prb        : std_logic := '0';
--    signal cmd_start_prb            : std_logic_vector(9 downto 0) := (others => '0');
--    signal cmd_num_prb              : std_logic_vector(7 downto 0) := (others => '0');

    component NUM_TO_BIT is
    generic (
        MAX_NUM                     : natural := 8
    );
    port (
        NUM                         : in  std_logic_vector(2 downto 0);
        BIT                         : out std_logic_vector(7 downto 0)
    );
    end component;

    signal cmd_channel              : std_logic_vector(7 downto 0);

    signal ontime_cmd               : std_logic_vector(1 downto 0) := (others => '0');

    type fsm_section                is (IDLE, LOAD, SPLIT, PACK, SECTION, WAITING);
    signal fsm_cmd                  : fsm_section;
    signal cnt_cmd_state            : std_logic_vector(3 downto 0);

    signal max_prb                  : std_logic_vector(9 downto 0);
    signal prb_start                : std_logic_vector(9 downto 0);
    signal prb_offset               : std_logic_vector(9 downto 0);
    signal prb_num                  : std_logic_vector(9 downto 0);
    signal prb_end                  : std_logic_vector(9 downto 0);
    signal split_section            : std_logic := '0';
    signal more_section             : std_logic := '0';

    component USAGE_TO_GAUGE is
    generic (
        MAX_USAGE                   : natural := 1024
    );
    port (
        CLK                         : in  std_logic;

        USAGE                       : in  std_logic_vector(31 downto 0);
        GAUGE                       : out std_logic_vector(31 downto 0)
    );
    end component;

    signal cnt_termination          : std_logic_vector(15 downto 0) := (others => '0');
    signal cnt_section              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    signal cnt_cq_full              : std_logic_array16(7 downto 0) := (others => (others => '0'));
    
--    attribute MARK_DEBUG : string;
                 
    
    
--    attribute MARK_DEBUG of slot_lost               : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_frame_id            : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_frame_id_sh         : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_subframe_id         : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_subframe_id_sh      : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_slot_id             : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_slot_id_sh          : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_symbol_id           : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_symbol_id_sh        : signal is "TRUE";     
--    attribute MARK_DEBUG of ref_channel_id          : signal is "TRUE";     
--    attribute MARK_DEBUG of channel_index           : signal is "TRUE";     
    
--    attribute MARK_DEBUG of cmd_filter_index        : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_frame_id            : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_subframe_id         : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_slot_id             : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_ud_comp_hdr         : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_section_id          : signal is "TRUE";     
--    attribute MARK_DEBUG of cmd_use_every_prb       : signal is "TRUE";  
    

begin

--------------------------------------------------------------------------------
-- Command Queue
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (INFO_UPDATE = '1') then
                ref_frame_id    <= INFO_FRAME_ID;
                ref_subframe_id <= INFO_SUBFRAME_ID;
                ref_slot_id     <= INFO_SLOT_ID;
                ref_symbol_id   <= INFO_SYMBOL_ID;
                ref_channel_id  <= INFO_CHANNEL_ID;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ref_frame_id_sh    <= ref_frame_id;
            ref_subframe_id_sh <= ref_subframe_id;
            ref_slot_id_sh     <= ref_slot_id;
            ref_symbol_id_sh   <= ref_symbol_id;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (ref_channel_id = 0) then         channel_index <= "00000001";
            elsif (ref_channel_id = 1) then         channel_index <= "00000010";
            elsif (ref_channel_id = 2) then         channel_index <= "00000100";
            elsif (ref_channel_id = 3) then         channel_index <= "00001000";
            elsif (ref_channel_id = 4) then         channel_index <= "00010000";
            elsif (ref_channel_id = 5) then         channel_index <= "00100000";
            elsif (ref_channel_id = 6) then         channel_index <= "01000000";
            elsif (ref_channel_id = 7) then         channel_index <= "10000000";
            else                                    channel_index <= "00000000";
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            din   <= CMD_IN;
            wr_en <= CMD_EN and (not wr_rst_busy);
        end if;
    end process;

    u_CQ_ANTENNA : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (wr_stop(i) = '1') then
                slot_lost(i) <= slot_lost(i)(0) & '1';
            else
                slot_lost(i) <= slot_lost(i)(0) & '0';
            end if;
        end if;
    end process;

    u_CQ : CQ_UL_SYMBOL
    generic map(
        MEMORY_TYPE                 => CMD_QUEUE_MEMORY_TYPE                   ,--: string := "auto";
        WRITE_DEPTH                 => CMD_QUEUE_DEPTH                          --: integer := 2048
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        SRST                        => slot_lost(i)(0)                         ,--: in  std_logic;
        DIN                         => din(i)                                  ,--: in  std_logic_vector(71 downto 0);
        WR_EN                       => wr_en(i)                                ,--: in  std_logic;
        RD_EN                       => rd_en(i)                                ,--: in  std_logic;
        DOUT                        => dout_buf(i)                             ,--: out std_logic_vector(71 downto 0);
        FULL                        => full(i)                                 ,--: out std_logic;
        EMPTY                       => empty(i)                                ,--: out std_logic;
        DATA_COUNT                  => data_count(i)                           ,--: out std_logic_vector(31 downto 0);
        WR_RST_BUSY                 => wr_rst_busy(i)                          ,--: out std_logic;
        RD_RST_BUSY                 => open                                     --: out std_logic
    );

    CMD_STOP(i) <= wr_stop(i);

    process (RST, CLK)
    begin
        if (RST = '1') then
            wr_stop(i) <= '1';
        elsif (CLK'event and CLK = '1') then
            if (wr_en(i) = '1') and (full(i) = '1') then
                wr_stop(i) <= '1';
            elsif (empty(i) = '1') then
                wr_stop(i) <= '0';
            end if;
        end if;
    end process;
    end generate;

    u_MAX_CH_2 : if MAX_CH = 2 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (ref_channel_id = 0) and (empty(0) = '0') then
                dout <= dout_buf(0);
            elsif (ref_channel_id = 1) and (empty(1) = '0') then
                dout <= dout_buf(1);
            else
                dout <= (others => '1');
            end if;
        end if;
    end process;
    end generate;

    u_MAX_CH_4 : if MAX_CH = 4 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (ref_channel_id = 0) and (empty(0) = '0') then
                dout <= dout_buf(0);
            elsif (ref_channel_id = 1) and (empty(1) = '0') then
                dout <= dout_buf(1);
            elsif (ref_channel_id = 2) and (empty(2) = '0') then
                dout <= dout_buf(2);
            elsif (ref_channel_id = 3) and (empty(3) = '0') then
                dout <= dout_buf(3);
            else
                dout <= (others => '1');
            end if;
        end if;
    end process;
    end generate;

    u_MAX_CH_8 : if MAX_CH = 8 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (ref_channel_id = 0) and (empty(0) = '0') then
                dout <= dout_buf(0);
            elsif (ref_channel_id = 1) and (empty(1) = '0') then
                dout <= dout_buf(1);
            elsif (ref_channel_id = 2) and (empty(2) = '0') then
                dout <= dout_buf(2);
            elsif (ref_channel_id = 3) and (empty(3) = '0') then
                dout <= dout_buf(3);
            elsif (ref_channel_id = 4) and (empty(4) = '0') then
                dout <= dout_buf(4);
            elsif (ref_channel_id = 5) and (empty(5) = '0') then
                dout <= dout_buf(5);
            elsif (ref_channel_id = 6) and (empty(6) = '0') then
                dout <= dout_buf(6);
            elsif (ref_channel_id = 7) and (empty(7) = '0') then
                dout <= dout_buf(7);
            else
                dout <= (others => '1');
            end if;
        end if;
    end process;
    end generate;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (rd_en /= 0) then
--                cmd_channel_id         <= dout(02 downto 00);
                cmd_filter_index       <= dout(06 downto 03);
                cmd_frame_id           <= dout(14 downto 07);
                cmd_subframe_id        <= dout(18 downto 15);
                cmd_slot_id            <= dout(24 downto 19);
                cmd_ud_comp_hdr        <= dout(38 downto 31);
                cmd_section_id         <= dout(50 downto 39);
                cmd_use_every_prb      <= not dout(51);
--                cmd_start_prb          <= dout(61 downto 52);
--                cmd_num_prb            <= dout(69 downto 62);
            end if;
        end if;
    end process;

    u_CONV_CHANNEL_ID : NUM_TO_BIT
    generic map(
        MAX_NUM                     => MAX_CH                                   --: natural := 8
    )
    port map(
        NUM                         => ref_channel_id                          ,--: in  std_logic_vector(2 downto 0);
        BIT                         => cmd_channel                              --: out std_logic_vector(7 downto 0)
    );

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (IGNORE_FRAME_ID = '1') then
                if (dout(18 downto 15) = ref_subframe_id_sh) and (dout(24 downto 19) = ref_slot_id_sh) and (dout(30 downto 25) = ref_symbol_id_sh) then
                    ontime_cmd(0) <= '1';
                else
                    ontime_cmd(0) <= '0';
                end if;
            else
                if (dout(14 downto 7) = ref_frame_id_sh) and (dout(18 downto 15) = ref_subframe_id_sh) and (dout(24 downto 19) = ref_slot_id_sh) and (dout(30 downto 25) = ref_symbol_id_sh) then
                    ontime_cmd(0) <= '1';
                else
                    ontime_cmd(0) <= '0';
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ontime_cmd(1) <= ontime_cmd(0);
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (dout(18 downto 15) = ref_subframe_id_sh) and (dout(24 downto 19) = ref_slot_id_sh) then
                IGNORE_FRAME_ID_RX <= ref_frame_id;
                IGNORE_FRAME_ID_TX <= dout(14 downto 7);
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Split command to maximum MTU size
--------------------------------------------------------------------------------

    -- FSM
    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_cmd <= IDLE;
        elsif (CLK'event and CLK = '1') then
            if (ontime_cmd = "01") then
                fsm_cmd <= IDLE;
            else
                case fsm_cmd is
                when IDLE    =>
                    if (ontime_cmd(0) = '1') then
                        fsm_cmd <= LOAD;
                    else
                        fsm_cmd <= IDLE;
                    end if;
                when LOAD    =>
                    fsm_cmd <= SPLIT;
                when SPLIT   =>
                    if (cnt_cmd_state = LATENCY_FIFO-1) then
                        fsm_cmd <= PACK;
                    else
                        fsm_cmd <= SPLIT;
                    end if;
                when PACK    =>
                    fsm_cmd <= SECTION;
                when SECTION =>
                    fsm_cmd <= WAITING;
                when WAITING =>
                    if (SECTION_DONE /= 0) then
                        if (split_section = '1') then
                            fsm_cmd <= SPLIT;
                        elsif (more_section = '1') then
                            if (ontime_cmd(0) = '0') then
                                fsm_cmd <= IDLE;
                            else
                                fsm_cmd <= LOAD;
                            end if;
                        else
                            fsm_cmd <= IDLE;
                        end if;
                    else
                        fsm_cmd <= WAITING;
                    end if;
                when others  =>
                    fsm_cmd <= IDLE;
                end case;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when SPLIT   =>
                if (cnt_cmd_state = LATENCY_FIFO-1) then
                    cnt_cmd_state <= (others => '0');
                else
                    cnt_cmd_state <= cnt_cmd_state + 1;
                end if;
            when others  =>
                cnt_cmd_state <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when LOAD    =>
                rd_en <= channel_index(MAX_CH-1 downto 0);
            when others  =>
                rd_en <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ontime_cmd = "01") then
                INIT_SESSION <= '1';
            else
                INIT_SESSION <= '0';
            end if;
        end if;
    end process;

    -- 1 MTU interrupt
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when PACK    =>
                if (more_section = '1') then
                    PACKING_TICK    <= (others => '0');
                else
                    PACKING_TICK    <= cmd_channel(MAX_CH-1 downto 0);
                end if;
            when others  =>
                PACKING_TICK    <= (others => '0');
            end case;
        end if;
    end process;

    u_RTCPC_ID_1_PORT : if MAX_CH = 1 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            RTCPC_ID        <= ID(0);
        end if;
    end process;
    end generate;

    u_RTCPC_ID_2_PORTS : if MAX_CH = 2 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (cmd_channel(0) = '1') then
                RTCPC_ID        <= ID(0);
            elsif (cmd_channel(1) = '1') then
                RTCPC_ID        <= ID(1);
            else
                RTCPC_ID        <= (others => '0');
            end if;
        end if;
    end process;
    end generate;

    u_RTCPC_ID_4_PORTS : if MAX_CH = 4 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (cmd_channel(0) = '1') then
                RTCPC_ID        <= ID(0);
            elsif (cmd_channel(1) = '1') then
                RTCPC_ID        <= ID(1);
            elsif (cmd_channel(2) = '1') then
                RTCPC_ID        <= ID(2);
            elsif (cmd_channel(3) = '1') then
                RTCPC_ID        <= ID(3);
            else
                RTCPC_ID        <= (others => '0');
            end if;
        end if;
    end process;
    end generate;

    u_RTCPC_ID_8_PORTS : if MAX_CH = 8 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (cmd_channel(0) = '1') then
                RTCPC_ID        <= ID(0);
            elsif (cmd_channel(1) = '1') then
                RTCPC_ID        <= ID(1);
            elsif (cmd_channel(2) = '1') then
                RTCPC_ID        <= ID(2);
            elsif (cmd_channel(3) = '1') then
                RTCPC_ID        <= ID(3);
            elsif (cmd_channel(4) = '1') then
                RTCPC_ID        <= ID(4);
            elsif (cmd_channel(5) = '1') then
                RTCPC_ID        <= ID(5);
            elsif (cmd_channel(6) = '1') then
                RTCPC_ID        <= ID(6);
            elsif (cmd_channel(7) = '1') then
                RTCPC_ID        <= ID(7);
            else
                RTCPC_ID        <= (others => '0');
            end if;
        end if;
    end process;
    end generate;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            DATA_DIRECTION  <= LINK_DIRECTION;
            PAYLOAD_VERSION <= "001";
            FILTER_INDEX    <= cmd_filter_index;
            FRAME_ID        <= cmd_frame_id;
            SUBFRAME_ID     <= cmd_subframe_id;
            SLOT_ID         <= cmd_slot_id;
            SYMBOL_ID       <= ref_symbol_id;
        end if;
    end process;

    -- Split 1-section to maximum PRBs
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when IDLE    =>
                max_prb <= PRB_PER_MTU;
            when PACK    =>
                max_prb <= max_prb - prb_num;
            when SECTION =>
                if (max_prb = 0) then
                    max_prb <= PRB_PER_MTU;
                end if;
            when others  =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when IDLE    =>
                prb_num   <= (others => '0');
            when SPLIT   =>
                if (prb_end >= max_prb) then
                    prb_num   <= max_prb;
                else
                    prb_num   <= prb_end;
                end if;
            when others  =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when IDLE    =>
                prb_start <= (others => '0');
                prb_offset <= (others => '0');
                prb_end   <= (others => '0');
            when LOAD    =>
                if (dout(69 downto 62) = 0) then
                    prb_start <= (others => '0');
                    prb_offset <= (others => '0');
                    prb_end   <= PRB_PER_SYMBOL;
                else
                    prb_start <= dout(61 downto 52);
                    prb_offset <= (others => '0');
                    prb_end   <= "00" & dout(69 downto 62);
                end if;
            when SECTION =>
--                prb_start <= prb_start + prb_num;
--                prb_offset <= prb_offset + prb_num;

                if (cmd_use_every_prb = '1') then
                    prb_start  <= prb_start + prb_num;
                    prb_offset <= prb_offset + prb_num;
                else
                    prb_start  <= prb_start + (prb_num(8 downto 0) & '0');
                    prb_offset <= prb_offset + (prb_num(8 downto 0) & '0');
                end if;
                
                prb_end   <= prb_end - prb_num;
            when others  =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when IDLE    =>
                split_section <= '0';
            when LOAD    =>
                split_section <= '0';
            when SPLIT   =>
                if (prb_end > max_prb) then
                    split_section <= '1';
                else
                    split_section <= '0';
                end if;
            when others  =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when IDLE    =>
                more_section <= '0';
            when SECTION =>
                if (max_prb = 0) then
                    more_section <= '0';
                else
                    more_section <= '1';
                end if;
            when others  =>
                NULL;
            end case;
        end if;
    end process;

    -- 1 section interrupt
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_cmd is
            when SECTION =>
                SECTION_TICK  <= cmd_channel(MAX_CH-1 downto 0);
                if (max_prb = 0) or (ontime_cmd(0) = '0') then
                    SECTION_LAST  <= cmd_channel(MAX_CH-1 downto 0);
                end if;
                SECTION_ID    <= cmd_section_id;
                USE_EVERY_PRB <= cmd_use_every_prb;
                START_OF_PRB  <= prb_start;
                OFFSET_OF_PRB <= prb_offset;
                NUMBER_OF_PRB <= prb_num;
                UD_COMP_HDR   <= cmd_ud_comp_hdr;
            when others  =>
                SECTION_TICK  <= (others => '0');
                SECTION_LAST  <= (others => '0');
                SECTION_ID    <= (others => '0');
                START_OF_PRB  <= (others => '0');
                NUMBER_OF_PRB <= (others => '0');
                OFFSET_OF_PRB <= (others => '0');
                UD_COMP_HDR   <= (others => '0');
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

    CNT_ABNORMAL_TERMINATION        <= x"0000" & cnt_termination;

    CNT_SECTION_SYMBOL0             <= x"0000" & cnt_section(0);
    CNT_SECTION_SYMBOL1             <= x"0000" & cnt_section(1);
    CNT_SECTION_SYMBOL2             <= x"0000" & cnt_section(2);
    CNT_SECTION_SYMBOL3             <= x"0000" & cnt_section(3);
    CNT_SECTION_SYMBOL4             <= x"0000" & cnt_section(4);
    CNT_SECTION_SYMBOL5             <= x"0000" & cnt_section(5);
    CNT_SECTION_SYMBOL6             <= x"0000" & cnt_section(6);
    CNT_SECTION_SYMBOL7             <= x"0000" & cnt_section(7);
    CNT_SECTION_SYMBOL8             <= (others => '0'); -- x"0000" & cnt_section(8);
    CNT_SECTION_SYMBOL9             <= (others => '0'); -- x"0000" & cnt_section(9);
    CNT_SECTION_SYMBOL10            <= (others => '0'); -- x"0000" & cnt_section(10);
    CNT_SECTION_SYMBOL11            <= (others => '0'); -- x"0000" & cnt_section(11);
    CNT_SECTION_SYMBOL12            <= (others => '0'); -- x"0000" & cnt_section(12);
    CNT_SECTION_SYMBOL13            <= (others => '0'); -- x"0000" & cnt_section(13);

    CNT_CQ_FULL_SYMBOL0             <= x"0000" & cnt_cq_full(0);
    CNT_CQ_FULL_SYMBOL1             <= x"0000" & cnt_cq_full(1);
    CNT_CQ_FULL_SYMBOL2             <= x"0000" & cnt_cq_full(2);
    CNT_CQ_FULL_SYMBOL3             <= x"0000" & cnt_cq_full(3);
    CNT_CQ_FULL_SYMBOL4             <= x"0000" & cnt_cq_full(4);
    CNT_CQ_FULL_SYMBOL5             <= x"0000" & cnt_cq_full(5);
    CNT_CQ_FULL_SYMBOL6             <= x"0000" & cnt_cq_full(6);
    CNT_CQ_FULL_SYMBOL7             <= x"0000" & cnt_cq_full(7);
    CNT_CQ_FULL_SYMBOL8             <= (others => '0'); -- x"0000" & cnt_cq_full(8);
    CNT_CQ_FULL_SYMBOL9             <= (others => '0'); -- x"0000" & cnt_cq_full(9);
    CNT_CQ_FULL_SYMBOL10            <= (others => '0'); -- x"0000" & cnt_cq_full(10);
    CNT_CQ_FULL_SYMBOL11            <= (others => '0'); -- x"0000" & cnt_cq_full(11);
    CNT_CQ_FULL_SYMBOL12            <= (others => '0'); -- x"0000" & cnt_cq_full(12);
    CNT_CQ_FULL_SYMBOL13            <= (others => '0'); -- x"0000" & cnt_cq_full(13);

    -- Abnormal termination
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (ontime_cmd = "01") then
                if (fsm_cmd = IDLE) then
                    cnt_termination <= cnt_termination;
                else
                    cnt_termination <= cnt_termination + 1;
                end if;
            end if;
        end if;
    end process;

    -- Normal operation
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            for i in MAX_CH-1 downto 0 loop
            if (CMD_EN(i) = '1') then
                cnt_section(i) <= cnt_section(i) + 1;
            end if;
            end loop;
        end if;
    end process;

    -- Command queue full
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            for i in MAX_CH-1 downto 0 loop
            if (slot_lost(i) = "01") then
                cnt_cq_full(i) <= cnt_cq_full(i) + 1;
            end if;
            end loop;
        end if;
    end process;

    u_FIFO_STATUS0  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(0),  USAGE_CQ_SYMBOL0);
    u_FIFO_STATUS1  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(1),  USAGE_CQ_SYMBOL1);
    u_FIFO_STATUS2  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(2),  USAGE_CQ_SYMBOL2);
    u_FIFO_STATUS3  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(3),  USAGE_CQ_SYMBOL3);
    u_FIFO_STATUS4  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(4),  USAGE_CQ_SYMBOL4);
    u_FIFO_STATUS5  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(5),  USAGE_CQ_SYMBOL5);
    u_FIFO_STATUS6  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(6),  USAGE_CQ_SYMBOL6);
    u_FIFO_STATUS7  : USAGE_TO_GAUGE generic map(CMD_QUEUE_DEPTH) port map(CLK, data_count(7),  USAGE_CQ_SYMBOL7);
    USAGE_CQ_SYMBOL8  <= (others => '0');
    USAGE_CQ_SYMBOL9  <= (others => '0');
    USAGE_CQ_SYMBOL10 <= (others => '0'); 
    USAGE_CQ_SYMBOL11 <= (others => '0'); 
    USAGE_CQ_SYMBOL12 <= (others => '0'); 
    USAGE_CQ_SYMBOL13 <= (others => '0'); 

end BEHAVE;