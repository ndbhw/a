--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL ecpriSeqid generation (O-RAN component)                    --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity UL_SEQ_ID is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST_PUxCH                   : in  std_logic;
        RST_PRACH                   : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        EN_MULTI_SEQUENCE           : in  std_logic_vector(MAX_CH-1 downto 0);

--------------------------------------------------------------------------------
-- PUxCH
--------------------------------------------------------------------------------

        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      : in  std_logic;
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- PRACH
--------------------------------------------------------------------------------

        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      : in  std_logic;
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0)
    );
end UL_SEQ_ID;

architecture BEHAVE of UL_SEQ_ID is

    type std_logic_array8           is array(natural range <>) of std_logic_vector(7 downto 0);

    signal puxch_tick               : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal puxch_tick_sh            : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal prach_tick               : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');
    signal prach_tick_sh            : std_logic_vector(MAX_CH-1 downto 0) := (others => '0');

    signal cnt_puxch                : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal puxch_id                 : std_logic_vector(7 downto 0) := (others => '0');

    signal cnt_prach                : std_logic_array8(7 downto 0) := (others => (others => '0'));
    signal prach_id                 : std_logic_vector(7 downto 0) := (others => '0');

    constant HDR_BUF                : natural := 2;
    signal puxch_id_buf             : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_puxch_wr           : natural range 0 to HDR_BUF;
    signal index_puxch_rd           : natural range 0 to HDR_BUF;
    signal prach_id_buf             : std_logic_array8(HDR_BUF-1 downto 0) := (others => (others => '0'));
    signal index_prach_wr           : natural range 0 to HDR_BUF;
    signal index_prach_rd           : natural range 0 to HDR_BUF;

begin

    PUxCH_RB_SEQUENCE_ID <= puxch_id_buf(index_puxch_rd) & x"80";
    PRACH_RB_SEQUENCE_ID <= prach_id_buf(index_prach_rd) & x"80";

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            puxch_tick(MAX_CH-1 downto 0) <= PUxCH_PACKING_TICK;
            prach_tick(MAX_CH-1 downto 0) <= PRACH_PACKING_TICK;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            puxch_tick_sh <= puxch_tick;
            prach_tick_sh <= prach_tick;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (puxch_tick_sh /= 0) then
                puxch_id_buf <= puxch_id_buf(HDR_BUF-2 downto 0) & puxch_id;
            end if;
        end if;
    end process;

    process (RST_PUxCH, CLK)
    begin
        if (RST_PUxCH = '1') then
            index_puxch_wr <= 0;
            index_puxch_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (puxch_tick_sh /= 0) then
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    index_puxch_wr <= index_puxch_wr;
                else
                    index_puxch_wr <= index_puxch_wr + 1;
                end if;
            else
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    if (index_puxch_wr = 0) then
                        index_puxch_wr <= 0;
                    else
                        index_puxch_wr <= index_puxch_wr - 1;
                    end if;
                end if;
            end if;
            if (puxch_tick_sh /= 0) then
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    index_puxch_rd <= index_puxch_rd;
                else
                    index_puxch_rd <= index_puxch_wr;
                end if;
            else
                if (PUxCH_PACKING_TICK_ACK = '1') then
                    if (index_puxch_rd = 0) then
                        index_puxch_rd <= 0;
                    else
                        index_puxch_rd <= index_puxch_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (prach_tick_sh /= 0) then
                prach_id_buf <= prach_id_buf(HDR_BUF-2 downto 0) & prach_id;
            end if;
        end if;
    end process;

    process (RST_PRACH, CLK)
    begin
        if (RST_PRACH = '1') then
            index_prach_wr <= 0;
            index_prach_rd <= 0;
        elsif (CLK'event and CLK = '1') then
            if (prach_tick_sh /= 0) then
                if (PRACH_PACKING_TICK_ACK = '1') then
                    index_prach_wr <= index_prach_wr;
                else
                    index_prach_wr <= index_prach_wr + 1;
                end if;
            else
                if (PRACH_PACKING_TICK_ACK = '1') then
                    if (index_prach_wr = 0) then
                        index_prach_wr <= 0;
                    else
                        index_prach_wr <= index_prach_wr - 1;
                    end if;
                end if;
            end if;
            if (prach_tick_sh /= 0) then
                if (PRACH_PACKING_TICK_ACK = '1') then
                    index_prach_rd <= index_prach_rd;
                else
                    index_prach_rd <= index_prach_wr;
                end if;
            else
                if (PRACH_PACKING_TICK_ACK = '1') then
                    if (index_prach_rd = 0) then
                        index_prach_rd <= 0;
                    else
                        index_prach_rd <= index_prach_rd - 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    u_1CHANNEL : if MAX_CH = 1 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            end if;
        end if;
    end process;
    end generate;

    u_2CHANNEL : if MAX_CH = 2 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            end if;
        end if;
    end process;
    end generate;

    u_3CHANNEL : if MAX_CH = 3 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            end if;
        end if;
    end process;
    end generate;

    u_4CHANNEL : if MAX_CH = 4 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            end if;
        end if;
    end process;
    end generate;

    u_5CHANNEL : if MAX_CH = 5 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            end if;
        end if;
    end process;
    end generate;

    u_6CHANNEL : if MAX_CH = 6 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            end if;
        end if;
    end process;
    end generate;

    u_7CHANNEL : if MAX_CH = 7 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            elsif (puxch_tick(6) = '1') then
                puxch_id <= cnt_puxch(6);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            elsif (prach_tick(6) = '1') then
                prach_id <= cnt_prach(6);
            end if;
        end if;
    end process;
    end generate;

    u_8CHANNEL : if MAX_CH = 8 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if    (puxch_tick(0) = '1') then
                puxch_id <= cnt_puxch(0);
            elsif (puxch_tick(1) = '1') then
                puxch_id <= cnt_puxch(1);
            elsif (puxch_tick(2) = '1') then
                puxch_id <= cnt_puxch(2);
            elsif (puxch_tick(3) = '1') then
                puxch_id <= cnt_puxch(3);
            elsif (puxch_tick(4) = '1') then
                puxch_id <= cnt_puxch(4);
            elsif (puxch_tick(5) = '1') then
                puxch_id <= cnt_puxch(5);
            elsif (puxch_tick(6) = '1') then
                puxch_id <= cnt_puxch(6);
            elsif (puxch_tick(7) = '1') then
                puxch_id <= cnt_puxch(7);
            end if;
            if    (prach_tick(0) = '1') then
                prach_id <= cnt_prach(0);
            elsif (prach_tick(1) = '1') then
                prach_id <= cnt_prach(1);
            elsif (prach_tick(2) = '1') then
                prach_id <= cnt_prach(2);
            elsif (prach_tick(3) = '1') then
                prach_id <= cnt_prach(3);
            elsif (prach_tick(4) = '1') then
                prach_id <= cnt_prach(4);
            elsif (prach_tick(5) = '1') then
                prach_id <= cnt_prach(5);
            elsif (prach_tick(6) = '1') then
                prach_id <= cnt_prach(6);
            elsif (prach_tick(7) = '1') then
                prach_id <= cnt_prach(7);
            end if;
        end if;
    end process;
    end generate;

    u_CH : for i in MAX_CH-1 downto 0 generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (EN_MULTI_SEQUENCE(i) = '1') then
                if (PUxCH_PACKING_TICK(i) = '1') then
                    cnt_puxch(i) <= cnt_puxch(i) + 1;
                end if;
                if (PRACH_PACKING_TICK(i) = '1') then
                    cnt_prach(i) <= cnt_prach(i) + 1;
                end if;
            else
                if    (PUxCH_PACKING_TICK(i) = '1') and (PRACH_PACKING_TICK(i) = '1') then
                    cnt_puxch(i) <= cnt_puxch(i) + 1;
                    cnt_prach(i) <= cnt_prach(i) + 2;
                elsif (PUxCH_PACKING_TICK(i) = '1') then
                    cnt_puxch(i) <= cnt_puxch(i) + 1;
                    cnt_prach(i) <= cnt_prach(i) + 1;
                elsif (PRACH_PACKING_TICK(i) = '1') then
                    cnt_puxch(i) <= cnt_puxch(i) + 1;
                    cnt_prach(i) <= cnt_prach(i) + 1;
                end if;
            end if;
        end if;
    end process;
    end generate;

end BEHAVE;