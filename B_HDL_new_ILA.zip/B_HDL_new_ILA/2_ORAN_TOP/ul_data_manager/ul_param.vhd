--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : UL U-Plane parameter (O-RAN component)                        --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity UL_PARAM is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        EN_MULTI_SEQUENCE           : in  std_logic_vector(MAX_CH-1 downto 0);

--------------------------------------------------------------------------------
-- PUxCH
--------------------------------------------------------------------------------

        PUxCH_INIT                  : in  std_logic;
        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PUxCH_DATA_DIRECTION        : in  std_logic;
        PUxCH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PUxCH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PUxCH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PUxCH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PUxCH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PUxCH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PUxCH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PUxCH_USE_EVERY_PRB         : in  std_logic;
        PUxCH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PUxCH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PUxCH_RB_INIT               : out std_logic;
        PUxCH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PUxCH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_APP_ACK     : in  std_logic;
        PUxCH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PUxCH_RB_HEADER_SEC_ACK     : in  std_logic;

--------------------------------------------------------------------------------
-- PRACH
--------------------------------------------------------------------------------

        PRACH_INIT                  : in  std_logic;
        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_RTCPC_ID              : in  std_logic_vector(15 downto 0);

        PRACH_DATA_DIRECTION        : in  std_logic;
        PRACH_PAYLOAD_VERSION       : in  std_logic_vector(2 downto 0);
        PRACH_FILTER_INDEX          : in  std_logic_vector(3 downto 0);
        PRACH_FRAME_ID              : in  std_logic_vector(7 downto 0);
        PRACH_SUBFRAME_ID           : in  std_logic_vector(3 downto 0);
        PRACH_SLOT_ID               : in  std_logic_vector(5 downto 0);
        PRACH_SYMBOL_ID             : in  std_logic_vector(5 downto 0);

        PRACH_SECTION_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);

        PRACH_SECTION_ID            : in  std_logic_vector(11 downto 0);
        PRACH_USE_EVERY_PRB         : in  std_logic;
        PRACH_START_OF_PRB          : in  std_logic_vector(9 downto 0);
        PRACH_NUMBER_OF_PRB         : in  std_logic_vector(9 downto 0);

        PRACH_RB_INIT               : out std_logic;
        PRACH_RB_eAxC_ID            : out std_logic_vector(15 downto 0);
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);
        PRACH_RB_HEADER_APP         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_APP_ACK     : in  std_logic;
        PRACH_RB_HEADER_SEC         : out std_logic_vector(31 downto 0);
        PRACH_RB_HEADER_SEC_ACK     : in  std_logic
    );
end UL_PARAM;

architecture BEHAVE of UL_PARAM is

    component UL_PARAM_COMMON is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        PACKING_TICK                : in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    : in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              : in  std_logic;
        PAYLOAD_VERSION             : in  std_logic_vector(2 downto 0);
        FILTER_INDEX                : in  std_logic_vector(3 downto 0);
        FRAME_ID                    : in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 : in  std_logic_vector(3 downto 0);
        SLOT_ID                     : in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   : in  std_logic_vector(5 downto 0);

        SECTION_TICK                : in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  : in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               : in  std_logic;
        START_OF_PRB                : in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               : in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  : out std_logic_vector(15 downto 0);
        RB_HEADER_APP               : out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : in  std_logic;
        RB_HEADER_SEC               : out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : in  std_logic
    );
    end component;

    component UL_SEQ_ID is
    generic (
        MAX_CH                      : natural := 8
    );
    port (
        CLK                         : in  std_logic;
        RST_PUxCH                   : in  std_logic;
        RST_PRACH                   : in  std_logic;

        EN_MULTI_SEQUENCE           : in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      : in  std_logic;
        PUxCH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0);

        PRACH_PACKING_TICK          : in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      : in  std_logic;
        PRACH_RB_SEQUENCE_ID        : out std_logic_vector(15 downto 0)
    );
    end component;

begin

    PUxCH_RB_INIT <= PUxCH_INIT;
    PRACH_RB_INIT <= PRACH_INIT;

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_PUxCH : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => PUxCH_INIT                              ,--: in  std_logic;

        PACKING_TICK                => PUxCH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => PUxCH_RTCPC_ID                          ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PUxCH_DATA_DIRECTION                    ,--: in  std_logic;
        PAYLOAD_VERSION             => PUxCH_PAYLOAD_VERSION                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => PUxCH_FILTER_INDEX                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => PUxCH_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PUxCH_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => PUxCH_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PUxCH_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => PUxCH_SECTION_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => PUxCH_SECTION_ID                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PUxCH_USE_EVERY_PRB                     ,--: in  std_logic;
        START_OF_PRB                => PUxCH_START_OF_PRB                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PUxCH_NUMBER_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => PUxCH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => PUxCH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        RB_HEADER_SEC               => PUxCH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => PUxCH_RB_HEADER_SEC_ACK                  --: in  std_logic
    );

    u_PRACH : UL_PARAM_COMMON
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => PRACH_INIT                              ,--: in  std_logic;

        PACKING_TICK                => PRACH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        RTCPC_ID                    => PRACH_RTCPC_ID                          ,--: in  std_logic_vector(15 downto 0);

        DATA_DIRECTION              => PRACH_DATA_DIRECTION                    ,--: in  std_logic;
        PAYLOAD_VERSION             => PRACH_PAYLOAD_VERSION                   ,--: in  std_logic_vector(2 downto 0);
        FILTER_INDEX                => PRACH_FILTER_INDEX                      ,--: in  std_logic_vector(3 downto 0);
        FRAME_ID                    => PRACH_FRAME_ID                          ,--: in  std_logic_vector(7 downto 0);
        SUBFRAME_ID                 => PRACH_SUBFRAME_ID                       ,--: in  std_logic_vector(3 downto 0);
        SLOT_ID                     => PRACH_SLOT_ID                           ,--: in  std_logic_vector(5 downto 0);
        SYMBOL_ID                   => PRACH_SYMBOL_ID                         ,--: in  std_logic_vector(5 downto 0);

        SECTION_TICK                => PRACH_SECTION_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        SECTION_ID                  => PRACH_SECTION_ID                        ,--: in  std_logic_vector(11 downto 0);
        USE_EVERY_PRB               => PRACH_USE_EVERY_PRB                     ,--: in  std_logic;
        START_OF_PRB                => PRACH_START_OF_PRB                      ,--: in  std_logic_vector(9 downto 0);
        NUMBER_OF_PRB               => PRACH_NUMBER_OF_PRB                     ,--: in  std_logic_vector(9 downto 0);

        RB_eAxC_ID                  => PRACH_RB_eAxC_ID                        ,--: out std_logic_vector(15 downto 0);
        RB_HEADER_APP               => PRACH_RB_HEADER_APP                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        RB_HEADER_SEC               => PRACH_RB_HEADER_SEC                     ,--: out std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => PRACH_RB_HEADER_SEC_ACK                  --: in  std_logic
    );

    u_SEQ_ID : UL_SEQ_ID
    generic map(
        MAX_CH                      => MAX_CH                                   --: natural := 8
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST_PUxCH                   => PUxCH_INIT                              ,--: in  std_logic;
        RST_PRACH                   => PRACH_INIT                              ,--: in  std_logic;

        EN_MULTI_SEQUENCE           => EN_MULTI_SEQUENCE                       ,--: in  std_logic_vector(MAX_CH-1 downto 0);

        PUxCH_PACKING_TICK          => PUxCH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        PUxCH_PACKING_TICK_ACK      => PUxCH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PUxCH_RB_SEQUENCE_ID        => PUxCH_RB_SEQUENCE_ID                    ,--: out std_logic_vector(15 downto 0);

        PRACH_PACKING_TICK          => PRACH_PACKING_TICK                      ,--: in  std_logic_vector(MAX_CH-1 downto 0);
        PRACH_PACKING_TICK_ACK      => PRACH_RB_HEADER_APP_ACK                 ,--: in  std_logic;
        PRACH_RB_SEQUENCE_ID        => PRACH_RB_SEQUENCE_ID                     --: out std_logic_vector(15 downto 0)
    );

end BEHAVE;