
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity eth_dump_axi_lite is
generic
(
    AXI_DATA_WIDTH    : integer :=                   32;
    AXI_ADDR_WIDTH    : integer :=                   16
);
port
(
    axi_aclk             : in  std_logic;
    axi_aresetn          : in  std_logic;
    axi_awaddr           : in  std_logic_vector( AXI_ADDR_WIDTH   -1 downto 0);
    axi_awvalid          : in  std_logic;
    axi_wdata            : in  std_logic_vector( AXI_DATA_WIDTH   -1 downto 0);
    axi_wstrb            : in  std_logic_vector((AXI_DATA_WIDTH/8)-1 downto 0);
    axi_wvalid           : in  std_logic;
    axi_bready           : in  std_logic;
    axi_araddr           : in  std_logic_vector( AXI_ADDR_WIDTH   -1 downto 0);
    axi_arvalid          : in  std_logic;
    axi_rready           : in  std_logic;
    axi_arready          : out std_logic;
    axi_rdata            : out std_logic_vector( AXI_DATA_WIDTH   -1 downto 0);
    axi_rresp            : out std_logic_vector(                   1 downto 0);
    axi_rvalid           : out std_logic;
    axi_wready           : out std_logic;
    axi_bresp            : out std_logic_vector(                   1 downto 0);
    axi_bvalid           : out std_logic;
    axi_awready          : out std_logic;

    rd_addr              : out std_logic_vector(AXI_ADDR_WIDTH    -1 downto 0);
    rd_data              : in  std_logic_vector(AXI_DATA_WIDTH    -1 downto 0);
                                                                  
    wr_addr              : out std_logic_vector(AXI_ADDR_WIDTH    -1 downto 0);
    wr_data              : out std_logic_vector(AXI_DATA_WIDTH    -1 downto 0);
    wr_stb               : out std_logic
);

end entity eth_dump_axi_lite;

architecture Behavioral of eth_dump_axi_lite is

    type state_type is (IDLE, RESP, ACK);
    signal rd_state : state_type;
    signal wr_state : state_type;
begin

    process (axi_aclk)
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                rd_state <= IDLE;
            else
                case rd_state is
                    when IDLE =>
                        if axi_arvalid = '1' then
                            rd_state <= ACK;
                            rd_addr <= axi_araddr;
                        end if;
                        
                    when ACK => 
                        rd_state <= RESP;

                    when RESP =>
                        if axi_rready = '1' then
                            rd_state <= IDLE;
                        end if;
                        
                    when others =>rd_state <= IDLE;
                end case;
            end if;
        end if;
    end process;


    axi_arready <= '1' when rd_state = IDLE else '0';
    axi_rvalid  <= '1' when rd_state = RESP else '0';
    axi_rresp   <= "00";

    axi_rdata   <= rd_data;

    process (axi_aclk)
    begin
        if rising_edge(axi_aclk) then
            if axi_aresetn = '0' then
                wr_state <= IDLE;
            else
                case wr_state is
                    when IDLE =>
                        if axi_awvalid = '1' and axi_wvalid = '1' then
                            wr_state <= ACK;
                        end if;

                    when ACK =>
                        wr_state <= RESP;

                    when RESP =>
                        if axi_bready = '1' then
                            wr_state <= IDLE;
                        end if;

                    when others => wr_state <= IDLE;

                end case;
            end if;
        end if;
    end process;

    wr_stb  <= '1' when axi_awvalid = '1' and axi_wvalid = '1' and wr_state = IDLE else '0';
    wr_data <= axi_wdata;
    wr_addr <= axi_awaddr;

    axi_awready <= '1' when wr_state = ACK else '0';
    axi_wready  <= '1' when wr_state = ACK else '0';

    axi_bresp  <= "00";
    axi_bvalid <= '1' when wr_state = RESP else '0';

end;
