module eth_dump_core (
    input  wire         axi_aclk   ,
    input  wire         axi_aresetn,
    
    input  wire [15:0]  rd_addr    ,
    output reg  [31:0]  rd_data    ,
                                    
    input  wire [15:0]  wr_addr    ,
    input  wire [31:0]  wr_data    ,
    input  wire         wr_stb     ,

    input  wire         axis_clk   ,
    
    input  wire         s_axis_tvalid ,
    output wire         s_axis_tready ,
    input  wire         s_axis_tlast  ,
    input  wire [ 7:0]  s_axis_tkeep  ,
    input  wire [63:0]  s_axis_tdata  ,
    
    output wire         m_axis_tvalid ,
    input  wire         m_axis_tready ,
    output wire         m_axis_tlast  ,
    output wire [ 7:0]  m_axis_tkeep  ,
    output wire [63:0]  m_axis_tdata      
    
);

    assign m_axis_tvalid = s_axis_tvalid;
    assign m_axis_tlast  = s_axis_tlast ;
    assign m_axis_tkeep  = s_axis_tkeep ;
    assign m_axis_tdata  = s_axis_tdata ;
    assign s_axis_tready = m_axis_tready;


    wire        eth_clk             ;
    
    assign eth_clk = axis_clk;
    wire        eth_resetn          ;

    reg         reg_reset           ;
    reg         reg_Dump_Enable     ;  
    reg  [ 7:0] reg_Mem_Addr        ;
    reg         reg_eth_dir         ;   //0: UL     1: DL
    
    wire [31:0] cpu_MSB_Data        ;
    wire [31:0] cpu_LSB_Data        ;
    wire [ 7:0] cpu_size_packet     ;
    
    wire         cpu_clk            ;
    wire         cpu_reset          ;
    wire         cpu_areset         ;
    wire         cpu_aresetn        ;
                                    
    wire         Dump_Enable        ;
    reg          Dump_Enable_dly    ;
    reg          Dump_Enable_act    ;

    reg          eth_active         ;
    reg          eth_dly_tvalid     ;
    reg          eth_dly_tlast      ;
    reg  [63:0]  eth_dly_tdata      ;
    
        
    reg          buff_write_wea     ;
    reg  [ 7:0]  buff_write_addr    ;   
    reg  [63:0]  buff_write_data    ;    
    wire [ 7:0]  buff_read_addr     ;   
    wire [63:0]  buff_read_data     ;
    
    assign cpu_areset  = reg_reset ;
    assign cpu_aresetn = ~reg_reset;
    assign cpu_clk     = axi_aclk  ;
        
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    eth_resetn_inst (
        .dest_arst(eth_resetn  ), 
        .dest_clk (eth_clk     ),   
        .src_arst (cpu_aresetn )    
    );
    
    xpm_cdc_async_rst #(
        .DEST_SYNC_FF   (2),    
        .INIT_SYNC_FF   (0),    
        .RST_ACTIVE_HIGH(0)  
    )
    cpu_reset_inst (
        .dest_arst(cpu_reset   ), 
        .dest_clk (axi_aclk    ),   
        .src_arst (cpu_areset  )    
    );
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 8)           
    )
    cdc_packet_size_inst (
        .dest_out(cpu_size_packet    ),     
        .dest_clk(axi_aclk           ), 
        .src_clk (eth_clk            ),   
        .src_in  (buff_write_addr    )      
    );
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin   
            reg_reset             <= 'd0;
            reg_Dump_Enable       <= 'd0;            
            reg_Mem_Addr          <= 'd0;
            reg_eth_dir           <= 'd0;
        end
        else begin
            if(wr_stb == 'b1) begin
                case (wr_addr)  
                    'h0004 : reg_reset             <= wr_data[0]  ;
                    'h000C : reg_Dump_Enable       <= wr_data[0]  ;                   
                    'h001C : reg_Mem_Addr          <= wr_data[7:0];      
                    'h0020 : reg_eth_dir           <= wr_data[0];                     
                endcase  
            end
        end
    end    
    
    always @(posedge axi_aclk) begin
        if(axi_aresetn == 1'b0) begin            
            rd_data              <= 'd0;               
        end
        else begin
            case (rd_addr)  
                'h0000 : rd_data <= {8'h25, 8'h11, 16'h2024};
                'h0004 : rd_data <= {31'd0, reg_reset      };
                'h000C : rd_data <= {31'd0, reg_Dump_Enable};                 
                'h001C : rd_data <= {24'd0, reg_Mem_Addr   }; 
                'h0020 : rd_data <= cpu_MSB_Data            ;
                'h0024 : rd_data <= cpu_LSB_Data            ;       
                'h0028 : rd_data <= {24'd0, cpu_size_packet };                 
            endcase  
        end
    end 
    
    xpm_cdc_array_single #(
        .DEST_SYNC_FF   ( 2),   
        .INIT_SYNC_FF   ( 0),   
        .SIM_ASSERT_CHK ( 0), 
        .SRC_INPUT_REG  ( 1),  
        .WIDTH          ( 1)           
    )
    cdc_Dump_Enable_inst (
        .dest_out(Dump_Enable        ),     
        .dest_clk(eth_clk            ), 
        .src_clk (axi_aclk           ),   
        .src_in  (reg_Dump_Enable    )      
    );
    
    always @(posedge eth_clk) begin
        if(eth_resetn == 1'b0) begin    
            Dump_Enable_dly <= 'b0;
        end
        else begin
            Dump_Enable_dly <= Dump_Enable;
        end
    end
    
    always @(posedge eth_clk) begin
        if(eth_resetn == 1'b0) begin    
            Dump_Enable_act <= 'b0;
        end
        else begin
            if (reg_eth_dir == 'b0) begin  // UL
                if(s_axis_tvalid == 'b1 && m_axis_tready == 'b1 && s_axis_tlast == 'b1 && eth_active == 'b1) begin
                    Dump_Enable_act <= 'b0;
                end
                else if(Dump_Enable == 'b1 && Dump_Enable_dly == 'b0) begin
                    Dump_Enable_act <= 'b1;
                end
                else begin
                    Dump_Enable_act <= Dump_Enable_act;
                end
            end 
            else begin      // DL
                if(s_axis_tvalid == 'b1 && s_axis_tlast == 'b1 && eth_active == 'b1) begin
                    Dump_Enable_act <= 'b0;
                end
                else if(Dump_Enable == 'b1 && Dump_Enable_dly == 'b0) begin
                    Dump_Enable_act <= 'b1;
                end
                else begin
                    Dump_Enable_act <= Dump_Enable_act;
                end
            end
        end
    end

    
    always @(posedge eth_clk) begin
        if(eth_resetn == 1'b0) begin    
            eth_active     <= 'b0;
            eth_dly_tvalid <= 'b0;
            eth_dly_tlast  <= 'b0;
            eth_dly_tdata  <= 'd0;
        end
        else begin
            eth_dly_tvalid <= s_axis_tvalid;
            eth_dly_tlast  <= s_axis_tlast ;
            eth_dly_tdata  <= s_axis_tdata ;
            
            if(eth_dly_tvalid == 'b1 && eth_dly_tlast == 'b1) begin
                eth_active <= 'b0;
            end 
            else if(Dump_Enable_act == 'b1 && s_axis_tvalid == 'b1 && eth_dly_tvalid == 'b0) begin
                eth_active <= 'b1;
            end
            else begin
                eth_active <= eth_active;
            end
        end
    end


    always @(posedge eth_clk) begin
        if(eth_resetn == 1'b0) begin            
            buff_write_wea  <= 'd0;    
            buff_write_data <= 'd0;    
        end
        else begin
            if(eth_active == 'b1) begin
                buff_write_wea  <= 'd1;    
                buff_write_data <= eth_dly_tdata;    
            end
            else begin
                buff_write_wea  <= 'd0;
                buff_write_data <= 'd0;
            end
        end
    end 
    
    always @(posedge eth_clk) begin
        if(eth_resetn == 1'b0) begin       
            buff_write_addr <= 'd0;  
        end
        else begin
            if(Dump_Enable == 'b1) begin
                if(eth_active == 'b1) begin
                    buff_write_addr <= buff_write_addr + 'd1; 
                end
                else 
                    buff_write_addr <= buff_write_addr;  
                end
            else begin
                buff_write_addr <= 'd0;  
            end
        end
    end 
    
    xpm_memory_sdpram #(
        .ADDR_WIDTH_A             (                      8), 
        .ADDR_WIDTH_B             (                      8), 
        .AUTO_SLEEP_TIME          (                      0), 
        .BYTE_WRITE_WIDTH_A       (                     64), 
        .CLOCKING_MODE            ("independent_clock"    ), 
        .ECC_MODE                 ("no_ecc"               ), 
        .MEMORY_INIT_FILE         ("none"                 ), 
        .MEMORY_INIT_PARAM        ("0"                    ), 
        .MEMORY_OPTIMIZATION      ("true"                 ),  
        .MEMORY_PRIMITIVE         ("auto"                 ),  
        .MEMORY_SIZE              (                  16384),
        .MESSAGE_CONTROL          (                      0),    
        .READ_DATA_WIDTH_B        (                     64),    
        .READ_LATENCY_B           (                      1),    
        .READ_RESET_VALUE_B       ("0"                    ),      
        .RST_MODE_A               ("SYNC"                 ),      
        .RST_MODE_B               ("SYNC"                 ),      
        .USE_EMBEDDED_CONSTRAINT  (                      0),   
        .USE_MEM_INIT             (                      0),      
        .WAKEUP_TIME              ("disable_sleep"        ),  
        .WRITE_DATA_WIDTH_A       (                     64),  
        .WRITE_MODE_B             ("no_change"            )   
    ) xpm_memory_data_inst (
        .clka                     (eth_clk                ),  
        .ena                      (                    'b1),
        .wea                      (buff_write_wea         ),
        .addra                    (buff_write_addr        ),
        .dina                     (buff_write_data        ),
                                  
        .clkb                     (cpu_clk                ),
        .enb                      (                    'b1),
        .rstb                     (cpu_reset              ), 
        .addrb                    (buff_read_addr         ),
        .doutb                    (buff_read_data         ), 
                                  
        .injectdbiterra           (                    'b0),
        .injectsbiterra           (                    'b0),
        .regceb                   (                    'b1),
        .dbiterrb                 (                       ), 
        .sbiterrb                 (                       ),
                                  
        .sleep                    (                    'b0)           
    );
    
    assign buff_read_addr = reg_Mem_Addr         ;
    assign cpu_MSB_Data   = buff_read_data[63:32];
    assign cpu_LSB_Data   = buff_read_data[31: 0];
    
endmodule
