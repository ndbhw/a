--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : O-RAN framer                                                  --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

use WORK.PKG_O_RAN.ALL;

entity O_RAN_FRAMER is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        RST                         : in  std_logic;                            -- ASYNC

        CLK_MAC                     : in  std_logic;                            -- 390.625-MHz
        CLK_BUS                     : in  std_logic;                            -- 245.76-MHz

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        TX_PARAM_DST_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_SRC_MAC            : in  std_logic_vector(47 downto 0);
        TX_PARAM_VLAN0_MODE         : in  std_logic;                            -- 0 : Untagged, 1 : Tagged
        TX_PARAM_VLAN0_TCI          : in  std_logic_vector(15 downto 0);
        TX_PARAM_VLAN1_MODE         : in  std_logic;                            -- 0 : Untagged, 1 : Tagged
        TX_PARAM_VLAN1_TCI          : in  std_logic_vector(15 downto 0);

        TX_COMP_MODE                : in  std_logic;
        TX_COMP_EXP_OFFSET          : in  std_logic_vector(4 downto 0);
        TX_COMP_GAIN_OFFSET         : in  std_logic_vector(10 downto 0);
        TX_COMP_SCALE_GAIN_OFFSET   : in  std_logic_vector(3 downto 0);

--------------------------------------------------------------------------------
-- Statistics
--------------------------------------------------------------------------------

        USAGE_TX_DATA_BUFFER        : out std_logic_vector(31 downto 0);
        USAGE_TX_C_PLANE_BUFFER     : out std_logic_vector(31 downto 0);
        USAGE_TX_U_PLANE_BUFFER     : out std_logic_vector(31 downto 0);

        TX_C_PLANE                  : out std_logic_vector(31 downto 0);
        TX_C_PLANE_LOST             : out std_logic_vector(31 downto 0);
        TX_U_PLANE                  : out std_logic_vector(31 downto 0);
        TX_U_PLANE_LOST             : out std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- MAC
--------------------------------------------------------------------------------

        MAC_TX_READY                : in  std_logic;
        MAC_TX_VALID                : out std_logic;
        MAC_TX_LAST                 : out std_logic;
        MAC_TX_KEEP                 : out std_logic_vector(7 downto 0);
        MAC_TX_DATA                 : out std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- UL U-Plane (Not encoded)
--------------------------------------------------------------------------------

        RB_INIT                     : in  std_logic;
        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

        RB_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        RB_VALID                    : in  std_logic;
        RB_START                    : in  std_logic;
        RB_TICK                     : in  std_logic;
        RB_LAST                     : in  std_logic;
        RB_DATA_I                   : in  std_logic_vector(15 downto 0);
        RB_DATA_Q                   : in  std_logic_vector(15 downto 0);
        RB_USER                     : in  std_logic_vector(15 downto 0)
    );
end O_RAN_FRAMER;

architecture BEHAVE of O_RAN_FRAMER is

    component RST_SYNC is
    generic (
        DLY_NUM                     : natural := 4;
        MAX_FANOUT_NUM              : integer := 200
    );
    port (
        RST_IN                      : in  std_logic;
        CLK                         : in  std_logic;
        RST_OUT                     : out std_logic
    );
    end component;

    signal reset_bus                : std_logic;
    signal reset_mac                : std_logic;

    component PRB_COMP is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        COMP_EXP_OFFSET             : in  std_logic_vector(4 downto 0);
        COMP_GAIN_OFFSET            : in  std_logic_vector(10 downto 0);
        COMP_SCALE_GAIN_OFFSET      : in  std_logic_vector(3 downto 0);

        IQ_COMP_HDR                 : in  std_logic_vector(7 downto 0);

        IQ_VALID                    : in  std_logic;
        IQ_TICK                     : in  std_logic;
        IQ_DATA_I                   : in  std_logic_vector(15 downto 0);
        IQ_DATA_Q                   : in  std_logic_vector(15 downto 0);
        IQ_USER                     : in  std_logic_vector(15 downto 0);

        COMP_HDR                    : out std_logic_vector(7 downto 0);
        COMP_PARAM                  : out std_logic_vector(7 downto 0);

        COMP_VALID                  : out std_logic;
        COMP_TICK                   : out std_logic;
        COMP_DATA_I                 : out std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : out std_logic_vector(15 downto 0);
        COMP_USER                   : out std_logic_vector(15 downto 0)
    );
    end component;

    signal comp_hdr                 : std_logic_vector(7 downto 0);
    signal comp_param               : std_logic_vector(7 downto 0);
    signal comp_valid               : std_logic;
    signal comp_tick                : std_logic;
    signal comp_data_i              : std_logic_vector(15 downto 0);
    signal comp_data_q              : std_logic_vector(15 downto 0);
    signal comp_user                : std_logic_vector(15 downto 0);

    component PRB_PACKER is
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        DST_MAC                     : in  std_logic_vector(47 downto 0);
        SRC_MAC                     : in  std_logic_vector(47 downto 0);
        VLAN0_MODE                  : in  std_logic;
        VLAN0_TCI                   : in  std_logic_vector(15 downto 0);
        VLAN1_MODE                  : in  std_logic;
        VLAN1_TCI                   : in  std_logic_vector(15 downto 0);

        COMP_MODE                   : in  std_logic;

        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

        COMP_HDR                    : in  std_logic_vector(7 downto 0);
        COMP_PARAM                  : in  std_logic_vector(7 downto 0);

        COMP_VALID                  : in  std_logic;
        COMP_TICK                   : in  std_logic;
        COMP_DATA_I                 : in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : in  std_logic_vector(15 downto 0);
        COMP_USER                   : in  std_logic_vector(15 downto 0);

        PACK_LENGTH                 : out std_logic_vector(15 downto 0);

        PACK_VALID                  : out std_logic;
        PACK_START                  : out std_logic;
        PACK_LAST                   : out std_logic;
        PACK_KEEP                   : out std_logic_vector(3 downto 0);
        PACK_DATA                   : out std_logic_vector(31 downto 0)
    );
    end component;

    signal pack_length              : std_logic_vector(15 downto 0);
    signal pack_valid               : std_logic;
    signal pack_start               : std_logic;
    signal pack_last                : std_logic;
    signal pack_keep                : std_logic_vector(3 downto 0);
    signal pack_data                : std_logic_vector(31 downto 0);

    component PKT_GEN is
    port (
        CLK_MAC                     : in  std_logic;
        CLK_BUS                     : in  std_logic;

        RST_MAC                     : in  std_logic;
        RST_BUS                     : in  std_logic;

        VLAN0_MODE                  : in  std_logic;
        VLAN1_MODE                  : in  std_logic;

        PACK_LENGTH                 : in  std_logic_vector(15 downto 0);

        PACK_VALID                  : in  std_logic;
        PACK_START                  : in  std_logic;
        PACK_LAST                   : in  std_logic;
        PACK_KEEP                   : in  std_logic_vector(3 downto 0);
        PACK_DATA                   : in  std_logic_vector(31 downto 0);

        TX_VALID                    : out std_logic;
        TX_START                    : out std_logic;
        TX_LAST                     : out std_logic;
        TX_KEEP                     : out std_logic_vector(7 downto 0);
        TX_DATA                     : out std_logic_vector(63 downto 0)
    );
    end component;

    signal tx_valid                 : std_logic;
    signal tx_last                  : std_logic;
    signal tx_keep                  : std_logic_vector(7 downto 0);
    signal tx_data                  : std_logic_vector(63 downto 0);

    component PKT_TX is
    generic (
        USAGE_C_PLANE               : boolean := true;
        USAGE_U_PLANE               : boolean := true
    );
    port (
        CLK                         : in  std_logic;

        RST                         : in  std_logic;

        USAGE_DATA_BUFFER           : out std_logic_vector(31 downto 0);
        USAGE_C_PLANE_BUFFER        : out std_logic_vector(31 downto 0);
        USAGE_U_PLANE_BUFFER        : out std_logic_vector(31 downto 0);

        CNT_C_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_C_PLANE_LOST            : out std_logic_vector(31 downto 0);
        CNT_U_PLANE                 : out std_logic_vector(31 downto 0);
        CNT_U_PLANE_LOST            : out std_logic_vector(31 downto 0);

        IN_C_VALID                  : in  std_logic;
        IN_C_LAST                   : in  std_logic;
        IN_C_KEEP                   : in  std_logic_vector(7 downto 0);
        IN_C_DATA                   : in  std_logic_vector(63 downto 0);

        IN_U_VALID                  : in  std_logic;
        IN_U_LAST                   : in  std_logic;
        IN_U_KEEP                   : in  std_logic_vector(7 downto 0);
        IN_U_DATA                   : in  std_logic_vector(63 downto 0);

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0)
    );
    end component;

begin

--------------------------------------------------------------------------------
-- U-Plane
--------------------------------------------------------------------------------

    u_RST_BUS : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST_OUT                     => reset_bus                                --: out std_logic
    );

    u_RST_MAC : RST_SYNC
    generic map(
        DLY_NUM                     => 4                                       ,--: natural := 4;
        MAX_FANOUT_NUM              => 200                                      --: integer := 200
    )
    port map(
        RST_IN                      => RST                                     ,--: in  std_logic;
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST_OUT                     => reset_mac                                --: out std_logic
    );

    u_COMP : PRB_COMP
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => RB_INIT                                 ,--: in  std_logic;

        COMP_EXP_OFFSET             => TX_COMP_EXP_OFFSET                      ,--: in  std_logic_vector(4 downto 0);
        COMP_GAIN_OFFSET            => TX_COMP_GAIN_OFFSET                     ,--: in  std_logic_vector(10 downto 0);
        COMP_SCALE_GAIN_OFFSET      => TX_COMP_SCALE_GAIN_OFFSET               ,--: in  std_logic_vector(3 downto 0);

        IQ_COMP_HDR                 => RB_COMP_HDR                             ,--: in  std_logic_vector(7 downto 0);

        IQ_VALID                    => RB_VALID                                ,--: in  std_logic;
        IQ_TICK                     => RB_TICK                                 ,--: in  std_logic;
        IQ_DATA_I                   => RB_DATA_I                               ,--: in  std_logic_vector(15 downto 0);
        IQ_DATA_Q                   => RB_DATA_Q                               ,--: in  std_logic_vector(15 downto 0);
        IQ_USER                     => RB_USER                                 ,--: in  std_logic_vector(15 downto 0);

        COMP_HDR                    => comp_hdr                                ,--: out std_logic_vector(7 downto 0);
        COMP_PARAM                  => comp_param                              ,--: out std_logic_vector(7 downto 0);

        COMP_VALID                  => comp_valid                              ,--: out std_logic;
        COMP_TICK                   => comp_tick                               ,--: out std_logic;
        COMP_DATA_I                 => comp_data_i                             ,--: out std_logic_vector(15 downto 0);
        COMP_DATA_Q                 => comp_data_q                             ,--: out std_logic_vector(15 downto 0);
        COMP_USER                   => comp_user                                --: out std_logic_vector(15 downto 0)
    );

    u_PACKER : PRB_PACKER
    port map(
        CLK                         => CLK_BUS                                 ,--: in  std_logic;
        RST                         => reset_bus                               ,--: in  std_logic;

        DST_MAC                     => TX_PARAM_DST_MAC                        ,--: in  std_logic_vector(47 downto 0);
        SRC_MAC                     => TX_PARAM_SRC_MAC                        ,--: in  std_logic_vector(47 downto 0);
        VLAN0_MODE                  => TX_PARAM_VLAN0_MODE                     ,--: in  std_logic;
        VLAN0_TCI                   => TX_PARAM_VLAN0_TCI                      ,--: in  std_logic_vector(15 downto 0);
        VLAN1_MODE                  => TX_PARAM_VLAN1_MODE                     ,--: in  std_logic;
        VLAN1_TCI                   => TX_PARAM_VLAN1_TCI                      ,--: in  std_logic_vector(15 downto 0);

        COMP_MODE                   => TX_COMP_MODE                            ,--: in  std_logic;

        RB_eAxC_ID                  => RB_eAxC_ID                              ,--: in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              => RB_SEQUENCE_ID                          ,--: in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               => RB_HEADER_APP                           ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           => RB_HEADER_APP_ACK                       ,--: out std_logic;
        RB_HEADER_SEC               => RB_HEADER_SEC                           ,--: in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           => RB_HEADER_SEC_ACK                       ,--: out std_logic;

        COMP_HDR                    => comp_hdr                                ,--: in  std_logic_vector(7 downto 0);
        COMP_PARAM                  => comp_param                              ,--: in  std_logic_vector(7 downto 0);

        COMP_VALID                  => comp_valid                              ,--: in  std_logic;
        COMP_TICK                   => comp_tick                               ,--: in  std_logic;
        COMP_DATA_I                 => comp_data_i                             ,--: in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 => comp_data_q                             ,--: in  std_logic_vector(15 downto 0);
        COMP_USER                   => comp_user                               ,--: in  std_logic_vector(15 downto 0);

        PACK_LENGTH                 => pack_length                             ,--: out std_logic_vector(15 downto 0);

        PACK_VALID                  => pack_valid                              ,--: out std_logic;
        PACK_START                  => pack_start                              ,--: out std_logic;
        PACK_LAST                   => pack_last                               ,--: out std_logic;
        PACK_KEEP                   => pack_keep                               ,--: out std_logic_vector(3 downto 0);
        PACK_DATA                   => pack_data                                --: out std_logic_vector(31 downto 0)
    );

    u_PKT_GEN : PKT_GEN
    port map(
        CLK_MAC                     => CLK_MAC                                 ,--: in  std_logic;
        CLK_BUS                     => CLK_BUS                                 ,--: in  std_logic;

        RST_MAC                     => reset_mac                               ,--: in  std_logic;
        RST_BUS                     => reset_bus                               ,--: in  std_logic;

        VLAN0_MODE                  => TX_PARAM_VLAN0_MODE                     ,--: in  std_logic;
        VLAN1_MODE                  => TX_PARAM_VLAN1_MODE                     ,--: in  std_logic;

        PACK_LENGTH                 => pack_length                             ,--: in  std_logic_vector(15 downto 0);

        PACK_VALID                  => pack_valid                              ,--: in  std_logic;
        PACK_START                  => pack_start                              ,--: in  std_logic;
        PACK_LAST                   => pack_last                               ,--: in  std_logic;
        PACK_KEEP                   => pack_keep                               ,--: in  std_logic_vector(3 downto 0);
        PACK_DATA                   => pack_data                               ,--: in  std_logic_vector(31 downto 0);

        TX_VALID                    => tx_valid                                ,--: out std_logic;
        TX_START                    => open                                    ,--: out std_logic;
        TX_LAST                     => tx_last                                 ,--: out std_logic;
        TX_KEEP                     => tx_keep                                 ,--: out std_logic_vector(7 downto 0);
        TX_DATA                     => tx_data                                  --: out std_logic_vector(63 downto 0)
    );

    u_PKT_TX : PKT_TX
    generic map(
        USAGE_C_PLANE               => USAGE_C_PLANE                           ,--: boolean := true;
        USAGE_U_PLANE               => USAGE_U_PLANE                            --: boolean := true
    )
    port map(
        CLK                         => CLK_MAC                                 ,--: in  std_logic;

        RST                         => RST                                     ,--: in  std_logic;

        USAGE_DATA_BUFFER           => USAGE_TX_DATA_BUFFER                    ,--: out std_logic_vector(31 downto 0);
        USAGE_C_PLANE_BUFFER        => USAGE_TX_C_PLANE_BUFFER                 ,--: out std_logic_vector(31 downto 0);
        USAGE_U_PLANE_BUFFER        => USAGE_TX_U_PLANE_BUFFER                 ,--: out std_logic_vector(31 downto 0);

        CNT_C_PLANE                 => TX_C_PLANE                              ,--: out std_logic_vector(31 downto 0);
        CNT_C_PLANE_LOST            => TX_C_PLANE_LOST                         ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE                 => TX_U_PLANE                              ,--: out std_logic_vector(31 downto 0);
        CNT_U_PLANE_LOST            => TX_U_PLANE_LOST                         ,--: out std_logic_vector(31 downto 0);

        IN_C_VALID                  => '0'                                     ,--: in  std_logic;
        IN_C_LAST                   => '0'                                     ,--: in  std_logic;
        IN_C_KEEP                   => (others => '0')                         ,--: in  std_logic_vector(7 downto 0);
        IN_C_DATA                   => (others => '0')                         ,--: in  std_logic_vector(63 downto 0);

        IN_U_VALID                  => tx_valid                                ,--: in  std_logic;
        IN_U_LAST                   => tx_last                                 ,--: in  std_logic;
        IN_U_KEEP                   => tx_keep                                 ,--: in  std_logic_vector(7 downto 0);
        IN_U_DATA                   => tx_data                                 ,--: in  std_logic_vector(63 downto 0);

        OUT_READY                   => MAC_TX_READY                            ,--: in  std_logic;
        OUT_VALID                   => MAC_TX_VALID                            ,--: out std_logic;
        OUT_LAST                    => MAC_TX_LAST                             ,--: out std_logic;
        OUT_KEEP                    => MAC_TX_KEEP                             ,--: out std_logic_vector(7 downto 0);
        OUT_DATA                    => MAC_TX_DATA                              --: out std_logic_vector(63 downto 0)

    );

end BEHAVE;