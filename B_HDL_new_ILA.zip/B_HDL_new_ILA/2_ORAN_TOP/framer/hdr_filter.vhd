--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Header filter                                                 --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity HDR_FILTER is
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        VLAN0_MODE                  : in  std_logic;
        VLAN1_MODE                  : in  std_logic;

--------------------------------------------------------------------------------
-- Data bus
--------------------------------------------------------------------------------

        IN_READY                    : in  std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(7 downto 0);
        IN_DATA                     : in  std_logic_vector(63 downto 0);

--------------------------------------------------------------------------------
-- Packet stamp
--------------------------------------------------------------------------------

        PACKET_IS_CP_DL             : out std_logic;
        PACKET_IS_CP_UL             : out std_logic;
        PACKET_IS_UP_DL             : out std_logic;
        PACKET_IS_UP_UL             : out std_logic;
        PACKET_CH                   : out std_logic_vector(2 downto 0);
        PACKET_CH_SUB               : out std_logic_vector(3 downto 0);
        PACKET_SUBFRAME             : out std_logic_vector(3 downto 0);
        PACKET_SLOT                 : out std_logic_vector(5 downto 0);
        PACKET_SYMBOL               : out std_logic_vector(5 downto 0)
    );
end HDR_FILTER;

architecture BEHAVE of HDR_FILTER is

    signal ready_in_reg             : std_logic := '0';
    signal valid_in_reg             : std_logic := '0';
    signal last_in_reg              : std_logic := '0';
--    signal keep_in_reg              : std_logic_vector(7 downto 0) := (others => '0');
    signal data_in_reg              : std_logic_vector(63 downto 0) := (others => '0');

    type fsm                        is (HDR0, HDR1, EXT0, EXT1, EXT2, DONE, DUMMY);
    signal fsm_ext                  : fsm;

    signal bypass_hdr               : std_logic := '0';
    signal ext_position             : std_logic := '0';

    signal c_plane                  : std_logic := '0';
    signal u_plane                  : std_logic := '0';
    signal dl_direction             : std_logic := '0';
    signal ul_direction             : std_logic := '0';
    signal subframe_id              : std_logic_vector(3 downto 0) := (others => '0');
    signal slot_id                  : std_logic_vector(5 downto 0) := (others => '0');
    signal symbol_id                : std_logic_vector(5 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- In/out port registering
--------------------------------------------------------------------------------

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            ready_in_reg <= IN_READY;
            valid_in_reg <= IN_VALID;
            last_in_reg  <= IN_LAST;
--            keep_in_reg  <= IN_KEEP;
            data_in_reg  <= IN_DATA;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when DONE   =>
                PACKET_IS_CP_DL <= c_plane and dl_direction;
                PACKET_IS_CP_UL <= c_plane and ul_direction;
                PACKET_IS_UP_DL <= u_plane and dl_direction;
                PACKET_IS_UP_UL <= u_plane and ul_direction;
            when others =>
                PACKET_IS_CP_DL <= '0';
                PACKET_IS_CP_UL <= '0';
                PACKET_IS_UP_DL <= '0';
                PACKET_IS_UP_UL <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PACKET_CH       <= (others => '0');
            PACKET_CH_SUB   <= (others => '0');
            PACKET_SUBFRAME <= subframe_id;
            PACKET_SLOT     <= slot_id;
            PACKET_SYMBOL   <= symbol_id;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Extract information
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_ext <= HDR0;
        elsif (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                if (ready_in_reg = '1') and (valid_in_reg = '1') then
                    if (bypass_hdr = '1') then
                        fsm_ext <= EXT0;
                    else
                        fsm_ext <= HDR1;
                    end if;
                else
                    fsm_ext <= HDR0;
                end if;
            when HDR1   =>
                if (ready_in_reg = '1') and (valid_in_reg = '1') then
                    fsm_ext <= EXT0;
                else
                    fsm_ext <= HDR1;
                end if;
            when EXT0   =>
                if (ready_in_reg = '1') and (valid_in_reg = '1') then
                    fsm_ext <= EXT1;
                else
                    fsm_ext <= EXT0;
                end if;
            when EXT1   =>
                if (ready_in_reg = '1') and (valid_in_reg = '1') then
                    fsm_ext <= EXT2;
                else
                    fsm_ext <= EXT1;
                end if;
            when EXT2   =>
                if (ready_in_reg = '1') and (valid_in_reg = '1') then
                    fsm_ext <= DONE;
                else
                    fsm_ext <= EXT2;
                end if;
            when DONE   =>
                fsm_ext <= DUMMY;
            when DUMMY  =>
                if (valid_in_reg = '1') and (last_in_reg = '1') then
                    fsm_ext <= HDR0;
                else
                    fsm_ext <= DUMMY;
                end if;
            when others =>
                fsm_ext <= HDR0;
            end case;
        end if;
    end process;

    bypass_hdr   <= '1' when (VLAN0_MODE = '0' and VLAN1_MODE = '0') else '0';
    ext_position <= '0' when (VLAN0_MODE = VLAN1_MODE) else '1';

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                c_plane      <= '0';
                u_plane      <= '0';
            when EXT0   =>
                if (ext_position = '0') then
                    if (data_in_reg(63 downto 56) = x"00") then
                        c_plane      <= '0';
                        u_plane      <= '1';
                    elsif (data_in_reg(63 downto 56) = x"02") then
                        c_plane      <= '1';
                        u_plane      <= '0';
                    else
                        c_plane      <= '0';
                        u_plane      <= '0';
                    end if;
                else
                    if (data_in_reg(31 downto 24) = x"00") then
                        c_plane      <= '0';
                        u_plane      <= '1';
                    elsif (data_in_reg(31 downto 24) = x"02") then
                        c_plane      <= '1';
                        u_plane      <= '0';
                    else
                        c_plane      <= '0';
                        u_plane      <= '0';
                    end if;
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when HDR0   =>
                dl_direction <= '0';
                ul_direction <= '0';
            when EXT1   =>
                if (ext_position = '0') then
                    if (data_in_reg(55) = '1') then
                        dl_direction <= '1';
                        ul_direction <= '0';
                    else
                        dl_direction <= '0';
                        ul_direction <= '1';
                    end if;
                else
                    if (data_in_reg(23) = '1') then
                        dl_direction <= '1';
                        ul_direction <= '0';
                    else
                        dl_direction <= '0';
                        ul_direction <= '1';
                    end if;
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_ext is
            when EXT1   =>
                if (ext_position = '1') then
                    subframe_id  <= data_in_reg(39 downto 36);
                    slot_id      <= data_in_reg(35 downto 32) & data_in_reg(47 downto 46);
                    symbol_id    <= data_in_reg(45 downto 40);
                end if;
            when EXT2   =>
                if (ext_position = '0') then
                    subframe_id  <= data_in_reg(7 downto 4);
                    slot_id      <= data_in_reg(3 downto 0) & data_in_reg(15 downto 14);
                    symbol_id    <= data_in_reg(13 downto 8);
                end if;
            when others =>
                NULL;
            end case;
        end if;
    end process;

end BEHAVE;