--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : 32bits@245.76MHz -> 64bits@390.625MHz                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity FROM_32_TO_64 is
    port (
--------------------------------------------------------------------------------
-- Clock
--------------------------------------------------------------------------------

        ARESET                      : in  std_logic;

--------------------------------------------------------------------------------
-- AXI input (32bits x 245.76MHz)
--------------------------------------------------------------------------------

        IN_CLK                      : in  std_logic;

        IN_READY                    : out std_logic;
        IN_VALID                    : in  std_logic;
        IN_LAST                     : in  std_logic;
        IN_KEEP                     : in  std_logic_vector(3 downto 0);
        IN_DATA                     : in  std_logic_vector(31 downto 0);

--------------------------------------------------------------------------------
-- AXI output (64bits x 390.625MHz)
--------------------------------------------------------------------------------

        OUT_CLK                     : in  std_logic;

        OUT_READY                   : in  std_logic;
        OUT_VALID                   : out std_logic;
        OUT_LAST                    : out std_logic;
        OUT_KEEP                    : out std_logic_vector(7 downto 0);
        OUT_DATA                    : out std_logic_vector(63 downto 0)
    );
end FROM_32_TO_64;

architecture BEHAVE of FROM_32_TO_64 is

    signal reset_n                  : std_logic;
    signal in_keep_rev              : std_logic_vector(3 downto 0);
    signal in_data_rev              : std_logic_vector(31 downto 0);

    component AXIS_READY_ADAPT is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                : out std_logic
    );
    end component;

    signal adapt_axis_tvalid        : std_logic;
    signal adapt_axis_tready        : std_logic;
    signal adapt_axis_tdata         : std_logic_vector(31 downto 0);
    signal adapt_axis_tkeep         : std_logic_vector(3 downto 0);
    signal adapt_axis_tlast         : std_logic;

    component AXIS_WIDTH_UP is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                : out std_logic
    );
    end component;

    signal width_axis_tvalid        : std_logic;
    signal width_axis_tready        : std_logic;
    signal width_axis_tdata         : std_logic_vector(63 downto 0);
    signal width_axis_tkeep         : std_logic_vector(7 downto 0);
    signal width_axis_tlast         : std_logic;

    component AXIS_REG_64 is
    port (
        ACLK                        : in  std_logic;
        ARESETN                     : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        S_AXIS_TUSER                : in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                : out std_logic;
        M_AXIS_TUSER                : out std_logic_vector(6 downto 0)
    );
    end component;

    signal width_reg_axis_tvalid    : std_logic;
    signal width_reg_axis_tready    : std_logic;
    signal width_reg_axis_tdata     : std_logic_vector(63 downto 0);
    signal width_reg_axis_tkeep     : std_logic_vector(7 downto 0);
    signal width_reg_axis_tlast     : std_logic;

    component AXIS_CLOCK_UP is
    port (
        S_AXIS_ARESETN              : in  std_logic;
        M_AXIS_ARESETN              : in  std_logic;
        S_AXIS_ACLK                 : in  std_logic;
        S_AXIS_TVALID               : in  std_logic;
        S_AXIS_TREADY               : out std_logic;
        S_AXIS_TDATA                : in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                : in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                : in  std_logic;
        M_AXIS_ACLK                 : in  std_logic;
        M_AXIS_TVALID               : out std_logic;
        M_AXIS_TREADY               : in  std_logic;
        M_AXIS_TDATA                : out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                : out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                : out std_logic
    );
    end component;

begin

    reset_n     <= not ARESET;

    in_keep_rev <= IN_KEEP(0) & IN_KEEP(1) & IN_KEEP(2) & IN_KEEP(3);
    in_data_rev <= IN_DATA(7 downto 0) & IN_DATA(15 downto 8) & IN_DATA(23 downto 16) & IN_DATA(31 downto 24);

--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_ADAPT : AXIS_READY_ADAPT
    port map(
        S_AXIS_ARESETN              => reset_n                                 ,--: in  std_logic;
        S_AXIS_ACLK                 => IN_CLK                                  ,--: in  std_logic;
        S_AXIS_TVALID               => IN_VALID                                ,--: in  std_logic;
        S_AXIS_TREADY               => IN_READY                                ,--: out std_logic;
        S_AXIS_TDATA                => in_data_rev                             ,--: in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                => in_keep_rev                             ,--: in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                => IN_LAST                                 ,--: in  std_logic;
        M_AXIS_TVALID               => adapt_axis_tvalid                       ,--: out std_logic;
        M_AXIS_TREADY               => adapt_axis_tready                       ,--: in  std_logic;
        M_AXIS_TDATA                => adapt_axis_tdata                        ,--: out std_logic_vector(31 downto 0);
        M_AXIS_TKEEP                => adapt_axis_tkeep                        ,--: out std_logic_vector(3 downto 0);
        M_AXIS_TLAST                => adapt_axis_tlast                         --: out std_logic
    );

    u_WIDTH : AXIS_WIDTH_UP
    port map(
        ACLK                        => IN_CLK                                  ,--: in  std_logic;
        ARESETN                     => reset_n                                 ,--: in  std_logic;
        S_AXIS_TVALID               => adapt_axis_tvalid                       ,--: in  std_logic;
        S_AXIS_TREADY               => adapt_axis_tready                       ,--: out std_logic;
        S_AXIS_TDATA                => adapt_axis_tdata                        ,--: in  std_logic_vector(31 downto 0);
        S_AXIS_TKEEP                => adapt_axis_tkeep                        ,--: in  std_logic_vector(3 downto 0);
        S_AXIS_TLAST                => adapt_axis_tlast                        ,--: in  std_logic;
        M_AXIS_TVALID               => width_axis_tvalid                       ,--: out std_logic;
        M_AXIS_TREADY               => width_axis_tready                       ,--: in  std_logic;
        M_AXIS_TDATA                => width_axis_tdata                        ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                => width_axis_tkeep                        ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                => width_axis_tlast                         --: out std_logic
    );

    u_WIDTH_REG : AXIS_REG_64
    port map(
        ACLK                        => IN_CLK                                  ,--: in  std_logic;
        ARESETN                     => reset_n                                 ,--: in  std_logic;
        S_AXIS_TVALID               => width_axis_tvalid                       ,--: in  std_logic;
        S_AXIS_TREADY               => width_axis_tready                       ,--: out std_logic;
        S_AXIS_TDATA                => width_axis_tdata                        ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                => width_axis_tkeep                        ,--: in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                => width_axis_tlast                        ,--: in  std_logic;
        S_AXIS_TUSER                => (others => '0')                         ,--: in  std_logic_vector(6 downto 0);
        M_AXIS_TVALID               => width_reg_axis_tvalid                   ,--: out std_logic;
        M_AXIS_TREADY               => width_reg_axis_tready                   ,--: in  std_logic;
        M_AXIS_TDATA                => width_reg_axis_tdata                    ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                => width_reg_axis_tkeep                    ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                => width_reg_axis_tlast                    ,--: out std_logic;
        M_AXIS_TUSER                => open                                     --: out std_logic_vector(6 downto 0)
    );

    u_CLOCK : AXIS_CLOCK_UP
    port map(
        S_AXIS_ARESETN              => reset_n                                 ,--: in  std_logic;
        M_AXIS_ARESETN              => reset_n                                 ,--: in  std_logic;
        S_AXIS_ACLK                 => IN_CLK                                  ,--: in  std_logic;
        S_AXIS_TVALID               => width_reg_axis_tvalid                   ,--: in  std_logic;
        S_AXIS_TREADY               => width_reg_axis_tready                   ,--: out std_logic;
        S_AXIS_TDATA                => width_reg_axis_tdata                    ,--: in  std_logic_vector(63 downto 0);
        S_AXIS_TKEEP                => width_reg_axis_tkeep                    ,--: in  std_logic_vector(7 downto 0);
        S_AXIS_TLAST                => width_reg_axis_tlast                    ,--: in  std_logic;
        M_AXIS_ACLK                 => OUT_CLK                                 ,--: in  std_logic;
        M_AXIS_TVALID               => OUT_VALID                               ,--: out std_logic;
        M_AXIS_TREADY               => OUT_READY                               ,--: in  std_logic;
        M_AXIS_TDATA                => OUT_DATA                                ,--: out std_logic_vector(63 downto 0);
        M_AXIS_TKEEP                => OUT_KEEP                                ,--: out std_logic_vector(7 downto 0);
        M_AXIS_TLAST                => OUT_LAST                                 --: out std_logic
    );

end BEHAVE;