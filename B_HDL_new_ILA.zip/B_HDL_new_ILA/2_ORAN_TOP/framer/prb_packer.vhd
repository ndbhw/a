--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2020, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : PRB packer (xRAN component)                                   --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : Hardware R&D Group 1 (Network Division)                       --
-- Release    : 2020.04.15                                                    --
--                                                                            --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

use WORK.PKG_O_RAN.ALL;

entity PRB_PACKER is
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RST                         : in  std_logic;

--------------------------------------------------------------------------------
-- Control
--------------------------------------------------------------------------------

        DST_MAC                     : in  std_logic_vector(47 downto 0);
        SRC_MAC                     : in  std_logic_vector(47 downto 0);
        VLAN0_MODE                  : in  std_logic;                            -- 0 : Untagged, 1 : Tagged
        VLAN0_TCI                   : in  std_logic_vector(15 downto 0);
        VLAN1_MODE                  : in  std_logic;                            -- 0 : Untagged, 1 : Tagged
        VLAN1_TCI                   : in  std_logic_vector(15 downto 0);

        COMP_MODE                   : in  std_logic;

--------------------------------------------------------------------------------
-- RB header
--------------------------------------------------------------------------------

        RB_eAxC_ID                  : in  std_logic_vector(15 downto 0);
        RB_SEQUENCE_ID              : in  std_logic_vector(15 downto 0);
        RB_HEADER_APP               : in  std_logic_vector(31 downto 0);
        RB_HEADER_APP_ACK           : out std_logic;
        RB_HEADER_SEC               : in  std_logic_vector(31 downto 0);
        RB_HEADER_SEC_ACK           : out std_logic;

--------------------------------------------------------------------------------
-- Compression block
--------------------------------------------------------------------------------

        COMP_HDR                    : in  std_logic_vector(7 downto 0);
        COMP_PARAM                  : in  std_logic_vector(7 downto 0);

        COMP_VALID                  : in  std_logic;
        COMP_TICK                   : in  std_logic;
        COMP_DATA_I                 : in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : in  std_logic_vector(15 downto 0);
        COMP_USER                   : in  std_logic_vector(15 downto 0);

--------------------------------------------------------------------------------
-- Packet generator
--------------------------------------------------------------------------------

        PACK_LENGTH                 : out std_logic_vector(15 downto 0);

        PACK_VALID                  : out std_logic;
        PACK_START                  : out std_logic;
        PACK_LAST                   : out std_logic;
        PACK_KEEP                   : out std_logic_vector(3 downto 0);
        PACK_DATA                   : out std_logic_vector(31 downto 0)
    );
end PRB_PACKER;

architecture BEHAVE of PRB_PACKER is

    component PRB_N_TO_32 is
    generic (
        UNCOMP_1B                   : boolean := true;
        UNCOMP_2B                   : boolean := true;
        UNCOMP_3B                   : boolean := true;
        UNCOMP_4B                   : boolean := true;
        UNCOMP_5B                   : boolean := true;
        UNCOMP_6B                   : boolean := true;
        UNCOMP_7B                   : boolean := true;
        UNCOMP_8B                   : boolean := true;
        UNCOMP_9B                   : boolean := true;
        UNCOMP_10B                  : boolean := true;
        UNCOMP_11B                  : boolean := true;
        UNCOMP_12B                  : boolean := true;
        UNCOMP_13B                  : boolean := true;
        UNCOMP_14B                  : boolean := true;
        UNCOMP_15B                  : boolean := true;
        UNCOMP_16B                  : boolean := true;
        COMP_1B                     : boolean := true;
        COMP_2B                     : boolean := true;
        COMP_3B                     : boolean := true;
        COMP_4B                     : boolean := true;
        COMP_5B                     : boolean := true;
        COMP_6B                     : boolean := true;
        COMP_7B                     : boolean := true;
        COMP_8B                     : boolean := true;
        COMP_9B                     : boolean := true;
        COMP_10B                    : boolean := true;
        COMP_11B                    : boolean := true;
        COMP_12B                    : boolean := true;
        COMP_13B                    : boolean := true;
        COMP_14B                    : boolean := true;
        COMP_15B                    : boolean := true;
        COMP_16B                    : boolean := true
    );
    port (
        CLK                         : in  std_logic;
        RST                         : in  std_logic;

        COMP_HDR                    : in  std_logic_vector(7 downto 0);
        COMP_PARAM                  : in  std_logic_vector(7 downto 0);

        COMP_VALID                  : in  std_logic;
        COMP_TICK                   : in  std_logic;
        COMP_DATA_I                 : in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 : in  std_logic_vector(15 downto 0);
        COMP_USER                   : in  std_logic_vector(15 downto 0);

        PRB_COMP_HDR                : out std_logic_vector(7 downto 0);

        PRB_VALID                   : out std_logic;
        PRB_TICK                    : out std_logic;
        PRB_KEEP                    : out std_logic_vector(3 downto 0);
        PRB_DATA                    : out std_logic_vector(31 downto 0);
        PRB_USER                    : out std_logic_vector(15 downto 0)
    );
    end component;

    signal conv_valid               : std_logic;
    signal conv_tick                : std_logic;
    signal conv_keep                : std_logic_vector(3 downto 0);
    signal conv_data                : std_logic_vector(31 downto 0);
    signal conv_user                : std_logic_vector(15 downto 0);

    type fsm                        is (IDLE, HDR_APP, HDR_SEC, HDR_COMP, PRB);
    signal fsm_tx                   : fsm;
    signal cnt_tx_state             : std_logic_vector(3 downto 0);

    signal buf_valid                : std_logic;
    signal buf_tick                 : std_logic;
    signal buf_last                 : std_logic;
    signal buf_end                  : std_logic;
    signal buf_keep                 : std_logic_vector(3 downto 0);
    signal buf_data                 : std_logic_vector(31 downto 0);

    signal prb_valid                : std_logic;
    signal prb_tick                 : std_logic;
    signal prb_last                 : std_logic;
    signal prb_end                  : std_logic;
    signal prb_keep                 : std_logic_vector(3 downto 0);
    signal prb_data                 : std_logic_vector(31 downto 0);

    signal not_aligned_valid        : std_logic;
    signal not_aligned_tick         : std_logic;
    signal not_aligned_last         : std_logic;
    signal not_aligned_end          : std_logic;
    signal not_aligned_keep         : std_logic_vector(3 downto 0);
    signal not_aligned_data         : std_logic_vector(31 downto 0);

    signal align_position           : std_logic_vector(1 downto 0) := (others => '0');
    signal merged_tick              : std_logic := '0';
    signal merged_valid             : std_logic := '0';
    signal merged_start             : std_logic := '0';
    signal merged_end               : std_logic := '0';
    signal merged_keep              : std_logic_vector(3 downto 0) := (others => '0');
    signal merged_data              : std_logic_vector(31 downto 0) := (others => '0');

    signal merged_init              : std_logic := '0';
    signal merged_bytes             : std_logic_vector(15 downto 0) := (others => '0');

    component BYTE_ALIGN is
    port (
        CLK                         : in  std_logic;

        ALIGN_START                 : in  std_logic;
        ALIGN_POSITION              : in  std_logic_vector(1 downto 0);

        VALID_IN                    : in  std_logic;
        LAST_IN                     : in  std_logic;
        KEEP_IN                     : in  std_logic_vector(3 downto 0);
        DATA_IN                     : in  std_logic_vector(31 downto 0);

        VALID_OUT                   : out std_logic;
        LAST_OUT                    : out std_logic;
        KEEP_OUT                    : out std_logic_vector(3 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
    end component;

    signal aligned_prb_valid        : std_logic;
    signal aligned_prb_start        : std_logic_vector(2 downto 0) := (others => '0');
    signal aligned_prb_end          : std_logic;
    signal aligned_prb_keep         : std_logic_vector(3 downto 0);
    signal aligned_prb_data         : std_logic_vector(31 downto 0);

begin

--------------------------------------------------------------------------------
-- Conversion
--------------------------------------------------------------------------------

    u_N_to_32 : PRB_N_TO_32
    generic map(
        UNCOMP_1B                   => TX_UNCOMP_1B                            ,--: boolean := true;
        UNCOMP_2B                   => TX_UNCOMP_2B                            ,--: boolean := true;
        UNCOMP_3B                   => TX_UNCOMP_3B                            ,--: boolean := true;
        UNCOMP_4B                   => TX_UNCOMP_4B                            ,--: boolean := true;
        UNCOMP_5B                   => TX_UNCOMP_5B                            ,--: boolean := true;
        UNCOMP_6B                   => TX_UNCOMP_6B                            ,--: boolean := true;
        UNCOMP_7B                   => TX_UNCOMP_7B                            ,--: boolean := true;
        UNCOMP_8B                   => TX_UNCOMP_8B                            ,--: boolean := true;
        UNCOMP_9B                   => TX_UNCOMP_9B                            ,--: boolean := true;
        UNCOMP_10B                  => TX_UNCOMP_10B                           ,--: boolean := true;
        UNCOMP_11B                  => TX_UNCOMP_11B                           ,--: boolean := true;
        UNCOMP_12B                  => TX_UNCOMP_12B                           ,--: boolean := true;
        UNCOMP_13B                  => TX_UNCOMP_13B                           ,--: boolean := true;
        UNCOMP_14B                  => TX_UNCOMP_14B                           ,--: boolean := true;
        UNCOMP_15B                  => TX_UNCOMP_15B                           ,--: boolean := true;
        UNCOMP_16B                  => TX_UNCOMP_16B                           ,--: boolean := true;
        COMP_1B                     => TX_COMP_1B                              ,--: boolean := true;
        COMP_2B                     => TX_COMP_2B                              ,--: boolean := true;
        COMP_3B                     => TX_COMP_3B                              ,--: boolean := true;
        COMP_4B                     => TX_COMP_4B                              ,--: boolean := true;
        COMP_5B                     => TX_COMP_5B                              ,--: boolean := true;
        COMP_6B                     => TX_COMP_6B                              ,--: boolean := true;
        COMP_7B                     => TX_COMP_7B                              ,--: boolean := true;
        COMP_8B                     => TX_COMP_8B                              ,--: boolean := true;
        COMP_9B                     => TX_COMP_9B                              ,--: boolean := true;
        COMP_10B                    => TX_COMP_10B                             ,--: boolean := true;
        COMP_11B                    => TX_COMP_11B                             ,--: boolean := true;
        COMP_12B                    => TX_COMP_12B                             ,--: boolean := true;
        COMP_13B                    => TX_COMP_13B                             ,--: boolean := true;
        COMP_14B                    => TX_COMP_14B                             ,--: boolean := true;
        COMP_15B                    => TX_COMP_15B                             ,--: boolean := true;
        COMP_16B                    => TX_COMP_16B                              --: boolean := true
    )
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;
        RST                         => RST                                     ,--: in  std_logic;

        COMP_HDR                    => COMP_HDR                                ,--: in  std_logic_vector(7 downto 0);
        COMP_PARAM                  => COMP_PARAM                              ,--: in  std_logic_vector(7 downto 0);

        COMP_VALID                  => COMP_VALID                              ,--: in  std_logic;
        COMP_TICK                   => COMP_TICK                               ,--: in  std_logic;
        COMP_DATA_I                 => COMP_DATA_I                             ,--: in  std_logic_vector(15 downto 0);
        COMP_DATA_Q                 => COMP_DATA_Q                             ,--: in  std_logic_vector(15 downto 0);
        COMP_USER                   => COMP_USER                               ,--: in  std_logic_vector(15 downto 0);

        PRB_COMP_HDR                => open                                    ,--: out std_logic_vector(7 downto 0);

        PRB_VALID                   => conv_valid                              ,--: out std_logic;
        PRB_TICK                    => conv_tick                               ,--: out std_logic;
        PRB_KEEP                    => conv_keep                               ,--: out std_logic_vector(3 downto 0);
        PRB_DATA                    => conv_data                               ,--: out std_logic_vector(31 downto 0);
        PRB_USER                    => conv_user                                --: out std_logic_vector(15 downto 0)
    );

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            buf_valid <= conv_valid;
            buf_tick  <= conv_tick;
            buf_last  <= conv_user(1);
            buf_end   <= conv_user(2);
            buf_keep  <= conv_keep;
            buf_data  <= conv_data;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            prb_valid <= buf_valid;
            prb_tick  <= buf_tick;
            if (conv_valid = '0') and (buf_valid = '1') then
                prb_last  <= buf_last;
                prb_end   <= buf_end;
            else
                prb_last  <= '0';
                prb_end   <= '0';
            end if;
            prb_keep  <= buf_keep;
            prb_data  <= buf_data;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            not_aligned_valid <= prb_valid;
            not_aligned_tick  <= prb_tick;
            not_aligned_last  <= prb_last;
            not_aligned_end   <= prb_end;
            not_aligned_keep  <= prb_keep;
            not_aligned_data  <= prb_data;
        end if;
    end process;

--------------------------------------------------------------------------------
-- TX
--------------------------------------------------------------------------------

    process (RST, CLK)
    begin
        if (RST = '1') then
            fsm_tx <= IDLE;
        elsif (CLK'event and CLK = '1') then
            case fsm_tx is
            when IDLE     =>
                if (COMP_TICK = '1') then
                    fsm_tx <= HDR_APP;
                else
                    fsm_tx <= IDLE;
                end if;
            when HDR_APP  =>
                if (cnt_tx_state = 8) then
                    fsm_tx <= HDR_SEC;
                else
                    fsm_tx <= HDR_APP;
                end if;
            when HDR_SEC  =>
                if (conv_tick = '1') then
                    if (COMP_MODE = '0') then
                        fsm_tx <= PRB;
                    else
                        fsm_tx <= HDR_COMP;
                    end if;
                else
                    fsm_tx <= HDR_SEC;
                end if;
            when HDR_COMP =>
                fsm_tx <= PRB;
            when PRB      =>
                if (not_aligned_last = '1') then
                    if (not_aligned_end = '1') then
                        fsm_tx <= IDLE;
                    else
                        fsm_tx <= HDR_SEC;
                    end if;
                else
                    fsm_tx <= PRB;
                end if;
            when others   =>
                fsm_tx <= IDLE;
            end case;
        end if;
    end process;

    process (RST, CLK)
    begin
        if (RST = '1') then
            cnt_tx_state <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            case fsm_tx is
            when HDR_APP  =>
                cnt_tx_state <= cnt_tx_state + 1;
            when others   =>
                cnt_tx_state <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_tx is
            when HDR_APP  =>
                if (cnt_tx_state = 8) then
                    RB_HEADER_APP_ACK <= '1';
                    RB_HEADER_SEC_ACK <= '0';
                else
                    RB_HEADER_APP_ACK <= '0';
                    RB_HEADER_SEC_ACK <= '0';
                end if;
            when HDR_SEC  =>
                RB_HEADER_APP_ACK <= '0';
                RB_HEADER_SEC_ACK <= conv_tick;
            when others   =>
                RB_HEADER_APP_ACK <= '0';
                RB_HEADER_SEC_ACK <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_tx is
            when HDR_APP  =>
                if    (VLAN0_MODE = '1') and (VLAN1_MODE = '0') then
                    if    (cnt_tx_state = 0) then
                        merged_tick  <= '1';
                        merged_valid <= '1';
                        merged_start <= '1';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(47 downto 16);
                    elsif (cnt_tx_state = 1) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(15 downto 0) & SRC_MAC(47 downto 32);
                    elsif (cnt_tx_state = 2) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= SRC_MAC(31 downto 0);
                    elsif (cnt_tx_state = 3) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"8100" & VLAN0_TCI;
                    elsif (cnt_tx_state = 4) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"AEFE1000";
                    elsif (cnt_tx_state = 5) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"0000" & RB_eAxC_ID;
                    elsif (cnt_tx_state = 6) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= RB_SEQUENCE_ID & RB_HEADER_APP(31 downto 16);
                    elsif (cnt_tx_state = 7) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1100";
                        merged_data  <= RB_HEADER_APP(15 downto 0) & x"0000";
                    else
                        merged_tick  <= '0';
                        merged_valid <= '0';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= (others => '0');
                        merged_data  <= (others => '0');
                    end if;
                elsif (VLAN0_MODE = '1') and (VLAN1_MODE = '1') then
                    if    (cnt_tx_state = 0) then
                        merged_tick  <= '1';
                        merged_valid <= '1';
                        merged_start <= '1';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(47 downto 16);
                    elsif (cnt_tx_state = 1) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(15 downto 0) & SRC_MAC(47 downto 32);
                    elsif (cnt_tx_state = 2) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= SRC_MAC(31 downto 0);
                    elsif (cnt_tx_state = 3) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"8100" & VLAN0_TCI;
                    elsif (cnt_tx_state = 4) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"8100" & VLAN1_TCI;
                    elsif (cnt_tx_state = 5) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"AEFE1000";
                    elsif (cnt_tx_state = 6) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"0000" & RB_eAxC_ID;
                    elsif (cnt_tx_state = 7) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= RB_SEQUENCE_ID & RB_HEADER_APP(31 downto 16);
                    elsif (cnt_tx_state = 8) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1100";
                        merged_data  <= RB_HEADER_APP(15 downto 0) & x"0000";
                    else
                        merged_tick  <= '0';
                        merged_valid <= '0';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= (others => '0');
                        merged_data  <= (others => '0');
                    end if;
                else
                    if    (cnt_tx_state = 0) then
                        merged_tick  <= '1';
                        merged_valid <= '1';
                        merged_start <= '1';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(47 downto 16);
                    elsif (cnt_tx_state = 1) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= DST_MAC(15 downto 0) & SRC_MAC(47 downto 32);
                    elsif (cnt_tx_state = 2) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= SRC_MAC(31 downto 0);
                    elsif (cnt_tx_state = 3) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"AEFE1000";
                    elsif (cnt_tx_state = 4) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= x"0000" & RB_eAxC_ID;
                    elsif (cnt_tx_state = 5) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1111";
                        merged_data  <= RB_SEQUENCE_ID & RB_HEADER_APP(31 downto 16);
                    elsif (cnt_tx_state = 6) then
                        merged_tick  <= '0';
                        merged_valid <= '1';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= "1100";
                        merged_data  <= RB_HEADER_APP(15 downto 0) & x"0000";
                    else
                        merged_tick  <= '0';
                        merged_valid <= '0';
                        merged_start <= '0';
                        merged_end   <= '0';
                        merged_keep  <= (others => '0');
                        merged_data  <= (others => '0');
                    end if;
                end if;
            when HDR_SEC  =>
                if (conv_tick = '1') then
                    merged_tick  <= '1';
                    merged_valid <= '1';
                    merged_start <= '0';
                    merged_end   <= '0';
                    merged_keep  <= "1111";
                    merged_data  <= RB_HEADER_SEC;
                else
                    merged_tick  <= '0';
                    merged_valid <= '0';
                    merged_start <= '0';
                    merged_end   <= '0';
                    merged_keep  <= (others => '0');
                    merged_data  <= (others => '0');
                end if;
            when HDR_COMP =>
                merged_tick  <= '0';
                merged_valid <= '1';
                merged_start <= '0';
                merged_end   <= '0';
                merged_keep  <= "1100";
                merged_data  <= COMP_HDR & x"000000";
            when PRB      =>
                merged_tick  <= not_aligned_tick;
                merged_valid <= not_aligned_valid;
                merged_start <= '0';
                merged_end   <= not_aligned_end;
                merged_keep  <= not_aligned_keep;
                merged_data  <= not_aligned_data;
            when others   =>
                merged_tick  <= '0';
                merged_valid <= '0';
                merged_start <= '0';
                merged_end   <= '0';
                merged_keep  <= (others => '0');
                merged_data  <= (others => '0');
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            case fsm_tx is
            when HDR_APP  =>
                merged_init <= '1';
            when others   =>
                merged_init <= '0';
            end case;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (merged_init = '1') then
                merged_bytes <= x"0008";
            else
                if    (merged_keep = x"F") then
                    merged_bytes <= merged_bytes + 4;
                elsif (merged_keep = x"E") or (merged_keep = x"7") then
                    merged_bytes <= merged_bytes + 3;
                elsif (merged_keep = x"C") or (merged_keep = x"3") then
                    merged_bytes <= merged_bytes + 2;
                elsif (merged_keep = x"8") or (merged_keep = x"1") then
                    merged_bytes <= merged_bytes + 1;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (merged_end = '1') then
                if    (merged_keep = x"F") then
                    PACK_LENGTH <= merged_bytes + 4;
                elsif (merged_keep = x"E") or (merged_keep = x"7") then
                    PACK_LENGTH <= merged_bytes + 3;
                elsif (merged_keep = x"C") or (merged_keep = x"3") then
                    PACK_LENGTH <= merged_bytes + 2;
                elsif (merged_keep = x"8") or (merged_keep = x"1") then
                    PACK_LENGTH <= merged_bytes + 1;
                end if;
            end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (merged_end = '1') then
                align_position <= "00";
            else
                if    (merged_keep = x"E") then
                    align_position <= align_position + 3;
                elsif (merged_keep = x"C") then
                    align_position <= align_position + 2;
                elsif (merged_keep = x"8") then
                    align_position <= align_position + 1;
                end if;
            end if;
        end if;
    end process;

    u_ALIGN : BYTE_ALIGN
    port map(
        CLK                         => CLK                                     ,--: in  std_logic;

        ALIGN_START                 => merged_tick                             ,--: in  std_logic;
        ALIGN_POSITION              => align_position                          ,--: in  std_logic_vector(1 downto 0);

        VALID_IN                    => merged_valid                            ,--: in  std_logic;
        LAST_IN                     => merged_end                              ,--: in  std_logic;
        KEEP_IN                     => merged_keep                             ,--: in  std_logic_vector(3 downto 0);
        DATA_IN                     => merged_data                             ,--: in  std_logic_vector(31 downto 0);

        VALID_OUT                   => aligned_prb_valid                       ,--: out std_logic;
        LAST_OUT                    => aligned_prb_end                         ,--: out std_logic;
        KEEP_OUT                    => aligned_prb_keep                        ,--: out std_logic_vector(3 downto 0);
        DATA_OUT                    => aligned_prb_data                         --: out std_logic_vector(31 downto 0)
    );

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            aligned_prb_start <= aligned_prb_start(1 downto 0) & merged_start;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            PACK_VALID <= aligned_prb_valid;
            PACK_START <= aligned_prb_start(2);
            PACK_LAST  <= aligned_prb_end;
            PACK_KEEP  <= aligned_prb_keep;
            PACK_DATA  <= aligned_prb_data;
        end if;
    end process;

end BEHAVE;