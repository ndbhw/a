//////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : VzW RT8808
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_ifft_map_buf
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe IFFT Mapper (RE to Subcarrier) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.04 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Add Calibraion Control Relay
//  ------------+---------------+-----------------------------------------------
//   2021.02.10 | jyzoo.lee     | CPRI Support
//  ------------+---------------+-----------------------------------------------
//   2021.03.05 | jyzoo.lee     | Redesigned for AIE Packet Mux
//  ------------+---------------+-----------------------------------------------
//   2021.05.18 | jyzoo.lee     | Optimized Memory for AIE IFFT Interface 
//  ------------+---------------+-----------------------------------------------
//   2021.07.12 | jyzoo.lee     | AIE 1K,2K IFFT Support
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//   2022.01.21 | jyzoo.lee     | Add AIE Protection
//  ------------+---------------+-----------------------------------------------
//   2022.03.16 | jyzoo.lee     | Add Packet Termination for AIE Recovery
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_ifft_map_buf
#(
     parameter  NUM_CC              =   1           
    ,parameter  NUM_ANT             =   4
    ,parameter  NUM_I_CHAIN         =   1
    ,parameter  NUM_O_CHAIN         =   1
    ,parameter  MAX_NIFFT           =   2048 
    ,parameter  DI_BW               =   16           
    ,parameter  DO_BW               =   16           
    ,parameter  VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  
            
    //--- from dlfe_param_if
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_1204
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_120c
    ,   input   wire    [NUM_ANT*NUM_CC-1:0]                    i_dlfe_par_124c
    
    //--- from dlfe_phase_comp
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_slot_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_I_CHAIN-1:0] i_din_cc_id
    ,   input   wire    [$clog2(NUM_ANT)*NUM_I_CHAIN-1:0]       i_din_ant_id
    ,   input   wire    [04-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_ofdm_mod
    ,   output  reg     [01-1:0]                                o_dout_frame_sync 
    ,   output  reg     [01-1:0]                                o_dout_subfrm_sync
    ,   output  reg     [01-1:0]                                o_dout_symbol_sync
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_en
    ,   output  reg     [2*DO_BW*NUM_O_CHAIN-1:0]               o_dout_iq
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_O_CHAIN-1:0] o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_O_CHAIN-1:0]       o_dout_ant_id
    ,   output  reg     [04-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size
    ,   output  reg     [02-1:0]                                o_dout_cal_en
);

//Parameter Local Logic
localparam                                  CC_REF                  =   0                                               ;
localparam                                  CHAIN_REF               =   0                                               ;
localparam                                  NUM_CBUF                =   2                                               ;
localparam                                  ORAN_FFT0512            =   4'h9                                            ;
localparam                                  ORAN_FFT1024            =   4'ha                                            ;
localparam                                  ORAN_FFT2048            =   4'hb                                            ;
localparam                                  ORAN_FFT4096            =   4'hc                                            ;
localparam                                  NFFT_0512               =   13'd512                                         ;
localparam                                  NFFT_1024               =   13'd1024                                        ;
localparam                                  NFFT_2048               =   13'd2048                                        ;
localparam                                  NFFT_4096               =   13'd4096                                        ;
localparam                                  BW_DLY_RD_SYNC          =   $clog2(32768)                                   ;
localparam [22-1:0]                         LEN_NSYM_015K           =   17536                                           ;
localparam [$clog2(LEN_NSYM_015K/2)-1:0]    LEN_NSYM_015K_LAT       =   LEN_NSYM_015K*3/4                               ;

`ifndef DLFE_AIE_DISABLE 
localparam                                  BW_MEM_DATA             =   72                                              ;
localparam                                  MEM_DEPTH               =   NFFT_1024*2                                     ;
localparam                                  BW_MEM_ADDR             =   $clog2(NFFT_1024*2)                             ;
localparam integer                          NUM_MEM                 =   $ceil((2*DO_BW*NUM_ANT)/(BW_MEM_DATA*1.0))      ;
localparam                                  NUM_PKT_AXIS            =   8                                               ;
localparam                                  NUM_S2P_AXIS            =   4                                               ;
localparam                                  SIZE_MEM_PKT            =   NFFT_1024                                       ;
localparam                                  SIZE_AIE_PKT            =   NFFT_0512                                       ;
localparam                                  GAP_PKT                 =   6                                               ;
localparam                                  NUM_RE_RB               =   4'd12                                           ;
localparam [22-1:0]                         LEN_FRAME_TOL_L         =   2457600-10                                      ;
localparam [22-1:0]                         LEN_FRAME_TOL_H         =   2457600+10                                      ;
`else//DLFE_AIE_DISABLE
localparam [$clog2(MAX_NIFFT):0]            SIZE_PKT                =   MAX_NIFFT                                       ;
`endif//DLFE_AIE_DISABLE
`ifndef DLFE_ORAN_DISABLE
localparam [BW_DLY_RD_SYNC-1:0]             RD_SYNC_OFFSET          =   0                                               ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_SYNC                =   MAX_NIFFT+16                                    ;
`else// DLFE_ORAN_DISABLE
localparam [BW_DLY_RD_SYNC-1:0]             RD_SYNC_OFFSET          =   273*12*2                                        ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_SYNC                =   RD_SYNC_OFFSET+7                                ;
`endif// DLFE_ORAN_DISABLE
localparam [BW_DLY_RD_SYNC-1:0]             GAP_SYMBOL              =   10                                              ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_NIFFT_0512          =   VENDOR=="Intel" ? 1548 : (MAX_NIFFT==NFFT_4096) ? 3603 : (MAX_NIFFT==NFFT_2048) ? 1681 : 0   ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_NIFFT_1024          =   VENDOR=="Intel" ? 1205 : (MAX_NIFFT==NFFT_4096) ? 3091 : (MAX_NIFFT==NFFT_2048) ? 1169 : 0   ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_NIFFT_2048          =   VENDOR=="Intel" ? 0    : (MAX_NIFFT==NFFT_4096) ? 2048 : (MAX_NIFFT==NFFT_2048) ? 0    : 0   ;
localparam [BW_DLY_RD_SYNC-1:0]             DLY_NIFFT_4096          =   VENDOR=="Intel" ? 0    : (MAX_NIFFT==NFFT_4096) ? 0    : (MAX_NIFFT==NFFT_2048) ? 0    : 0   ;

//Logic Variable
integer i       ;
genvar  gidx    ;

reg         r_frame_sync    ;
reg [3:0]   r_symbol        ;
always@(posedge i_clk) begin
    r_frame_sync <= i_din_frame_sync ;
    if(i_din_symbol_sync) begin
        if(i_din_slot_sync) begin
            r_symbol <= 4'd0 ;
        end
        else begin
            r_symbol <= r_symbol + 1'd1 ;
        end
    end
end
reg     [3:0]                   r_mu                            ;
reg     [12-1:0]                r_k0            [NUM_CC-1:0]    ;
reg     [12-1:0]                r_ntone         [NUM_CC-1:0]    ;
reg     [NUM_ANT-1:0]           r_ant_gate      [NUM_CC-1:0]    ;
reg     [3:0]                   r_fft_size      [NUM_CC-1:0]    ;
reg     [BW_DLY_RD_SYNC-1:0]    r_fft_offset    [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin
        for(i=0;i<NUM_CC;i=i+1) begin
            case(i_din_fft_size[((04)*(i+1)-1)-:(04)]) 
                ORAN_FFT0512    :   r_fft_offset[i] <= DLY_NIFFT_0512    ;
                ORAN_FFT1024    :   r_fft_offset[i] <= DLY_NIFFT_1024    ;
                ORAN_FFT2048    :   r_fft_offset[i] <= DLY_NIFFT_2048    ; 
                ORAN_FFT4096    :   r_fft_offset[i] <= DLY_NIFFT_4096    ; 
                default         :   r_fft_offset[i] <= DLY_NIFFT_4096    ; 
            endcase
        end
    end
end
always@(*) begin
    r_mu = i_din_mu ;
    for(i=0;i<NUM_CC;i=i+1) begin
        r_fft_size  [i] =  i_din_fft_size  [((04)*(i+1)-1)-:(04)]  ;
        r_k0        [i] =  i_dlfe_par_1204 [((12)*(i+1)-1)-:(12)]  ;
        r_ntone     [i] =  i_dlfe_par_120c [((12)*(i+1)-1)-:(12)]  ;
        r_ant_gate  [i] =  i_dlfe_par_124c [((NUM_ANT)*(i+1)-1)-:(NUM_ANT)]  ;
    end
end

`ifndef DLFE_AIE_DISABLE
reg [0:0]  r_event_n ;
`ifndef DLFE_WDOG_DISABLE
wire [21:0] w_frame_sync_diff ;
ylib_mon_sync_diff #(
    .WIDTH(22)) 
u00_0_frame_sync_chk
(
     .i_clk     (   i_clk               )
    ,.i_sync0   (   r_frame_sync        )
    ,.i_sync1   (   i_din_frame_sync    )
    ,.o_diff    (   w_frame_sync_diff   )
);
reg [4-1:0]  r_prev_fft_size ;
reg [12-1:0] r_prev_ntone    ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        r_prev_fft_size <= r_fft_size [CC_REF] ;
        r_prev_ntone    <= r_ntone    [CC_REF] ;
    end
end
always@(posedge i_clk) begin
    if(o_dout_frame_sync) begin 
        r_event_n   <= (r_fft_size[CC_REF]==r_prev_fft_size) && (r_ntone[CC_REF]==r_prev_ntone) && (r_ntone[CC_REF]!=12'd0) && (w_frame_sync_diff>LEN_FRAME_TOL_L&&w_frame_sync_diff<LEN_FRAME_TOL_H);
    end
end
`else //DLFE_WDOG_DISABLE
always@(posedge i_clk) begin
    if(o_dout_frame_sync) begin 
        r_event_n   <= 1'b1 ;
    end
end
`endif //DLFE_WDOG_DISABLE
reg     [1-1:0]                         r_en            [NUM_ANT-1:0]       ;
reg     [1-1:0]                         rr_en           [NUM_ANT-1:0]       ;
reg     [(`mlib_clog2(NUM_CC))-1:0]     r_cc_id         [NUM_ANT-1:0]       ;
reg     [$clog2(NUM_ANT)-1:0]           r_ant_id        [NUM_ANT-1:0]       ;
reg     [1-1:0]                         r_din_en        [NUM_I_CHAIN-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]         r_wr_addr       [NUM_I_CHAIN-1:0]   ;
reg     [2*DI_BW-1:0]                   r_iq            [NUM_I_CHAIN-1:0]   ;
wire    [(`mlib_clog2(NUM_CC))-1:0]     w_din_cc_id     [NUM_I_CHAIN-1:0]   ;
wire    [$clog2(NUM_ANT)-1:0]           w_din_ant_id    [NUM_I_CHAIN-1:0]   ;
reg     [2*DI_BW*NUM_ANT-1:0]           rr_iq                               ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_0_mem_wr_ctrl
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_ant_id[(($clog2(NUM_ANT))*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:($clog2(NUM_ANT))]==({{$clog2(NUM_ANT)}{1'b1}}&gidx) ? i_din_en[((01)*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:(01)] : 1'd0 ;
end
always@(*) begin
    r_cc_id [gidx] = i_din_cc_id [((`mlib_clog2(NUM_CC))*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:`mlib_clog2(NUM_CC)] ;
    r_ant_id[gidx] = ({{$clog2(NUM_ANT)}{1'b1}}&gidx) ;
end
if(gidx%(NUM_ANT/NUM_I_CHAIN)==0) begin
always@(posedge i_clk) begin
    rr_en[gidx] <= r_en[gidx] ;
    if(r_en[gidx]) begin
        rr_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] <= r_iq[gidx/(NUM_ANT/NUM_I_CHAIN)] ;
    end
end
end
else begin//(gidx%(NUM_ANT/NUM_I_CHAIN)==0)
always@(*) begin
    rr_en[gidx] = r_en[gidx] ;
    rr_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] = r_iq[gidx/(NUM_ANT/NUM_I_CHAIN)] ;
end
end//(gidx%(NUM_ANT/NUM_I_CHAIN)==0)
end
endgenerate
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_1_mem_wr_ctrl
assign w_din_cc_id  [gidx] = i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
assign w_din_ant_id [gidx] = i_din_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] ;
always@(posedge i_clk) begin
    r_din_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        if(r_ant_gate[w_din_cc_id[gidx]]&({{{NUM_ANT-1}{1'b0}},{1'b1}}<<w_din_ant_id[gidx])) begin
            r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
        end
        else begin
            r_iq[gidx] <= {{2*DI_BW}{1'b0}} ;
        end
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]&~r_din_en[gidx]) begin
        r_wr_addr[gidx] <= (1'd1<<r_fft_size[w_din_cc_id[gidx]])-(r_ntone[w_din_cc_id[gidx]]>>1)+r_k0[w_din_cc_id[gidx]][$clog2(MAX_NIFFT)-1:0] ;
    end
    else if(r_en[gidx*(NUM_ANT/NUM_I_CHAIN)]) begin
        if(r_wr_addr[gidx]==(1'd1<<r_fft_size[w_din_cc_id[gidx]])-1'd1) begin
            r_wr_addr[gidx] <= {{$clog2(MAX_NIFFT)}{1'd0}} ;
        end
        else begin
            r_wr_addr[gidx] <= r_wr_addr[gidx] + 1'd1 ;
        end
    end
end
end
endgenerate

wire            w_rd_frame_sync         ;
wire            w_rd_subfrm_sync        ;
wire            w_rd_slot_sync          ;
wire            w_rd_symbol_sync        ;
wire    [3:0]   w_rd_subfrm             ;
wire    [7:0]   w_rd_slot               ;
wire    [3:0]   w_rd_symbol             ;
reg     [21:0]  r_rd_frame_sync_offset  ;
always@(*) begin
    r_rd_frame_sync_offset = LEN_NSYM_015K >> r_mu ;
end
ref_vsync_gen u00_ifft_map_rtg
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( r_mu                      )
    ,.i_retard              ( r_rd_frame_sync_offset    )
    ,.i_frame_sync          ( r_frame_sync              )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_rd_frame_sync           )   
    ,.o_subfrm_sync         ( w_rd_subfrm_sync          )   
    ,.o_slot_sync           ( w_rd_slot_sync            )   
    ,.o_symbol_sync         ( w_rd_symbol_sync          )   
    ,.o_subfrm              ( w_rd_subfrm               )          
    ,.o_slot                ( w_rd_slot                 )          
    ,.o_symbol              ( w_rd_symbol               )          
);

wire w_half_sym_sync  ;
ylib_pshift #(
     .BW_SHIFT  (   $clog2(LEN_NSYM_015K_LAT) ))
u01_cal_sync_shift
(
    .i_clk        ( i_clk                       )          
   ,.i_shift      ( LEN_NSYM_015K_LAT>>r_mu     )
   ,.i_in         ( i_din_symbol_sync           )
   ,.o_out        ( w_half_sym_sync             )
);
reg r_sig_det ;
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_sig_det <= 1'b0 ;
    end
    else if(|i_din_en) begin
        r_sig_det <= 1'b1 ;
    end
end
reg r_rd_sig_exist ;
always@(posedge i_clk) begin
    if(w_half_sym_sync) begin
        r_rd_sig_exist  <= r_sig_det  ;
    end
end
reg rr_rd_sig_exist ;
always@(posedge i_clk) begin
    if(w_rd_symbol_sync) begin
        rr_rd_sig_exist  <= r_rd_sig_exist  ;
    end
end
reg [05-1:0] r_rd_pkt_cnt ;
reg [$clog2(SIZE_MEM_PKT+GAP_PKT)-1:0] r_rd_en_cnt ; 
always@(posedge i_clk) begin
    if(w_rd_symbol_sync) begin
        r_rd_en_cnt  <= {{$clog2(SIZE_MEM_PKT+GAP_PKT)}{1'b0}} ;
        r_rd_pkt_cnt <= 4'd0 ;
    end
    else if(r_rd_en_cnt==({{$clog2(SIZE_MEM_PKT+GAP_PKT)}{1'b1}}&(SIZE_MEM_PKT+GAP_PKT-1))) begin
        r_rd_en_cnt <= {{$clog2(SIZE_MEM_PKT+GAP_PKT)}{1'b0}} ;
        r_rd_pkt_cnt <= r_rd_pkt_cnt + 1'd1 ;
    end
    else begin
        r_rd_en_cnt <= r_rd_en_cnt + 1'd1 ;
    end
end
reg [01-1:0] r_aie_ab_flag ; 
reg [01-1:0] r_aie_axis_rden1 ; 
reg [01-1:0] r_aie_axis_rden2 ; 
reg [$clog2(SIZE_MEM_PKT+GAP_PKT)-1:0] r_aie_axis_raddr ; 
always@(posedge i_clk) begin
    if(!r_aie_ab_flag) begin
        r_aie_axis_rden1 <= r_rd_en_cnt<={{{$clog2(GAP_PKT)}{1'b0}},{{$clog2(SIZE_MEM_PKT)}{1'b1}}}&&r_rd_en_cnt[$clog2(SIZE_AIE_PKT)]==1'b0&&r_rd_pkt_cnt<((5'h1f&NUM_ANT)>>(4'd12-r_fft_size[CC_REF])) ;
        r_aie_axis_rden2 <= r_rd_en_cnt<={{{$clog2(GAP_PKT)}{1'b0}},{{$clog2(SIZE_MEM_PKT)}{1'b1}}}&&r_rd_en_cnt[$clog2(SIZE_AIE_PKT)]==1'b1&&r_rd_pkt_cnt<((5'h1f&NUM_ANT)>>(4'd12-r_fft_size[CC_REF])) ;
    end
    else begin
        r_aie_axis_rden1 <= 1'd0 ;
        r_aie_axis_rden2 <= 1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(w_rd_symbol_sync) begin
        if(r_aie_axis_rden1|r_aie_axis_rden2) begin
            r_aie_ab_flag <= 1'b1 ;
        end
        else begin
            r_aie_ab_flag <= 1'b0 ;
        end
    end
end
always@(posedge i_clk) begin
    case(r_fft_size[CC_REF])
        ORAN_FFT0512 : r_aie_axis_raddr <= r_rd_en_cnt[$clog2(SIZE_AIE_PKT)-1:0] ;
        ORAN_FFT1024 : r_aie_axis_raddr <= r_rd_en_cnt[$clog2(SIZE_AIE_PKT)-1:0] ;
        ORAN_FFT2048 : r_aie_axis_raddr <= r_rd_en_cnt[$clog2(SIZE_AIE_PKT)-1:0] ;
        ORAN_FFT4096 : r_aie_axis_raddr <= (r_rd_en_cnt[$clog2(SIZE_AIE_PKT)-1:0]<<1)+{{{$clog2(SIZE_MEM_PKT+GAP_PKT)-1}{1'b0}},~r_rd_en_cnt[$clog2(SIZE_AIE_PKT)]} ;
        default      : r_aie_axis_raddr <= {{$clog2(SIZE_MEM_PKT+GAP_PKT)}{1'b0}} ;
    endcase
end
wire [01-1:0] w_aie_axis_rden2 ; 
wire [$clog2(SIZE_MEM_PKT+GAP_PKT)-1:0] w_aie_axis_raddr2 ; 
ylib_reg_en #(
     .WIDTH     (   $clog2(SIZE_MEM_PKT+GAP_PKT)    ) 
    ,.DEPTH     (   GAP_PKT/2                       )) 
u02_axis_pkt2_rd_dly
(
     .i_clk      (  i_clk                   )
    ,.i_en       (  r_aie_axis_rden2        )
    ,.i_in       (  r_aie_axis_raddr        )
    ,.o_en       (  w_aie_axis_rden2        )
    ,.o_out      (  w_aie_axis_raddr2       )
);
reg  [NUM_PKT_AXIS-1:0]   r_aie_axis_wren    ;
always@(posedge i_clk) begin
    if(r_en[CHAIN_REF][0]) begin
        case(r_fft_size[CC_REF])
            ORAN_FFT0512 : r_aie_axis_wren <= {{{NUM_PKT_AXIS-1}{1'b0}},r_en[CHAIN_REF][0]}<<(r_wr_addr[CHAIN_REF][$clog2(NUM_PKT_AXIS)-1:0]<<1) ;
            ORAN_FFT1024 : r_aie_axis_wren <= {{{NUM_PKT_AXIS/2-1}{1'b0}},r_en[CHAIN_REF][0],{{NUM_PKT_AXIS/2-1}{1'b0}},r_en[CHAIN_REF][0]}<<({2'b0,r_wr_addr[CHAIN_REF][$clog2(NUM_PKT_AXIS)-3:0]}<<1) ;
            ORAN_FFT2048 : r_aie_axis_wren <= {{{NUM_PKT_AXIS-1}{1'b0}},r_en[CHAIN_REF][0]}<<({1'b0,r_wr_addr[CHAIN_REF][$clog2(NUM_PKT_AXIS)-2:0]}<<1) ;
            ORAN_FFT4096 : r_aie_axis_wren <= {{{NUM_PKT_AXIS-1}{1'b0}},r_en[CHAIN_REF][0]}<<(r_wr_addr[CHAIN_REF][$clog2(NUM_PKT_AXIS)-1:0]<<0) ;
            default      : r_aie_axis_wren <= {{NUM_PKT_AXIS}{1'b0}} ;
        endcase
    end
    else begin
        r_aie_axis_wren <= {{NUM_PKT_AXIS}{1'b0}} ;
    end
end
reg  [BW_MEM_ADDR-1:0]  r_aie_axis_waddr    [NUM_S2P_AXIS-1:0]   ;
reg  [01-1:0]           rr_aie_axis_wren    [NUM_S2P_AXIS-1:0]   ;
reg  [01-1:0]           rr_aie_axis_rden    [NUM_S2P_AXIS-1:0]   ;
reg  [BW_MEM_ADDR-1:0]  rr_aie_axis_waddr   [NUM_S2P_AXIS-1:0]   ;
reg  [BW_MEM_ADDR-1:0]  rr_aie_axis_raddr   [NUM_S2P_AXIS-1:0]   ;
generate for(gidx=0;gidx<NUM_S2P_AXIS;gidx=gidx+1) begin : g01_mem_ctrl_aie_axis
always@(posedge i_clk) begin
    if(r_en[CHAIN_REF][0]) begin
        case(r_fft_size[CC_REF]) 
            ORAN_FFT0512 : r_aie_axis_waddr[gidx] <= r_wr_addr[CHAIN_REF]>>($clog2(NUM_PKT_AXIS)-2) ;
            ORAN_FFT1024 : r_aie_axis_waddr[gidx] <= r_wr_addr[CHAIN_REF]>>($clog2(NUM_PKT_AXIS)-2) ;
            ORAN_FFT2048 : r_aie_axis_waddr[gidx] <= r_wr_addr[CHAIN_REF]>>($clog2(NUM_PKT_AXIS)-1) ;
            ORAN_FFT4096 : r_aie_axis_waddr[gidx] <= r_wr_addr[CHAIN_REF]>>($clog2(NUM_PKT_AXIS)-0) ;
            default      : r_aie_axis_waddr[gidx] <= {{BW_MEM_ADDR}{1'b0}} ;
        endcase
    end
end
always@(posedge i_clk) begin
    if(r_aie_axis_wren[gidx*(NUM_PKT_AXIS/NUM_S2P_AXIS)+0]) begin
        rr_aie_axis_wren [gidx] <= 1'd1 ;
        case(r_fft_size[CC_REF]) 
            ORAN_FFT0512 : rr_aie_axis_waddr[gidx] <= {r_symbol[0], r_aie_axis_waddr[gidx][BW_MEM_ADDR-2:0]<<0} ;
            ORAN_FFT1024 : rr_aie_axis_waddr[gidx] <= {r_symbol[0], r_aie_axis_waddr[gidx][BW_MEM_ADDR-2:0]<<0} ;
            ORAN_FFT2048 : rr_aie_axis_waddr[gidx] <= {r_symbol[0], r_aie_axis_waddr[gidx][BW_MEM_ADDR-2:0]<<0} ;
            ORAN_FFT4096 : rr_aie_axis_waddr[gidx] <= {r_symbol[0], r_aie_axis_waddr[gidx][BW_MEM_ADDR-2:0]<<1} ;
            default      : rr_aie_axis_waddr[gidx] <= {{BW_MEM_ADDR}{1'b0}} ;
        endcase
    end
    else if(r_aie_axis_wren[gidx*(NUM_PKT_AXIS/NUM_S2P_AXIS)+1]) begin
        rr_aie_axis_wren [gidx] <= 1'd1 ;
        rr_aie_axis_waddr[gidx] <= {r_symbol[0], r_aie_axis_waddr[gidx][BW_MEM_ADDR-2:0]<<1}+1'd1 ;
    end
    else begin
        rr_aie_axis_wren [gidx] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(r_aie_axis_rden1) begin
        rr_aie_axis_rden [gidx] <= rr_rd_sig_exist ;
        rr_aie_axis_raddr[gidx] <= {w_rd_symbol[0],r_aie_axis_raddr[BW_MEM_ADDR-2:0]} ;
    end
    else if(w_aie_axis_rden2) begin
        rr_aie_axis_rden [gidx] <= rr_rd_sig_exist ;
        rr_aie_axis_raddr[gidx] <= {w_rd_symbol[0],w_aie_axis_raddr2[BW_MEM_ADDR-2:0]} ;
    end
    else begin
        rr_aie_axis_rden [gidx] <= 1'd0 ;
    end
end
end
endgenerate

reg  [BW_MEM_DATA-1:0]  r_aie_axis_wdata    [NUM_MEM-1:0]   ;
reg  [BW_MEM_DATA-1:0]  rr_aie_axis_wdata   [NUM_MEM-1:0]   ;
generate for(gidx=0;gidx<NUM_MEM;gidx=gidx+1) begin : g02_mem_data_aie_axis
always@(*) begin
    if(gidx==NUM_MEM-1) begin
        r_aie_axis_wdata[gidx] = {{{(BW_MEM_DATA*NUM_MEM-2*DI_BW*NUM_ANT)}{1'b0}},rr_iq[(2*DI_BW*NUM_ANT-1):(BW_MEM_DATA*(NUM_MEM-1))]} ;
    end
    else begin
        r_aie_axis_wdata[gidx] = rr_iq[((BW_MEM_DATA)*(gidx+1)-1)-:(BW_MEM_DATA)] ;
    end
end
always@(posedge i_clk) begin
    if(rr_en[CHAIN_REF]) begin
        rr_aie_axis_wdata[gidx] <= r_aie_axis_wdata[gidx] ;
    end
end
end
endgenerate

wire [01-1:0]                   w_aie_axis_rden      [NUM_MEM*NUM_S2P_AXIS-1:0] ;
wire [BW_MEM_DATA-1:0]          w_aie_axis_rdata     [NUM_MEM*NUM_S2P_AXIS-1:0] ;
reg  [BW_MEM_DATA*NUM_MEM-1:0]  r_aie_axis_rdata_cat [NUM_S2P_AXIS-1:0]         ;
generate for(gidx=0;gidx<NUM_MEM*NUM_S2P_AXIS;gidx=gidx+1) begin : g03_mem_aie_axis
xpm_memory_sdpram #(
    .ADDR_WIDTH_A            (BW_MEM_ADDR            ) 
   ,.ADDR_WIDTH_B            (BW_MEM_ADDR            ) 
   ,.AUTO_SLEEP_TIME         (0                      ) 
   ,.BYTE_WRITE_WIDTH_A      (BW_MEM_DATA            ) 
   ,.CASCADE_HEIGHT          (0                      ) 
   ,.CLOCKING_MODE           ("common_clock"         ) 
   ,.ECC_MODE                ("no_ecc"               ) 
   ,.MEMORY_INIT_FILE        ("none"                 ) 
   ,.MEMORY_INIT_PARAM       ("0"                    ) 
   ,.MEMORY_OPTIMIZATION     ("true"                 ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                ) 
   ,.MEMORY_SIZE             (BW_MEM_DATA*MEM_DEPTH  ) 
   ,.MESSAGE_CONTROL         (0                      ) 
   ,.READ_DATA_WIDTH_B       (BW_MEM_DATA            ) 
   ,.READ_LATENCY_B          (3                      ) 
   ,.READ_RESET_VALUE_B      ("0"                    ) 
   ,.RST_MODE_A              ("SYNC"                 ) 
   ,.RST_MODE_B              ("SYNC"                 ) 
   ,.SIM_ASSERT_CHK          (0                      ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                      ) 
   ,.USE_MEM_INIT            (1                      ) 
   ,.WAKEUP_TIME             ("disable_sleep"        ) 
   ,.WRITE_DATA_WIDTH_A      (BW_MEM_DATA            ) 
   ,.WRITE_MODE_B            ("write_first"          )  
)
u03_aie_pkt_sdpram (
    .dbiterrb           (                                           )
   ,.doutb              (   w_aie_axis_rdata [gidx]                 )
   ,.sbiterrb           (                                           )
   ,.addra              (   rr_aie_axis_waddr[gidx%NUM_S2P_AXIS]    )
   ,.addrb              (   rr_aie_axis_raddr[gidx%NUM_S2P_AXIS]    )
   ,.clka               (   i_clk                                   )
   ,.clkb               (   i_clk                                   )
   ,.dina               (   rr_aie_axis_wdata[gidx/NUM_S2P_AXIS]    )
   ,.ena                (   rr_aie_axis_wren [gidx%NUM_S2P_AXIS]    )
   ,.enb                (   rr_aie_axis_rden [gidx%NUM_S2P_AXIS]    )
   ,.injectdbiterra     (   1'b0                                    )
   ,.injectsbiterra     (   1'b0                                    )
   ,.regceb             (   1'b1                                    )
   ,.rstb               (   i_rst                                   )
   ,.sleep              (   1'b0                                    )
   ,.wea                (   rr_aie_axis_wren[gidx%NUM_S2P_AXIS]     )
);
ylib_reg #(
     .WIDTH     (   1       ) 
    ,.DEPTH     (   3       )) 
u04_rden_dly
(
     .i_clk      (  i_clk                                   )
    ,.i_in       (  rr_aie_axis_rden [gidx%NUM_S2P_AXIS]    )
    ,.o_out      (  w_aie_axis_rden  [gidx]                 )
);
always@(*) begin
    r_aie_axis_rdata_cat[gidx/NUM_MEM][((BW_MEM_DATA)*((gidx%NUM_MEM)+1)-1)-:(BW_MEM_DATA)] = w_aie_axis_rdata[(gidx%NUM_MEM)*NUM_S2P_AXIS+(gidx/NUM_MEM)] ;
end
end
endgenerate

reg [NUM_O_CHAIN-1:0]           r_ref_re_ptr    ;
reg [NUM_O_CHAIN-1:0]           r_map_val       ;
reg [NUM_O_CHAIN-1:0]           r_dout_en       ;
reg [2*DO_BW*NUM_O_CHAIN-1:0]   r_dout_iq       ;
reg [$clog2(NUM_ANT*2)-1:0]     r_dout_ant_id   [NUM_O_CHAIN-1:0]   ;
reg [$clog2(NUM_ANT*2)-1:0]     r_dout_pkt_id   [NUM_O_CHAIN-1:0]   ;
reg [(`mlib_clog2(NUM_CC))-1:0] r_dout_cc_id    [NUM_O_CHAIN-1:0]   ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g01_rd_ant_map
always@(*) begin
    case(r_fft_size[r_dout_cc_id[gidx]]) 
        ORAN_FFT1024 : r_dout_pkt_id[gidx] = (gidx/2)==0 ? r_dout_ant_id[gidx]<<1 : (r_dout_ant_id[gidx]<<1)+1'd1 ;
        ORAN_FFT2048 : r_dout_pkt_id[gidx] = r_dout_ant_id[gidx]    ;
        ORAN_FFT4096 : r_dout_pkt_id[gidx] = r_dout_ant_id[gidx]>>1 ;
        default      : r_dout_pkt_id[gidx] = r_dout_ant_id[gidx]    ;
    endcase
end
always@(posedge i_clk) begin
    r_dout_en[gidx] <= w_aie_axis_rden[CHAIN_REF] ;
    if(w_aie_axis_rden[CHAIN_REF]) begin
        case(r_dout_pkt_id[gidx])
            'd00    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(00+1)-1)-:(2*DO_BW)] ; end  
            'd01    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(01+1)-1)-:(2*DO_BW)] ; end 
            'd02    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(02+1)-1)-:(2*DO_BW)] ; end 
            'd03    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(03+1)-1)-:(2*DO_BW)] ; end 
`ifdef DLFE_ANT_PORT_008            
            'd04    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(04+1)-1)-:(2*DO_BW)] ; end 
            'd05    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(05+1)-1)-:(2*DO_BW)] ; end 
            'd06    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(06+1)-1)-:(2*DO_BW)] ; end 
            'd07    :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_aie_axis_rdata_cat[gidx][((2*DO_BW)*(07+1)-1)-:(2*DO_BW)] ; end 
`endif//DLFE_ANT_PORT_008            
            default :   begin r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= {{2*DI_BW}{1'b0}} ; end 
        endcase
    end
end
always@(posedge i_clk) begin
    if(w_rd_symbol_sync) begin
        r_dout_cc_id  [gidx] <= {{`mlib_clog2(NUM_CC)}{1'b0}} ;
        r_dout_ant_id [gidx] <= {{$clog2(NUM_ANT*2)}{1'b0}}  ;
    end
    else if(~w_aie_axis_rden[CHAIN_REF]&r_dout_en[gidx]) begin
        r_dout_ant_id [gidx] <= r_dout_ant_id [gidx] + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    o_dout_en[gidx] <= r_dout_en[gidx]&r_event_n ;
    if(r_dout_en[gidx]) begin
        if(r_map_val[gidx]) begin
            o_dout_iq [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] ;
        end
        else begin
            o_dout_iq [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= {{2*DO_BW}{1'b0}} ;
        end
    end
end
always@(posedge i_clk) begin
    if(r_dout_en[gidx]) begin
        o_dout_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= r_dout_cc_id [gidx] ;
        case(r_fft_size[r_dout_cc_id[gidx]]) 
            ORAN_FFT1024 : o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= (r_dout_ant_id[gidx]<<1)+(gidx/2) ;
            ORAN_FFT2048 : o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_dout_ant_id[gidx]     ;
            ORAN_FFT4096 : o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_dout_ant_id[gidx]>>1  ;
            default      : o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= {{$clog2(NUM_ANT)}{1'b0}} ;
        endcase
    end
end
end
endgenerate

reg [$clog2(MAX_NIFFT)-1:0]     r_sc_map_l      [NUM_O_CHAIN-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0]     r_sc_map_h      [NUM_O_CHAIN-1:0] ;
reg [04-1:0]                    r_re_offset     [NUM_O_CHAIN-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0]     r_sc_idx        [NUM_O_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g02_sc_nulling
always@(posedge i_clk) begin
    if(o_dout_symbol_sync) begin
        r_sc_map_l [gidx] <= ((1'd1<<r_fft_size[r_dout_cc_id[gidx]])-(r_ntone[r_dout_cc_id[gidx]]>>1)+r_k0[r_dout_cc_id[gidx]]) ;
        r_sc_map_h [gidx] <= ((r_ntone[r_dout_cc_id[gidx]]>>1)+r_k0[r_dout_cc_id[gidx]]) ;
    end
end
always@(*) begin
    r_map_val [gidx] = ((r_sc_idx[gidx]>=r_sc_map_l[gidx])||(r_sc_idx[gidx]<r_sc_map_h[gidx])) ;
end
always@(posedge i_clk) begin
    if(w_aie_axis_rden[CHAIN_REF]&~r_dout_en[gidx]) begin
        case(r_fft_size[r_dout_cc_id[gidx]]) 
            ORAN_FFT1024 : r_sc_idx [gidx] <= ({{$clog2(MAX_NIFFT)}{1'b1}}&(gidx%2)) ;
            ORAN_FFT2048 : r_sc_idx [gidx] <= ({{$clog2(MAX_NIFFT)}{1'b1}}&gidx) ;
            ORAN_FFT4096 : r_sc_idx [gidx] <= ({{$clog2(MAX_NIFFT)}{1'b1}}&(gidx*(NUM_PKT_AXIS/NUM_S2P_AXIS)))+{{{$clog2(MAX_NIFFT)-1}{1'b0}},~r_dout_ant_id[gidx][0]} ;
            default      : r_sc_idx [gidx] <= {{$clog2(MAX_NIFFT)}{1'b0}} ;
        endcase
    end
    else if(r_dout_en[gidx]) begin
        case(r_fft_size[r_dout_cc_id[gidx]]) 
            ORAN_FFT1024 : r_sc_idx [gidx] <= r_sc_idx [gidx] + ((4'hf&NUM_PKT_AXIS)>>2) ;
            ORAN_FFT2048 : r_sc_idx [gidx] <= r_sc_idx [gidx] + ((4'hf&NUM_PKT_AXIS)>>1) ;
            ORAN_FFT4096 : r_sc_idx [gidx] <= r_sc_idx [gidx] + (4'hf&NUM_PKT_AXIS) ;
            default      : r_sc_idx [gidx] <= {{$clog2(MAX_NIFFT)}{1'b0}} ;
        endcase
   end
end
end
endgenerate

reg [3:0]           rr_mu       ;
reg [04*NUM_CC-1:0] rr_fft_size ;
reg [1:0]           r_cal_en    ;
always@(posedge i_clk) begin
    if(r_frame_sync||((r_dout_en[CHAIN_REF])&~o_dout_en[CHAIN_REF])) begin
        rr_mu <=  r_mu ;
        for(i=0;i<NUM_CC;i=i+1) begin
            rr_fft_size[((04)*(i+1)-1)-:(04)] <= r_fft_size[i] ;
        end
    end
end
always@(posedge i_clk) begin
    o_dout_frame_sync    <=   w_rd_frame_sync    ;
    o_dout_subfrm_sync   <=   w_rd_subfrm_sync   ;
    o_dout_symbol_sync   <=   w_rd_symbol_sync   ;
    if(w_rd_frame_sync) begin
        o_dout_mu   <=   rr_mu  ;
        for(i=0;i<NUM_CC;i=i+1) begin
            o_dout_fft_size <=  rr_fft_size ;
        end
    end
    if(w_half_sym_sync) begin
        r_cal_en <=  i_din_cal_en    ;
    end
    if(w_rd_symbol_sync) begin
        o_dout_cal_en <=  r_cal_en    ;
    end
end
`else // DLFE_AIE_DISABLE
reg     [1-1:0]                         r_en            [NUM_ANT-1:0]       ;
reg     [1-1:0]                         rr_en           [NUM_ANT-1:0]       ;
reg     [1-1:0]                         rrr_en          [NUM_ANT-1:0]       ;
reg     [(`mlib_clog2(NUM_CC))-1:0]     r_cc_id         [NUM_ANT-1:0]       ;
reg     [$clog2(NUM_ANT)-1:0]           r_ant_id        [NUM_ANT-1:0]       ;
reg     [1-1:0]                         r_din_en        [NUM_I_CHAIN-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]         r_wr_addr       [NUM_I_CHAIN-1:0]   ;
reg     [2*DI_BW-1:0]                   r_iq            [NUM_I_CHAIN-1:0]   ;
wire    [(`mlib_clog2(NUM_CC))-1:0]     w_din_cc_id     [NUM_I_CHAIN-1:0]   ;
wire    [$clog2(NUM_ANT)-1:0]           w_din_ant_id    [NUM_I_CHAIN-1:0]   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_0_mem_wr_ctrl
always@(posedge i_clk) begin
    r_en    [gidx] <= i_din_ant_id[(($clog2(NUM_ANT))*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:($clog2(NUM_ANT))]==({{$clog2(NUM_ANT)}{1'b1}}&gidx) ? i_din_en[((01)*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:(01)] : 1'd0 ;
    rr_en   [gidx] <= r_en  [gidx] ;
    rrr_en  [gidx] <= rr_en [gidx] ;
end
always@(*) begin
    r_cc_id [gidx] = i_din_cc_id [((`mlib_clog2(NUM_CC))*((gidx/(NUM_ANT/NUM_I_CHAIN))+1)-1)-:`mlib_clog2(NUM_CC)] ;
    r_ant_id[gidx] = ({{$clog2(NUM_ANT)}{1'b1}}&gidx) ;
end
end
endgenerate
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_1_mem_wr_ctrl
assign w_din_cc_id  [gidx] = i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
assign w_din_ant_id [gidx] = i_din_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] ;
always@(posedge i_clk) begin
    r_din_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        if(r_ant_gate[w_din_cc_id[gidx]]&({{{NUM_ANT-1}{1'b0}},{1'b1}}<<w_din_ant_id[gidx])) begin
            r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
        end
        else begin
            r_iq[gidx] <= {{2*DI_BW}{1'b0}} ;
        end
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]&~r_din_en[gidx]) begin
        r_wr_addr[gidx] <= (1'd1<<r_fft_size[w_din_cc_id[gidx]])-(r_ntone[w_din_cc_id[gidx]]>>1)+r_k0[w_din_cc_id[gidx]][$clog2(MAX_NIFFT)-1:0] ;
    end
    else if(r_en[gidx*(NUM_ANT/NUM_I_CHAIN)+1]) begin
        if(r_wr_addr[gidx]==(1'd1<<r_fft_size[w_din_cc_id[gidx]])-1'd1) begin
            r_wr_addr[gidx] <= {{$clog2(MAX_NIFFT)}{1'd0}} ;
        end
        else begin
            r_wr_addr[gidx] <= r_wr_addr[gidx] + 1'd1 ;
        end
    end
end
end
endgenerate

wire            w_rd_frame_sync         ;
wire            w_rd_subfrm_sync        ;
wire            w_rd_slot_sync          ;
wire            w_rd_symbol_sync        ;
wire    [3:0]   w_rd_subfrm             ;
wire    [7:0]   w_rd_slot               ;
wire    [3:0]   w_rd_symbol             ;
reg     [21:0]  r_rd_frame_sync_offset  ;
always@(*) begin
    r_rd_frame_sync_offset = {{{22-BW_DLY_RD_SYNC}{1'b0}},RD_SYNC_OFFSET} + {{{22-BW_DLY_RD_SYNC}{1'b0}},r_fft_offset[r_cc_id[CHAIN_REF]]} ;
end
ref_vsync_gen u00_ifft_map_rtg
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( r_mu                      )
    ,.i_retard              ( r_rd_frame_sync_offset    )
    ,.i_frame_sync          ( r_frame_sync              )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_rd_frame_sync           )   
    ,.o_subfrm_sync         ( w_rd_subfrm_sync          )   
    ,.o_slot_sync           ( w_rd_slot_sync            )   
    ,.o_symbol_sync         ( w_rd_symbol_sync          )   
    ,.o_subfrm              ( w_rd_subfrm               )          
    ,.o_slot                ( w_rd_slot                 )          
    ,.o_symbol              ( w_rd_symbol               )          
);

wire w_half_sym_sync  ;
ylib_pshift #(
     .BW_SHIFT  (   $clog2(LEN_NSYM_015K_LAT) ))
u01_cal_sync_shift
(
    .i_clk        ( i_clk                       )          
   ,.i_shift      ( LEN_NSYM_015K_LAT>>r_mu     )
   ,.i_in         ( i_din_symbol_sync           )
   ,.o_out        ( w_half_sym_sync             )
);

reg  [0:0]                r_wr_sync        [NUM_ANT-1:0][NUM_CBUF-1:0] ;   
wire [0:0]                w_rd_sync        [NUM_ANT-1:0][NUM_CBUF-1:0] ;   
reg  [BW_DLY_RD_SYNC-1:0] r_rd_sync_offset [NUM_ANT-1:0]               ;
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        for(i=0;i<NUM_ANT;i=i+1) begin
            r_rd_sync_offset[i] <= (SIZE_PKT+GAP_SYMBOL)*({{BW_DLY_RD_SYNC}{1'b1}}&(i%(NUM_ANT/NUM_O_CHAIN)))+RD_SYNC_OFFSET+r_fft_offset[r_cc_id[i]] ; 
        end
    end
end
generate for(gidx=0;gidx<NUM_ANT*NUM_CBUF;gidx=gidx+1) begin : g01_mem_rd_sync
always@(posedge i_clk) begin
    r_wr_sync[gidx/NUM_CBUF][gidx%NUM_CBUF] <= (((r_en[gidx/NUM_CBUF]|rr_en[gidx/NUM_CBUF])&~(rr_en[gidx/NUM_CBUF]|rrr_en[gidx/NUM_CBUF]))&&r_symbol[0]==(gidx%NUM_CBUF)) ;    
end
ylib_pshift #(
     .BW_SHIFT  (   BW_DLY_RD_SYNC      ))
u02_rd_sync_shift
(
    .i_clk        ( i_clk                                       )          
   ,.i_shift      ( r_rd_sync_offset[gidx/NUM_CBUF]             )
   ,.i_in         ( r_wr_sync[gidx/NUM_CBUF][gidx%NUM_CBUF]     )
   ,.o_out        ( w_rd_sync[gidx/NUM_CBUF][gidx%NUM_CBUF]     )
);
end
endgenerate

reg [0:0]                       r_rd_sync   [NUM_ANT-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0]     r_rd_cnt    [NUM_ANT-1:0] ;
reg [0:0]                       r_rd_en     [NUM_ANT-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0]     r_rd_addr   [NUM_ANT-1:0] ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g02_mem_rd_ctrl
always@(posedge i_clk) begin
    if(w_rd_sync[gidx][0]) begin
        r_rd_sync[gidx] <= 1'b1   ;
    end
    else if(w_rd_sync[gidx][1]) begin
        r_rd_sync[gidx] <= 1'b1   ;
    end
    else begin
        r_rd_sync[gidx] <= 1'b0   ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_sync[gidx]) begin
        r_rd_cnt[gidx] <= {{$clog2(MAX_NIFFT)}{1'd0}} ;
    end
    else if(r_rd_cnt[gidx]<(1'd1<<r_fft_size[r_cc_id[gidx]])-1'd1) begin
        r_rd_cnt[gidx] <= r_rd_cnt[gidx] + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_sync[gidx]) begin
        r_rd_en[gidx] <= 1'd1 ;
    end
    else if(r_rd_cnt[gidx]==(1'd1<<r_fft_size[r_cc_id[gidx]])-1'd1) begin
        r_rd_en[gidx] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_sync[gidx]) begin
        r_rd_addr   [gidx] <= {{$clog2(MAX_NIFFT)}{1'b0}} ;
    end
    else if(r_rd_en[gidx]) begin
        r_rd_addr   [gidx] <= r_rd_addr [gidx] + 1'd1 ;
    end
end
end
endgenerate

reg  [0:0]                      rr_rd_en            [NUM_ANT*NUM_CBUF-1:0]  ;
reg  [$clog2(MAX_NIFFT)-1:0]    rr_rd_addr          [NUM_ANT*NUM_CBUF-1:0]  ;
reg  [0:0]                      r_mem_en            [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [0:0]                      r_mem_wr_en         [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [$clog2(MAX_NIFFT)-1:0]    r_mem_addr          [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [2*DI_BW-1:0]              r_mem_din           [NUM_ANT*NUM_CBUF-1:0]  ;
wire [2*DI_BW-1:0]              w_mem_dout          [NUM_ANT*NUM_CBUF-1:0]  ;
reg  [0:0]                      r_mem_rd_en         [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [0:0]                      rr_mem_rd_en        [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [0:0]                      rrr_mem_rd_en       [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [2*DO_BW-1:0]              rrr_mem_dout        [NUM_ANT*NUM_CBUF-1:0]  ;
reg  [0:0]                      r_dout_zp_en        [NUM_ANT*NUM_CBUF-1:0]  ;
reg  [12-1:0]                   r_dout_zp_l         [NUM_ANT*NUM_CBUF-1:0]  ; 
reg  [12-1:0]                   r_dout_zp_h         [NUM_ANT*NUM_CBUF-1:0]  ; 
generate for(gidx=0;gidx<NUM_ANT*NUM_CBUF;gidx=gidx+1) begin : g03_mem_chain  
always@(posedge i_clk) begin
    rr_rd_en[gidx] <= r_rd_en[gidx/NUM_CBUF] ;
    if(r_rd_en[gidx/NUM_CBUF]) begin
        rr_rd_addr[gidx] <= r_rd_addr[gidx/NUM_CBUF] ;
    end
end
always@(posedge i_clk) begin
    if(r_en[gidx/NUM_CBUF] && r_symbol[0]==(gidx%NUM_CBUF)) begin
        r_mem_en    [gidx] <=  1'd1   ; 
        r_mem_wr_en [gidx] <=  1'd1   ; 
    end
    else if(rr_rd_en[gidx] && w_rd_symbol[0]==(gidx%NUM_CBUF)) begin
        r_mem_en    [gidx] <=  1'd1   ; 
        r_mem_wr_en [gidx] <=  1'd0   ; 
    end
    else begin
        r_mem_en    [gidx] <=  1'd0   ; 
        r_mem_wr_en [gidx] <=  1'd0   ; 
    end
end
always@(posedge i_clk) begin
    if(r_en[gidx/NUM_CBUF] && r_symbol[0]==(gidx%NUM_CBUF)) begin
        r_mem_addr[gidx] <=  r_wr_addr[(gidx/(NUM_ANT/NUM_I_CHAIN))/NUM_CBUF]    ;
    end
    else if(rr_rd_en[gidx] && w_rd_symbol[0]==(gidx%NUM_CBUF)) begin
        r_mem_addr  [gidx] <=  rr_rd_addr[gidx] ;
    end
end
always@(posedge i_clk) begin
    if(r_en[gidx/NUM_CBUF] && r_symbol[0]==(gidx%NUM_CBUF)) begin
        r_mem_din   [gidx] <= r_iq  [(gidx/(NUM_ANT/NUM_I_CHAIN))/NUM_CBUF] ;
    end
end
ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW     )
    ,.DEPTH     (   MAX_NIFFT   )
    ,.VENDOR    (   VENDOR      ))
u03_ifft_map_spram
(
     .clk       (   i_clk                                       )     
    ,.en        (   r_mem_en    [gidx]                          ) 
    ,.we        (   r_mem_wr_en [gidx]                          ) 
    ,.addr      (   r_mem_addr  [gidx][$clog2(MAX_NIFFT)-1:0]   )        
    ,.di        (   r_mem_din   [gidx]                          ) 
    ,.dout      (   w_mem_dout  [gidx]                          ) 
);
always@(posedge i_clk) begin
    if(w_rd_symbol_sync) begin
        r_dout_zp_l[gidx] <= (r_ntone[r_cc_id[gidx/NUM_CBUF]]>>1)+($signed(r_k0[r_cc_id[gidx/NUM_CBUF]][$clog2(MAX_NIFFT)-1:0]))-1'd1  ; 
        r_dout_zp_h[gidx] <= (1'd1<<r_fft_size[r_cc_id[gidx/NUM_CBUF]])-(r_ntone[r_cc_id[gidx/NUM_CBUF]]>>1)+($signed(r_k0[r_cc_id[gidx/NUM_CBUF]][$clog2(MAX_NIFFT)-1:0]))  ; 
    end
end
always@(posedge i_clk) begin
    r_mem_rd_en  [gidx]  <= rr_rd_en[gidx] && w_rd_symbol[0]==(gidx%NUM_CBUF) ;
    rr_mem_rd_en [gidx]  <= r_mem_rd_en[gidx] ;
    r_dout_zp_en [gidx]  <= r_mem_rd_en[gidx] && r_mem_addr[gidx]>r_dout_zp_l[gidx][$clog2(MAX_NIFFT)-1:0] && r_mem_addr[gidx]<r_dout_zp_h[gidx][$clog2(MAX_NIFFT)-1:0] ;
end
always@(posedge i_clk) begin
    rrr_mem_rd_en[gidx] <= rr_mem_rd_en[gidx] ;
    if(rr_mem_rd_en[gidx]) begin
        rrr_mem_dout[gidx] <=   r_dout_zp_en[gidx] ? {{2*DO_BW}{1'b0}} : w_mem_dout[gidx] ;
    end
end
end
endgenerate

reg [01-1:0]                    r_dout_en   [NUM_O_CHAIN-1:0] ;        
reg [2*DO_BW-1:0]               r_dout_iq   [NUM_O_CHAIN-1:0] ;             
reg [(`mlib_clog2(NUM_CC))-1:0] rr_cc_id    [NUM_O_CHAIN-1:0] ;        
reg [$clog2(NUM_ANT)-1:0]       rr_ant_id   [NUM_O_CHAIN-1:0] ;   
reg [04-1:0]                    r_re_idx    [NUM_O_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g04_out_chain
if((NUM_ANT/NUM_O_CHAIN)==1) begin
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
    end
    else begin
        r_dout_en[gidx] <= 1'd0 ;             
    end
end
always@(posedge i_clk) begin
    if((rrr_mem_rd_en[NUM_CBUF*gidx+0]|rrr_mem_rd_en[NUM_CBUF*gidx+1])&~r_dout_en[gidx]) begin
        rr_cc_id [gidx] <= r_cc_id [gidx] ;
        rr_ant_id[gidx] <= r_ant_id[gidx] ;
    end
end
end //((NUM_ANT/NUM_O_CHAIN)==1)
else if((NUM_ANT/NUM_O_CHAIN)==2) begin
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;             
    end
    else begin
        r_dout_en[gidx] <= 1'd0 ;             
    end
end
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
    end
end
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]&~r_dout_en[gidx]) begin
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]&~r_dout_en[gidx]) begin
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
end
end //((NUM_ANT/NUM_O_CHAIN)==2)
else if((NUM_ANT/NUM_O_CHAIN)==4) begin
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+4]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+4] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+4] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+5]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+5] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+5] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+6]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+6] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+6] ;             
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+7]) begin
        r_dout_en[gidx] <= rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+7] ;             
        r_dout_iq[gidx] <= rrr_mem_dout [NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+7] ;             
    end
    else begin
        r_dout_en[gidx] <= 1'd0 ;             
    end
end
always@(posedge i_clk) begin
    if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+0]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+1]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+0] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+2]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+3]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+1] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+4]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+5]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+2] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+6]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;
    end
    else if(rrr_mem_rd_en[NUM_CBUF*(NUM_ANT/NUM_O_CHAIN)*gidx+7]&~r_dout_en[gidx]) begin
        rr_ant_id[gidx] <= r_ant_id[(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;
        rr_cc_id [gidx] <= r_cc_id [(NUM_ANT/NUM_O_CHAIN)*gidx+3] ;
    end
end
end //((NUM_ANT/NUM_O_CHAIN)==4)

always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)] <= r_dout_en[gidx] ;
    if(w_rd_symbol_sync) begin
        o_dout_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= 1'd0 ;
    end
    else if(r_dout_en[gidx]) begin
        o_dout_iq     [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= r_dout_iq[gidx][(2*DO_BW-1)-:2*DO_BW] ;
        o_dout_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= rr_cc_id[gidx] ;
        o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= rr_ant_id[gidx] ;
    end
end
end
endgenerate
reg [3:0]           rr_mu       ;
reg [04*NUM_CC-1:0] rr_fft_size ;
reg [1:0]           r_cal_en    ;
always@(posedge i_clk) begin
    if(r_frame_sync||((rrr_mem_rd_en[NUM_ANT*CHAIN_REF+0]|rrr_mem_rd_en[NUM_ANT*CHAIN_REF+1])&~r_dout_en[CHAIN_REF])) begin
        rr_mu       <=  r_mu     ;
        for(i=0;i<NUM_CC;i=i+1) begin
            rr_fft_size[((04)*(i+1)-1)-:(04)] <= r_fft_size[i] ;
        end
    end
end
always@(posedge i_clk) begin
    o_dout_frame_sync   <=  w_rd_frame_sync    ;
    o_dout_subfrm_sync  <=  w_rd_subfrm_sync   ;
    o_dout_symbol_sync  <=  w_rd_symbol_sync   ;
    if(w_rd_frame_sync) begin
        o_dout_mu   <=   rr_mu  ;
        for(i=0;i<NUM_CC;i=i+1) begin
            o_dout_fft_size <=  rr_fft_size ;
        end
    end
    if(w_half_sym_sync) begin
        r_cal_en <=  i_din_cal_en    ;
    end
    if(w_rd_symbol_sync) begin
        o_dout_cal_en <=  r_cal_en    ;
    end
end
`endif// DLFE_AIE_DISABLE

endmodule
