////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10/FSU20
//                 oRU : DCM RT4419/RT4422
//                       VzW RF4440d
//                       VDF RF4448/RF4449/RF2221d/RF2222d
//                       Telus RT8809/RT8811
//                       MSTR_V02
//  Module       : dlfe_in_if
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe ORAN input interface (configurable cell multiplexing) 
//                 dlfe CPRI input interface (Single cell) 
//                 n to m chain multiplexing, Input Control, Debug Mode
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.14 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2020.10.27 | jyzoo.lee     | din Frame Sync Time Stamp Monitoring Support
//  ------------+---------------+-----------------------------------------------
//   2020.11.05 | jyzoo.lee     | Layer Gate Removed, fft,scsType available
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.12.03 | jyzoo.lee     | Supports Beamforming
//  ------------+---------------+-----------------------------------------------
//   2020.12.15 | jyzoo.lee     | Supports DO_BW saturation for input iq 
//  ------------+---------------+-----------------------------------------------
//   2021.02.04 | jyzoo.lee     | ORAN 16bit to T-Bit down Shift Support
//  ------------+---------------+-----------------------------------------------
//   2021.02.10 | jyzoo.lee     | LSSI Support
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Merge the CPRI dedicated module
//  ------------+---------------+-----------------------------------------------
//   2021.06.10 | jyzoo.lee     | DSS Support
//  ------------+---------------+-----------------------------------------------
//   2021.08.11 | jyzoo.lee     | Add H Interface for CPRI 
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | sector multiplexing support (up to 2ccX2sect)
//  ------------+---------------+-----------------------------------------------
//   2021.12.08 | jyzoo.lee     | Test Tone Insertion Support
//  ------------+---------------+-----------------------------------------------
//   2021.12.29 | jyzoo.lee     | Support muxed sector data processing in CPRI
//  ------------+---------------+-----------------------------------------------
//   2022.02.17 | jyzoo.lee     | Support Parameter Map Type1 (CPRI)
//  ------------+---------------+-----------------------------------------------
//   2022.02.21 | jyzoo.lee     | Add CC_ID to distinguish Parameter Map (CPRI)
//  ------------+---------------+-----------------------------------------------
//   2022.02.24 | jyzoo.lee     | Support Double Data Mode (CPRI)
//  ------------+---------------+-----------------------------------------------
//   2022.04.13 | jyzoo.lee     | Fixed mismatched Start RB with DU
//  ------------+---------------+-----------------------------------------------
//   2022.06.30 | jyzoo.lee     | Fixed Resync of Double Mode Buffer 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_in_if
#(
     parameter  NUM_CC              =   1
    ,parameter  NUM_LAYER           =   4
`ifndef DLFE_ORAN_DISABLE
    ,parameter  NUM_O_CHAIN         =   1
`else //DLFE_ORAN_DISABLE
    ,parameter  NUM_LANE_CC         =   4
    ,parameter  NUM_LAYER_LANE      =   2
`endif //DLFE_ORAN_DISABLE
    ,parameter  DI_BW               =   16 
    ,parameter  DO_BW               =   12 
    ,parameter  VENDOR              =  "Xilinx" 
)(
    //--- reset & clk
        input   wire                                            i_clk                  
    ,   input   wire    [01*NUM_CC-1:0]                         i_rst                
            
    //--- from dlfe_param_if
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_1004
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_1100
    ,   input   wire    [08*NUM_CC-1:0]                         i_dlfe_par_1108
    ,   input   wire    [32*NUM_CC-1:0]                         i_dlfe_par_110c
    ,   input   wire    [32*NUM_CC-1:0]                         i_dlfe_par_1110
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_120c
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_1210
    ,   input   wire    [03*NUM_CC-1:0]                         i_dlfe_par_1240
    ,   input   wire    [NUM_LAYER*NUM_CC-1:0]                  i_dlfe_par_1244

    //--- from dlfe_cc
`ifndef DLFE_ORAN_DISABLE
    ,   input   wire    [01*NUM_CC-1:0]                         i_dlfe_par_1008
    ,   input   wire    [01*NUM_CC-1:0]                         i_dlfe_par_1104
    ,   input   wire    [03*NUM_CC-1:0]                         i_dlfe_par_1254

    ,   input   wire    [01*NUM_CC-1:0]                         i_din_frame_sync
    ,   input   wire    [08*NUM_CC-1:0]                         i_din_frame_idx
    ,   input   wire    [01*NUM_LAYER*NUM_CC-1:0]               i_din_en
    ,   input   wire    [2*DI_BW*NUM_LAYER*NUM_CC-1:0]          i_din_iq
    ,   input   wire    [08*NUM_LAYER*NUM_CC-1:0]               i_din_frame_struct
    ,   input   wire    [01*NUM_LAYER*NUM_CC-1:0]               i_din_sys_mode_dss
    ,   input   wire    [01*NUM_LAYER*NUM_CC-1:0]               i_din_re_mask
    ,   input   wire    [15*NUM_LAYER*NUM_CC-1:0]               i_din_beam_id
    ,   input   wire    [05*NUM_CC-1:0]                         i_din_nlayer
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_en        
    ,   output  reg     [2*DO_BW*NUM_O_CHAIN-1:0]               o_dout_iq                
    ,   output  reg     [15*NUM_O_CHAIN-1:0]                    o_dout_beam_id                
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_sys_mode_dss               
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_O_CHAIN-1:0] o_dout_cc_id
    ,   output  reg     [$clog2(NUM_LAYER)*NUM_O_CHAIN-1:0]     o_dout_lyr_id
    ,   output  reg     [05-1:0]                                o_dout_nlayer               
`else //DLFE_ORAN_DISABLE
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_10f0
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_10f4
    ,   input   wire    [01-1:0]                                i_din_tdd_cfg
    ,   input   wire    [01*NUM_LANE_CC-1:0]                    i_din_rts0
    ,   input   wire    [01*NUM_LANE_CC-1:0]                    i_din_rts1
    ,   input   wire    [01*NUM_LANE_CC-1:0]                    i_din_fsync
    ,   input   wire    [01*NUM_LANE_CC-1:0]                    i_din_csync
    ,   input   wire    [2*DI_BW*NUM_LANE_CC-1:0]               i_din_cdata
    ,   input   wire    [01-1:0]                                i_pin0_rts0
    ,   input   wire    [01-1:0]                                i_pin0_rts1
    ,   input   wire    [01-1:0]                                i_pin0_fsync
    ,   input   wire    [01-1:0]                                i_pin0_csync
    ,   input   wire    [2*DI_BW-1:0]                           i_pin0_cdata
    ,   input   wire    [01-1:0]                                i_pin1_rts0
    ,   input   wire    [01-1:0]                                i_pin1_rts1
    ,   input   wire    [01-1:0]                                i_pin1_fsync
    ,   input   wire    [01-1:0]                                i_pin1_csync
    ,   input   wire    [2*DI_BW-1:0]                           i_pin1_cdata
    ,   output  reg     [01*NUM_LAYER_LANE*NUM_LANE_CC-1:0]     o_dout_en        
    ,   output  reg     [2*DO_BW*NUM_LANE_CC-1:0]               o_dout_iq                
    ,   output  reg     [09-1:0]                                o_dout_muw_idx
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_LANE_CC-1:0] o_dout_cc_id
    ,   output  reg     [$clog2(NUM_LAYER)*NUM_LANE_CC-1:0]     o_dout_lyr_id
    ,   output  reg     [12-1:0]                                o_pout0_cb_idx
    ,   output  reg     [05-1:0]                                o_pout0_nmusul
    ,   output  reg     [06-1:0]                                o_pout0_re_map
    ,   output  wire    [01-1:0]                                o_pout0_nmul_en        
    ,   output  wire    [01-1:0]                                o_pout0_sch_srs_idx_en 
    ,   output  wire    [01-1:0]                                o_pout0_null_lyr_ind_en
    ,   output  wire    [2*DI_BW-1:0]                           o_pout0_cparam            
    ,   output  wire    [01-1:0]                                o_pout1_h_en           
    ,   output  wire    [2*DI_BW-1:0]                           o_pout1_cparam            
    ,   output  wire    [01-1:0]                                o_pout1_muwg_fsync
`endif //DLFE_ORAN_DISABLE

    //--- to phase_comp
    ,   output  wire    [01-1:0]                                o_dout_frame_sync
    ,   output  wire    [01-1:0]                                o_dout_subfrm_sync
    ,   output  wire    [01-1:0]                                o_dout_slot_sync
    ,   output  wire    [01-1:0]                                o_dout_symbol_sync
    ,   output  reg     [04-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size

    //--- to dlfe_param_if
`ifndef DLFE_LSSI_DISABLE
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1080
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1084
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1088
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_108c
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1090
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1094
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_1098
    ,   output  reg     [32*NUM_CC-1:0]                         o_dlfe_rpt_109c
`endif //DLFE_LSSI_DISABLE
`ifndef DLFE_MON_SMP_DISABLE
    ,   output  wire    [32*NUM_CC-1:0]                         o_dlfe_rpt_1120
    ,   output  wire    [32*NUM_CC-1:0]                         o_dlfe_rpt_1124
`endif //DLFE_MON_SMP_DISABLE
    ,   output  wire    [22*NUM_CC-1:0]                         o_dlfe_rpt_1130
    ,   output  reg     [16*NUM_CC-1:0]                         o_dlfe_rpt_1138
);

//Parameter Local Logic
localparam              DLFE_MU_015K            =       3'd0                                            ;
localparam              DLFE_MU_030K            =       3'd1                                            ;
localparam              DLFE_MU_060K            =       3'd2                                            ;
localparam              ORAN_MU_015K            =       4'd0                                            ;
localparam              ORAN_MU_030K            =       4'd1                                            ;
localparam              ORAN_MU_060K            =       4'd2                                            ;
localparam              DLFE_FFT0512            =       2'h0                                            ;
localparam              DLFE_FFT1024            =       2'h1                                            ;
localparam              DLFE_FFT2048            =       2'h2                                            ;
localparam              DLFE_FFT4096            =       2'h3                                            ;
localparam              ORAN_FFT0512            =       4'h9                                            ;
localparam              ORAN_FFT1024            =       4'ha                                            ;
localparam              ORAN_FFT2048            =       4'hb                                            ;
localparam              ORAN_FFT4096            =       4'hc                                            ;
localparam              CLK_FRAME               =       22'd2457600                                     ;
localparam              CLK_FRAME_TOL           =       22'd10                                          ;
localparam              NUM_FRAME_XSSI          =      `DLFE_NUM_FRAME_XSSI                             ;
localparam  [DO_BW-1:0] I_TEST_TONE             =       'd2047                                          ;
localparam  [DO_BW-1:0] Q_TEST_TONE             =      -'sd2047                                         ;
`ifndef DLFE_ORAN_DISABLE
localparam              CC_REF                  =       0                                               ;
localparam              CHAIN_REF               =       0                                               ;
localparam              DLY_DIN                 =       4                                               ;   
localparam              DLY_SYNC                =       4                                               ;   
localparam              ID_CC0                  =       0                                               ;
localparam              ID_CC1                  =       1                                               ;
localparam              ID_CC2                  =       2                                               ;
localparam              ID_CC3                  =       3                                               ;
`else //DLFE_ORAN_DISABLE
localparam              ENABLE_TDD              =       0                                               ;
localparam              ENABLE_FSLOT            =       0                                               ;
localparam              CC_REF                  =       0                                               ;
localparam              IDX_LANE_REF            =       0                                               ;
localparam              IDX_LAYER_CNT_REF       =       1                                               ;
localparam              IDX_LAYER_RD_REF        =       0                                               ;
localparam              DLY_DIN                 =       4                                               ;
localparam              DLY_DATA_CSYNC          =       7                                               ;
localparam              DLY_P0_CSYNC            =       7                                               ;
localparam              DLY_P1_CSYNC            =       7                                               ;
localparam              CNT_CSYNC               =       6'd62                                           ;
localparam              RETARD_CPRI_SYNC_GEN    =       2                                               ;
localparam              ID_TDD_4_1              =      'h0                                              ;
localparam              ID_TDD_8_2              =      'h1                                              ;
localparam              TDD_4_1_SLOT0           =      'h4                                              ;
localparam              TDD_8_2_SLOT0           =      'h8                                              ;
localparam              TDD_8_2_SLOT1           =      'h9                                              ;
localparam              TDD_4_1                 =       10'b0111101111                                  ;
localparam              TDD_8_2                 =       10'b0011111111                                  ;
localparam              IDX_GSYMBOL_F_4_1       =       ENABLE_FSLOT ? 4'd12 : 4'd14                    ;
localparam              IDX_GSYMBOL_F_8_2       =       ENABLE_FSLOT ? 4'd12 : 4'd14                    ;
localparam              DO_BW_CPRI              =       15                                              ;
localparam              NUM_SYMBOL_SLOT         =       14                                              ;
localparam              NUM_RE_RB               =       4'd12                                           ;
localparam              NUM_CBUF                =       2                                               ;
localparam              BW_CPRI_CBIDX           =       16                                              ;
localparam              BW_CPRI_NMUSUL          =      `PARAM_MAP_TYPE=="TYPE0" ? 8 : 16                ;
localparam              BW_CPRI_REMAP           =       8                                               ;
localparam              BW_CBIDX                =       12                                              ;
localparam              BW_NMUSUL               =      `PARAM_MAP_TYPE=="TYPE0" ? 5 : 4                 ;
localparam              BW_REMAP                =       6                                               ;
localparam              PARAM_REAR_OFFSET       =       16'h3600                                        ;
localparam  [09-1:0]    NUM_CPARAM_RB_SYMBOL    =       272                                             ;
localparam  [12-1:0]    NUM_CPARAM_RE_SYMBOL    =       NUM_CPARAM_RB_SYMBOL*NUM_RE_RB                  ;
localparam              NUM_CPARAM_RB_SLOT      =       NUM_CPARAM_RB_SYMBOL*NUM_SYMBOL_SLOT            ;
localparam              NUM_CPARAM_RE_SLOT      =       NUM_CPARAM_RE_SYMBOL*NUM_SYMBOL_SLOT            ;
localparam              DLY_CBIDX               =       2                                               ;
localparam              DLY_NMUSUL              =       2                                               ;
localparam              DLY_REMAP               =       0                                               ;
localparam              DLY_MEM_CBIDX           =       1                                               ;
localparam              DLY_MEM_NMUSUL          =       1                                               ;
localparam              DLY_MEM_REMAP           =       3                                               ;
localparam              DLY_DOUT_SYNC           =       4                                               ;
localparam              DLY_SYNC                =       12                                              ;
`endif //DLFE_ORAN_DISABLE

//Logic Variable
genvar gidx ;
integer i,j ;

`ifndef DLFE_ORAN_DISABLE
reg [1-1:0] r_frame_sync ;
`ifndef DLFE_WDOG_DISABLE
reg [21:00] r_frame_sync_cnt ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_frame_sync_cnt <= 22'd0 ;
    end
    else if(i_din_frame_sync[CC_REF]) begin
        r_frame_sync_cnt <= 22'd0 ;
    end
    else begin
        r_frame_sync_cnt <= r_frame_sync_cnt + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    r_frame_sync <= i_din_frame_sync[CC_REF] && (r_frame_sync_cnt>CLK_FRAME-CLK_FRAME_TOL&&r_frame_sync_cnt<CLK_FRAME+CLK_FRAME_TOL) ;
end
`else //DLFE_WDOG_DISABLE
always@(posedge i_clk) begin
    r_frame_sync <= i_din_frame_sync[CC_REF] ;
end
`endif //DLFE_WDOG_DISABLE
reg [02-1:0]        r_iq_swap           [NUM_CC-1:0]    ;
reg [02-1:0]        r_dbg_mode          [NUM_CC-1:0]    ;
reg [01-1:0]        r_dbg_re_mask       [NUM_CC-1:0]    ;
reg [32-1:0]        r_dbg_bf            [NUM_CC-1:0]    ;
reg [15-1:0]        r_dbg_beam_id       [NUM_CC-1:0]    ;
reg [05-1:0]        r_dbg_nlayer        [NUM_CC-1:0]    ;
reg [08-1:0]        r_dbg_frame_struct  [NUM_CC-1:0]    ;
reg [08-1:0]        r_mp_frame_struct   [NUM_CC-1:0]    ;
reg [NUM_LAYER-1:0] r_layer_gate        [NUM_CC-1:0]    ;
reg [01-1:0]        r_frame_struct_sel  [NUM_CC-1:0]    ;
reg [04-1:0]        r_mp_fft            [NUM_CC-1:0]    ;
reg [04-1:0]        r_mp_scs            [NUM_CC-1:0]    ;
reg [32-1:0]        r_smp_mon_cfg       [NUM_CC-1:0]    ;
reg [03-1:0]        r_down_shift        [NUM_CC-1:0]    ;
reg [12-1:0]        r_ntone             [NUM_CC-1:0]    ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        case(i_dlfe_par_1210[((02)*(i+1)-1)-:(02)]) 
            DLFE_FFT0512    : r_mp_fft[i] = ORAN_FFT0512   ;
            DLFE_FFT1024    : r_mp_fft[i] = ORAN_FFT1024   ;
            DLFE_FFT2048    : r_mp_fft[i] = ORAN_FFT2048   ;
            DLFE_FFT4096    : r_mp_fft[i] = ORAN_FFT4096   ;
            default         : r_mp_fft[i] = 4'd0           ;  
        endcase
        case(i_dlfe_par_1240[((03)*(i+1)-1)-:(03)]) 
            DLFE_MU_015K    : r_mp_scs[i] = ORAN_MU_015K ;
            DLFE_MU_030K    : r_mp_scs[i] = ORAN_MU_030K ;
            DLFE_MU_060K    : r_mp_scs[i] = ORAN_MU_060K ;
            default         : r_mp_scs[i] = 4'd0         ;  
        endcase
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(i_din_frame_sync[CC_REF]) begin 
            r_iq_swap          [i]  <=  i_dlfe_par_1004 [((02)*(i+1)-1)-:(02)]   ;
            r_frame_struct_sel [i]  <=  i_dlfe_par_1008 [((01)*(i+1)-1)-:(01)]   ;
            r_dbg_mode         [i]  <=  i_dlfe_par_1100 [((02)*(i+1)-1)-:(02)]   ;
            r_dbg_re_mask      [i]  <=  i_dlfe_par_1104 [((01)*(i+1)-1)-:(01)]   ;
            r_dbg_frame_struct [i]  <=  i_dlfe_par_1108 [((08)*(i+1)-1)-:(08)]   ;
            r_dbg_bf           [i]  <=  i_dlfe_par_110c [((32)*(i+1)-1)-:(32)]   ;
            r_smp_mon_cfg      [i]  <=  i_dlfe_par_1110 [((32)*(i+1)-1)-:(32)]   ;
            r_mp_frame_struct  [i]  <= {r_mp_fft[i],r_mp_scs[i]}                 ;
            r_layer_gate       [i]  <=  i_dlfe_par_1244 [((NUM_LAYER)*(i+1)-1)-:(NUM_LAYER)]   ;
            r_down_shift       [i]  <=  i_dlfe_par_1254 [((03)*(i+1)-1)-:(03)]   ;
            r_ntone            [i]  <=  i_dlfe_par_120c [((12)*(i+1)-1)-:(12)]   ;
        end
    end
end
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_dbg_beam_id [i] = r_dbg_bf[i][15-1:00] ;
        r_dbg_nlayer  [i] = r_dbg_bf[i][21-1:16] ;
    end
end
reg [$clog2(NUM_LAYER)-1:0] r_id_layer          [NUM_LAYER*NUM_CC-1:0]              ;
reg [01-1:0]                r_en                [NUM_LAYER*NUM_CC-1:0]              ;
reg [2*DI_BW-1:0]           r_iq                [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                r_sys_mode_dss      [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                r_re_mask           [NUM_LAYER*NUM_CC-1:0]              ;   
reg [15-1:0]                r_beam_id           [NUM_LAYER*NUM_CC-1:0]              ;   
reg [08-1:0]                r_cp_frame_struct   [NUM_LAYER*NUM_CC-1:0]              ;
reg [01-1:0]                rr_en               [NUM_LAYER*NUM_CC-1:0]              ;
reg [2*DI_BW-1:0]           rr_iq               [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                rr_sys_mode_dss     [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                rr_re_mask          [NUM_LAYER*NUM_CC-1:0]              ;   
reg [15-1:0]                rr_beam_id          [NUM_LAYER*NUM_CC-1:0]              ;   
wire[01-1:0]                w_rrr_en            [NUM_LAYER*NUM_CC-1:0]              ;
wire[2*DI_BW-1:0]           w_rrr_iq            [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                rrr_en              [NUM_LAYER*NUM_CC-1:0]              ;
reg [01-1:0]                rrr_sys_mode_dss    [NUM_LAYER*NUM_CC-1:0]              ;   
reg [15-1:0]                rrr_beam_id         [NUM_LAYER*NUM_CC-1:0]              ;   
reg [01-1:0]                rrrr_sys_mode_dss   [NUM_LAYER*NUM_CC-1:0]              ;   
reg [15-1:0]                rrrr_beam_id        [NUM_LAYER*NUM_CC-1:0]              ;   
wire[01-1:0]                w_rrr_sat_en        [NUM_LAYER*NUM_CC-1:0]              ;
wire[2*DO_BW-1:0]           w_rrr_sat_iq        [NUM_LAYER*NUM_CC-1:0]              ;   
reg [NUM_LAYER*NUM_CC-1:0]  r_dly_en            [DLY_DIN:0]                         ;
reg [2*DO_BW-1:0]           r_dly_iq            [NUM_LAYER*NUM_CC-1:0][DLY_DIN:0]   ;
reg [01-1:0]                r_dly_sys_mode_dss  [NUM_LAYER*NUM_CC-1:0][DLY_DIN:0]   ;
reg [15-1:0]                r_dly_beam_id       [NUM_LAYER*NUM_CC-1:0][DLY_DIN:0]   ;
generate for(gidx=0;gidx<NUM_LAYER*NUM_CC;gidx=gidx+1) begin : g00_0_inctrl_cc_lyr
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        r_id_layer [gidx] <= {{$clog2(NUM_LAYER)}{1'b1}}&(gidx%NUM_LAYER) ; 
    end
end
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[gidx]) begin
        r_iq                [gidx]  <=  i_din_iq            [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
        r_sys_mode_dss      [gidx]  <=  i_din_sys_mode_dss  [((01     )*(gidx+1)-1)-:(01     )] ;
        r_re_mask           [gidx]  <=  i_din_re_mask       [((01     )*(gidx+1)-1)-:(01     )] ;
        r_beam_id           [gidx]  <=  i_din_beam_id       [((15     )*(gidx+1)-1)-:(15     )] ;
        r_cp_frame_struct   [gidx]  <=  i_din_frame_struct  [((08     )*(gidx+1)-1)-:(08     )] ;
    end
end
always@(posedge i_clk) begin
    rr_en[gidx]  <=  r_en[gidx] ;
    if(r_en[gidx]) begin
        rr_iq[gidx]  <=  r_iq_swap[gidx/NUM_LAYER][0] ? {r_iq[gidx][(DI_BW*1-1)-:DI_BW],r_iq[gidx][(DI_BW*2-1)-:DI_BW]} : r_iq[gidx]  ;   
        rr_sys_mode_dss[gidx] <=  r_sys_mode_dss[gidx] ;
        if(|r_dbg_mode[gidx/NUM_LAYER]) begin
            rr_re_mask[gidx]  <=  r_dbg_re_mask[gidx/NUM_LAYER]   ;
            rr_beam_id[gidx]  <=  r_dbg_beam_id[gidx/NUM_LAYER]   ;
        end
        else begin
            rr_re_mask[gidx]  <=  r_re_mask[gidx] ;
            rr_beam_id[gidx]  <=  r_beam_id[gidx] ;
        end
    end
end

ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   3           )
 ,.IO_BW        (   DI_BW       ))
u00_in_shiftd_rnd 
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   rr_en[gidx]                                 )
    ,.i_in      (   {{2*DI_BW}{rr_re_mask[gidx]}}&{rr_iq[gidx]} )
    ,.i_shiftd  (   r_down_shift[gidx/NUM_LAYER]                )
    ,.o_out_en  (   w_rrr_en[gidx]                              )
    ,.o_out     (   w_rrr_iq[gidx]                              )
);
always@(posedge i_clk) begin
    rrr_en[gidx]  <=  rr_en[gidx] ;
    if(rr_en[gidx]) begin
        rrr_sys_mode_dss [gidx] <= rr_sys_mode_dss [gidx] ;   
        rrr_beam_id [gidx] <= rr_beam_id [gidx] ;   
    end
end
always@(posedge i_clk) begin
    if(rrr_en[gidx]) begin
        rrrr_sys_mode_dss [gidx] <= rrr_sys_mode_dss [gidx] ;   
        rrrr_beam_id [gidx] <= rrr_beam_id [gidx] ;   
    end
end
always@(posedge i_clk) begin
    if(w_rrr_en[gidx]) begin
        r_dly_beam_id      [gidx][0] <=  rrrr_beam_id       [gidx] ;   
        r_dly_sys_mode_dss [gidx][0] <=  rrrr_sys_mode_dss  [gidx] ;   
    end
end
ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   DI_BW       )
 ,.DO_BW        (   DO_BW       ))
u01_in_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   w_rrr_en        [gidx]      )
    ,.i_in      (   w_rrr_iq        [gidx]      )
    ,.o_out_en  (   w_rrr_sat_en    [gidx]      )
    ,.o_out     (   w_rrr_sat_iq    [gidx]      )
);
always@(*) begin
    r_dly_en[0][gidx]  =   w_rrr_sat_en    [gidx]  ;
    r_dly_iq[gidx][0]  =   w_rrr_sat_iq    [gidx]  ;
end

always@(posedge i_clk) begin
    for(i=1;i<=DLY_DIN;i=i+1) begin
        r_dly_en[i][gidx]  <=  r_dly_en[i-1][gidx] ;
        if(r_dly_en[i-1][gidx]) begin
            r_dly_iq           [gidx][i]   <=  r_dly_iq           [gidx][i-1] ;   
            r_dly_beam_id      [gidx][i]   <=  r_dly_beam_id      [gidx][i-1] ;   
            r_dly_sys_mode_dss [gidx][i]   <=  r_dly_sys_mode_dss [gidx][i-1] ;   
        end
    end
end
end
endgenerate

reg [05-1:0]    r_nlayer        [NUM_CC-1:0]            ; 
reg [05-1:0]    rr_nlayer       [NUM_CC-1:0]            ; 
reg [05-1:0]    r_dly_nlayer    [NUM_CC-1:0][DLY_DIN:0] ; 
reg [01-1:0]    r_cc_en         [NUM_CC-1:0]            ; 
reg [01-1:0]    rr_cc_en        [NUM_CC-1:0]            ; 
reg [01-1:0]    r_dly_cc_en     [NUM_CC-1:0][DLY_DIN:0] ; 
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_1_inctrl_cc
always@(posedge i_clk) begin
    r_cc_en [gidx]  <=  |i_din_en[((01*NUM_LAYER)*(gidx+1)-1)-:(01*NUM_LAYER)]   ;
    if(|i_din_en[((01*NUM_LAYER)*(gidx+1)-1)-:(01*NUM_LAYER)]) begin
        r_nlayer [gidx]  <=  i_din_nlayer[((05)*(gidx+1)-1)-:(05)]   ;
    end
end
always@(posedge i_clk) begin
    rr_cc_en[gidx]  <=  r_cc_en [gidx]   ;
    if(r_cc_en [gidx]) begin
        if(|r_dbg_mode[gidx]) begin
            rr_nlayer [gidx]  <=  r_dbg_nlayer [gidx] ;
        end
        else begin
            rr_nlayer [gidx]  <=  r_nlayer [gidx] ;
        end
    end
end
always@(*) begin
    r_dly_cc_en    [gidx][0]   =   rr_cc_en    [gidx] ;
    r_dly_nlayer   [gidx][0]   =   rr_nlayer   [gidx] ;   
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_DIN;i=i+1) begin
        r_dly_cc_en[gidx][i]  <=  r_dly_cc_en[gidx][i-1] ;
        if(r_dly_cc_en[gidx][i-1]) begin
            r_dly_nlayer [gidx][i]   <=  r_dly_nlayer [gidx][i-1] ;   
        end
    end
end
end
endgenerate

reg [01-1:0] rr_frame_sync  ;
reg [04-1:0] rr_mu         [NUM_CC-1:0] ;
reg [04-1:0] rr_fft_size   [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    rr_frame_sync   <=  r_frame_sync    ;
    for(i=0;i<NUM_CC;i=i+1) begin
        if(r_frame_sync) begin
            if(|r_dbg_mode[i]) begin
                rr_mu       [i] <=  r_dbg_frame_struct[i][3:0] ;
                rr_fft_size [i] <=  r_dbg_frame_struct[i][7:4] ;
            end
            else begin
                rr_mu       [i] <=  r_frame_struct_sel[i] ? r_cp_frame_struct[NUM_LAYER*i][3:0] : r_mp_frame_struct[i][3:0] ;
                rr_fft_size [i] <=  r_frame_struct_sel[i] ? r_cp_frame_struct[NUM_LAYER*i][7:4] : r_mp_frame_struct[i][7:4] ;
            end
        end
    end
end

wire        w_frame_sync     ;
wire        w_subfrm_sync    ;
wire        w_slot_sync      ;
wire        w_symbol_sync    ;
wire [3:0]  w_subfrm         ;
wire [7:0]  w_slot           ;
wire [3:0]  w_symbol         ;
ref_vsync_gen u02_dlfe_rtg
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( rr_mu[CC_REF]             )
    ,.i_retard              ( 22'd4                     )
    ,.i_frame_sync          ( rr_frame_sync             )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_frame_sync              )   
    ,.o_subfrm_sync         ( w_subfrm_sync             )   
    ,.o_slot_sync           ( w_slot_sync               )   
    ,.o_symbol_sync         ( w_symbol_sync             )   
    ,.o_subfrm              ( w_subfrm                  )          
    ,.o_slot                ( w_slot                    )          
    ,.o_symbol              ( w_symbol                  )          
);

reg [01*NUM_O_CHAIN-1:0]                    r_mux_en            ;
reg [2*DO_BW*NUM_O_CHAIN-1:0]               r_mux_iq            ;   
reg [15*NUM_O_CHAIN-1:0]                    r_mux_beam_id       ;
reg [01*NUM_O_CHAIN-1:0]                    r_mux_sys_mode_dss  ;
reg [(`mlib_clog2(NUM_CC))*NUM_O_CHAIN-1:0] r_mux_cc_id         ;
reg [$clog2(NUM_LAYER)*NUM_O_CHAIN-1:0]     r_mux_lyr_id        ;
reg [05-1:0]                                r_mux_nlayer        ;
generate if(NUM_CC==2&&NUM_LAYER==4) begin : g01_chain_ctrl
always@(posedge i_clk) begin
    case(r_dly_en[DLY_DIN]) 
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<0 : begin r_mux_en <= r_dly_en[DLY_DIN][0]; r_mux_iq <= r_dly_iq[0][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[0][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[0][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[0]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<1 : begin r_mux_en <= r_dly_en[DLY_DIN][1]; r_mux_iq <= r_dly_iq[1][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[1][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[1][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[1]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<2 : begin r_mux_en <= r_dly_en[DLY_DIN][2]; r_mux_iq <= r_dly_iq[2][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[2][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[2][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[2]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<3 : begin r_mux_en <= r_dly_en[DLY_DIN][3]; r_mux_iq <= r_dly_iq[3][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[3][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[3][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[3]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<4 : begin r_mux_en <= r_dly_en[DLY_DIN][4]; r_mux_iq <= r_dly_iq[4][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[4][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[4][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[4]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<5 : begin r_mux_en <= r_dly_en[DLY_DIN][5]; r_mux_iq <= r_dly_iq[5][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[5][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[5][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[5]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<6 : begin r_mux_en <= r_dly_en[DLY_DIN][6]; r_mux_iq <= r_dly_iq[6][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[6][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[6][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[6]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<7 : begin r_mux_en <= r_dly_en[DLY_DIN][7]; r_mux_iq <= r_dly_iq[7][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[7][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[7][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[7]; end
        default : r_mux_en <= 1'd0 ;
    endcase
end
end
else if(NUM_CC==2&&NUM_LAYER==2) begin
always@(posedge i_clk) begin
    case(r_dly_en[DLY_DIN]) 
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<0 : begin r_mux_en <= r_dly_en[DLY_DIN][0]; r_mux_iq <= r_dly_iq[0][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[0][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[0][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[0]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<1 : begin r_mux_en <= r_dly_en[DLY_DIN][1]; r_mux_iq <= r_dly_iq[1][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[1][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[1][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[1]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<2 : begin r_mux_en <= r_dly_en[DLY_DIN][2]; r_mux_iq <= r_dly_iq[2][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[2][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[2][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[2]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<3 : begin r_mux_en <= r_dly_en[DLY_DIN][3]; r_mux_iq <= r_dly_iq[3][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[3][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[3][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[3]; end
        default : r_mux_en <= 1'd0 ;
    endcase
end
end
else if(NUM_CC==4&&NUM_LAYER==2) begin
always@(posedge i_clk) begin
    case(r_dly_en[DLY_DIN]) 
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<0 : begin r_mux_en <= r_dly_en[DLY_DIN][0]; r_mux_iq <= r_dly_iq[0][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[0][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[0][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[0]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<1 : begin r_mux_en <= r_dly_en[DLY_DIN][1]; r_mux_iq <= r_dly_iq[1][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[1][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[1][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[1]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<2 : begin r_mux_en <= r_dly_en[DLY_DIN][2]; r_mux_iq <= r_dly_iq[2][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[2][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[2][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[2]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<3 : begin r_mux_en <= r_dly_en[DLY_DIN][3]; r_mux_iq <= r_dly_iq[3][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[3][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[3][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC1][DLY_DIN]; r_mux_cc_id <= ID_CC1; r_mux_lyr_id <= r_id_layer[3]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<4 : begin r_mux_en <= r_dly_en[DLY_DIN][4]; r_mux_iq <= r_dly_iq[4][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[4][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[4][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC2][DLY_DIN]; r_mux_cc_id <= ID_CC2; r_mux_lyr_id <= r_id_layer[4]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<5 : begin r_mux_en <= r_dly_en[DLY_DIN][5]; r_mux_iq <= r_dly_iq[5][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[5][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[5][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC2][DLY_DIN]; r_mux_cc_id <= ID_CC2; r_mux_lyr_id <= r_id_layer[5]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<6 : begin r_mux_en <= r_dly_en[DLY_DIN][6]; r_mux_iq <= r_dly_iq[6][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[6][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[6][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC3][DLY_DIN]; r_mux_cc_id <= ID_CC3; r_mux_lyr_id <= r_id_layer[6]; end
        {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<7 : begin r_mux_en <= r_dly_en[DLY_DIN][7]; r_mux_iq <= r_dly_iq[7][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[7][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[7][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC3][DLY_DIN]; r_mux_cc_id <= ID_CC3; r_mux_lyr_id <= r_id_layer[7]; end
        default : r_mux_en <= 1'd0 ;
    endcase
end
end
else begin //NUM_CC==1
if(NUM_O_CHAIN==1) begin
    if(NUM_LAYER==2) begin
        always@(posedge i_clk) begin
            case(r_dly_en[DLY_DIN]) 
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<0 : begin r_mux_en <= r_dly_en[DLY_DIN][0]; r_mux_iq <= r_dly_iq[0][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[0][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[0][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[0]; end
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<1 : begin r_mux_en <= r_dly_en[DLY_DIN][1]; r_mux_iq <= r_dly_iq[1][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[1][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[1][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[1]; end
                default : r_mux_en <= 1'd0 ;
            endcase
        end
    end
    else begin
        always@(posedge i_clk) begin
            case(r_dly_en[DLY_DIN]) 
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<0 : begin r_mux_en <= r_dly_en[DLY_DIN][0]; r_mux_iq <= r_dly_iq[0][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[0][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[0][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[0]; end
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<1 : begin r_mux_en <= r_dly_en[DLY_DIN][1]; r_mux_iq <= r_dly_iq[1][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[1][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[1][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[1]; end
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<2 : begin r_mux_en <= r_dly_en[DLY_DIN][2]; r_mux_iq <= r_dly_iq[2][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[2][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[2][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[2]; end
                {{{NUM_LAYER*NUM_CC-1}{1'd0}},1'd1}<<3 : begin r_mux_en <= r_dly_en[DLY_DIN][3]; r_mux_iq <= r_dly_iq[3][DLY_DIN]; r_mux_beam_id <= r_dly_beam_id[3][DLY_DIN]; r_mux_sys_mode_dss <= r_dly_sys_mode_dss[3][DLY_DIN]; r_mux_nlayer <= r_dly_nlayer[ID_CC0][DLY_DIN]; r_mux_cc_id <= ID_CC0; r_mux_lyr_id <= r_id_layer[3]; end
                default : r_mux_en <= 1'd0 ;
            endcase
        end
    end
end//if(NUM_O_CHAIN==1)
else if(NUM_O_CHAIN==2) begin//if(NUM_O_CHAIN==1)
    always@(posedge i_clk) begin
            r_mux_nlayer    <= r_dly_nlayer[ID_CC0][DLY_DIN]  ;
            if(r_dly_en[DLY_DIN][0]) begin
                r_mux_en            [((01)*(0+1)-1)-:(01)]              <= r_dly_en[DLY_DIN][0]                ; 
                r_mux_iq            [((2*DO_BW)*(0+1)-1)-:(2*DO_BW)]    <= r_dly_iq[0][DLY_DIN]                ; 
                r_mux_beam_id       [((15)*(0+1)-1)-:(15)]              <= r_dly_beam_id[0][DLY_DIN]           ; 
                r_mux_sys_mode_dss  [((01)*(0+1)-1)-:(01)]              <= r_dly_sys_mode_dss[0][DLY_DIN]      ; 
                r_mux_cc_id         [((`mlib_clog2(NUM_CC))*(0+1)-1)-:`mlib_clog2(NUM_CC)]  <= ID_CC0          ; 
                r_mux_lyr_id        [(($clog2(NUM_LAYER))*(0+1)-1)-:($clog2(NUM_LAYER))]    <= r_id_layer[0]   ; 
            end
            else if(r_dly_en[DLY_DIN][1]) begin
                r_mux_en            [((01)*(0+1)-1)-:(01)]              <= r_dly_en[DLY_DIN][1]                ; 
                r_mux_iq            [((2*DO_BW)*(0+1)-1)-:(2*DO_BW)]    <= r_dly_iq[1][DLY_DIN]                ; 
                r_mux_beam_id       [((15)*(0+1)-1)-:(15)]              <= r_dly_beam_id[1][DLY_DIN]           ; 
                r_mux_sys_mode_dss  [((01)*(0+1)-1)-:(01)]              <= r_dly_sys_mode_dss[1][DLY_DIN]      ; 
                r_mux_cc_id         [((`mlib_clog2(NUM_CC))*(0+1)-1)-:`mlib_clog2(NUM_CC)]  <= ID_CC0          ; 
                r_mux_lyr_id        [(($clog2(NUM_LAYER))*(0+1)-1)-:($clog2(NUM_LAYER))]    <= r_id_layer[1]   ; 
            end
            else begin
                r_mux_en            [((01)*(0+1)-1)-:(01)]              <= 1'd0                                ;
            end
            if(r_dly_en[DLY_DIN][2]) begin
                r_mux_en            [((01)*(1+1)-1)-:(01)]              <= r_dly_en[DLY_DIN][2]                ; 
                r_mux_iq            [((2*DO_BW)*(1+1)-1)-:(2*DO_BW)]    <= r_dly_iq[2][DLY_DIN]                ; 
                r_mux_beam_id       [((15)*(1+1)-1)-:(15)]              <= r_dly_beam_id[2][DLY_DIN]           ; 
                r_mux_sys_mode_dss  [((01)*(1+1)-1)-:(01)]              <= r_dly_sys_mode_dss[2][DLY_DIN]      ; 
                r_mux_cc_id         [((`mlib_clog2(NUM_CC))*(1+1)-1)-:`mlib_clog2(NUM_CC)]  <= ID_CC0          ; 
                r_mux_lyr_id        [(($clog2(NUM_LAYER))*(1+1)-1)-:($clog2(NUM_LAYER))]    <= r_id_layer[2]   ; 
            end
            else if(r_dly_en[DLY_DIN][3]) begin
                r_mux_en            [((01)*(1+1)-1)-:(01)]              <= r_dly_en[DLY_DIN][3]                ; 
                r_mux_iq            [((2*DO_BW)*(1+1)-1)-:(2*DO_BW)]    <= r_dly_iq[3][DLY_DIN]                ; 
                r_mux_beam_id       [((15)*(1+1)-1)-:(15)]              <= r_dly_beam_id[3][DLY_DIN]           ; 
                r_mux_sys_mode_dss  [((01)*(1+1)-1)-:(01)]              <= r_dly_sys_mode_dss[3][DLY_DIN]      ; 
                r_mux_cc_id         [((`mlib_clog2(NUM_CC))*(1+1)-1)-:`mlib_clog2(NUM_CC)]  <= ID_CC0          ; 
                r_mux_lyr_id        [(($clog2(NUM_LAYER))*(1+1)-1)-:($clog2(NUM_LAYER))]    <= r_id_layer[3]   ; 
            end
            else begin
                r_mux_en            [((01)*(1+1)-1)-:(01)]              <= 1'd0                                ;
            end
    end
end//if(NUM_O_CHAIN==1)
else if(NUM_O_CHAIN==NUM_LAYER) begin//if(NUM_O_CHAIN==1) 
    always@(posedge i_clk) begin
        r_mux_en        <= r_dly_en    [DLY_DIN]   ; 
        r_mux_nlayer    <= r_dly_nlayer[ID_CC0][DLY_DIN]  ;
        for(i=0;i<NUM_O_CHAIN;i=i+1) begin
            if(r_dly_en[DLY_DIN][i]) begin
                r_mux_iq            [((2*DO_BW)*(i+1)-1)-:(2*DO_BW)]    <= r_dly_iq[i][DLY_DIN]                ; 
                r_mux_beam_id       [((15)*(i+1)-1)-:(15)]              <= r_dly_beam_id[i][DLY_DIN]           ; 
                r_mux_sys_mode_dss  [((01)*(i+1)-1)-:(01)]              <= r_dly_sys_mode_dss[i][DLY_DIN]      ; 
                r_mux_cc_id         [((`mlib_clog2(NUM_CC))*(i+1)-1)-:`mlib_clog2(NUM_CC)]  <= ID_CC0          ; 
                r_mux_lyr_id        [(($clog2(NUM_LAYER))*(i+1)-1)-:($clog2(NUM_LAYER))]    <= r_id_layer[i]   ; 
            end
        end
    end
end//if(NUM_O_CHAIN==1)
end
endgenerate
always@(posedge i_clk) begin
    if(w_frame_sync) begin
        o_dout_mu   <=  rr_mu[CC_REF] ;
        for(i=0;i<NUM_CC;i=i+1) begin
            o_dout_fft_size[((04)*(i+1)-1)-:(04)] <=  rr_fft_size[i]    ;
        end
    end
end
reg [01-1:0]                r_dout_mon_en   [NUM_O_CHAIN-1:0] ;
reg [2*DO_BW-1:0]           r_dout_mon_iq   [NUM_O_CHAIN-1:0] ;
reg [$clog2(NUM_LAYER)-1:0] r_dout_mon_lyr  [NUM_O_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g02_dout_chain
always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)]  <=  r_mux_en[((01)*(gidx+1)-1)-:(01)] ;        
    if(w_frame_sync) begin
        o_dout_cc_id    [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <=  ID_CC0 ;
        o_dout_lyr_id   [(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))] <=  r_id_layer[0]   ;
    end
    else if(r_mux_en[((01)*(gidx+1)-1)-:(01)]) begin
        o_dout_cc_id        [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]   <=  r_mux_cc_id     [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]   ;
        o_dout_lyr_id       [(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))]     <=  r_mux_lyr_id    [(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))]     ;
        o_dout_iq           [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]     <=  r_mux_iq            [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] ;               
        o_dout_beam_id      [((15)*(gidx+1)-1)-:(15)]               <=  r_mux_beam_id       [((15)*(gidx+1)-1)-:(15)]           ;               
        o_dout_sys_mode_dss [((01)*(gidx+1)-1)-:(01)]               <=  r_mux_sys_mode_dss  [((01)*(gidx+1)-1)-:(01)]           ;               
    end
end
always@(*) begin
    r_dout_mon_en [gidx] = o_dout_en    [((01)*(gidx+1)-1)-:(01)] ;
    r_dout_mon_iq [gidx] = o_dout_iq    [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] ;
    r_dout_mon_lyr[gidx] = o_dout_lyr_id[(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))] ;
end
end
endgenerate
always@(posedge i_clk) begin
    if(|r_mux_en) begin
        o_dout_nlayer   <=  r_mux_nlayer    ;               
    end
end
ylib_reg #(
     .WIDTH     (    4          ) 
    ,.DEPTH     (    DLY_SYNC   )) 
u03_fsync_dly
(
     .i_clk      (  i_clk               )
    ,.i_in       ( {w_frame_sync        ,w_subfrm_sync        ,w_slot_sync        ,w_symbol_sync      }   )
    ,.o_out      ( {o_dout_frame_sync   ,o_dout_subfrm_sync   ,o_dout_slot_sync   ,o_dout_symbol_sync }   )
);

`ifndef  DLFE_LSSI_DISABLE
wire    [0:0]   w_lssi_en    [NUM_LAYER*NUM_CC-1:0]   ;
wire    [6:0]   w_lssi_id    [NUM_LAYER*NUM_CC-1:0]   ;
wire    [31:0]  w_lssi       [NUM_LAYER*NUM_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_LAYER*NUM_CC;gidx=gidx+1) begin : g04_lssi
ylib_xssi #(
     .NUM_FRAME     (    NUM_FRAME_XSSI     ) 
    ,.RPT_FRAME     (    7'd0               ) 
    ,.BW_SIG        (    DI_BW              ) 
    ,.ID_XSSI       (    7'd0               )) 
u04_lssi
(
      .i_rst            (     i_rst[gidx/NUM_LAYER]                 )
     ,.i_clk            (     i_clk                                 )
     ,.i_frame_sync     (     r_frame_sync                          )
     ,.i_sig_en         (     r_en[gidx]                            )
     ,.i_sig_i          (     r_iq[gidx][(DI_BW*2-1)-:DI_BW]        )
     ,.i_sig_q          (     r_iq[gidx][(DI_BW*1-1)-:DI_BW]        )
     ,.o_xssi_en        (     w_lssi_en[gidx]                       )
     ,.o_xssi_id        (     w_lssi_id[gidx]                       )
     ,.o_xssi           (     w_lssi   [gidx]                       )
);
end
endgenerate
`endif //DLFE_LSSI_DISABLE
`else //DLFE_ORAN_DISABLE
reg [02-1:0] r_dbg_mode  [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(|i_din_fsync) begin 
            r_dbg_mode  [i]  <=  i_dlfe_par_1100 [((02)*(i+1)-1)-:(02)]   ;
        end
    end
end
reg [01-1:0]     r_fsync            ;
reg [01-1:0]     r_p0_rts0          ;
reg [01-1:0]     r_p0_frame_sync    ;
always@(posedge i_clk) begin
    r_p0_rts0       <= i_pin0_rts0 ; 
    r_p0_frame_sync <= i_pin0_rts0&~r_p0_rts0 ; 
    r_fsync         <= i_din_fsync[((01)*(IDX_LANE_REF+1)-1)-:(01)]  ; 
end
reg [1-1:0] r_frame_sync ;
`ifndef DLFE_WDOG_DISABLE
reg [21:00] r_frame_sync_cnt ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_frame_sync_cnt <= 22'd0 ;
    end
    else if(i_din_fsync[((01)*(IDX_LANE_REF+1)-1)-:(01)]&~r_fsync) begin
        r_frame_sync_cnt <= 22'd0 ;
    end
    else begin
        r_frame_sync_cnt <= r_frame_sync_cnt + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    r_frame_sync <= (i_din_fsync[((01)*(IDX_LANE_REF+1)-1)-:(01)]&~r_fsync) && (r_frame_sync_cnt>CLK_FRAME-CLK_FRAME_TOL&&r_frame_sync_cnt<CLK_FRAME+CLK_FRAME_TOL) ;
end
`else //DLFE_WDOG_DISABLE
always@(posedge i_clk) begin
    r_frame_sync <= i_din_fsync[((01)*(IDX_LANE_REF+1)-1)-:(01)]&~r_fsync ; 
end
`endif //DLFE_WDOG_DISABLE
reg [06-1:0] r_csync_cnt  ;
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        r_csync_cnt <=  6'd0  ;
    end
    else begin
        r_csync_cnt <=  r_csync_cnt + 1'd1  ;
    end
end
reg [01-1:0]        r_csync    [NUM_LANE_CC-1:0][DLY_DATA_CSYNC:0]   ;
reg [2*DI_BW-1:0]   r_cdata    [NUM_LANE_CC-1:0][DLY_DATA_CSYNC:0]   ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_csync [i][1] <= r_csync_cnt==CNT_CSYNC ; 
        r_cdata [i][1] <= i_din_cdata [((2*DI_BW)*(i+1)-1)-:(2*DI_BW)] ; 
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        for(j=2;j<=DLY_DATA_CSYNC;j=j+1) begin
            r_csync [i][j] <=   r_csync [i][j-1] ; 
            r_cdata [i][j] <=   r_cdata [i][j-1] ; 
        end
    end
end
reg [06-1:0] r_p0_csync_cnt  ;
always@(posedge i_clk) begin
    if(r_p0_frame_sync) begin
        r_p0_csync_cnt <=  6'd0  ;
    end
    else begin
        r_p0_csync_cnt <=  r_p0_csync_cnt + 1'd1  ;
    end
end
reg [01-1:0]        r_p0_csync  [DLY_P0_CSYNC:0]   ;
reg [2*DI_BW-1:0]   r_p0_cdata  [DLY_P0_CSYNC:0]   ;
reg [2*DI_BW-1:0]   r_p1_cdata  [DLY_P1_CSYNC:0]   ;
always@(*) begin
    r_p0_csync [0] =   r_p0_csync_cnt==CNT_CSYNC ; 
    r_p0_cdata [0] =   i_pin0_cdata ; 
    r_p1_cdata [0] =   i_pin1_cdata ; 
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_P0_CSYNC;i=i+1) begin
        r_p0_csync [i]  <=   r_p0_csync [i-1] ; 
        r_p0_cdata [i]  <=   r_p0_cdata [i-1] ; 
    end
    for(i=1;i<=DLY_P1_CSYNC;i=i+1) begin
        r_p1_cdata [i]  <=   r_p1_cdata [i-1] ; 
    end
end

reg [01-1:0]        r_tdd_cfg  ;
reg [02-1:0]        r_iq_swap           [NUM_CC-1:0]    ;
reg [08-1:0]        r_dbg_frame_struct  [NUM_CC-1:0]    ;
reg [32-1:0]        r_dbg_bf            [NUM_CC-1:0]    ;
reg [08-1:0]        r_mp_frame_struct   [NUM_CC-1:0]    ;
reg [NUM_LAYER-1:0] r_layer_gate        [NUM_CC-1:0]    ;
reg [01-1:0]        r_frame_struct_sel  [NUM_CC-1:0]    ;
reg [12-1:0]        r_ntone             [NUM_CC-1:0]    ;
reg [04-1:0]        r_mp_fft            [NUM_CC-1:0]    ;
reg [04-1:0]        r_mp_scs            [NUM_CC-1:0]    ;
reg [32-1:0]        r_smp_mon_cfg       [NUM_CC-1:0]    ;
reg [12-1:0]        r_re_start          [NUM_CC-1:0]    ;
reg [01-1:0]        r_param_rear_mode   [NUM_CC-1:0]    ;
reg [01-1:0]        r_data_double_mode  [NUM_CC-1:0]    ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        case(i_dlfe_par_1210[((02)*(i+1)-1)-:(02)]) 
            DLFE_FFT0512    : r_mp_fft[i] = ORAN_FFT0512    ;
            DLFE_FFT1024    : r_mp_fft[i] = ORAN_FFT1024    ;
            DLFE_FFT2048    : r_mp_fft[i] = ORAN_FFT2048    ;
            DLFE_FFT4096    : r_mp_fft[i] = ORAN_FFT4096    ;
            default         : r_mp_fft[i] = 4'd0            ;  
        endcase
        case(i_dlfe_par_1240[((03)*(i+1)-1)-:(03)]) 
            DLFE_MU_015K    : r_mp_scs[i] = ORAN_MU_015K    ;
            DLFE_MU_030K    : r_mp_scs[i] = ORAN_MU_030K    ;
            DLFE_MU_060K    : r_mp_scs[i] = ORAN_MU_060K    ;
            default         : r_mp_scs[i] = 4'd0            ;  
        endcase
    end
end
always@(posedge i_clk) begin
    if(r_frame_sync) begin 
        r_tdd_cfg  <= i_din_tdd_cfg   ;
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(|i_din_fsync) begin 
            r_iq_swap           [i]  <=  i_dlfe_par_1004 [((02)*(i+1)-1)-:(02)] ;
            r_dbg_frame_struct  [i]  <=  i_dlfe_par_1108 [((08)*(i+1)-1)-:(08)] ;
            r_dbg_bf            [i]  <=  i_dlfe_par_110c [((32)*(i+1)-1)-:(32)] ;
            r_smp_mon_cfg       [i]  <=  i_dlfe_par_1110 [((32)*(i+1)-1)-:(32)] ;
            r_ntone             [i]  <=  i_dlfe_par_120c [((12)*(i+1)-1)-:(12)] ;
            r_mp_frame_struct   [i]  <= {r_mp_fft[i],r_mp_scs[i]}               ;
            r_layer_gate        [i]  <=  i_dlfe_par_1244 [((NUM_LAYER)*(i+1)-1)-:(NUM_LAYER)]   ;
            r_re_start          [i]  <=  i_dlfe_par_10f0 [((12)*(i+1)-1)-:(12)] ;
            r_param_rear_mode   [i]  <=  i_dlfe_par_10f4 [2*i+0] ;
            r_data_double_mode  [i]  <=  i_dlfe_par_10f4 [2*i+1] ;
        end
    end
end
reg [01-1:0] rr_frame_sync    ;
reg [01-1:0] rr_p0_frame_sync ;
reg [04-1:0] rr_mu         [NUM_CC-1:0] ;
reg [04-1:0] rr_fft_size   [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    rr_frame_sync    <=  r_frame_sync       ;
    rr_p0_frame_sync <=  r_p0_frame_sync    ;
    for(i=0;i<NUM_CC;i=i+1) begin
        if(r_frame_sync) begin
            if(|r_dbg_mode[CC_REF]) begin
                rr_mu       [i] <=  r_dbg_frame_struct[i][3:0] ;
                rr_fft_size [i] <=  r_dbg_frame_struct[i][7:4] ;
            end
            else begin
                rr_mu       [i] <=  r_mp_frame_struct[i][3:0] ;
                rr_fft_size [i] <=  r_mp_frame_struct[i][7:4] ;
            end
        end
    end
end
reg  [9:0]                  r_tdd_ind       ;
reg  [0:0]                  r_tdd_en        ;
wire                        w_frame_sync    ;
wire                        w_subfrm_sync   ;
wire                        w_slot_sync     ;
wire                        w_symbol_sync   ;
wire [3:0]                  w_subfrm        ;
wire [7:0]                  w_slot          ;
wire [3:0]                  w_symbol        ;
reg                         r_slot_sync     ;
reg  [3:0]                  r_symbol        ;
wire [NUM_LAYER_LANE-1:0]   w_re_cdata_en   [NUM_LANE_CC-1:0]   ;
wire [2*DO_BW_CPRI-1:0]     w_re_cdata      [NUM_LANE_CC-1:0]   ;
always@(posedge i_clk) begin
    r_slot_sync  <= w_slot_sync ;
    if(w_symbol_sync) begin
        r_symbol  <=  w_symbol  ;
    end
end
always@(posedge i_clk) begin
    if(w_frame_sync) begin
        if(r_tdd_cfg) begin
            r_tdd_ind   <=  TDD_8_2 ;
        end
        else begin
            r_tdd_ind   <=  TDD_4_1 ;
        end
    end
    else if(w_slot_sync) begin
        if((|r_tdd_ind==1'b0)) begin
            if(r_tdd_cfg) begin
                r_tdd_ind   <=  TDD_8_2 ;
            end
            else begin
                r_tdd_ind   <=  TDD_4_1 ;
            end
        end
        else begin
            r_tdd_ind   <=  r_tdd_ind>>1 ;
        end
    end
end
always@(posedge i_clk) begin
    if(r_tdd_cfg) begin
        if(r_tdd_ind[1:0]==2'b01) begin
            r_tdd_en  <= r_symbol<IDX_GSYMBOL_F_8_2 ? 1'b1 : 1'b0 ;
        end
        else begin
            r_tdd_en  <=  r_tdd_ind[0] ;
        end
    end
    else begin
        if(r_tdd_ind[1:0]==2'b01) begin
            r_tdd_en  <= r_symbol<IDX_GSYMBOL_F_4_1 ? 1'b1 : 1'b0 ;
        end
        else begin
            r_tdd_en  <=  r_tdd_ind[0] ;
        end
    end
end
ref_vsync_gen u00_0_dlfe_din_rtg 
(
     .i_clk             ( i_clk                             )
    ,.i_mu              ( rr_mu [CC_REF]                    )
    ,.i_retard          ( 22'd4                             )
    ,.i_frame_sync      ( rr_frame_sync                     )
    ,.i_en              ( 1'd1                              )
    ,.o_frame_sync      ( w_frame_sync                      )
    ,.o_subfrm_sync     ( w_subfrm_sync                     )
    ,.o_slot_sync       ( w_slot_sync                       )
    ,.o_symbol_sync     ( w_symbol_sync                     )
    ,.o_subfrm          ( w_subfrm                          )
    ,.o_slot            ( w_slot                            )
    ,.o_symbol          ( w_symbol                          )
);
wire        w_p0_frame_sync    ;
wire        w_p0_subfrm_sync   ;
wire        w_p0_slot_sync     ;
wire        w_p0_symbol_sync   ;
wire [3:0]  w_p0_subfrm        ;
wire [7:0]  w_p0_slot          ;
wire [3:0]  w_p0_symbol        ;
ref_vsync_gen u00_1_dlfe_pin0_rtg 
(
     .i_clk             ( i_clk                             )
    ,.i_mu              ( rr_mu [CC_REF]                    )
    ,.i_retard          ( 22'd4                             )
    ,.i_frame_sync      ( rr_p0_frame_sync                  )
    ,.i_en              ( 1'd1                              )
    ,.o_frame_sync      ( w_p0_frame_sync                   )
    ,.o_subfrm_sync     ( w_p0_subfrm_sync                  )
    ,.o_slot_sync       ( w_p0_slot_sync                    )
    ,.o_symbol_sync     ( w_p0_symbol_sync                  )
    ,.o_subfrm          ( w_p0_subfrm                       )
    ,.o_slot            ( w_p0_slot                         )
    ,.o_symbol          ( w_p0_symbol                       )
);
`ifdef DLFE_DOUBLE_MODE_DISABLE                
generate for(gidx=0;gidx<NUM_LANE_CC;gidx=gidx+1) begin : g01_cpri_iq_if
ylib_cpri_iq_conv #(
      .DI_BW             (  DI_BW                   ) 
     ,.DO_BW             (  DO_BW_CPRI              ) 
     ,.NUM_LAYER_LANE    (  NUM_LAYER_LANE          ) 
     ,.RETARD            (  RETARD_CPRI_SYNC_GEN    )) 
u01_cpri_iq_conv
(
     .i_clk             ( i_clk                                 )          
    ,.i_symbol_sync     ( w_symbol_sync                         )   
    ,.i_en              ( ENABLE_TDD ? r_tdd_en : 1'd1          )
    ,.i_csync           ( r_csync       [gidx][DLY_DATA_CSYNC]  )   
    ,.i_cdata           ( r_cdata       [gidx][DLY_DATA_CSYNC]  )   
    ,.i_ntone           ( r_ntone       [CC_REF]                )
    ,.i_re_start        ( r_re_start    [CC_REF]                )
    ,.o_re_cdata_en     ( w_re_cdata_en [gidx]                  )
    ,.o_re_cdata        ( w_re_cdata    [gidx]                  )
);
end
endgenerate
`else //DLFE_DOUBLE_MODE_DISABLE                
wire [NUM_LAYER_LANE-1:0]   w_re_nmode_cdata_en   [NUM_LANE_CC-1:0]     ;
wire [2*DO_BW_CPRI-1:0]     w_re_nmode_cdata      [NUM_LANE_CC-1:0]     ;
wire [NUM_LAYER_LANE-1:0]   w_re_rear_cdata_en    [NUM_LANE_CC/2-1:0]   ;
wire [2*DO_BW_CPRI-1:0]     w_re_rear_cdata       [NUM_LANE_CC/2-1:0]   ;
wire [2*DO_BW_CPRI-1:0]     w_re_dmode_cdata      [NUM_LANE_CC-1:0]     ;
reg  [NUM_LAYER_LANE-1:0]   r_re_dmode_cdata_en   [NUM_LANE_CC-1:0]     ;
reg  [2*DO_BW_CPRI-1:0]     r_re_dmode_cdata      [NUM_LANE_CC-1:0]     ;
generate for(gidx=0;gidx<NUM_LANE_CC;gidx=gidx+1) begin : g01_1_cpri_iq_if_normal
ylib_cpri_iq_conv #(
      .DI_BW             (  DI_BW                   ) 
     ,.DO_BW             (  DO_BW_CPRI              ) 
     ,.NUM_LAYER_LANE    (  NUM_LAYER_LANE          ) 
     ,.RETARD            (  RETARD_CPRI_SYNC_GEN    )) 
u01_0_cpri_iq_conv_normal
(
     .i_clk             ( i_clk                                                     )          
    ,.i_symbol_sync     ( w_symbol_sync                                             )   
    ,.i_en              ( ENABLE_TDD ? r_tdd_en : 1'd1                              )
    ,.i_csync           ( r_csync               [gidx][DLY_DATA_CSYNC]              )   
    ,.i_cdata           ( r_cdata               [gidx][DLY_DATA_CSYNC]              )   
    ,.i_ntone           ( r_ntone               [CC_REF]                            )
    ,.i_re_start        ( r_data_double_mode[CC_REF] ? 12'd0 : r_re_start[CC_REF]   )
    ,.o_re_cdata_en     ( w_re_nmode_cdata_en   [gidx]                              )
    ,.o_re_cdata        ( w_re_nmode_cdata      [gidx]                              )
);
assign w_re_cdata_en [gidx] = r_data_double_mode[CC_REF] ? r_re_dmode_cdata_en [gidx] : w_re_nmode_cdata_en [gidx] ;
assign w_re_cdata    [gidx] = r_data_double_mode[CC_REF] ? r_re_dmode_cdata    [gidx] : w_re_nmode_cdata    [gidx] ;
end
endgenerate
reg [01-1:0]   r_re_nmode_cdata_en      [NUM_LANE_CC-1:0]   ;
reg [12-1:0]   r_re_dmode_cdata_en_addr [NUM_LANE_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_LANE_CC/2;gidx=gidx+1) begin : g01_1_cpri_iq_if_double
ylib_cpri_iq_conv #(
      .DI_BW            (  DI_BW                   ) 
     ,.DO_BW            (  DO_BW_CPRI              ) 
     ,.NUM_LAYER_LANE   (  NUM_LAYER_LANE          ) 
     ,.RETARD           (  RETARD_CPRI_SYNC_GEN    )) 
u01_1_cpri_iq_conv_rear
(
     .i_clk             ( i_clk                                         )          
    ,.i_symbol_sync     ( w_symbol_sync                                 )   
    ,.i_en              ( ENABLE_TDD ? r_tdd_en : 1'd1                  )
    ,.i_csync           ( r_csync               [gidx][DLY_DATA_CSYNC]  )   
    ,.i_cdata           ( r_cdata               [gidx][DLY_DATA_CSYNC]  )   
    ,.i_ntone           ( r_ntone               [CC_REF]                )
    ,.i_re_start        ( r_re_start            [CC_REF]                )
    ,.o_re_cdata_en     ( w_re_rear_cdata_en    [gidx]                  )
    ,.o_re_cdata        ( w_re_rear_cdata       [gidx]                  )
);
always@(posedge i_clk) begin
    r_re_nmode_cdata_en [gidx]  <=  |w_re_nmode_cdata_en   [gidx]   ;
    if(w_symbol_sync||(~(|w_re_nmode_cdata_en[gidx])&r_re_nmode_cdata_en[gidx])) begin
        r_re_dmode_cdata_en_addr[gidx] <= 12'd0 ;
    end
    else if((|w_re_nmode_cdata_en[gidx])||(|w_re_rear_cdata_en[gidx])) begin
        r_re_dmode_cdata_en_addr[gidx] <= r_re_dmode_cdata_en_addr[gidx] + 1'd1 ;
    end
end
ylib_rams_sdp #(
    .WIDTH      (   2*DO_BW_CPRI    )
   ,.DEPTH      (   4096            )
   ,.VENDOR     (   VENDOR          )
   ,.RAM_STYLE  (   "block"         )) 
u01_2_cpri_iq_mem_double 
(
    .clk    (   i_clk                                   )
   ,.ena    (  |w_re_nmode_cdata_en         [gidx]      )
   ,.enb    (  |w_re_rear_cdata_en          [gidx]      )
   ,.wea    (  |w_re_nmode_cdata_en         [gidx]      )
   ,.addra  (   r_re_dmode_cdata_en_addr    [gidx]      )
   ,.addrb  (   r_re_dmode_cdata_en_addr    [gidx]      )
   ,.dia    (   w_re_nmode_cdata            [gidx]      )
   ,.dob    (   w_re_dmode_cdata            [gidx]      )
);
always@(*) begin
    r_re_dmode_cdata [gidx] = w_re_dmode_cdata [gidx] ;
end
always@(posedge i_clk) begin
    r_re_dmode_cdata_en [gidx]                <=  w_re_rear_cdata_en [gidx]  ;
    r_re_dmode_cdata_en [gidx+NUM_LANE_CC/2]  <=  w_re_rear_cdata_en [gidx]  ;
    if(|w_re_rear_cdata_en[gidx]) begin
        r_re_dmode_cdata [gidx+NUM_LANE_CC/2] <= w_re_rear_cdata [gidx]  ;
    end
end
end
endgenerate
`endif //DLFE_DOUBLE_MODE_DISABLE

reg rrr_p0_frame_sync     ;
reg rrr_p0_slot_sync      ;
reg rrr_p0_symbol_sync    ;
always@(*) begin
    rrr_p0_frame_sync     =   w_p0_frame_sync   ;
    rrr_p0_slot_sync      =   w_p0_slot_sync    ;
    rrr_p0_symbol_sync    =   w_p0_symbol_sync  ;
end
reg rrrr_p0_symbol_sync  ;
always@(posedge i_clk) begin
    rrrr_p0_symbol_sync   <=  rrr_p0_symbol_sync  ;
end

wire [01-1:0]       w_rb_cbidx_en           ;
wire [01-1:0]       w_rb_nmusul_en          ;
wire [01-1:0]       w_re_map_en             ;
wire [01-1:0]       w_rb_nmul_en            ;
wire [01-1:0]       w_rb_sch_srs_idx_en     ;
wire [01-1:0]       w_rb_null_lyr_ind_en    ;
wire [2*DI_BW-1:0]  w_cparam0               ;
wire [01-1:0]       w_h_en                  ;
wire [2*DI_BW-1:0]  w_cparam1               ;
ylib_cpri_param_if #(
     .DI_BW             (   2*DI_BW                 ) 
    ,.MAP_TYPE          (  `PARAM_MAP_TYPE          ) 
    ,.RETARD            (   RETARD_CPRI_SYNC_GEN    )) 
u02_dl_pmif
(
     .i_clk                 ( i_clk                                     )          
    ,.i_frame_sync          ( rrr_p0_frame_sync                         )
    ,.i_slot_sync           ( rrr_p0_slot_sync                          )   
    ,.i_symbol_sync         ( rrr_p0_symbol_sync                        )   
    ,.i_en                  ( 1'd1                                      )
    ,.i_tdd_cfg             ( r_tdd_cfg                                 )
    ,.i_addr_offset         ( r_param_rear_mode[CC_REF] ?           
                                            PARAM_REAR_OFFSET : 16'd0   )
    ,.i_p0_csync            ( r_p0_csync    [DLY_P0_CSYNC]              )   
    ,.i_p0_cdata            ( r_p0_cdata    [DLY_P0_CSYNC]              )   
    ,.i_p1_cdata            ( r_p1_cdata    [DLY_P1_CSYNC]              )   
    ,.o_rb_cbidx_en         ( w_rb_cbidx_en                             )
    ,.o_rb_nmusul_en        ( w_rb_nmusul_en                            )
    ,.o_re_map_en           ( w_re_map_en                               )
    ,.o_rb_nmul_en          ( w_rb_nmul_en                              )
    ,.o_rb_sch_srs_idx_en   ( w_rb_sch_srs_idx_en                       )
    ,.o_rb_null_lyr_ind_en  ( w_rb_null_lyr_ind_en                      )
    ,.o_cparam0             ( w_cparam0                                 )
    ,.o_h_en                ( w_h_en                                    )
    ,.o_cparam1             ( w_cparam1                                 )
);
assign  o_pout0_nmul_en             =   w_rb_nmul_en            ;
assign  o_pout0_sch_srs_idx_en      =   w_rb_sch_srs_idx_en     ;
assign  o_pout0_null_lyr_ind_en     =   w_rb_null_lyr_ind_en    ;
assign  o_pout0_cparam              =   w_cparam0               ;
assign  o_pout1_h_en                =   w_h_en                  ;
assign  o_pout1_cparam              =   w_cparam1               ;
assign  o_pout1_muwg_fsync          =   rrr_p0_frame_sync       ;

reg [01-1:0]                                                    r_param_cbuf_cnt        ;
reg [09-1:0]                                                    r_param_rb_idx          ;
reg [04-1:0]                                                    r_param_re_rb_idx       ;
reg [$clog2(NUM_CPARAM_RB_SLOT)-1:0]                            r_param_rb_rd_offset    ;
reg [$clog2(NUM_CPARAM_RE_SLOT)-1:0]                            r_param_re_rd_offset    ;
reg [$clog2(NUM_CPARAM_RB_SLOT)-1:0]                            r_param_rd_rb_idx       ;
reg [$clog2(NUM_CPARAM_RE_SLOT)-1:0]                            r_param_rd_re_idx       ;
reg [$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_CBIDX))-1:0]    r_rb_cbidx_wr_addr      ;
reg [$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL))-1:0]   r_rb_nmusul_wr_addr     ;
reg [$clog2(NUM_CPARAM_RE_SLOT/(2*DI_BW/BW_CPRI_REMAP))-1:0]    r_re_map_wr_addr        ;
always@(posedge i_clk) begin
    if(rrr_p0_slot_sync) begin
        r_param_cbuf_cnt  <=  w_p0_slot[$clog2(NUM_CBUF)-1:0] ;
    end
end
generate if(`PARAM_MAP_TYPE == "TYPE0") begin : gen0_pmap_type0
always@(posedge i_clk) begin
    if(rrr_p0_slot_sync) begin
        r_rb_cbidx_wr_addr    <=  9'd0    ;
        r_rb_nmusul_wr_addr   <=  9'd0    ;
        r_re_map_wr_addr      <=  12'd0   ;
    end
    else if(w_rb_cbidx_en) begin
        r_rb_cbidx_wr_addr    <=  r_rb_cbidx_wr_addr+1'd1   ;
    end
    else if(w_rb_nmusul_en) begin
        r_rb_nmusul_wr_addr   <=  r_rb_nmusul_wr_addr+1'd1  ;
    end
    else if(w_re_map_en) begin
        r_re_map_wr_addr      <=  r_re_map_wr_addr+1'd1     ;
    end
end
end
else begin : gen0_pmap_type1
always@(posedge i_clk) begin
    if(rrr_p0_slot_sync) begin
        r_rb_cbidx_wr_addr    <=  9'd0    ;
        r_rb_nmusul_wr_addr   <=  9'd0    ;
        r_re_map_wr_addr      <=  12'd0   ;
    end
    else if(w_rb_cbidx_en) begin
        r_rb_cbidx_wr_addr    <=  r_rb_cbidx_wr_addr+1'd1   ;
        r_rb_nmusul_wr_addr   <=  r_rb_nmusul_wr_addr+1'd1  ;
    end
    else if(w_re_map_en) begin
        r_re_map_wr_addr      <=  r_re_map_wr_addr+1'd1     ;
    end
end
end
endgenerate
always@(posedge i_clk) begin
    if(rrr_p0_symbol_sync) begin
        r_param_re_rb_idx <=  4'd0    ;
        r_param_rb_idx    <=  9'd0    ;
    end
    else if(w_re_cdata_en[IDX_LANE_REF][IDX_LAYER_CNT_REF]) begin
        if(r_param_re_rb_idx==NUM_RE_RB-1'd1) begin
            r_param_re_rb_idx <=  4'd0    ;
            r_param_rb_idx    <=  r_param_rb_idx+1'd1   ;
        end
        else begin
            r_param_re_rb_idx  <=  r_param_re_rb_idx+1'd1   ;
        end
    end
end
always@(posedge i_clk) begin
    if(rrr_p0_slot_sync) begin
        r_param_rb_rd_offset <=  {{$clog2(NUM_CPARAM_RB_SYMBOL)}{1'd0}} ;
        r_param_re_rd_offset <=  {{$clog2(NUM_CPARAM_RE_SYMBOL)}{1'd0}} ;
    end
    else if(rrr_p0_symbol_sync) begin
        r_param_rb_rd_offset   <= r_param_rb_rd_offset+NUM_CPARAM_RB_SYMBOL   ;
        r_param_re_rd_offset   <= r_param_re_rd_offset+NUM_CPARAM_RE_SYMBOL   ;
    end
end
always@(posedge i_clk) begin
    if(rrrr_p0_symbol_sync) begin
        r_param_rd_rb_idx  <=  r_param_rb_rd_offset ;
    end
    else if(w_re_cdata_en[IDX_LANE_REF][IDX_LAYER_CNT_REF]) begin
        if(r_param_re_rb_idx==NUM_RE_RB-1'd1) begin
            if(r_param_rb_idx==NUM_CPARAM_RB_SYMBOL-1'd1) begin
                r_param_rd_rb_idx  <=  r_param_rd_rb_idx ;
            end
            else begin
                r_param_rd_rb_idx  <=  r_param_rd_rb_idx + 1'd1 ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(rrrr_p0_symbol_sync) begin
        r_param_rd_re_idx  <=  r_param_re_rd_offset ;
    end
    else if(w_re_cdata_en[IDX_LANE_REF][IDX_LAYER_CNT_REF]) begin
        if((r_param_rb_idx==NUM_CPARAM_RB_SYMBOL-1'd1)&&(r_param_re_rb_idx==NUM_RE_RB-1'd1)) begin
            r_param_rd_re_idx  <=  r_param_rd_re_idx-(NUM_RE_RB-1'd1) ;
        end
        else begin
            r_param_rd_re_idx  <=  r_param_rd_re_idx + 1'd1 ;
        end
    end
end

wire [0:0]                                                      w_mem_rb_cbidx_en           [NUM_CBUF-1:0]  ; 
wire [0:0]                                                      w_mem_rb_cbidx_wr_en        [NUM_CBUF-1:0]  ; 
wire [$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_CBIDX))-1:0]   w_mem_rb_cbidx_addr         [NUM_CBUF-1:0]  ; 
wire [BW_CBIDX*(2*DI_BW/BW_CPRI_CBIDX)-1:0]                     w_mem_rb_cbidx_dout         [NUM_CBUF-1:0]  ;
reg  [BW_CBIDX*(2*DI_BW/BW_CPRI_CBIDX)-1:0]                     r_mem_rb_cbidx_dout         [NUM_CBUF-1:0][DLY_MEM_CBIDX:0]    ;
reg  [0:0]                                                      r_mem_rb_cbidx_rd_en        [NUM_CBUF-1:0][DLY_MEM_CBIDX:0]    ;
reg  [$clog2(2*DI_BW/BW_CPRI_CBIDX)-1:0]                        r_mem_rb_cbidx_pos          [NUM_CBUF-1:0][DLY_MEM_CBIDX:0]    ;
reg  [0:0]                                                      rr_mem_rb_cbidx_rd_en       [NUM_CBUF-1:0]  ; 
reg  [BW_CBIDX-1:0]                                             rr_mem_rb_cbidx_dout        [NUM_CBUF-1:0]  ;
reg  [0:0]                                                      rr_cbuf_mux_mem_rb_cbidx_rd_en      ; 
reg  [BW_CBIDX-1:0]                                             rr_cbuf_mux_mem_rb_cbidx_dout       ;
reg  [0:0]                                                      rr_dly_cbuf_mux_mem_rb_cbidx_rd_en  [DLY_CBIDX:0]  ; 
reg  [BW_CBIDX-1:0]                                             rr_dly_cbuf_mux_mem_rb_cbidx_dout   [DLY_CBIDX:0]  ;
generate for(gidx=0;gidx<NUM_CBUF;gidx=gidx+1) begin : g02_00_cpri_pbuf_cbidx
assign  w_mem_rb_cbidx_en[gidx]     = (w_rb_cbidx_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF))   ; 
assign  w_mem_rb_cbidx_wr_en[gidx]  = (w_rb_cbidx_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))    ;
assign  w_mem_rb_cbidx_addr[gidx]   = (w_rb_cbidx_en && r_param_cbuf_cnt==(gidx%NUM_CBUF)) ? r_rb_cbidx_wr_addr : {{$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_CBIDX))}{1'b0}}
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ? r_param_rd_rb_idx[$clog2(NUM_CPARAM_RB_SLOT)-1:$clog2(2*DI_BW/BW_CPRI_CBIDX)] : {{$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_CBIDX))}{1'b0}} ;
ylib_rams_sp_wf #(
     .WIDTH     (   BW_CBIDX*(2*DI_BW/BW_CPRI_CBIDX)                        )
    ,.DEPTH     (   2**($clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_CBIDX))) )
    ,.VENDOR    (   VENDOR                                                  ))
u02_00_cbidx_spram
(
     .clk       (   i_clk                       )     
    ,.en        (   w_mem_rb_cbidx_en   [gidx]  ) 
    ,.we        (   w_mem_rb_cbidx_wr_en[gidx]  ) 
    ,.addr      (   w_mem_rb_cbidx_addr [gidx]  ) 
    ,.di        (  {w_cparam0[(BW_CPRI_CBIDX*01)+BW_CBIDX-1:BW_CPRI_CBIDX*01]
                   ,w_cparam0[(BW_CPRI_CBIDX*00)+BW_CBIDX-1:BW_CPRI_CBIDX*00]})
    ,.dout      (   w_mem_rb_cbidx_dout [gidx]  ) 
);
always@(posedge i_clk) begin
    r_mem_rb_cbidx_rd_en[gidx][0] <= (w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ;
    r_mem_rb_cbidx_pos  [gidx][0] <= r_param_rd_rb_idx[$clog2(2*DI_BW/BW_CPRI_CBIDX)-1:0] ;
end
always@(*) begin
    r_mem_rb_cbidx_dout[gidx][0] = w_mem_rb_cbidx_dout[gidx]   ; 
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_MEM_CBIDX;i=i+1) begin
        r_mem_rb_cbidx_rd_en[gidx][i] <= r_mem_rb_cbidx_rd_en[gidx][i-1]    ; 
        if(r_mem_rb_cbidx_rd_en[gidx][i-1]) begin
            r_mem_rb_cbidx_pos[gidx][i] <= r_mem_rb_cbidx_pos[gidx][i-1]     ;
            r_mem_rb_cbidx_dout[gidx][i] <= r_mem_rb_cbidx_dout[gidx][i-1]     ;
        end
    end
end
always@(posedge i_clk) begin
    rr_mem_rb_cbidx_rd_en[gidx] <= r_mem_rb_cbidx_rd_en[gidx][DLY_MEM_CBIDX] ;
    if(r_mem_rb_cbidx_rd_en[gidx][DLY_MEM_CBIDX]) begin
        if(r_mem_rb_cbidx_pos[gidx][DLY_MEM_CBIDX]==1'd0) begin
            rr_mem_rb_cbidx_dout[gidx] <= r_mem_rb_cbidx_dout[gidx][DLY_MEM_CBIDX][((BW_CBIDX)*(01+1)-1)-:(BW_CBIDX)] ;
        end
        else if(r_mem_rb_cbidx_pos[gidx][DLY_MEM_CBIDX]==1'd1) begin
            rr_mem_rb_cbidx_dout[gidx] <= r_mem_rb_cbidx_dout[gidx][DLY_MEM_CBIDX][((BW_CBIDX)*(00+1)-1)-:(BW_CBIDX)] ;
        end
    end
end
end
endgenerate
always@(posedge i_clk) begin
    if(rr_mem_rb_cbidx_rd_en[0]) begin
        rr_cbuf_mux_mem_rb_cbidx_rd_en  <=  rr_mem_rb_cbidx_rd_en   [0] ;
        rr_cbuf_mux_mem_rb_cbidx_dout   <=  rr_mem_rb_cbidx_dout    [0] ;
    end
    else if(rr_mem_rb_cbidx_rd_en[1]) begin
        rr_cbuf_mux_mem_rb_cbidx_rd_en  <=  rr_mem_rb_cbidx_rd_en   [1] ;
        rr_cbuf_mux_mem_rb_cbidx_dout   <=  rr_mem_rb_cbidx_dout    [1] ;
    end
    else begin
        rr_cbuf_mux_mem_rb_cbidx_rd_en  <=  1'd0 ;
    end
end
always@(*) begin
    rr_dly_cbuf_mux_mem_rb_cbidx_rd_en  [0] = rr_cbuf_mux_mem_rb_cbidx_rd_en    ; 
    rr_dly_cbuf_mux_mem_rb_cbidx_dout   [0] = |r_dbg_mode[CC_REF] ? r_dbg_bf[CC_REF][(BW_CBIDX-1+00)-:BW_CBIDX] : rr_cbuf_mux_mem_rb_cbidx_dout     ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_CBIDX;i=i+1) begin
        rr_dly_cbuf_mux_mem_rb_cbidx_rd_en[i] <= rr_dly_cbuf_mux_mem_rb_cbidx_rd_en[i-1]    ; 
        if(rr_dly_cbuf_mux_mem_rb_cbidx_rd_en[i-1]) begin
            rr_dly_cbuf_mux_mem_rb_cbidx_dout[i] <= rr_dly_cbuf_mux_mem_rb_cbidx_dout[i-1]     ;
        end
    end
end

wire [0:0]                                                      w_mem_rb_nmusul_en      [NUM_CBUF-1:0]  ; 
wire [0:0]                                                      w_mem_rb_nmusul_wr_en   [NUM_CBUF-1:0]  ; 
wire [$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL))-1:0]  w_mem_rb_nmusul_addr    [NUM_CBUF-1:0]  ; 
wire [BW_NMUSUL*(2*DI_BW/BW_CPRI_NMUSUL)-1:0]                   w_mem_rb_nmusul_dout    [NUM_CBUF-1:0]  ;
reg  [BW_NMUSUL*(2*DI_BW/BW_CPRI_NMUSUL)-1:0]                   r_mem_rb_nmusul_dout    [NUM_CBUF-1:0][DLY_MEM_NMUSUL:0]  ; 
reg  [0:0]                                                      r_mem_rb_nmusul_rd_en   [NUM_CBUF-1:0][DLY_MEM_NMUSUL:0]  ; 
reg  [$clog2(2*DI_BW/BW_CPRI_NMUSUL)-1:0]                       r_mem_rb_nmusul_pos     [NUM_CBUF-1:0][DLY_MEM_NMUSUL:0]  ; 
reg  [0:0]                                                      rr_mem_rb_nmusul_rd_en  [NUM_CBUF-1:0]  ; 
reg  [BW_NMUSUL-1:0]                                            rr_mem_rb_nmusul_dout   [NUM_CBUF-1:0]  ;
reg  [0:0]                                                      rr_cbuf_mux_mem_rb_nmusul_rd_en         ; 
reg  [BW_NMUSUL-1:0]                                            rr_cbuf_mux_mem_rb_nmusul_dout          ;
reg  [0:0]                                                      rr_dly_cbuf_mux_mem_rb_nmusul_rd_en  [DLY_NMUSUL:0]  ; 
reg  [BW_NMUSUL-1:0]                                            rr_dly_cbuf_mux_mem_rb_nmusul_dout   [DLY_NMUSUL:0]  ;
generate for(gidx=0;gidx<NUM_CBUF;gidx=gidx+1) begin : g02_01_cpri_pbuf_nmusul
assign  w_mem_rb_nmusul_en[gidx]    = (w_rb_nmusul_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF))   ; 
assign  w_mem_rb_nmusul_wr_en[gidx] = (w_rb_nmusul_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))    ;
assign  w_mem_rb_nmusul_addr[gidx]  = (w_rb_nmusul_en && r_param_cbuf_cnt==(gidx%NUM_CBUF)) ? r_rb_nmusul_wr_addr : {{$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL))}{1'b0}} 
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ? r_param_rd_rb_idx[$clog2(NUM_CPARAM_RB_SLOT)-1:$clog2(2*DI_BW/BW_CPRI_NMUSUL)] : {{$clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL))}{1'b0}} ;
if(`PARAM_MAP_TYPE=="TYPE0") begin : gen1_pmap_type0
ylib_rams_sp_wf #(
     .WIDTH     (   BW_NMUSUL*(2*DI_BW/BW_CPRI_NMUSUL)                          )
    ,.DEPTH     (   2**($clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL)))    )
    ,.VENDOR    (   VENDOR                                                      ))
u02_01_nmusul_spram
(
     .clk       (   i_clk                        )     
    ,.en        (   w_mem_rb_nmusul_en   [gidx]  ) 
    ,.we        (   w_mem_rb_nmusul_wr_en[gidx]  ) 
    ,.addr      (   w_mem_rb_nmusul_addr [gidx]  ) 
    ,.di        (  {w_cparam0[(BW_CPRI_NMUSUL*03)+BW_NMUSUL-1:BW_CPRI_NMUSUL*03]
                   ,w_cparam0[(BW_CPRI_NMUSUL*02)+BW_NMUSUL-1:BW_CPRI_NMUSUL*02]
                   ,w_cparam0[(BW_CPRI_NMUSUL*01)+BW_NMUSUL-1:BW_CPRI_NMUSUL*01]
                   ,w_cparam0[(BW_CPRI_NMUSUL*00)+BW_NMUSUL-1:BW_CPRI_NMUSUL*00]})
    ,.dout      (   w_mem_rb_nmusul_dout [gidx]  ) 
);
end
else begin : gen1_pmap_type1
ylib_rams_sp_wf #(
     .WIDTH     (   BW_NMUSUL*(2*DI_BW/BW_CPRI_NMUSUL)                          )
    ,.DEPTH     (   2**($clog2(NUM_CPARAM_RB_SLOT/(2*DI_BW/BW_CPRI_NMUSUL)))    )
    ,.VENDOR    (   VENDOR                                                      ))
u02_01_nmusul_spram
(
     .clk       (   i_clk                        )     
    ,.en        (   w_mem_rb_nmusul_en   [gidx]  ) 
    ,.we        (   w_mem_rb_nmusul_wr_en[gidx]  ) 
    ,.addr      (   w_mem_rb_nmusul_addr [gidx]  ) 
    ,.di        (  {w_cparam0[((BW_CPRI_NMUSUL*01+BW_CBIDX)+BW_NMUSUL-1):(BW_CPRI_NMUSUL*01+BW_CBIDX)]
                   ,w_cparam0[((BW_CPRI_NMUSUL*00+BW_CBIDX)+BW_NMUSUL-1):(BW_CPRI_NMUSUL*00+BW_CBIDX)]})
    ,.dout      (   w_mem_rb_nmusul_dout [gidx]  ) 
);
end
always@(posedge i_clk) begin
    r_mem_rb_nmusul_rd_en[gidx][0] <= (w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ;
    r_mem_rb_nmusul_pos  [gidx][0] <= r_param_rd_rb_idx[$clog2(2*DI_BW/BW_CPRI_NMUSUL)-1:0] ;
end
always@(*) begin
    r_mem_rb_nmusul_dout[gidx][0] = w_mem_rb_nmusul_dout[gidx]   ; 
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_MEM_NMUSUL;i=i+1) begin
        r_mem_rb_nmusul_rd_en[gidx][i] <= r_mem_rb_nmusul_rd_en[gidx][i-1]    ; 
        if(r_mem_rb_nmusul_rd_en[gidx][i-1]) begin
            r_mem_rb_nmusul_pos[gidx][i] <= r_mem_rb_nmusul_pos[gidx][i-1]     ;
            r_mem_rb_nmusul_dout[gidx][i] <= r_mem_rb_nmusul_dout[gidx][i-1]     ;
        end
    end
end
if(`PARAM_MAP_TYPE == "TYPE0") begin : gen2_pmap_type0
always@(posedge i_clk) begin
    rr_mem_rb_nmusul_rd_en[gidx] <= r_mem_rb_nmusul_rd_en[gidx][DLY_MEM_NMUSUL] ;
    if(r_mem_rb_nmusul_rd_en[gidx][DLY_MEM_NMUSUL]) begin
        if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd0) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(03+1)-1)-:(BW_NMUSUL)] ;
        end
        else if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd1) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(02+1)-1)-:(BW_NMUSUL)] ;
        end
        else if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd2) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(01+1)-1)-:(BW_NMUSUL)] ;
        end
        else if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd3) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(00+1)-1)-:(BW_NMUSUL)] ;
        end
    end
end
end 
else begin : gen2_pmap_type1
always@(posedge i_clk) begin
    rr_mem_rb_nmusul_rd_en[gidx] <= r_mem_rb_nmusul_rd_en[gidx][DLY_MEM_NMUSUL] ;
    if(r_mem_rb_nmusul_rd_en[gidx][DLY_MEM_NMUSUL]) begin
        if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd0) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(01+1)-1)-:(BW_NMUSUL)] ;
        end
        else if(r_mem_rb_nmusul_pos[gidx][DLY_MEM_NMUSUL]==2'd1) begin
            rr_mem_rb_nmusul_dout[gidx] <= r_mem_rb_nmusul_dout[gidx][DLY_MEM_NMUSUL][((BW_NMUSUL)*(00+1)-1)-:(BW_NMUSUL)] ;
        end
    end
end
end
always@(posedge i_clk) begin
    if(rr_mem_rb_nmusul_rd_en[0]) begin
        rr_cbuf_mux_mem_rb_nmusul_rd_en  <=  rr_mem_rb_nmusul_rd_en   [0] ;
        rr_cbuf_mux_mem_rb_nmusul_dout   <=  rr_mem_rb_nmusul_dout    [0] ;
    end
    else if(rr_mem_rb_nmusul_rd_en[1]) begin
        rr_cbuf_mux_mem_rb_nmusul_rd_en  <=  rr_mem_rb_nmusul_rd_en   [1] ;
        rr_cbuf_mux_mem_rb_nmusul_dout   <=  rr_mem_rb_nmusul_dout    [1] ;
    end
    else begin
        rr_cbuf_mux_mem_rb_nmusul_rd_en  <=  1'd0 ;
    end
end
always@(*) begin
    rr_dly_cbuf_mux_mem_rb_nmusul_rd_en  [0] = rr_cbuf_mux_mem_rb_nmusul_rd_en    ; 
    rr_dly_cbuf_mux_mem_rb_nmusul_dout   [0] = |r_dbg_mode[CC_REF] ? r_dbg_bf[CC_REF][(BW_NMUSUL-1+16)-:BW_NMUSUL] : rr_cbuf_mux_mem_rb_nmusul_dout     ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_NMUSUL;i=i+1) begin
        rr_dly_cbuf_mux_mem_rb_nmusul_rd_en[i] <= rr_dly_cbuf_mux_mem_rb_nmusul_rd_en[i-1]    ; 
        if(rr_dly_cbuf_mux_mem_rb_nmusul_rd_en[i-1]) begin
            rr_dly_cbuf_mux_mem_rb_nmusul_dout[i] <= rr_dly_cbuf_mux_mem_rb_nmusul_dout[i-1]     ;
        end
    end
end
end
endgenerate

wire [0:0]                                                      w_mem_re_map_en         [NUM_CBUF-1:0]  ; 
wire [0:0]                                                      w_mem_re_map_wr_en      [NUM_CBUF-1:0]  ; 
wire [$clog2(NUM_CPARAM_RE_SLOT/(2*DI_BW/BW_CPRI_REMAP))-1:0]   w_mem_re_map_addr       [NUM_CBUF-1:0]  ; 
wire [BW_REMAP*(2*DI_BW/BW_CPRI_REMAP)-1:0]                     w_mem_re_map_dout       [NUM_CBUF-1:0]  ;
reg  [BW_REMAP*(2*DI_BW/BW_CPRI_REMAP)-1:0]                     r_mem_re_map_dout       [NUM_CBUF-1:0][DLY_MEM_REMAP:0]  ; 
reg  [0:0]                                                      r_mem_re_map_rd_en      [NUM_CBUF-1:0][DLY_MEM_REMAP:0]  ; 
reg  [$clog2(2*DI_BW/BW_CPRI_REMAP)-1:0]                        r_mem_re_map_pos        [NUM_CBUF-1:0][DLY_MEM_REMAP:0]  ; 
reg  [0:0]                                                      rr_mem_re_map_rd_en     [NUM_CBUF-1:0]  ; 
reg  [BW_REMAP-1:0]                                             rr_mem_re_map_dout      [NUM_CBUF-1:0]  ;
reg  [0:0]                                                      rr_cbuf_mux_mem_re_map_rd_en            ; 
reg  [BW_REMAP-1:0]                                             rr_cbuf_mux_mem_re_map_dout             ;
reg  [0:0]                                                      rr_dly_cbuf_mux_mem_re_map_rd_en  [DLY_REMAP:0]  ; 
reg  [BW_REMAP-1:0]                                             rr_dly_cbuf_mux_mem_re_map_dout   [DLY_REMAP:0]  ;
generate for(gidx=0;gidx<NUM_CBUF;gidx=gidx+1) begin : g02_01_cpri_pbuf_remap
assign  w_mem_re_map_en[gidx]       = (w_re_map_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF))   ; 
assign  w_mem_re_map_wr_en[gidx]    = (w_re_map_en && r_param_cbuf_cnt==(gidx%NUM_CBUF))    ;
assign  w_mem_re_map_addr[gidx]     = (w_re_map_en && r_param_cbuf_cnt==(gidx%NUM_CBUF)) ? r_re_map_wr_addr : 9'd0 
                                     |(w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ? r_param_rd_re_idx[$clog2(NUM_CPARAM_RE_SLOT)-1:$clog2(2*DI_BW/BW_CPRI_REMAP)] : {{$clog2(NUM_CPARAM_RE_SLOT/(2*DI_BW/BW_CPRI_REMAP))}{1'd0}} ;

if(VENDOR == "Xilinx") begin
xlib_urams_sp_wf #(
     .DWIDTH     (   BW_REMAP*(2*DI_BW/BW_CPRI_REMAP)                       )
    ,.AWIDTH     (   ($clog2(NUM_CPARAM_RE_SLOT/(2*DI_BW/BW_CPRI_REMAP)))   )
    ,.NBPIPE     (   1                                                      ))
u02_02_remap_spuram
(
    .clk    (   i_clk                                      )
   ,.rst    (  |i_rst                                      )
   ,.we     (   w_mem_re_map_wr_en[gidx]                   )
   ,.regce  (   1'd1                                       )
   ,.mem_en (   w_mem_re_map_en   [gidx]                   )
   ,.din    (  {w_cparam0[(BW_CPRI_REMAP*03)+BW_REMAP-1:BW_CPRI_REMAP*03]
               ,w_cparam0[(BW_CPRI_REMAP*02)+BW_REMAP-1:BW_CPRI_REMAP*02]
               ,w_cparam0[(BW_CPRI_REMAP*01)+BW_REMAP-1:BW_CPRI_REMAP*01]
               ,w_cparam0[(BW_CPRI_REMAP*00)+BW_REMAP-1:BW_CPRI_REMAP*00]})
   ,.addr   (   w_mem_re_map_addr [gidx]                   )
   ,.dout   (   w_mem_re_map_dout [gidx]                   )
);
always@(posedge i_clk) begin
    r_mem_re_map_rd_en[gidx][0] <= (w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ;
    r_mem_re_map_pos  [gidx][0] <= r_param_rd_re_idx[$clog2(2*DI_BW/BW_CPRI_REMAP)-1:0] ;
end
always@(posedge i_clk) begin
    r_mem_re_map_dout[gidx][DLY_MEM_REMAP] <= w_mem_re_map_dout[gidx]   ; 
    for(i=1;i<=DLY_MEM_REMAP;i=i+1) begin
        r_mem_re_map_rd_en[gidx][i] <= r_mem_re_map_rd_en[gidx][i-1]    ; 
        if(r_mem_re_map_rd_en[gidx][i-1]) begin
            r_mem_re_map_pos[gidx][i] <= r_mem_re_map_pos[gidx][i-1]     ;
        end
    end
end
end
else begin//VENDOR
ylib_rams_sp_wf #(
     .WIDTH     (   BW_REMAP*(2*DI_BW/BW_CPRI_REMAP)                        )
    ,.DEPTH     (   2**($clog2(NUM_CPARAM_RE_SLOT/(2*DI_BW/BW_CPRI_REMAP))) )
    ,.VENDOR    (   VENDOR                                                  ))
u02_02_remap_spram
(
     .clk       (   i_clk                       )     
    ,.en        (   w_mem_re_map_en   [gidx]    ) 
    ,.we        (   w_mem_re_map_wr_en[gidx]    ) 
    ,.addr      (   w_mem_re_map_addr [gidx]    ) 
    ,.di        (  {w_cparam0[(BW_CPRI_REMAP*03)+BW_REMAP-1:BW_CPRI_REMAP*03]
                   ,w_cparam0[(BW_CPRI_REMAP*02)+BW_REMAP-1:BW_CPRI_REMAP*02]
                   ,w_cparam0[(BW_CPRI_REMAP*01)+BW_REMAP-1:BW_CPRI_REMAP*01]
                   ,w_cparam0[(BW_CPRI_REMAP*00)+BW_REMAP-1:BW_CPRI_REMAP*00]})
    ,.dout      (   w_mem_re_map_dout [gidx]    ) 
);
always@(posedge i_clk) begin
    r_mem_re_map_rd_en[gidx][0] <= (w_re_cdata_en [IDX_LANE_REF][IDX_LAYER_RD_REF] && r_param_cbuf_cnt==!(gidx%NUM_CBUF)) ;
    r_mem_re_map_pos  [gidx][0] <= r_param_rd_re_idx[$clog2(2*DI_BW/BW_CPRI_REMAP)-1:0] ;
end
always@(*) begin
    r_mem_re_map_dout[gidx][0] = w_mem_re_map_dout[gidx]   ; 
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_MEM_REMAP;i=i+1) begin
        r_mem_re_map_rd_en[gidx][i] <= r_mem_re_map_rd_en[gidx][i-1]    ; 
        if(r_mem_re_map_rd_en[gidx][i-1]) begin
            r_mem_re_map_pos[gidx][i] <= r_mem_re_map_pos[gidx][i-1]     ;
            r_mem_re_map_dout[gidx][i] <= r_mem_re_map_dout[gidx][i-1]     ;
        end
    end
end
end//VENDOR
always@(posedge i_clk) begin
    rr_mem_re_map_rd_en[gidx] <= r_mem_re_map_rd_en[gidx][DLY_MEM_REMAP]    ;
    if(r_mem_re_map_rd_en[gidx][DLY_MEM_REMAP]) begin
        if(r_mem_re_map_pos[gidx][DLY_MEM_REMAP]==2'd0) begin
            rr_mem_re_map_dout[gidx] <= r_mem_re_map_dout[gidx][DLY_MEM_REMAP][((BW_REMAP)*(03+1)-1)-:(BW_REMAP)] ;
        end
        else if(r_mem_re_map_pos[gidx][DLY_MEM_REMAP]==2'd1) begin
            rr_mem_re_map_dout[gidx] <= r_mem_re_map_dout[gidx][DLY_MEM_REMAP][((BW_REMAP)*(02+1)-1)-:(BW_REMAP)] ;
        end
        else if(r_mem_re_map_pos[gidx][DLY_MEM_REMAP]==2'd2) begin
            rr_mem_re_map_dout[gidx] <= r_mem_re_map_dout[gidx][DLY_MEM_REMAP][((BW_REMAP)*(01+1)-1)-:(BW_REMAP)] ;
        end
        else if(r_mem_re_map_pos[gidx][DLY_MEM_REMAP]==2'd3) begin
            rr_mem_re_map_dout[gidx] <= r_mem_re_map_dout[gidx][DLY_MEM_REMAP][((BW_REMAP)*(00+1)-1)-:(BW_REMAP)] ;
        end
    end
end
end
endgenerate

always@(posedge i_clk) begin
    if(rr_mem_re_map_rd_en[0]) begin
        rr_cbuf_mux_mem_re_map_rd_en  <=  rr_mem_re_map_rd_en   [0] ;
        rr_cbuf_mux_mem_re_map_dout   <=  rr_mem_re_map_dout    [0] ;
    end
    else if(rr_mem_re_map_rd_en[1]) begin 
        rr_cbuf_mux_mem_re_map_rd_en  <=  rr_mem_re_map_rd_en   [1] ;
        rr_cbuf_mux_mem_re_map_dout   <=  rr_mem_re_map_dout    [1] ;
    end
    else begin
        rr_cbuf_mux_mem_re_map_rd_en  <=  1'd0 ;
    end
end
always@(*) begin
    rr_dly_cbuf_mux_mem_re_map_rd_en  [0] = rr_cbuf_mux_mem_re_map_rd_en    ; 
    rr_dly_cbuf_mux_mem_re_map_dout   [0] = |r_dbg_mode[CC_REF] ? r_dbg_bf[CC_REF][(BW_REMAP-1+24)-:BW_REMAP] : rr_cbuf_mux_mem_re_map_dout     ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_REMAP;i=i+1) begin
        rr_dly_cbuf_mux_mem_re_map_rd_en[i] <= rr_dly_cbuf_mux_mem_re_map_rd_en[i-1]    ; 
        if(rr_dly_cbuf_mux_mem_re_map_rd_en[i-1]) begin
            rr_dly_cbuf_mux_mem_re_map_dout[i] <= rr_dly_cbuf_mux_mem_re_map_dout[i-1]     ;
        end
    end
end

reg  [01-1:0]       r_re_ext_cdata_en   [NUM_LANE_CC-1:0]   ;
reg  [2*DO_BW-1:0]  r_re_ext_cdata      [NUM_LANE_CC-1:0]   ;
wire [01-1:0]       w_re_sat_cdata_en   [NUM_LANE_CC-1:0]   ;
wire [2*DO_BW-1:0]  w_re_sat_cdata      [NUM_LANE_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_LANE_CC;gidx=gidx+1) begin : g03_cpri_iq_sat
ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   DO_BW_CPRI  )
 ,.DO_BW        (   DO_BW       ))
u03_bfw_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (  |w_re_cdata_en       [gidx]  )
    ,.i_in      (   w_re_cdata          [gidx]  )
    ,.o_out_en  (   w_re_sat_cdata_en   [gidx]  )
    ,.o_out     (   w_re_sat_cdata      [gidx]  )
);
end
endgenerate

reg [NUM_LAYER_LANE-1:0]    r_dly_re_cdata_en   [NUM_LANE_CC-1:0][DLY_DOUT_SYNC:0]  ;
reg [2*DO_BW-1:0]           r_dly_re_cdata      [NUM_LANE_CC-1:0][DLY_DOUT_SYNC:0]  ;
reg [12-1:0]                r_dbg_pat_cnt   ;
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        r_dbg_pat_cnt <= 12'd0 ;
    end
    else if(r_dly_re_cdata_en[IDX_LANE_REF][0][1]) begin
        r_dbg_pat_cnt <= r_dbg_pat_cnt + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_dly_re_cdata_en [i][0] <= w_re_cdata_en [i] ; 
    end
end
always@(*) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_dly_re_cdata [i][0] =  w_re_sat_cdata [i] ;
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_dly_re_cdata_en[i][1] <= r_dly_re_cdata_en[i][0] ;
        if(r_dly_re_cdata_en[i][0]) begin
            if(r_dbg_mode[CC_REF]==2'd3) begin
                r_dly_re_cdata [i][1] <= ((r_dbg_pat_cnt==((r_ntone[CC_REF]>>1)-r_smp_mon_cfg[CC_REF][12-1:0]))||(r_dbg_pat_cnt==((r_ntone[CC_REF]>>1)+r_smp_mon_cfg[CC_REF][12-1:0]))) ? {I_TEST_TONE,Q_TEST_TONE} : {{2*DO_BW}{1'b0}} ;
            end
            else begin
                r_dly_re_cdata [i][1] <= r_dly_re_cdata [i][0] ;
            end
        end
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        for(j=2;j<=DLY_DOUT_SYNC;j=j+1) begin
            r_dly_re_cdata_en[i][j] <= r_dly_re_cdata_en[i][j-1]    ; 
            if(r_dly_re_cdata_en[i][j-1]) begin
                r_dly_re_cdata[i][j] <= r_dly_re_cdata[i][j-1]     ;
            end
        end
    end
end

ylib_reg #(
     .WIDTH     (    4          ) 
    ,.DEPTH     (    DLY_SYNC   )) 
u04_fsync_dly
(
     .i_clk      (  i_clk               )
    ,.i_in       ( {w_frame_sync        ,w_subfrm_sync        ,w_slot_sync        ,w_symbol_sync      }   )
    ,.o_out      ( {o_dout_frame_sync   ,o_dout_subfrm_sync   ,o_dout_slot_sync   ,o_dout_symbol_sync }   )
);

always@(posedge i_clk) begin
    if(w_frame_sync) begin
        o_dout_mu   <=  rr_mu[CC_REF]    ;
        for(i=0;i<NUM_CC;i=i+1) begin
            o_dout_fft_size[((04)*(i+1)-1)-:(04)] <=  rr_fft_size[i]    ;
        end
    end
end
reg [01*NUM_LAYER_LANE-1:0]     r_dout_en     [NUM_LANE_CC-1:0] ;      
reg [2*DO_BW-1:0]               r_dout_iq     [NUM_LANE_CC-1:0] ;      
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        for(j=0;j<NUM_LAYER_LANE;j=j+1) begin
            r_dout_en   [i][j]  <=  r_dly_re_cdata_en [i][DLY_DOUT_SYNC][j] ;
        end
        if(r_dly_re_cdata_en[i][DLY_DOUT_SYNC][0]) begin
            r_dout_iq   [i] <= r_dly_re_cdata[i][DLY_DOUT_SYNC]&{{2*DO_BW}{r_layer_gate[CC_REF][i*NUM_LAYER_LANE+0]}} ;
        end
        else if(r_dly_re_cdata_en[i][DLY_DOUT_SYNC][1]) begin
            r_dout_iq   [i] <= r_dly_re_cdata[i][DLY_DOUT_SYNC]&{{2*DO_BW}{r_layer_gate[CC_REF][i*NUM_LAYER_LANE+1]}} ;
        end
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        for(j=0;j<NUM_LAYER_LANE;j=j+1) begin
            o_dout_en       [((01)*((i*NUM_LAYER_LANE+j+1)-1))-:(01)]  <=  r_dout_en[i][j] ;
        end
        if(r_dout_en[i][0]) begin
            o_dout_cc_id    [((`mlib_clog2(NUM_CC))*(i+1)-1)-:`mlib_clog2(NUM_CC)] <= 1'd0 ;
            o_dout_lyr_id   [(($clog2(NUM_LAYER))*(i+1)-1)-:($clog2(NUM_LAYER))] <= {{$clog2(NUM_LAYER)}{1'd1}}&(i*NUM_LAYER_LANE+0) ;
        end
        else if(r_dout_en[i][1]) begin
            o_dout_cc_id    [((`mlib_clog2(NUM_CC))*(i+1)-1)-:`mlib_clog2(NUM_CC)] <= 1'd0 ;
            o_dout_lyr_id   [(($clog2(NUM_LAYER))*(i+1)-1)-:($clog2(NUM_LAYER))] <= {{$clog2(NUM_LAYER)}{1'd1}}&(i*NUM_LAYER_LANE+1) ;
        end
        if(|r_dout_en[0]) begin
            o_dout_iq [((2*DO_BW )*(i+1)-1)-:(2*DO_BW)] <= r_dout_iq[i] ;
        end
    end
    if(|r_dout_en[0]) begin
        o_pout0_cb_idx <= rr_dly_cbuf_mux_mem_rb_cbidx_dout   [DLY_CBIDX ]  ;
        o_pout0_nmusul <= rr_dly_cbuf_mux_mem_rb_nmusul_dout  [DLY_NMUSUL]  ;
        o_pout0_re_map <= rr_dly_cbuf_mux_mem_re_map_dout     [DLY_REMAP ]  ;
    end
end
reg [01*NUM_LAYER_LANE-1:0] r_dout_mon_en   [NUM_LANE_CC-1:0] ;
reg [2*DO_BW-1:0]           r_dout_mon_iq   [NUM_LANE_CC-1:0] ;
reg [$clog2(NUM_LAYER)-1:0] r_dout_mon_lyr  [NUM_LANE_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_dout_mon_iq  [i] = o_dout_iq     [((2*DO_BW)*(i+1)-1)-:(2*DO_BW)] ;
        r_dout_mon_lyr [i] = o_dout_lyr_id [(($clog2(NUM_LAYER))*(i+1)-1)-:($clog2(NUM_LAYER))] ;
        for(j=0;j<NUM_LAYER_LANE;j=j+1) begin
            r_dout_mon_en [i][j] = o_dout_en [((01)*((i*NUM_LAYER_LANE+j+1)-1))-:(01)] ;
        end
    end
end
reg [4-1:0] r_re_idx ;
reg [9-1:0] r_rb_idx ;
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        r_re_idx <= 4'd0 ;
        r_rb_idx <= 9'd0 ;
    end
    else if(r_dout_en[IDX_LANE_REF][IDX_LAYER_CNT_REF]) begin
        if(r_re_idx==NUM_RE_RB-1'd1) begin
            r_re_idx <= 4'd0 ;
            if(r_rb_idx<NUM_CPARAM_RB_SYMBOL) begin
                r_rb_idx <= r_rb_idx + 1'd1 ;
            end
        end
        else begin
            r_re_idx <= r_re_idx + 1'd1 ;
        end
    end
end
always@(posedge i_clk) begin
    if(|r_dout_en[IDX_LANE_REF]) begin
        o_dout_muw_idx <= r_rb_idx>>1 ;
    end
end
`ifndef  DLFE_LSSI_DISABLE
wire    [0:0]   w_lssi_en    [NUM_LAYER*NUM_CC-1:0]   ;
wire    [6:0]   w_lssi_id    [NUM_LAYER*NUM_CC-1:0]   ;
wire    [31:0]  w_lssi       [NUM_LAYER*NUM_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_LAYER*NUM_CC;gidx=gidx+1) begin : g04_lssi
ylib_xssi #(
     .NUM_FRAME     (    NUM_FRAME_XSSI     ) 
    ,.RPT_FRAME     (    7'd0               ) 
    ,.BW_SIG        (    DO_BW              ) 
    ,.ID_XSSI       (    7'd0               )) 
u05_lssi
(
      .i_rst            (     i_rst[gidx/NUM_LAYER]                 )
     ,.i_clk            (     i_clk                                 )
     ,.i_frame_sync     (     w_frame_sync                          )
     ,.i_sig_en         (     r_dly_re_cdata_en [gidx/NUM_LAYER_LANE][DLY_DOUT_SYNC][gidx%NUM_LAYER_LANE]       )
     ,.i_sig_i          (     r_dly_re_cdata    [gidx/NUM_LAYER_LANE][DLY_DOUT_SYNC][(DO_BW*2-1)-:DO_BW]        )
     ,.i_sig_q          (     r_dly_re_cdata    [gidx/NUM_LAYER_LANE][DLY_DOUT_SYNC][(DO_BW*1-1)-:DO_BW]        )
     ,.o_xssi_en        (     w_lssi_en[gidx]                       )
     ,.o_xssi_id        (     w_lssi_id[gidx]                       )
     ,.o_xssi           (     w_lssi   [gidx]                       )
);
end
endgenerate
`endif //DLFE_LSSI_DISABLE
`endif //DLFE_ORAN_DISABLE
`ifndef DLFE_MON_SMP_DISABLE
reg [5:0]  r_slot_idx   ;
reg [3:0]  r_symbol_idx ;
always@(posedge i_clk) begin
    if(o_dout_slot_sync) begin
        r_slot_idx      <=  w_slot[5:0] ;
    end
    if(o_dout_symbol_sync) begin
        r_symbol_idx    <=  w_symbol    ;
    end
end
reg [8-1:0] r_frame_idx ;
always@(posedge i_clk) begin
    if(|i_rst) begin
        r_frame_idx <= 8'd0 ;
    end
    if(o_dout_frame_sync) begin 
        r_frame_idx <= r_frame_idx + 1'd1 ;
    end
end
reg [01-1:0]        r_mon_smp_en [NUM_CC-1:0] ;
reg [2*DO_BW-1:0]   r_mon_smp_iq [NUM_CC-1:0] ;
`endif //DLFE_MON_SMP_DISABLE
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g06_mon_dlfe
ylib_mon_time_stamp #(
     .WIDTH         (  22           )) 
u06_mon_time_stamp
(
     .i_clk         (  i_clk                                        )
    ,.i_sync        (  r_frame_sync                                 )
    ,.o_time_stamp  (  o_dlfe_rpt_1130[((22)*(gidx+1)-1)-:(22)]     )
);
always@(posedge i_clk) begin
    if(r_frame_sync&&o_dlfe_rpt_1130[((22)*(gidx+1)-1)-:(22)]!=CLK_FRAME-1'd1) begin
        o_dlfe_rpt_1138[((16)*(gidx+1)-1)-:(16)] <= o_dlfe_rpt_1138[((16)*(gidx+1)-1)-:(16)] + 1'd1 ;
    end
end
`ifndef DLFE_MON_SMP_DISABLE
`ifndef DLFE_ORAN_DISABLE
always@(posedge i_clk) begin
    if(o_dout_cc_id==((`mlib_clog2(NUM_CC))&gidx)&&r_dout_mon_lyr[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_O_CHAIN))-1:28]]==r_smp_mon_cfg[gidx][24+(`mlib_clog2(NUM_LAYER))-1:24]) begin
        r_mon_smp_en[gidx]  <=  r_dout_mon_en[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_O_CHAIN))-1:28]] ;
        r_mon_smp_iq[gidx]  <=  r_dout_mon_iq[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_O_CHAIN))-1:28]] ;
    end
    else begin
        r_mon_smp_en[gidx]  <=  1'd0   ;
    end
end
`else //DLFE_ORAN_DISABLE
always@(posedge i_clk) begin
    if(o_dout_cc_id==((`mlib_clog2(NUM_CC))&gidx)&&r_dout_mon_lyr[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_LANE_CC))-1:28]]==r_smp_mon_cfg[gidx][24+(`mlib_clog2(NUM_LAYER))-1:24]) begin
        r_mon_smp_en[gidx]  <=  r_dout_mon_en[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_LANE_CC))-1:28]] ;
        r_mon_smp_iq[gidx]  <=  r_dout_mon_iq[r_smp_mon_cfg[gidx][28+(`mlib_clog2(NUM_LANE_CC))-1:28]] ;
    end
    else begin
        r_mon_smp_en[gidx]  <=  1'd0   ;
    end
end
`endif //DLFE_ORAN_DISABLE
wire    [2*DO_BW-1:0]  w_mon_smp_min  [NUM_CC-1:0]    ;
wire    [2*DO_BW-1:0]  w_mon_smp_max  [NUM_CC-1:0]    ;
ylib_mon_smp #(
     .NUM_STREAM    (  2           ) 
    ,.DIO_BW        (  DO_BW       )) 
u07_mon_fd_smp
(
     .i_clk         (  i_clk                                        )
    ,.i_target      (  r_smp_mon_cfg[gidx]                          )
    ,.i_frame       (  r_frame_idx                                  )
    ,.i_slot        ( {2'd0,r_slot_idx}                             )
    ,.i_symbol      ( {4'd0,r_symbol_idx}                           )
    ,.i_rsync       (  o_dout_frame_sync                            )
    ,.i_en          (  r_mon_smp_en[gidx]                           )
    ,.i_in          (  r_mon_smp_iq[gidx]                           )
    ,.o_max         (  w_mon_smp_min[gidx]                          )
    ,.o_min         (  w_mon_smp_max[gidx]                          )
);
assign    o_dlfe_rpt_1120[((32)*(gidx+1)-1)-:(32)]   =   {{{2*(DI_BW-DO_BW)}{1'b0}},w_mon_smp_min[gidx]} ;
assign    o_dlfe_rpt_1124[((32)*(gidx+1)-1)-:(32)]   =   {{{2*(DI_BW-DO_BW)}{1'b0}},w_mon_smp_max[gidx]} ;
`endif //DLFE_MON_SMP_DISABLE
end
endgenerate

`ifndef  DLFE_LSSI_DISABLE
generate if(NUM_CC==1) begin : g07_lssi_if
    if(NUM_LAYER==2) begin
        always@(*) begin
            o_dlfe_rpt_1080    =   w_lssi[0] ;                 
            o_dlfe_rpt_1084    =   w_lssi[1] ;                 
        end
    end//NUM_LAYER
    else if(NUM_LAYER==4) begin
        always@(*) begin
            o_dlfe_rpt_1080    =   w_lssi[0] ;                 
            o_dlfe_rpt_1084    =   w_lssi[1] ;                 
            o_dlfe_rpt_1088    =   w_lssi[2] ;                 
            o_dlfe_rpt_108c    =   w_lssi[3] ;                 
        end
    end//NUM_LAYER
    else if(NUM_LAYER==8) begin
        always@(*) begin
            o_dlfe_rpt_1080    =   w_lssi[0] ;                 
            o_dlfe_rpt_1084    =   w_lssi[1] ;                 
            o_dlfe_rpt_1088    =   w_lssi[2] ;                 
            o_dlfe_rpt_108c    =   w_lssi[3] ;                 
            o_dlfe_rpt_1090    =   w_lssi[4] ;                 
            o_dlfe_rpt_1094    =   w_lssi[5] ;                 
            o_dlfe_rpt_1098    =   w_lssi[6] ;                 
            o_dlfe_rpt_109c    =   w_lssi[7] ;                 
        end
    end//NUM_LAYER
end
else if(NUM_CC==2) begin
    if(NUM_LAYER==2) begin
        always@(*) begin
            o_dlfe_rpt_1080    =  {w_lssi[2],w_lssi[0]} ;                 
            o_dlfe_rpt_1084    =  {w_lssi[3],w_lssi[1]} ;                 
        end
    end//NUM_LAYER
    else if(NUM_LAYER==4) begin
        always@(*) begin
            o_dlfe_rpt_1080    =  {w_lssi[4],w_lssi[0]} ;                 
            o_dlfe_rpt_1084    =  {w_lssi[5],w_lssi[1]} ;                 
            o_dlfe_rpt_1088    =  {w_lssi[6],w_lssi[2]} ;                 
            o_dlfe_rpt_108c    =  {w_lssi[7],w_lssi[3]} ;                 
        end
    end//NUM_LAYER
    else if(NUM_LAYER==8) begin
        always@(*) begin
            o_dlfe_rpt_1080    =  {w_lssi[08],w_lssi[00]} ;                 
            o_dlfe_rpt_1084    =  {w_lssi[09],w_lssi[01]} ;                 
            o_dlfe_rpt_1088    =  {w_lssi[10],w_lssi[02]} ;                 
            o_dlfe_rpt_108c    =  {w_lssi[11],w_lssi[03]} ;                 
            o_dlfe_rpt_1090    =  {w_lssi[12],w_lssi[04]} ;                 
            o_dlfe_rpt_1094    =  {w_lssi[13],w_lssi[05]} ;                 
            o_dlfe_rpt_1098    =  {w_lssi[14],w_lssi[06]} ;                 
            o_dlfe_rpt_109c    =  {w_lssi[15],w_lssi[07]} ;                 
        end
    end//NUM_LAYER
end
else if(NUM_CC==4) begin
    if(NUM_LAYER==2) begin
        always@(*) begin
            o_dlfe_rpt_1080    =  {w_lssi[6],w_lssi[4],w_lssi[2],w_lssi[0]} ;                 
            o_dlfe_rpt_1084    =  {w_lssi[7],w_lssi[5],w_lssi[3],w_lssi[1]} ;                 
        end
    end//NUM_LAYER
end
endgenerate
`endif //DLFE_LSSI_DISABLE
endmodule
