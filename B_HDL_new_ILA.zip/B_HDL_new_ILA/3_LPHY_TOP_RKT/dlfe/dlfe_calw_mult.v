////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : VzW RT8808
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_calw_mult
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe calibration weight multiplication 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.06 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2021.02.10 | jyzoo.lee     | CPRI Support
//  ------------+---------------+-----------------------------------------------
//   2021.04.29 | jyzoo.lee     | Added Xilinx Attribute to Memory Fanout Paths
//  ------------+---------------+-----------------------------------------------
//   2021.04.29 | jyzoo.lee     | Forward IFFT Mapper Structure
//  ------------+---------------+-----------------------------------------------
//   2021.05.10 | jyzoo.lee     | Xilinx Cmult Support for Resource Reduction
//  ------------+---------------+-----------------------------------------------
//   2021.06.25 | jyzoo.lee     | Indirect CAL Weight Interface Support
//  ------------+---------------+-----------------------------------------------
//   2021.07.21 | jyzoo.lee     | MU-MIMO Support with Shared Memory  
//  ------------+---------------+-----------------------------------------------
//   2021.08.12 | jyzoo.lee     | Add MUCAL Interface with MUWG
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//   2021.11.21 | jyzoo.lee     | ANT Multiplexing Support 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_calw_mult
#(
    parameter  NUM_CC               =   1
   ,parameter  NUM_ANT              =   1
   ,parameter  NUM_CHAIN            =   1
   ,parameter  DI_BW                =   16           
   ,parameter  DO_BW                =   16           
   ,parameter  ADDR_OFFSET          =   'h00000           
   ,parameter  VENDOR               =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_clk                  
            
    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid

    //--- from dlfe_param_if
    ,   input   wire    [01*NUM_CC-1:0]                         i_dlfe_par_0050
    ,   input   wire    [$clog2(NUM_ANT)*NUM_CC-1:0]            i_dlfe_par_3c04
    ,   input   wire    [04*NUM_CC-1:0]                         i_dlfe_par_1290
    
    //--- from dlfe_bfw_mult
    ,   input   wire    [01-1:0]                                i_din_frame_sync 
    ,   input   wire    [01-1:0]                                i_din_slot_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [01*NUM_CHAIN-1:0]                      i_din_en        
    ,   input   wire    [2*DI_BW*NUM_CHAIN-1:0]                 i_din_iq                
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_CHAIN-1:0]   i_din_cc_id
    ,   input   wire    [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         i_din_ant_id
    ,   input   wire    [04-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
    ,   input   wire    [02-1:0]                                i_din_cal_en
    ,   input   wire    [01-1:0]                                i_din_mure_en

    //--- to dlfe_phase_comp
    ,   output  wire    [01-1:0]                                o_dout_frame_sync 
    ,   output  wire    [01-1:0]                                o_dout_slot_sync
    ,   output  wire    [01-1:0]                                o_dout_symbol_sync
    ,   output  wire    [01*NUM_CHAIN-1:0]                      o_dout_en        
    ,   output  wire    [2*DO_BW*NUM_CHAIN-1:0]                 o_dout_iq                
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_CHAIN-1:0]   o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         o_dout_ant_id
    ,   output  reg     [04-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size
    ,   output  reg     [02-1:0]                                o_dout_cal_en

    //--- to MU_WG 
`ifndef DLFE_MU_MIMO_DISABLE
    ,   output  reg     [14*NUM_CC-1:0]                         o_muwg_addr
    ,   output  reg     [01*NUM_CC-1:0]                         o_muwg_wren
    ,   output  reg     [01*NUM_CC-1:0]                         o_muwg_rden
    ,   output  reg     [24*NUM_CC-1:0]                         o_muwg_wdata
`endif// DLFE_MU_MIMO_DISABLE

);

//Parameter Local Logic
localparam                  CC_REF              =       0                                       ;
localparam                  CHAIN_REF           =       0                                       ;
localparam                  IDX_DATA_SYM        =       2'd0                                    ;
localparam                  IDX_DL_CAL_SYM      =       2'd1                                    ;
localparam                  IDX_UL_CAL_SYM      =       2'd2                                    ;
localparam                  BW_WGT              =       12                                      ;
localparam                  DLY_SYNC            =       4'd13                                   ;   
localparam                  DLY_WGT_RD          =       1                                       ;   
localparam                  DLY_IN              =       4                                       ;   
localparam                  NUM_RE_RB_CHAIN     =       NUM_ANT/NUM_CHAIN==2 ? 5'd24 : 5'd12    ;
localparam                  MAX_RB              =       9'd273                                  ;
localparam                  NUM_SU_CALW         =       9'd273                                  ;   
`ifndef DLFE_MU_MIMO_DISABLE
localparam                  NUM_MU_CALW         =       9'd136                                  ;   
`else// DLFE_MU_MIMO_DISABLE
localparam                  NUM_MU_CALW         =       9'd0                                    ;   
`endif// DLFE_MU_MIMO_DISABLE
localparam                  NUM_CALW            =       NUM_SU_CALW+NUM_MU_CALW                 ;   
localparam  [20-1:00]       SU_CAL_START_ADDR   =       ADDR_OFFSET                             ;
localparam  [20-1:00]       SU_CAL_ADDR_OFFSET  =       NUM_SU_CALW*4                           ;
localparam  [20-1:00]       MU_CAL_START_ADDR   =       ADDR_OFFSET+'h800                       ;
localparam  [20-1:00]       MU_CAL_ADDR_OFFSET  =       NUM_MU_CALW*4                           ;

//Logic Variable
integer i ;
genvar gidx ;

reg [01-1:0]                    r_en        [NUM_CHAIN-1:0][DLY_IN:0] ;
reg [2*DI_BW-1:0]               r_iq        [NUM_CHAIN-1:0][DLY_IN:0] ;   
reg [(`mlib_clog2(NUM_CC))-1:0] r_cc_id     [NUM_CHAIN-1:0];
reg [$clog2(NUM_ANT)-1:0]       r_ant_id    [NUM_CHAIN-1:0];

reg [01-1:0] r_cpu_wren  [NUM_CC-1:0] ;
reg [01-1:0] r_cpu_rden  [NUM_CC-1:0] ;
reg [20-1:0] r_cpu_addr  [NUM_CC-1:0] ;
reg [32-1:0] r_cpu_wdata [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cpu_wren  [i] = i_cpu_wren[i]  ;
        r_cpu_rden  [i] = i_cpu_rden[i]  ;
        r_cpu_addr  [i] = i_cpu_addr [((20)*(i+1)-1)-:(20)] ;
        r_cpu_wdata [i] = i_cpu_wdata[((32)*(i+1)-1)-:(32)] ;
    end
end
reg [2*BW_WGT-1:0] r_cpu_wgt [NUM_CC-1:0]   ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cpu_wgt  [i] = {r_cpu_wdata[i][16+BW_WGT-1:16],r_cpu_wdata[i][00+BW_WGT-1:00]};
    end
end

reg [04-1:0] r_scale_wcal    [NUM_CC-1:0] ;
reg [01-1:0] r_dlSuCalBypass [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin
        for(i=0;i<NUM_CC;i=i+1) begin
            r_scale_wcal    [i] <=  i_dlfe_par_1290[((04)*(i+1)-1)-:(04)] ;
            r_dlSuCalBypass [i] <=  i_dlfe_par_0050[((01)*(i+1)-1)-:(01)] ;
        end
    end
end
reg [$clog2(NUM_ANT)-1:0] r_ant_buf_sel [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_ant_buf_sel [i] = i_dlfe_par_3c04[(($clog2(NUM_ANT))*(i+1)-1)-:($clog2(NUM_ANT))] ;
    end
end
reg [01-1:0] r_mure_en  ;
always@(posedge i_clk) begin
    r_mure_en <= i_din_mure_en ;
end
reg [05-1:0] r_re_idx   ;
reg [10-1:0] r_rb_idx   ;
always@(posedge i_clk) begin
    if((r_en[CHAIN_REF][0]|r_en[CHAIN_REF][1])&~(r_en[CHAIN_REF][1]|r_en[CHAIN_REF][2])) begin
        r_re_idx <= 5'd0 ;
        r_rb_idx <= 10'd0 ;
    end
    else if(r_en[CHAIN_REF][1]) begin
        if(r_re_idx==NUM_RE_RB_CHAIN-1) begin
            r_re_idx <= 5'd0 ;
            r_rb_idx <= r_rb_idx + 10'd1 ;
        end
        else begin
            r_re_idx <= r_re_idx + 5'd1 ;
        end
    end
end
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_calw_buf_en      [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [01-1:0]        r_calw_buf_wren    [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [20-1:0]        r_calw_buf_addr    [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [2*BW_WGT-1:0]  r_calw_buf_wdata   [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [01-1:0]        r_calw_buf_rden    [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [01-1:0]        r_calw_buf_muen    [NUM_ANT*NUM_CC-1:0] ;
`else// DLFE_XILINX_VERSAL
reg [01-1:0]        r_calw_buf_en      [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        r_calw_buf_wren    [NUM_ANT*NUM_CC-1:0] ;
reg [20-1:0]        r_calw_buf_addr    [NUM_ANT*NUM_CC-1:0] ;
reg [2*BW_WGT-1:0]  r_calw_buf_wdata   [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        r_calw_buf_rden    [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        r_calw_buf_muen    [NUM_ANT*NUM_CC-1:0] ;
`endif// DLFE_XILINX_VERSAL
wire[2*BW_WGT-1:0]  w_calw_buf_rdata   [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        rr_calw_buf_muen   [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        rr_calw_buf_en     [NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        rr_calw_buf_rden   [NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [2*BW_WGT-1:0]  rr_calw_buf_rdata  [NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
generate for(gidx=0;gidx<NUM_ANT*NUM_CC;gidx=gidx+1) begin : g00_calw_mem
always@(posedge i_clk) begin
    if(r_cpu_wren[gidx/NUM_ANT]&&r_cpu_addr[gidx/NUM_ANT]>=SU_CAL_START_ADDR&&r_cpu_addr[gidx/NUM_ANT]<(SU_CAL_START_ADDR+SU_CAL_ADDR_OFFSET)&&(r_ant_buf_sel[gidx/NUM_ANT]==(gidx%NUM_ANT))) begin
        r_calw_buf_en    [gidx]  <=  1'd0 ;
        r_calw_buf_wren  [gidx]  <=  r_cpu_wren[gidx/NUM_ANT] ;
        r_calw_buf_addr  [gidx]  <= (r_cpu_addr[gidx/NUM_ANT]-(SU_CAL_START_ADDR))>>2 ; 
        r_calw_buf_wdata [gidx]  <=  r_cpu_wgt[gidx/(NUM_ANT)] ;
        r_calw_buf_rden  [gidx]  <=  1'd0 ;
    end
    else if(r_cpu_rden[gidx/NUM_ANT]&&r_cpu_addr[gidx/NUM_ANT]>=SU_CAL_START_ADDR&&r_cpu_addr[gidx/NUM_ANT]<(SU_CAL_START_ADDR+SU_CAL_ADDR_OFFSET)&&(r_ant_buf_sel[gidx/NUM_ANT]==(gidx%NUM_ANT))) begin
        r_calw_buf_en    [gidx]  <=  1'd0 ;
        r_calw_buf_wren  [gidx]  <=  1'd0 ;
        r_calw_buf_addr  [gidx]  <= (r_cpu_addr[gidx/NUM_ANT]-(SU_CAL_START_ADDR))>>2 ; 
        r_calw_buf_rden  [gidx]  <=  r_cpu_rden[gidx/NUM_ANT] ;
    end
    else if((r_en[(gidx/NUM_CC)/(NUM_ANT/NUM_CHAIN)][1]&&i_din_cal_en==IDX_DATA_SYM)&&(r_cc_id[(gidx/NUM_CC)/(NUM_ANT/NUM_CHAIN)]==(gidx/NUM_ANT))) begin
        r_calw_buf_en    [gidx]  <=  1'd1 ;
        r_calw_buf_wren  [gidx]  <=  1'd0 ;
        r_calw_buf_rden  [gidx]  <=  1'd0 ;
        r_calw_buf_muen  [gidx]  <=  r_mure_en ;
        r_calw_buf_addr  [gidx]  <= {10'd0,r_rb_idx} ;
    end
    else begin
        r_calw_buf_en    [gidx]  <=  1'd0 ;
        r_calw_buf_wren  [gidx]  <=  1'd0 ;
        r_calw_buf_rden  [gidx]  <=  1'd0 ;
    end
end

if(VENDOR=="Xilinx_Versal") begin : g00_0_calw_mem_vendor
ylib_rams_sdp #(
    .WIDTH      (   2*BW_WGT        )
   ,.DEPTH      (   NUM_CALW        )
   ,.VENDOR     (   "Xilinx"        )
   ,.RAM_STYLE  (   "block"         )) 
u00_calw_mem 
(
    .clk    (i_clk                                          )
   ,.ena    (r_calw_buf_wren [gidx]                         )
   ,.enb    (r_calw_buf_en   [gidx]|r_calw_buf_rden [gidx]  )
   ,.wea    (r_calw_buf_wren [gidx]                         )
   ,.addra  (r_calw_buf_addr [gidx][$clog2(NUM_CALW)-1:0]   )
   ,.addrb  (r_calw_buf_addr [gidx][$clog2(NUM_CALW)-1:0]   )
   ,.dia    (r_calw_buf_wdata[gidx]                         )
   ,.dob    (w_calw_buf_rdata[gidx]                         )
);
end
else begin
ylib_rams_sdp #(
    .WIDTH      (   2*BW_WGT        )
   ,.DEPTH      (   NUM_CALW        )
   ,.VENDOR     (   VENDOR          )
   ,.RAM_STYLE  (   "block"         )) 
u00_calw_mem 
(
    .clk    (i_clk                                          )
   ,.ena    (r_calw_buf_wren [gidx]                         )
   ,.enb    (r_calw_buf_en   [gidx]|r_calw_buf_rden [gidx]  )
   ,.wea    (r_calw_buf_wren [gidx]                         )
   ,.addra  (r_calw_buf_addr [gidx][$clog2(NUM_CALW)-1:0]   )
   ,.addrb  (r_calw_buf_addr [gidx][$clog2(NUM_CALW)-1:0]   )
   ,.dia    (r_calw_buf_wdata[gidx]                         )
   ,.dob    (w_calw_buf_rdata[gidx]                         )
);
end
always@(posedge i_clk) begin
    rr_calw_buf_en  [gidx]    <= r_calw_buf_en[gidx]    ;
    rr_calw_buf_muen[gidx]    <= r_calw_buf_muen[gidx]  ;
    rr_calw_buf_rden[gidx][0] <= r_calw_buf_rden[gidx]  ;
end
always@(*) begin
    rr_calw_buf_rdata[gidx][0] = w_calw_buf_rdata[gidx]  ;
end
if(DLY_WGT_RD>0) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_calw_buf_rden[gidx][i] <= rr_calw_buf_rden[gidx][i-1] ;
        if(rr_calw_buf_rden[gidx][i-1]) begin
            rr_calw_buf_rdata[gidx][i] <= rr_calw_buf_rdata[gidx][i-1] ;
        end
    end
end
end//if(DLY_WGT_RD>0)
end
endgenerate

reg [01-1:0]        r_mux_calw_mux_en [NUM_ANT-1:0] ;
reg [2*BW_WGT-1:0]  r_mux_calw_mux    [NUM_ANT-1:0] ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_mux_calw_mux
if(NUM_CC>1) begin
always@(posedge i_clk) begin
    if(rr_calw_buf_en[gidx]|rr_calw_buf_en[gidx+NUM_ANT]) begin
        if(r_cc_id[gidx]=={{(`mlib_clog2(NUM_CC))}{1'd0}}) begin
            r_mux_calw_mux_en[gidx]   <= rr_calw_buf_en[gidx] ;
            if((rr_calw_buf_muen[gidx]==1'b0&&r_dlSuCalBypass[0])||(rr_calw_buf_muen[gidx]==1'b1)) begin
                r_mux_calw_mux[gidx] <= {{{{{BW_WGT-1}{1'b0}},1'b1}<<r_scale_wcal[0]},{{BW_WGT}{1'b0}}} ;  
            end
            else begin
                r_mux_calw_mux[gidx] <= rr_calw_buf_rdata[gidx][0] ;  
            end
        end
        else begin
            r_mux_calw_mux_en[gidx]   <= rr_calw_buf_en[gidx+NUM_ANT] ;
            if((rr_calw_buf_muen[gidx+NUM_ANT]==1'b0&&r_dlSuCalBypass[1])||(rr_calw_buf_muen[gidx+NUM_ANT]==1'b1)) begin
                r_mux_calw_mux[gidx] <= {{{{{BW_WGT-1}{1'b0}},1'b1}<<r_scale_wcal[1]},{{BW_WGT}{1'b0}}} ;  
            end
            else begin
                r_mux_calw_mux[gidx] <= rr_calw_buf_rdata[gidx+NUM_ANT][0] ;  
            end
        end
    end
    else if(|i_din_cal_en) begin
        r_mux_calw_mux_en[gidx]   <= 1'd1 ; 
        r_mux_calw_mux   [gidx]   <= {{{{{BW_WGT-1}{1'b0}},1'b1}<<r_scale_wcal[r_cc_id[gidx]]},{{BW_WGT}{1'b0}}} ;  
    end
    else begin
        r_mux_calw_mux_en[gidx]   <=  1'd0 ;  
    end
end
end//(NUM_CC>1)
else begin//(NUM_CC>1)
always@(posedge i_clk) begin
    if(|i_din_cal_en) begin
        r_mux_calw_mux_en[gidx]   <= 1'd1   ; 
        r_mux_calw_mux   [gidx]   <= {{{{{BW_WGT-1}{1'b0}},1'b1}<<r_scale_wcal[CC_REF]},{{BW_WGT}{1'b0}}} ;  
    end
    else if(rr_calw_buf_en[gidx]) begin
        r_mux_calw_mux_en[gidx]   <= rr_calw_buf_en[gidx]    ; 
        if((rr_calw_buf_muen[gidx]==1'b0&&r_dlSuCalBypass[0])||(rr_calw_buf_muen[gidx]==1'b1)) begin
            r_mux_calw_mux[gidx]    <= {{{{{BW_WGT-1}{1'b0}},1'b1}<<r_scale_wcal[0]},{{BW_WGT}{1'b0}}} ;  
        end
        else begin
            r_mux_calw_mux[gidx]    <= rr_calw_buf_rdata[gidx][0] ;  
        end
    end
    else begin
        r_mux_calw_mux_en[gidx]   <= 1'd0 ;  
    end
end
end//(NUM_CC>1)
end
endgenerate

reg [01-1:0]    r_calw_cpu_rd_valid  [NUM_CC-1:0]  ;
reg [32-1:0]    r_calw_cpu_rdata     [NUM_CC-1:0]  ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g03_cal_cpu_rd //Multiplexing Stage depends on NUM_ANT
always@(posedge i_clk) begin
    if(rr_calw_buf_rden[NUM_ANT*gidx+00][DLY_WGT_RD]) begin
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+00][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+00][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+01][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+01][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+01][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+02][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+02][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+02][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+03][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+03][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+03][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+04][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+04][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+04][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+05][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+05][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+05][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+06][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+06][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+06][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_calw_buf_rden[NUM_ANT*gidx+07][DLY_WGT_RD]) begin                                       
        r_calw_cpu_rd_valid  [gidx]   <=  rr_calw_buf_rden  [NUM_ANT*gidx+07][DLY_WGT_RD] ;
        r_calw_cpu_rdata     [gidx]   <=  rr_calw_buf_rdata [NUM_ANT*gidx+07][DLY_WGT_RD] ;
    end
    else begin
        r_calw_cpu_rd_valid  [gidx]   <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(r_calw_cpu_rd_valid[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  r_calw_cpu_rd_valid  [gidx] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},r_calw_cpu_rdata [gidx][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},r_calw_cpu_rdata [gidx][(1*BW_WGT-1)-:BW_WGT]} ;
    end
    else begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  1'd0 ;
    end
end
end
endgenerate

generate for(gidx=0;gidx<NUM_CHAIN;gidx=gidx+1) begin : g04_din_chain
always@(*) begin
    r_en[gidx][0] = i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    r_iq[gidx][0] = i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1] ;
        if(r_en[gidx][i-1]) begin
            r_iq[gidx][i] <= r_iq[gidx][i-1] ;
        end
    end
end
if((NUM_ANT/NUM_CHAIN)==1) begin
always@(*) begin
    r_cc_id [gidx] = i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
    r_ant_id[gidx] = i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:$clog2(NUM_ANT)] ;
end
end //if((NUM_ANT/NUM_CHAIN)==1)
else if((NUM_ANT/NUM_CHAIN)==2) begin
always@(posedge i_clk) begin
    if(i_din_frame_sync||(r_en[gidx][DLY_IN-1]&~r_en[gidx][DLY_IN])) begin
        r_cc_id [gidx] <= i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
        r_ant_id[gidx] <= {{$clog2(NUM_ANT)}{1'b1}}&((NUM_ANT/NUM_CHAIN)*gidx) ;
    end
    else if(r_en[gidx][DLY_IN]) begin
        r_ant_id[gidx] <= {r_ant_id[gidx][$clog2(NUM_ANT)-1:1],~r_ant_id[gidx][0]} ;
    end
end
end //if((NUM_ANT/NUM_CHAIN)==2)
end
endgenerate

wire [NUM_CHAIN-1:0]            w_calw_mult_en                      ;
wire [2*(DI_BW+BW_WGT+1)-1:0]   w_calw_mult_iq      [NUM_CHAIN-1:0] ;
wire [NUM_CHAIN-1:0]            w_calw_mult_sr_en                   ;
wire [2*(DI_BW+BW_WGT+1)-1:0]   w_calw_mult_sr_iq   [NUM_CHAIN-1:0] ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_calw_mult_i_dummy [NUM_CHAIN-1:0] ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_calw_mult_q_dummy [NUM_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_CHAIN;gidx=gidx+1) begin : g05_calw_mult_chain
if(VENDOR=="Xilinx_Versal") begin
xip_cmult_bb_top_c16
u01_calw_mult
(
    .aclk                   (   i_clk                                               )
   ,.s_axis_a_tvalid        (   r_en[gidx][DLY_IN]                                  )
   ,.s_axis_a_tdata         (  {{{{16-DI_BW}{r_iq[gidx][DLY_IN][(DI_BW*1-1)]}},r_iq[gidx][DLY_IN][(DI_BW*1-1)-:DI_BW]}
                               ,{{{16-DI_BW}{r_iq[gidx][DLY_IN][(DI_BW*2-1)]}},r_iq[gidx][DLY_IN][(DI_BW*2-1)-:DI_BW]}} )
   ,.s_axis_b_tvalid        (  |r_en[gidx/NUM_ANT][DLY_IN]                          )
   ,.s_axis_b_tdata         (  {{{{16-BW_WGT}{r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*1-1)]}},r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*1-1)-:BW_WGT]}
                               ,{{{16-BW_WGT}{r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*2-1)]}},r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*2-1)-:BW_WGT]}} )
   ,.m_axis_dout_tvalid     (   w_calw_mult_en[gidx]                                )
   ,.m_axis_dout_tdata      (  {w_calw_mult_q_dummy[gidx],w_calw_mult_iq[gidx][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)],w_calw_mult_i_dummy[gidx],w_calw_mult_iq[gidx][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]}  )
);                  
end
else begin //(VENDOR=="Xilinx_Versal")
ylib_cmult #(
    .AWIDTH     (   DI_BW       )
   ,.BWIDTH     (   BW_WGT      ))
u02_calw_mult
(
    .clk    (   i_clk                                                                                   )
   ,.en     (   r_en[gidx][DLY_IN]                                                                      )
   ,.ar     (   r_iq[gidx][DLY_IN][(DI_BW*2-1)-:DI_BW]                                                  )
   ,.ai     (   r_iq[gidx][DLY_IN][(DI_BW*1-1)-:DI_BW]                                                  )
   ,.br     (   r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*2-1)-:BW_WGT] )
   ,.bi     (   r_mux_calw_mux[r_ant_id[gidx]][(BW_WGT*1-1)-:BW_WGT] )
   ,.pen    (   w_calw_mult_en[gidx]                                                                    )
   ,.pr     (   w_calw_mult_iq[gidx][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]                          )
   ,.pi     (   w_calw_mult_iq[gidx][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]                          )
);
end //(VENDOR=="Xilinx_Versal")
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                   )
 ,.SHIFTD_BW    (   4                   )
 ,.IO_BW        (   DI_BW+BW_WGT+1      ))
u03_calw_shiftd_rnd 
(
     .i_clk     (   i_clk                           )
    ,.i_in_en   (   w_calw_mult_en[gidx]            )
    ,.i_in      (   w_calw_mult_iq[gidx]            )
    ,.i_shiftd  (   r_scale_wcal[r_cc_id[gidx]]     )
    ,.o_out_en  (   w_calw_mult_sr_en[gidx]         )
    ,.o_out     (   w_calw_mult_sr_iq[gidx]         )
);
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_WGT+1      )
 ,.DO_BW        (   DO_BW               ))
u04_calw_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_calw_mult_sr_en[gidx]                         )
    ,.i_in      (   w_calw_mult_sr_iq[gidx]                         )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
if((NUM_ANT/NUM_CHAIN)==1) begin
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_calw_mult_sr_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= r_cc_id [gidx] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_ant_id[gidx] ;
    end
end
end //if((NUM_ANT/NUM_CHAIN)==1)
else if((NUM_ANT/NUM_CHAIN)==2) begin
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_calw_mult_sr_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= r_cc_id [gidx] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= {{$clog2(NUM_ANT)}{1'b1}}&((NUM_ANT/NUM_CHAIN)*gidx) ;
    end
    else if(o_dout_en[((01)*(gidx+1)-1)-:(01)]) begin
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= {o_dout_ant_id[($clog2(NUM_ANT)*(gidx+1)-1):($clog2(NUM_ANT)*gidx)+1],~o_dout_ant_id[$clog2(NUM_ANT)*gidx]} ;
    end
end
end //if((NUM_ANT/NUM_CHAIN)==2)
end
endgenerate
always@(posedge i_clk) begin
    if(i_din_frame_sync||(|w_calw_mult_sr_en&~|o_dout_en)) begin
        o_dout_mu       <=  i_din_mu        ;
        o_dout_fft_size <=  i_din_fft_size  ;
        o_dout_cal_en   <=  i_din_cal_en    ;
    end
end
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u05_0_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_frame_sync ),.o_out(o_dout_frame_sync ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u05_1_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_slot_sync  ),.o_out(o_dout_slot_sync  ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u05_2_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_symbol_sync),.o_out(o_dout_symbol_sync));

`ifndef DLFE_MU_MIMO_DISABLE
reg [14-1:0] r_muwg_addr    [NUM_CC-1:0]    ;
reg [01-1:0] r_muwg_wren    [NUM_CC-1:0]    ;
reg [01-1:0] r_muwg_rden    [NUM_CC-1:0]    ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g06_muwg_calw_if
always@(posedge i_clk) begin
    if(r_cpu_wren[gidx]||r_cpu_rden[gidx]) begin
        if(r_cpu_addr[gidx]>=MU_CAL_START_ADDR&&r_cpu_addr[gidx]<(MU_CAL_START_ADDR+MU_CAL_ADDR_OFFSET)) begin
            r_muwg_wren[gidx] <= r_cpu_wren[gidx]   ;
            r_muwg_rden[gidx] <= r_cpu_rden[gidx]   ;
            case(r_ant_buf_sel[gidx])
                'h00    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h00 ; 
                'h01    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h01 ; 
                'h02    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h02 ; 
                'h03    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h03 ; 
                'h04    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h04 ; 
                'h05    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h05 ; 
                'h06    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h06 ; 
                'h07    :   r_muwg_addr[gidx] <= ((r_cpu_addr[gidx]-(MU_CAL_START_ADDR))>>2)+NUM_MU_CALW*'h07 ; 
                default :   r_muwg_addr[gidx] <= 'h0 ;
            endcase
        end
    end
    else begin
        r_muwg_wren[gidx] <= 1'b0 ;
        r_muwg_rden[gidx] <= 1'b0 ;
    end
end
always@(*) begin
    o_muwg_addr [((14)*(gidx+1)-1)-:(14)] = r_muwg_addr[gidx] ;
    o_muwg_wren [((01)*(gidx+1)-1)-:(01)] = r_muwg_wren[gidx] ;
    o_muwg_rden [((01)*(gidx+1)-1)-:(01)] = r_muwg_rden[gidx] ;
    o_muwg_wdata[((2*BW_WGT)*(gidx+1)-1)-:(2*BW_WGT)] = r_cpu_wgt[gidx] ;
end
end
endgenerate
`endif// DLFE_MU_MIMO_DISABLE
endmodule
