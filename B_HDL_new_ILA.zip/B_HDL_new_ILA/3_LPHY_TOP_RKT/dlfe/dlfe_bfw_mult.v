////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : VzW RT8808
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_bfw_mult
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe Opt7-2b beamforming weight multiplication 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.12.10 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2021.01.14 | jyzoo.lee     | Supports multiplexing
//  ------------+---------------+-----------------------------------------------
//   2021.05.03 | jyzoo.lee     | Cals Processing for Versal Optimization
//  ------------+---------------+-----------------------------------------------
//   2021.05.10 | jyzoo.lee     | Xilinx Cmult Support for Resource Reduction
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Merge the CPRI dedicated module
//  ------------+---------------+-----------------------------------------------
//   2021.06.28 | jyzoo.lee     | Indirect CPRI BF Weight Interface Support 
//  ------------+---------------+-----------------------------------------------
//   2021.06.29 | jyzoo.lee     | Memory Optimized for CPRI
//  ------------+---------------+-----------------------------------------------
//   2021.07.19 | jyzoo.lee     | MU-MIMO Support 
//  ------------+---------------+-----------------------------------------------
//   2021.08.03 | jyzoo.lee     | SUCB Comperession Support
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//   2021.11.21 | jyzoo.lee     | ANT Multiplexing Support 
//  ------------+---------------+-----------------------------------------------
//   2021.12.02 | jyzoo.lee     | nMaxL==8 Support
//  ------------+---------------+-----------------------------------------------
//   2021.12.07 | jyzoo.lee     | Combine Cal Pattern for maximizing its BW 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_bfw_mult
#(
    parameter   NUM_CC              =   1
   ,parameter   NUM_LAYER           =   1
   ,parameter   NUM_ANT             =   1
`ifndef DLFE_ORAN_DISABLE
   ,parameter   NUM_I_CHAIN         =   1
`else //DLFE_ORAN_DISABLE
   ,parameter   NUM_LANE_CC         =   4
   ,parameter   NUM_LAYER_LANE      =   2
`endif //DLFE_ORAN_DISABLE
   ,parameter   NUM_O_CHAIN         =   1
   ,parameter   MAX_NIFFT           =   2048 
   ,parameter   DI_BW               =   16           
   ,parameter   DO_BW               =   16           
   ,parameter   CALP_BW             =   14
   ,parameter   BW_WGT              =   12  
   ,parameter   ADDR_OFFSET         =   'h00000           
   ,parameter   BFCB_ADDR_OFFSET    =   'h00000           
   ,parameter   VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  
            
    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid

    //--- from dlfe_param_if

    ,   input   wire    [$clog2(NUM_LAYER)*NUM_CC-1:0]          i_dlfe_par_3c00
    ,   input   wire    [$clog2(NUM_ANT  )*NUM_CC-1:0]          i_dlfe_par_3c04
    ,   input   wire    [$clog2(NUM_LAYER)*NUM_CC-1:0]          i_dlfe_par_3c08

    //--- from bb_cal_schdlr
    ,   input   wire    [02-1:0]                                i_cals_cal_en
    ,   input   wire    [01*NUM_ANT-1:0]                        i_cals_pat_en 
    ,   input   wire    [2*CALP_BW-1:0]                         i_cals_pat_iq 

    //--- from dlfe_in_if
    ,   input   wire    [01-1:0]                                i_din_frame_sync 
    ,   input   wire    [01-1:0]                                i_din_subfrm_sync
    ,   input   wire    [01-1:0]                                i_din_slot_sync  
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [04-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
`ifndef DLFE_ORAN_DISABLE
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en        
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq                
    ,   input   wire    [15*NUM_I_CHAIN-1:0]                    i_din_beam_id       
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_I_CHAIN-1:0] i_din_cc_id
    ,   input   wire    [$clog2(NUM_LAYER)*NUM_I_CHAIN-1:0]     i_din_lyr_id
    ,   input   wire    [05-1:0]                                i_din_nlayer
`else //DLFE_ORAN_DISABLE
    ,   input   wire    [01*NUM_LAYER_LANE*NUM_LANE_CC-1:0]     i_din_en        
    ,   input   wire    [2*DI_BW*NUM_LANE_CC-1:0]               i_din_iq                
    ,   input   wire    [12-1:0]                                i_din_cb_idx
    ,   input   wire    [05-1:0]                                i_din_nmusul
    ,   input   wire    [06-1:0]                                i_din_re_map
    ,   input   wire    [09-1:0]                                i_din_muw_idx
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_LANE_CC-1:0] i_din_cc_id
    ,   input   wire    [$clog2(NUM_LAYER)*NUM_LANE_CC-1:0]     i_din_lyr_id
`endif //DLFE_ORAN_DISABLE

    //--- to dlfe_ifft_map_buf
    ,   output  wire    [01-1:0]                                o_dout_frame_sync 
    ,   output  wire    [01-1:0]                                o_dout_subfrm_sync
    ,   output  wire    [01-1:0]                                o_dout_slot_sync  
    ,   output  wire    [01-1:0]                                o_dout_symbol_sync
    ,   output  wire    [01*NUM_O_CHAIN-1:0]                    o_dout_en        
    ,   output  wire    [2*DO_BW*NUM_O_CHAIN-1:0]               o_dout_iq                
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_O_CHAIN-1:0] o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_O_CHAIN-1:0]       o_dout_ant_id
    ,   output  reg     [04-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size
    ,   output  reg     [02-1:0]                                o_dout_cal_en
    ,   output  wire    [01-1:0]                                o_dout_mure_en

    //--- from MU_WG 
`ifndef DLFE_MU_MIMO_DISABLE
    //,   input   wire    [NUM_ANT-1:0]                           i_muwg_en
    //,   input   wire    [BW_WGT*NUM_ANT-1:0]                    i_muwg_i
    //,   input   wire    [BW_WGT*NUM_ANT-1:0]                    i_muwg_q
    ,   input   wire    [01-1:0]                                i_muwg_en
    ,   input   wire    [BW_WGT-1:0]                            i_muwg_i
    ,   input   wire    [BW_WGT-1:0]                            i_muwg_q
`endif// DLFE_MU_MIMO_DISABLE
);

//Parameter Local Logic
`ifndef DLFE_ORAN_DISABLE
localparam                              CHAIN_REF                   =       0                                                               ;
localparam                              BW_ISQRT                    =       13                                                              ;
localparam  [13-1:00]                   DLY_SYNC                    =       NUM_I_CHAIN<NUM_LAYER ? MAX_NIFFT+305 : 15                      ;   
localparam                              DLY_WGT_RD                  =       3                                                               ;   
localparam                              DLY_IQ                      =       3                                                               ;   
localparam                              DLY_BUF_SYNC                =       2                                                               ;   
localparam                              DLY_NLAYER                  =       9                                                               ;   
localparam  [15-1:00]                   NUM_BF_CBW                  =       2**13                                                           ;   
localparam  [15-1:00]                   NUM_SU_CBW                  =       2**13                                                           ;   
localparam  [15-1:00]                   NUM_MU_CBW                  =       2**13                                                           ;   
localparam  [15-1:00]                   BID_BASE_BF_CBW             =       0*NUM_BF_CBW                                                    ;   
localparam  [15-1:00]                   BID_BASE_SU_CBW             =       1*NUM_SU_CBW                                                    ;   
localparam  [15-1:00]                   BID_BASE_MU_CBW             =       2*NUM_MU_CBW                                                    ;   
localparam  [20-1:00]                   BF_CB_START_ADDR            =       'h10000                                                         ;
localparam  [20-1:00]                   BF_CB_ADDR_OFFSET           =       NUM_BF_CBW*4                                                    ;
localparam  [20-1:00]                   SU_CB_START_ADDR            =       'h50000                                                         ;
localparam  [20-1:00]                   SU_CB_ADDR_OFFSET           =       NUM_SU_CBW*4                                                    ;
localparam  [20-1:00]                   MU_CB_START_ADDR            =       'h90000                                                         ;
localparam  [20-1:00]                   MU_CB_ADDR_OFFSET           =       NUM_MU_CBW*4                                                    ;
`else //DLFE_ORAN_DISABLE
localparam                              LANE_REF                    =       0                                                               ;
localparam                              CC_REF                      =       0                                                               ;
localparam                              IDX_LANE00                  =       0                                                               ;
localparam                              IDX_LANE01                  =       1                                                               ;
localparam                              IDX_LANE02                  =       2                                                               ;
localparam                              IDX_LANE03                  =       3                                                               ;
localparam                              BW_ISQRT                    =       13                                                              ;
localparam                              BW_WGT_COMP                 =       9                                                               ;
localparam                              BW_WGT_COMP_EXP             =       2                                                               ;
localparam  [06-1:00]                   IDX_REMAP_MUCB              =       0                                                               ;
localparam  [06-1:00]                   IDX_REMAP_SUCB              =       1                                                               ;
localparam  [06-1:00]                   IDX_REMAP_WPREDEF           =       2                                                               ;
localparam                              NUM_LAYER_R1                =       1                                                               ;
localparam                              NUM_LAYER_R2                =       2                                                               ;
localparam                              NUM_LAYER_R3                =       3                                                               ;
localparam                              NUM_LAYER_R4                =       4                                                               ;
localparam                              DLY_SYNC                    =       5'd20                                                           ;
localparam                              DLY_WGT_RD                  =       2                                                               ;
localparam                              DLY_IN                      =       5                                                               ;
localparam                              DLY_BUF_SYNC                =       2                                                               ;
localparam                              DLY_NLAYER                  =       7                                                               ;
localparam                              DLY_MURE_EN                 =       14                                                              ;
localparam                              NUM_BFCB_PORT8_R1           =       256                                                             ;
localparam                              NUM_BFCB_PORT8_R2           =       512                                                             ;
localparam                              NUM_BFCB_PORT8_R3           =       384                                                             ;
localparam                              NUM_BFCB_PORT8_R4           =       384                                                             ;
localparam                              NUM_BFCB_PORT4_R1           =       32                                                              ;
localparam                              NUM_BFCB_PORT4_R2           =       32                                                              ;
localparam                              NUM_BFCB_PORT4_R3           =       16                                                              ;
localparam                              NUM_BFCB_PORT4_R4           =       16                                                              ;
`ifndef DLFE_MU_MIMO_DISABLE
localparam                              NUM_MUW                     =       136                                                             ;
`else// DLFE_MU_MIMO_DISABLE
localparam                              NUM_MUW                     =       0                                                               ;
`endif// DLFE_MU_MIMO_DISABLE
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK01                  =       0                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK02                  =       1                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK03                  =       2                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK04                  =       3                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER00                 =       0                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER01                 =       1                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER02                 =       2                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER03                 =       3                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER04                 =       4                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER05                 =       5                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER06                 =       6                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER07                 =       7                                                               ;
localparam                              NUM_CBIDX                   =       2592                                                            ;
localparam                              NUM_PREDEF_BEAM             =       62                                                              ;
localparam  [20-1:00]                   SUCB_START_ADDR             =       BFCB_ADDR_OFFSET                                                ;
localparam  [20-1:00]                   SUCB_END_ADDR               =       BFCB_ADDR_OFFSET+NUM_CBIDX*4                                    ;
localparam  [20-1:00]                   PREDEFW_START_ADDR          =       ADDR_OFFSET+20'h08008                                           ;
localparam  [20-1:00]                   PREDEFW_END_ADDR            =       PREDEFW_START_ADDR+NUM_PREDEF_BEAM*4                            ;
localparam  [20-1:00]                   BFCB0_R1_L0_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB0_R2_L0_START_ADDR      =       BFCB0_R1_L0_START_ADDR+NUM_BFCB_PORT8_R1+NUM_BFCB_PORT4_R1      ;
localparam  [20-1:00]                   BFCB0_R3_L0_START_ADDR      =       BFCB0_R2_L0_START_ADDR+NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2      ;
localparam  [20-1:00]                   BFCB0_R4_L0_START_ADDR      =       BFCB0_R3_L0_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB0_PD_L0_START_ADDR      =       BFCB0_R4_L0_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB0_MU_L0_START_ADDR      =       BFCB0_PD_L0_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB0_R2_L1_START_ADDR      =       BFCB0_MU_L0_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB0_R3_L1_START_ADDR      =       BFCB0_R2_L1_START_ADDR+NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2      ;
localparam  [20-1:00]                   BFCB0_R4_L1_START_ADDR      =       BFCB0_R3_L1_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB0_PD_L1_START_ADDR      =       BFCB0_R4_L1_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB0_MU_L1_START_ADDR      =       BFCB0_PD_L1_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB0_END_ADDR              =       BFCB0_MU_L1_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB1_R3_L2_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB1_R4_L2_START_ADDR      =       BFCB1_R3_L2_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB1_PD_L2_START_ADDR      =       BFCB1_R4_L2_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB1_MU_L2_START_ADDR      =       BFCB1_PD_L2_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB1_R4_L3_START_ADDR      =       BFCB1_MU_L2_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB1_PD_L3_START_ADDR      =       BFCB1_R4_L3_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB1_MU_L3_START_ADDR      =       BFCB1_PD_L3_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB1_END_ADDR              =       BFCB1_MU_L3_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB2_PD_L4_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB2_MU_L4_START_ADDR      =       BFCB2_PD_L4_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB2_PD_L5_START_ADDR      =       BFCB2_MU_L4_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB2_MU_L5_START_ADDR      =       BFCB2_PD_L5_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB2_END_ADDR              =       BFCB2_MU_L5_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB3_PD_L6_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB3_MU_L6_START_ADDR      =       BFCB3_PD_L6_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB3_PD_L7_START_ADDR      =       BFCB3_MU_L6_START_ADDR+NUM_MUW                                  ;
localparam  [20-1:00]                   BFCB3_MU_L7_START_ADDR      =       BFCB3_PD_L7_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB3_END_ADDR              =       BFCB3_MU_L7_START_ADDR+NUM_MUW                                  ;
localparam                              BW_MEM_DATA                 =       72                                                              ;
localparam  integer                     NUM_BFCB_MEM                =       $ceil((2.0*BW_WGT*NUM_ANT)/BW_MEM_DATA)                         ;
localparam                              BW_BFCB_MEM_DATA            =       BW_MEM_DATA*NUM_BFCB_MEM                                        ;
localparam                              DEPTH_BFMEM0                =       NUM_BFCB_PORT8_R1+NUM_BFCB_PORT4_R1+(NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4+NUM_PREDEF_BEAM+NUM_MUW)*2 ;
localparam                              DEPTH_BFMEM1                =       NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3+(NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4+NUM_PREDEF_BEAM+NUM_MUW)*2 ;
localparam                              DEPTH_BFMEM2                =       (NUM_PREDEF_BEAM+NUM_MUW)*2                                     ;
localparam                              DEPTH_BFMEM3                =       (NUM_PREDEF_BEAM+NUM_MUW)*2                                     ;
localparam  [20-1:00]                   NPREDEFL_START_ADDR         =       ADDR_OFFSET+'h3000                                              ;
localparam  [20-1:00]                   NPREDEFL_END_ADDR           =       NPREDEFL_START_ADDR+NUM_PREDEF_BEAM*4                           ;
localparam  [2*BW_WGT-1:00]             BYPASS_BFW_CALS             =      'h100000                                                         ;
localparam  [05-1:00]                   NLAYER_CALS                 =      'h1                                                              ;
`endif //DLFE_ORAN_DISABLE

//Logic Variable
integer i ;
genvar gidx ;

`ifndef DLFE_ORAN_DISABLE
`else //DLFE_ORAN_DISABLE
reg [01-1:0] r_cpu_wren   ;
reg [01-1:0] r_cpu_rden   ;
reg [20-1:0] r_cpu_addr   ;
reg [32-1:0] r_cpu_wdata  ;
always@(*) begin
    r_cpu_wren   =  i_cpu_wren   [CC_REF]  ;
    r_cpu_rden   =  i_cpu_rden   [CC_REF]  ;
    r_cpu_addr   =  i_cpu_addr   [((20)*(CC_REF+1)-1)-:(20)] ;
    r_cpu_wdata  =  i_cpu_wdata  [((32)*(CC_REF+1)-1)-:(32)] ;
end
reg [01-1:0] r_cals_cal_en  ;
always@(posedge i_clk) begin
    r_cals_cal_en <= |i_cals_cal_en ;
end
reg [01*NUM_LAYER_LANE-1:0] r_en [NUM_LANE_CC-1:0][DLY_IN:0] ;
reg [2*DI_BW-1:0]           r_iq [NUM_LANE_CC-1:0][DLY_IN:0] ;   
generate for(gidx=0;gidx<NUM_LANE_CC;gidx=gidx+1) begin : g00_din_lane
`ifndef DLFE_AIE_DISABLE
always@(*) begin
    r_en[gidx][0] = r_cals_cal_en ? {{NUM_LAYER_LANE}{|i_cals_pat_en}} : i_din_en [((01*NUM_LAYER_LANE)*(gidx+1)-1)-:(01*NUM_LAYER_LANE)] ;
    if(gidx==0) begin
        r_iq[gidx][0] = r_cals_cal_en ?  i_cals_pat_iq : i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
    end
    else begin
        r_iq[gidx][0] = r_cals_cal_en ? {{2*DI_BW}{1'b0}} : i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
    end
end
`else //DLFE_AIE_DISABLE
always@(*) begin
    r_en[gidx][0] = i_din_en [((01*NUM_LAYER_LANE)*(gidx+1)-1)-:(01*NUM_LAYER_LANE)] ;
    r_iq[gidx][0] = i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
end
`endif //DLFE_AIE_DISABLE
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1] ;
        if(r_en[gidx][i-1]) begin
            r_iq[gidx][i] <= r_iq[gidx][i-1] ;
        end
    end
end
end
endgenerate
reg [$clog2(NUM_LAYER)-1:0] r_lyr_buf_sel   ;
reg [$clog2(NUM_ANT  )-1:0] r_ant_buf_sel   ;
reg [$clog2(NUM_LAYER)-1:0] r_rank_buf_sel  ;
always@(*) begin
    r_lyr_buf_sel  = i_dlfe_par_3c00 [(($clog2(NUM_LAYER))*(CC_REF+1)-1)-:($clog2(NUM_LAYER))] ;
    r_ant_buf_sel  = i_dlfe_par_3c04 [(($clog2(NUM_ANT  ))*(CC_REF+1)-1)-:($clog2(NUM_ANT  ))] ;
    r_rank_buf_sel = i_dlfe_par_3c08 [(($clog2(NUM_LAYER))*(CC_REF+1)-1)-:($clog2(NUM_LAYER))] ;
end
reg [12-1:0]    r_cb_idx    [DLY_IN:0]  ;   
reg [05-1:0]    r_nmusul    [DLY_IN:0]  ;   
reg [06-1:0]    r_re_map    [DLY_IN:0]  ;   
reg [09-1:0]    r_muw_idx   [DLY_IN:0]  ;   
always@(*) begin
    r_cb_idx [0] = i_din_cb_idx  ;
    r_nmusul [0] = i_din_nmusul  ;
    r_re_map [0] = i_din_re_map  ;
    r_muw_idx[0] = i_din_muw_idx ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        if(r_en[LANE_REF][i-1]) begin
            r_cb_idx [i] <= r_cb_idx [i-1] ;
            r_nmusul [i] <= r_nmusul [i-1] ;
            r_re_map [i] <= r_re_map [i-1] ;
            r_muw_idx[i] <= r_muw_idx[i-1] ;
        end
    end
end
`ifndef DLFE_AIE_DISABLE
reg [NUM_ANT-1:0] r_cals_pat_en ;
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_cals_pat_en <= {{NUM_ANT}{1'b0}} ;
    end
    else if(r_cals_cal_en) begin
        for(i=0;i<NUM_ANT;i=i+1) begin
            if(i_cals_pat_en[i]) begin
                r_cals_pat_en[i] <= 1'b1 ;
            end
        end
    end
end
`endif //DLFE_AIE_DISABLE
`ifndef DLFE_MU_MIMO_DISABLE
reg [1-1:0]             r_muwg_en       ;
reg [2*BW_WGT-1:0]      r_muwg_iq       ;
reg [1-1:0]             rr_muwg_en      ;
reg [2*BW_WGT-1:0]      rr_muwg_iq      ;
always@(posedge i_clk) begin
    r_muwg_en <= i_muwg_en ;
    if(i_muwg_en) begin
        r_muwg_iq <= {i_muwg_i,i_muwg_q} ;
    end
end
always@(posedge i_clk) begin
    rr_muwg_en <= r_muwg_en ;
    if(r_muwg_en) begin
        rr_muwg_iq <= r_muwg_iq ;
    end
end
reg [$clog2(NUM_LAYER)-1:0] r_muwg_lyr ;
reg [$clog2(NUM_ANT  )-1:0] r_muwg_ant ;
reg [$clog2(NUM_MUW  )-1:0] r_muwg_rbg_idx ;
always@(posedge i_clk) begin
    if(i_muwg_en&~r_muwg_en) begin
        r_muwg_lyr      <= {{$clog2(NUM_LAYER)}{1'b0}}  ;
        r_muwg_ant      <= {{$clog2(NUM_ANT  )}{1'b0}}  ;
        r_muwg_rbg_idx  <= {{$clog2(NUM_MUW  )}{1'b0}}  ;
    end
    else if(r_muwg_en) begin
        if(r_muwg_rbg_idx==({{$clog2(NUM_MUW  )}{1'b1}}&NUM_MUW)-1'd1) begin
            r_muwg_rbg_idx  <= {{$clog2(NUM_MUW  )}{1'b0}} ;
            r_muwg_ant      <= r_muwg_ant + 1'b1 ;
            if(&r_muwg_ant) begin
                r_muwg_lyr  <= r_muwg_lyr + 1'b1 ;
            end
        end
        else begin
            r_muwg_rbg_idx  <= r_muwg_rbg_idx + 1'b1 ;
        end
    end
end
reg [20-1:0]            r_muwg_addr ;
reg [NUM_ANT-1:0]       r_muwg_wren     [NUM_LANE_CC-1:0] ;
reg [NUM_LANE_CC-1:0]   r_muwg_bfcb_en   ;
always@(posedge i_clk) begin
    if(r_muwg_en) begin
        r_muwg_wren[r_muwg_lyr[$clog2(NUM_LAYER)-1:1]] <= {{{NUM_ANT-1}{1'b0}},1'b1}<<r_muwg_ant ; 
        case(r_muwg_lyr) 
            IDX_LAYER00 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER00>>1) ; r_muwg_addr <= BFCB0_MU_L0_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER01 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER01>>1) ; r_muwg_addr <= BFCB0_MU_L1_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER02 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER02>>1) ; r_muwg_addr <= BFCB1_MU_L2_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER03 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER03>>1) ; r_muwg_addr <= BFCB1_MU_L3_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER04 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER04>>1) ; r_muwg_addr <= BFCB2_MU_L4_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER05 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER05>>1) ; r_muwg_addr <= BFCB2_MU_L5_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER06 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER06>>1) ; r_muwg_addr <= BFCB3_MU_L6_START_ADDR + r_muwg_rbg_idx ; end
            IDX_LAYER07 : begin r_muwg_bfcb_en <= {{{NUM_LANE_CC-1}{1'b0}},1'b1}<<(IDX_LAYER07>>1) ; r_muwg_addr <= BFCB3_MU_L7_START_ADDR + r_muwg_rbg_idx ; end
            default     : begin r_muwg_bfcb_en <= {{NUM_LANE_CC}{1'b0}} ; r_muwg_addr <= 20'd0 ; end
        endcase
    end
    else begin
        r_muwg_bfcb_en <= {{NUM_LANE_CC}{1'b0}} ;
    end
end
`endif// DLFE_MU_MIMO_DISABLE

`ifndef DLFE_SU_WGT_COMP_DISABLE 
wire [1-1:0]                w_wgt_wdata_comp_en     ;
wire [2*BW_WGT_COMP-1:0]    w_wgt_wdata_comp_iq     ;
wire [BW_WGT_COMP_EXP-1:0]  w_wgt_wdata_comp_exp    ;
wire [1-1:0]                w_cpu_comp_mux_wren     ;
ylib_iq_comp #(
    .DI_BW      (   BW_WGT              )
   ,.DO_BW      (   BW_WGT_COMP         )
   ,.BW_EXP     (   BW_WGT_COMP_EXP     ))
u00_wgt_comp
(
     .i_clk     (   i_clk                                                               )
    ,.i_in_en   (   r_cpu_wren&&(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) )
    ,.i_in_iq   (   {r_cpu_wdata[16+BW_WGT-1:16],r_cpu_wdata[00+BW_WGT-1:00]}           )
    ,.o_out_en  (   w_wgt_wdata_comp_en                                                 )
    ,.o_out_iq  (   w_wgt_wdata_comp_iq                                                 )
    ,.o_out_exp (   w_wgt_wdata_comp_exp                                                )
);
assign w_cpu_comp_mux_wren = w_wgt_wdata_comp_en ;
`else //DLFE_SU_WGT_COMP_DISABLE 
assign w_cpu_comp_mux_wren = r_cpu_wren&&(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) ;
`endif //DLFE_SU_WGT_COMP_DISABLE 

reg [2*BW_WGT-1:0]  r_wgt_wdata   ;
always@(posedge i_clk) begin
`ifndef DLFE_SU_WGT_COMP_DISABLE 
    if(w_wgt_wdata_comp_en) begin
        r_wgt_wdata <= {{{2*BW_WGT-2*BW_WGT_COMP-BW_WGT_COMP_EXP}{1'b0}},w_wgt_wdata_comp_exp,w_wgt_wdata_comp_iq};
    end
    else if(r_cpu_wren&&(!(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR))) begin
        r_wgt_wdata <= {r_cpu_wdata[16+BW_WGT-1:16],r_cpu_wdata[00+BW_WGT-1:00]};
    end
`else //DLFE_SU_WGT_COMP_DISABLE 
    if(r_cpu_wren) begin
        r_wgt_wdata <= {r_cpu_wdata[16+BW_WGT-1:16],r_cpu_wdata[00+BW_WGT-1:00]};
    end
`endif //DLFE_SU_WGT_COMP_DISABLE 
`ifndef DLFE_MU_MIMO_DISABLE
    else if(rr_muwg_en) begin
        r_wgt_wdata <= rr_muwg_iq ;
    end
`endif// DLFE_MU_MIMO_DISABLE
end
reg [NUM_ANT-1:0]   r_bfcb0_buf_cpu_wren    ;
reg [20-1:0]        r_bfcb0_buf_cpu_addr    ;
reg [1-1:0]         r_bfcb0_buf_cpu_rden    ;
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_en     ;
(* keep = "true" *) reg [20-1:0]        r_bfcb0_buf_addr   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_null   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_suen   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb0_buf_en     ;
reg [20-1:0]        r_bfcb0_buf_addr   ;
reg [1-1:0]         r_bfcb0_buf_null   ;
reg [1-1:0]         r_bfcb0_buf_suen   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb0_buf_cpu_rdata                   ;
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb0_buf_rdata                       ;
reg [2*BW_WGT-1:0]              rr_bfcb0_buf_rdata      [NUM_ANT-1:0]   ;
reg [2*BW_WGT-1:0]              rr_bfcb0_buf_cpu_rdata  [NUM_ANT-1:0]   ;
reg [1-1:0]                     rr_bfcb0_buf_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb0_buf_en                         ;
reg [1-1:0]                     rr_bfcb0_cpu_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb0_cpu_en                         ;
reg [1-1:0]                     rr_bfcb0_buf_zpen       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb0_buf_null                       ;
reg [1-1:0]                     rr_bfcb0_buf_decomp_en  [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb0_buf_suen                       ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb0_buf_byte_wren_byte              ;
always@(posedge i_clk) begin : l00_0_bfcb_mem_cpu
    if(w_cpu_comp_mux_wren||(r_cpu_rden&&r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR)) begin
        case({r_rank_buf_sel,r_lyr_buf_sel}) 
            {IDX_RANK01,IDX_LAYER00} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R1_L0_START_ADDR ; end 
            {IDX_RANK02,IDX_LAYER00} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R2_L0_START_ADDR ; end 
            {IDX_RANK03,IDX_LAYER00} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R3_L0_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER00} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R4_L0_START_ADDR ; end 
            {IDX_RANK02,IDX_LAYER01} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R2_L1_START_ADDR ; end 
            {IDX_RANK03,IDX_LAYER01} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R3_L1_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER01} : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R4_L1_START_ADDR ; end 
            default                  : begin r_bfcb0_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb0_buf_cpu_rden <= 1'b0 ; end 
        endcase
    end
    else if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        case(r_lyr_buf_sel) 
            IDX_LAYER00 : begin r_bfcb0_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB0_PD_L0_START_ADDR ; end 
            IDX_LAYER01 : begin r_bfcb0_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_cpu_rden <= r_cpu_rden ; r_bfcb0_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB0_PD_L1_START_ADDR ; end 
            default     : begin r_bfcb0_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb0_buf_cpu_rden <= 1'b0 ; end
        endcase
    end
`ifndef DLFE_MU_MIMO_DISABLE
    else if(r_muwg_bfcb_en[0]) begin
        r_bfcb0_buf_cpu_wren    <=  r_muwg_wren[0]  ;
        r_bfcb0_buf_cpu_addr    <=  r_muwg_addr     ;
        r_bfcb0_buf_cpu_rden    <=  1'd0            ;
    end
`endif// DLFE_MU_MIMO_DISABLE
    else begin
        r_bfcb0_buf_cpu_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb0_buf_cpu_rden    <=  1'b0 ;
    end
end
always@(posedge i_clk) begin : l00_1_bfcb_mem_ctrl
    if(|r_en[IDX_LANE00][0]) begin
        if(r_re_map[0]==IDX_REMAP_MUCB) begin
            r_bfcb0_buf_en      <=  1'b1 ;
            r_bfcb0_buf_suen    <=  1'd0 ;
            r_bfcb0_buf_null    <=  1'd0 ;
            if(r_en[IDX_LANE00][0][0]) begin
                r_bfcb0_buf_addr    <=  BFCB0_MU_L0_START_ADDR+r_muw_idx[0] ;
            end
            else begin
                r_bfcb0_buf_addr    <=  BFCB0_MU_L1_START_ADDR+r_muw_idx[0] ;
            end
        end
        else if(r_re_map[0]==IDX_REMAP_SUCB) begin
            r_bfcb0_buf_en      <=  1'b1 ;
            r_bfcb0_buf_suen    <=  1'd1 ;
            if(r_en[IDX_LANE00][0][0]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R1  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R1_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R2  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R2_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R3_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R4_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb0_buf_null <= 1'b1 ; end 
                endcase
            end
            else begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R2  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R2_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R3_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R4_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb0_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]<(IDX_REMAP_WPREDEF+NUM_PREDEF_BEAM)) begin
            r_bfcb0_buf_en      <=  1'b1 ;
            r_bfcb0_buf_suen    <=  1'd0 ;
            r_bfcb0_buf_null    <=  1'd0 ;
            if(r_en[IDX_LANE00][0][0]) begin
                r_bfcb0_buf_addr    <=  BFCB0_PD_L0_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else begin
                r_bfcb0_buf_addr    <=  BFCB0_PD_L1_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
        else begin
            r_bfcb0_buf_en      <=   1'd0 ;
            r_bfcb0_buf_suen    <=   1'd0 ;
            r_bfcb0_buf_null    <=   1'd0 ;
        end
    end
    else begin
        r_bfcb0_buf_en      <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb0_buf_byte_wren_byte[i] = r_bfcb0_buf_cpu_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb0_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_tdpram #(
    .ADDR_WIDTH_A            ($clog2(DEPTH_BFMEM0)          ) 
   ,.ADDR_WIDTH_B            ($clog2(DEPTH_BFMEM0)          ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(DEPTH_BFMEM0))   )
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_A       (BW_BFCB_MEM_DATA              ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_A          (3                             ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_A      ("0"                           ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_DATA_WIDTH_B      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_A            ("no_change"                   ) 
   ,.WRITE_MODE_B            ("no_change"                   ) 
)
u01_0_bfcb_mem (
    .dbiterra           (                                                                                   )
   ,.dbiterrb           (                                                                                   )
   ,.douta              (   w_bfcb0_buf_cpu_rdata                                                           )
   ,.doutb              (   w_bfcb0_buf_rdata                                                               )
   ,.sbiterra           (                                                                                   )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb0_buf_cpu_addr [$clog2(DEPTH_BFMEM0)-1:0]                                 )
   ,.addrb              (   r_bfcb0_buf_addr     [$clog2(DEPTH_BFMEM0)-1:0]                                 )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_wgt_wdata}}}            )
   ,.dinb               (  {{BW_BFCB_MEM_DATA}{1'b0}}                                                       )
   ,.ena                (  |r_bfcb0_buf_byte_wren_byte | r_bfcb0_buf_cpu_rden                               )
   ,.enb                (   r_bfcb0_buf_en                                                                  )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectdbiterrb     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.injectsbiterrb     (   1'b0                                                                            )
   ,.regcea             (   1'b1                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rsta               (   i_rst                                                                           )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb0_buf_byte_wren_byte                                                      )
   ,.web                (   1'b0                                                                            )
);
always@(posedge i_clk) begin
    rr_bfcb0_buf_en     <= r_bfcb0_buf_en       ;
    rr_bfcb0_buf_null   <= r_bfcb0_buf_null     ;
    rr_bfcb0_cpu_en     <= r_bfcb0_buf_cpu_rden ;
    rr_bfcb0_buf_suen   <= r_bfcb0_buf_suen     ;
end
always@(*) begin
    rr_bfcb0_buf_rden       [0] = rr_bfcb0_buf_en     ;
    rr_bfcb0_buf_zpen       [0] = rr_bfcb0_buf_null   ;
    rr_bfcb0_cpu_rden       [0] = rr_bfcb0_cpu_en     ;
    rr_bfcb0_buf_decomp_en  [0] = rr_bfcb0_buf_suen   ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb0_buf_cpu_rdata[i] = w_bfcb0_buf_cpu_rdata   [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
        rr_bfcb0_buf_rdata    [i] = w_bfcb0_buf_rdata       [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb0_buf_rden       [i] <= rr_bfcb0_buf_rden       [i-1] ;
        rr_bfcb0_buf_zpen       [i] <= rr_bfcb0_buf_zpen       [i-1] ;
        rr_bfcb0_cpu_rden       [i] <= rr_bfcb0_cpu_rden       [i-1] ;
        rr_bfcb0_buf_decomp_en  [i] <= rr_bfcb0_buf_decomp_en  [i-1] ;
    end
end

reg [NUM_ANT-1:0]   r_bfcb1_buf_cpu_wren    ;
reg [20-1:0]        r_bfcb1_buf_cpu_addr    ;
reg [1-1:0]         r_bfcb1_buf_cpu_rden    ;
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_en     ;
(* keep = "true" *) reg [20-1:0]        r_bfcb1_buf_addr   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_null   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_suen   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb1_buf_en     ;
reg [20-1:0]        r_bfcb1_buf_addr   ;
reg [1-1:0]         r_bfcb1_buf_null   ;
reg [1-1:0]         r_bfcb1_buf_suen   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb1_buf_cpu_rdata                   ;
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb1_buf_rdata                       ;
reg [2*BW_WGT-1:0]              rr_bfcb1_buf_rdata      [NUM_ANT-1:0]   ;
reg [2*BW_WGT-1:0]              rr_bfcb1_buf_cpu_rdata  [NUM_ANT-1:0]   ;
reg [1-1:0]                     rr_bfcb1_buf_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb1_buf_en                         ;
reg [1-1:0]                     rr_bfcb1_cpu_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb1_cpu_en                         ;
reg [1-1:0]                     rr_bfcb1_buf_zpen       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb1_buf_null                       ;
reg [1-1:0]                     rr_bfcb1_buf_decomp_en  [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb1_buf_suen                       ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb1_buf_byte_wren_byte              ;
always@(posedge i_clk) begin : l01_0_bfcb_mem_cpu
    if(w_cpu_comp_mux_wren||(r_cpu_rden&&r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR)) begin
        case({r_rank_buf_sel,r_lyr_buf_sel}) 
            {IDX_RANK03,IDX_LAYER02} : begin r_bfcb1_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb1_buf_cpu_rden <= r_cpu_rden ; r_bfcb1_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R3_L2_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER02} : begin r_bfcb1_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb1_buf_cpu_rden <= r_cpu_rden ; r_bfcb1_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R4_L2_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER03} : begin r_bfcb1_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},w_cpu_comp_mux_wren}<<r_ant_buf_sel ; r_bfcb1_buf_cpu_rden <= r_cpu_rden ; r_bfcb1_buf_cpu_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R4_L3_START_ADDR ; end 
            default                  : begin r_bfcb1_buf_cpu_wren <=  {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb1_buf_cpu_rden <= 1'b0 ; end 
        endcase
    end
    else if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        case(r_lyr_buf_sel) 
            IDX_LAYER02 : begin r_bfcb1_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_cpu_rden <= r_cpu_rden ; r_bfcb1_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB1_PD_L2_START_ADDR ; end 
            IDX_LAYER03 : begin r_bfcb1_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_cpu_rden <= r_cpu_rden ; r_bfcb1_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB1_PD_L3_START_ADDR ; end 
            default     : begin r_bfcb1_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb1_buf_cpu_rden <= 1'b0 ; end
        endcase
    end
`ifndef DLFE_MU_MIMO_DISABLE
    else if(r_muwg_bfcb_en[1]) begin
        r_bfcb1_buf_cpu_wren    <=  r_muwg_wren[1]  ;
        r_bfcb1_buf_cpu_addr    <=  r_muwg_addr     ;
        r_bfcb1_buf_cpu_rden    <=  1'd0            ;
    end
`endif// DLFE_MU_MIMO_DISABLE
    else begin
        r_bfcb1_buf_cpu_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb1_buf_cpu_rden    <=  1'b0 ;
    end
end
always@(posedge i_clk) begin : l01_1_bfcb_mem_ctrl
    if(|r_en[IDX_LANE01][0]) begin
        if(r_re_map[0]==IDX_REMAP_MUCB) begin
            r_bfcb1_buf_en      <=  1'b1 ;
            r_bfcb1_buf_suen    <=  1'd0 ;
            r_bfcb1_buf_null    <=  1'd0 ;
            if(r_en[IDX_LANE01][0][0]) begin
                r_bfcb1_buf_addr    <=  BFCB1_MU_L2_START_ADDR+r_muw_idx[0] ;
            end
            else begin
                r_bfcb1_buf_addr    <=  BFCB1_MU_L3_START_ADDR+r_muw_idx[0] ;
            end
        end
        else if(r_re_map[0]==IDX_REMAP_SUCB) begin
            r_bfcb1_buf_en      <=  1'b1 ;
            r_bfcb1_buf_suen    <=  1'd1 ;
            if(r_en[IDX_LANE01][0][0]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R3_L2_START_ADDR+{4'd0,r_cb_idx[0]} ; end  
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R4_L2_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb1_buf_null <= 1'b1 ; end
                endcase
            end
            else begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R4_L3_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb1_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]<(IDX_REMAP_WPREDEF+NUM_PREDEF_BEAM)) begin
            r_bfcb1_buf_en      <=  1'b1 ;
            r_bfcb1_buf_suen    <=  1'd0 ;
            r_bfcb1_buf_null    <=  1'b0 ;
            if(r_en[IDX_LANE01][0][0]) begin
                r_bfcb1_buf_addr    <=  BFCB1_PD_L2_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else begin
                r_bfcb1_buf_addr    <=  BFCB1_PD_L3_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
        else begin
            r_bfcb1_buf_en      <=  1'b0 ;
            r_bfcb1_buf_suen    <=  1'b0 ;
            r_bfcb1_buf_null    <=  1'b0 ;
        end
    end
    else begin
        r_bfcb1_buf_en      <=  1'b0 ;
        r_bfcb1_buf_null    <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb1_buf_byte_wren_byte[i] = r_bfcb1_buf_cpu_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb1_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_tdpram #(
    .ADDR_WIDTH_A            ($clog2(DEPTH_BFMEM1)          ) 
   ,.ADDR_WIDTH_B            ($clog2(DEPTH_BFMEM1)          ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(DEPTH_BFMEM1))   )
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_A       (BW_BFCB_MEM_DATA              ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_A          (3                             ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_A      ("0"                           ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_DATA_WIDTH_B      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_A            ("no_change"                   ) 
   ,.WRITE_MODE_B            ("no_change"                   ) 
)
u01_1_bfcb_mem (
    .dbiterra           (                                                                                   )
   ,.dbiterrb           (                                                                                   )
   ,.douta              (   w_bfcb1_buf_cpu_rdata                                                           )
   ,.doutb              (   w_bfcb1_buf_rdata                                                               )
   ,.sbiterra           (                                                                                   )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb1_buf_cpu_addr [$clog2(DEPTH_BFMEM1)-1:0]                                 )
   ,.addrb              (   r_bfcb1_buf_addr     [$clog2(DEPTH_BFMEM1)-1:0]                                 )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_wgt_wdata}}}            )
   ,.dinb               (  {{BW_BFCB_MEM_DATA}{1'b0}}                                                       )
   ,.ena                (  |r_bfcb1_buf_byte_wren_byte | r_bfcb1_buf_cpu_rden                               )
   ,.enb                (   r_bfcb1_buf_en                                                                  )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectdbiterrb     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.injectsbiterrb     (   1'b0                                                                            )
   ,.regcea             (   1'b1                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rsta               (   i_rst                                                                           )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb1_buf_byte_wren_byte                                                      )
   ,.web                (   1'b0                                                                            )
);
always@(posedge i_clk) begin
    rr_bfcb1_buf_en     <= r_bfcb1_buf_en       ;
    rr_bfcb1_buf_null   <= r_bfcb1_buf_null     ;
    rr_bfcb1_cpu_en     <= r_bfcb1_buf_cpu_rden ;
    rr_bfcb1_buf_suen   <= r_bfcb1_buf_suen     ;
end
always@(*) begin
    rr_bfcb1_buf_rden       [0] = rr_bfcb1_buf_en     ;
    rr_bfcb1_buf_zpen       [0] = rr_bfcb1_buf_null   ;
    rr_bfcb1_cpu_rden       [0] = rr_bfcb1_cpu_en     ;
    rr_bfcb1_buf_decomp_en  [0] = rr_bfcb1_buf_suen   ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb1_buf_cpu_rdata[i] = w_bfcb1_buf_cpu_rdata   [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
        rr_bfcb1_buf_rdata    [i] = w_bfcb1_buf_rdata       [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb1_buf_rden       [i] <= rr_bfcb1_buf_rden       [i-1] ;
        rr_bfcb1_buf_zpen       [i] <= rr_bfcb1_buf_zpen       [i-1] ;
        rr_bfcb1_cpu_rden       [i] <= rr_bfcb1_cpu_rden       [i-1] ;
        rr_bfcb1_buf_decomp_en  [i] <= rr_bfcb1_buf_decomp_en  [i-1] ;
    end
end

reg [NUM_ANT-1:0]   r_bfcb2_buf_cpu_wren   ;
reg [20-1:0]        r_bfcb2_buf_cpu_addr   ;
reg [1-1:0]         r_bfcb2_buf_cpu_rden   ;
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb2_buf_en     ;
(* keep = "true" *) reg [20-1:0]        r_bfcb2_buf_addr   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb2_buf_null   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb2_buf_suen   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb2_buf_en     ;
reg [20-1:0]        r_bfcb2_buf_addr   ;
reg [1-1:0]         r_bfcb2_buf_null   ;
reg [1-1:0]         r_bfcb2_buf_suen   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb2_buf_cpu_rdata                   ;
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb2_buf_rdata                       ;
reg [2*BW_WGT-1:0]              rr_bfcb2_buf_rdata      [NUM_ANT-1:0]   ;
reg [2*BW_WGT-1:0]              rr_bfcb2_buf_cpu_rdata  [NUM_ANT-1:0]   ;
reg [1-1:0]                     rr_bfcb2_buf_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb2_buf_en                         ;
reg [1-1:0]                     rr_bfcb2_cpu_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb2_cpu_en                         ;
reg [1-1:0]                     rr_bfcb2_buf_zpen       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb2_buf_null                       ;
reg [1-1:0]                     rr_bfcb2_buf_decomp_en  [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb2_buf_suen                       ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb2_buf_byte_wren_byte              ;
`ifdef DLFE_LAYER_NUM_008
always@(posedge i_clk) begin : l02_0_bfcb_mem_cpu
    if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        case(r_lyr_buf_sel) 
            IDX_LAYER04 : begin r_bfcb2_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb2_buf_cpu_rden <= r_cpu_rden ; r_bfcb2_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB2_PD_L4_START_ADDR ; end 
            IDX_LAYER05 : begin r_bfcb2_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb2_buf_cpu_rden <= r_cpu_rden ; r_bfcb2_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB2_PD_L5_START_ADDR ; end 
            default     : begin r_bfcb2_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb2_buf_cpu_rden <= 1'b0 ; end
        endcase
    end
`ifndef DLFE_MU_MIMO_DISABLE
    else if(r_muwg_bfcb_en[2]) begin
        r_bfcb2_buf_cpu_wren    <=  r_muwg_wren[2]  ;
        r_bfcb2_buf_cpu_addr    <=  r_muwg_addr     ;
        r_bfcb2_buf_cpu_rden    <=  1'd0            ;
    end
`endif// DLFE_MU_MIMO_DISABLE
    else begin
        r_bfcb2_buf_cpu_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb2_buf_cpu_rden    <=  1'b0 ;
    end
end
always@(posedge i_clk) begin : l02_1_bfcb_mem_ctrl
    if(|r_en[IDX_LANE02][0]) begin
        if(r_re_map[0]==IDX_REMAP_MUCB) begin
            r_bfcb2_buf_en      <=  1'b1 ;
            r_bfcb2_buf_suen    <=  1'd0 ;
            r_bfcb2_buf_null    <=  1'b0 ;
            if(r_en[IDX_LANE02][0][0]) begin
                r_bfcb2_buf_addr    <=  BFCB2_MU_L4_START_ADDR+r_muw_idx[0] ;
            end
            else begin
                r_bfcb2_buf_addr    <=  BFCB2_MU_L5_START_ADDR+r_muw_idx[0] ;
            end
        end
        else if(r_re_map[0]==IDX_REMAP_SUCB) begin
            r_bfcb2_buf_en      <=  1'b1 ;
            r_bfcb2_buf_suen    <=  1'd1 ;
            if(r_en[IDX_LANE02][0][0]) begin
                case(r_nmusul[0]) 
                    default : begin r_bfcb2_buf_null <= 1'b1 ; end
                endcase
            end
            else begin
                case(r_nmusul[0]) 
                    default : begin r_bfcb2_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]<(IDX_REMAP_WPREDEF+NUM_PREDEF_BEAM)) begin
            r_bfcb2_buf_en      <=  1'b1 ;
            r_bfcb2_buf_suen    <=  1'd0 ;
            r_bfcb2_buf_null    <=  1'b0 ;
            if(r_en[IDX_LANE02][0][0]) begin
                r_bfcb2_buf_addr    <=  BFCB2_PD_L4_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else begin
                r_bfcb2_buf_addr    <=  BFCB2_PD_L5_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
        else begin
            r_bfcb2_buf_en      <=  1'b0 ;
            r_bfcb2_buf_suen    <=  1'b0 ;
            r_bfcb2_buf_null    <=  1'b0 ;
        end
    end
    else begin
        r_bfcb2_buf_en      <=  1'b0 ;
        r_bfcb2_buf_suen    <=  1'b0 ;
        r_bfcb2_buf_null    <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb2_buf_byte_wren_byte[i] = r_bfcb2_buf_cpu_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb2_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_tdpram #(
    .ADDR_WIDTH_A            ($clog2(DEPTH_BFMEM2)          ) 
   ,.ADDR_WIDTH_B            ($clog2(DEPTH_BFMEM2)          ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(DEPTH_BFMEM2))   )
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_A       (BW_BFCB_MEM_DATA              ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_A          (3                             ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_A      ("0"                           ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_DATA_WIDTH_B      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_A            ("no_change"                   ) 
   ,.WRITE_MODE_B            ("no_change"                   ) 
)
u01_2_bfcb_mem (
    .dbiterra           (                                                                                   )
   ,.dbiterrb           (                                                                                   )
   ,.douta              (   w_bfcb2_buf_cpu_rdata                                                           )
   ,.doutb              (   w_bfcb2_buf_rdata                                                               )
   ,.sbiterra           (                                                                                   )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb2_buf_cpu_addr [$clog2(DEPTH_BFMEM2)-1:0]                                 )
   ,.addrb              (   r_bfcb2_buf_addr     [$clog2(DEPTH_BFMEM2)-1:0]                                 )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_wgt_wdata}}}            )
   ,.dinb               (  {{BW_BFCB_MEM_DATA}{1'b0}}                                                       )
   ,.ena                (  |r_bfcb2_buf_byte_wren_byte | r_bfcb2_buf_cpu_rden                               )
   ,.enb                (   r_bfcb2_buf_en                                                                  )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectdbiterrb     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.injectsbiterrb     (   1'b0                                                                            )
   ,.regcea             (   1'b1                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rsta               (   i_rst                                                                           )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb2_buf_byte_wren_byte                                                      )
   ,.web                (   1'b0                                                                            )
);
always@(posedge i_clk) begin
    rr_bfcb2_buf_en     <= r_bfcb2_buf_en       ;
    rr_bfcb2_buf_null   <= r_bfcb2_buf_null     ;
    rr_bfcb2_cpu_en     <= r_bfcb2_buf_cpu_rden ;
end
always@(*) begin
    rr_bfcb2_buf_rden [0] = rr_bfcb2_buf_en     ;
    rr_bfcb2_buf_zpen [0] = rr_bfcb2_buf_null   ;
    rr_bfcb2_cpu_rden [0] = rr_bfcb2_cpu_en     ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb2_buf_cpu_rdata[i] = w_bfcb2_buf_cpu_rdata   [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
        rr_bfcb2_buf_rdata    [i] = w_bfcb2_buf_rdata       [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb2_buf_rden[i] <= rr_bfcb2_buf_rden[i-1] ;
        rr_bfcb2_buf_zpen[i] <= rr_bfcb2_buf_zpen[i-1] ;
        rr_bfcb2_cpu_rden[i] <= rr_bfcb2_cpu_rden[i-1] ;
    end
end
`endif //DLFE_LAYER_NUM_008

reg [NUM_ANT-1:0]   r_bfcb3_buf_cpu_wren   ;
reg [20-1:0]        r_bfcb3_buf_cpu_addr   ;
reg [1-1:0]         r_bfcb3_buf_cpu_rden   ;
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb3_buf_en     ;
(* keep = "true" *) reg [20-1:0]        r_bfcb3_buf_addr   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb3_buf_null   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb3_buf_suen   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb3_buf_en     ;
reg [20-1:0]        r_bfcb3_buf_addr   ;
reg [1-1:0]         r_bfcb3_buf_null   ;
reg [1-1:0]         r_bfcb3_buf_suen   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb3_buf_cpu_rdata                   ;
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb3_buf_rdata                       ;
reg [2*BW_WGT-1:0]              rr_bfcb3_buf_rdata      [NUM_ANT-1:0]   ;
reg [2*BW_WGT-1:0]              rr_bfcb3_buf_cpu_rdata  [NUM_ANT-1:0]   ;
reg [1-1:0]                     rr_bfcb3_buf_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb3_buf_en                         ;
reg [1-1:0]                     rr_bfcb3_cpu_rden       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb3_cpu_en                         ;
reg [1-1:0]                     rr_bfcb3_buf_zpen       [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb3_buf_null                       ;
reg [1-1:0]                     rr_bfcb3_buf_decomp_en  [DLY_WGT_RD:0]  ;
reg [1-1:0]                     rr_bfcb3_buf_suen                       ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb3_buf_byte_wren_byte              ;
`ifdef DLFE_LAYER_NUM_008
always@(posedge i_clk) begin : l03_0_bfcb_mem_cpu
    if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        case(r_lyr_buf_sel) 
            IDX_LAYER06 : begin r_bfcb3_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb3_buf_cpu_rden <= r_cpu_rden ; r_bfcb3_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB3_PD_L6_START_ADDR ; end 
            IDX_LAYER07 : begin r_bfcb3_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb3_buf_cpu_rden <= r_cpu_rden ; r_bfcb3_buf_cpu_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB3_PD_L7_START_ADDR ; end 
            default     : begin r_bfcb3_buf_cpu_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb3_buf_cpu_rden <= 1'b0 ; end
        endcase
    end
`ifndef DLFE_MU_MIMO_DISABLE
    else if(r_muwg_bfcb_en[3]) begin
        r_bfcb3_buf_cpu_wren    <=  r_muwg_wren[3]  ;
        r_bfcb3_buf_cpu_addr    <=  r_muwg_addr     ;
        r_bfcb3_buf_cpu_rden    <=  1'd0            ;
    end
`endif// DLFE_MU_MIMO_DISABLE
    else begin
        r_bfcb3_buf_cpu_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb3_buf_cpu_rden    <=  1'b0 ;
    end
end
always@(posedge i_clk) begin : l03_1_bfcb_mem_ctrl
    if(|r_en[IDX_LANE03][0]) begin
        if(r_re_map[0]==IDX_REMAP_MUCB) begin
            r_bfcb3_buf_en      <=  1'b1 ;
            r_bfcb3_buf_suen    <=  1'd0 ;
            r_bfcb3_buf_null    <=  1'd0 ;
            if(r_en[IDX_LANE03][0][0]) begin
                r_bfcb3_buf_addr    <=  BFCB3_MU_L6_START_ADDR+r_muw_idx[0] ;
            end
            else begin
                r_bfcb3_buf_addr    <=  BFCB3_MU_L7_START_ADDR+r_muw_idx[0] ;
            end
        end
        else if(r_re_map[0]==IDX_REMAP_SUCB) begin
            r_bfcb3_buf_en      <=  1'b1 ;
            r_bfcb3_buf_suen    <=  1'd1 ;
            if(r_en[IDX_LANE03][0][0]) begin
                case(r_nmusul[0]) 
                    default : begin r_bfcb3_buf_null <= 1'b1 ; end
                endcase
            end
            else begin
                case(r_nmusul[0]) 
                    default : begin r_bfcb3_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]<(IDX_REMAP_WPREDEF+NUM_PREDEF_BEAM)) begin
            r_bfcb3_buf_en      <=  1'b1 ;
            r_bfcb3_buf_suen    <=  1'd0 ;
            r_bfcb3_buf_null    <=  1'b0 ;
            if(r_en[IDX_LANE03][0][0]) begin
                r_bfcb3_buf_addr    <=  BFCB3_PD_L6_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else if(r_en[IDX_LANE03][0][1]) begin
                r_bfcb3_buf_addr    <=  BFCB3_PD_L7_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
        else begin
            r_bfcb3_buf_en      <=  1'b0 ;
            r_bfcb3_buf_suen    <=  1'd0 ;
            r_bfcb3_buf_null    <=  1'b0 ;
        end
    end
    else begin
        r_bfcb3_buf_en      <=  1'b0 ;
        r_bfcb3_buf_suen    <=  1'd0 ;
        r_bfcb3_buf_null    <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb3_buf_byte_wren_byte[i] = r_bfcb3_buf_cpu_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb3_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_tdpram #(
    .ADDR_WIDTH_A            ($clog2(DEPTH_BFMEM3)          ) 
   ,.ADDR_WIDTH_B            ($clog2(DEPTH_BFMEM3)          ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(DEPTH_BFMEM3))   )
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_A       (BW_BFCB_MEM_DATA              ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_A          (3                             ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_A      ("0"                           ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_DATA_WIDTH_B      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_A            ("no_change"                   ) 
   ,.WRITE_MODE_B            ("no_change"                   ) 
)
u01_3_bfcb_mem (
    .dbiterra           (                                                                                   )
   ,.dbiterrb           (                                                                                   )
   ,.douta              (   w_bfcb3_buf_cpu_rdata                                                           )
   ,.doutb              (   w_bfcb3_buf_rdata                                                               )
   ,.sbiterra           (                                                                                   )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb3_buf_cpu_addr [$clog2(DEPTH_BFMEM3)-1:0]                                 )
   ,.addrb              (   r_bfcb3_buf_addr     [$clog2(DEPTH_BFMEM3)-1:0]                                 )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_wgt_wdata}}}            )
   ,.dinb               (  {{BW_BFCB_MEM_DATA}{1'b0}}                                                       )
   ,.ena                (  |r_bfcb3_buf_byte_wren_byte | r_bfcb3_buf_cpu_rden                               )
   ,.enb                (   r_bfcb3_buf_en                                                                  )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectdbiterrb     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.injectsbiterrb     (   1'b0                                                                            )
   ,.regcea             (   1'b1                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rsta               (   i_rst                                                                           )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb3_buf_byte_wren_byte                                                      )
   ,.web                (   1'b0                                                                            )
);
always@(posedge i_clk) begin
    rr_bfcb3_buf_en     <= r_bfcb3_buf_en       ;
    rr_bfcb3_buf_null   <= r_bfcb3_buf_null     ;
    rr_bfcb3_cpu_en     <= r_bfcb3_buf_cpu_rden ;
end
always@(*) begin
    rr_bfcb3_buf_rden [0] = rr_bfcb3_buf_en     ;
    rr_bfcb3_buf_zpen [0] = rr_bfcb3_buf_null   ;
    rr_bfcb3_cpu_rden [0] = rr_bfcb3_cpu_en     ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb3_buf_cpu_rdata[i] = w_bfcb3_buf_cpu_rdata   [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
        rr_bfcb3_buf_rdata    [i] = w_bfcb3_buf_rdata       [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb3_buf_rden[i] <= rr_bfcb3_buf_rden[i-1] ;
        rr_bfcb3_buf_zpen[i] <= rr_bfcb3_buf_zpen[i-1] ;
        rr_bfcb3_cpu_rden[i] <= rr_bfcb3_cpu_rden[i-1] ;
    end
end
`endif //DLFE_LAYER_NUM_008

`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg     [01-1:0]    r_npredefl_en    ;
(* keep = "true" *) reg     [01-1:0]    r_npredefl_wren  ;
(* keep = "true" *) reg     [20-1:0]    r_npredefl_addr  ;
(* keep = "true" *) reg     [05-1:0]    r_npredefl_wdata ;
(* keep = "true" *) reg     [01-1:0]    r_npredefl_rden  ;
`else// DLFE_XILINX_VERSAL
reg     [01-1:0]    r_npredefl_en       ;
reg     [01-1:0]    r_npredefl_wren     ;
reg     [20-1:0]    r_npredefl_addr     ;
reg     [05-1:0]    r_npredefl_wdata    ;
reg     [01-1:0]    r_npredefl_rden     ;
`endif// DLFE_XILINX_VERSAL
reg     [01-1:0]    rr_npredefl_rden    ;
wire    [05-1:0]    w_npredefl_rdata    ;
always@(posedge i_clk) begin
    if(r_cpu_wren&&r_cpu_addr>=NPREDEFL_START_ADDR&&r_cpu_addr<=NPREDEFL_END_ADDR) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  r_cpu_wren ;
        r_npredefl_addr    <= (r_cpu_addr-NPREDEFL_START_ADDR)>>2 ; 
        r_npredefl_wdata   <=  r_cpu_wdata ;
        r_npredefl_rden    <=  1'd0 ;
    end
    else if(r_cpu_rden&&r_cpu_addr>=NPREDEFL_START_ADDR&&r_cpu_addr<=NPREDEFL_END_ADDR) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_addr    <= (r_cpu_addr-NPREDEFL_START_ADDR)>>2 ; 
        r_npredefl_rden    <=  r_cpu_rden ;
    end
    else if(|r_en[LANE_REF][DLY_IN-2]&&r_re_map[DLY_IN-2]>IDX_REMAP_SUCB) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_rden    <=  1'd0 ;
        r_npredefl_addr    <= {14'd0,(r_re_map[DLY_IN-2]-IDX_REMAP_WPREDEF)} ;  
    end
    else begin
        r_npredefl_en      <=  1'd0 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_rden    <=  1'd0 ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   5                           )
   ,.DEPTH  (   2**$clog2(NUM_PREDEF_BEAM)  )
   ,.VENDOR (   VENDOR                      )) 
u02_npredefl_mem (
    .clk    (   i_clk                                           )
   ,.we     (   r_npredefl_wren                                 )
   ,.en     (   r_npredefl_en                                   )
   ,.addr   (   r_npredefl_addr[$clog2(NUM_PREDEF_BEAM)-1:0]    )
   ,.di     (   r_npredefl_wdata                                )
   ,.dout   (   w_npredefl_rdata                                )
);
always@(posedge i_clk) begin
    rr_npredefl_rden   <=  r_npredefl_rden    ;
end

generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g01_bfw_cpu_rd
always@(posedge i_clk) begin
    if(rr_bfcb0_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb0_cpu_rden[DLY_WGT_RD] ;
`ifndef DLFE_SU_WGT_COMP_DISABLE 
        if(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]
                                                            ,{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]};
        end                             
        else begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
        end
`else //DLFE_SU_WGT_COMP_DISABLE 
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
`endif //DLFE_SU_WGT_COMP_DISABLE 
    end
    else if(rr_bfcb1_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb1_cpu_rden[DLY_WGT_RD] ;
`ifndef DLFE_SU_WGT_COMP_DISABLE 
        if(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]
                                                            ,{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]};
        end
        else begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
        end
`else //DLFE_SU_WGT_COMP_DISABLE 
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
`endif //DLFE_SU_WGT_COMP_DISABLE 
    end
    else if(rr_bfcb2_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb2_cpu_rden[DLY_WGT_RD] ;
`ifndef DLFE_SU_WGT_COMP_DISABLE 
        if(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]
                                                            ,{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]};
        end
        else begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
        end
`else //DLFE_SU_WGT_COMP_DISABLE 
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb2_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
`endif //DLFE_SU_WGT_COMP_DISABLE 
    end
    else if(rr_bfcb3_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb3_cpu_rden[DLY_WGT_RD] ;
`ifndef DLFE_SU_WGT_COMP_DISABLE 
        if(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR) begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]
                                                            ,{{{16-BW_WGT_COMP}{1'b0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]};
        end
        else begin
            o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
        end
`else //DLFE_SU_WGT_COMP_DISABLE 
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb3_buf_cpu_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
`endif //DLFE_SU_WGT_COMP_DISABLE 
    end
    else if(rr_npredefl_rden[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_npredefl_rden ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {27'd0,w_npredefl_rdata} ;
    end
    else begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  1'd0 ;
    end
end
end
endgenerate

reg [2*BW_WGT-1:0]    rr_bfcb_buf_rdata [NUM_LANE_CC-1:0][NUM_ANT-1:0]  ;
reg [NUM_LANE_CC-1:0] rr_bfcb_buf_rden   ;
reg [NUM_LANE_CC-1:0] rr_bfcb_buf_zpen   ;
reg [NUM_LANE_CC-1:0] rr_bfcb_buf_decomp_en   ;
always@(*) begin
    rr_bfcb_buf_rden  [0] = rr_bfcb0_buf_rden[DLY_WGT_RD] ;
    rr_bfcb_buf_rden  [1] = rr_bfcb1_buf_rden[DLY_WGT_RD] ;
    rr_bfcb_buf_rden  [2] = rr_bfcb2_buf_rden[DLY_WGT_RD] ;
    rr_bfcb_buf_rden  [3] = rr_bfcb3_buf_rden[DLY_WGT_RD] ;
    rr_bfcb_buf_zpen  [0] = rr_bfcb0_buf_zpen[DLY_WGT_RD] ;
    rr_bfcb_buf_zpen  [1] = rr_bfcb1_buf_zpen[DLY_WGT_RD] ;
    rr_bfcb_buf_zpen  [2] = rr_bfcb2_buf_zpen[DLY_WGT_RD] ;
    rr_bfcb_buf_zpen  [3] = rr_bfcb3_buf_zpen[DLY_WGT_RD] ;
    rr_bfcb_buf_decomp_en  [0] = rr_bfcb0_buf_decomp_en[DLY_WGT_RD] ;
    rr_bfcb_buf_decomp_en  [1] = rr_bfcb1_buf_decomp_en[DLY_WGT_RD] ;
    rr_bfcb_buf_decomp_en  [2] = rr_bfcb2_buf_decomp_en[DLY_WGT_RD] ;
    rr_bfcb_buf_decomp_en  [3] = rr_bfcb3_buf_decomp_en[DLY_WGT_RD] ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb_buf_rdata [0][i] = rr_bfcb0_buf_rdata[i] ;
        rr_bfcb_buf_rdata [1][i] = rr_bfcb1_buf_rdata[i] ;
        rr_bfcb_buf_rdata [2][i] = rr_bfcb2_buf_rdata[i] ;
        rr_bfcb_buf_rdata [3][i] = rr_bfcb3_buf_rdata[i] ;
    end
end
reg [2*BW_WGT-1:0]  r_mux_bfw_mat   [NUM_LANE_CC*NUM_ANT-1:0]    ;
generate for(gidx=0;gidx<NUM_LANE_CC*NUM_ANT;gidx=gidx+1) begin : g01_mux_bfw_mat
always@(posedge i_clk) begin
    if(|rr_bfcb_buf_rden) begin
        if(rr_bfcb_buf_rden[gidx/NUM_ANT]) begin
            if(rr_bfcb_buf_zpen[gidx/NUM_ANT]) begin
                r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
            end
`ifndef DLFE_SU_WGT_COMP_DISABLE 
            else if(rr_bfcb_buf_decomp_en[gidx/NUM_ANT]) begin
                r_mux_bfw_mat   [gidx]   <= {{{{BW_WGT-BW_WGT_COMP}{rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][2*BW_WGT_COMP-1]}},rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][(2*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]  
                                            ,{{{BW_WGT-BW_WGT_COMP}{rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][1*BW_WGT_COMP-1]}},rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][(1*BW_WGT_COMP-1)-:BW_WGT_COMP]}<<rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT][2*BW_WGT_COMP+BW_WGT_COMP_EXP-1:2*BW_WGT_COMP]} ;  
            end
`endif //DLFE_SU_WGT_COMP_DISABLE 
            else begin
                r_mux_bfw_mat   [gidx]   <= rr_bfcb_buf_rdata[gidx/NUM_ANT][gidx%NUM_ANT]  ;  
            end
        end
        else begin
            r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
        end
    end
end
end
endgenerate
reg [01-1:0]    r_nlayer_en ;
reg [05-1:0]    r_nlayer    ;
always@(posedge i_clk) begin
    r_nlayer_en <= |r_en[LANE_REF][DLY_IN]  ;
    if(|r_en[LANE_REF][DLY_IN]) begin
        if(r_cals_cal_en) begin
            r_nlayer <= NLAYER_CALS ;
        end
        else begin
            if(r_re_map[DLY_IN]>IDX_REMAP_SUCB) begin
                r_nlayer <=  w_npredefl_rdata ;
            end
            else begin
                r_nlayer <=  r_nmusul[DLY_IN]    ;
            end
        end
    end
end
reg [01-1:0] r_dly_nlayer_en [DLY_NLAYER:0]  ;
reg [05-1:0] r_dly_nlayer    [DLY_NLAYER:0]  ;
always@(*) begin
    r_dly_nlayer_en [0] = r_nlayer_en ;
    r_dly_nlayer    [0] = r_nlayer    ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_NLAYER;i=i+1) begin
        r_dly_nlayer_en[i] <= r_dly_nlayer_en[i-1] ;
        if(r_dly_nlayer_en[i-1]) begin
            r_dly_nlayer[i] <=  r_dly_nlayer[i-1] ;
        end
    end
end
reg [1-1:0]         r_isqrt_en  ;
reg [BW_ISQRT-1:0]  r_isqrt     ;
always@(posedge i_clk) begin
    r_isqrt_en <= r_dly_nlayer_en[DLY_NLAYER] ;
    if(r_dly_nlayer_en[DLY_NLAYER]) begin
        case(r_dly_nlayer[DLY_NLAYER]) 
            5'd1    :   r_isqrt <= 'd4096  ;
            5'd2    :   r_isqrt <= 'd2896  ;
            5'd3    :   r_isqrt <= 'd2365  ;
            5'd4    :   r_isqrt <= 'd2048  ;
            5'd5    :   r_isqrt <= 'd1832  ;
            5'd6    :   r_isqrt <= 'd1672  ;
            5'd7    :   r_isqrt <= 'd1548  ;
            5'd8    :   r_isqrt <= 'd1448  ;
            default :   r_isqrt <= 'd0     ;
        endcase
    end
end
reg [BW_ISQRT-1:0]  rr_isqrt     ;
always@(posedge i_clk) begin
    if(r_isqrt_en) begin
        rr_isqrt <= r_isqrt ;
    end
end
reg  [2*BW_WGT-1:0]             r_mux_cals_bfw_mat  [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [0:0]                      w_bfw_mult_en       [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_i        [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_q        [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_bfw_mult_i_dummy  [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_bfw_mult_q_dummy  [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [0:0]                      r_bfw_mult_en       [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [(DI_BW+BW_WGT+1)-1:0]     r_bfw_mult_i        [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [(DI_BW+BW_WGT+1)-1:0]     r_bfw_mult_q        [NUM_LANE_CC*NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_LANE_CC*NUM_ANT;gidx=gidx+1) begin : g02_0_bfw_mult_lane
`ifndef DLFE_AIE_DISABLE
always@(*) begin
    if(gidx<NUM_ANT) begin
        r_mux_cals_bfw_mat [gidx] = r_cals_cal_en ? {{2*BW_WGT}{r_cals_pat_en[gidx%NUM_ANT]}}&BYPASS_BFW_CALS : r_mux_bfw_mat[gidx]  ;
    end
    else begin
        r_mux_cals_bfw_mat [gidx] = r_cals_cal_en ? {{2*BW_WGT}{1'b0}} : r_mux_bfw_mat[gidx]  ;
    end
end
`else //DLFE_AIE_DISABLE
always@(*) begin
    r_mux_cals_bfw_mat [gidx] = r_mux_bfw_mat[gidx]  ;
end
`endif //DLFE_AIE_DISABLE
if(VENDOR=="Xilinx_Versal") begin
xip_cmult_bb_top_c16
u03_bfw_mult
(
    .aclk                   (   i_clk                                                                                                       )
   ,.s_axis_a_tvalid        (  |r_en[gidx/NUM_ANT][DLY_IN]                                                                                  )
   ,.s_axis_a_tdata         (  {{{{16-DI_BW}{r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)]}},r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)-:DI_BW]}
                               ,{{{16-DI_BW}{r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)]}},r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)-:DI_BW]}}     )
   ,.s_axis_b_tvalid        (  |r_en[gidx/NUM_ANT][DLY_IN]                                                                                  )
   ,.s_axis_b_tdata         (  {{{{16-BW_WGT}{r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)]}},r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)-:BW_WGT]}
                               ,{{{16-BW_WGT}{r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)]}},r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)-:BW_WGT]}}     )
   ,.m_axis_dout_tvalid     (   w_bfw_mult_en[gidx]                                                                                         )
   ,.m_axis_dout_tdata      (  {w_bfw_mult_q_dummy[gidx],w_bfw_mult_q[gidx],w_bfw_mult_i_dummy[gidx],w_bfw_mult_i[gidx]}                    )
);                  
end
else begin //(VENDOR=="Xilinx_Versal")
ylib_cmult #(
    .AWIDTH     (   DI_BW       )
   ,.BWIDTH     (   BW_WGT      ))
u03_bfw_mult
(
    .clk    (   i_clk                                               )
   ,.en     (  |r_en[gidx/NUM_ANT][DLY_IN]                          )
   ,.ar     (   r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)-:DI_BW]      )
   ,.ai     (   r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)-:DI_BW]      )
   ,.br     (   r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)-:BW_WGT]      )
   ,.bi     (   r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)-:BW_WGT]      )
   ,.pen    (   w_bfw_mult_en[gidx]                                 )
   ,.pr     (   w_bfw_mult_i[gidx]                                  )
   ,.pi     (   w_bfw_mult_q[gidx]                                  )
);
end //(VENDOR=="Xilinx_Versal")
always@(posedge i_clk) begin 
    r_bfw_mult_en[gidx] <=  w_bfw_mult_en[gidx]  ;
    if(w_bfw_mult_en[gidx]) begin
        r_bfw_mult_i[gidx]  <=  w_bfw_mult_i[gidx]  ;
        r_bfw_mult_q[gidx]  <=  w_bfw_mult_q[gidx]  ;
    end
end
end
endgenerate

reg  [01-1:0]                               r_bf_mat_lyr_cnt    [NUM_ANT-1:0]   ;
reg  [01-1:0]                               r_bf_mat_mult_en    [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]   r_bf_mat_mult_i     [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]   r_bf_mat_mult_q     [NUM_ANT-1:0]   ;
reg  [01-1:0]                               rr_bf_mat_mult_en   [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]   rr_bf_mat_mult_i    [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]   rr_bf_mat_mult_q    [NUM_ANT-1:0]   ;
reg  [01-1:0]                               rrr_bf_mat_mult_en  [NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g02_1_bf_ant
always@(posedge i_clk) begin
`ifndef DLFE_AIE_DISABLE
    if(r_cals_cal_en) begin
        r_bf_mat_mult_en[gidx] <= r_bfw_mult_en[gidx] ;
        if(r_bfw_mult_en[gidx%NUM_ANT]) begin
            r_bf_mat_mult_i[gidx] <= $signed(r_bfw_mult_i[NUM_ANT*00+gidx])+$signed(r_bfw_mult_i[NUM_ANT*01+gidx]) ;
            r_bf_mat_mult_q[gidx] <= $signed(r_bfw_mult_q[NUM_ANT*00+gidx])+$signed(r_bfw_mult_q[NUM_ANT*01+gidx]) ;
        end
    end
    else begin
`endif //DLFE_AIE_DISABLE
        r_bf_mat_mult_en[gidx] <= r_bfw_mult_en[gidx]&&r_bf_mat_lyr_cnt[gidx]==1'd0 ;
        if(w_bfw_mult_en[gidx%NUM_ANT]&~r_bfw_mult_en[gidx]) begin
            r_bf_mat_lyr_cnt[gidx] <= 1'd0 ;
        end
        else if(r_bfw_mult_en[gidx%NUM_ANT]) begin
            r_bf_mat_lyr_cnt[gidx] <= r_bf_mat_lyr_cnt[gidx] + 1'd1 ;
if(NUM_LANE_CC==2) begin
            r_bf_mat_mult_i[gidx] <= $signed(w_bfw_mult_i[NUM_ANT*00+gidx])+$signed(w_bfw_mult_i[NUM_ANT*01+gidx])+$signed(r_bfw_mult_i[NUM_ANT*00+gidx])+$signed(r_bfw_mult_i[NUM_ANT*01+gidx])    ;
            r_bf_mat_mult_q[gidx] <= $signed(w_bfw_mult_q[NUM_ANT*00+gidx])+$signed(w_bfw_mult_q[NUM_ANT*01+gidx])+$signed(r_bfw_mult_q[NUM_ANT*00+gidx])+$signed(r_bfw_mult_q[NUM_ANT*01+gidx])    ;
end//NUM_LANE_CC==2
else if(NUM_LANE_CC==4) begin
            r_bf_mat_mult_i[gidx] <= $signed(w_bfw_mult_i[NUM_ANT*00+gidx])+$signed(w_bfw_mult_i[NUM_ANT*01+gidx])+$signed(w_bfw_mult_i[NUM_ANT*02+gidx])+$signed(w_bfw_mult_i[NUM_ANT*03+gidx])+$signed(r_bfw_mult_i[NUM_ANT*00+gidx])+$signed(r_bfw_mult_i[NUM_ANT*01+gidx])+$signed(r_bfw_mult_i[NUM_ANT*02+gidx])+$signed(r_bfw_mult_i[NUM_ANT*03+gidx]) ;
            r_bf_mat_mult_q[gidx] <= $signed(w_bfw_mult_q[NUM_ANT*00+gidx])+$signed(w_bfw_mult_q[NUM_ANT*01+gidx])+$signed(w_bfw_mult_q[NUM_ANT*02+gidx])+$signed(w_bfw_mult_q[NUM_ANT*03+gidx])+$signed(r_bfw_mult_q[NUM_ANT*00+gidx])+$signed(r_bfw_mult_q[NUM_ANT*01+gidx])+$signed(r_bfw_mult_q[NUM_ANT*02+gidx])+$signed(r_bfw_mult_q[NUM_ANT*03+gidx]) ;
end//NUM_LANE_CC==4
        end
`ifndef DLFE_AIE_DISABLE
    end
`endif //DLFE_AIE_DISABLE
end
always@(posedge i_clk) begin
`ifndef DLFE_AIE_DISABLE
    rr_bf_mat_mult_en[gidx] <= r_bf_mat_mult_en[gidx]  ;
    rrr_bf_mat_mult_en[gidx] <= rr_bf_mat_mult_en[gidx]  ;
    if(r_bf_mat_mult_en[gidx]) begin
        rr_bf_mat_mult_i [gidx] <= r_bf_mat_mult_i [gidx] ;
        rr_bf_mat_mult_q [gidx] <= r_bf_mat_mult_q [gidx] ;
    end
`else //DLFE_AIE_DISABLE
    rrr_bf_mat_mult_en[gidx] <= rr_bf_mat_mult_en[gidx]  ;
    if(r_cals_cal_en) begin
        rr_bf_mat_mult_en[gidx] <= |i_cals_pat_en ;
        if((|i_cals_pat_en)|rr_bf_mat_mult_en[gidx]) begin
            if(i_cals_pat_en[gidx]) begin
                rr_bf_mat_mult_i [gidx] <= {{{{DI_BW+BW_WGT+$clog2(NUM_LAYER)-CALP_BW}{i_cals_pat_iq[(CALP_BW)*(1+1)-1]}},i_cals_pat_iq[((CALP_BW)*(1+1)-1)-:(CALP_BW)]}} ;
                rr_bf_mat_mult_q [gidx] <= {{{{DI_BW+BW_WGT+$clog2(NUM_LAYER)-CALP_BW}{i_cals_pat_iq[(CALP_BW)*(0+1)-1]}},i_cals_pat_iq[((CALP_BW)*(0+1)-1)-:(CALP_BW)]}} ;
            end
        end
        else begin
            rr_bf_mat_mult_i [gidx] <= {{DI_BW+BW_WGT+$clog2(NUM_LAYER)}{1'b0}} ;
            rr_bf_mat_mult_q [gidx] <= {{DI_BW+BW_WGT+$clog2(NUM_LAYER)}{1'b0}} ;
        end
    end
    else begin
        rr_bf_mat_mult_en[gidx] <= r_bf_mat_mult_en[gidx]  ;
        if(r_bf_mat_mult_en[gidx]) begin
            rr_bf_mat_mult_i [gidx] <= r_bf_mat_mult_i [gidx] ;
            rr_bf_mat_mult_q [gidx] <= r_bf_mat_mult_q [gidx] ;
        end
    end
`endif //DLFE_AIE_DISABLE
end
end
endgenerate
reg  [01-1:0]                                           r_bf_mat_mult_mux_en    [NUM_O_CHAIN-1:0]   ;
reg  [(DI_BW+BW_WGT+$clog2(NUM_LAYER))-1:0]             r_bf_mat_mult_mux_i     [NUM_O_CHAIN-1:0]   ;
reg  [(DI_BW+BW_WGT+$clog2(NUM_LAYER))-1:0]             r_bf_mat_mult_mux_q     [NUM_O_CHAIN-1:0]   ;
reg  [01-1:0]                                           r_bf_mat_mult_s_en      [NUM_O_CHAIN-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  r_bf_mat_mult_s_iq      [NUM_O_CHAIN-1:0]   ;
reg  [01-1:0]                                           rr_bf_mat_mult_s_en     [NUM_O_CHAIN-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  rr_bf_mat_mult_s_iq     [NUM_O_CHAIN-1:0]   ;
wire [01-1:0]                                           w_bf_mat_mult_sr_en     [NUM_O_CHAIN-1:0]   ;
wire [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  w_bf_mat_mult_sr_iq     [NUM_O_CHAIN-1:0]   ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g03_bf_ant_mux_norm
if((NUM_ANT/NUM_O_CHAIN)==1) begin
always@(posedge i_clk) begin
    r_bf_mat_mult_mux_en[gidx] <= rr_bf_mat_mult_en[gidx]   ;
    if(rr_bf_mat_mult_en[gidx]) begin
        r_bf_mat_mult_mux_i [gidx] <= rr_bf_mat_mult_i [gidx] ;
        r_bf_mat_mult_mux_q [gidx] <= rr_bf_mat_mult_q [gidx] ;
    end
end
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_bf_mat_mult_sr_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx%NUM_LANE_CC+1)-1)-:`mlib_clog2(NUM_CC)] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= gidx&{{$clog2(NUM_ANT)}{1'b1}} ;
    end
end
end //if((NUM_ANT/NUM_O_CHAIN)==1)
else if((NUM_ANT/NUM_O_CHAIN)==2) begin
always@(posedge i_clk) begin
    if(rr_bf_mat_mult_en[gidx*(NUM_ANT/NUM_O_CHAIN)+0]) begin
        r_bf_mat_mult_mux_en[gidx] <= rr_bf_mat_mult_en  [gidx*(NUM_ANT/NUM_O_CHAIN)+0] ;
        r_bf_mat_mult_mux_i [gidx] <= rr_bf_mat_mult_i   [gidx*(NUM_ANT/NUM_O_CHAIN)+0] ;
        r_bf_mat_mult_mux_q [gidx] <= rr_bf_mat_mult_q   [gidx*(NUM_ANT/NUM_O_CHAIN)+0] ;
    end
    else if(rrr_bf_mat_mult_en[gidx*(NUM_ANT/NUM_O_CHAIN)+1]) begin
        r_bf_mat_mult_mux_en[gidx] <= rrr_bf_mat_mult_en [gidx*(NUM_ANT/NUM_O_CHAIN)+1] ;
        r_bf_mat_mult_mux_i [gidx] <= rr_bf_mat_mult_i   [gidx*(NUM_ANT/NUM_O_CHAIN)+1] ;
        r_bf_mat_mult_mux_q [gidx] <= rr_bf_mat_mult_q   [gidx*(NUM_ANT/NUM_O_CHAIN)+1] ;
    end
    else begin
        r_bf_mat_mult_mux_en[gidx] <= 1'b0 ;
    end
end
always@(posedge i_clk) begin
    if(i_din_frame_sync||(rr_bf_mat_mult_s_en[gidx]&~w_bf_mat_mult_sr_en[gidx])) begin
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx%NUM_LANE_CC+1)-1)-:`mlib_clog2(NUM_CC)] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= {{$clog2(NUM_ANT)}{1'b1}}&((NUM_ANT/NUM_O_CHAIN)*gidx) ;
    end
    else if(o_dout_en[((01)*(gidx+1)-1)-:(01)]) begin
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= {o_dout_ant_id[($clog2(NUM_ANT)*(gidx+1)-1):($clog2(NUM_ANT)*gidx)+1],~o_dout_ant_id[$clog2(NUM_ANT)*gidx]} ;
    end
end
end //if((NUM_ANT/NUM_O_CHAIN)==2)
always@(posedge i_clk) begin
    r_bf_mat_mult_s_en[gidx] <=  r_bf_mat_mult_mux_en[gidx]  ;
    if(r_bf_mat_mult_mux_en[gidx]) begin
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*2-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)] <= $signed(r_bf_mat_mult_mux_i[gidx])*$signed({1'd0,rr_isqrt}) ;
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*1-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)] <= $signed(r_bf_mat_mult_mux_q[gidx])*$signed({1'd0,rr_isqrt}) ;
    end
end
always@(posedge i_clk) begin
    rr_bf_mat_mult_s_en[gidx] <=  r_bf_mat_mult_s_en[gidx]  ;
    if(r_bf_mat_mult_s_en[gidx]) begin
        rr_bf_mat_mult_s_iq[gidx] <= r_bf_mat_mult_s_iq[gidx] ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                                       )
 ,.SHIFTD_BW    (   5                                       )
 ,.IO_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT ))
u04_bfw_shiftd_rnd 
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   rr_bf_mat_mult_s_en[gidx]   )
    ,.i_in      (   rr_bf_mat_mult_s_iq[gidx]   )
`ifndef DLFE_AIE_DISABLE
    ,.i_shiftd  (   5'd20                       )
`else //DLFE_AIE_DISABLE
    ,.i_shiftd  (   r_cals_cal_en ? 5'd12:5'd20 )
`endif //DLFE_AIE_DISABLE
    ,.o_out_en  (   w_bf_mat_mult_sr_en[gidx]   )
    ,.o_out     (   w_bf_mat_mult_sr_iq[gidx]   )
);
ylib_sat #(
  .NUM_STREAM   (   2                                       )
 ,.DI_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT )
 ,.DO_BW        (   DO_BW                                   ))
u05_bfw_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_bf_mat_mult_sr_en[gidx]                       )
    ,.i_in      (   w_bf_mat_mult_sr_iq[gidx]                       )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
end
endgenerate
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u06_0_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_frame_sync ),.o_out(o_dout_frame_sync ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u06_1_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_subfrm_sync),.o_out(o_dout_subfrm_sync));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u06_2_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_slot_sync  ),.o_out(o_dout_slot_sync  ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u06_3_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_symbol_sync),.o_out(o_dout_symbol_sync));
ylib_reg  #(.WIDTH(1),.DEPTH(DLY_MURE_EN)) u07_fsync_dly (.i_clk(i_clk),.i_in(r_re_map[DLY_IN]==IDX_REMAP_MUCB),.o_out(o_dout_mure_en));
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        o_dout_mu       <=  i_din_mu        ;   
        o_dout_fft_size <=  i_din_fft_size  ;
        o_dout_cal_en   <=  i_cals_cal_en   ;
    end
end
`endif //DLFE_ORAN_DISABLE
endmodule
