//////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10/FSU20
//                 oRU : DCM RT4419/RT4422
//                       VzW RT8808/RF4440d
//                       VDF RF4448/RF4449
//                       MSTR_V02
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_cdd_cp_buf
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe multi purpose buffer (configurable cell multiplexing) 
//                 1. dlfe cyclic delay diversity
//                 2. add cyclic prefix 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.16 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.09.21 | jyzoo.lee     | Read Buffering Gating 
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.12.17 | jyzoo.lee     | Supports 30k scs
//  ------------+---------------+-----------------------------------------------
//   2020.12.28 | jyzoo.lee     | Supports NUM_ANT==8
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Supports Procesing Calibraion Symbols
//  ------------+---------------+-----------------------------------------------
//   2021.02.16 | jyzoo.lee     | Supports Punturing UL Calibration Signal
//  ------------+---------------+-----------------------------------------------
//   2021.03.15 | jyzoo.lee     | Supports LTE
//  ------------+---------------+-----------------------------------------------
//   2021.04.05 | jyzoo.lee     | Supports AIE IFFT
//  ------------+---------------+-----------------------------------------------
//   2021.04.29 | jyzoo.lee     | Add RAMs for CDD Value
//  ------------+---------------+-----------------------------------------------
//   2021.05.26 | jyzoo.lee     | Non-Aligned AIE AXIS Support
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_cdd_cp_buf
#(
    parameter  NUM_CC               =   1
   ,parameter  NUM_ANT              =   4
   ,parameter  NUM_I_CHAIN          =   1
   ,parameter  DI_BW                =   15           
   ,parameter  DO_BW                =   15           
   ,parameter  MAX_MU               =   0
   ,parameter  MAX_NIFFT            =   2048 
   ,parameter  ADDR_OFFSET          =   'h00000           
   ,parameter  VENDOR               =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  

    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid
            
    //--- from dlfe_param_if
    ,   input   wire    [22*NUM_CC-1:0]                         i_dlfe_par_100c

    ,   input   wire    [1*NUM_CC			-1:0] 	            i_counter_rst					       
	,   input   wire    [2*NUM_CC			-1:0] 	            i_sig_susp_en					 /* 0 = disable, 1 = common_threshold, 2 = sym per threshold */    
	,   input   wire    [32*14*NUM_CC		-1:0] 	            i_sym_per_thrshld_val			

	,   input   wire    [12*NUM_CC			-1:0] 	            i_reg_ntone
    ,   input   wire    [32*NUM_CC			-1:0]	            i_comm_thrshld_val
    
    ,   output  wire    [32*14*NUM_CC		-1:0] 	            o_upper_threshold_cnt			
	,   output  wire    [32*14*NUM_CC		-1:0] 	            o_max_pwr_per_sym	
    
    //--- from bb_cal_schdlr
    ,   input   wire    [12*NUM_CC-1:0]                         i_cals_punc_len
    
    //--- from dlfe_ant_scale
    ,   input   wire    [01-1:0]                                i_din_ref_frame_sync
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [04-1:0]                                i_din_symbol_idx
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en        
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq        
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_I_CHAIN-1:0] i_din_cc_id    
    ,   input   wire    [$clog2(NUM_ANT)*NUM_I_CHAIN-1:0]       i_din_ant_id
    ,   input   wire    [04-1:0]                                i_din_mu        
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size  
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_out_if
    ,   output  reg     [01*NUM_CC-1:0]                         o_dout_frame_sync 
    ,   output  reg     [01*NUM_CC-1:0]                         o_dout_subfrm_sync
    ,   output  reg     [01*NUM_CC-1:0]                         o_dout_slot_sync  
    ,   output  reg     [01*NUM_CC-1:0]                         o_dout_symbol_sync
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_subfrm_idx 
    ,   output  reg     [06*NUM_CC-1:0]                         o_dout_slot_idx   
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_symbol_idx 
    ,   output  reg     [01*NUM_ANT*NUM_CC-1:0]                 o_dout_en
    ,   output  reg     [02*DO_BW*NUM_ANT*NUM_CC-1:0]           o_dout_iq
);

//Parameter Local Logic
localparam              CHAIN_REF           =           0                                               ;
localparam              CC_REF              =           0                                               ;
localparam              ID_CAL_UL_PUNC      =           2'd3                                            ;
localparam              ORAN_FFT0512        =           4'h9                                            ;
localparam              ORAN_FFT1024        =           4'ha                                            ;
localparam              ORAN_FFT2048        =           4'hb                                            ;
localparam              ORAN_FFT4096        =           4'hc                                            ;
localparam  [04-1:0]    DLFE_MU_015K        =           0                                               ;
localparam  [04-1:0]    DLFE_MU_030K        =           1                                               ;
localparam  [04-1:0]    DLFE_MU_060K        =           2                                               ;
localparam  [03-1:0]    EXP_SR_BW_100       =           3'd1                                            ;
localparam  [03-1:0]    EXP_SR_BW_080       =           3'd1                                            ;
localparam  [03-1:0]    EXP_SR_BW_060       =           3'd1                                            ;
localparam  [03-1:0]    EXP_SR_BW_050       =           3'd2                                            ;
localparam  [03-1:0]    EXP_SR_BW_040       =           3'd2                                            ;
localparam  [03-1:0]    EXP_SR_BW_030       =           3'd2                                            ;
localparam  [03-1:0]    EXP_SR_BW_020       =           3'd3                                            ;
localparam  [03-1:0]    EXP_SR_BW_015       =           3'd3                                            ;
localparam  [03-1:0]    EXP_SR_BW_010       =           3'd4                                            ;
localparam  [03-1:0]    EXP_SR_BW_005       =           3'd5                                            ;
localparam  [12-1:0]    LCP_MU_015K         =           (((144*64)>>DLFE_MU_015K)+16*64)/8              ;
localparam  [12-1:0]    LCP_MU_030K         =           (((144*64)>>DLFE_MU_030K)+16*64)/8              ;
localparam  [12-1:0]    LCP_MU_060K         =           (((144*64)>>DLFE_MU_060K)+16*64)/8              ;
localparam  [12-1:0]    NCP_MU_015K         =           ((144*64)>>DLFE_MU_015K)/8                      ;
localparam  [12-1:0]    NCP_MU_030K         =           ((144*64)>>DLFE_MU_030K)/8                      ;
localparam  [12-1:0]    NCP_MU_060K         =           ((144*64)>>DLFE_MU_060K)/8                      ;
localparam              NUM_CBUF_MEM        =           2                                               ;
localparam              BW_SYM_CNT          =           $clog2(2**(15-MAX_MU))                          ; 
localparam              BW_CDD              =           $clog2(MAX_NIFFT)                               ;
localparam  [19:00]     CDD_START_ADDR      =           ADDR_OFFSET+'h01300                             ;
localparam  [19:00]     CDD_END_ADDR        =           CDD_START_ADDR+((NUM_ANT-1)<<2)                 ;
localparam              DLY_REG_RD          =           1                                               ;
`ifndef DLFE_AIE_DISABLE
localparam              BW_MEM_DATA         =           72                                              ;
localparam              SIZE_AXIS_PKT       =           1024                                            ;
localparam              SIZE_AIE_PKT        =           512                                             ;
localparam              MEM_DEPTH           =           SIZE_AXIS_PKT*NUM_CBUF_MEM                      ;
localparam              BW_MEM_ADDR         =           $clog2(MEM_DEPTH)                               ;
localparam              NUM_CHAIN_MEM       =           BW_MEM_DATA/(2*DO_BW)                           ;
localparam              NUM_S2P_AXIS        =           4                                               ;
localparam integer      NUM_MEM             =           $ceil((2*DO_BW*NUM_S2P_AXIS)/(BW_MEM_DATA*1.0)) ;
localparam              AIE_OUT_BLK_ID0     =           2'd0                                            ;
localparam              AIE_OUT_BLK_ID1     =           2'd2                                            ;
localparam              AIE_OUT_BLK_ID2     =           2'd1                                            ;
localparam              AIE_OUT_BLK_ID3     =           2'd3                                            ;
localparam              DLY_SYNC            =           7                                               ;   
`ifndef DLFE_ORAN_DISABLE
localparam              ADV_TARGET_DLY      =           22'd24                                          ;
`else// DLFE_ORAN_DISABLE
localparam              ADV_TARGET_DLY      =           22'd33                                          ;
`endif// DLFE_ORAN_DISABLE
`else //DLFE_AIE_DISABLE
localparam              DLY_SYNC            =           6                                               ;   
`ifndef DLFE_ORAN_DISABLE
localparam              ADV_TARGET_DLY      =           22'd23                                          ;
`else// DLFE_ORAN_DISABLE
localparam              ADV_TARGET_DLY      =           22'd31                                          ;
`endif// DLFE_ORAN_DISABLE
`endif //DLFE_AIE_DISABLE

//reg [32*14*NUM_CC					-1:0] 	w_sym_per_thrshld_val;
//always@(posedge i_clk) begin
//    w_sym_per_thrshld_val[0*32 +:32] <= 32'h00000100;            // symbol 0, cc0
//    w_sym_per_thrshld_val[14*32 +:32] <= 32'h00000101;    // symbol 0, cc1
//end
//Logic Variable
genvar gidx ;
integer i ;

	wire[1*NUM_CC			-1:0]   w_pwr_msr_complete  ;
	reg[1*NUM_CC			-1:0]   r_pwr_msr_complete_d  ;
	wire[1*NUM_CC			-1:0]   w_sg_suspens_sym_null_en  ;
	reg[1*NUM_CC*NUM_ANT	-1:0]   r_sg_suspens_sym_null_en_stretch  ;
	reg[1*NUM_CC*NUM_ANT	-1:0]   r_sg_suspens_sym_null_en_latch  ;
    
    wire   [32*14*NUM_CC	-1:0] 	w_upper_threshold_cnt;			
	wire   [32*14*NUM_CC	-1:0] 	w_max_pwr_per_sym;				
    wire   [32*NUM_CC   	-1:0]	w_comm_thrshld_val;
    /************************************************/
    /*  Test: Signal Suspensor						*/
    /************************************************/  
    
    dlfe_sg_suspensor
    #( // Parameter
         .NUM_ANT           ( NUM_ANT       )
        ,.NUM_I_CHAIN       ( NUM_I_CHAIN   )
        ,.DI_BW             ( DI_BW         )
        ,.DO_BW             ( DO_BW         )
        ,.CC_NUM            ( NUM_CC        )
    )
    u_dlfe_sg_suspensor
    ( // IO Port
        // Clock and Reset
        .i_rst                             	(i_rst              	), 
        .i_clk                             	(i_clk              	), 
    
		// Control Input
		.i_reg_ntone					    (i_reg_ntone),            //r_wr_bandwidth			),
		.i_comm_thrshld_val					(i_comm_thrshld_val),            //r_wr_ffttype			),
        .i_counter_rst                  	(i_counter_rst),            //i_counter_rst			),
        .i_sig_susp_en                  	(i_sig_susp_en),            //i_sig_susp_en			),
        .i_sym_per_thrshld_val          	(i_sym_per_thrshld_val),            //   64'h0000010000000100),   //i_sym_per_thrshld_val	),
        
		.i_symbol_sync			            (i_din_symbol_sync		), 	
		.i_symbol_idx                       (i_din_symbol_idx		), 	
		.i_cc_idx              	            (i_din_cc_id    		), 	
		.i_din_ant_id 			            (i_din_ant_id		), 	
		.i_din_en     			            (i_din_en    		), 	
		.i_din_iq     			            (i_din_iq    		), 	
        
		// Output Data
        .o_upper_threshold_cnt         		(w_upper_threshold_cnt    ), 
        .o_max_pwr_per_sym          		(w_max_pwr_per_sym        ),         
        .o_pwr_msr_complete                	(w_pwr_msr_complete       ),
        .o_sg_suspens_sym_null_en       	(w_sg_suspens_sym_null_en ),
        .o_comm_thrshld_val					(w_comm_thrshld_val       )        
    );
    assign o_upper_threshold_cnt = w_upper_threshold_cnt;
    assign o_max_pwr_per_sym = w_max_pwr_per_sym;
	
    always@(posedge i_clk) begin
        r_pwr_msr_complete_d <= w_pwr_msr_complete ;
        if( (w_pwr_msr_complete[1] == 1) && (r_pwr_msr_complete_d[1] == 0) ) begin
            r_sg_suspens_sym_null_en_stretch <=  {w_sg_suspens_sym_null_en[0],w_sg_suspens_sym_null_en[0],w_sg_suspens_sym_null_en[0],w_sg_suspens_sym_null_en[0],w_sg_suspens_sym_null_en[1],w_sg_suspens_sym_null_en[1],w_sg_suspens_sym_null_en[1],w_sg_suspens_sym_null_en[1]} ;
        end
    end
    
    always@(posedge i_clk) begin
        if (w_dly_symbol_sync_prev_1 == 1) begin
            if (r_sg_suspens_sym_null_en_stretch == 8'd255) begin
                r_sg_suspens_sym_null_en_latch <=  r_sg_suspens_sym_null_en_stretch;
            end
            else begin 
                r_sg_suspens_sym_null_en_latch <= 8'd0;
            end 
             
        end
    end

reg [0:0] r_ref_frame_sync ;
reg [3:0] r_mu ;
always@(posedge i_clk) begin
    r_ref_frame_sync <= i_din_ref_frame_sync ;
    if(i_din_ref_frame_sync) begin
        r_mu <=  i_din_mu ;
    end
end
reg r_cdd_rd_en ;
reg [$clog2(NUM_ANT)-1:0] r_cdd_rd_cnt ;
always@(posedge i_clk) begin
    if(i_din_ref_frame_sync) begin
        r_cdd_rd_en <= 1'd1 ;
        r_cdd_rd_cnt <= {{$clog2(NUM_ANT)}{1'b0}} ;
    end
    else if(r_cdd_rd_en) begin
        r_cdd_rd_cnt <= r_cdd_rd_cnt + 1'd1 ;
        if(r_cdd_rd_cnt=={{$clog2(NUM_ANT)}{1'b1}}) begin
            r_cdd_rd_en <= 1'd0 ;
        end
    end
end
reg rr_cdd_rd_en ;
reg rrr_cdd_rd_en ;
reg [$clog2(NUM_ANT)-1:0] rrr_cdd_rd_cnt ;
always@(posedge i_clk) begin
    rr_cdd_rd_en <= r_cdd_rd_en ;
    rrr_cdd_rd_en <= rr_cdd_rd_en ;
    if(i_din_ref_frame_sync) begin
        rrr_cdd_rd_cnt <= {{$clog2(NUM_ANT)}{1'b0}} ;
    end
    else if(rrr_cdd_rd_en) begin
        rrr_cdd_rd_cnt <= rrr_cdd_rd_cnt + 1'd1 ;
    end
end
wire[3:0]           w_fft_size      [NUM_CC-1:0]                ;
reg [3:0]           r_fft_size      [NUM_CC-1:0]                ;
reg [2:0]           r_sr_exp        [NUM_CC-1:0]                ;
reg [12-1:0]        r_lcp_len_base  [NUM_CC-1:0]                ;
reg [12-1:0]        r_ncp_len_base  [NUM_CC-1:0]                ;
reg [21:0]          r_cddcp_retard  [NUM_CC-1:0]                ;
reg [12-1:0]        r_puncLength    [NUM_CC-1:0]                ;
reg [01-1:0]        r_cpu_wren      [NUM_CC-1:0]                ;
reg [01-1:0]        r_cpu_rden      [NUM_CC-1:0]                ;
reg [20-1:0]        r_cpu_addr      [NUM_CC-1:0]                ;
reg [32-1:0]        r_cpu_wdata     [NUM_CC-1:0]                ;
reg [0:0]           r_buf_en        [NUM_CC-1:0]                ;
reg [0:0]           r_buf_wren      [NUM_CC-1:0]                ;
reg [19:0]          r_buf_addr      [NUM_CC-1:0]                ;
reg [BW_CDD-1:0]    r_buf_wdata     [NUM_CC-1:0]                ;
reg [0:0]           r_buf_rden      [NUM_CC-1:0]                ;
wire[BW_CDD-1:0]    w_buf_rdata     [NUM_CC-1:0]                ;
reg [0:0]           rr_buf_rden     [NUM_CC-1:0][DLY_REG_RD:0]  ;
reg [BW_CDD-1:0]    rr_buf_rdata    [NUM_CC-1:0][DLY_REG_RD:0]  ;
reg [BW_CDD-1:0]    r_cdd           [NUM_CC-1:0][NUM_ANT-1:0]   ;
reg [BW_CDD-1:0]    rr_cdd          [NUM_CC-1:0][NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_cdd_cp_param
always@(posedge i_clk) begin
    if(i_din_ref_frame_sync) begin
`ifndef DLFE_IFFT_MAP_DISABLE 
        r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] ;
`else // DLFE_IFFT_MAP_DISABLE 
        case(w_fft_size[gidx])
            ORAN_FFT0512   :   r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] + 22'd0      ;
            ORAN_FFT1024   :   r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] + 22'd0      ;
            ORAN_FFT2048   :   r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] + 22'd0      ;
            ORAN_FFT4096   :   r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] + 22'd2000   ;
            default        :   r_cddcp_retard[gidx] <= i_dlfe_par_100c [((22)*(gidx+1)-1)-:(22)] + 22'd0      ;
        endcase
`endif // DLFE_IFFT_MAP_DISABLE 
    end
end
assign  w_fft_size[gidx] =  i_din_fft_size[((04)*(gidx+1)-1)-:(04)] ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin
        r_puncLength[gidx] <= i_cals_punc_len[((12)*(gidx+1)-1)-:(12)]    ;
    end
end
always@(*) begin
    r_cpu_wren  [gidx] = i_cpu_wren[gidx]  ;
    r_cpu_rden  [gidx] = i_cpu_rden[gidx]  ;
    r_cpu_addr  [gidx] = i_cpu_addr [((20)*(gidx+1)-1)-:(20)] ;
    r_cpu_wdata [gidx] = i_cpu_wdata[((32)*(gidx+1)-1)-:(32)] ;
end
always@(posedge i_clk) begin
    if(r_cpu_wren[gidx]&&r_cpu_addr[gidx]>=CDD_START_ADDR&&r_cpu_addr[gidx]<=CDD_END_ADDR) begin
        r_buf_en    [gidx]  <=  1'd1                                ;
        r_buf_wren  [gidx]  <=  r_cpu_wren[gidx]                    ;
        r_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-CDD_START_ADDR)>>2 ; 
        r_buf_wdata [gidx]  <=  r_cpu_wdata[gidx]                   ;
        r_buf_rden  [gidx]  <=  1'd0                                ;
    end
    else if(r_cpu_rden[gidx]&&r_cpu_addr[gidx]>=CDD_START_ADDR&&r_cpu_addr[gidx]<=CDD_END_ADDR) begin
        r_buf_en    [gidx]  <=  1'd1                                ;
        r_buf_wren  [gidx]  <=  1'd0                                ;
        r_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-CDD_START_ADDR)>>2 ; 
        r_buf_rden  [gidx]  <=  r_cpu_rden[gidx]                    ;
    end
    else if(r_cdd_rd_en) begin
        r_buf_en    [gidx]  <=  r_cdd_rd_en ;
        r_buf_wren  [gidx]  <=  1'd0        ;
        r_buf_rden  [gidx]  <=  1'd0        ;
        r_buf_addr  [gidx]  <=  {{{20-$clog2(NUM_ANT)}{1'd0}},r_cdd_rd_cnt} ;  
    end
    else begin
        r_buf_en    [gidx]  <=  1'd0 ;
        r_buf_wren  [gidx]  <=  1'd0 ;
        r_buf_rden  [gidx]  <=  1'd0 ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   BW_CDD          )
   ,.DEPTH  (   NUM_ANT         )
   ,.VENDOR (   VENDOR          )) 
u00_cdd_cp_mem (
    .clk    (i_clk                                      )
   ,.we     (r_buf_wren[gidx]                           )
   ,.en     (r_buf_en[gidx]                             )
   ,.addr   (r_buf_addr[gidx][$clog2(NUM_ANT)-1:0]      )
   ,.di     (r_buf_wdata[gidx]                          )
   ,.dout   (w_buf_rdata[gidx]                          )
);
always@(posedge i_clk) begin
    rr_buf_rden[gidx][0] <= r_buf_rden[gidx]    ;
end
always@(*) begin
    rr_buf_rdata[gidx][0] = w_buf_rdata[gidx]   ;
end
if(DLY_REG_RD>0) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_REG_RD;i=i+1) begin
        rr_buf_rden[gidx][i] <= rr_buf_rden[gidx][i-1]   ;
        if(rr_buf_rden[gidx][i-1]) begin
            rr_buf_rdata[gidx][i]  <=  rr_buf_rdata[gidx][i-1]  ;
        end
    end
end
end
always@(*) begin
    o_cpu_rd_valid [((01)*(gidx+1)-1)-:(01)] = rr_buf_rden [gidx][DLY_REG_RD]   ;
    o_cpu_rdata    [((32)*(gidx+1)-1)-:(32)] = rr_buf_rdata[gidx][DLY_REG_RD]   ;
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_ANT;i=i+1) begin
        if(rrr_cdd_rd_en&&rrr_cdd_rd_cnt==({{$clog2(NUM_ANT)}{1'b1}}&i)) begin
            r_cdd[gidx][i] <= w_buf_rdata[gidx] ;
        end
    end
end
end
endgenerate

reg     [1-1:0]                     r_en                [NUM_I_CHAIN-1:0] ;
reg     [2*DI_BW-1:0]               r_iq                [NUM_I_CHAIN-1:0] ;   
reg     [(`mlib_clog2(NUM_CC))-1:0] r_cc_id             [NUM_I_CHAIN-1:0] ;
reg     [$clog2(NUM_ANT)-1:0]       r_ant_id            [NUM_I_CHAIN-1:0] ;   
wire    [1-1:0]                     w_ifft_out_en       [NUM_I_CHAIN-1:0] ;
wire    [$clog2(MAX_NIFFT)-1:0]     w_ifft_out_idx      [NUM_I_CHAIN-1:0] ;   
`ifndef DLFE_AIE_DISABLE
reg     [$clog2(SIZE_AXIS_PKT)-1:0] r_aie_pkt_smp_idx   [NUM_I_CHAIN-1:0] ;   
`endif //DLFE_AIE_DISABLE
always@(posedge i_clk) begin
    if(i_din_frame_sync||(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF])) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            r_fft_size[i]  <=  i_din_fft_size[((04)*(i+1)-1)-:(04)]  ;
            case({i_din_mu,i_din_fft_size[((04)*(i+1)-1)-:(04)]})
                {DLFE_MU_015K,ORAN_FFT2048} : r_sr_exp[i] <= EXP_SR_BW_020 ; 
                {DLFE_MU_015K,ORAN_FFT1024} : r_sr_exp[i] <= EXP_SR_BW_010 ; 
                {DLFE_MU_015K,ORAN_FFT0512} : r_sr_exp[i] <= EXP_SR_BW_005 ; 
                {DLFE_MU_030K,ORAN_FFT4096} : r_sr_exp[i] <= EXP_SR_BW_100 ; 
                {DLFE_MU_030K,ORAN_FFT2048} : r_sr_exp[i] <= EXP_SR_BW_050 ; 
                {DLFE_MU_030K,ORAN_FFT1024} : r_sr_exp[i] <= EXP_SR_BW_020 ; 
                default                     : r_sr_exp[i] <= 3'd0 ; 
            endcase
            case(i_din_mu)
                DLFE_MU_015K : begin r_lcp_len_base[i] <= LCP_MU_015K ; r_ncp_len_base[i] <= NCP_MU_015K ; end 
                DLFE_MU_030K : begin r_lcp_len_base[i] <= LCP_MU_030K ; r_ncp_len_base[i] <= NCP_MU_030K ; end 
                DLFE_MU_060K : begin r_lcp_len_base[i] <= LCP_MU_060K ; r_ncp_len_base[i] <= NCP_MU_060K ; end 
                default      : begin r_lcp_len_base[i] <= LCP_MU_015K ; r_ncp_len_base[i] <= NCP_MU_015K ; end 
            endcase
        end
    end
end
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g01_buf_in_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]&~r_en[gidx]) begin
        r_cc_id  [gidx]    <=  i_din_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
        r_ant_id [gidx]    <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] ;
    end
end
ylib_xfft_order_gen #(
    .MAX_NFFT   (   MAX_NIFFT       )
`ifndef DLFE_AIE_DISABLE
   ,.IP_TYPE    (   "AIE_IFFT"      )
   ,.ID_AXIS    (   gidx            ))
`else //DLFE_AIE_DISABLE 
   ,.IP_TYPE    (   "NORMAL"        ))
`endif //DLFE_AIE_DISABLE
u00_ifft_order_gen
(
     .i_clk             (  i_clk                                            )
    ,.i_xfft_size       (  w_fft_size[i_din_cc_id[(((`mlib_clog2(NUM_CC)))*(gidx+1)-1)-:((`mlib_clog2(NUM_CC)))]] )
    ,.i_xfft_out_en     (  i_din_en[((01)*(gidx+1)-1)-:(01)]                )
    ,.o_xfft_out_en     (  w_ifft_out_en  [gidx]                            )
    ,.o_xfft_out_idx    (  w_ifft_out_idx [gidx]                            )
);
`ifndef DLFE_AIE_DISABLE
always@(posedge i_clk) begin
    if(i_din_en[gidx]&~r_en[gidx]) begin
        r_aie_pkt_smp_idx[gidx] <= {{$clog2(MAX_NIFFT)}{1'b0}} ;
    end
    else if(r_en[gidx]) begin
        r_aie_pkt_smp_idx[gidx] <= r_aie_pkt_smp_idx[gidx] + 1'd1 ;
    end
end
`endif //DLFE_AIE_DISABLE
end
endgenerate

`ifndef DLFE_AIE_DISABLE
reg [BW_MEM_DATA-1:0] r_iq_cat [NUM_MEM-1:0] ;   
always@(*) begin
    for(i=0;i<NUM_MEM;i=i+1) begin
        r_iq_cat[i][NUM_CHAIN_MEM*2*DI_BW-1:0] = {r_iq[(NUM_CHAIN_MEM*i)+01], r_iq[(NUM_CHAIN_MEM*i)+00]} ;
    end
end
reg [1-1:0]             r_sym_det   [NUM_MEM*NUM_ANT-1:0] ;
reg [1-1:0]             r_wr_en     [NUM_MEM*NUM_ANT-1:0] ;
reg [BW_MEM_DATA-1:0]   r_wr_data   [NUM_MEM*NUM_ANT-1:0] ;
reg [BW_MEM_ADDR-1:0]   r_wr_addr   [NUM_MEM*NUM_ANT-1:0] ;
generate for(gidx=0;gidx<NUM_MEM*NUM_ANT;gidx=gidx+1) begin : g03_buf_in_aieblk2ant
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_sym_det [gidx]  <=  1'd0  ;
        r_wr_addr [gidx]  <=  {{$clog2(MAX_NIFFT)}{1'd0}} ;
    end
    else if(r_en[(gidx/NUM_ANT)*NUM_MEM]&&r_ant_id[(gidx/NUM_ANT)*NUM_MEM]==({{$clog2(NUM_ANT)}{1'b1}}&(gidx%NUM_ANT))) begin
        r_sym_det [gidx]  <=  1'd1 ;
        r_wr_en   [gidx]  <=  r_ant_id[(gidx/NUM_ANT)*NUM_MEM]==({{$clog2(NUM_ANT)}{1'b1}}&(gidx%NUM_ANT)) ;
        r_wr_data [gidx]  <=  r_iq_cat[gidx/NUM_ANT] ;
        r_wr_addr [gidx]  <= {i_din_symbol_idx[0],r_aie_pkt_smp_idx[(gidx/NUM_ANT)*NUM_MEM][BW_MEM_ADDR-2:0]} ;
    end
    else begin
        r_wr_en   [gidx]  <=  1'd0    ;
    end
end
end
endgenerate
`else //DLFE_AIE_DISABLE 
reg [1-1:0]                 r_sym_det   [NUM_ANT*NUM_CC-1:0] ;
reg [1-1:0]                 r_wr_en     [NUM_ANT*NUM_CC-1:0] ;
reg [2*DI_BW-1:0]           r_wr_data   [NUM_ANT*NUM_CC-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0] r_wr_addr   [NUM_ANT*NUM_CC-1:0] ;
generate for(gidx=0;gidx<NUM_ANT*NUM_CC;gidx=gidx+1) begin : g02_buf_in_chain2ant
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_sym_det [gidx]  <=  1'd0  ;
        r_wr_addr [gidx]  <=  {{$clog2(MAX_NIFFT)}{1'd0}} ;
    end
    else if(r_en[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)]&&r_cc_id[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)]==(gidx/NUM_ANT)&&r_ant_id[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)]==(gidx%NUM_ANT)) begin
        r_sym_det [gidx]  <=  1'd1 ;
        r_wr_en   [gidx]  <=  r_en[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)] ;
        r_wr_data [gidx]  <=  r_iq[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)] ;
        r_wr_addr [gidx]  <=  w_ifft_out_idx[gidx/((NUM_ANT*NUM_CC)/NUM_I_CHAIN)] ;
    end
    else begin
        r_wr_en   [gidx]  <=  1'd0    ;
    end
end
end
endgenerate
`endif //DLFE_AIE_DISABLE

wire        w_frame_sync     ;
wire        w_subfrm_sync    ;
wire        w_slot_sync      ;
wire        w_symbol_sync    ;
wire [3:0]  w_subfrm         ;
wire [7:0]  w_slot           ;
wire [3:0]  w_symbol         ;
ref_vsync_gen u01_buf_rd_rtg
(
     .i_clk                 ( i_clk                                     )          
    ,.i_mu                  ( r_mu                                      )
    ,.i_retard              ( r_cddcp_retard[CC_REF]-ADV_TARGET_DLY     )
    ,.i_frame_sync          ( r_ref_frame_sync                          )          
    ,.i_en                  ( 1'd1                                      )          
    ,.o_frame_sync          ( w_frame_sync                              )   
    ,.o_subfrm_sync         ( w_subfrm_sync                             )   
    ,.o_slot_sync           ( w_slot_sync                               )   
    ,.o_symbol_sync         ( w_symbol_sync                             )   
    ,.o_subfrm              ( w_subfrm                                  )          
    ,.o_slot                ( w_slot                                    )          
    ,.o_symbol              ( w_symbol                                  )          
);
reg [3:0] r_rd_mu ;
always@(posedge i_clk) begin
    if(w_frame_sync) begin
        r_rd_mu <= r_mu ;
    end
end
reg [5:0] r_smp_cnt     [NUM_CC-1:0] ;
reg [2:0] r_rd_sr_exp   [NUM_CC-1:0] ;
reg [4-1:0]                 r_rd_fft_size       [NUM_CC-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0] r_rd_fft_base_ptr   [NUM_CC-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0] r_cp_len_base       [NUM_CC-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0] r_cp_len_base_sr    [NUM_CC-1:0] ;
reg [BW_SYM_CNT-1:0]        r_punc_ptr_base     [NUM_CC-1:0] ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g04_rd_param_sync
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        for(i=0;i<NUM_ANT;i=i+1) begin
            if(|i_din_cal_en) begin
                rr_cdd[gidx][i] <= {{BW_CDD}{1'b0}} ;
            end
            else begin
                rr_cdd[gidx][i] <= r_cdd[gidx][i] ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(w_frame_sync) begin
        r_smp_cnt     [gidx] <=  6'd0             ;
        r_rd_sr_exp   [gidx] <=  r_sr_exp[gidx]   ;
    end
    else begin
        r_smp_cnt [gidx] <= (r_smp_cnt[gidx]==(6'd1<<r_rd_sr_exp[gidx])-1'd1) ? 6'd0 : r_smp_cnt[gidx]+1'd1 ;
    end
end
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        r_rd_fft_size[gidx] <= r_fft_size[gidx] ;
        r_rd_fft_base_ptr[gidx] <= {{{$clog2(MAX_NIFFT)-1}{1'd0}},1'd1}<<r_fft_size[gidx] ;
        r_punc_ptr_base[gidx] <= (({{{BW_SYM_CNT-1}{1'd0}},1'd1}<<r_fft_size[gidx/NUM_ANT])-r_puncLength[gidx])<<r_rd_sr_exp[gidx] ;
        if((r_mu==DLFE_MU_015K&&(w_symbol==4'd0||w_symbol==4'd7))||(r_mu==DLFE_MU_030K&&w_symbol==4'd0)) begin
            r_cp_len_base_sr[gidx] <= r_lcp_len_base[gidx]>>r_sr_exp[gidx] ;
            r_cp_len_base[gidx] <= r_lcp_len_base[gidx] ;
        end
        else begin
            r_cp_len_base_sr[gidx] <= r_ncp_len_base[gidx]>>r_sr_exp[gidx] ;
            r_cp_len_base[gidx] <= r_ncp_len_base[gidx] ;
        end
    end
end
end
endgenerate
reg [0:0]   r_symbol_sync   ;
reg [7:0]   r_slot          ;
reg [3:0]   r_symbol        ;
always@(posedge i_clk) begin
    r_symbol_sync   <=  w_symbol_sync   ;
    if(w_symbol_sync) begin
        r_symbol <=  w_symbol    ;
    end
    if(w_slot_sync) begin
        r_slot <=  w_slot ;
    end
end
reg     [0:0]   rr_symbol_sync  ;
reg     [3:0]   rr_symbol       ;
reg     [3:0]   rrr_symbol  ;
always@(posedge i_clk) begin
    rr_symbol_sync  <=  r_symbol_sync   ;
    if(r_symbol_sync) begin
        rr_symbol   <=  r_symbol    ;
    end
    if(rr_symbol_sync) begin
        rrr_symbol   <=  rr_symbol    ;
    end
end
`ifndef DLFE_AIE_DISABLE
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg     [$clog2(MAX_NIFFT)-1:0]     r_rd_addr           [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [$clog2(MAX_NIFFT)-1:0]     rr_rd_addr          [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [BW_SYM_CNT-1:0]            r_punc_ptr          [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [1-1:0]                     r_rd_rdy            [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [1-1:0]                     rr_rd_rdy           [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [$clog2(MAX_NIFFT)-1:0]     r_sc_idx_offset     [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [$clog2(MAX_NIFFT)-1:0]     r_wr_addr_offset    [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [1-1:0]                     r_rd_data_ptr       [NUM_MEM*NUM_ANT-1:0]   ;
(* keep = "true" *) reg     [1-1:0]                     r_rd_data_axis_id   [NUM_MEM*NUM_ANT-1:0]   ;
`else// DLFE_XILINX_VERSAL
reg     [$clog2(MAX_NIFFT)-1:0]     r_rd_addr           [NUM_MEM*NUM_ANT-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]     rr_rd_addr          [NUM_MEM*NUM_ANT-1:0]   ;
reg     [BW_SYM_CNT-1:0]            r_punc_ptr          [NUM_MEM*NUM_ANT-1:0]   ;
reg     [1-1:0]                     r_rd_rdy            [NUM_MEM*NUM_ANT-1:0]   ;
reg     [1-1:0]                     rr_rd_rdy           [NUM_MEM*NUM_ANT-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]     r_sc_idx_offset     [NUM_MEM*NUM_ANT-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]     r_wr_addr_offset    [NUM_MEM*NUM_ANT-1:0]   ;
reg     [1-1:0]                     r_rd_data_ptr       [NUM_MEM*NUM_ANT-1:0]   ;
reg     [1-1:0]                     r_rd_data_axis_id   [NUM_MEM*NUM_ANT-1:0]   ;
`endif// DLFE_XILINX_VERSAL
generate for(gidx=0;gidx<NUM_MEM*NUM_ANT;gidx=gidx+1) begin : g08_buf_rd_ctrl
always@(posedge i_clk) begin
    if(r_symbol_sync) begin
        r_rd_addr  [gidx]  <= r_rd_fft_base_ptr[gidx/(NUM_MEM*NUM_ANT)]-r_cp_len_base_sr[gidx/(NUM_MEM*NUM_ANT)]-rr_cdd[gidx/(NUM_MEM*NUM_ANT)][gidx%NUM_ANT] ;
        r_punc_ptr [gidx]  <= r_punc_ptr_base[gidx/(NUM_MEM*NUM_ANT)]+r_cp_len_base[gidx/(NUM_MEM*NUM_ANT)] ;
    end
    else if(~|r_smp_cnt[gidx/(NUM_MEM*NUM_ANT)]) begin
        r_rd_addr  [gidx]  <= r_rd_addr[gidx]==(r_rd_fft_base_ptr[gidx/(NUM_MEM*NUM_ANT)]-1'd1) ? {{$clog2(MAX_NIFFT)}{1'b0}} : r_rd_addr[gidx]+1'd1 ;
    end
end
always@(posedge i_clk) begin
    if(r_symbol_sync) begin
        r_rd_rdy[gidx] <= r_sym_det[gidx] ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_rdy[gidx]) begin
        rr_rd_addr      [gidx] <= r_rd_addr[gidx] ;
        r_rd_data_ptr   [gidx] <= r_rd_addr[gidx][0] ;
        if(r_rd_fft_size[gidx/(NUM_MEM*NUM_ANT)]==ORAN_FFT4096) begin 
            case(r_rd_addr[gidx]>>(ORAN_FFT4096-4'd2)) 
                'h0     :   begin r_rd_data_axis_id[gidx] <= 1'b0 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end //0000~1023 
                'h1     :   begin r_rd_data_axis_id[gidx] <= 1'b1 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d1024}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end //1024~2047 
                'h2     :   begin r_rd_data_axis_id[gidx] <= 1'b0 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d2048}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0512}; end //2048~3071 
                'h3     :   begin r_rd_data_axis_id[gidx] <= 1'b1 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d3072}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0512}; end //3072~4095 
                default :   begin r_rd_data_axis_id[gidx] <= 1'b0 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end
            endcase
        end
        else if(r_rd_fft_size[gidx/(NUM_MEM*NUM_ANT)]==ORAN_FFT2048) begin 
            case(r_rd_addr[gidx]>>(ORAN_FFT2048-4'd1)) 
                'h0     :   begin r_rd_data_axis_id[gidx] <= 1'b0 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end //0000~1023 
                'h1     :   begin r_rd_data_axis_id[gidx] <= 1'b1 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d1024}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end //1024~2047 
                default :   begin r_rd_data_axis_id[gidx] <= 1'b0 ; r_sc_idx_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; r_wr_addr_offset[gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000}; end
            endcase
        end
        else if(r_rd_fft_size[gidx/(NUM_MEM*NUM_ANT)]==ORAN_FFT1024||r_rd_fft_size[gidx/(NUM_MEM*NUM_ANT)]==ORAN_FFT0512) begin 
            r_rd_data_axis_id[gidx] <= 1'b0 ;
            r_sc_idx_offset  [gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000};
            r_wr_addr_offset [gidx] <= {{{$clog2(MAX_NIFFT)}{1'b1}}&'d0000};
        end
    end
end
always@(posedge i_clk) begin
    if(rr_symbol_sync) begin
        rr_rd_rdy[gidx] <= r_sym_det[gidx] ;
    end
end
end
endgenerate
reg     [0:0]                       r_mem_wr_en         [NUM_MEM*NUM_ANT-1:0]   ;
reg     [0:0]                       r_mem_rd_en         [NUM_MEM*NUM_ANT-1:0]   ;
reg     [BW_MEM_ADDR-1:0]           r_mem_wr_addr       [NUM_MEM*NUM_ANT-1:0]   ;
reg     [$clog2(MAX_NIFFT)-1:0]     r_mem_rd_addr       [NUM_MEM*NUM_ANT-1:0]   ;
reg     [BW_MEM_DATA-1:0]           r_mem_wr_data       [NUM_MEM*NUM_ANT-1:0]   ;
wire    [0:0]                       w_mem_rd_data_en    [NUM_MEM*NUM_ANT-1:0]   ;
wire    [BW_MEM_DATA-1:0]           w_mem_rd_data       [NUM_MEM*NUM_ANT-1:0]   ;
wire    [0:0]                       w_rd_data_ptr       [NUM_MEM*NUM_ANT-1:0]   ;
wire    [0:0]                       w_rd_data_axis_id   [NUM_MEM*NUM_ANT-1:0]   ;
reg     [NUM_MEM*NUM_ANT-1:0]       r_mem_rd_dout_en                            ;
reg     [2*DO_BW-1:0]               r_mem_rd_dout       [NUM_MEM*NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_MEM*NUM_ANT;gidx=gidx+1) begin : g09_cdd_cp_buf
always@(posedge i_clk) begin
    if(r_wr_en[gidx]) begin
        r_mem_wr_en   [gidx] <=  1'd1 ;
        r_mem_wr_addr [gidx] <=  r_wr_addr[gidx] ;
        r_mem_wr_data [gidx] <=  r_wr_data[gidx] ;
    end
    else begin
        r_mem_wr_en   [gidx] <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(rr_rd_rdy[gidx]) begin
        r_mem_rd_en   [gidx] <=  1'd1 ;
        r_mem_rd_addr [gidx] <=  ((rr_rd_addr[gidx]-r_sc_idx_offset[gidx])>>1)+r_wr_addr_offset[gidx]+(rrr_symbol[0]<<$clog2(SIZE_AXIS_PKT)) ;
    end
    else begin
        r_mem_rd_en   [gidx] <=  1'd0 ;
    end
end
xpm_memory_sdpram #(
    .ADDR_WIDTH_A            (BW_MEM_ADDR               ) 
   ,.ADDR_WIDTH_B            (BW_MEM_ADDR               ) 
   ,.AUTO_SLEEP_TIME         (0                         ) 
   ,.BYTE_WRITE_WIDTH_A      (BW_MEM_DATA               ) 
   ,.CASCADE_HEIGHT          (0                         ) 
   ,.CLOCKING_MODE           ("common_clock"            ) 
   ,.ECC_MODE                ("no_ecc"                  ) 
   ,.MEMORY_INIT_FILE        ("none"                    ) 
   ,.MEMORY_INIT_PARAM       ("0"                       ) 
   ,.MEMORY_OPTIMIZATION     ("true"                    ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                   ) 
   ,.MEMORY_SIZE             (BW_MEM_DATA*MEM_DEPTH     ) 
   ,.MESSAGE_CONTROL         (0                         ) 
   ,.READ_DATA_WIDTH_B       (BW_MEM_DATA               ) 
   ,.READ_LATENCY_B          (3                         ) 
   ,.READ_RESET_VALUE_B      ("0"                       ) 
   ,.RST_MODE_A              ("SYNC"                    ) 
   ,.RST_MODE_B              ("SYNC"                    ) 
   ,.SIM_ASSERT_CHK          (0                         ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                         ) 
   ,.USE_MEM_INIT            (1                         ) 
   ,.WAKEUP_TIME             ("disable_sleep"           ) 
   ,.WRITE_DATA_WIDTH_A      (BW_MEM_DATA               ) 
   ,.WRITE_MODE_B            ("write_first"             )  
)
u02_aie_pkt_sdpram (
    .dbiterrb           (                                           )
   ,.doutb              (   w_mem_rd_data [gidx]                    )
   ,.sbiterrb           (                                           )
   ,.addra              (   r_mem_wr_addr [gidx]                    )
   ,.addrb              (   r_mem_rd_addr [gidx][BW_MEM_ADDR-1:0]   )
   ,.clka               (   i_clk                                   )
   ,.clkb               (   i_clk                                   )
   ,.dina               (   r_mem_wr_data [gidx]                    )
   ,.ena                (   r_mem_wr_en   [gidx]                    )
   ,.enb                (   r_mem_rd_en   [gidx]                    )
   ,.injectdbiterra     (   1'b0                                    )
   ,.injectsbiterra     (   1'b0                                    )
   ,.regceb             (   1'b1                                    )
   ,.rstb               (   i_rst                                   )
   ,.sleep              (   1'b0                                    )
   ,.wea                (   r_mem_wr_en   [gidx]                    )
);
ylib_reg #(
     .WIDTH (    1      ) 
    ,.DEPTH (    5      )) 
u03_rd_data_ptr_dly
(
     .i_clk      (  i_clk                   )
    ,.i_in       (  r_rd_data_axis_id[gidx] )
    ,.o_out      (  w_rd_data_axis_id[gidx] )
);
ylib_reg #(
     .WIDTH (    1      ) 
    ,.DEPTH (    4      )) 
u04_rd_data_ptr_dly
(
     .i_clk      (  i_clk                   )
    ,.i_in       (  r_rd_data_ptr[gidx]     )
    ,.o_out      (  w_rd_data_ptr[gidx]     )
);
ylib_reg #(
     .WIDTH (    1      ) 
    ,.DEPTH (    3      )) 
u05_rd_data_en_dly
(
     .i_clk      (  i_clk                   )
    ,.i_in       (  r_mem_rd_en     [gidx]  )
    ,.o_out      (  w_mem_rd_data_en[gidx]  )
);
always@(posedge i_clk) begin
    r_mem_rd_dout_en[gidx] <= w_mem_rd_data_en[gidx] ;
    if(w_mem_rd_data_en[gidx]) begin
        case(w_rd_data_ptr[gidx])
            'd0     :   r_mem_rd_dout[gidx] <= w_mem_rd_data[gidx][((2*DO_BW)*(00+1)-1)-:(2*DO_BW)] ;
            'd1     :   r_mem_rd_dout[gidx] <= w_mem_rd_data[gidx][((2*DO_BW)*(01+1)-1)-:(2*DO_BW)] ;
            default :   r_mem_rd_dout[gidx] <= {{2*DO_BW}{1'd0}}  ;
        endcase
    end
end
end
endgenerate
wire w_dly_frame_sync  ;
wire w_dly_subfrm_sync ;
wire w_dly_slot_sync   ;
wire w_dly_symbol_sync ;
ylib_reg #(
     .WIDTH(    4               ) 
    ,.DEPTH(    DLY_SYNC        )) 
u03_sync_dly
(
     .i_clk      (  i_clk           )
    ,.i_in       (  {w_frame_sync ,w_subfrm_sync ,w_slot_sync ,w_symbol_sync }              )
    ,.o_out      (  {w_dly_frame_sync,w_dly_subfrm_sync,w_dly_slot_sync,w_dly_symbol_sync}  )
);
reg [BW_SYM_CNT-1:0] r_sym_punc_cnt ;
always@(posedge i_clk) begin
    if(w_dly_symbol_sync) begin
        r_sym_punc_cnt  <= 15'd0 ;
    end
    else begin
        r_sym_punc_cnt <= r_sym_punc_cnt + 1'd1 ;
    end
end
reg [02-1:0] r_cal_en ;
always@(posedge i_clk) begin
    if(w_dly_symbol_sync) begin
        r_cal_en <= i_din_cal_en  ;
    end
end
reg r_dly_frame_sync  ;
reg r_dly_subfrm_sync ;
reg r_dly_slot_sync   ;
reg r_dly_symbol_sync ;
always@(posedge i_clk) begin
    r_dly_frame_sync   <= w_dly_frame_sync   ;     
    r_dly_subfrm_sync  <= w_dly_subfrm_sync  ;
    r_dly_slot_sync    <= w_dly_slot_sync    ;
    r_dly_symbol_sync  <= w_dly_symbol_sync  ;
    o_dout_frame_sync  <= r_dly_frame_sync   ;     
    o_dout_subfrm_sync <= r_dly_subfrm_sync  ;
    o_dout_slot_sync   <= r_dly_slot_sync    ;
    o_dout_symbol_sync <= r_dly_symbol_sync  ;
    if(r_dly_subfrm_sync) begin
        o_dout_subfrm_idx <= w_subfrm ;  
    end                                         
    if(r_dly_slot_sync) begin                   
        o_dout_slot_idx <= w_slot[5:0] ;  
    end                                         
    if(r_dly_symbol_sync) begin                 
        o_dout_symbol_idx <= w_symbol ;  
    end
end
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g10_cbuf_mux
always@(posedge i_clk) begin
    o_dout_en[gidx] <= |r_mem_rd_dout_en ;
    if(|r_mem_rd_dout_en) begin
        if(r_cal_en==ID_CAL_UL_PUNC&&r_sym_punc_cnt>=r_punc_ptr[gidx]) begin
            o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;
        end
        else if(r_rd_fft_size[gidx/NUM_ANT]==ORAN_FFT4096||r_rd_fft_size[gidx/NUM_ANT]==ORAN_FFT2048) begin
            case(w_rd_data_axis_id[gidx]) 
                'd00     :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[gidx] ;   
                'd01     :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[gidx+NUM_ANT] ;   
                 default :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[gidx] ;   
            endcase
        end
        else if(r_rd_fft_size[gidx/NUM_ANT]==ORAN_FFT1024||r_rd_fft_size[gidx/NUM_ANT]==ORAN_FFT0512) begin
            case(gidx)
                0   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[0+NUM_ANT] ;
                1   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[1+NUM_ANT] ;
                2   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[2] ;
                3   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[3] ;
`ifdef DLFE_ANT_PORT_008
                4   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[4+NUM_ANT] ;
                5   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[5+NUM_ANT] ;
                6   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[6] ;
                7   :   o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= r_mem_rd_dout[7] ;
`endif //DLFE_ANT_PORT_008
            endcase
        end
    end
    else begin
        o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;
    end
end
end
endgenerate
`else //DLFE_AIE_DISABLE 
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [$clog2(MAX_NIFFT)-1:0] r_rd_addr   [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [$clog2(MAX_NIFFT)-1:0] rr_rd_addr  [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [BW_SYM_CNT-1:0]        r_punc_ptr  [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [1-1:0]                 r_rd_rdy    [NUM_ANT*NUM_CC-1:0] ;
(* keep = "true" *) reg [1-1:0]                 rr_rd_rdy   [NUM_ANT*NUM_CC-1:0] ;
`else// DLFE_XILINX_VERSAL
reg [$clog2(MAX_NIFFT)-1:0] r_rd_addr   [NUM_ANT*NUM_CC-1:0] ;
reg [$clog2(MAX_NIFFT)-1:0] rr_rd_addr  [NUM_ANT*NUM_CC-1:0] ;
reg [BW_SYM_CNT-1:0]        r_punc_ptr  [NUM_ANT*NUM_CC-1:0] ;
reg [1-1:0]                 r_rd_rdy    [NUM_ANT*NUM_CC-1:0] ;
reg [1-1:0]                 rr_rd_rdy   [NUM_ANT*NUM_CC-1:0] ;
`endif// DLFE_XILINX_VERSAL
generate for(gidx=0;gidx<NUM_ANT*NUM_CC;gidx=gidx+1) begin : g05_buf_rd_ctrl
always@(posedge i_clk) begin
    if(r_symbol_sync) begin
        r_rd_addr  [gidx]  <= r_rd_fft_base_ptr[gidx/NUM_ANT]-r_cp_len_base_sr[gidx/NUM_ANT]-rr_cdd[gidx/NUM_ANT][gidx%NUM_ANT] ;
        r_punc_ptr [gidx]  <= r_punc_ptr_base[gidx/NUM_ANT]+r_cp_len_base[gidx/NUM_ANT] ;
    end
    else if(~|r_smp_cnt[gidx/NUM_ANT]) begin
        r_rd_addr  [gidx]  <= r_rd_addr[gidx]==(r_rd_fft_base_ptr[gidx/NUM_ANT]-1'd1) ? {{$clog2(MAX_NIFFT)}{1'b0}} : r_rd_addr[gidx] + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    if(r_symbol_sync) begin
        r_rd_rdy[gidx] <= r_sym_det[gidx] ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_rdy[gidx]) begin
        rr_rd_addr  [gidx] <= r_rd_addr[gidx] ;
    end
end
always@(posedge i_clk) begin
    if(rr_symbol_sync) begin
        rr_rd_rdy[gidx] <= r_sym_det[gidx] ;
    end
end
end
endgenerate
reg     [0:0]                       r_mem_en        [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [0:0]                       r_mem_we        [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [$clog2(MAX_NIFFT)-1:0]     r_mem_addr      [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [2*DO_BW-1:0]               r_mem_wdata     [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [0:0]                       r_rd_dout_en    [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
wire    [2*DO_BW-1:0]               w_rd_dout_iq    [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [0:0]                       rr_rd_dout_en   [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [2*DO_BW-1:0]               rr_rd_dout_iq   [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [BW_SYM_CNT-1:0]            rr_sym_punc_cnt [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
reg     [02-1:0]                    rr_cal_en       [NUM_CBUF_MEM*NUM_ANT*NUM_CC-1:0] ;
generate for(gidx=0;gidx<NUM_CBUF_MEM*NUM_ANT*NUM_CC;gidx=gidx+1) begin : g06_cdd_cp_buf
always@(posedge i_clk) begin
    if(r_wr_en[gidx/2]&&i_din_symbol_idx[0]==gidx%2) begin
        r_mem_en    [gidx]  <=  1'd1                ;
        r_mem_we    [gidx]  <=  1'd1                ;
        r_mem_addr  [gidx]  <=  r_wr_addr[gidx/2]   ;
        r_mem_wdata [gidx]  <=  r_wr_data[gidx/2]   ;
    end
    else if(rr_rd_rdy[gidx/2]&&rrr_symbol[0]==gidx%2) begin
        r_mem_en    [gidx]  <=  1'd1                ;
        r_mem_we    [gidx]  <=  1'd0                ;
        r_mem_addr  [gidx]  <=  rr_rd_addr[gidx/2]  ;
    end
    else begin
        r_mem_en    [gidx]  <=  1'd0                ;
        r_mem_we    [gidx]  <=  1'd0                ;
    end
end
ylib_rams_sp_wf # (
     .WIDTH     (   2*DI_BW         )
    ,.DEPTH     (   MAX_NIFFT       )
    ,.VENDOR    (   VENDOR          ))
u02_mp_mem
(
     .clk       (  i_clk                    )
    ,.en        (  r_mem_en     [gidx]      )
    ,.we        (  r_mem_we     [gidx]      )
    ,.addr      (  r_mem_addr   [gidx]      )
    ,.di        (  r_mem_wdata  [gidx]      )
    ,.dout      (  w_rd_dout_iq [gidx]      )
);
always@(posedge i_clk) begin
    r_rd_dout_en[gidx] <= r_mem_en[gidx] & ~r_mem_we[gidx] ;
end
always@(posedge i_clk) begin
    rr_rd_dout_en [gidx] <= r_rd_dout_en [gidx] ;
    if(r_rd_dout_en[gidx]) begin
        rr_rd_dout_iq [gidx] <= w_rd_dout_iq [gidx] ;
    end
end
always@(posedge i_clk) begin
    if(r_rd_dout_en[gidx]&~rr_rd_dout_en[gidx]) begin
        rr_cal_en[gidx] <= i_din_cal_en ;
        rr_sym_punc_cnt[gidx] <= 15'd0 ;
    end
    else if(rr_rd_dout_en[gidx]) begin
        rr_sym_punc_cnt [gidx] <= rr_sym_punc_cnt [gidx] + 1'd1 ;
    end
end
end
endgenerate

generate for(gidx=0;gidx<NUM_ANT*NUM_CC;gidx=gidx+1) begin : g07_cbuf_mux
always@(posedge i_clk) begin
    if(rr_rd_dout_en[gidx*NUM_CBUF_MEM+0]) begin
        o_dout_en[gidx] <=  rr_rd_dout_en[gidx*NUM_CBUF_MEM+0]  ;
        if(rr_cal_en[gidx*NUM_CBUF_MEM+0]==ID_CAL_UL_PUNC&&rr_sym_punc_cnt[gidx*NUM_CBUF_MEM+0]>=r_punc_ptr[gidx]) begin
            o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;
        end
        else begin
            if (r_sg_suspens_sym_null_en_latch[gidx] == 0) begin
            o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= rr_rd_dout_iq[gidx*NUM_CBUF_MEM+0]  ;
        end
            else begin
                o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;    
            end
        end
    end
    else if(rr_rd_dout_en[gidx*NUM_CBUF_MEM+1]) begin
        o_dout_en[gidx] <=  rr_rd_dout_en[gidx*NUM_CBUF_MEM+1]  ; 
        if(rr_cal_en[gidx*NUM_CBUF_MEM+1]==ID_CAL_UL_PUNC&&rr_sym_punc_cnt[gidx*NUM_CBUF_MEM+1]>=r_punc_ptr[gidx]) begin
            o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;
        end
        else begin
            o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= rr_rd_dout_iq[gidx*NUM_CBUF_MEM+1]  ;
            if (r_sg_suspens_sym_null_en_latch[gidx] == 0) begin
                o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= rr_rd_dout_iq[gidx*NUM_CBUF_MEM+1]  ;
            end
            else begin
                o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= {{2*DO_BW}{1'd0}}  ;    
            end
        end
    end
    else begin
        o_dout_en[gidx] <=  1'd0    ; 
    end
end
end
endgenerate


wire        w_dly_frame_sync     ;
wire        w_dly_subfrm_sync    ;
wire        w_dly_slot_sync      ;
wire        w_dly_symbol_sync    ;
ylib_reg #(
     .WIDTH(    4               ) 
    ,.DEPTH(    DLY_SYNC        )) 
u03_sync_dly
(
     .i_clk      (  i_clk           )
    ,.i_in       (  {w_frame_sync ,w_subfrm_sync ,w_slot_sync ,w_symbol_sync }              )
    ,.o_out      (  {w_dly_frame_sync,w_dly_subfrm_sync,w_dly_slot_sync,w_dly_symbol_sync}  )
);

wire        w_dly_symbol_sync_prev_1    ;
ylib_reg #(
     .WIDTH(    1               ) 
    ,.DEPTH(    DLY_SYNC-1        )) 
u04_sync_dly
(
     .i_clk      (  i_clk               )
    ,.i_in       (  {w_symbol_sync     })
    ,.o_out      (  {w_dly_symbol_sync_prev_1 })
);

always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        o_dout_frame_sync  [((01)*(i+1)-1)-:(01)] <=  w_dly_frame_sync    ;     
        o_dout_subfrm_sync [((01)*(i+1)-1)-:(01)] <=  w_dly_subfrm_sync   ;
        o_dout_slot_sync   [((01)*(i+1)-1)-:(01)] <=  w_dly_slot_sync     ;
        o_dout_symbol_sync [((01)*(i+1)-1)-:(01)] <=  w_dly_symbol_sync   ;
        if(w_dly_subfrm_sync) begin
            o_dout_subfrm_idx   [((04)*(i+1)-1)-:(04)]  <=  w_subfrm    ;  
        end                                         
        if(w_dly_slot_sync) begin                   
            o_dout_slot_idx     [((06)*(i+1)-1)-:(06)]  <=  w_slot[5:0] ;  
        end                                         
        if(w_dly_symbol_sync) begin                 
            o_dout_symbol_idx   [((04)*(i+1)-1)-:(04)]  <=  w_symbol    ;  
        end
    end
end
`endif //DLFE_AIE_DISABLE 
endmodule
