// ****************************************************************************************************************************
// ****************************************************************************************************************************
// Project Name		: RT8808 23A	
// File Name		: dlfe_layer_if.v
// Date				: 2022.11.16
// Revision			: 0
// Engineer			: Jihoon Han
// Company			: Samsung Electronics
// ****************************************************************************************************************************
// ****************************************************************************************************************************
// (X)Functional Description
// ****************************************************************************************************************************
// ****************************************************************************************************************************
// (X)Revision History              
// [2022.11.16, v0.00, jihoon.han] initial release                            
// ****************************************************************************************************************************

module dlfe_sg_suspensor 
#(
    // Parameter
    parameter  NUM_ANT              =   4
   ,parameter  NUM_I_CHAIN          =   1
   ,parameter  DI_BW                =   15           
   ,parameter  DO_BW                =   15
   ,parameter  CC_NUM               =   2        
)
(	
	/****************************************************************************/
	/* Clock and Reset															*/
	/****************************************************************************/   
    input   wire [1				 		-1:0]	i_rst                  			 // Input Reset, Active High
    ,input  wire [1				 		-1:0]	i_clk           				 // Input Block Clock
	/****************************************************************************/
	/* General Configuration Register											*/
	/****************************************************************************/     
    ,input  wire [1				    		-1:0] 	i_symbol_sync					
    ,input  wire [4				    		-1:0] 	i_symbol_idx              		
    ,input  wire [0				    		  :0] 	i_cc_idx              		    
    ,input  wire [2                         -1:0]   i_din_ant_id                    
    ,input  wire [0                           :0]   i_din_en            
    ,input  wire [2*DI_BW*NUM_I_CHAIN       -1:0]   i_din_iq              
    
	/****************************************************************************/
	/* Control Input															*/
	/****************************************************************************/   	
          		   
	,input  wire [1*CC_NUM						-1:0] 	i_counter_rst					       
	,input  wire [2*CC_NUM						-1:0] 	i_sig_susp_en					 /* 0 = disable, 1 = common_threshold, 2 = sym per threshold */    
	,input  wire [32*14*CC_NUM					-1:0] 	i_sym_per_thrshld_val			
	
	,input  wire [12*CC_NUM						-1:0] 	i_reg_ntone
    ,input  wire [32*CC_NUM						-1:0]	i_comm_thrshld_val
	
	/****************************************************************************/
	/* Output Data																*/
	/****************************************************************************/
	,output reg   [32*14*CC_NUM					-1:0] 	o_upper_threshold_cnt			
	,output reg   [32*14*CC_NUM					-1:0] 	o_max_pwr_per_sym				
    ,output reg   [1*CC_NUM					    -1:0]   o_sg_suspens_sym_null_en
    ,output reg   [1*CC_NUM					    -1:0]   o_pwr_msr_complete            
    ,output reg   [32*CC_NUM   				    -1:0]	o_comm_thrshld_val
);
	
	/********************************************/
    /* Power Measure Per_ANT / Per_CC / Per_Symbol					*/
    /* symbol_sync:     ...|..........................|..........................|....		*/
    /* symbol_idx:      ...|.........0................|...........1..............|....		*/
    /* sigsus_idx:      ...|...ss0-cc0...|...ss1-cc1..|...ss0-cc0...|...ss1-cc1..|....		*/
    /* CC_idx:          ...|.....0.......|......1.....|.....0.......|......1.....|....		*/
    /* ant_idx:         ...|.0..1..2..3..|.0..1..2..3.|.0..1..2..3..|.0..1..2..3.|....		*/
    /********************************************/  
	wire[1*CC_NUM			-1:0]   w_pwr_oe   			;
	wire[1*CC_NUM			-1:0]   w_pwr_msr_complete  ;
	reg[1*CC_NUM			-1:0]   r_pwr_msr_complete_d ;

//	wire[1*CC_NUM			-1:0]   w_bw_chagned   		;
	reg[32*CC_NUM			-1:0]   r_comm_thrshld_val	;
	wire[32*CC_NUM    		-1:0]   w_pwr_accum   		;
	
    dlfe_td_ant_pwr_msr #(
         .NUM_ANT           ( NUM_ANT       )
        ,.NUM_I_CHAIN       ( NUM_I_CHAIN   )
        ,.DI_BW             ( DI_BW         )
        ,.DO_BW             ( DO_BW         )
        ,.CC_NUM            ( CC_NUM        )
    )
    u00_dlfe_td_ant_pwr_msr
    ( 
        .i_rst   				(i_rst          	), 	
        .i_clk   				(i_clk          	), 	
        
		.i_symbol_sync			(i_symbol_sync		), 	
		.i_symbol_idx           (i_symbol_idx		), 	
		.i_cc_idx              	(i_cc_idx    		), 	
		.i_din_ant_id 			(i_din_ant_id		), 	
		.i_din_en     			(i_din_en    		), 	
		.i_din_iq     			(i_din_iq    		), 	
  
        .o_pwr_oe     			(w_pwr_oe			), 
        .o_pwr_msr_complete     (w_pwr_msr_complete ),
        .o_pwr_ant      	   	(w_pwr_accum		)
    );
    
//    assign o_comm_thrshld_val = r_comm_thrshld_val;
        
    /********************************************/
    /* Symbol Valid								*/
    /********************************************/  
	
	reg [14*CC_NUM           -1:0]  r_upper_sym_per_thres_valid;
	reg [1*CC_NUM           -1:0]   r_upper_sym_per_thres_valid_per_cc;
	reg [1*CC_NUM			-1:0]   r_upper_sym_per_thres_valid_en;
	reg [1*CC_NUM			-1:0]   r_upper_com_thres_valid_en;
	reg [1*CC_NUM			-1:0]   r_upper_com_thres_valid;	
    
    reg [1*CC_NUM			-1:0]   r_sym_per_thres_null_en;
	reg [1*CC_NUM			-1:0]   r_com_thres_null_en;
	
	reg [32*14*CC_NUM		-1:0]   r_upper_threshold_cnt;
	reg [32*14*CC_NUM		-1:0]   r_max_pwr_per_sym;
	reg [32*CC_NUM		    -1:0]   r_max_pwr_per_cc;
	reg [1*CC_NUM      		-1:0]   r_sym_valid;
	
    reg [12*CC_NUM			-1:0] 	r_reg_ntone;
	reg	[1*CC_NUM			-1:0]	r_bw_chagned;	
	
//	assign o_upper_threshold_cnt = r_upper_threshold_cnt;
////    assign o_max_pwr_per_sym[(cc_idx*32*14)+: 32*14] = r_max_pwr_per_sym[(cc_idx*32*14)+: 32*14];
//    assign o_max_pwr_per_sym = r_max_pwr_per_sym;
    
    
    always @ (posedge i_clk) begin
        o_upper_threshold_cnt <= r_upper_threshold_cnt;
        o_max_pwr_per_sym  <= r_max_pwr_per_sym;           
        o_comm_thrshld_val <= r_comm_thrshld_val; 	        
    end   
    
    always @ (posedge i_clk) begin
        if(i_symbol_sync) begin
            r_reg_ntone                  <= i_reg_ntone;     
            r_comm_thrshld_val           <= i_comm_thrshld_val;                        
        end    	        
    end   

genvar cc_idx;
genvar symbol_idx, symbol_idx1;
generate for (cc_idx = 0; cc_idx < CC_NUM; cc_idx = cc_idx+1) begin : g00_ss_by_cc   

    always @ (posedge i_clk) begin        
        r_bw_chagned[cc_idx] <= ((i_symbol_sync) && (r_reg_ntone[cc_idx*12+:12] != i_reg_ntone[cc_idx*12+:12]));
        r_sym_valid[cc_idx] <= w_pwr_oe[cc_idx] &&  w_pwr_msr_complete[cc_idx];
        r_upper_sym_per_thres_valid_per_cc[cc_idx] <= r_upper_sym_per_thres_valid[cc_idx*14] || r_upper_sym_per_thres_valid[cc_idx*14 + 1] || r_upper_sym_per_thres_valid[cc_idx*14 + 2] ||  
                                                        r_upper_sym_per_thres_valid[cc_idx*14 + 3] || r_upper_sym_per_thres_valid[cc_idx*14 + 4] || r_upper_sym_per_thres_valid[cc_idx*14 + 5] ||
                                                        r_upper_sym_per_thres_valid[cc_idx*14 + 6] || r_upper_sym_per_thres_valid[cc_idx*14 + 7] || r_upper_sym_per_thres_valid[cc_idx*14 + 8] ||
                                                        r_upper_sym_per_thres_valid[cc_idx*14 + 9] || r_upper_sym_per_thres_valid[cc_idx*14 + 10] || r_upper_sym_per_thres_valid[cc_idx*14 + 11] ||
                                                        r_upper_sym_per_thres_valid[cc_idx*14 + 12] || r_upper_sym_per_thres_valid[cc_idx*14 + 13];
    end    

    for (symbol_idx = 0; symbol_idx < 14; symbol_idx = symbol_idx+1) begin : g00_ss_by_symbol
        always @ (posedge i_clk) begin		   	   
           if (i_symbol_sync) begin
               r_upper_sym_per_thres_valid[cc_idx*14 + symbol_idx] <= 'b0;
           end	
           else begin
//               if ( (cc_idx == i_cc_idx) && (symbol_idx == i_symbol_idx) && (w_pwr_accum[32*cc_idx+:32] > i_sym_per_thrshld_val[(cc_idx*14*32 + symbol_idx*32)	+: 32]) ) begin
               if ( (symbol_idx == i_symbol_idx) && (w_pwr_accum[32*cc_idx+:32] > i_sym_per_thrshld_val[(cc_idx*14*32 + symbol_idx*32)	+: 32]) ) begin
                   r_upper_sym_per_thres_valid[cc_idx*14 + symbol_idx] <= 'b1;
               end 
               else begin
                   r_upper_sym_per_thres_valid[cc_idx*14 + symbol_idx] <= 'b0;
               end               
           end
        end
    end        
    
	always @ (posedge i_clk) begin
		r_upper_sym_per_thres_valid_en[cc_idx] 	<= (i_sig_susp_en[cc_idx*2+:2] == 2'd2);
		r_upper_com_thres_valid_en[cc_idx] 		<= (i_sig_susp_en[cc_idx*2+:2] == 2'd1);
		if (i_symbol_sync) begin
	       r_upper_com_thres_valid[cc_idx] <= 'b0;
	    end	
	    else begin
	        if (w_pwr_accum[32*cc_idx+:32] > r_comm_thrshld_val[32*cc_idx+: 32]) begin
	            r_upper_com_thres_valid[cc_idx] <= 'b1;
	        end 
	    end
    end	    

    /********************************************/
    /* Max Power Per Symbol						*/
    /********************************************/  	
    always @ (posedge i_clk) begin
        if((i_rst)||(i_counter_rst[cc_idx] == 1)||(r_bw_chagned[cc_idx])||(i_symbol_sync)) begin
            r_max_pwr_per_cc[(cc_idx*32)+: 32] <= 0;
        end
        else if(w_pwr_oe[cc_idx]) begin
            if (r_max_pwr_per_cc[(cc_idx*32)+: 32] < w_pwr_accum[(cc_idx*32)+: 32]) begin 
                r_max_pwr_per_cc[(cc_idx*32)+: 32] <= w_pwr_accum[(cc_idx*32)+: 32];
            end
        end
    end
    
    for (symbol_idx1 = 0; symbol_idx1 < 14; symbol_idx1 = symbol_idx1+1) begin : g01_ss_by_symbol
    
        always @ (posedge i_clk) begin
            if((i_rst)||(i_counter_rst[cc_idx] == 1)||(r_bw_chagned[cc_idx])) begin
                r_max_pwr_per_sym[(cc_idx*32*14 + 32*symbol_idx1)+: 32] <= 0;
            end
//            else if((r_sym_valid[cc_idx]) && (r_max_pwr_per_sym[(cc_idx*32*14 + symbol_idx1*32)+: 32] < r_max_pwr_per_cc[(32*cc_idx)+:32]) && (cc_idx == i_cc_idx) && (symbol_idx1 == i_symbol_idx)) begin
            else if((r_sym_valid[cc_idx]) && (r_max_pwr_per_sym[(cc_idx*32*14 + symbol_idx1*32)+: 32] < r_max_pwr_per_cc[(32*cc_idx)+:32]) && (symbol_idx1 == i_symbol_idx)) begin
                r_max_pwr_per_sym[(cc_idx*32*14 + symbol_idx1*32)+: 32] <= r_max_pwr_per_cc[(32*cc_idx)+:32];
            end
        end
           
        /********************************************/
        /* Upper Threshold Count					*/
        /********************************************/  
            
        always @ (posedge i_clk) begin
            if((i_rst)||(i_counter_rst[cc_idx] == 1)||(r_bw_chagned[cc_idx])) begin
                r_upper_threshold_cnt[(32*14*cc_idx + 32*symbol_idx1)+: 32] <= 0;
            end
            else if( r_sym_valid[cc_idx] 
                    && ( ( (r_upper_sym_per_thres_valid_en[cc_idx]) && (r_upper_sym_per_thres_valid_per_cc[cc_idx]) ) || ( (r_upper_com_thres_valid_en[cc_idx]) && (r_upper_com_thres_valid[cc_idx])) )
                    && (symbol_idx1 == i_symbol_idx) ) begin 
//                    && (cc_idx == i_cc_idx) && (symbol_idx1 == i_symbol_idx) ) begin
                r_upper_threshold_cnt[(32*14*cc_idx + 32*symbol_idx1)+: 32] <= r_upper_threshold_cnt[(32*14*cc_idx + 32*symbol_idx1)+: 32] + 1;
            end
        end	
	
	end
    /********************************************/
    /* Signal Suspension						*/
    /********************************************/  
        
    always @ (posedge i_clk) begin
        r_pwr_msr_complete_d[cc_idx]       <= w_pwr_msr_complete[cc_idx];
		if(i_rst) begin
			r_sym_per_thres_null_en[cc_idx]  <= 0;
			r_com_thres_null_en[cc_idx]      <= 0;
//			r_pwr_msr_complete_d[cc_idx]     <= 0;
		end
		else if(w_pwr_oe) begin
			r_sym_per_thres_null_en[cc_idx]    <= (r_upper_sym_per_thres_valid_en[cc_idx]  && r_upper_sym_per_thres_valid_per_cc[cc_idx]);		  					  
		  	r_com_thres_null_en[cc_idx]        <= (r_upper_com_thres_valid_en[cc_idx]      && r_upper_com_thres_valid[cc_idx]);	  	
		end 
    end
    		
	always @ (posedge i_clk) begin
		if(i_rst) begin
			o_sg_suspens_sym_null_en[cc_idx] <= 1'd0;
			o_pwr_msr_complete[cc_idx]       <= 0;
		end
		else begin
			o_sg_suspens_sym_null_en[cc_idx] <= (r_sym_per_thres_null_en[cc_idx] || r_com_thres_null_en[cc_idx]);
			o_pwr_msr_complete[cc_idx]       <= r_pwr_msr_complete_d[cc_idx];
		end 
    end
end
endgenerate	
endmodule
