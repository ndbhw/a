// ****************************************************************************************************************************
// ****************************************************************************************************************************
// Project Name		: RT8808 23A	
// File Name		: dlfe_td_ant_pwr_msr.v
// Date				: 2023.08.22
// Revision			: 0
// Engineer			: Jihoon Han
// Company			: Samsung Electronics
// ****************************************************************************************************************************
// ****************************************************************************************************************************
// (X)Functional Description
// ****************************************************************************************************************************
// ****************************************************************************************************************************
// (X)Revision History              
// [2023.08.22, v0.00, jihoon.han] initial release                            
// ****************************************************************************************************************************

module dlfe_td_ant_pwr_msr 
#(
     // Parameter                           
     parameter  NUM_ANT              =   4  
    ,parameter  NUM_I_CHAIN          =   1  
    ,parameter  DI_BW                =   15 
    ,parameter  DO_BW                =   15 
    ,parameter  CC_NUM               =   2    
)
(	
	/****************************************************************************/
	/* Clock and Reset															*/
	/****************************************************************************/   
    input  wire [1				 		       -1:0]	i_rst                  			 // Input Reset, Active High
    ,input  wire [1				 		       -1:0]	i_clk           				 // Input Block Clock
	/****************************************************************************/
	/* Input Write Timing														*/
	/****************************************************************************/             			    	
        
    ,input  wire [1 						-1:0] 	i_symbol_sync					
    ,input  wire [4				    		-1:0] 	i_symbol_idx              		
    ,input  wire [0				    		  :0] 	i_cc_idx              		    
    ,input  wire [2                         -1:0]   i_din_ant_id                    
    ,input  wire [0                           :0]   i_din_en            
    ,input  wire [2*DI_BW*NUM_I_CHAIN       -1:0]   i_din_iq      

	/****************************************************************************/
	/* Output Data																*/
	/****************************************************************************/
    ,output reg	[1*CC_NUM						-1:0]	o_pwr_oe
    ,output reg	[1*CC_NUM						-1:0]	o_pwr_msr_complete 						    			
   	,output reg	[32*CC_NUM          			-1:0]	o_pwr_ant 				
);
		
	/********************************************/
    /* Latch Input Data							*/
    /********************************************/  
	wire[1			-1:0]   w_symbol_sync;
	wire[1			-1:0]	w_din_en_d;
	reg [1			-1:0]	w_din_en_d_d;
	reg [1			-1:0]	w_din_en_d_d_d;
	reg [16			-1:0]	w_dlifft_i;
	reg [16			-1:0]	w_dlifft_q;
	

    always @ (posedge i_clk) begin
	    w_dlifft_i		<= {i_din_iq[14], i_din_iq[(0*15)	+: 15]};	  // I
	    w_dlifft_q		<= {i_din_iq[29], i_din_iq[(1*15)	+: 15]};	  // Q	    
    end
    
	zdelay_wo_rst # (
        .WIDTH  (2	       		),
        .ZDEPTH (6				) 
    )
    u99_zdelay_rden
    (        
        .clk    (i_clk              	), 
        .i_in   ({i_symbol_sync, i_din_en}),
		.o_out  ({w_symbol_sync, w_din_en_d})
    );
    
    always @ (posedge i_clk) begin
		w_din_en_d_d <= w_din_en_d;
		w_din_en_d_d_d <= w_din_en_d_d;
	end
	
	genvar cc_idx;
	generate for(cc_idx = 0; cc_idx < CC_NUM; cc_idx = cc_idx + 1) begin : g00_output_check
        always @ (posedge i_clk) begin
            if (i_cc_idx == cc_idx) begin
                if ((w_din_en_d_d_d == 1) && (w_din_en_d_d == 0)) begin 		                            
                      o_pwr_oe[cc_idx+:1] <= 1;
                      o_pwr_ant[cc_idx*32+:32] <= w_sum_ii_qq_accum_per_sym[12	+: 32];                      	      		          	 		
                end
                else begin
                      o_pwr_oe[cc_idx+:1] <= 0;                      
                end		
            end
        end    
        
        always @ (posedge i_clk) begin
            if (i_symbol_sync) begin
                o_pwr_msr_complete[cc_idx+:1] <= 'b0;
            end	
            else begin
                if (i_cc_idx == cc_idx) begin
                    if ((w_din_en_d_d_d == 1) && (w_din_en_d_d == 0) && (i_din_ant_id == 2'b11) ) begin 		                            
                          o_pwr_msr_complete[cc_idx+:1] <= 1;                                          	      		          	 		
                    end                		
                end
            end
        end
    end
    endgenerate
    
	/********************************************/
    /* Multiplication(I*I+Q*Q)					*/
    /********************************************/
	wire [48		-1:0]   w_pwr_mult_ii;
	wire [48		-1:0]   w_pwr_mult_qq;

	dsp48e2_mult #(						// I*I or Q*Q
        .DEVICE ( "ULTRASCALE" )   // "C" or "PCIN"
    )
    u00_dlfe_mult_48_func
    (           
        .CLK            (i_clk                ) , // [1  -1: 0] 

        .DATA_IN_A      ({ {(29-16){w_dlifft_i[16-1]}}, w_dlifft_i} ) , // A Port           [29 -1: 0] 
        .DATA_IN_B      ({ {(17-16){w_dlifft_i[16-1]}}, w_dlifft_i} ) , // B Port           [17 -1: 0] 
        
        .DATA_OUT       (w_pwr_mult_ii	)  // P port           [58 -1: 0]         
    );

    dsp48e2_mult #(						// I*I or Q*Q
        .DEVICE ( "ULTRASCALE" )   // "C" or "PCIN"
    )
    u01_dlfe_mult_48_func
    (           
        .CLK            (i_clk                ) , // [1  -1: 0] 

        .DATA_IN_A      ({ {(29-16){w_dlifft_q[16-1]}}, w_dlifft_q} ) , // A Port           [29 -1: 0] 
        .DATA_IN_B      ({ {(17-16){w_dlifft_q[16-1]}}, w_dlifft_q} ) , // B Port           [17 -1: 0] 
        
        .DATA_OUT       (w_pwr_mult_qq	)  // P port           [58 -1: 0]         
    );
		
	/********************************************/
    /* Add Mult Out								*/
    /********************************************/  
	reg [33 		-1:0]   w_sum_ii_qq;			
    always @ (posedge i_clk) begin
		
		if(w_din_en_d == 0) begin
    		w_sum_ii_qq <= 0;	
    	end
    	else begin //if (w_din_en_d) begin
    		w_sum_ii_qq <= w_pwr_mult_ii[0	+: 33] + w_pwr_mult_qq[0 +: 33]; // S1 = I^2 + Q^2		
    	end   		
    end

	/********************************************/
    /* Add Mult Out								*/
    /********************************************/  
	reg [44		-1:0]   w_sum_ii_qq_accum_per_sym	;	                 
    
    /* Accum 3276 Sample => 12 bit extension */      
	always @ (posedge i_clk) begin
    	if(w_din_en_d_d == 0) begin
    		w_sum_ii_qq_accum_per_sym <= 0;	
    	end
    	else begin // if (w_din_en_d_d) begin
    		w_sum_ii_qq_accum_per_sym <= w_sum_ii_qq_accum_per_sym + {{(11){w_sum_ii_qq[32-1]}}, w_sum_ii_qq};  // sum all S1 of sample within 1 symbol
    	end 
    end
   
    reg [13			-1:0]   w_dlfft_sample_cnt	;
    always @ (posedge i_clk) begin
    	if(w_din_en_d == 0) begin
    		w_dlfft_sample_cnt 	<= 0;
    	end
    	else begin //if (w_din_en_d) begin /* upto 4096 */
    		w_dlfft_sample_cnt	<= w_dlfft_sample_cnt + 1;
    	end    	    	
    end
							
    
endmodule
