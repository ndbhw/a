library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;

library work;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;

entity dsp48e2_mult is
generic(
    DEVICE                      : string  := "7SERIES"  -- "7SERIES": DSP48E1, "ULTRASCALE": DSP48E2
    );
port(
    CLK                         : in  std_logic;

    DATA_IN_A                   : in  std_logic_vector(29 downto 0);
    DATA_IN_B                   : in  std_logic_vector(17 downto 0);

    DATA_OUT                    : out std_logic_vector(47 downto 0)
    );
end dsp48e2_mult;

architecture arc_dsp48e2_mult of dsp48e2_mult is

component DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PREADDER_MODE         : string  :=        "ADD";  -- "ADD" or "SUB" 
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;

    A_nREG                      : integer :=           2 ;  -- 0, 1, 2
    B_nREG                      : integer :=           2 ;  -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ;
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    CLK                         : in  std_logic;

    ALUMODE_IN                  : in  std_logic_vector( 3 downto 0);
    OPMODE_IN                   : in  std_logic_vector( 8 downto 0);

    C_IN                        : in  std_logic_vector(47 downto 0);
    A_IN                        : in  std_logic_vector(29 downto 0);
    D_IN                        : in  std_logic_vector(26 downto 0);
    B_IN                        : in  std_logic_vector(17 downto 0);

    P_CIN                       : in  std_logic_vector(47 downto 0);
    P_COUT                      : out std_logic_vector(47 downto 0);

    P_OUT                       : out std_logic_vector(47 downto 0);
    CRRY_OUT                    : out std_logic
    );
end component;

signal w_data_a               	: std_logic_vector(29 downto 0);
signal w_data_b               	: std_logic_vector(17 downto 0);
signal result_m                 : std_logic_vector(47 downto 0);

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            w_data_a	<= DATA_IN_A;
			w_data_b	<= DATA_IN_B;   
        end if;
    end process;

    -- a * b 
    U_Low_MULT  : DSP48E_MULT 
	generic map(
		DEVICE              => DEVICE, 
		DSP48_MODECTRL      => FALSE, 
		DSP48_PREADDER_USE  => FALSE, 
		DSP48_PREADDER_MODE => "ADD", 
		DSP48_PCIN_USE      => FALSE, 
		DSP48_PCOUT_USE     => FALSE, 
							 
		A_nREG              => 2, 
		B_nREG              => 2, 
							 
		C_EN                => FALSE, 
		RND_SYMMETRY        => FALSE
	) 
	port map(
		CLK         =>  CLK, 
					
		ALUMODE_IN  =>  x"0", 
		OPMODE_IN   =>  (others => '0'), 
					
		C_IN        =>  (others => '0'), 
		A_IN        =>  w_data_a, 
		D_IN        =>  (others => '0'), 
		B_IN        =>  w_data_b, 
					
		P_CIN       =>  (others => '0'), 
		P_COUT      =>  open, 
					
		P_OUT       =>  result_m, 
		CRRY_OUT    =>  open
	); 

    DATA_OUT <= result_m;

end arc_dsp48e2_mult;
