// *****************************************************************************
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************
//
// ***************************************************************************** 
// 
// Copyright (C) 2022, Samsung Electronics Co., LTD. All Right Reserved.
//
// Department  : FPGA Part/H/W R&D Group
// Author      : MoonHyeok Jang (mmhh.jang@samsung.com)
// 
// *****************************************************************************
// Function    : dlfe_multadd_58_func.v
// Description : 2's Complement Multiplier + Adder (AxB+C)
//               or 
//               2's Complement Multiplier + CasCade Adder (AxB+PCIN)
//
//               * Using DSP58 Primitive (VERSAL ACAP Device DSP Engine) *
// *****************************************************************************
// Revision History                                                           
// *****************************************************************************
// [2022.05.27, v1.00, mmhh.jang] Initial Release
// *****************************************************************************


//===========================//
// Processing Latency: 4 CLK //
//===========================//



module dlfe_multadd_58_func #(
    parameter  ADD_SRC = "C"    // "C" or "PCIN"
)
( 
    input  wire  [1  -1: 0] i_rst    ,
    input  wire  [1  -1: 0] i_clk    ,

    input  wire  [27 -1: 0] i_a      , // A Port
    input  wire  [24 -1: 0] i_b      , // B Port
    input  wire  [58 -1: 0] i_c      , // C Port
    input  wire  [58 -1: 0] i_p_c    , // PCIN  port
                                             
    output wire  [58 -1: 0] o_p      , // P port
    output wire  [58 -1: 0] o_p_c      // PCOUT port
);
    

    localparam  AREG   = 2;  // Do not Touch 
    localparam  BREG   = 2;  // Do not Touch 
    localparam  CREG   = 1;  // Do not Touch
    localparam  MREG   = 1;  // Do not Touch
    localparam  PREG   = 1;  // Do not Touch

    
    localparam  [5   -1: 0]  INMODE  = 5'b0_0000;
    localparam  [9   -1: 0]  OPMODE  = (ADD_SRC == "C") ? 9'b0_0011_0101 : 9'b0_0001_0101;   // W=0, X=M, Y=M, Z=(C or PCIN)
    localparam  [4   -1: 0]  ALUMODE = 4'b0000;      


    // AxB: AREG(or BREG)+MREG =  2+1 = 3CLK 
    wire    [34    -1: 0]    w_a ;
    wire    [24    -1: 0]    w_b ;

    assign  w_a   =   { {(34-27){i_a[26]}}, i_a };
    assign  w_b   =   i_b                        ;

    // +C (or +PCIN): PREG = 1 = 1CLK 
    reg     [58   -1: 0]     r_c_tmp = 0;
    reg     [58   -1: 0]     r_c     = 0;

    always @ (posedge i_clk) begin
        r_c_tmp   <= i_c;
        r_c       <= r_c_tmp;
    end

    DSP58 #(
        .ACASCREG          ( AREG       ),
        .ALUMODEREG        ( 1          ),
        .AMULTSEL          ( "A"        ),
        .AREG              ( AREG       ),
        .BCASCREG          ( BREG       ),
        .BMULTSEL          ( "B"        ),
        .BREG              ( BREG       ),
        .CREG              ( CREG       ),
        .DSP_MODE          ( "INT24"    ),
        .MREG              ( MREG       ),
        .PREG              ( PREG       ),
        .RESET_MODE        ( "ASYNC"    ),
        .USE_MULT          ( "MULTIPLY" )  
    )
    u00_dsp58_primitive
    (
      .ACOUT            (           ),   // output
      .BCOUT            (           ),   // output 
      .CARRYCASCOUT     (           ),   // output
      .CARRYOUT         (           ),   // output
      .MULTSIGNOUT      (           ),   // output
      .OVERFLOW         (           ),   // output
      .P                ( o_p       ),   // output
      .PATTERNBDETECT   (           ),   // output
      .PATTERNDETECT    (           ),   // output
      .PCOUT            ( o_p_c     ),   // output
      .UNDERFLOW        (           ),   // output
      .XOROUT           (           ),   // output

      .A                ( w_a       ),   // input
      .ACIN             ( 34'd0     ),   // input 
      .ALUMODE          (           ),   // input
      .ASYNC_RST        ( i_rst     ),   // input 
      .B                ( w_b       ),   // input 
      .BCIN             ( 24'd0     ),   // input 
      .C                ( r_c       ),   // input 
      .CARRYCASCIN      ( 1'b0      ),   // input 
      .CARRYIN          ( 1'b0      ),   // input 
      .CARRYINSEL       ( 3'b000    ),   // input 
      .CEA1             ( 1'b1      ),   // input 
      .CEA2             ( 1'b1      ),   // input 
      .CEAD             ( 1'b1      ),   // input 
      .CEALUMODE        ( 1'b1      ),   // input 
      .CEB1             ( 1'b1      ),   // input 
      .CEB2             ( 1'b1      ),   // input 
      .CEC              ( 1'b1      ),   // input 
      .CECARRYIN        ( 1'b1      ),   // input 
      .CECTRL           ( 1'b1      ),   // input 
      .CED              ( 1'b1      ),   // input 
      .CEINMODE         ( 1'b1      ),   // input 
      .CEM              ( 1'b1      ),   // input 
      .CEP              ( 1'b1      ),   // input 

      .CLK              ( i_clk     ),   // input 
      .D                ( 27'd0     ),   // input 
      .INMODE           ( INMODE    ),   // input 
      .MULTSIGNIN       ( 1'b0      ),   // input 
      .NEGATE           ( 3'b000    ),   // input 
      .OPMODE           ( OPMODE    ),   // input 
      .PCIN             ( i_p_c     ),   // input 
      .RSTA             ( 1'b0      ),   // input 
      .RSTALLCARRYIN    ( 1'b0      ),   // input 
      .RSTALUMODE       ( 1'b0      ),   // input 
      .RSTB             ( 1'b0      ),   // input 
      .RSTC             ( 1'b0      ),   // input 
      .RSTCTRL          ( 1'b0      ),   // input 
      .RSTD             ( 1'b0      ),   // input 
      .RSTINMODE        ( 1'b0      ),   // input 
      .RSTM             ( 1'b0      ),   // input 
      .RSTP             ( 1'b0      )    // input 
    );
  

endmodule
