////////////////////////////////////////////////////////////////////////////////
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10/FSU20
//                 oRU : DCM RT4419/RT4422
//                       VzW RT8808/RF4440d
//                       VDF RF4448/RF4449
//                       MSTR_V02
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_ofdm_mod
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe OFDM Modulation (configurable cell multiplexing) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.15 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.10.19 | jyzoo.lee     | Xilinx Support
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.12.16 | jyzoo.lee     | Supports Xilinx 4k IFFT
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Supports Processing for Calibraion Symbol
//  ------------+---------------+-----------------------------------------------
//   2021.03.30 | jyzoo.lee     | AIE IFFT Support
//  ------------+---------------+-----------------------------------------------
//   2021.05.18 | jyzoo.lee     | Optimized Memory for AIE IFFT Interface 
//  ------------+---------------+-----------------------------------------------
//   2021.07.12 | jyzoo.lee     | AIE 1K,2K IFFT Support
//  ------------+---------------+-----------------------------------------------
//   2021.10.01 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//   2021.12.06 | jyzoo.lee     | Add gaurd and reset for ifft when changing bw
//  ------------+---------------+-----------------------------------------------
//   2021.12.07 | jyzoo.lee     | Add watchdog and reset for intel cell mux  
//  ------------+---------------+-----------------------------------------------
//   2022.01.13 | jyzoo.lee     | Custom FFT Support
//  ------------+---------------+-----------------------------------------------
//   2022.02.03 | jyzoo.lee     | Remove the AAI
//  ------------+---------------+-----------------------------------------------
//   2021.03.16 | jyzoo.lee     | Add packet recovery for AIE IFFT
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_ofdm_mod
#(
     parameter  NUM_CC              =   1           
    ,parameter  NUM_ANT             =   4
    ,parameter  NUM_I_CHAIN         =   1
    ,parameter  NUM_O_CHAIN         =   1
    ,parameter  MAX_NIFFT           =   2048 
    ,parameter  DI_BW               =   16           
    ,parameter  DO_BW               =   16           
`ifndef DLFE_AIE_DISABLE
    ,parameter  DIO_BW_AIE          =  `DLFE_DIO_BW_AIE
    ,parameter  DIO_NB_AIE          =  `DLFE_DIO_NB_AIE
`endif //DLFE_AIE_DISABLE
    ,parameter  VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire    [01*NUM_CC-1:0]                         i_rst                
    ,   input   wire                                            i_clk                  
            
    //--- from dlfe_param_if
    ,   input   wire    [22*NUM_CC-1:0]                         i_dlfe_par_1050
    ,   input   wire    [03*NUM_CC-1:0]                         i_dlfe_par_1208
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_120c
    
    //--- from dlfe_ifft_mapper
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_I_CHAIN-1:0] i_din_cc_id
    ,   input   wire    [$clog2(NUM_ANT)*NUM_I_CHAIN-1:0]       i_din_ant_id
    ,   input   wire    [04-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_ant_scale
    ,   output  reg     [01-1:0]                                o_dout_frame_sync
    ,   output  reg     [01-1:0]                                o_dout_symbol_sync
    ,   output  reg     [04-1:0]                                o_dout_symbol_idx
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_en
    ,   output  reg     [2*DO_BW*NUM_O_CHAIN-1:0]               o_dout_iq        
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_O_CHAIN-1:0] o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_O_CHAIN-1:0]       o_dout_ant_id
    ,   output  reg     [02-1:0]                                o_dout_cal_en

`ifndef DLFE_AIE_DISABLE
    ,   input   wire                                            i_aie_clk
    ,   input   wire    [01*NUM_CC-1:0]                         i_aie_rst
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tready
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tvalid
    ,   output  wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]             o_aie_ifft_tdata
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tlast
    ,   output  wire    [DIO_BW_AIE/8*DIO_NB_AIE-1:0]           o_aie_ifft_tkeep
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tready
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tvalid
    ,   input   wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]             i_aie_ifft_tdata
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tlast
    ,   output  wire    [22*NUM_CC-1:0]                         o_dlfe_rpt_1040
    ,   output  wire    [22*NUM_CC-1:0]                         o_dlfe_rpt_1044
    ,   output  wire    [32*NUM_CC-1:0]                         o_dlfe_rpt_1054
`else// DLFE_AIE_DISABLE
    ,   output  wire    [13*NUM_CC-1:0]                         o_dlfe_rpt_1048
    ,   output  wire    [32*NUM_CC-1:0]                         o_dlfe_rpt_104c
`endif// DLFE_AIE_DISABLE
);

//Parameter Local Logic
localparam      CC_REF                      =       0                                                                   ;
localparam      CHAIN_REF                   =       0                                                                   ;
localparam      BW_IFFT_IN                  =       16                                                                  ;
localparam      BW_IFFT_OUT                 =       28                                                                  ;
localparam      BW_SHIFTA                   =       6                                                                   ;
localparam      NFFT_0512                   =       13'd512                                                             ;
localparam      NFFT_1024                   =       13'd1024                                                            ;
localparam      NFFT_2048                   =       13'd2048                                                            ;
localparam      NFFT_4096                   =       13'd4096                                                            ;
localparam      DLY_THIS                    =       22'd3                                                               ;
localparam      ORAN_FFT0512                =       4'h9                                                                ;
localparam      ORAN_FFT1024                =       4'ha                                                                ;
localparam      ORAN_FFT2048                =       4'hb                                                                ;
localparam      ORAN_FFT4096                =       4'hc                                                                ;
localparam      DLY_RST                     =       3                                                                   ;
`ifndef DLFE_VENDOR_FFT_DISABLE
localparam      DLY_NIFFT_0512              =       VENDOR=="Intel" ? 22'd666 +DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd1158+22'd3-NFFT_0512+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd1152-NFFT_0512+DLY_THIS : (MAX_NIFFT==NFFT_1024) ? 22'd1159-NFFT_0512+DLY_THIS :22'd0   ;
localparam      DLY_NIFFT_1024              =       VENDOR=="Intel" ? 22'd1169+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd2182+22'd3-NFFT_1024+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd2195-NFFT_1024+DLY_THIS : (MAX_NIFFT==NFFT_1024) ? 22'd2183-NFFT_1024+DLY_THIS :22'd0   ;
localparam      DLY_NIFFT_2048              =       VENDOR=="Intel" ? 22'd2214+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd4249+22'd3-NFFT_2048+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd4243-NFFT_2048+DLY_THIS : (MAX_NIFFT==NFFT_1024) ? 22'd0                       :22'd0   ;
localparam      DLY_NIFFT_4096              =       VENDOR=="Intel" ? 22'd2214+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd8345+22'd3-NFFT_4096+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd0                       : (MAX_NIFFT==NFFT_1024) ? 22'd0                       :22'd0   ;
`else //DLFE_VENDOR_FFT_DISABLE
localparam      DLY_NIFFT_0512              =       22'd555 +DLY_THIS ;
localparam      DLY_NIFFT_1024              =       22'd1068+DLY_THIS ;
localparam      DLY_NIFFT_2048              =       22'd2101+DLY_THIS ;
localparam      DLY_NIFFT_4096              =       22'd4150+DLY_THIS ;
`endif //DLFE_VENDOR_FFT_DISABLE
`ifndef DLFE_AIE_DISABLE
localparam      PL_SIZE_PACKET_AAI          =       1027                                                                ;
localparam      AIE_SIZE_PACKET_AAI         =       1024                                                                ;
localparam      VALID_STATE_WDOG_PL2AIE     =       2'd0                                                                ;
localparam      INVALID_STATE_WDOG_PL2AIE   =       2'd1                                                                ;
localparam      AIE_IFFT_AXIS00_D00         =       {^31'h0,31'h0}                                                      ;
localparam      AIE_IFFT_AXIS00_D01         =       {^31'h0,31'h1}                                                      ;
localparam      AIE_IFFT_AXIS00_D02         =       {^31'h0,31'h2}                                                      ; 
localparam      AIE_IFFT_AXIS00_D03         =       {^31'h0,31'h0}                                                      ;
localparam      AIE_IFFT_AXIS00_D04         =       {^31'h0,31'h1}                                                      ;
localparam      PL2AIE_ASYNC_FIFO_DEPTH     =       16                                                                  ;
localparam      AIE2PL_ASYNC_FIFO_DEPTH     =       256                                                                 ;
localparam      CIN_NFFT_0512               =       {{DIO_BW_AIE/2}{1'b1}}&'d3                                          ;
localparam      CIN_NFFT_1024               =       {{DIO_BW_AIE/2}{1'b1}}&'d2                                          ;
localparam      CIN_NFFT_2048               =       {{DIO_BW_AIE/2}{1'b1}}&'d1                                          ;
localparam      CIN_NFFT_4096               =       {{DIO_BW_AIE/2}{1'b1}}&'d0                                          ;
localparam      SHIFT_A_XCAL                =       4                                                                   ;
localparam      BW_SCALE_A                  =       25                                                                  ;
localparam      SHIFT_B                     =       4'd7                                                                ;
`else //DLFE_AIE_DISABLE
localparam      SHIFT_A_XCAL                =       0                                                                   ;
localparam      BW_SCALE_A                  =       36                                                                  ;
localparam      SHIFT_B                     =       4'd10                                                               ;
`endif//DLFE_AIE_DISABLE

//Logic Variable
genvar gidx ;
integer i,j ;

reg [1-1:0]   r_frame_sync  ;
reg [1-1:0]   rr_frame_sync ;
reg [4-1:0]   r_mu          ;
reg [3-1:0]   r_shift_a   [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    r_frame_sync    <=  i_din_frame_sync ;
    rr_frame_sync   <=  r_frame_sync     ;
    if(i_din_frame_sync) begin 
        r_mu    <=  i_din_mu    ;
        for(i=0;i<NUM_CC;i=i+1) begin
            r_shift_a[i] <= i_dlfe_par_1208[((03)*(i+1)-1)-:(03)] ;
        end
    end
end
reg [4-1:0]  r_fft_size [NUM_CC-1:0] ;
reg [12-1:0] r_ntone    [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_fft_size [i] = i_din_fft_size [((04)*(i+1)-1)-:(04)] ;
        r_ntone    [i] = i_dlfe_par_120c[((12)*(i+1)-1)-:(12)] ;
    end
end
reg [4-1:0]  rr_fft_size    [NUM_CC-1:0] ;
reg [12-1:0] rr_ntone       [NUM_CC-1:0] ;
reg [0:0]    r_bw_event_n   [NUM_CC-1:0] ;
reg [01*NUM_O_CHAIN-1:0] r_ifft_symbol_rst_n    [NUM_CC-1:0] ;
reg [01*NUM_O_CHAIN-1:0] r_dout_en ;
`ifndef DLFE_WDOG_DISABLE
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            rr_fft_size [i] <= r_fft_size [i] ;
            rr_ntone    [i] <= r_ntone    [i] ;
            r_bw_event_n[i] <= (r_fft_size[i]==rr_fft_size[i]) && (r_ntone[i]==rr_ntone[i]) && (r_ntone[i]!=12'd0);
        end
    end
end
`ifndef DLFE_CELL_MUX_DISABLE
generate if(NUM_CC>1) begin : gen_cell_sw_ifft_rst
always@(posedge i_clk) begin
    r_dout_en <= o_dout_en ;
    if(rr_fft_size[0]!=rr_fft_size[1]) begin
        for(i=0;i<NUM_CC;i=i+1) begin
            for(j=0;j<NUM_O_CHAIN;j=j+1) begin
                r_ifft_symbol_rst_n [i][j] <= (~o_dout_en[((01)*(j+1)-1)-:(01)] & r_dout_en[((01)*(j+1)-1)-:(01)]) && (o_dout_cc_id[((`mlib_clog2(NUM_CC))*(j+1)-1)-:`mlib_clog2(NUM_CC)]==({{`mlib_clog2(NUM_CC)}{1'b1}}&i) && o_dout_ant_id[(($clog2(NUM_ANT))*(j+1)-1)-:($clog2(NUM_ANT))]=={{$clog2(NUM_ANT)}{1'b1}}) ;
            end
        end
    end
end
end
endgenerate
`endif //DLFE_CELL_MUX_DISABLE
`else //DLFE_WDOG_DISABLE
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            r_bw_event_n[i] <= 1'b1 ;
        end
    end
end
`endif //DLFE_WDOG_DISABLE

reg  [02-1:0]                       r_cal_en                                ;
reg  [$clog2(MAX_NIFFT):0]          r_fft_pts                               ;
reg  [21:0]                         r_ifft_dly                              ;
reg  [0:0]                          r_en                [NUM_I_CHAIN-1:0]   ;
reg  [2*DI_BW-1:0]                  r_iq                [NUM_I_CHAIN-1:0]   ;   
reg  [(`mlib_clog2(NUM_CC))-1:0]    r_cc_id             [NUM_I_CHAIN-1:0]   ;
reg  [$clog2(NUM_ANT)-1:0]          r_ant_id            [NUM_I_CHAIN-1:0]   ;   
reg  [0:0]                          r_shift_a_en        [NUM_I_CHAIN-1:0]   ;   
reg  [DI_BW+BW_SHIFTA-1:0]          r_shift_a_i         [NUM_I_CHAIN-1:0]   ;
reg  [DI_BW+BW_SHIFTA-1:0]          r_shift_a_q         [NUM_I_CHAIN-1:0]   ;   
wire [0:0]                          w_shift_a_sat_en    [NUM_I_CHAIN-1:0]   ;   
wire [BW_IFFT_IN-1:0]               w_shift_a_sat_i     [NUM_I_CHAIN-1:0]   ;
wire [BW_IFFT_IN-1:0]               w_shift_a_sat_q     [NUM_I_CHAIN-1:0]   ;   
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin
        case(r_fft_size[CC_REF]) 
            ORAN_FFT0512 : r_ifft_dly <= (`DLFE_PROJECT_NAME=="FSU20"&&NUM_CC==2) ? DLY_NIFFT_2048 : DLY_NIFFT_0512 ;
            ORAN_FFT1024 : r_ifft_dly <= (`DLFE_PROJECT_NAME=="FSU20"&&NUM_CC==2) ? DLY_NIFFT_2048 : DLY_NIFFT_1024 ;
            ORAN_FFT2048 : r_ifft_dly <= (`DLFE_PROJECT_NAME=="FSU20"&&NUM_CC==2) ? DLY_NIFFT_2048 : DLY_NIFFT_2048 ;
            ORAN_FFT4096 : r_ifft_dly <= (`DLFE_PROJECT_NAME=="FSU20"&&NUM_CC==2) ? DLY_NIFFT_2048 : DLY_NIFFT_4096 ;
            default      : r_ifft_dly <= (`DLFE_PROJECT_NAME=="FSU20"&&NUM_CC==2) ? DLY_NIFFT_2048 : DLY_NIFFT_1024 ;
        endcase
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF]) begin
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT0512 : r_fft_pts <= NFFT_0512 ;
            ORAN_FFT1024 : r_fft_pts <= NFFT_1024 ;
            ORAN_FFT2048 : r_fft_pts <= NFFT_2048 ;
            ORAN_FFT4096 : r_fft_pts <= NFFT_4096 ;
            default      : r_fft_pts <= NFFT_1024 ;
        endcase
    end
end
reg [9-1:0] r_scale_a  ;
always@(posedge i_clk) begin
    if(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF]) begin
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT0512 :  r_scale_a <= 9'd362 ; 
            ORAN_FFT1024 :  r_scale_a <= 9'd256 ; 
            ORAN_FFT2048 :  r_scale_a <= 9'd181 ; 
            ORAN_FFT4096 :  r_scale_a <= 9'd128 ; 
            default      :  r_scale_a <= 9'd0   ; 
        endcase
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF]) begin
        r_cal_en <=  i_din_cal_en ;
    end
end
`ifndef DLFE_AIE_DISABLE
reg [22-1:0]   r_aie_ifft_proc_dly   [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            r_aie_ifft_proc_dly[i] <= i_dlfe_par_1050[((22)*(i+1)-1)-:(22)]   ;
        end
    end
end
reg  [DIO_BW_AIE/2-1:0] r_fft_cin   ;
always@(posedge i_clk) begin
    if(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF]) begin
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT0512 :  r_fft_cin <= CIN_NFFT_0512 ;
            ORAN_FFT1024 :  r_fft_cin <= CIN_NFFT_1024 ;
            ORAN_FFT2048 :  r_fft_cin <= CIN_NFFT_2048 ;
            ORAN_FFT4096 :  r_fft_cin <= CIN_NFFT_4096 ;
            default      :  r_fft_cin <= CIN_NFFT_1024 ;
        endcase
    end
end
reg  [1-1:0]            r_shift_a_sat_en    [NUM_I_CHAIN-1:0] ;
reg  [2*BW_IFFT_IN-1:0] r_shift_a_sat_qi    [NUM_I_CHAIN-1:0] ;
reg  [04-1:0]           r_aie_pkt_id        [NUM_I_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_ofdm_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT1024 : begin //post mapping for axi order
                if     (gidx==1)  r_iq[gidx] <= i_din_iq[((2*DI_BW)*(02+1)-1)-:(2*DI_BW)] ;            
                else if(gidx==2)  r_iq[gidx] <= i_din_iq[((2*DI_BW)*(01+1)-1)-:(2*DI_BW)] ;
                else              r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
            end
            default      : r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
        endcase
    end
end
always@(posedge i_clk) begin
    if(~i_din_en[((01)*(gidx+1)-1)-:(01)]&r_en[gidx]) begin
        r_cc_id  [gidx] <=  i_din_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]  ;
        r_ant_id [gidx] <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]  ;
    end
end
always@(posedge i_clk) begin
    r_shift_a_en[gidx]  <=  r_en[gidx]  ;
    if(r_en[gidx]) begin
        if(|r_cal_en) begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
        end
        else begin
          r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]] ; 
          r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]] ; 
        end
    end
end
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_SHIFTA     )
 ,.DO_BW        (   BW_IFFT_IN          ))
u00_shifta_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   r_shift_a_en[gidx]                              )
    ,.i_in      (   {r_shift_a_i[gidx],r_shift_a_q[gidx]}           )
    ,.o_out_en  (   w_shift_a_sat_en[gidx]                          )
    ,.o_out     (   {w_shift_a_sat_i[gidx],w_shift_a_sat_q[gidx]}   )
);
if(gidx==0||gidx==1) begin
always@(*) begin
    r_shift_a_sat_en[gidx] =  w_shift_a_sat_en [gidx] ;
    r_shift_a_sat_qi[gidx] =  {w_shift_a_sat_q[gidx], w_shift_a_sat_i[gidx]} ;
end
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin 
        r_aie_pkt_id[gidx] <=  4'd0 ;
    end
    else if(~r_shift_a_en[gidx]&r_shift_a_sat_en[gidx]) begin
        r_aie_pkt_id[gidx] <=  r_aie_pkt_id[gidx] + 1'd1 ;
    end
end
end//(gidx==0||gidx==1)
else begin //(gidx==0||gidx==1)
always@(posedge i_clk) begin
    r_shift_a_sat_en[gidx] <=  w_shift_a_sat_en [gidx] ;
    if(w_shift_a_sat_en[gidx]) begin
        r_shift_a_sat_qi[gidx] <=  {w_shift_a_sat_q[gidx], w_shift_a_sat_i[gidx]} ;
    end
end
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin 
        r_aie_pkt_id[gidx] <=  4'd0 ;
    end
    else if(~w_shift_a_sat_en[gidx]&r_shift_a_sat_en[gidx]) begin
        r_aie_pkt_id[gidx] <=  r_aie_pkt_id[gidx] + 1'd1 ;
    end
end
end//(gidx==0||gidx==1)
end
endgenerate

reg [DIO_NB_AIE-1:0]    r_aai_in_axis_tvalid ;   
reg [DIO_BW_AIE-1:0]    r_aai_in_axis_tdata  [DIO_NB_AIE-1:0] ;
reg [DIO_NB_AIE-1:0]    r_aai_in_axis_tlast  ;   
reg [DIO_BW_AIE/8-1:0]  r_aai_in_axis_tkeep  [DIO_NB_AIE-1:0] ;   
always@(posedge i_clk) begin : l00_axis0_tvalid_tdata
    if((r_shift_a_en[00]&~r_shift_a_sat_en[00])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_fft_cin,AIE_IFFT_AXIS00_D02} ;
    end
    else if((r_shift_a_sat_en[00]&~r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],AIE_IFFT_AXIS00_D01} ;
    end
    else if(r_shift_a_sat_en[02]&&r_aie_pkt_id[2][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],r_shift_a_sat_qi[02]} ;
    end
    else if((r_shift_a_sat_en[00]&~r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b1) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],AIE_IFFT_AXIS00_D00} ;
    end
    else if(r_shift_a_sat_en[02]&&r_aie_pkt_id[2][0]==1'b1) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],r_shift_a_sat_qi[02]} ;
    end
    else begin
        r_aai_in_axis_tvalid[00] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l01_axis1_tvalid_tdata
    if((r_shift_a_sat_en[01]&~r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b0) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],AIE_IFFT_AXIS00_D04} ;
    end
    else if(r_shift_a_sat_en[03]&&r_aie_pkt_id[3][0]==1'b0) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],r_shift_a_sat_qi[03]} ;
    end
    else if((r_shift_a_sat_en[01]&~r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],AIE_IFFT_AXIS00_D03} ;
    end
    else if(r_shift_a_sat_en[03]&&r_aie_pkt_id[3][0]==1'b1) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],r_shift_a_sat_qi[03]} ;
    end
    else begin
        r_aai_in_axis_tvalid[01] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l02_axis0_tlast_tkeep
    if((r_shift_a_en[00]&~r_shift_a_sat_en[00])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hff;
    end
    else if((~r_shift_a_sat_en[00]&r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hf ;
    end
    else if((~r_shift_a_sat_en[00]&r_shift_a_sat_en[02])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hf ;
    end
    else begin
        r_aai_in_axis_tlast[00] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l03_axis1_tlast_tkeep
    if((~r_shift_a_sat_en[01]&r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b0) begin
        r_aai_in_axis_tlast[01] <= 1'd1 ;
        r_aai_in_axis_tkeep[01] <= 8'hf ;
    end
    else if((~r_shift_a_sat_en[01]&r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tlast[01] <= 1'd1 ;
        r_aai_in_axis_tkeep[01] <= 8'hf ;
    end
    else begin
        r_aai_in_axis_tlast[01] <= 1'd0 ;
    end
end
wire            w_frame_sync    ;
wire            w_subfrm_sync   ;
wire            w_slot_sync     ;
wire            w_symbol_sync   ;
wire [3:0]      w_subfrm        ;
wire [7:0]      w_slot          ;
wire [3:0]      w_symbol        ;
ref_vsync_gen u01_ifft_rtg
(
     .i_clk                 ( i_clk                         )          
    ,.i_mu                  ( r_mu                          )
    ,.i_retard              ( r_aie_ifft_proc_dly[CC_REF]   )
    ,.i_frame_sync          ( rr_frame_sync                 )          
    ,.i_en                  ( 1'd1                          )          
    ,.o_frame_sync          ( w_frame_sync                  )   
    ,.o_subfrm_sync         ( w_subfrm_sync                 )   
    ,.o_slot_sync           ( w_slot_sync                   )   
    ,.o_symbol_sync         ( w_symbol_sync                 )   
    ,.o_subfrm              ( w_subfrm                      )          
    ,.o_slot                ( w_slot                        )          
    ,.o_symbol              ( w_symbol                      )          
);
wire [01-1:0]                           w_aai_out_axis_tvalid   [DIO_NB_AIE-1:0]    ;
wire [DIO_BW_AIE-1:0]                   w_aai_out_axis_tdata    [DIO_NB_AIE-1:0]    ;
wire [01-1:0]                           w_aai_out_axis_tlast    [DIO_NB_AIE-1:0]    ;
reg  [10-1:0]                           r_aai_out_axis_tcnt     [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_out_axis_tvalid   [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           rr_aai_in_axis_tvalid   [DIO_NB_AIE-1:0]    ;
wire [22-1:0]                           w_aai_inout_proc_dly    [DIO_NB_AIE-1:0]    ;
reg  [$clog2(NUM_ANT):0]                r_aai_in_blk_id         [DIO_NB_AIE-1:0]    ;
reg  [$clog2(NUM_ANT)-1:0]              r_aai_out_blk_id        [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_a2p_axis_tready       [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_p2a_axis_tvalid       [DIO_NB_AIE-1:0]    ; 
wire [DIO_BW_AIE-1:0]                   w_p2a_axis_tdata        [DIO_NB_AIE-1:0]    ;
wire [01-1:0]                           w_p2a_axis_tlast        [DIO_NB_AIE-1:0]    ; 
wire [DIO_BW_AIE/8-1:0]                 w_p2a_axis_tkeep        [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_p2a_axis_fifo_empty   [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           r_p2a_axis_tready       [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_a2p_axis_tvalid       [DIO_NB_AIE-1:0]    ; 
wire [DIO_BW_AIE-1:0]                   w_a2p_axis_tdata        [DIO_NB_AIE-1:0]    ;
wire [01-1:0]                           w_a2p_axis_tlast        [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_a2p_axis_fifo_empty   [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           r_a2p_axis_fifo_empty   [DIO_NB_AIE-1:0]    ; 
reg  [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_aai_in_wdog_cnt       [DIO_NB_AIE-1:0]    ; 
reg  [02-1:0]                           r_aai_in_wdog_chk       [DIO_NB_AIE-1:0]    ;    
reg  [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_aai_in_wdog_chk_cnt   [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           r_aai_in_rec_tvalid     [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_in_rec_tlast      [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_in_rec_done       [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_in_pair_cnt       [DIO_NB_AIE-1:0]    ;
generate for(gidx=0;gidx<DIO_NB_AIE;gidx=gidx+1) begin : g01_aai_aie_ifft_chain
always@(posedge i_clk) begin 
    if(|i_rst) begin
        r_aai_in_rec_done  [gidx] <= 1'd0 ;
    end
    else if(r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE) begin
        if(i_din_symbol_sync) begin
            r_aai_in_rec_done  [gidx] <= 1'd0 ;
        end
        else if((r_aai_in_pair_cnt[gidx]==1'd0&&r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI)))||(r_aai_in_pair_cnt[gidx]==1'd1&&r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))-1'd1)) begin
            r_aai_in_rec_done  [gidx] <= 1'd1 ;
        end
    end
end
always@(posedge i_clk) begin 
    if(|i_rst) begin
        r_aai_in_wdog_cnt   [gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        r_aai_in_rec_tvalid [gidx] <= 1'd0 ;
        r_aai_in_rec_tlast  [gidx] <= 1'd0 ;
    end
    else if(r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE) begin
        r_aai_in_rec_tvalid[gidx] <= (r_aai_in_rec_done[gidx]==1'd0) && (r_aai_in_wdog_cnt[gidx]<=((({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&AIE_SIZE_PACKET_AAI)>>r_aai_in_pair_cnt[gidx])-r_aai_in_pair_cnt[gidx])) ;
        if(i_din_symbol_sync) begin
            r_aai_in_rec_tvalid[gidx] <= 1'd0 ;
            r_aai_in_rec_tlast [gidx] <= 1'd0 ;
        end
        else if(r_aai_in_rec_done[gidx]==1'd0&&(r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI))||r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))-1'd1)) begin
            r_aai_in_rec_tlast [gidx] <= r_aai_in_rec_tvalid[gidx] ;
        end
        else begin
            r_aai_in_rec_tlast [gidx] <= 1'd0 ;
        end
        if(i_din_symbol_sync&r_aai_in_rec_done[gidx]) begin
            r_aai_in_wdog_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        end
        else if(r_aai_in_wdog_cnt[gidx]<=({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&AIE_SIZE_PACKET_AAI)) begin
            r_aai_in_wdog_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] + 1'd1 ;
        end
    end
    else if(r_aai_in_wdog_chk[gidx]==VALID_STATE_WDOG_PL2AIE) begin
        if(r_aai_in_axis_tvalid[gidx]) begin
            if(r_aai_in_axis_tlast[gidx]) begin
                if(r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))) begin
                    r_aai_in_wdog_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
                end
            end
            else begin
                r_aai_in_wdog_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] + 1'd1 ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(|i_rst) begin
        r_aai_in_wdog_chk_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        r_aai_in_pair_cnt    [gidx] <= 1'd0 ;
    end
    else if(i_din_symbol_sync) begin
        r_aai_in_wdog_chk[gidx] <= VALID_STATE_WDOG_PL2AIE ;
    end
    else if(&r_aai_in_axis_tvalid) begin
        if(&r_aai_in_axis_tlast) begin
            if(r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))) begin
                r_aai_in_pair_cnt  [gidx] <= ~r_aai_in_pair_cnt[gidx] ;
            end
            else begin
                r_aai_in_wdog_chk[gidx] <= INVALID_STATE_WDOG_PL2AIE ;
                if(r_aai_in_wdog_chk[gidx]==VALID_STATE_WDOG_PL2AIE) begin
                    r_aai_in_wdog_chk_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] ;
                end
            end
        end
    end
    else if(r_aai_in_rec_done[gidx]) begin
        r_aai_in_pair_cnt    [gidx] <= 1'd0 ;
    end
end
xpm_fifo_async #(
     .CASCADE_HEIGHT      (0                                )
    ,.CDC_SYNC_STAGES     (2                                ) 
    ,.DOUT_RESET_VALUE    ("0"                              )
    ,.ECC_MODE            ("no_ecc"                         )
    ,.FIFO_MEMORY_TYPE    ("auto"                           )
    ,.FIFO_READ_LATENCY   (1                                )
    ,.FIFO_WRITE_DEPTH    (PL2AIE_ASYNC_FIFO_DEPTH          )
    ,.FULL_RESET_VALUE    (0                                )
    ,.PROG_EMPTY_THRESH   (10                               )
    ,.PROG_FULL_THRESH    (10                               )
    ,.RD_DATA_COUNT_WIDTH ($clog2(PL2AIE_ASYNC_FIFO_DEPTH)  )
    ,.READ_DATA_WIDTH     (1+DIO_BW_AIE+1+DIO_BW_AIE/8      )
    ,.READ_MODE           ("std"                            )
    ,.RELATED_CLOCKS      (0                                )
    ,.SIM_ASSERT_CHK      (0                                )
    ,.USE_ADV_FEATURES    ("0707"                           )
    ,.WAKEUP_TIME         (0                                )
    ,.WRITE_DATA_WIDTH    (1+DIO_BW_AIE+1+DIO_BW_AIE/8      )
    ,.WR_DATA_COUNT_WIDTH ($clog2(PL2AIE_ASYNC_FIFO_DEPTH)  )
)
u02_0_p2a_fifo_async 
(
     .almost_empty              (                                   )
    ,.almost_full               (                                   )
    ,.data_valid                (                                   )
    ,.dbiterr                   (                                   )
    ,.dout                      (   {w_p2a_axis_tvalid[gidx]
                                    ,w_p2a_axis_tdata [gidx] 
                                    ,w_p2a_axis_tlast [gidx] 
                                    ,w_p2a_axis_tkeep [gidx]}       )
    ,.empty                     (   w_p2a_axis_fifo_empty[gidx]     )
    ,.full                      (                                   )
    ,.overflow                  (                                   )
    ,.prog_empty                (                                   )
    ,.prog_full                 (                                   )
    ,.rd_data_count             (                                   )
    ,.rd_rst_busy               (                                   )
    ,.sbiterr                   (                                   )
    ,.underflow                 (                                   )
    ,.wr_ack                    (                                   )
    ,.wr_data_count             (                                   )
    ,.wr_rst_busy               (                                   )
    ,.din                       (    r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE
                                   ?{r_aai_in_rec_tvalid [gidx] 
                                    ,{{DIO_BW_AIE}{1'b0}}                            
                                    ,r_aai_in_rec_tlast  [gidx] 
                                    ,8'h0f}
                                   :{r_aai_in_axis_tvalid[gidx]
                                    ,r_aai_in_axis_tdata [gidx] 
                                    ,r_aai_in_axis_tlast [gidx]&(&(~r_aai_in_wdog_cnt[gidx][$clog2(AIE_SIZE_PACKET_AAI/2)-1:0])) 
                                    ,r_aai_in_axis_tkeep [gidx]}    )
    ,.injectdbiterr             (                                   )
    ,.injectsbiterr             (                                   )
    ,.rd_clk                    (   i_aie_clk                       )
    ,.rd_en                     (   1'd1                            )
    ,.rst                       (   i_rst                           )
    ,.sleep                     (                                   )
    ,.wr_clk                    (   i_clk                           )
    ,.wr_en                     (   1'd1                            )
);
always@(*) begin
    r_a2p_axis_tready[gidx] = i_aie_ifft_tready[((01)*(gidx+1)-1)-:(01)] ;
    r_p2a_axis_tready[gidx] = r_bw_event_n[CC_REF] ;
end
assign  o_aie_ifft_tvalid[((01)*(gidx+1)-1)-:(01)]                      = w_p2a_axis_tvalid [gidx] & ~w_p2a_axis_fifo_empty[gidx] ;
assign  o_aie_ifft_tdata [((DIO_BW_AIE)*(gidx+1)-1)-:(DIO_BW_AIE)]      = w_p2a_axis_tdata  [gidx] ;
assign  o_aie_ifft_tlast [((01)*(gidx+1)-1)-:(01)]                      = w_p2a_axis_tlast  [gidx] ;
assign  o_aie_ifft_tkeep [((DIO_BW_AIE/8)*(gidx+1)-1)-:(DIO_BW_AIE/8)]  = w_p2a_axis_tkeep  [gidx] ;
assign  o_aie_ifft_tready[((01)*(gidx+1)-1)-:(01)]                      = 1'd1 ;
xpm_fifo_async #(
     .CASCADE_HEIGHT      (0                                )
    ,.CDC_SYNC_STAGES     (2                                ) 
    ,.DOUT_RESET_VALUE    ("0"                              )
    ,.ECC_MODE            ("no_ecc"                         )
    ,.FIFO_MEMORY_TYPE    ("auto"                           )
    ,.FIFO_READ_LATENCY   (1                                )
    ,.FIFO_WRITE_DEPTH    (AIE2PL_ASYNC_FIFO_DEPTH          )
    ,.FULL_RESET_VALUE    (0                                )
    ,.PROG_EMPTY_THRESH   (10                               )
    ,.PROG_FULL_THRESH    (10                               )
    ,.RD_DATA_COUNT_WIDTH ($clog2(AIE2PL_ASYNC_FIFO_DEPTH)  )
    ,.READ_DATA_WIDTH     (1+DIO_BW_AIE+1                   )
    ,.READ_MODE           ("std"                            )
    ,.RELATED_CLOCKS      (0                                )
    ,.SIM_ASSERT_CHK      (0                                )
    ,.USE_ADV_FEATURES    ("0707"                           )
    ,.WAKEUP_TIME         (0                                )
    ,.WRITE_DATA_WIDTH    (1+DIO_BW_AIE+1                   )
    ,.WR_DATA_COUNT_WIDTH ($clog2(AIE2PL_ASYNC_FIFO_DEPTH)  )
)
u02_1_a2p_fifo_async 
(
     .almost_empty              (                                                                       )
    ,.almost_full               (                                                                       )
    ,.data_valid                (                                                                       )
    ,.dbiterr                   (                                                                       )
    ,.dout                      (   {w_a2p_axis_tvalid [gidx]
                                    ,w_a2p_axis_tdata  [gidx]
                                    ,w_a2p_axis_tlast  [gidx]}                                          )
    ,.empty                     (   w_a2p_axis_fifo_empty[gidx]                                         )
    ,.full                      (                                                                       )
    ,.overflow                  (                                                                       )
    ,.prog_empty                (                                                                       )
    ,.prog_full                 (                                                                       )
    ,.rd_data_count             (                                                                       )
    ,.rd_rst_busy               (                                                                       )
    ,.sbiterr                   (                                                                       )
    ,.underflow                 (                                                                       )
    ,.wr_ack                    (                                                                       )
    ,.wr_data_count             (                                                                       )
    ,.wr_rst_busy               (                                                                       )
    ,.din                       (   {i_aie_ifft_tvalid[((01)*(gidx+1)-1)-:(01)]               
                                    ,i_aie_ifft_tdata [((DIO_BW_AIE)*(gidx+1)-1)-:(DIO_BW_AIE)]
                                    ,i_aie_ifft_tlast [((01)*(gidx+1)-1)-:(01)]}                        )
    ,.injectdbiterr             (                                                                       )
    ,.injectsbiterr             (                                                                       )
    ,.rd_clk                    (   i_clk                                                               )
    ,.rd_en                     (   1'd1                                                                )
    ,.rst                       (   i_aie_rst                                                           )
    ,.sleep                     (                                                                       )
    ,.wr_clk                    (   i_aie_clk                                                           )
    ,.wr_en                     (   i_aie_ifft_tvalid[((01)*(gidx+1)-1)-:(01)]                          )
);
always@(posedge i_clk) begin 
    r_a2p_axis_fifo_empty[gidx] <= w_a2p_axis_fifo_empty[gidx] ;   
end
assign  w_aai_out_axis_tvalid[gidx] = w_a2p_axis_tvalid [gidx] & ~r_a2p_axis_fifo_empty[gidx] ;
assign  w_aai_out_axis_tdata [gidx] = w_a2p_axis_tdata  [gidx] ;
assign  w_aai_out_axis_tlast [gidx] = w_a2p_axis_tlast  [gidx] ;
always@(posedge i_clk) begin 
    rr_aai_in_axis_tvalid[gidx] <= r_aai_in_axis_tvalid[gidx]  ;
    if(i_din_symbol_sync) begin
        r_aai_in_blk_id[gidx] <= {{$clog2(NUM_ANT+1)}{1'b0}};
    end
    else if(~r_aai_in_axis_tvalid[gidx]&rr_aai_in_axis_tvalid[gidx]) begin
        r_aai_in_blk_id[gidx]<= r_aai_in_blk_id[gidx]+1'd1;
    end
end
always@(posedge i_clk) begin 
    r_aai_out_axis_tvalid[gidx] <= w_aai_out_axis_tvalid[gidx]  ;
    if(w_symbol_sync) begin
        r_aai_out_axis_tcnt[gidx] <= 10'd0 ;
        r_aai_out_blk_id[gidx] <= {{$clog2(NUM_ANT)}{1'b0}};
    end
    else if(w_aai_out_axis_tvalid[gidx]) begin
        r_aai_out_axis_tcnt[gidx] <= r_aai_out_axis_tcnt[gidx] + 1'd1 ;
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT4096 :  if(&r_aai_out_axis_tcnt[gidx][10-1:0]) r_aai_out_blk_id[gidx]<= r_aai_out_blk_id[gidx] + 1'd1 ;
            default      :  if(&r_aai_out_axis_tcnt[gidx][09-1:0]) r_aai_out_blk_id[gidx]<= r_aai_out_blk_id[gidx] + 1'd1 ;
        endcase
    end
    else if(~w_aai_out_axis_tvalid[gidx]&r_aai_out_axis_tvalid[gidx]) begin
        r_aai_out_axis_tcnt[gidx] <= 10'd0 ;
    end
end
ylib_mon_sync_diff #(
    .WIDTH(22)) 
u03_aie_proc_dly
(
     .i_clk     (i_clk                      )
    ,.i_sync0   ((r_aai_in_axis_tvalid [gidx]&~rr_aai_in_axis_tvalid [gidx])&&r_aai_in_blk_id [gidx]=={{$clog2(NUM_ANT+1)}{1'b0}})
    ,.i_sync1   ((w_aai_out_axis_tvalid[gidx]&~r_aai_out_axis_tvalid [gidx])&&r_aai_out_blk_id[gidx]=={{$clog2(NUM_ANT+0)}{1'b0}})
    ,.o_diff    (w_aai_inout_proc_dly[gidx] )
);
assign  o_dlfe_rpt_1054 [gidx+00] = r_a2p_axis_tready[gidx] ;
assign  o_dlfe_rpt_1054 [gidx+08] = r_p2a_axis_tready[gidx] ;
end
endgenerate
reg [9-1:0] r_pkt_len_cnt ;
always@(posedge i_clk) begin
    if(i_din_en[CHAIN_REF]&~r_en[CHAIN_REF]) begin
        r_pkt_len_cnt <= 12'd0 ;
    end
    else if(r_en[CHAIN_REF]) begin
        r_pkt_len_cnt <= r_pkt_len_cnt+12'd1 ;
    end
end
reg [16-1:0] r_pkt_len_wdog_cnt ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_pkt_len_wdog_cnt <= 16'd0 ;
    end
    else if(~i_din_en[CHAIN_REF]&r_en[CHAIN_REF]) begin
        if(~&r_pkt_len_cnt) begin
            r_pkt_len_wdog_cnt <= r_pkt_len_wdog_cnt+16'd1 ;
        end
    end
end
assign  o_dlfe_rpt_1054 [32-1:16] = r_pkt_len_wdog_cnt ;
reg r_sig_det ;
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_sig_det <= 1'b0 ;
    end
    else if(|i_din_en) begin
        r_sig_det <= 1'b1 ;
    end
end
reg r_sig_exist ;
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        r_sig_exist  <= r_sig_det  ;
    end
end
reg  [0:0]                  r_even_ifft_out_en  [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_even_ifft_out_i   [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_even_ifft_out_q   [NUM_O_CHAIN-1:0] ;
reg  [0:0]                  r_odd_ifft_out_en   [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_odd_ifft_out_i    [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_odd_ifft_out_q    [NUM_O_CHAIN-1:0] ;
reg  [0:0]                  r_ifft_out_en       [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_ifft_out_i        [NUM_O_CHAIN-1:0] ;
reg  [DO_BW-1:0]            r_ifft_out_q        [NUM_O_CHAIN-1:0] ;
reg  [0:0]                  r_ifft_out_s_en     [NUM_O_CHAIN-1:0] ;
reg  [BW_SCALE_A-1:0]       r_ifft_out_s_i      [NUM_O_CHAIN-1:0] ;
reg  [BW_SCALE_A-1:0]       r_ifft_out_s_q      [NUM_O_CHAIN-1:0] ;
wire [0:0]                  w_ifft_out_sr_en    [NUM_O_CHAIN-1:0] ;
wire [2*BW_SCALE_A-1:0]     w_ifft_out_sr_iq    [NUM_O_CHAIN-1:0] ;
wire [0:0]                  w_ifft_out_sat_en   [NUM_O_CHAIN-1:0] ;
wire [2*DO_BW-1:0]          w_ifft_out_sat_iq   [NUM_O_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g02_out_chain
always@(*) begin
    r_even_ifft_out_en[gidx] = (w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&r_sig_exist)&&r_aai_out_blk_id[gidx/DIO_NB_AIE][0]==1'b0 ;
    r_even_ifft_out_i [gidx] = w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(0+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW] ;
    r_even_ifft_out_q [gidx] = w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(2+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW] ;
end
always@(posedge i_clk) begin
    r_odd_ifft_out_en[gidx] <= (w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&r_sig_exist)&&r_aai_out_blk_id[gidx/DIO_NB_AIE][0]==1'b1 ;
    if((w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&r_sig_exist)&&r_aai_out_blk_id[gidx/DIO_NB_AIE][0]==1'b1) begin
        r_odd_ifft_out_i [gidx] <= w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(0+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW] ;
        r_odd_ifft_out_q [gidx] <= w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(2+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW] ;
    end
end
always@(posedge i_clk) begin
    if(r_even_ifft_out_en[gidx]) begin
        r_ifft_out_en[gidx] <= r_even_ifft_out_en[gidx] ; 
        r_ifft_out_i [gidx] <= r_even_ifft_out_i [gidx] ;
        r_ifft_out_q [gidx] <= r_even_ifft_out_q [gidx] ;
    end
    else if(r_odd_ifft_out_en[gidx]) begin
        r_ifft_out_en[gidx] <= r_odd_ifft_out_en[gidx] ; 
        r_ifft_out_i [gidx] <= r_odd_ifft_out_i [gidx] ;
        r_ifft_out_q [gidx] <= r_odd_ifft_out_q [gidx] ;
    end
    else begin
        r_ifft_out_en[gidx] <= 1'd0 ; 
    end
end
always@(posedge i_clk) begin
    r_ifft_out_s_en[gidx] <= r_ifft_out_en[gidx] ;
    if(r_ifft_out_en[gidx]) begin
        r_ifft_out_s_i[gidx] <=  $signed($signed({{{BW_SCALE_A-DO_BW}{r_ifft_out_i[gidx][DO_BW-1]}},r_ifft_out_i[gidx]})*r_scale_a)  ;
        r_ifft_out_s_q[gidx] <=  $signed($signed({{{BW_SCALE_A-DO_BW}{r_ifft_out_q[gidx][DO_BW-1]}},r_ifft_out_q[gidx]})*r_scale_a)  ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2               )
 ,.SHIFTD_BW    (   4               )
 ,.IO_BW        (   BW_SCALE_A      ))
u04_ifft_out_sr
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   r_ifft_out_s_en[gidx]                       )
    ,.i_in      (   {r_ifft_out_s_i[gidx],r_ifft_out_s_q[gidx]} )
    ,.i_shiftd  (   SHIFT_B                                     )
    ,.o_out_en  (   w_ifft_out_sr_en[gidx]                      )
    ,.o_out     (   w_ifft_out_sr_iq[gidx]                      )
);
ylib_sat #(
  .NUM_STREAM   (   2               )
 ,.DI_BW        (   BW_SCALE_A      )
 ,.DO_BW        (   DO_BW           ))
u05_ifft_out_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   w_ifft_out_sr_en  [gidx]    )
    ,.i_in      (   w_ifft_out_sr_iq  [gidx]    )
    ,.o_out_en  (   w_ifft_out_sat_en [gidx]    )
    ,.o_out     (   w_ifft_out_sat_iq [gidx]    )
);
always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)] <= w_ifft_out_sat_en [gidx] ;
    if(w_ifft_out_sat_en[gidx]) begin
        o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= w_ifft_out_sat_iq [gidx] ;
    end
end
always@(posedge i_clk) begin
    if(w_ifft_out_sr_en[gidx]&~w_ifft_out_sat_en[gidx]) begin
        case(r_fft_size[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]]) 
            ORAN_FFT0512 :  o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_aai_out_blk_id[gidx/DIO_NB_AIE] ;
            ORAN_FFT1024 :  begin
                if(gidx/2==1)  o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_aai_out_blk_id[gidx/DIO_NB_AIE] + ((r_aai_out_blk_id[gidx/DIO_NB_AIE]>>1)<<1) ;
                else           o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_aai_out_blk_id[gidx/DIO_NB_AIE] + ((r_aai_out_blk_id[gidx/DIO_NB_AIE]>>1)<<1)+({{$clog2(NUM_ANT)}{1'b1}}&'d2) ;
            end
            ORAN_FFT2048 :  o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <={r_aai_out_blk_id[gidx/DIO_NB_AIE][$clog2(NUM_ANT)-1:1],~r_aai_out_blk_id[gidx/DIO_NB_AIE][0]} ;
            ORAN_FFT4096 :  o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_aai_out_blk_id[gidx/DIO_NB_AIE] ;
            default      :  o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_aai_out_blk_id[gidx/DIO_NB_AIE] ;
        endcase
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= r_cc_id [gidx] ;  
    end
end
end
endgenerate
assign o_dlfe_rpt_1040[((22)*(0+1)-1)-:(22)] = w_aai_inout_proc_dly[0] ;
assign o_dlfe_rpt_1044[((22)*(0+1)-1)-:(22)] = w_aai_inout_proc_dly[1] ;
`else// DLFE_AIE_DISABLE
reg  [1-1:0]                        r_shift_a_sat_en    [NUM_I_CHAIN-1:0]               ;   
wire [0:0]                          w_ifft_rstn         [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_ready        [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_out_en       [NUM_I_CHAIN-1:0]               ;
wire [1:0]                          w_ifft_out_err      [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                          r_ifft_out_err      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_out_sop      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_out_eop      [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]              w_ifft_out_i        [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]              w_ifft_out_q        [NUM_I_CHAIN-1:0]               ;
wire [$clog2(MAX_NIFFT):0]          w_ifft_out_pts      [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                          r_ifft_rstn         [NUM_I_CHAIN-1:0][DLY_RST:0]    ;
wire [0:0]                          w_ifft_out_r_en     [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]              w_ifft_out_r_i      [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]              w_ifft_out_r_q      [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                          r_ifft_out_s_en     [NUM_I_CHAIN-1:0]               ;
reg  [BW_SCALE_A-1:0]               r_ifft_out_s_i      [NUM_I_CHAIN-1:0]               ;
reg  [BW_SCALE_A-1:0]               r_ifft_out_s_q      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_out_sr_en    [NUM_I_CHAIN-1:0]               ;
wire [2*BW_SCALE_A-1:0]             w_ifft_out_sr_iq    [NUM_I_CHAIN-1:0]               ;
wire [0:0]                          w_ifft_out_sat_en   [NUM_I_CHAIN-1:0]               ;
wire [2*DO_BW-1:0]                  w_ifft_out_sat_iq   [NUM_I_CHAIN-1:0]               ;
wire [01-1:0]                       w_dout_en           [NUM_I_CHAIN-1:0]               ;
wire [2*DO_BW-1:0]                  w_dout_iq           [NUM_I_CHAIN-1:0]               ;
wire [(`mlib_clog2(NUM_CC))-1:0]    w_dout_cc_id        [NUM_I_CHAIN-1:0]               ;
wire [02-1:0]                       w_dout_ant_id       [NUM_I_CHAIN-1:0]               ;   
wire                                w_frame_sync                                        ;
wire                                w_subfrm_sync                                       ;
wire                                w_slot_sync                                         ;
wire                                w_symbol_sync                                       ;
wire [3:0]                          w_subfrm                                            ;
wire [7:0]                          w_slot                                              ;
wire [3:0]                          w_symbol                                            ;
reg  [02*NUM_O_CHAIN-1:0]           r_ifft_out_err_mon  [NUM_CC-1:0]                    ;
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_ofdm_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    end
end
always@(posedge i_clk) begin
    if(~i_din_en[((01)*(gidx+1)-1)-:(01)]&r_en[gidx]) begin
        r_cc_id  [gidx] <=  i_din_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]  ;
        r_ant_id [gidx] <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]  ;
    end
end
always@(posedge i_clk) begin
    r_shift_a_en[gidx]  <=  r_en[gidx]&r_bw_event_n[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]] ;
    if(r_en[gidx]) begin
        if(|r_cal_en) begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
        end
        else begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]] ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]] ; 
        end
    end
end
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_SHIFTA     )
 ,.DO_BW        (   BW_IFFT_IN          ))
u00_shifta_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   r_shift_a_en[gidx]                              )
    ,.i_in      (   {r_shift_a_i[gidx],r_shift_a_q[gidx]}           )
    ,.o_out_en  (   w_shift_a_sat_en[gidx]                          )
    ,.o_out     (   {w_shift_a_sat_i[gidx],w_shift_a_sat_q[gidx]}   )
);
always@(posedge i_clk) begin
    r_shift_a_sat_en[gidx]  <=  w_shift_a_sat_en[gidx] ;
    r_ifft_out_err  [gidx]  <= |w_ifft_out_err  [gidx] ;
end
always@(posedge i_clk) begin
    if(|i_rst) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else if(|w_ifft_out_err[gidx]&~r_ifft_out_err[gidx]) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else if(r_ifft_symbol_rst_n[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]]) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else if((r_bw_event_n[i_din_cc_id[((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)]]==1'b0)&&r_ant_id[gidx]=={{$clog2(NUM_ANT)}{1'b0}}) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else begin
        r_ifft_rstn[gidx][0] <=  1'b1 ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_RST;i=i+1) begin
        r_ifft_rstn[gidx][i] <=  r_ifft_rstn[gidx][i-1] ;
    end
end
assign w_ifft_rstn[gidx] = r_ifft_rstn[gidx][DLY_RST-1]&r_ifft_rstn[gidx][DLY_RST]  ;
ylib_vfft_wrapper #(
     .MAX_NFFT   (    MAX_NIFFT         )
`ifndef DLFE_VENDOR_FFT_DISABLE    
    ,.VENDOR     (    VENDOR            ))
`else
    ,.FFT_TYPE   (   "IFFT"             )
    ,.VENDOR     (   "Custom"           ))
`endif    
u01_ifft 
(
     .clk               (   i_clk                                           )
    ,.reset_n           (   w_ifft_rstn     [gidx]                          )
    ,.sink_valid        (   w_shift_a_sat_en[gidx]                          )
    ,.sink_ready        (   w_ifft_ready    [gidx]                          )
    ,.sink_error        (   2'd0                                            ) 
    ,.sink_sop          (   w_shift_a_sat_en[gidx]&~r_shift_a_sat_en[gidx]  ) 
    ,.sink_eop          (   ~r_shift_a_en[gidx]&w_shift_a_sat_en[gidx]      ) 
    ,.sink_real         (   w_shift_a_sat_i [gidx]                          ) 
    ,.sink_imag         (   w_shift_a_sat_q [gidx]                          ) 
    ,.fftpts_in         (   r_fft_pts                                       ) 
    ,.inverse           (   1'd1                                            ) 
    ,.source_valid      (   w_ifft_out_en   [gidx]                          ) 
    ,.source_ready      (   1'd1                                            ) 
    ,.source_error      (   w_ifft_out_err  [gidx]                          ) 
    ,.source_sop        (   w_ifft_out_sop  [gidx]                          ) 
    ,.source_eop        (   w_ifft_out_eop  [gidx]                          ) 
    ,.source_real       (   w_ifft_out_i    [gidx]                          ) 
    ,.source_imag       (   w_ifft_out_q    [gidx]                          ) 
    ,.fftpts_out        (   w_ifft_out_pts  [gidx]                          ) 
);
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2               )
 ,.SHIFTD_BW    (   2               )
 ,.IO_BW        (   BW_IFFT_OUT     ))
u02_ifft_out_r
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   w_ifft_out_en[gidx]                         )
    ,.i_in      (   {w_ifft_out_i[gidx],w_ifft_out_q[gidx]}     )
    ,.i_shiftd  (   2'd3                                        )
    ,.o_out_en  (   w_ifft_out_r_en[gidx]                       )
    ,.o_out     (   {w_ifft_out_r_i[gidx],w_ifft_out_r_q[gidx]} )
);
always@(posedge i_clk) begin
    r_ifft_out_s_en[gidx] <= w_ifft_out_r_en[gidx] ;
    if(w_ifft_out_r_en[gidx]) begin
        r_ifft_out_s_i[gidx] <= $signed($signed({{{BW_SCALE_A-BW_IFFT_OUT}{w_ifft_out_r_i[gidx][BW_IFFT_OUT-1]}},w_ifft_out_r_i[gidx]})*r_scale_a) ;
        r_ifft_out_s_q[gidx] <= $signed($signed({{{BW_SCALE_A-BW_IFFT_OUT}{w_ifft_out_r_q[gidx][BW_IFFT_OUT-1]}},w_ifft_out_r_q[gidx]})*r_scale_a) ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2               )
 ,.SHIFTD_BW    (   4               )
 ,.IO_BW        (   BW_SCALE_A      ))
u03_ifft_out_sr
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   r_ifft_out_s_en[gidx]                       )
    ,.i_in      (   {r_ifft_out_s_i[gidx],r_ifft_out_s_q[gidx]} )
    ,.i_shiftd  (   SHIFT_B                                     )
    ,.o_out_en  (   w_ifft_out_sr_en[gidx]                      )
    ,.o_out     (   w_ifft_out_sr_iq[gidx]                      )
);
ylib_sat #(
  .NUM_STREAM   (   2               )
 ,.DI_BW        (   BW_SCALE_A      )
 ,.DO_BW        (   DO_BW           ))
u04_ifft_out_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   w_ifft_out_sr_en  [gidx]    )
    ,.i_in      (   w_ifft_out_sr_iq  [gidx]    )
    ,.o_out_en  (   w_ifft_out_sat_en [gidx]    )
    ,.o_out     (   w_ifft_out_sat_iq [gidx]    )
);
always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)] <= w_ifft_out_sat_en [gidx] ;  
    if(w_ifft_out_sr_en[gidx]&~w_ifft_out_sat_en[gidx]) begin
        o_dout_cc_id  [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= r_cc_id[gidx] ;  
        o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= r_ant_id[gidx] ;  
    end
    else if(w_ifft_out_sat_en[gidx]) begin
        o_dout_iq [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= w_ifft_out_sat_iq[gidx] ;  
    end
end
end
endgenerate //g00_ofdm_chain
ref_vsync_gen u05_ifft_rtg
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( r_mu                      )
    ,.i_retard              ( r_ifft_dly                )
    ,.i_frame_sync          ( rr_frame_sync             )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_frame_sync              )   
    ,.o_subfrm_sync         ( w_subfrm_sync             )   
    ,.o_slot_sync           ( w_slot_sync               )   
    ,.o_symbol_sync         ( w_symbol_sync             )   
    ,.o_subfrm              ( w_subfrm                  )          
    ,.o_slot                ( w_slot                    )          
    ,.o_symbol              ( w_symbol                  )          
);
`endif// DLFE_AIE_DISABLE
always@(posedge i_clk) begin
    o_dout_frame_sync  <= w_frame_sync  ;
    o_dout_symbol_sync <= w_symbol_sync ;
    if(w_symbol_sync) begin
        o_dout_symbol_idx <=  w_symbol     ;
        o_dout_cal_en     <=  i_din_cal_en ;
    end
end

`ifndef DLFE_AIE_DISABLE
`ifndef DLFE_INNER_ILA_DISABLE
reg [01-1:0]                           r_dbg_0_aai_in_axis_tvalid     ; 
reg [DIO_BW_AIE-1:0]                   r_dbg_0_aai_in_axis_tdata      ;
reg [01-1:0]                           r_dbg_0_aai_in_axis_tlast      ; 
reg [08-1:0]                           r_dbg_0_aai_in_axis_tkeep      ; 
reg [01-1:0]                           r_dbg_0_aai_out_axis_tvalid    ; 
reg [DIO_BW_AIE-1:0]                   r_dbg_0_aai_out_axis_tdata     ;
reg [01-1:0]                           r_dbg_0_aai_out_axis_tlast     ; 
reg [10-1:0]                           r_dbg_0_aai_out_axis_tcnt      ; 
reg [$clog2(NUM_ANT):0]                r_dbg_0_aai_in_blk_id          ; 
reg [$clog2(NUM_ANT)-1:0]              r_dbg_0_aai_out_blk_id         ; 
reg [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_dbg_0_aai_in_wdog_cnt        ; 
reg [02-1:0]                           r_dbg_0_aai_in_wdog_chk        ;    
reg [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_dbg_0_aai_in_wdog_chk_cnt    ; 
reg [01-1:0]                           r_dbg_0_aai_in_rec_tvalid      ;
reg [01-1:0]                           r_dbg_0_aai_in_rec_tlast       ;
reg [01-1:0]                           r_dbg_0_aai_in_rec_done        ;
reg [01-1:0]                           r_dbg_1_aai_in_axis_tvalid     ; 
reg [DIO_BW_AIE-1:0]                   r_dbg_1_aai_in_axis_tdata      ;
reg [01-1:0]                           r_dbg_1_aai_in_axis_tlast      ; 
reg [08-1:0]                           r_dbg_1_aai_in_axis_tkeep      ; 
reg [01-1:0]                           r_dbg_1_aai_out_axis_tvalid    ; 
reg [DIO_BW_AIE-1:0]                   r_dbg_1_aai_out_axis_tdata     ;
reg [01-1:0]                           r_dbg_1_aai_out_axis_tlast     ; 
reg [10-1:0]                           r_dbg_1_aai_out_axis_tcnt      ; 
reg [$clog2(NUM_ANT):0]                r_dbg_1_aai_in_blk_id          ; 
reg [$clog2(NUM_ANT)-1:0]              r_dbg_1_aai_out_blk_id         ; 
reg [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_dbg_1_aai_in_wdog_cnt        ; 
reg [02-1:0]                           r_dbg_1_aai_in_wdog_chk        ;    
reg [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_dbg_1_aai_in_wdog_chk_cnt    ; 
reg [01-1:0]                           r_dbg_1_aai_in_rec_tvalid      ;
reg [01-1:0]                           r_dbg_1_aai_in_rec_tlast       ;
reg [01-1:0]                           r_dbg_1_aai_in_rec_done        ;
reg                                    r_dbg_frame_sync               ;
reg                                    r_dbg_subfrm_sync              ;
reg                                    r_dbg_slot_sync                ;
reg                                    r_dbg_symbol_sync              ;
reg [3:0]                              r_dbg_subfrm                   ;
reg [7:0]                              r_dbg_slot                     ;
reg [3:0]                              r_dbg_symbol                   ;
always@(posedge i_clk) begin
    r_dbg_0_aai_in_axis_tvalid      <=  r_aai_in_axis_tvalid    [0] ; 
    r_dbg_0_aai_in_axis_tdata       <=  r_aai_in_axis_tdata     [0] ; 
    r_dbg_0_aai_in_axis_tlast       <=  r_aai_in_axis_tlast     [0] ; 
    r_dbg_0_aai_in_axis_tkeep       <=  r_aai_in_axis_tkeep     [0] ; 
    r_dbg_0_aai_out_axis_tvalid     <=  w_aai_out_axis_tvalid   [0] ; 
    r_dbg_0_aai_out_axis_tdata      <=  w_aai_out_axis_tdata    [0] ;
    r_dbg_0_aai_out_axis_tlast      <=  w_aai_out_axis_tlast    [0] ; 
    r_dbg_0_aai_out_axis_tcnt       <=  r_aai_out_axis_tcnt     [0] ; 
    r_dbg_0_aai_in_blk_id           <=  r_aai_in_blk_id         [0] ; 
    r_dbg_0_aai_out_blk_id          <=  r_aai_out_blk_id        [0] ; 
    r_dbg_0_aai_in_wdog_cnt         <=  r_aai_in_wdog_cnt       [0] ; 
    r_dbg_0_aai_in_wdog_chk         <=  r_aai_in_wdog_chk       [0] ;    
    r_dbg_0_aai_in_wdog_chk_cnt     <=  r_aai_in_wdog_chk_cnt   [0] ; 
    r_dbg_0_aai_in_rec_tvalid       <=  r_aai_in_rec_tvalid     [0] ;
    r_dbg_0_aai_in_rec_tlast        <=  r_aai_in_rec_tlast      [0] ;
    r_dbg_0_aai_in_rec_done         <=  r_aai_in_rec_done       [0] ;
    r_dbg_1_aai_in_axis_tvalid      <=  r_aai_in_axis_tvalid    [1] ; 
    r_dbg_1_aai_in_axis_tdata       <=  r_aai_in_axis_tdata     [1] ; 
    r_dbg_1_aai_in_axis_tlast       <=  r_aai_in_axis_tlast     [1] ; 
    r_dbg_1_aai_in_axis_tkeep       <=  r_aai_in_axis_tkeep     [1] ; 
    r_dbg_1_aai_out_axis_tvalid     <=  w_aai_out_axis_tvalid   [1] ; 
    r_dbg_1_aai_out_axis_tdata      <=  w_aai_out_axis_tdata    [1] ;
    r_dbg_1_aai_out_axis_tlast      <=  w_aai_out_axis_tlast    [1] ; 
    r_dbg_1_aai_out_axis_tcnt       <=  r_aai_out_axis_tcnt     [1] ; 
    r_dbg_1_aai_in_blk_id           <=  r_aai_in_blk_id         [1] ; 
    r_dbg_1_aai_out_blk_id          <=  r_aai_out_blk_id        [1] ; 
    r_dbg_1_aai_in_wdog_cnt         <=  r_aai_in_wdog_cnt       [1] ; 
    r_dbg_1_aai_in_wdog_chk         <=  r_aai_in_wdog_chk       [1] ;    
    r_dbg_1_aai_in_wdog_chk_cnt     <=  r_aai_in_wdog_chk_cnt   [1] ; 
    r_dbg_1_aai_in_rec_tvalid       <=  r_aai_in_rec_tvalid     [1] ;
    r_dbg_1_aai_in_rec_tlast        <=  r_aai_in_rec_tlast      [1] ;
    r_dbg_1_aai_in_rec_done         <=  r_aai_in_rec_done       [1] ;
    r_dbg_frame_sync                <=  w_frame_sync                ;
    r_dbg_subfrm_sync               <=  w_subfrm_sync               ;
    r_dbg_slot_sync                 <=  w_slot_sync                 ;
    r_dbg_symbol_sync               <=  w_symbol_sync               ;
    r_dbg_subfrm                    <=  w_subfrm                    ;
    r_dbg_slot                      <=  w_slot                      ;
    r_dbg_symbol                    <=  w_symbol                    ;
end
ila_dlfe_aie_pkt ila_dlfe_aie_pkt
(
     .clk    (   i_clk                          )
    ,.probe0 (   r_dbg_0_aai_in_axis_tvalid     )
    ,.probe1 (   r_dbg_0_aai_in_axis_tdata      )
    ,.probe2 (   r_dbg_0_aai_in_axis_tlast      )
    ,.probe3 (   r_dbg_0_aai_in_axis_tkeep      )
    ,.probe4 (   r_dbg_0_aai_out_axis_tvalid    )
    ,.probe5 (   r_dbg_0_aai_out_axis_tdata     )
    ,.probe6 (   r_dbg_0_aai_out_axis_tlast     )
    ,.probe7 (   r_dbg_0_aai_out_axis_tcnt      )
    ,.probe8 (   r_dbg_0_aai_in_blk_id          )
    ,.probe9 (   r_dbg_0_aai_out_blk_id         )
    ,.probe10(   r_dbg_0_aai_in_wdog_cnt        )
    ,.probe11(   r_dbg_0_aai_in_wdog_chk        )
    ,.probe12(   r_dbg_0_aai_in_wdog_chk_cnt    )
    ,.probe13(   r_dbg_0_aai_in_rec_tvalid      )
    ,.probe14(   r_dbg_0_aai_in_rec_tlast       )
    ,.probe15(   r_dbg_0_aai_in_rec_done        )
    ,.probe16(   r_dbg_1_aai_in_axis_tvalid     )
    ,.probe17(   r_dbg_1_aai_in_axis_tdata      )
    ,.probe18(   r_dbg_1_aai_in_axis_tlast      )
    ,.probe19(   r_dbg_1_aai_in_axis_tkeep      )
    ,.probe20(   r_dbg_1_aai_out_axis_tvalid    )
    ,.probe21(   r_dbg_1_aai_out_axis_tdata     )
    ,.probe22(   r_dbg_1_aai_out_axis_tlast     )
    ,.probe23(   r_dbg_1_aai_out_axis_tcnt      )
    ,.probe24(   r_dbg_1_aai_in_blk_id          )
    ,.probe25(   r_dbg_1_aai_out_blk_id         )
    ,.probe26(   r_dbg_1_aai_in_wdog_cnt        )
    ,.probe27(   r_dbg_1_aai_in_wdog_chk        )
    ,.probe28(   r_dbg_1_aai_in_wdog_chk_cnt    )
    ,.probe29(   r_dbg_1_aai_in_rec_tvalid      )
    ,.probe30(   r_dbg_1_aai_in_rec_tlast       )
    ,.probe31(   r_dbg_1_aai_in_rec_done        )
    ,.probe32(   r_dbg_frame_sync               )
    ,.probe33(   r_dbg_subfrm_sync              )
    ,.probe34(   r_dbg_slot_sync                )
    ,.probe35(   r_dbg_symbol_sync              )
    ,.probe36(   r_dbg_subfrm                   )
    ,.probe37(   r_dbg_slot                     )
    ,.probe38(   r_dbg_symbol                   )
);
`endif //DLFE_INNER_ILA_DISABLE
`else// DLFE_AIE_DISABLE
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g03_ifft_dly_chk
ylib_mon_sync_diff #(.WIDTH(13)) 
u05_ifft_dly 
(
     .i_clk     (i_clk  )
    ,.i_sync0   ((w_shift_a_sat_en[0]&~r_shift_a_sat_en[0])&&(i_din_cc_id[((`mlib_clog2(NUM_CC))*(0+1)-1)-:`mlib_clog2(NUM_CC)]==({{`mlib_clog2(NUM_CC)}{1'b1}}&gidx))&&(i_din_ant_id[(($clog2(NUM_ANT))*(0+1)-1)-:($clog2(NUM_ANT))]=={{$clog2(NUM_ANT)}{1'b0}})   )
    ,.i_sync1   ((w_ifft_out_en[0]&w_ifft_out_sop[0])&&(r_cc_id[0]==({{`mlib_clog2(NUM_CC)}{1'b1}}&gidx))&&(r_ant_id[0]=={{$clog2(NUM_ANT)}{1'b0}})         )
    ,.o_diff    (o_dlfe_rpt_1048[((13)*(gidx+1)-1)-:(13)]   )
);
always@(posedge i_clk) begin
    for(i=0;i<NUM_O_CHAIN;i=i+1) begin
        if(i_rst[gidx]) begin
            r_ifft_out_err_mon[gidx][((02)*(i+1)-1)-:(02)] <= 2'd0 ;
        end
        else if(|w_ifft_out_err[i]&&(r_cc_id[i]==({{`mlib_clog2(NUM_CC)}{1'b1}}&gidx))) begin
            r_ifft_out_err_mon[gidx][((02)*(i+1)-1)-:(02)] <= w_ifft_out_err[i] ;
        end
    end
end
assign o_dlfe_rpt_104c [((02*NUM_O_CHAIN)*(gidx+1)-1)-:(02*NUM_O_CHAIN)] = r_ifft_out_err_mon[gidx] ;
end
endgenerate
`endif// DLFE_AIE_DISABLE
endmodule
