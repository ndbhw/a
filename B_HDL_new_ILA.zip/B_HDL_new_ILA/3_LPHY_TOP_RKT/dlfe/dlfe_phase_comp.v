//////////////////////////////////////////////////////////////////////////////// // 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10/FSU20
//                 oRU : DCM RT4419/RT4422
//                       VzW RT8808/RF4440d
//                       VDF RF4448/RF4449
//                       MSTR_V02
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_phase_comp
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe phase compensation (configurable cell multiplexing) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.15 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.11.16 | jyzoo.lee     | Add RAMs for Phase Coeffients 
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2021.03.15 | jyzoo.lee     | Supports LTE
//  ------------+---------------+-----------------------------------------------
//   2021.05.03 | jyzoo.lee     | Processing for Calibration Symbol
//  ------------+---------------+-----------------------------------------------
//   2021.05.10 | jyzoo.lee     | Xilinx Cmult Support for Resource Reduction
//  ------------+---------------+-----------------------------------------------
//   2021.06.10 | jyzoo.lee     | DSS Support
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | multi cc multiplexing support
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_phase_comp
#(
    parameter  NUM_CC               =   1
   ,parameter  NUM_ANT              =   4
   ,parameter  NUM_CHAIN            =   1
   ,parameter  DI_BW                =   16           
   ,parameter  DO_BW                =   16           
   ,parameter  MAX_MU               =   0
   ,parameter  ADDR_OFFSET          =   'h00000           
   ,parameter  VENDOR               =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_clk                  
            
    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid

    //--- from dlfe_param_if
    ,   input   wire    [32*NUM_CC-1:0]                         i_dlfe_par_1200
    
    //--- from dlfe_in_if or dlfe_ifft_map_buf
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_subfrm_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [01*NUM_CHAIN-1:0]                      i_din_en        
    ,   input   wire    [2*DI_BW*NUM_CHAIN-1:0]                 i_din_iq                
    ,   input   wire    [01-1:0]                                i_din_sys_mode_dss
    ,   input   wire    [(`mlib_clog2(NUM_CC))*NUM_CHAIN-1:0]   i_din_cc_id
    ,   input   wire    [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         i_din_ant_id
    ,   input   wire    [04-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_ofdm_mod
    ,   output  wire    [01-1:0]                                o_dout_frame_sync
    ,   output  wire    [01-1:0]                                o_dout_symbol_sync
    ,   output  wire    [01*NUM_CHAIN-1:0]                      o_dout_en        
    ,   output  wire    [2*DO_BW*NUM_CHAIN-1:0]                 o_dout_iq                
    ,   output  reg     [(`mlib_clog2(NUM_CC))*NUM_CHAIN-1:0]   o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         o_dout_ant_id
    ,   output  reg     [04-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size
    ,   output  reg     [02-1:0]                                o_dout_cal_en
);

//Parameter Local Logic
localparam                      CHAIN_REF           =       0                                       ;
localparam                      NUM_PHASE           =       12'd14*(2**MAX_MU)                      ;   
localparam                      NUM_SYM_SLOT        =       4'd14                                   ;   
localparam                      BW_PHASE            =       16                                      ;
localparam                      PC_DSHIFT           =       4'd11                                   ;
localparam                      DLY_IN              =       4                                       ;   
localparam                      DLY_SYNC            =       13                                      ;   
localparam                      DLY_REG_RD          =       1                                       ;
localparam  [19:00]             PHASE_START_ADDR    =       ADDR_OFFSET+'h01600                     ;
localparam  [19:00]             PHASE_END_ADDR      =       PHASE_START_ADDR+((NUM_PHASE-1)<<2)     ;
localparam  [BW_PHASE*2-1:0]    PHASE_DEG_000       =      'h08000000                               ;

//Logic Variable
integer i ;
genvar gidx ;

reg [01-1:0]    r_cpu_wren     [NUM_CC-1:0] ;
reg [01-1:0]    r_cpu_rden     [NUM_CC-1:0] ;
reg [20-1:0]    r_cpu_addr     [NUM_CC-1:0] ;
reg [32-1:0]    r_cpu_wdata    [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cpu_wren  [i] = i_cpu_wren[i]  ;
        r_cpu_rden  [i] = i_cpu_rden[i]  ;
        r_cpu_addr  [i] = i_cpu_addr [((20)*(i+1)-1)-:(20)] ;
        r_cpu_wdata [i] = i_cpu_wdata[((32)*(i+1)-1)-:(32)] ;
    end
end
reg [31:0] r_sys_mode   [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(i_din_frame_sync) begin 
            r_sys_mode[i]  <=  i_dlfe_par_1200 [((32)*(i+1)-1)-:(32)]   ;
        end
    end
end
reg [7:0] r_phase_symbol_idx ;
always@(posedge i_clk) begin
    if(i_din_subfrm_sync) begin
        r_phase_symbol_idx  <=  8'd0 ;
    end
    else if(i_din_symbol_sync) begin
        r_phase_symbol_idx  <=  r_phase_symbol_idx + 1'd1 ;
    end
end
reg [1-1:0]         r_en            [NUM_CHAIN-1:0][DLY_IN:0] ;
reg [2*DI_BW-1:0]   r_iq            [NUM_CHAIN-1:0][DLY_IN:0] ;   
reg [1-1:0]         r_sys_mode_dss  [NUM_CHAIN-1:0][DLY_IN:0] ;
reg [0:0]           r_buf_en        [NUM_CC-1:0]    ;
reg [0:0]           r_buf_wren      [NUM_CC-1:0]    ;
reg [19:0]          r_buf_addr      [NUM_CC-1:0]    ;
reg [31:0]          r_buf_wdata     [NUM_CC-1:0]    ;
reg [0:0]           r_buf_rden      [NUM_CC-1:0]    ;
wire[31:0]          w_buf_rdata     [NUM_CC-1:0]    ;
reg [01-1:0]        rr_buf_rden     [NUM_CC-1:0][DLY_REG_RD:0] ;
reg [31:0]          rr_buf_rdata    [NUM_CC-1:0][DLY_REG_RD:0] ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_phase_mem
always@(posedge i_clk) begin
    if(r_cpu_wren[gidx]&&r_cpu_addr[gidx]>=PHASE_START_ADDR&&r_cpu_addr[gidx]<=PHASE_END_ADDR) begin
        r_buf_en    [gidx]  <=  1'd1                                    ;
        r_buf_wren  [gidx]  <=  r_cpu_wren[gidx]                        ;
        r_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-PHASE_START_ADDR)>>2   ; 
        r_buf_wdata [gidx]  <=  r_cpu_wdata[gidx]                       ;
        r_buf_rden  [gidx]  <=  1'd0                                    ;
    end
    else if(r_cpu_rden[gidx]&&r_cpu_addr[gidx]>=PHASE_START_ADDR&&r_cpu_addr[gidx]<=PHASE_END_ADDR) begin
        r_buf_en    [gidx]  <=  1'd1                                    ;
        r_buf_wren  [gidx]  <=  1'd0                                    ;
        r_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-PHASE_START_ADDR)>>2   ; 
        r_buf_rden  [gidx]  <=  r_cpu_rden[gidx]                        ;
    end
    else if(r_en[CHAIN_REF][1]&&(i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]==gidx)) begin
        r_buf_en    [gidx]  <=  1'd1    ;
        r_buf_wren  [gidx]  <=  1'd0    ;
        r_buf_rden  [gidx]  <=  1'd0    ;
        r_buf_addr  [gidx]  <=  r_phase_symbol_idx ;  
    end
    else begin
        r_buf_en    [gidx]  <=  1'd0 ;
        r_buf_wren  [gidx]  <=  1'd0 ;
        r_buf_rden  [gidx]  <=  1'd0 ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   2*BW_PHASE          )
   ,.DEPTH  (   NUM_PHASE           )
   ,.VENDOR (   VENDOR              )) 
u00_phase_comp_mem (
    .clk    (i_clk                                      )
   ,.we     (r_buf_wren[gidx]                           )
   ,.en     (r_buf_en[gidx]                             )
   ,.addr   (r_buf_addr[gidx][$clog2(NUM_PHASE)-1:0]    )
   ,.di     (r_buf_wdata[gidx]                          )
   ,.dout   (w_buf_rdata[gidx]                          )
);
always@(posedge i_clk) begin
    rr_buf_rden[gidx][0] <= r_buf_rden[gidx]    ;
end
always@(*) begin
    rr_buf_rdata[gidx][0] = w_buf_rdata[gidx]   ;
end
if(DLY_REG_RD>0) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_REG_RD;i=i+1) begin
        rr_buf_rden[gidx][i] <= rr_buf_rden[gidx][i-1]   ;
        if(rr_buf_rden[gidx][i-1]) begin
            rr_buf_rdata[gidx][i]  <=  rr_buf_rdata[gidx][i-1]  ;
        end
    end
end
end
always@(*) begin
    o_cpu_rd_valid [((01)*(gidx+1)-1)-:(01)] = rr_buf_rden [gidx][DLY_REG_RD]   ;
    o_cpu_rdata    [((32)*(gidx+1)-1)-:(32)] = rr_buf_rdata[gidx][DLY_REG_RD]   ;
end
end
endgenerate
reg     [31:0]                      r_pw            [NUM_CHAIN-1:0] ;
wire    [0:0]                       w_pcomp_en      [NUM_CHAIN-1:0] ;
wire    [2*(DI_BW+BW_PHASE+1)-1:0]  w_pcomp_iq      [NUM_CHAIN-1:0] ;   
wire    [40-(DI_BW+BW_PHASE+1)-1:0] w_pcomp_i_dummy [NUM_CHAIN-1:0] ;
wire    [40-(DI_BW+BW_PHASE+1)-1:0] w_pcomp_q_dummy [NUM_CHAIN-1:0] ;
wire    [0:0]                       w_pcomp_r_en    [NUM_CHAIN-1:0] ;
wire    [2*(DI_BW+BW_PHASE+1)-1:0]  w_pcomp_r_iq    [NUM_CHAIN-1:0] ;   
generate for(gidx=0;gidx<NUM_CHAIN;gidx=gidx+1) begin : g01_pc_chain
always@(*) begin
    r_en[gidx][0] = i_din_en[((01)*(gidx+1)-1)-:(01)]   ;
    r_iq[gidx][0] = i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    r_sys_mode_dss[gidx][0] = i_din_sys_mode_dss  ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1]   ;
        r_sys_mode_dss[gidx][i] <= r_sys_mode_dss[gidx][i-1]   ;
        if(r_en[gidx][i-1]) begin
            r_iq[gidx][i] <= r_iq[gidx][i-1]   ;
        end
    end
end
always@(posedge i_clk) begin
    if(r_en[gidx][DLY_IN-1]) begin
`ifndef DLFE_DSS_DISABLE
        if(r_sys_mode_dss[gidx][DLY_IN-1]&&(~|i_din_cal_en)) begin
`else //DLFE_DSS_DISABLE
        if(r_sys_mode[i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]][28]&&(~|i_din_cal_en)) begin
`endif //DLFE_DSS_DISABLE
            r_pw[gidx] <= w_buf_rdata[i_din_cc_id[((`mlib_clog2(NUM_CC))*(CHAIN_REF+1)-1)-:`mlib_clog2(NUM_CC)]] ;
        end
        else begin
            r_pw[gidx] <= PHASE_DEG_000 ;
        end
    end
end
if(VENDOR=="Xilinx_Versal") begin
xip_cmult_bb_top_c16
u01_phase_comp
(
    .aclk                   (   i_clk                                           )
   ,.s_axis_a_tvalid        (   r_en[gidx][DLY_IN]                              )
   ,.s_axis_a_tdata         (  {{{{16-DI_BW}{r_iq[gidx][DLY_IN][(DI_BW*1-1)]}},r_iq[gidx][DLY_IN][(DI_BW*1-1)-:DI_BW]}
                               ,{{{16-DI_BW}{r_iq[gidx][DLY_IN][(DI_BW*2-1)]}},r_iq[gidx][DLY_IN][(DI_BW*2-1)-:DI_BW]}} )
   ,.s_axis_b_tvalid        (   r_en[gidx][DLY_IN]                              )
   ,.s_axis_b_tdata         (  {{{{16-BW_PHASE}{r_pw[gidx][(BW_PHASE*1-1)]}},r_pw[gidx][(BW_PHASE*1-1)-:BW_PHASE]}
                               ,{{{16-BW_PHASE}{r_pw[gidx][(BW_PHASE*2-1)]}},r_pw[gidx][(BW_PHASE*2-1)-:BW_PHASE]}} )
   ,.m_axis_dout_tvalid     (   w_pcomp_en[gidx]                                )
   ,.m_axis_dout_tdata      (  {w_pcomp_q_dummy[gidx],w_pcomp_iq[gidx][((DI_BW+BW_PHASE+1)*1-1)-:(DI_BW+BW_PHASE+1)],w_pcomp_i_dummy[gidx],w_pcomp_iq[gidx][((DI_BW+BW_PHASE+1)*2-1)-:(DI_BW+BW_PHASE+1)]}  )
);                  
end
else begin //(VENDOR=="Xilinx_Versal")
ylib_cmult #(
    .AWIDTH     (   DI_BW       )
   ,.BWIDTH     (   BW_PHASE    )
)
u01_phase_comp
(
    .clk    (   i_clk                                                           )
   ,.en     (   r_en[gidx][DLY_IN]                                              )
   ,.ar     (   r_iq[gidx][DLY_IN][(DI_BW*2-1)-:DI_BW]                          )
   ,.ai     (   r_iq[gidx][DLY_IN][(DI_BW*1-1)-:DI_BW]                          )
   ,.br     (   r_pw[gidx][(BW_PHASE*2-1)-:BW_PHASE]                            )
   ,.bi     (   r_pw[gidx][(BW_PHASE*1-1)-:BW_PHASE]                            )
   ,.pen    (   w_pcomp_en[gidx]                                                )
   ,.pr     (   w_pcomp_iq[gidx][((DI_BW+BW_PHASE+1)*2-1)-:(DI_BW+BW_PHASE+1)]  )
   ,.pi     (   w_pcomp_iq[gidx][((DI_BW+BW_PHASE+1)*1-1)-:(DI_BW+BW_PHASE+1)]  )
);
end //(VENDOR=="Xilinx_Versal")

ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                   )
 ,.SHIFTD_BW    (   $clog2(PC_DSHIFT)   )
 ,.IO_BW        (   DI_BW+BW_PHASE+1    ))
u02_pc_shiftd_rnd 
(
     .i_clk     (   i_clk                   )
    ,.i_in_en   (   w_pcomp_en[gidx]        )
    ,.i_in      (   w_pcomp_iq[gidx]        )
    ,.i_shiftd  (   4'd11                   )
    ,.o_out_en  (   w_pcomp_r_en[gidx]      )
    ,.o_out     (   w_pcomp_r_iq[gidx]      )
);
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_PHASE+1    )
 ,.DO_BW        (   DO_BW               ))
u03_pc_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_pcomp_r_en[gidx]                              )
    ,.i_in      (   w_pcomp_r_iq[gidx]                              )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_pcomp_r_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] <= i_din_cc_id [((`mlib_clog2(NUM_CC))*(gidx+1)-1)-:`mlib_clog2(NUM_CC)] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= i_din_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] ;
    end
end
end
endgenerate
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_pcomp_r_en[CHAIN_REF]&~o_dout_en[((01)*(CHAIN_REF+1)-1)-:(01)])) begin
        o_dout_mu           <=  i_din_mu            ;
        o_dout_fft_size     <=  i_din_fft_size      ;
        o_dout_cal_en       <=  i_din_cal_en        ;
    end
end
ylib_reg #(
     .WIDTH     (    2          ) 
    ,.DEPTH     (    DLY_SYNC   )) 
u04_fsync_dly
(
     .i_clk      (  i_clk               )
    ,.i_in       ( {i_din_frame_sync  , i_din_symbol_sync }   )
    ,.o_out      ( {o_dout_frame_sync , o_dout_symbol_sync}   )
);
endmodule
