////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common Library
//  Module       : ylib_sig_cap
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Multiplexing Signal Buses and Capturing on Time
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.06.15 | jyzoo.lee     | Created Initial Design
//  ------------+---------------+-----------------------------------------------
//   2021.12.06 | jyzoo.lee     | Modification according to ref_vsync_gen
//  ------------+---------------+-----------------------------------------------
//   2022.04.07 | jyzoo.lee     | Supports mode to ingnore Frame Index
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`define mlib_clog2(A) A > 1 ? $clog2(A) : 1 

module ylib_sig_cap
#(
     parameter  NUM_ITEM    =       1
    ,parameter  NUM_CC      =       1
    ,parameter  NUM_PATH    =       4
    ,parameter  BW_ADDR     =       15
    ,parameter  BW_DATA     =       32 
)(
     input   wire                                               i_clk

    ,input   wire    [01-1:0]                                   i_cap_en     
    ,input   wire    [(`mlib_clog2(NUM_CC))-1:0]                i_cap_cc_id
    ,input   wire    [$clog2(NUM_PATH)-1:0]                     i_cap_path_id
    ,input   wire    [12-1:0]                                   i_cap_frame_id
    ,input   wire    [04-1:0]                                   i_cap_subfrm_id
    ,input   wire    [08-1:0]                                   i_cap_slot_id
    ,input   wire    [04-1:0]                                   i_cap_symbol_id
    ,input   wire    [$clog2(NUM_ITEM)-1:0]                     i_cap_item_id
    ,input   wire    [03-1:0]                                   i_cap_mode   
    ,input   wire    [04-1:0]                                   i_cap_mu
    ,input   wire    [03-1:0]                                   i_cap_sr
    ,input   wire    [32-1:0]                                   i_cap_thres

    ,input   wire    [12*NUM_CC*NUM_ITEM-1:0]                   i_sig_frame_id
    ,input   wire    [01*NUM_CC*NUM_ITEM-1:0]                   i_sig_frame_sync
    ,input   wire    [01*NUM_PATH*NUM_CC*NUM_ITEM-1:0]          i_sig_data_en
    ,input   wire    [BW_DATA*NUM_PATH*NUM_CC*NUM_ITEM-1:0]     i_sig_data

    ,output  reg     [01-1:0]                                   o_cap_data_en
    ,output  reg     [BW_ADDR-1:0]                              o_cap_data_addr
    ,output  reg     [BW_DATA-1:0]                              o_cap_data
);

localparam      CAP0_SYMBOL_WOVAL_CORE_CLK_SR   =       3'd0    ;
localparam      CAP0_SYMBOL_WVAL_CORE_CLK_SR    =       3'd1    ;
localparam      CAP1_ON_VAL_WSR                 =       3'd2    ;
localparam      CAP2_TRIG_POW                   =       3'd3    ;
localparam      MEM_INIT                        =       3'd7    ;
localparam      DLY_SYNC                        =       22'd4   ;

genvar gidx ;

reg r_cap_en ;
always@(posedge i_clk) begin
    r_cap_en <= i_cap_en ;
end
reg [12*NUM_CC-1:0]               r_item_sig_frame_id   [NUM_ITEM-1:0] ;
reg [01*NUM_CC-1:0]               r_item_sig_frame_sync [NUM_ITEM-1:0] ;
reg [01*NUM_PATH*NUM_CC-1:0]      r_item_sig_data_en    [NUM_ITEM-1:0] ;
reg [BW_DATA*NUM_PATH*NUM_CC-1:0] r_item_sig_data       [NUM_ITEM-1:0] ;
generate for(gidx=0; gidx<NUM_ITEM; gidx=gidx+1) begin : g00_cap_item
always@(*) begin
    r_item_sig_frame_id   [gidx] = i_sig_frame_id   [((12*NUM_CC)*(gidx+1)-1)-:(12*NUM_CC)] ;
    r_item_sig_frame_sync [gidx] = i_sig_frame_sync [((01*NUM_CC)*(gidx+1)-1)-:(01*NUM_CC)] ;
    r_item_sig_data_en    [gidx] = i_sig_data_en    [((01*NUM_PATH*NUM_CC)*(gidx+1)-1)-:(01*NUM_PATH*NUM_CC)] ;
    r_item_sig_data       [gidx] = i_sig_data       [((BW_DATA*NUM_PATH*NUM_CC)*(gidx+1)-1)-:(BW_DATA*NUM_PATH*NUM_CC)] ;
end
end
endgenerate
reg [12*NUM_CC-1:0]               r_item_sel_sig_frame_id   ;
reg [01*NUM_CC-1:0]               r_item_sel_sig_frame_sync ;
reg [01*NUM_PATH*NUM_CC-1:0]      r_item_sel_sig_data_en    ;
reg [BW_DATA*NUM_PATH*NUM_CC-1:0] r_item_sel_sig_data       ;
always@(posedge i_clk) begin
    r_item_sel_sig_frame_sync <= r_item_sig_frame_sync [i_cap_item_id] ;
    if(i_cap_en) begin
        r_item_sel_sig_frame_id   <= r_item_sig_frame_id   [i_cap_item_id] ;
        r_item_sel_sig_data_en    <= r_item_sig_data_en    [i_cap_item_id] ;
        r_item_sel_sig_data       <= r_item_sig_data       [i_cap_item_id] ;
    end
end
reg [12-1:0]               r_cc_sig_frame_id   [NUM_CC-1:0] ;
reg [01-1:0]               r_cc_sig_frame_sync [NUM_CC-1:0] ;
reg [01*NUM_PATH-1:0]      r_cc_sig_data_en    [NUM_CC-1:0] ;
reg [BW_DATA*NUM_PATH-1:0] r_cc_sig_data       [NUM_CC-1:0] ;
generate for(gidx=0; gidx<NUM_CC; gidx=gidx+1) begin : g01_cap_cc
always@(*) begin
    r_cc_sig_frame_id   [gidx] = r_item_sel_sig_frame_id   [((12)*(gidx+1)-1)-:(12)] ;
    r_cc_sig_frame_sync [gidx] = r_item_sel_sig_frame_sync [((01)*(gidx+1)-1)-:(01)] ;
    r_cc_sig_data_en    [gidx] = r_item_sel_sig_data_en    [((01*NUM_PATH)*(gidx+1)-1)-:(01*NUM_PATH)] ;
    r_cc_sig_data       [gidx] = r_item_sel_sig_data       [((BW_DATA*NUM_PATH)*(gidx+1)-1)-:(BW_DATA*NUM_PATH)] ;
end
end
endgenerate
reg [12-1:0]               r_cc_sel_sig_frame_id   ;
reg [01-1:0]               r_cc_sel_sig_frame_sync ;
reg [01*NUM_PATH-1:0]      r_cc_sel_sig_data_en    ;
reg [BW_DATA*NUM_PATH-1:0] r_cc_sel_sig_data       ;
always@(posedge i_clk) begin
    r_cc_sel_sig_frame_sync <= r_cc_sig_frame_sync [i_cap_cc_id] ;
    if(i_cap_en) begin
        r_cc_sel_sig_frame_id   <= r_cc_sig_frame_id   [i_cap_cc_id] ;
        r_cc_sel_sig_data_en    <= r_cc_sig_data_en    [i_cap_cc_id] ;
        r_cc_sel_sig_data       <= r_cc_sig_data       [i_cap_cc_id] ;
    end
end
reg [12-1:0]               r_path_sig_frame_id   ;
reg [01-1:0]               r_path_sig_frame_sync ;
reg [01-1:0]               r_path_sig_data_en    [NUM_PATH-1:0] ;
reg [BW_DATA-1:0]          r_path_sig_data       [NUM_PATH-1:0] ;
always@(*) begin
    r_path_sig_frame_id   = r_cc_sel_sig_frame_id   ;
    r_path_sig_frame_sync = r_cc_sel_sig_frame_sync ;
end
generate for(gidx=0; gidx<NUM_PATH; gidx=gidx+1) begin : g02_cap_path
always@(*) begin
    r_path_sig_data_en    [gidx] = r_cc_sel_sig_data_en    [((01)*(gidx+1)-1)-:(01)] ;
    r_path_sig_data       [gidx] = r_cc_sel_sig_data       [((BW_DATA)*(gidx+1)-1)-:(BW_DATA)] ;
end
end
endgenerate
reg [12-1:0]      r_path_sel_sig_frame_id   ;
reg [01-1:0]      r_path_sel_sig_frame_sync ;
reg [01-1:0]      r_path_sel_sig_data_en    ;
reg [BW_DATA-1:0] r_path_sel_sig_data       ;
always@(posedge i_clk) begin
    r_path_sel_sig_frame_sync <= r_path_sig_frame_sync  ;
    if(i_cap_en) begin
        if(r_path_sig_frame_sync) begin
            r_path_sel_sig_frame_id   <= r_path_sig_frame_id    ;
        end
        r_path_sel_sig_data_en    <= r_path_sig_data_en [i_cap_path_id]  ;
        r_path_sel_sig_data       <= r_path_sig_data    [i_cap_path_id]  ;
    end
end
reg [01-1:0]      r_frm_cap_sig_frame_sync  ;
reg [01-1:0]      r_frm_cap_sig_data_en     ;
reg [BW_DATA-1:0] r_frm_cap_sig_data        ;
reg [01-1:0]      r_frm_cap_en              ;
always@(posedge i_clk) begin
    r_frm_cap_sig_frame_sync <= r_path_sel_sig_frame_sync   ;
    if(i_cap_en) begin
        if(&i_cap_frame_id) begin
            r_frm_cap_sig_data_en    <= r_path_sel_sig_data_en      ;
            r_frm_cap_sig_data       <= r_path_sel_sig_data         ;
            r_frm_cap_en             <= 1'd1                        ;
        end
        else begin
            if(r_path_sel_sig_frame_id==i_cap_frame_id) begin
                r_frm_cap_sig_data_en    <= r_path_sel_sig_data_en      ;
                r_frm_cap_sig_data       <= r_path_sel_sig_data         ;
                r_frm_cap_en             <= 1'd1                        ;
            end
            else begin
                r_frm_cap_en             <= 1'd0                        ;
            end
        end
    end
    else begin
        r_frm_cap_en             <= 1'd0                        ;
    end
end

wire [01-1:0]      w_frm_cap_sig_data_en ;
wire [BW_DATA-1:0] w_frm_cap_sig_data    ;
wire [01-1:0]      w_frm_cap_en          ;
ylib_reg #(.WIDTH(1         ),.DEPTH(DLY_SYNC+1)) u00_0_sig_dly (.i_clk(i_clk),.i_in(r_frm_cap_en         ),.o_out(w_frm_cap_en         ));
ylib_reg #(.WIDTH(1         ),.DEPTH(DLY_SYNC+1)) u00_1_sig_dly (.i_clk(i_clk),.i_in(r_frm_cap_sig_data_en),.o_out(w_frm_cap_sig_data_en));
ylib_reg #(.WIDTH(BW_DATA   ),.DEPTH(DLY_SYNC+1)) u00_2_sig_dly (.i_clk(i_clk),.i_in(r_frm_cap_sig_data   ),.o_out(w_frm_cap_sig_data   ));

wire        w_cap_frame_sync     ;
wire        w_cap_subfrm_sync    ;
wire        w_cap_slot_sync      ;
wire        w_cap_symbol_sync    ;
wire [3:0]  w_cap_subfrm         ;
wire [7:0]  w_cap_slot           ;
wire [3:0]  w_cap_symbol         ;
ref_vsync_gen #(.SLOT_INC_TYPE ( "SUBFRAME" )) 
u01_cap_ref_sync
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( i_cap_mu                  )
    ,.i_retard              ( DLY_SYNC                  )
    ,.i_frame_sync          ( r_frm_cap_sig_frame_sync  )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_cap_frame_sync          )   
    ,.o_subfrm_sync         ( w_cap_subfrm_sync         )   
    ,.o_slot_sync           ( w_cap_slot_sync           )   
    ,.o_symbol_sync         ( w_cap_symbol_sync         )   
    ,.o_subfrm              ( w_cap_subfrm              )          
    ,.o_slot                ( w_cap_slot                )          
    ,.o_symbol              ( w_cap_symbol              )          
);
reg [01-1:0]      r_cap0_symbol_en  ;
reg [01-1:0]      r_cap0_data_en    ;
reg [BW_DATA-1:0] r_cap0_data       ;
reg [01-1:0]      r_cap0_done       ;
always@(posedge i_clk) begin
    if(i_cap_en&(r_cap0_done==1'b0&&w_frm_cap_en&&w_cap_subfrm==i_cap_subfrm_id&&w_cap_slot==i_cap_slot_id&&w_cap_symbol==i_cap_symbol_id)) begin
        r_cap0_symbol_en <= 1'd1 ;
        r_cap0_data_en   <= w_frm_cap_sig_data_en    ;
        r_cap0_data      <= w_frm_cap_sig_data       ;
    end
    else begin
        r_cap0_symbol_en <= 1'd0 ;
    end
end
reg [01-1:0]      rr_cap0_data_en     ;
reg [BW_DATA-1:0] rr_cap0_data        ;
always@(posedge i_clk) begin
    if(i_cap_en&&r_cap0_done==1'b0&&i_cap_mode==CAP0_SYMBOL_WOVAL_CORE_CLK_SR) begin
        rr_cap0_data_en  <=  r_cap0_symbol_en ;
        rr_cap0_data     <=  r_cap0_data      ;
    end
    else if(i_cap_en&&r_cap0_done==1'b0&&i_cap_mode==CAP0_SYMBOL_WVAL_CORE_CLK_SR) begin
        rr_cap0_data_en  <=  r_cap0_symbol_en ;
        rr_cap0_data     <= {r_cap0_data[BW_DATA-1:1],r_cap0_data_en} ;
    end
    else begin
        rr_cap0_data_en  <=  1'd0 ;
    end
end
reg [BW_ADDR-1:0] rr_cap0_data_addr   ;
always@(posedge i_clk) begin
    if(r_cap0_symbol_en&~rr_cap0_data_en) begin
        rr_cap0_data_addr <= {{BW_ADDR}{1'b0}} ;
    end
    else if(rr_cap0_data_en) begin
        rr_cap0_data_addr <= rr_cap0_data_addr + 1'd1 ;
    end
end
always@(posedge i_clk) begin
    if(i_cap_en) begin
        if(~r_cap0_symbol_en&rr_cap0_data_en) begin
            r_cap0_done <=  1'b1 ;
        end
    end
    else begin
        r_cap0_done <=  1'b0 ;
    end
end
reg [01-1:0]      r_cap1_symbol_en  ;
reg [01-1:0]      r_cap1_data_en    ;
reg [BW_DATA-1:0] r_cap1_data       ;
always@(posedge i_clk) begin
    if(i_cap_en) begin
        r_cap1_data_en   <= w_frm_cap_sig_data_en    ;
        r_cap1_data      <= w_frm_cap_sig_data       ;
        if(w_cap_symbol_sync&(w_frm_cap_en&&w_cap_subfrm==i_cap_subfrm_id&&w_cap_slot==i_cap_slot_id&&w_cap_symbol==i_cap_symbol_id)) begin
            r_cap1_symbol_en <= 1'd1 ;
        end
    end
    else begin
        r_cap1_symbol_en <= 1'd0 ;
    end
end
reg [01-1:0]      rr_cap1_data_en   ;
reg [BW_DATA-1:0] rr_cap1_data      ;
always@(posedge i_clk) begin
    if((i_cap_en&r_cap1_symbol_en)&&(i_cap_mode==CAP1_ON_VAL_WSR)) begin
        rr_cap1_data_en     <=  r_cap1_data_en      ;
        rr_cap1_data        <=  r_cap1_data         ;
    end
    else begin
        rr_cap1_data_en  <=  1'd0  ;
    end
end
reg [06-1:0]      rr_cap1_data_sr_cnt ;
reg [BW_ADDR-1:0] rr_cap1_data_addr   ;
always@(posedge i_clk) begin
    if(i_cap_en&~r_cap_en) begin
        rr_cap1_data_sr_cnt <= 6'd0 ;
        rr_cap1_data_addr <= {{BW_ADDR}{1'b0}} ;
    end
    else if(rr_cap1_data_en) begin
        rr_cap1_data_sr_cnt <= rr_cap1_data_sr_cnt + 1'd1 ;
        case(i_cap_sr) 
            3'd0    :   begin rr_cap1_data_addr <=  rr_cap1_data_addr + 1'd1 ;                                                end   
            3'd1    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[0:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            3'd2    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[1:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            3'd3    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[2:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            3'd4    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[3:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            3'd5    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[4:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            3'd6    :   begin rr_cap1_data_addr <= &rr_cap1_data_sr_cnt[5:0] ? rr_cap1_data_addr + 1'd1 : rr_cap1_data_addr ; end 
            default :   begin rr_cap1_data_addr <= {{BW_ADDR}{1'b0}} ;                                                        end 
        endcase
    end
end
reg [01-1:0] rr_cap1_done ;
always@(posedge i_clk) begin
    if(i_cap_en) begin
        if(rr_cap1_data_addr=={{BW_ADDR}{1'b1}}) begin
            rr_cap1_done <=  1'b1 ;
        end
    end
    else begin
        rr_cap1_done <=  1'b0 ;
    end
end
reg [01-1:0]      rrr_cap1_data_en      ;
reg [BW_ADDR-1:0] rrr_cap1_data_addr    ;
reg [BW_DATA-1:0] rrr_cap1_data         ;
always@(posedge i_clk) begin
    if(i_cap_en&(rr_cap1_done==1'b0&&i_cap_mode==CAP1_ON_VAL_WSR)) begin
        rrr_cap1_data_en     <=  rr_cap1_data_en    ;
        rrr_cap1_data_addr   <=  rr_cap1_data_addr  ;
        rrr_cap1_data        <=  rr_cap1_data       ;
    end
    else begin
        rrr_cap1_data_en  <=  1'd0  ;
    end
end
reg [01-1:0]      r_init_data_en    ;
reg [BW_ADDR-1:0] r_init_data_addr  ;
always@(posedge i_clk) begin
    if(i_cap_en&~r_cap_en) begin
        r_init_data_addr <= {{BW_ADDR}{1'b0}} ;
        r_init_data_en   <= 1'd1 ;
    end
    else if(r_cap_en&&i_cap_mode==MEM_INIT) begin
        if(r_init_data_addr<{{BW_ADDR}{1'b1}}) begin
            r_init_data_addr <= r_init_data_addr + 1'd1 ;
        end
        else if(r_init_data_addr=={{BW_ADDR}{1'b1}}) begin
            r_init_data_en  <= 1'b0 ;
        end
    end
    else begin
        r_init_data_en <= 1'd0 ;
    end
end

reg [01-1:0]      r_cap2_symbol_en  ;
reg [01-1:0]      r_cap2_data_en    ;
reg [BW_DATA-1:0] r_cap2_data       ;
reg [01-1:0]      r_cap2_done       ;
always@(posedge i_clk) begin
    if(i_cap_en&(r_cap2_done==1'b0&&w_frm_cap_en&&w_cap_subfrm==i_cap_subfrm_id&&w_cap_slot==i_cap_slot_id&&w_cap_symbol==i_cap_symbol_id)) begin
        r_cap2_symbol_en <= 1'd1 ;
        r_cap2_data_en   <= w_frm_cap_sig_data_en    ;
        r_cap2_data      <= w_frm_cap_sig_data       ;
    end
    else begin
        r_cap2_symbol_en <= 1'd0 ;
    end
end
reg [01-1:0]      rr_cap2_data_en     ;
reg [BW_DATA-1:0] rr_cap2_data        ;
always@(posedge i_clk) begin
    if(i_cap_en&&r_cap2_done==1'b0&&i_cap_mode==CAP2_TRIG_POW) begin
        rr_cap2_data_en  <=  r_cap2_symbol_en ;
        rr_cap2_data     <=  r_cap2_data      ;
    end
    else begin
        rr_cap2_data_en  <=  1'd0 ;
    end
end
reg [BW_ADDR-1:0] rr_cap2_data_addr   ;
always@(posedge i_clk) begin
    if(r_cap2_symbol_en&~rr_cap2_data_en) begin
        rr_cap2_data_addr <= {{BW_ADDR}{1'b0}} ;
    end
    else if(rr_cap2_data_en) begin
        rr_cap2_data_addr <= rr_cap2_data_addr + 1'd1 ;
    end
end
reg r_dump_pow_report_sync  ;
always@(posedge i_clk) begin
    r_dump_pow_report_sync  <=  ~rr_cap2_data_en&o_cap_data_en ;
end
reg [0:0]               r_pow2_en           ;
reg [2*BW_DATA/2-1:0]   r_pow2_i            ;
reg [2*BW_DATA/2-1:0]   r_pow2_q            ;
reg [0:0]               r_pow2_iq_en        ;
reg [2*BW_DATA/2:0]     r_pow2_iq           ;
reg [63:0]              r_dump_pow          ;
reg [0:0]               r_dump_pow_rpt_en   ;
reg [63:0]              r_dump_pow_rpt      ;
always@(posedge i_clk) begin 
    r_pow2_en <=  rr_cap2_data_en  ;
    if(rr_cap2_data_en) begin
        r_pow2_i    <=  $signed({{{BW_DATA/2}{rr_cap2_data[BW_DATA-1]}},rr_cap2_data[(BW_DATA-1)-:(BW_DATA/2)]})*$signed({{{BW_DATA/2}{rr_cap2_data[BW_DATA-1]}},rr_cap2_data[(BW_DATA-1)-:(BW_DATA/2)]})   ;
        r_pow2_q    <=  $signed({{{BW_DATA/2}{rr_cap2_data[BW_DATA/2-1]}},rr_cap2_data[(BW_DATA/2-1)-:(BW_DATA/2)]})*$signed({{{BW_DATA/2}{rr_cap2_data[BW_DATA/2-1]}},rr_cap2_data[(BW_DATA/2-1)-:(BW_DATA/2)]})   ;
    end
end
always@(posedge i_clk) begin 
    r_pow2_iq_en    <=  r_pow2_en  ;
    if(~r_pow2_en&r_pow2_iq_en) begin
        r_pow2_iq <= {{BW_DATA}{1'b0}} ;
    end
    else if(r_pow2_en) begin
        r_pow2_iq <=  {1'd0,r_pow2_i}+{1'd0,r_pow2_q}   ;
    end
end
always@(posedge i_clk) begin 
    if(rr_cap2_data_en&~o_cap_data_en) begin
        r_dump_pow  <= 64'd0    ;
    end
    else if(r_pow2_iq_en) begin
        r_dump_pow  <= r_dump_pow_report_sync ? 64'd0 : r_dump_pow + r_pow2_iq  ;
    end        
end
always@(posedge i_clk) begin 
    r_dump_pow_rpt_en <= r_dump_pow_report_sync ;
    if(i_cap_en&~r_cap_en) begin
        r_dump_pow_rpt  <= 64'd0 ;
    end
    else if(r_dump_pow_report_sync) begin
        r_dump_pow_rpt  <= r_dump_pow ;
    end
end
always@(posedge i_clk) begin
    if(r_cap_en&&i_cap_mode==CAP2_TRIG_POW) begin
        if(r_dump_pow_rpt>i_cap_thres) begin
            r_cap2_done <=  1'b1 ;
        end
    end
    else begin
        r_cap2_done <=  1'b0 ;
    end
end
always@(posedge i_clk) begin
    if(i_cap_en) begin
        case(i_cap_mode) 
            CAP0_SYMBOL_WOVAL_CORE_CLK_SR   : begin o_cap_data_en <= rr_cap0_data_en  ; o_cap_data_addr <= rr_cap0_data_addr  ; o_cap_data <= rr_cap0_data      ; end
            CAP0_SYMBOL_WVAL_CORE_CLK_SR    : begin o_cap_data_en <= rr_cap0_data_en  ; o_cap_data_addr <= rr_cap0_data_addr  ; o_cap_data <= rr_cap0_data      ; end
            CAP1_ON_VAL_WSR                 : begin o_cap_data_en <= rrr_cap1_data_en ; o_cap_data_addr <= rrr_cap1_data_addr ; o_cap_data <= rrr_cap1_data     ; end
            CAP2_TRIG_POW                   : begin o_cap_data_en <= rr_cap2_data_en  ; o_cap_data_addr <= rr_cap2_data_addr  ; o_cap_data <= rr_cap2_data      ; end
            MEM_INIT                        : begin o_cap_data_en <= r_init_data_en   ; o_cap_data_addr <= r_init_data_addr   ; o_cap_data <= {{BW_DATA}{1'b0}} ; end
            default                         : begin o_cap_data_en <= 1'd0; o_cap_data_addr <= {{BW_ADDR}{1'b0}}; o_cap_data <= {{BW_DATA}{1'b0}} ; end
        endcase
    end
    else begin
        o_cap_data_en <= 1'd0 ;
    end
end
endmodule
