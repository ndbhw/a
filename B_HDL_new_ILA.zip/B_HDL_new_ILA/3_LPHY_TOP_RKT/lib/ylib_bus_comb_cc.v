////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2019 Samsung Electronics Inc. All rights reserved
//
//  Project      : Verizon FSU20
//  Module       : ylib_bus_comb_cc
//  Author       : taeyeong
//  Description  : bus combine 24 to 1
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.03 | taeyeong      | Inital Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_bus_comb_cc #(
     parameter  IB          =   16
    ,parameter  OB          =   16
    ,parameter  DLY         =    0          
)(
     input   wire                              i_clk

    ,input   wire    [IB*2     -1:0]           i_in_00 
    ,input   wire    [IB*2     -1:0]           i_in_01 
    ,input   wire    [IB*2     -1:0]           i_in_02 
    ,input   wire    [IB*2     -1:0]           i_in_03 

    ,input   wire    [IB*2     -1:0]           i_in_10 
    ,input   wire    [IB*2     -1:0]           i_in_11 
    ,input   wire    [IB*2     -1:0]           i_in_12 
    ,input   wire    [IB*2     -1:0]           i_in_13 

    ,input   wire    [IB*2     -1:0]           i_in_20 
    ,input   wire    [IB*2     -1:0]           i_in_21 
    ,input   wire    [IB*2     -1:0]           i_in_22 
    ,input   wire    [IB*2     -1:0]           i_in_23 

    ,input   wire    [IB*2     -1:0]           i_in_30 
    ,input   wire    [IB*2     -1:0]           i_in_31 
    ,input   wire    [IB*2     -1:0]           i_in_32 
    ,input   wire    [IB*2     -1:0]           i_in_33 

    ,input   wire    [IB*2     -1:0]           i_in_40 
    ,input   wire    [IB*2     -1:0]           i_in_41 
    ,input   wire    [IB*2     -1:0]           i_in_42 
    ,input   wire    [IB*2     -1:0]           i_in_43 

    ,input   wire    [IB*2     -1:0]           i_in_50 
    ,input   wire    [IB*2     -1:0]           i_in_51 
    ,input   wire    [IB*2     -1:0]           i_in_52 
    ,input   wire    [IB*2     -1:0]           i_in_53 

    ,output  wire    [OB*2*24  -1:0]           i_out
);

// signal
wire    [OB*2*24     -1:0]           w_out; 

// generate
generate
if(IB > OB) begin : left
    assign w_out = { 
     i_in_53[IB-1],i_in_53[OB-2:0],i_in_52[IB-1],i_in_52[OB-2:0],i_in_51[IB-1],i_in_51[OB-2:0],i_in_50[IB-1],i_in_50[OB-2:0]
    ,i_in_43[IB-1],i_in_43[OB-2:0],i_in_42[IB-1],i_in_42[OB-2:0],i_in_41[IB-1],i_in_41[OB-2:0],i_in_40[IB-1],i_in_40[OB-2:0]
    ,i_in_33[IB-1],i_in_33[OB-2:0],i_in_32[IB-1],i_in_32[OB-2:0],i_in_31[IB-1],i_in_31[OB-2:0],i_in_30[IB-1],i_in_30[OB-2:0]
    ,i_in_23[IB-1],i_in_23[OB-2:0],i_in_22[IB-1],i_in_22[OB-2:0],i_in_21[IB-1],i_in_21[OB-2:0],i_in_20[IB-1],i_in_20[OB-2:0]
    ,i_in_13[IB-1],i_in_13[OB-2:0],i_in_12[IB-1],i_in_12[OB-2:0],i_in_11[IB-1],i_in_11[OB-2:0],i_in_10[IB-1],i_in_10[OB-2:0]
    ,i_in_03[IB-1],i_in_03[OB-2:0],i_in_02[IB-1],i_in_02[OB-2:0],i_in_01[IB-1],i_in_01[OB-2:0],i_in_00[IB-1],i_in_00[OB-2:0]
    };
end
else if(IB < OB) begin : right
    localparam DIFF = OB-IB    ;

    assign w_out = {
     {DIFF{i_in_53[IB-1]}},i_in_53,{DIFF{i_in_52[IB-1]}},i_in_52,{DIFF{i_in_51[IB-1]}},i_in_51,{DIFF{i_in_50[IB-1]}},i_in_50        
    ,{DIFF{i_in_43[IB-1]}},i_in_43,{DIFF{i_in_42[IB-1]}},i_in_42,{DIFF{i_in_41[IB-1]}},i_in_41,{DIFF{i_in_40[IB-1]}},i_in_40
    ,{DIFF{i_in_33[IB-1]}},i_in_33,{DIFF{i_in_32[IB-1]}},i_in_32,{DIFF{i_in_31[IB-1]}},i_in_31,{DIFF{i_in_30[IB-1]}},i_in_30
    ,{DIFF{i_in_23[IB-1]}},i_in_23,{DIFF{i_in_22[IB-1]}},i_in_22,{DIFF{i_in_21[IB-1]}},i_in_21,{DIFF{i_in_20[IB-1]}},i_in_20
    ,{DIFF{i_in_13[IB-1]}},i_in_13,{DIFF{i_in_12[IB-1]}},i_in_12,{DIFF{i_in_11[IB-1]}},i_in_11,{DIFF{i_in_10[IB-1]}},i_in_10
    ,{DIFF{i_in_03[IB-1]}},i_in_03,{DIFF{i_in_02[IB-1]}},i_in_02,{DIFF{i_in_01[IB-1]}},i_in_01,{DIFF{i_in_00[IB-1]}},i_in_00
    };
end
else begin : same
    assign w_out = {
     i_in_53,i_in_52,i_in_51,i_in_50        
    ,i_in_43,i_in_42,i_in_41,i_in_40
    ,i_in_33,i_in_32,i_in_31,i_in_30
    ,i_in_23,i_in_22,i_in_21,i_in_20
    ,i_in_13,i_in_12,i_in_11,i_in_10
    ,i_in_03,i_in_02,i_in_01,i_in_00
    };
end
endgenerate

// output
generate
if (DLY == 0) begin : zero_dly
    assign o_out = w_out ; 
end
else begin : fix_dly
    ylib_reg #(.WIDTH(OB*2*24) ,.DEPTH(DLY)) u_out_reg(
         .i_clk      (i_clk     )
        ,.i_in       (w_out     )
        ,.o_out      (o_out     )
     );
end
endgenerate

endmodule
