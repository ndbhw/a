////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_conv_15to16.v
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Convert 15bit to 16bit for Multi Stream 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.11 |jyzoo.lee      | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2022.02.16 |jyzoo.lee      | CONV_15TO16 Integreated
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_conv_15to16
#(
        parameter   DI_BW          =   2 
       ,parameter   NUM_STREAM     =   2 
)(
        input   wire                            i_clk
    ,   input   wire    [01-1:0]                i_bfn_strb
    ,   input   wire    [12-1:0]                i_bfn
    ,   input   wire    [01-1:0]                i_en
    ,   input   wire    [DI_BW*NUM_STREAM-1:0]  i_in
    ,   output  reg     [01-1:0]                o_bfn_strb
    ,   output  reg     [12-1:0]                o_bfn
    ,   output  reg     [01-1:0]                o_fsync
    ,   output  wire    [01-1:0]                o_csync
    ,   output  reg     [01-1:0]                o_en
    ,   output  wire    [16*NUM_STREAM-1:0]     o_out
);

localparam  DLY_SYNC    =   8   ;

reg r_bfn_strb ;
reg [5:0] r_axc_cnt ;
always@(posedge i_clk) begin
    r_bfn_strb <= i_bfn_strb ;
    if(i_bfn_strb&~r_bfn_strb) begin
        r_axc_cnt <= 6'd0 ;
    end
    else begin
        r_axc_cnt <= r_axc_cnt + 1'd1 ;
    end
end
reg r_en ;
reg [15*NUM_STREAM-1:0] r_in ;
always@(posedge i_clk) begin
    r_en <= i_en ;
    if(i_en) begin
        r_in [(15*2-1)-:15] <= i_in [(16*2-1-1)-:15] ;
        r_in [(15*1-1)-:15] <= i_in [(16*1-1-1)-:15] ;
    end
end
reg [15*NUM_STREAM-1:0] rr_in ;
always@(posedge i_clk) begin
    if(r_en) begin
        rr_in <= r_in ;
    end
end
CONV_15TO16 u00_15to16
(
     .CLK                          (   i_clk                    )
    ,.CONV_IN_SYNC                 (   r_axc_cnt==6'd0          )
    ,.CONV_IN_DATA_I               (   rr_in [(15*2-1)-:15]     )
    ,.CONV_IN_DATA_Q               (   rr_in [(15*1-1)-:15]     )
    ,.CONV_OUT_SYNC                (   o_csync                  )
    ,.CONV_OUT_DATA_I              (   o_out[(16*2-1)-:16]      )
    ,.CONV_OUT_DATA_Q              (   o_out[(16*1-1)-:16]      )
);

wire w_bfn_strb ;
wire w_en ;
ylib_reg #(
     .WIDTH (   2               ) 
    ,.DEPTH (   DLY_SYNC        )) 
u01_sync
(
     .i_clk     (  i_clk                )
    ,.i_in      (  {i_bfn_strb,i_en}    )
    ,.o_out     (  {w_bfn_strb,w_en}    )
);
always@(posedge i_clk) begin
    o_en <= w_en ;
    o_fsync <= w_bfn_strb & ~o_bfn_strb ;
    o_bfn_strb <= w_bfn_strb ;
    if(w_bfn_strb & ~o_bfn_strb) begin
        o_bfn <= i_bfn ;
    end
end
endmodule
