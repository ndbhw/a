////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_mon_smp
//  Author       : jyzoo.lee@samsung.com 
//  Description  : This Module is Designed to Monitor Samples.
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.23 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_mon_smp
#(
    parameter  NUM_STREAM   =   2           
   ,parameter  DIO_BW       =   16           
)(
     input   wire                               i_clk
    ,input   wire    [32-1:0]                   i_target
    ,input   wire    [08-1:0]                   i_frame
    ,input   wire    [08-1:0]                   i_slot
    ,input   wire    [08-1:0]                   i_symbol
    ,input   wire    [01-1:0]                   i_rsync
    ,input   wire    [01-1:0]                   i_en
    ,input   wire    [NUM_STREAM*DIO_BW-1:0]    i_in
    ,output  reg     [NUM_STREAM*DIO_BW-1:0]    o_max
    ,output  reg     [NUM_STREAM*DIO_BW-1:0]    o_min
);

integer i ;

reg [0:0] r_target_valid ;
always@(*) begin
    r_target_valid = (i_frame==i_target[((08)*(2+1)-1)-:(08)]&&i_slot==i_target[((08)*(1+1)-1)-:(08)]&&i_symbol==i_target[((08)*(0+1)-1)-:(08)]) ;
end
reg [0:0] rr_target_valid ;
always@(posedge i_clk) begin
    rr_target_valid <= r_target_valid ;
end
reg [NUM_STREAM*DIO_BW-1:0] r_max   ;
reg [NUM_STREAM*DIO_BW-1:0] r_min   ;
always@(posedge i_clk) begin
    if(i_rsync) begin
        for(i=0;i<NUM_STREAM;i=i+1) begin
            r_max[((DIO_BW)*(i+1)-1)-:(DIO_BW)] <= {{DIO_BW}{1'd0}} ;
            r_min[((DIO_BW)*(i+1)-1)-:(DIO_BW)] <= {{DIO_BW}{1'd0}} ;
        end
    end
    else if(r_target_valid&i_en) begin
        for(i=0;i<NUM_STREAM;i=i+1) begin
            r_max[((DIO_BW)*(i+1)-1)-:(DIO_BW)] <= $signed(i_in[((DIO_BW)*(i+1)-1)-:(DIO_BW)])>=$signed(r_max[((DIO_BW)*(i+1)-1)-:(DIO_BW)]) ? i_in[((DIO_BW)*(i+1)-1)-:(DIO_BW)] : r_max[((DIO_BW)*(i+1)-1)-:(DIO_BW)] ;
            r_min[((DIO_BW)*(i+1)-1)-:(DIO_BW)] <= $signed(i_in[((DIO_BW)*(i+1)-1)-:(DIO_BW)])< $signed(r_min[((DIO_BW)*(i+1)-1)-:(DIO_BW)]) ? i_in[((DIO_BW)*(i+1)-1)-:(DIO_BW)] : r_min[((DIO_BW)*(i+1)-1)-:(DIO_BW)] ;
        end
    end
end
always@(posedge i_clk) begin
    if(~r_target_valid&rr_target_valid) begin
        o_max <= r_max ;
        o_min <= r_min ;
    end
end

endmodule
