////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : lib_sdpram
//  Author       : Song, Moon-Gun
//  Description  : Simple Dual Port Memory
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module lib_sdpram 
#(
      parameter AW = 12      // Address Width
    , parameter ND = (1<<AW) // Number of Data
    , parameter DW = 72      // Data Width
    , parameter NP = 2       // Number of pipeline Registers NP >= 1
    , parameter RAM_TYPE = "block" // Memory Type: "block" or "distributed" or "ultra" 
) (
      input  wire           i_clk        // Clock 
    , input  wire           i_ena        // Input port Enable
    , input  wire           i_enb        // Output Register Enable
    , input  wire           i_wea        // Write Enable
    , input  wire [AW-1:0]  i_addra      // Write Address
    , input  wire [AW-1:0]  i_addrb      // Read  Address
    , input  wire [DW-1:0]  i_dina       // Data input wire   
    , output wire [DW-1:0]  o_doutb      // Data Output
);

(* ram_style = RAM_TYPE *)
reg [DW-1:0] r_ram         [ND-1:0];    // Memory Declaration
reg          r_enb                      ;
reg [DW-1:0] r_ram_read                 ;
reg          r_read_en_pipe[NP-1:0]     ;    // Pipelines for memory enable  
reg [DW-1:0] r_read_pipe   [NP-1:0]     ;    // Pipelines for memory


always @(posedge i_clk) begin
    if(i_ena) begin
        if(i_wea) r_ram[i_addra] <= i_dina;
    end
end


always @(posedge i_clk) begin
    if(i_enb) begin
        r_ram_read <= r_ram[i_addrb];
    end
end

integer i;

generate
if (NP == 0) begin

assign o_doutb = r_ram_read;

end
else begin

always @(posedge i_clk) begin
    r_read_en_pipe[0] <= i_enb;
    for(i = 1; i < NP; i = i + 1) r_read_en_pipe[i] <= r_read_en_pipe[i-1];
end

always @(posedge i_clk) begin
    if(r_read_en_pipe[0]) r_read_pipe[0] <= r_ram_read;
end    

always @(posedge i_clk) begin
    for(i = 1; i < NP; i = i + 1) begin
        if(r_read_en_pipe[i]) r_read_pipe[i] <= r_read_pipe[i-1];
    end
end  

assign o_doutb = r_read_pipe[NP-1];

end
endgenerate

endmodule
	
