////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Complex Multiplier (pr+i.pi) = (ar+i.ai)*(br+i.bi)
// file: ylib_cmult.v
// jyzoo.lee@samsung.com

module ylib_cmult # (parameter AWIDTH = 16, BWIDTH = 18)
   (
    input clk,
    input en,
    input signed [AWIDTH-1:0]      ar, ai,
    input signed [BWIDTH-1:0]      br, bi,
    output pen,
    output signed [AWIDTH+BWIDTH:0] pr, pi
   );

reg signed [AWIDTH-1:0] ai_d, ai_dd, ai_ddd, ai_dddd   ; 
reg signed [AWIDTH-1:0] ar_d, ar_dd, ar_ddd, ar_dddd   ; 
reg signed [BWIDTH-1:0] bi_d, bi_dd, bi_ddd, br_d, br_dd, br_ddd ; 
reg signed [AWIDTH:0]  addcommon     ; 
reg signed [BWIDTH:0]  addr, addi     ; 
reg signed [AWIDTH+BWIDTH:0] mult0, multr, multi, pr_int, pi_int  ; 
reg signed [AWIDTH+BWIDTH:0] common, commonr1, commonr2   ; 

reg en_d,en_dd,en_ddd,en_dddd,en_ddddd,en_dddddd;
always @(posedge clk) begin
en_d       <=  en         ;
en_dd      <=  en_d       ;
en_ddd     <=  en_dd      ;
en_dddd    <=  en_ddd     ;
en_ddddd   <=  en_dddd    ;
en_dddddd  <=  en_ddddd   ;
end

always @(posedge clk) begin
    if(en) begin
        ar_d    <=  ar   ;
        ai_d    <=  ai   ;
    end
end

always @(posedge clk) begin
    if(en_d) begin
        ar_dd   <=  ar_d   ;
        ai_dd   <=  ai_d   ;
    end
end

always @(posedge clk) begin
    if(en_dd) begin
        ar_ddd   <=  ar_dd   ;
        ai_ddd   <=  ai_dd   ;
    end
end

always @(posedge clk) begin
    if(en_ddd) begin
        ar_dddd   <=  ar_ddd   ;
        ai_dddd   <=  ai_ddd   ;
    end
end

always @(posedge clk) begin
    if(en) begin
        br_d    <=  br   ;
        bi_d    <=  bi   ;
    end
end

always @(posedge clk) begin
    if(en_d) begin
        br_dd   <=  br_d   ;
        bi_dd   <=  bi_d   ;
    end
end

always @(posedge clk) begin
    if(en_dd) begin
        br_ddd   <=  br_dd   ;
        bi_ddd   <=  bi_dd   ;
    end
end
 
// Common factor (ar ai) x bi, shared for the calculations of the real and imaginary final products
always @(posedge clk) begin
    if(en_d) begin
        addcommon <= {ar_d[AWIDTH-1],ar_d} - {ai_d[AWIDTH-1],ai_d};
    end
end

always @(posedge clk) begin
    if(en_dd) begin
        mult0     <= {{{BWIDTH}{addcommon[AWIDTH]}},addcommon} * {{{AWIDTH+1}{bi_dd[BWIDTH-1]}},bi_dd};
    end
end

always @(posedge clk) begin
    if(en_ddd) begin
        common    <= mult0;
    end
end

// Real product
always @(posedge clk) begin
    if(en_ddd) begin
        addr    <=  {br_ddd[BWIDTH-1],br_ddd} - {bi_ddd[BWIDTH-1],bi_ddd};
    end
end

always @(posedge clk) begin
    if(en_dddd) begin
        multr    <= {{{AWIDTH}{addr[BWIDTH]}},addr} * {{{BWIDTH+1}{ar_dddd[AWIDTH-1]}},ar_dddd};
    end
end

always @(posedge clk) begin
    if(en_dddd) begin
        commonr1 <= common;
    end
end

always @(posedge clk) begin
    if(en_ddddd) begin
        pr_int   <= multr + commonr1;
    end
end

// Imaginary product
always @(posedge clk) begin
    if(en_ddd) begin
        addi     <= {br_ddd[BWIDTH-1],br_ddd} + {bi_ddd[BWIDTH-1],bi_ddd};
    end
end

always @(posedge clk) begin
    if(en_dddd) begin
        multi    <= {{{AWIDTH}{addi[BWIDTH]}},addi} * {{{BWIDTH+1}{ai_dddd[AWIDTH-1]}},ai_dddd};
    end
end

always @(posedge clk) begin
    if(en_dddd) begin
        commonr2 <= common;
    end
end

always @(posedge clk) begin
    if(en_ddddd) begin
        pi_int   <= multi + commonr2;
    end
end

assign pr   = pr_int;
assign pi   = pi_int;
assign pen  = en_dddddd;
   
endmodule // cmult
