////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_cdc_pulse
//  Author       : jyzoo.lee@samsung.com 
//  Description  : cdc hadling for independent register with sync reset
//                 set_false_path -to [get_cells {o_dest[*]}]
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.09 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.09.24 |jyzoo.lee      | Fix for Low Latency
//  ------------+---------------+-----------------------------------------------
//   2020.11.09 |jyzoo.lee      | Xilinx XPM CDC Support
//  ------------+---------------+-----------------------------------------------
//   2020.11.16 |jyzoo.lee      | Destination register initialization @ Intel
//  ------------+---------------+-----------------------------------------------
//   2021.01.19 |jyzoo.lee      | Vendor Independent
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cdc_reg 
# (
        parameter CDC_LEVEL     =   4
    ,   parameter WIDTH         =   32
    ,   parameter INIT          =   1
    ,   parameter VENDOR        =   "Intel"
)(
        input   wire                    i_src_clk
    ,   input   wire                    i_src_rst
    ,   input	wire                    i_src_en
    ,   input	wire    [WIDTH-1:0]     i_src
    
    ,   input   wire                    i_dest_clk
    ,   input   wire                    i_dest_rst
    ,   input   wire                    i_dest_init
    ,   output	reg                     o_dest_en
    ,   output	reg     [WIDTH-1:0]     o_dest
);

wire w_dest_en ;
ylib_cdc_pulse #(
     .CDC_LEVEL (   CDC_LEVEL   ))
u00_cdc_pulse
(
     .i_src_clk     ( i_src_clk         )
    ,.i_src_rst     ( i_src_rst         )
    ,.i_dest_clk    ( i_dest_clk        )
    ,.i_dest_rst    ( i_dest_rst        )
    ,.i_in          ( i_src_en          )
    ,.o_out         ( w_dest_en         )
);

reg [WIDTH-1:0] r_src, rr_src  ;
always@(posedge i_dest_clk) begin
    r_src   <=  i_src    ;
    rr_src  <=  r_src    ;
end
generate if(INIT==1) begin
always@(posedge i_dest_clk) begin
    o_dest_en   <= w_dest_en    ;
    if(i_dest_init) begin
        o_dest  <= {{WIDTH}{1'd0}}  ;
    end
    else if(w_dest_en) begin
        o_dest  <= rr_src   ;
    end
end
end
else begin
always@(*) begin
    o_dest_en   = w_dest_en ;
    o_dest      = rr_src    ;
end
end
endgenerate
   
endmodule
