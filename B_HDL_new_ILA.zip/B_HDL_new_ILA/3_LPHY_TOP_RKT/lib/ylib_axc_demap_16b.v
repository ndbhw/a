////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_smp_demap_16b
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Demap CPRI 16b smp to NR TD Signal 
//                 Feature : 4R,CBW 20/15/10/5M 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.08.12 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.08.24 |jyzoo.lee      | Designed in Detail : Real Format, Align
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_axc_demap_16b
#(
        parameter   NUM_ANT     =    4
   ,    parameter   DIO_BW      =    16
)(
        input   wire                                i_clk
    ,   input   wire    [4-1:0]                     i_bw_idx
    ,   input   wire    [01-1:0]                    i_ssync
    ,   input   wire    [01-1:0]                    i_en
    ,   input   wire    [DIO_BW-1:0]                i_iq
    ,   output  reg     [01-1:0]                    o_ssync
    ,   output  reg     [01*NUM_ANT-1:0]            o_en
    ,   output  reg     [2*DIO_BW*NUM_ANT-1:0]      o_iq
);

genvar  gidx    ;
integer i       ;

localparam      NUM_AXC             =           64                  ;
localparam      BW_AXC              =           $clog2(NUM_AXC)     ;
localparam      BW_NUM_ANT          =           $clog2(NUM_ANT)     ;
localparam      IDX_BW_020          =           4'd3                ;
localparam      IDX_BW_015          =           4'd2                ;
localparam      IDX_BW_010          =           4'd1                ;
localparam      IDX_BW_005          =           4'd0                ;
localparam      BW_SR_BW_020        =           $clog2(08)          ;
localparam      BW_SR_BW_015        =           $clog2(08)          ;
localparam      BW_SR_BW_010        =           $clog2(16)          ;
localparam      BW_SR_BW_005        =           $clog2(32)          ;
localparam      POS_I               =           1'b0                ;
localparam      POS_Q               =           1'b1                ;
localparam      DLY_SR3             =           7                   ;
localparam      DLY_SR4             =           3                   ;
localparam      DLY_SR5             =           1                   ;
localparam      DLY_SYNC            =           67                  ;

reg [BW_AXC-1:0] r_smp_cnt ;
always@(posedge i_clk) begin
    if(i_ssync) begin
        r_smp_cnt <= {{BW_AXC}{1'd0}} ;
    end
    else begin
        r_smp_cnt <= r_smp_cnt+1'd1 ;
    end
end
reg [0:0] r_en          ;
reg [5:0] rr_smp_cnt    ;
reg [DIO_BW-1:0]r_iq    ;   
always@(posedge i_clk) begin
    r_en <= i_en ;
    rr_smp_cnt <= r_smp_cnt ;
    if(i_en) begin
        r_iq <= i_iq ;
    end
end
reg [1-1:0]         r_demap_en  [NUM_ANT-1:0]  ;   
reg [2*DIO_BW-1:0]  r_demap_iq  [NUM_ANT-1:0]  ;   
reg [01*NUM_ANT-1:0]        r_a_align_en  ;
reg [2*DIO_BW*NUM_ANT-1:0]  r_a_align_iq  ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_demap_ant_split
always@(posedge i_clk) begin
    r_demap_en[gidx] <= r_en ;
    if(r_en) begin
        case(i_bw_idx)
            IDX_BW_020  : begin
                r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_I ? r_iq : r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW] ;
                r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_Q ? r_iq : r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW] ;
            end
            IDX_BW_015  : begin
                r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_I ? r_iq : r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW] ;
                r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_Q ? r_iq : r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW] ;
            end
            IDX_BW_010  : begin
                r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_I ? r_iq : r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW] ;
                r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_Q ? r_iq : r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW] ;
            end                                                               
            IDX_BW_005  : begin                                               
                r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_I ? r_iq : r_demap_iq[gidx][(DIO_BW*2-1)-:DIO_BW] ;
                r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW]  <= r_smp_cnt[BW_AXC-1:1]==gidx && r_smp_cnt[0]==POS_Q ? r_iq : r_demap_iq[gidx][(DIO_BW*1-1)-:DIO_BW] ;
            end
            default     : r_demap_iq[gidx]  <= {{DIO_BW*2}{1'd0}} ; 
        endcase
    end
end
always@(posedge i_clk) begin
    if(r_demap_en[gidx]) begin
        case(i_bw_idx)
            IDX_BW_020  : begin 
                r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= rr_smp_cnt[BW_SR_BW_020-1:0]=={{BW_SR_BW_020}{1'd1}} ? r_demap_iq[gidx] : r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]; 
                r_a_align_en[gidx]  <= rr_smp_cnt[BW_SR_BW_020-1:0]=={{BW_SR_BW_020}{1'd1}} ? r_demap_en[gidx] : r_a_align_en[gidx]; 
            end 
            IDX_BW_015  : begin 
                r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= rr_smp_cnt[BW_SR_BW_015-1:0]=={{BW_SR_BW_015}{1'd1}} ? r_demap_iq[gidx] : r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]; 
                r_a_align_en[gidx]  <= rr_smp_cnt[BW_SR_BW_015-1:0]=={{BW_SR_BW_015}{1'd1}} ? r_demap_en[gidx] : r_a_align_en[gidx]; 
            end
            IDX_BW_010  : begin 
                r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= rr_smp_cnt[BW_SR_BW_010-1:0]=={{BW_SR_BW_010}{1'd1}} ? r_demap_iq[gidx] : r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]; 
                r_a_align_en[gidx]  <= rr_smp_cnt[BW_SR_BW_010-1:0]=={{BW_SR_BW_010}{1'd1}} ? r_demap_en[gidx] : r_a_align_en[gidx]; 
            end
            IDX_BW_005  : begin 
                r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= rr_smp_cnt[BW_SR_BW_005-1:0]=={{BW_SR_BW_005}{1'd1}} ? r_demap_iq[gidx] : r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]; 
                r_a_align_en[gidx]  <= rr_smp_cnt[BW_SR_BW_005-1:0]=={{BW_SR_BW_005}{1'd1}} ? r_demap_en[gidx] : r_a_align_en[gidx]; 
            end
            default     : begin 
                r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= {{2*DIO_BW*NUM_ANT}{1'd0}} ; 
                r_a_align_en[gidx]  <= 1'd0 ; 
            end
        endcase
    end
    else begin
        r_a_align_en[gidx]  <= 1'd0 ; 
    end
end
end
endgenerate

reg [01*NUM_ANT-1:0]        r_sr3_align_en [DLY_SR3-1:0]  ;
reg [2*DIO_BW*NUM_ANT-1:0]  r_sr3_align_iq [DLY_SR3-1:0]  ;
reg [01*NUM_ANT-1:0]        r_sr4_align_en [DLY_SR4-1:0]  ;
reg [2*DIO_BW*NUM_ANT-1:0]  r_sr4_align_iq [DLY_SR4-1:0]  ;
reg [01*NUM_ANT-1:0]        r_sr5_align_en [DLY_SR4-1:0]  ;
reg [2*DIO_BW*NUM_ANT-1:0]  r_sr5_align_iq [DLY_SR4-1:0]  ;
reg [01*NUM_ANT-1:0]        r_s_align_en   ;
reg [2*DIO_BW*NUM_ANT-1:0]  r_s_align_iq   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_smp_align
always@(posedge i_clk) begin
    if(i_bw_idx==IDX_BW_020 || i_bw_idx==IDX_BW_015) begin
        if(r_a_align_en[gidx]&i_ssync) begin
            r_sr3_align_en[0][gidx]                                     <= r_a_align_en[gidx]                                       ;
            r_sr3_align_iq[0][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]      <= r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]        ;
        end
        for(i=1;i<DLY_SR3;i=i+1) begin
            if(r_sr3_align_en[i-1][gidx]&i_ssync) begin
                r_sr3_align_en[i][gidx]                                 <= r_sr3_align_en[i-1][gidx]                                ;
                r_sr3_align_iq[i][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= r_sr3_align_iq[i-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(i_bw_idx==IDX_BW_010) begin
        if(r_a_align_en[gidx]&i_ssync) begin
            r_sr4_align_en[0][gidx]                                     <= r_a_align_en[gidx]                                       ;
            r_sr4_align_iq[0][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]      <= r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]        ;
        end
        for(i=1;i<DLY_SR4;i=i+1) begin
            if(r_sr4_align_en[i-1][gidx]&i_ssync) begin
                r_sr4_align_en[i][gidx]                                 <= r_sr4_align_en[i-1][gidx]                                ;
                r_sr4_align_iq[i][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= r_sr4_align_iq[i-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(i_bw_idx==IDX_BW_005) begin
        if(r_a_align_en[gidx]&i_ssync) begin
            r_sr5_align_en[0][gidx]                                     <= r_a_align_en[gidx]                                       ;
            r_sr5_align_iq[0][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]      <= r_a_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]        ;
        end
        for(i=1;i<DLY_SR5;i=i+1) begin
            if(r_sr5_align_en[i-1][gidx]&i_ssync) begin
                r_sr5_align_en[i][gidx]                                 <= r_sr5_align_en[i-1][gidx]                                ;
                r_sr5_align_iq[i][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= r_sr5_align_iq[i-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
            end
        end
    end
end
always@(posedge i_clk) begin
    case(i_bw_idx)
        IDX_BW_020  : begin 
            r_s_align_en[gidx]                                  <=  r_sr3_align_en[DLY_SR3-1][gidx]                                 ;                               
            r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]   <=  r_sr3_align_iq[DLY_SR3-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  ;
        end 
        IDX_BW_015  : begin 
            r_s_align_en[gidx]                                  <=  r_sr3_align_en[DLY_SR3-1][gidx]                                 ;                               
            r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]   <=  r_sr3_align_iq[DLY_SR3-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  ;
        end
        IDX_BW_010  : begin 
            r_s_align_en[gidx]                                  <=  r_sr4_align_en[DLY_SR4-1][gidx]                                 ;                               
            r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]   <=  r_sr4_align_iq[DLY_SR4-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  ;
        end
        IDX_BW_005  : begin 
            r_s_align_en[gidx]                                  <=  r_sr5_align_en[DLY_SR5-1][gidx]                                 ;                               
            r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]   <=  r_sr5_align_iq[DLY_SR5-1][((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  ;
        end
        default     : begin 
            r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <= {{2*DIO_BW*NUM_ANT}{1'd0}} ; 
            r_s_align_en[gidx]  <= 1'd0 ; 
        end
    endcase
end
always@(posedge i_clk) begin
    if(r_s_align_en[gidx]) begin
        o_en[gidx]                                  <=  r_s_align_en[gidx]                                 ;                               
        o_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]   <=  r_s_align_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  ;
    end
    else begin
        o_en[gidx]                                  <=  1'd0 ;                               
    end
end
end
endgenerate
reg r_ssync;
reg rr_ssync;
always@(posedge i_clk) begin
    r_ssync  <=  i_ssync    ;
    rr_ssync <=  r_ssync    ;
    if(|r_s_align_en) begin
        o_ssync  <=  rr_ssync    ;
    end
    else begin
        o_ssync  <=  1'd0   ;
    end
end
endmodule
