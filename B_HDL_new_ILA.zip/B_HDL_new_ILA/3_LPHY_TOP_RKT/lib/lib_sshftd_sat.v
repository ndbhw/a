////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : lib_sshftd_sat
//  Author       : Song, Moon-Gun
//  Description  : Fixed Point Complex Number Conversion
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////


module lib_sshftd_sat
#(
      parameter   IB            =  33                    // Input Bit Width
    , parameter   SF            =  15                    // Bit Shift for Round
    , parameter   OB            =  16                    // Saturation Bit Width (Output Bit Width
    , parameter   ROUND_TYPE    =  "SYMMETRIC_ROUND"     // SYMMETRIC_ROUND or ROUND or TRUNC
    , parameter   SAT_TYPE      =  "SYMMETRIC"           // SYMMETRIC or NONSYMMETRIC
)
(
      input  wire                  i_clk          // i_clk 
    , input  wire                  i_rst          // Sync. Reset Active High
    
    , input  wire                  i_din_vld      // Input Siganl Enable
    , input  wire signed [IB-1:0]  i_din          // Input Signal

    , output wire                  o_dout_vld     // Output Signal Enable
    , output wire signed [OB-1:0]  o_dout         // Output Signal
);


localparam  RNDBW = (ROUND_TYPE == "TRUNC") ? 0 : 1;

wire signed [IB-SF+RNDBW-1:0]  w_shft_din           ;
wire                           w_shft_din_vld_1d    ;
wire signed [IB-SF+RNDBW-1:0]  w_shft_din_1d        ;
wire                           w_cond_non_sat       ;
wire signed [         OB-1:0]  w_dout               ;
wire        [          1-1:0]  w_dout_sat_last      ;

generate
if(ROUND_TYPE == "SYMMETRIC_ROUND") begin
    if     (SF == 0) assign w_shft_din = {i_din[IB-1],i_din};
    else if(SF == 1) assign w_shft_din = {i_din[IB-1],i_din[IB-1:1]} + $signed({1'b0,(i_din[SF-1])&(~i_din[IB-1])});
    else             assign w_shft_din = $signed(i_din[IB-1:SF]) + $signed({1'b0,((i_din[SF-1])&(~i_din[IB-1]|(|i_din[SF-2:0])))});
end
else if(ROUND_TYPE == "ROUND") begin
    if(SF == 0)      assign w_shft_din = {i_din[IB-1],i_din};
    else             assign w_shft_din = $signed(i_din[IB-1:SF]) + $signed({1'b0,i_din[SF-1]});
end
else begin
    if(SF == 0)      assign w_shft_din = i_din;
    else             assign w_shft_din = i_din[IB-1:SF];
end
endgenerate

ylib_reg #(.WIDTH(1), .DEPTH(1)) u00_lib_reg
(
     .i_clk   (    i_clk              )                        
    ,.i_in    (    i_din_vld          )
    ,.o_out   (    w_shft_din_vld_1d  )
);

ylib_reg #(.WIDTH(IB-SF+RNDBW), .DEPTH(1)) u01_lib_reg
(
     .i_clk   (    i_clk              )                        
    ,.i_in    (    w_shft_din         )
    ,.o_out   (    w_shft_din_1d      )
);

generate
if(SAT_TYPE == "SYMMETRIC") begin
    assign w_dout_sat_last = 1'b1;
end
else begin
    assign w_dout_sat_last = ~w_shft_din_1d[IB-SF+RNDBW-1];
end

if(IB-SF+RNDBW >= OB) begin
    assign w_cond_non_sat = ({(IB-SF+RNDBW-OB+1){w_shft_din_1d[IB-SF+RNDBW-1]}} == w_shft_din_1d[IB-SF+RNDBW-1:OB-1]) && ({(OB-1){~w_shft_din_1d[IB-SF+RNDBW-1]}} != w_shft_din_1d[OB-1-1:0]);
    assign w_dout[OB-1]     = w_shft_din_1d[IB-SF+RNDBW-1];
    assign w_dout[OB-1-1:0] = (w_cond_non_sat) ? w_shft_din_1d[OB-1-1:0] : {{(OB-2){~w_shft_din_1d[IB-SF+RNDBW-1]}}, w_dout_sat_last};
end
else begin
    assign w_cond_non_sat = 1'b1;
    assign w_dout[OB-1:0] = {{(OB-(IB-SF+RNDBW)){w_shft_din_1d[IB-SF+RNDBW-1]}}, w_shft_din_1d};
end
endgenerate


ylib_reg #(.WIDTH(1), .DEPTH(1)) u02_lib_reg
(
     .i_clk   (    i_clk              )                        
    ,.i_in    (    w_shft_din_vld_1d  )
    ,.o_out   (    o_dout_vld         )
);

ylib_reg #(.WIDTH(OB), .DEPTH(1)) u03_lib_reg
(
     .i_clk   (    i_clk              )                        
    ,.i_in    (    (w_shft_din_vld_1d) ? w_dout : {OB{1'b0}}  )
    ,.o_out   (    o_dout             )
);


endmodule

