////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2019 Samsung Electronics Inc. All rights reserved
//
//  Project      : Verizon FSU20
//  Module       : ylib_bus_split_ant
//  Author       : taeyeong
//  Description  : bus split 1 to 4
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.03 | taeyeong      | Inital Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_bus_split_ant #(
     parameter  IB          =   16
    ,parameter  OB          =   16
    ,parameter  DLY         =    0          
)(
     input   wire                              i_clk
    ,input   wire    [IB*2*4   -1:0]           i_in

    ,output  wire    [OB*2     -1:0]           o_out_0 
    ,output  wire    [OB*2     -1:0]           o_out_1 
    ,output  wire    [OB*2     -1:0]           o_out_2 
    ,output  wire    [OB*2     -1:0]           o_out_3 
);

// signal
wire    [OB*2     -1:0]           w_out_00; 
wire    [OB*2     -1:0]           w_out_01; 
wire    [OB*2     -1:0]           w_out_02; 
wire    [OB*2     -1:0]           w_out_03; 

// generate
generate
if(IB > OB) begin : left
    assign w_out_00 = {i_in[IB* 2 -1],i_in[IB* 1+OB -2: IB* 1],i_in[IB* 1 -1],i_in[IB* 0+OB -2: IB* 0]};
    assign w_out_01 = {i_in[IB* 4 -1],i_in[IB* 3+OB -2: IB* 3],i_in[IB* 3 -1],i_in[IB* 2+OB -2: IB* 2]};
    assign w_out_02 = {i_in[IB* 6 -1],i_in[IB* 5+OB -2: IB* 5],i_in[IB* 5 -1],i_in[IB* 4+OB -2: IB* 4]};
    assign w_out_03 = {i_in[IB* 8 -1],i_in[IB* 7+OB -2: IB* 7],i_in[IB* 7 -1],i_in[IB* 6+OB -2: IB* 6]};
end
else if(IB < OB) begin : right
    localparam DIFF = OB-IB    ;

    assign w_out_00 = {  {DIFF{i_in[IB* 2 -1]}} ,i_in[IB* 2 -1:IB* 1], {DIFF{i_in[IB* 1 -1]}} ,i_in[IB* 1 -1:IB* 0]  };
    assign w_out_01 = {  {DIFF{i_in[IB* 4 -1]}} ,i_in[IB* 4 -1:IB* 3], {DIFF{i_in[IB* 3 -1]}} ,i_in[IB* 3 -1:IB* 2]  };
    assign w_out_02 = {  {DIFF{i_in[IB* 6 -1]}} ,i_in[IB* 6 -1:IB* 5], {DIFF{i_in[IB* 5 -1]}} ,i_in[IB* 5 -1:IB* 4]  };
    assign w_out_03 = {  {DIFF{i_in[IB* 8 -1]}} ,i_in[IB* 8 -1:IB* 7], {DIFF{i_in[IB* 7 -1]}} ,i_in[IB* 7 -1:IB* 6]  };
end
else begin : same
    assign w_out_00 = {  i_in[IB* 2 -1:IB* 1], i_in[IB* 1 -1:IB* 0]  };
    assign w_out_01 = {  i_in[IB* 4 -1:IB* 3], i_in[IB* 3 -1:IB* 2]  };
    assign w_out_02 = {  i_in[IB* 6 -1:IB* 5], i_in[IB* 5 -1:IB* 4]  };
    assign w_out_03 = {  i_in[IB* 8 -1:IB* 7], i_in[IB* 7 -1:IB* 6]  };
end
endgenerate

// output
generate
if (DLY == 0) begin : zero_dly
    assign o_out_0 = w_out_00 ; 
    assign o_out_1 = w_out_01 ; 
    assign o_out_2 = w_out_02 ; 
    assign o_out_3 = w_out_03 ; 
end
else begin : fix_dly
    ylib_reg #(.WIDTH(OB*2*24) ,.DEPTH(DLY)) u_out_reg(
         .i_clk      (i_clk     )
        ,.i_in       ( {w_out_00 ,w_out_01 ,w_out_02 ,w_out_03})
        ,.o_out      ( {o_out_0 ,o_out_1 ,o_out_2 ,o_out_3})
     );
end
endgenerate

endmodule
