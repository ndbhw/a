////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU
//  Module       : ylib_reg
//  Author       : jyzoo.lee@samsung.com 
//  Description  : pipelined registers
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2019.10.24 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_reg #(parameter WIDTH = 16, parameter DEPTH = 1)
(
    input   wire                    i_clk,
    input   wire    [WIDTH-1:0]     i_in,
    output  reg     [WIDTH-1:0]     o_out
);
integer i ;
reg [WIDTH-1:0] r_in [DEPTH:0] ; 
always@(posedge i_clk) for(i=1;i<=DEPTH;i=i+1) r_in[i] <= r_in[i-1];
always@(*) begin 
    r_in[0] = i_in ;        
    o_out = r_in[DEPTH] ;        
end
endmodule
