////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_cc_bw_align.v
//  Author       : jyzoo.lee@samsung.com 
//  Description  : CC BW Alignment
//                 Feature : CBW 20/15/10/5M 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.12 |jyzoo.lee      | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cc_bw_align
#(
        parameter   MAX_BW_IDX  =    1
   ,    parameter   NUM_ANT     =    4 
   ,    parameter   DIO_BW      =    16
)(
        input   wire                                 i_clk
    ,   input   wire    [01-1:0]                     i_bfn_strb
    ,   input   wire    [12-1:0]                     i_bfn
    ,   input   wire    [01-1:0]                     i_fsync
    ,   input   wire    [01*NUM_ANT-1:0]             i_en
    ,   input   wire    [2*DIO_BW*NUM_ANT-1:0]       i_iq
    ,   output  wire    [01-1:0]                     o_bfn_strb
    ,   output  reg     [12-1:0]                     o_bfn
    ,   output  reg     [01-1:0]                     o_fsync
    ,   output  wire    [01*NUM_ANT-1:0]             o_en
    ,   output  reg     [2*DIO_BW*NUM_ANT-1:0]       o_iq
);

genvar  gidx    ;

localparam      IDX_BW_020          =           3                   ;
localparam      IDX_BW_015          =           2                   ;
localparam      IDX_BW_010          =           1                   ;
localparam      IDX_BW_005          =           0                   ;
localparam      BW_SR_BW_020        =           $clog2(08)          ;
localparam      BW_SR_BW_015        =           $clog2(08)          ;
localparam      BW_SR_BW_010        =           $clog2(16)          ;
localparam      BW_SR_BW_005        =           $clog2(32)          ;
localparam      CLK_STROBE          =           64                  ;
localparam      DLY_SYNC            =           8                   ;

reg [5:0] r_axc_cnt ;
always@(posedge i_clk) begin
    if(i_fsync) begin
        r_axc_cnt <= 6'd0 ;
    end
    else begin
        r_axc_cnt <= r_axc_cnt+1'd1 ;
    end
end
reg r_ssync ;
always@(*) begin
    case(MAX_BW_IDX)
        IDX_BW_020  : r_ssync = &r_axc_cnt[BW_SR_BW_020-1:0] ;
        IDX_BW_015  : r_ssync = &r_axc_cnt[BW_SR_BW_015-1:0] ;
        IDX_BW_010  : r_ssync = &r_axc_cnt[BW_SR_BW_010-1:0] ;
        IDX_BW_005  : r_ssync = &r_axc_cnt[BW_SR_BW_005-1:0] ;
        default     : r_ssync = {{2*DIO_BW}{1'd0}} ; 
    endcase
end
reg [NUM_ANT-1:0]  r_en ;
reg [2*DIO_BW-1:0] r_iq [NUM_ANT-1:0] ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_ant_split
always@(posedge i_clk) begin
    r_en[gidx]  <=  i_en[gidx] ;
    if(i_en[gidx]) begin
        r_iq[gidx]  <=  i_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
    end
end
always@(posedge i_clk) begin
    if(r_en[gidx]&r_ssync) begin
        o_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)]  <=  r_iq[gidx] ;
    end
end
ylib_reg #(
     .WIDTH (   1               ) 
    ,.DEPTH (   DLY_SYNC        )) 
u00_sync
(
     .i_clk     (   i_clk            )
    ,.i_in      (   r_en[gidx]       )
    ,.o_out     (   o_en[gidx]       )
);
end
endgenerate
reg r_fsync_det ; 
always@(posedge i_clk) begin
    if(i_bfn_strb) begin
        if(i_fsync) begin
            r_fsync_det <= 1'b0 ; 
        end
        else if(r_ssync) begin
            r_fsync_det <= 1'b1 ; 
        end
    end
end
always@(posedge i_clk) begin
    if(i_bfn_strb) begin
        o_fsync <= r_fsync_det==1'b0 && r_ssync ;
    end
end
always@(posedge i_clk) begin
    if(i_bfn_strb && r_fsync_det==1'b0 && r_ssync) begin
        o_bfn <= i_bfn ;
    end
end
ylib_pwiden #(
    .CYCLE  (   CLK_STROBE      )) 
u01_bfn_strb
(
     .i_clk     (   i_clk           )
    ,.i_in      (   i_bfn_strb && r_fsync_det==1'b0 && r_ssync    )
    ,.o_out     (   o_bfn_strb      )
);
endmodule
