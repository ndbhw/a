////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : lib_cshftvd_sat
//  Author       : Song, Moon-Gun
//  Description  : Signed Complex Variable Shift Down and Saturation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

//dly4
module ylib_cshftvd_sat
#(
      parameter   IB            =  33                    // Input Bit Width
    , parameter   SB            =   4                    // Bit Shift Variable Bit Width
    , parameter   OB            =  16                    // Saturation Bit Width Output Bit Width
    , parameter   ROUND_TYPE    =  "SYMMETRIC_ROUND"     // SYMMETRIC_ROUND or ROUND or TRUNC
    , parameter   SAT_TYPE      =  "SYMMETRIC"           // SYMMETRIC or NONSYMMETRIC
)
(
      input  wire                  i_clk          // i_clk 
    
    , input  wire        [SB-1:0]  i_shft         // Bit Shift
    , input  wire                  i_din_vld      // Input Siganl Enable
    , input  wire signed [IB-1:0]  i_din_i        // Input Signal I
    , input  wire signed [IB-1:0]  i_din_q        // Input Signal I

    , output wire                  o_dout_vld     // Output Signal Enable
    , output wire signed [OB-1:0]  o_dout_i       // Output Signal
    , output wire signed [OB-1:0]  o_dout_q       // Output Signal
);

//dly+4
ylib_sshftvd_sat
#(
     .IB          (    IB                 )
    ,.SB          (    SB                 )
    ,.OB          (    OB                 )
    ,.ROUND_TYPE  (    ROUND_TYPE         )
    ,.SAT_TYPE    (    SAT_TYPE           )
)
u00_lib_sshftvd_sat
(
     .i_clk       (    i_clk              )                        
    
    ,.i_shft      (    i_shft             )
    ,.i_din_vld   (    i_din_vld          )
    ,.i_din       (    i_din_i            )

    ,.o_dout_vld  (    o_dout_vld         )
    ,.o_dout      (    o_dout_i           )
);

ylib_sshftvd_sat
#(
     .IB          (    IB                 )
    ,.SB          (    SB                 )
    ,.OB          (    OB                 )
    ,.ROUND_TYPE  (    ROUND_TYPE         )
    ,.SAT_TYPE    (    SAT_TYPE           )
)
u01_lib_sshftvd_sat
(
     .i_clk       (    i_clk              )                        
    
    ,.i_shft      (    i_shft             )
    ,.i_din_vld   (    i_din_vld          )
    ,.i_din       (    i_din_q            )

    ,.o_dout_vld  (                       )
    ,.o_dout      (    o_dout_q           )
);


endmodule

