////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common 
//  Module       : ylib_rst_sync
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Reset Synchronizer 
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.22 | jyzoo.lee     | Initial Design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_rst_sync #(parameter DELAY = 16, parameter MAX_FANOUT = 200)
(
    input   wire                    i_clk,
    input   wire                    i_in,
    output  wire                    o_out
);
integer i ;
reg [DELAY:0] r_in ; 
(* max_fanout = MAX_FANOUT *) reg r_out ;
always@(posedge i_clk) for(i=1;i<=DELAY;i=i+1) r_in[i] <= r_in[i-1];
always@(*) begin 
    r_in[0] = i_in ;        
    r_out = r_in[DELAY] ;        
end
assign o_out = r_out ;
endmodule
