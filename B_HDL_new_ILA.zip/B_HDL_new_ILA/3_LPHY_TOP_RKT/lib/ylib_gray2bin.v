////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_bin2gray
//  Author       : jyzoo.lee@samsung.com 
//  Description  : gray to binary converter
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.28 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_gray2bin #(
    parameter WIDTH         =   32
)(
        input	wire    [WIDTH-1:0]     i_in
    ,   output	wire    [WIDTH-1:0]     o_out
);
genvar gidx; 
generate for(gidx=0; gidx<WIDTH; gidx=gidx+1) 
   begin 
      assign o_out[gidx]= ^i_in[WIDTH-1:gidx]; 
   end 
endgenerate 
endmodule 
