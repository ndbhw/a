////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : ylib_shiftd_rnd
//  Author       : jyzoo.lee@samsung.com
//  Description  : multi stream bit down shift with round
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.5.11  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

module ylib_shiftd_rnd
#(
    parameter  NUM_STREAM          =   2           
   ,parameter  SHIFTD_BW           =   4           
   ,parameter  IO_BW               =   15           
)(
        input   wire                                i_clk                      
    ,   input   wire    [0:0]                       i_in_en
    ,   input   wire    [NUM_STREAM*IO_BW-1:0]      i_in
    ,   input   wire    [SHIFTD_BW-1:0]             i_shiftd
    ,   output  reg     [0:0]                       o_out_en
    ,   output  reg     [NUM_STREAM*IO_BW-1:0]      o_out
);

genvar gidx ;

reg [IO_BW-1:0] r_in    [NUM_STREAM-1:0];
reg [0:0]       r_tmp1  [NUM_STREAM-1:0];
reg [IO_BW-1:0] r_tmp2  [NUM_STREAM-1:0];
reg [IO_BW-1:0] r_tmp3  [NUM_STREAM-1:0];
reg [0:0]           r_tmp_en    ;
reg [SHIFTD_BW-1:0] r_shiftd    ;
generate for(gidx=0;gidx<NUM_STREAM;gidx=gidx+1) begin : g00_gen_shiftd_rnd
always@(*) begin
    r_in[gidx] = i_in[(IO_BW*(gidx+1)-1)-:IO_BW] ;
end
if(gidx==0) begin
always@(posedge i_clk) begin 
    r_tmp_en    <=  i_in_en     ;
    o_out_en    <=  r_tmp_en    ;
    if(i_in_en) begin
        r_shiftd    <=  i_shiftd    ;
    end
end
end
always@(posedge i_clk) begin 
    if(i_in_en) begin
        r_tmp1[gidx]    <=  r_in[gidx][IO_BW-1]&~|(r_in[gidx]<<<((IO_BW-1)-i_shiftd+2))   ;
        r_tmp2[gidx]    <=  $signed($signed(r_in[gidx])>>>i_shiftd) ;
        r_tmp3[gidx]    <=  $signed($signed($signed(r_in[gidx])>>>i_shiftd))+r_in[gidx][i_shiftd-1]    ;
    end
end
always@(posedge i_clk) begin
    if(r_tmp_en) begin
        o_out[(IO_BW*(gidx+1)-1)-:IO_BW] <= ((~|r_shiftd)||(r_tmp1[gidx])) ? r_tmp2[gidx] : r_tmp3[gidx]  ;
    end
end
end
endgenerate

endmodule
