////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_conv_16to15.v
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Convert 16bit to 15bit for Multi Stream 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.12 |jyzoo.lee      | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2022.02.16 |jyzoo.lee      | CONV_16TO15 Integrated
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_conv_16to15
#(
        parameter   DO_BW          =   16 
       ,parameter   NUM_STREAM     =   2 
)(
        input   wire                            i_clk
    ,   input   wire    [01-1:0]                i_bfn_strb
    ,   input   wire    [12-1:0]                i_bfn
    ,   input   wire    [01-1:0]                i_csync
    ,   input   wire    [01-1:0]                i_en
    ,   input   wire    [16*NUM_STREAM-1:0]     i_in
    ,   output  wire    [01-1:0]                o_bfn_strb
    ,   output  wire    [12-1:0]                o_bfn
    ,   output  wire    [01-1:0]                o_fsync
    ,   output  wire    [01-1:0]                o_en
    ,   output  wire    [DO_BW*NUM_STREAM-1:0]  o_out
);

localparam  DLY_SYNC    =   3   ;

wire [15*NUM_STREAM-1:0] w_out ;
CONV_16TO15 u00_16to15
(
     .CLK                          (   i_clk                    )
    ,.CONV_IN_10MS                 (   i_bfn_strb               )
    ,.CONV_IN_TDD                  (   1'd0                     )
    ,.CONV_IN_SYNC                 (   i_csync                  )
    ,.CONV_IN_DATA_I               (   i_in[(16*2-1)-:16]       )
    ,.CONV_IN_DATA_Q               (   i_in[(16*1-1)-:16]       )
    ,.CONV_OUT_10MS                (   o_bfn_strb               )
    ,.CONV_OUT_TDD                 (                            )
    ,.CONV_OUT_SYNC                (                            )
    ,.CONV_OUT_DATA_I              (   o_out[(16*2-1-1)-:15]    )
    ,.CONV_OUT_DATA_Q              (   o_out[(16*1-1-1)-:15]    )
);
assign o_out[16*2-1] = o_out[16*2-1-1] ;
assign o_out[16*1-1] = o_out[16*1-1-1] ;
reg r_bfn_strb ;
always@(posedge i_clk) begin
    r_bfn_strb <= i_bfn_strb ;
end
wire w_fsync ;
assign w_fsync = i_bfn_strb&~r_bfn_strb ;
assign o_bfn = i_bfn ;
ylib_reg #(
     .WIDTH (   2               ) 
    ,.DEPTH (   DLY_SYNC        )) 
u01_sync
(
     .i_clk     (  i_clk            )
    ,.i_in      (  {w_fsync,i_en}   )
    ,.o_out     (  {o_fsync,o_en}   )
);
endmodule
