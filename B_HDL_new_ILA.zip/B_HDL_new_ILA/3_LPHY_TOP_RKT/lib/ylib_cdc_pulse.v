////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_cdc_pulse
//  Author       : jyzoo.lee@samsung.com 
//  Description  : cdc hadling for pulse with sync reset
//                 set_false_path -to [get_cells {cdc[*]}]
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.09 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.12.08 |jyzoo.lee      | Available CDC_LEVEL=0 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cdc_pulse #(parameter CDC_LEVEL = 4)
(
        input   wire        i_src_clk
    ,   input   wire        i_src_rst
    ,   input   wire        i_dest_clk
    ,   input   wire        i_dest_rst
    ,   input   wire        i_in
    ,   output  reg         o_out
);

generate if(CDC_LEVEL>0) begin
reg r_in    ;
reg [CDC_LEVEL:0]   cdc     ;
always@(posedge i_src_clk) begin
    r_in <= i_in;
end
reg toggle  ;
always@(posedge i_src_clk) begin
    if(i_src_rst) begin
        toggle <= 1'b0;
    end
    else if(i_in&~r_in) begin
        toggle <= ~toggle   ;
    end
end
always@(posedge i_dest_clk) begin
    if(i_dest_rst) begin
        cdc <=  {{CDC_LEVEL+1}{1'b0}} ;
    end
    else begin
        cdc <=  {cdc[CDC_LEVEL-1:0], toggle}    ;
    end
end
always@(posedge i_dest_clk) begin
    o_out <= cdc[CDC_LEVEL-1]^cdc[CDC_LEVEL]  ;
end
end
else begin
reg r_in    ;
reg rr_in   ;
reg rrr_in  ;
always@(posedge i_dest_clk) begin
    r_in   <= i_in  ;
    rr_in  <= r_in  ;
    rrr_in <= rr_in ;
end
always@(*) begin
    o_out = rr_in&~rrr_in  ;
end
end
endgenerate

endmodule
