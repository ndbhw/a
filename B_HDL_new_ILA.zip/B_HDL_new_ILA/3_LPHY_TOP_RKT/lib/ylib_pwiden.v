////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common 
//  Module       : ylib_pwiden
//  Author       : jyzoo.lee@samsung.com
//  Description  : Widen a pulse
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.08 |jyzoo.lee      | Create initial design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`define mlib_clog2(A) A > 1 ? $clog2(A) : 1 

module ylib_pwiden #(
    parameter   CYCLE    =  64 
)(
        input   wire                        i_clk
    ,   input   wire    [0:0]               i_in
    ,   output  wire    [0:0]               o_out
);

reg [0:0] r_cnt_en ;
reg [`mlib_clog2(CYCLE)-1:0] r_cnt ;
always@(posedge i_clk) begin
    if(i_in) begin
        r_cnt <= {{`mlib_clog2(CYCLE)}{1'b0}} ;
    end
    else if(r_cnt_en) begin
        r_cnt <= (r_cnt==CYCLE-1'd1) ? {{`mlib_clog2(CYCLE)}{1'b0}} : r_cnt+1'b1 ;
    end 
end
always@(posedge i_clk) begin
    if(i_in) begin
        r_cnt_en <= 1'b1 ;
    end 
    else if(r_cnt==CYCLE-1'd1) begin
        r_cnt_en <= 1'b0 ;
    end
end
assign o_out = CYCLE=={{`mlib_clog2(CYCLE)}{1'b0}} ? i_in : r_cnt_en ;

endmodule
