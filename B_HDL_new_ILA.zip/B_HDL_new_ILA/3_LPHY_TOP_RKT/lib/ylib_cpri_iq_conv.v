//////////////////////////////////////////////////////////////////////////////// // 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_cpri_iq_conv
//  Author       : jyzoo.lee@samsung.com 
//  Description  : cpri iq conversion parser
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.27 |jyzoo.lee      | Created Initial Design
//  ------------+---------------+-----------------------------------------------
//   2021.12.29 |jyzoo.lee      | Sector Mode Support
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cpri_iq_conv
#(
     parameter  DI_BW               =   16           
    ,parameter  DO_BW               =   15           
    ,parameter  NUM_LAYER_LANE      =   2           
    ,parameter  RETARD              =   1           
)(
     input  wire                                i_clk
    ,input  wire                                i_symbol_sync
    ,input  wire                                i_en
    ,input  wire                                i_csync
    ,input  wire   [2*DI_BW-1:0]                i_cdata
    ,input  wire   [12-1:0]                     i_ntone
    ,input  wire   [12-1:0]                     i_re_start
    ,output reg    [NUM_LAYER_LANE-1:0]         o_re_cdata_en 
    ,output reg    [2*DO_BW-1:0]                o_re_cdata 
);

//Parameter Local Logic
localparam              DLY_CDATA                   =        RETARD+5           ;      
localparam              DLY_CDATA_16_15             =        DLY_CDATA-4        ;      
localparam              DLY_SYNC                    =        0                  ;      

//Logic Variable
integer i ;

reg [RETARD:0]      r_symbol_sync   ;
reg [RETARD:0]      r_csync         ;
reg [RETARD:0]      r_en            ;
reg [DI_BW-1:0]     r_cdata_i [DLY_CDATA:0]   ;
reg [DI_BW-1:0]     r_cdata_q [DLY_CDATA:0]   ;
always@(*) begin
    r_symbol_sync   [0]   =  i_symbol_sync  ;
    r_csync         [0]   =  i_csync        ;
    r_en            [0]   =  i_en           ;
    r_cdata_i       [0]   =  i_cdata[(DI_BW*2-1)-:DI_BW]    ;
    r_cdata_q       [0]   =  i_cdata[(DI_BW*1-1)-:DI_BW]    ;
end
always@(posedge i_clk) begin
    for(i=1;i<=RETARD;i=i+1) begin
        r_symbol_sync[i]   <=  r_symbol_sync[i-1] ;
        r_en         [i]   <=  r_en         [i-1] ;
    end
    for(i=1;i<=DLY_CDATA;i=i+1) begin
        r_csync      [i]   <=  r_csync      [i-1] ;
        r_cdata_i    [i]   <=  r_cdata_i    [i-1] ;
        r_cdata_q    [i]   <=  r_cdata_q    [i-1] ;
    end
end
reg [09-1:0]    r_chip_idx      ;
reg [06-1:0]    r_axc_idx       ;
reg [01-1:0]    r_din_en        ;
always@(posedge i_clk) begin
    r_din_en        <= r_en[RETARD] ;
    if(r_en[RETARD]) begin
        if(r_symbol_sync[RETARD]) begin
            r_chip_idx   <= 9'd0    ;
            r_axc_idx    <= 6'd0    ;
        end
        else begin
            r_axc_idx    <= r_axc_idx + 1 ;
            if(r_csync[RETARD]) begin
                r_chip_idx  <=  r_chip_idx + 1'd1   ;
            end
        end
    end
end
reg [12-1:0] r_re_start ;
always@(posedge i_clk) begin
    if(r_symbol_sync[RETARD]) begin
        r_re_start <= i_re_start ;
    end
end
reg [16-1:0]    rr_re_idx       ;
always@(posedge i_clk) begin
    if(r_symbol_sync[RETARD]) begin
        rr_re_idx <= 16'd0 ;
    end
    else if(r_din_en) begin
        if(r_axc_idx[0]) begin
            rr_re_idx <= rr_re_idx + 1'd1 ;
        end
    end
end
reg [01-1:0]    rr_re_en ;
reg [DO_BW-1:0] rr_re_i ;
reg [DO_BW-1:0] rr_re_q ;
always@(posedge i_clk) begin
    rr_re_en    <=  r_din_en&&(rr_re_idx>={4'd0,r_re_start}&&rr_re_idx<({4'd0,r_re_start}+{4'd0,i_ntone})) ;
    if(r_din_en) begin
        case(r_axc_idx[3:0])
            4'h0    :   begin   rr_re_i  <=  r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][14:00]                                                    ; rr_re_q  <=  r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][14:00] ;                                                    end
            4'h1    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][13:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:15]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][13:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:15]}; end
            4'h2    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][12:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:14]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][12:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:14]}; end
            4'h3    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][11:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:13]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][11:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:13]}; end
            4'h4    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][10:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:12]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][10:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:12]}; end
            4'h5    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][09:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:11]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][09:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:11]}; end
            4'h6    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][08:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:10]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][08:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:10]}; end
            4'h7    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][07:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:09]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][07:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:09]}; end
            4'h8    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][06:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:08]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][06:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:08]}; end
            4'h9    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][05:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:07]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][05:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:07]}; end
            4'hA    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][04:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:06]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][04:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:06]}; end
            4'hB    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][03:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:05]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][03:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:05]}; end
            4'hC    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][02:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:04]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][02:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:04]}; end
            4'hD    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][01:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:03]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][01:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:03]}; end
            4'hE    :   begin   rr_re_i  <= {r_cdata_i[DLY_CDATA_16_15+0+r_axc_idx[5:4]][00:00],r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:02]}; rr_re_q  <= {r_cdata_q[DLY_CDATA_16_15+0+r_axc_idx[5:4]][00:00],r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:02]}; end
            4'hF    :   begin   rr_re_i  <=                                                     r_cdata_i[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:01] ; rr_re_q  <=                                                     r_cdata_q[DLY_CDATA_16_15+1+r_axc_idx[5:4]][15:01] ; end
            default :   begin   rr_re_i  <= {{DO_BW}{1'b0}}                                                                                        ; rr_re_q  <= {{DO_BW}{1'b0}}                                                                                        ; end
        endcase
    end
end
reg r_re_cdata_en    ;
reg [NUM_LAYER_LANE-1:0]    r_dly_re_cdata_en   [DLY_SYNC:0] ;
reg [2*DO_BW-1:0]           r_dly_re_cdata      [DLY_SYNC:0] ;
always@(posedge i_clk) begin
    if(r_symbol_sync[RETARD]) begin
        r_re_cdata_en   <= 1'd0   ;
    end
    else if(rr_re_en) begin
        r_re_cdata_en       <= 1'd1   ;
        r_dly_re_cdata[0]   <=  {rr_re_i,rr_re_q}   ;
    end
    else begin
        r_re_cdata_en   <= 1'd0   ;
    end
end
reg [$clog2(NUM_LAYER_LANE)-1:0]    r_re_cdata_cnt    ;
always@(posedge i_clk) begin
    if(r_re_cdata_en) begin
        r_re_cdata_cnt  <=  r_re_cdata_cnt+1'd1 ;
    end
    else begin
        r_re_cdata_cnt  <=  {{$clog2(NUM_LAYER_LANE)}{1'b0}} ;
    end
end
always@(*) begin
    r_dly_re_cdata_en[0]    =  {{NUM_LAYER_LANE}{r_re_cdata_en }}&({{{NUM_LAYER_LANE-1}{1'b0}},1'd1}<<r_re_cdata_cnt )    ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_SYNC;i=i+1) begin
        r_dly_re_cdata_en[i] <= r_dly_re_cdata_en[i-1]    ; 
        if(|r_dly_re_cdata_en[i-1]) begin
            r_dly_re_cdata[i] <= r_dly_re_cdata[i-1]     ;
        end
    end
end
always@(*) begin
    o_re_cdata_en   =  r_dly_re_cdata_en    [DLY_SYNC]  ;
    o_re_cdata      =  r_dly_re_cdata       [DLY_SYNC]  ;
end

endmodule
