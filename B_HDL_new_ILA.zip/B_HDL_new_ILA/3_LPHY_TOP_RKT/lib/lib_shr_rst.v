////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : lib_shr_rst
//  Author       : Song, Moon-Gun
//  Description  : Shift Register with Async. Reset
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module lib_shr_rst #(
      parameter                WIDTH = 1
    , parameter                DEPTH = 8
    , parameter                RESET_VAL   = {WIDTH{1'b0}}
) (
      input  wire              i_clk
    , input  wire              i_rst
    , input  wire              i_en  
    , input  wire [WIDTH-1:0]  i_in  
    , output wire [WIDTH-1:0]  o_out
);

reg     [WIDTH-1:0] r_shr[DEPTH-1:0];
integer k;

always @ (posedge i_clk or posedge i_rst) begin
    if(i_rst) begin
        for(k = 0; k < DEPTH; k = k + 1) begin
            r_shr[k] <= RESET_VAL;
        end
    end
    else if(i_en) begin
        r_shr[0]  <= i_in;
        for(k = 1; k < DEPTH; k = k + 1) begin
            r_shr[k] <= r_shr[k-1];
        end
    end
end

assign o_out = r_shr[DEPTH-1];

endmodule
