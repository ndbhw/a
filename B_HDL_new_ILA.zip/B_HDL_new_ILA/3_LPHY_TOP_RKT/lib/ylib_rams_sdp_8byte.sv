////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_rams_sdp
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Simple Dual-Port Block RAM (recommended template)
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.7.07  | taeyeong      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.7.09  | jyzoo.lee     | Xilinx Compatible
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_rams_sdp_8byte #(  
    parameter  WIDTH        =   64   ,//"FIXED"     //  bytes * byte_width
    parameter  DEPTH        =   1024, 
    parameter  VENDOR       =   "Xilinx"
)(
        input                                   clk
    ,   input                                   ena
    ,   input                                   enb
    ,   input                                   wea
    ,   input       [WIDTH/8-1:0]               be
    ,   input       [$clog2(DEPTH)-1:0]         addra
    ,   input       [$clog2(DEPTH)-1:0]         addrb
    ,   input       [WIDTH-1:0]                 dia
    ,   output  reg [WIDTH-1:0]                 dob
);

//parameter WIDTH = 64;

//reg [8-1:0] ram [DEPTH-1:0][WIDTH/8-1:0] ;
logic [8-1:0][WIDTH/8-1:0] ram[0:DEPTH-1];

generate if (VENDOR == "Xilinx") begin

(* ram_style = "ultra" *)
localparam DW = WIDTH;
localparam ND = DEPTH;
localparam NP = 2;


reg [DW-1:0] r_ram         [ND-1:0];    // Memory Declaration
reg          r_enb                      ;
reg [DW-1:0] r_ram_read                 ;
reg          r_read_en_pipe[NP-1:0]     ;    // Pipelines for memory enable  
reg [DW-1:0] r_read_pipe   [NP-1:0]     ;    // Pipelines for memory


always @(posedge clk) begin
    if(ena) begin
        if(wea) r_ram[addra] <= dia;
    end
end


always @(posedge clk) begin
    if(enb) begin
        r_ram_read <= r_ram[addrb];
    end
end

integer i;




always @(posedge clk) begin
    r_read_en_pipe[0] <= enb;
    for(i = 1; i < NP; i = i + 1) r_read_en_pipe[i] <= r_read_en_pipe[i-1];
end

always @(posedge clk) begin
    if(r_read_en_pipe[0]) r_read_pipe[0] <= r_ram_read;
end    

always @(posedge clk) begin
    for(i = 1; i < NP; i = i + 1) begin
        if(r_read_en_pipe[i]) r_read_pipe[i] <= r_read_pipe[i-1];
    end
end  

assign dob = r_read_pipe[NP-1];





end

else begin : Intel

integer i,j,jj;


initial 
begin : INIT
    
    for(i = 0; i < DEPTH; i = i + 1)
    begin
        for(j = 0; j < WIDTH/8 ; j = j + 1)
        begin
            ram[i][j]          = {8{1'b0}};
        end
    end
end
     

always@(posedge clk)
begin
	if (ena&wea)
    begin
	    //generate 
	    for(j = 0; j < WIDTH/8 ; j = j + 1)
	    begin
	        if(be[0]) ram[addra][0] <= dia[(0+1)*8-1:(0)*8];
            if(be[1]) ram[addra][1] <= dia[(1+1)*8-1:(1)*8];
	        if(be[2]) ram[addra][2] <= dia[(2+1)*8-1:(2)*8];
	        if(be[3]) ram[addra][3] <= dia[(3+1)*8-1:(3)*8];
	        if(be[4]) ram[addra][4] <= dia[(4+1)*8-1:(4)*8];
	        if(be[5]) ram[addra][5] <= dia[(5+1)*8-1:(5)*8];
	        if(be[6]) ram[addra][6] <= dia[(6+1)*8-1:(6)*8];
            if(be[7]) ram[addra][7] <= dia[(7+1)*8-1:(7)*8];
                
//	                   if(be[jj]) ram[addra][jj] <= dia[(8*(jj+1)-1)-:8]; 
		end
		//endgenerate
    end
    if (enb)
	    dob <= ram[addrb];
end

end
endgenerate

endmodule
