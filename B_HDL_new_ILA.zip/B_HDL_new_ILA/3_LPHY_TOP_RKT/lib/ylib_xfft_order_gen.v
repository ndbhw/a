////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_xfft_order_gen
//  Author       : jyzoo.lee@samsung.com
//  Description  : NORMAL - Generate Digit Reverse Order for xFFT output
//                 AIE_IFFT - Generate Order for XILINX AIE IFFT 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.07 |jyzoo.lee      | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.07.13 |jyzoo.lee      | fft_size Configurable 
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 |jyzoo.lee      | Supports up to 4k
//  ------------+---------------+-----------------------------------------------
//   2020.12.08 |jyzoo.lee      | Infered Latch Removed
//  ------------+---------------+-----------------------------------------------
//   2021.03.31 |jyzoo.lee      | Supports AIE FFT
//  ------------+---------------+-----------------------------------------------
//   2021.10.14 |jyzoo.lee      | Supports 128pts in normal mode
//  ------------+---------------+-----------------------------------------------
//   2021.11.23 |jyzoo.lee      | Supports 16,64pts fft and burst fft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_xfft_order_gen #(
    parameter   MAX_NFFT    =   2048 
   ,parameter   IP_TYPE     =   "NORMAL" 
   ,parameter   ID_AXIS     =   0 
)(
     input   wire                               i_clk       
    ,input   wire    [3:0]                      i_xfft_size //NORMAL : xFFT Size, AIE_IFFT : Stream ID
    ,input   wire    [0:0]                      i_xfft_out_en
    ,output  reg     [0:0]                      o_xfft_out_en
    ,output  reg     [$clog2(MAX_NFFT)-1:0]     o_xfft_out_idx
);

localparam      ORAN_FFT0016        =       4'h4                ;
localparam      ORAN_FFT0064        =       4'h6                ;
localparam      ORAN_FFT0128        =       4'h7                ;
localparam      ORAN_FFT0512        =       4'h9                ;
localparam      ORAN_FFT1024        =       4'ha                ;
localparam      ORAN_FFT2048        =       4'hb                ;
localparam      ORAN_FFT4096        =       4'hc                ;
localparam      AIE_AXIS_ID0        =       0                   ;
localparam      AIE_AXIS_ID1        =       1                   ;
localparam      AIE_AXIS_ID2        =       2                   ;
localparam      AIE_AXIS_ID3        =       3                   ;
localparam      BW_MAX_NFFT         =       $clog2(MAX_NFFT)    ;

integer i ;

reg [$clog2(MAX_NFFT)-1:0]  r_cnt = 0 ; //for sim
reg [ORAN_FFT4096-1:0]      r_xfft_out_idx ;
always@(posedge i_clk) begin
    o_xfft_out_en    <=  i_xfft_out_en ;
    if(~i_xfft_out_en&o_xfft_out_en) begin
        r_cnt <=  {{$clog2(MAX_NFFT)}{1'd0}}  ;
    end
    else if(i_xfft_out_en) begin
        r_cnt <=  r_cnt + 1'd1  ;
    end
end
generate if(IP_TYPE=="AIE_IFFT") begin
always@(posedge i_clk) begin
    if(~i_xfft_out_en&o_xfft_out_en) begin
        r_xfft_out_idx <= {{BW_MAX_NFFT}{1'd0}} ;
    end
    else if(i_xfft_out_en) begin
        case(ID_AXIS) 
            AIE_AXIS_ID0 : r_xfft_out_idx <= r_cnt<({{{BW_MAX_NFFT-1}{1'd0}},1'b1}<<ORAN_FFT0512) ? ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d0+'d0    : ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d2048+'d0 ;
            AIE_AXIS_ID1 : r_xfft_out_idx <= r_cnt<({{{BW_MAX_NFFT-1}{1'd0}},1'b1}<<ORAN_FFT0512) ? ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d0+'d1    : ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d2048+'d1 ;
            AIE_AXIS_ID2 : r_xfft_out_idx <= r_cnt<({{{BW_MAX_NFFT-1}{1'd0}},1'b1}<<ORAN_FFT0512) ? ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d1024+'d0 : ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d3072+'d0 ;
            AIE_AXIS_ID3 : r_xfft_out_idx <= r_cnt<({{{BW_MAX_NFFT-1}{1'd0}},1'b1}<<ORAN_FFT0512) ? ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d1024+'d1 : ({{{ORAN_FFT4096-ORAN_FFT0512}{1'b0}},r_cnt[ORAN_FFT0512-1:0]}<<1)+'d3072+'d1 ;
            default      : r_xfft_out_idx <= {{BW_MAX_NFFT}{1'd0}} ;
        endcase
    end
end
end
else begin
always@(posedge i_clk) begin
    if(~i_xfft_out_en&o_xfft_out_en) begin
        r_xfft_out_idx <= {{BW_MAX_NFFT}{1'd0}} ;
    end
    else if(i_xfft_out_en) begin
        case(i_xfft_size) 
            ORAN_FFT0016 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT0016) r_xfft_out_idx[ORAN_FFT0016-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT0064 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT0064) r_xfft_out_idx[ORAN_FFT0064-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT0128 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT0128) r_xfft_out_idx[ORAN_FFT0128-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT0512 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT0512) r_xfft_out_idx[ORAN_FFT0512-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT1024 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT1024) r_xfft_out_idx[ORAN_FFT1024-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT2048 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT2048) r_xfft_out_idx[ORAN_FFT2048-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            ORAN_FFT4096 : begin 
                for(i=0;i<BW_MAX_NFFT;i=i+1) begin 
                    if(i<ORAN_FFT4096) r_xfft_out_idx[ORAN_FFT4096-1-i] <= r_cnt[i] ;
                    else r_xfft_out_idx[i] <= 1'd0 ;
                end
            end
            default     : begin r_xfft_out_idx <= {{BW_MAX_NFFT}{1'd0}} ; end
        endcase
    end
end
end
endgenerate
always@(*) begin
    o_xfft_out_idx = r_xfft_out_idx[$clog2(MAX_NFFT)-1:0] ;
end
endmodule
