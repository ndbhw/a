//////////////////////////////////////////////////////////////////////////////// // 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common 
//  Module       : ylib_reg_en
//  Author       : jyzoo.lee@samsung.com 
//  Description  : pipelined registers with enable
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.08.20 | jyzoo.lee     | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_reg_en #(parameter WIDTH = 16, parameter DEPTH = 1)
(
    input   wire                    i_clk,
    input   wire                    i_en,
    input   wire    [WIDTH-1:0]     i_in,
    output  reg                     o_en,
    output  reg     [WIDTH-1:0]     o_out
);

integer i ;
reg [1-1:0] r_en [DEPTH:0] ; 
reg [WIDTH-1:0] r_in [DEPTH:0] ; 
always@(posedge i_clk) begin
    for(i=1;i<=DEPTH;i=i+1) begin
        r_en[i] <= r_en[i-1];
        if(r_en[i-1]) begin
            r_in[i] <= r_in[i-1];
        end
    end
end
always@(*) begin 
    r_en[0] = i_en ;        
    r_in[0] = i_in ;        
    o_en  = r_en[DEPTH] ;        
    o_out = r_in[DEPTH] ;        
end
endmodule
