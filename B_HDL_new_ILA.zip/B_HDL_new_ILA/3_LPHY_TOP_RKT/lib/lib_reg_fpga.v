/*
////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
--  Module Name : lib_reg
--  Author      : Kilsik Ha
--  Date        : 2014/03/03
--  Abstract    : Multi-bit register
--  Revision
    2014/03/03  : First version created
*/

module lib_reg_fpga #(
    parameter                       WIDTH       = 1
) (
    input   wire                    i_clk,
    input   wire                    i_en,
    input   wire    [WIDTH-1:0]     i_in,
    output  reg     [WIDTH-1:0]     o_out=0
);

always @ (posedge i_clk) begin
    if(i_en) begin
        o_out   <= i_in;
    end
end

endmodule
