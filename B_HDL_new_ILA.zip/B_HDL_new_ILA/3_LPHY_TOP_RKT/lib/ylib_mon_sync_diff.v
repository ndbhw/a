////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_mon_sync_diff
//  Author       : jyzoo.lee@samsung.com 
//  Description  : time difference monitoring
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.08.28 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2021.03.15 |jyzoo.lee      | compensated by plus one for real difference
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_mon_sync_diff
# (
    parameter WIDTH         =   22   
)(
        input   wire                    i_clk
    ,   input   wire                    i_sync0
    ,   input	wire                    i_sync1
    ,   output	reg     [WIDTH-1:0]     o_diff
);

reg     [WIDTH-1:0] r_cnt   ;
always@(posedge i_clk) begin
    if(i_sync0) begin
    	r_cnt   <=  {{{WIDTH-1}{1'b0}},1'b1}   ;
    end
    else begin
    	r_cnt   <=  r_cnt+1'b1      ;
    end
end
always@(posedge i_clk) begin
    if(i_sync1) begin
        o_diff  <=  r_cnt   ;
    end
end
endmodule
