////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2019 Samsung Electronics Inc. All rights reserved
//
//  Project      : Verizon FSU20
//  Module       : ylib_bus_comb_ant
//  Author       : taeyeong
//  Description  : bus combine 4 to 1
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.03 | taeyeong      | Inital Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_bus_comb_ant #(
     parameter  IB          =   16
    ,parameter  OB          =   16
    ,parameter  DLY         =    0          
)(
     input   wire                              i_clk

    ,input   wire    [IB*2     -1:0]           i_in_00 
    ,input   wire    [IB*2     -1:0]           i_in_01 
    ,input   wire    [IB*2     -1:0]           i_in_02 
    ,input   wire    [IB*2     -1:0]           i_in_03 

    ,output  wire    [OB*2*24  -1:0]           i_out
);

// signal
wire    [OB*2*24     -1:0]           w_out; 

// generate
generate
if(IB > OB) begin : left
    assign w_out = { 
    i_in_03[IB-1],i_in_03[OB-2:0],i_in_02[IB-1],i_in_02[OB-2:0],i_in_01[IB-1],i_in_01[OB-2:0],i_in_00[IB-1],i_in_00[OB-2:0]
    };
end
else if(IB < OB) begin : right
    localparam DIFF = OB-IB    ;

    assign w_out = {
    {DIFF{i_in_03[IB-1]}},i_in_03,{DIFF{i_in_02[IB-1]}},i_in_02,{DIFF{i_in_01[IB-1]}},i_in_01,{DIFF{i_in_00[IB-1]}},i_in_00
    };
end
else begin : same
    assign w_out = {
    i_in_03,i_in_02,i_in_01,i_in_00
    };
end
endgenerate

// output
generate
if (DLY == 0) begin : zero_dly
    assign o_out = w_out ; 
end
else begin : fix_dly
    ylib_reg #(.WIDTH(OB*2*24) ,.DEPTH(DLY)) u_out_reg(
         .i_clk      (i_clk     )
        ,.i_in       (w_out     )
        ,.o_out      (o_out     )
     );
end
endgenerate

endmodule
