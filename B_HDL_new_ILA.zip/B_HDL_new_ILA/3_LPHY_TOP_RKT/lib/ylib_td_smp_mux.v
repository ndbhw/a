////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_td_smp_mux.v
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Map TD Signal to SBIF AxC Signal
//                 Feature : CBW 20/15/10/5M 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.10 |jyzoo.lee      | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_td_smp_mux
#(
        parameter   NUM_ANT     =    4
   ,    parameter   CC_IDX      =    0 
   ,    parameter   DIO_BW      =    16
)(
        input   wire                                i_clk
    ,   input   wire    [4-1:0]                     i_bw_idx
    ,   input   wire    [01-1:0]                    i_bfn_strb
    ,   input   wire    [12-1:0]                    i_bfn
    ,   input   wire    [01-1:0]                    i_fsync
    ,   input   wire    [01*NUM_ANT-1:0]            i_en
    ,   input   wire    [2*DIO_BW*NUM_ANT-1:0]      i_iq
    ,   output  reg     [01-1:0]                    o_bfn_strb
    ,   output  reg     [12-1:0]                    o_bfn
    ,   output  reg     [01-1:0]                    o_en
    ,   output  reg     [2*DIO_BW-1:0]              o_iq
);

genvar  gidx    ;

localparam      BW_NUM_ANT          =           $clog2(NUM_ANT)     ;
localparam      IDX_BW_020          =           4'd3                ;
localparam      IDX_BW_015          =           4'd2                ;
localparam      IDX_BW_010          =           4'd1                ;
localparam      IDX_BW_005          =           4'd0                ;
localparam      BW_SR_BW_020        =           $clog2(08)          ;
localparam      BW_SR_BW_015        =           $clog2(08)          ;
localparam      BW_SR_BW_010        =           $clog2(16)          ;
localparam      BW_SR_BW_005        =           $clog2(32)          ;
localparam      DLY_SYNC            =           5                   ;

reg [5:0] r_axc_cnt ;
always@(posedge i_clk) begin
    if(i_fsync) begin
        r_axc_cnt <= 6'd0 ;
    end
    else begin
        r_axc_cnt <= r_axc_cnt+1'd1 ;
    end
end
reg [01-1:0]    r_bfn_strb      ;
reg [01-1:0]    rr_bfn_strb     ;
always@(posedge i_clk) begin
    r_bfn_strb <= i_bfn_strb ;
    if(i_fsync) begin
        rr_bfn_strb <= 1'd0 ;
    end
    else begin
        rr_bfn_strb <= r_bfn_strb ;
    end
end
reg r_ssync ;
reg [01*NUM_ANT-1:0] r_en   ;   
reg [2*DIO_BW-1:0]   r_iq     [NUM_ANT-1:0]  ;   
always@(posedge i_clk) begin
    if(|r_en) begin
        case(i_bw_idx)
            IDX_BW_020  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_020-1:0] ;
            IDX_BW_015  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_015-1:0] ;
            IDX_BW_010  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_010-1:0] ;
            IDX_BW_005  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_005-1:0] ;
            default     : r_ssync  <= {{2*DIO_BW}{1'd0}} ; 
        endcase
    end
end
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_ant_split
always@(posedge i_clk) begin
    r_en[gidx]  <=  i_en[gidx] ;
    if(i_en[gidx]) begin
        r_iq[gidx]  <=  i_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
    end
end
end
endgenerate
reg [1-1:0]         r_map_en   ;
reg [2*DIO_BW-1:0]  r_map_iq  ;   
always@(posedge i_clk) begin
    r_map_en    <= |r_en  ;
    if(|r_en) begin
        case(i_bw_idx)
            IDX_BW_020  : r_map_iq  <= r_axc_cnt[BW_SR_BW_020-1:0]>=(NUM_ANT*CC_IDX) && r_axc_cnt[BW_SR_BW_020-1:0]<(NUM_ANT*(CC_IDX+1)) ? {r_iq[r_axc_cnt[BW_NUM_ANT-1:0]]} : {{2*DIO_BW}{1'd0}} ;
            IDX_BW_015  : r_map_iq  <= r_axc_cnt[BW_SR_BW_015-1:0]>=(NUM_ANT*CC_IDX) && r_axc_cnt[BW_SR_BW_015-1:0]<(NUM_ANT*(CC_IDX+1)) ? {r_iq[r_axc_cnt[BW_NUM_ANT-1:0]]} : {{2*DIO_BW}{1'd0}} ;
            IDX_BW_010  : r_map_iq  <= r_axc_cnt[BW_SR_BW_010-1:0]>=(NUM_ANT*CC_IDX) && r_axc_cnt[BW_SR_BW_010-1:0]<(NUM_ANT*(CC_IDX+1)) ? {r_iq[r_axc_cnt[BW_NUM_ANT-1:0]]} : {{2*DIO_BW}{1'd0}} ;
            IDX_BW_005  : r_map_iq  <= r_axc_cnt[BW_SR_BW_005-1:0]>=(NUM_ANT*CC_IDX) && r_axc_cnt[BW_SR_BW_005-1:0]<(NUM_ANT*(CC_IDX+1)) ? {r_iq[r_axc_cnt[BW_NUM_ANT-1:0]]} : {{2*DIO_BW}{1'd0}} ;
            default     : r_map_iq  <= {{2*DIO_BW}{1'd0}} ; 
        endcase
    end
end
always@(posedge i_clk) begin
    o_bfn_strb  <= rr_bfn_strb  ;
    o_en        <= r_map_en     ;
    if(r_map_en) begin
        o_iq <= r_map_iq ;
    end
    else begin
        o_iq <= {{2*DIO_BW}{1'b0}} ;
    end
    if(rr_bfn_strb&~o_bfn_strb) begin
        o_bfn <= i_bfn ;
    end
end
endmodule
