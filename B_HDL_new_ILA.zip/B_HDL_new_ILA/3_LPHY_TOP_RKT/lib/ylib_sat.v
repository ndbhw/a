////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_sat
//  Author       : jyzoo.lee@samsung.com
//  Description  : multi stream DI_BW to DO_BW conversion
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.5.11  | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2020.7.15  | jyzoo.lee     | Asymmetric -> Symmetric
//  ------------+---------------+-------------------------------------------------------
//   2020.7.22  | jyzoo.lee     | SAT_TYPE Option Support
//  ------------+---------------+-------------------------------------------------------
//   2020.7.22  | jyzoo.lee     | SAT_TYPE Option Support
//  ------------+---------------+-------------------------------------------------------
//   2021.5.09  | jyzoo.lee     | Sign Extension Support
//  ------------+---------------+-------------------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

module ylib_sat
#(
    parameter  NUM_STREAM   =   1           
   ,parameter  DI_BW        =   15           
   ,parameter  DO_BW        =   15           
   ,parameter  SAT_TYPE     =   "SYMMETRIC"  
)(
        input   wire                                i_clk                      
    ,   input   wire    [0:0]                       i_in_en
    ,   input   wire    [NUM_STREAM*DI_BW-1:0]      i_in
    ,   output  reg     [0:0]                       o_out_en
    ,   output  reg     [NUM_STREAM*DO_BW-1:0]      o_out
);

genvar gidx ;

reg [DI_BW-1:0] r_in [NUM_STREAM-1:0] ;
generate for(gidx=0;gidx<NUM_STREAM;gidx=gidx+1) begin : g00_gen_sat
if(DI_BW>DO_BW) begin 
    always@(*) begin
        r_in[gidx] = i_in[(DI_BW*(gidx+1)-1)-:DI_BW] ;
    end
    if(SAT_TYPE == "ASSYMETRIC") begin
        always@(posedge i_clk) begin
            if(i_in_en) begin
                if($signed(r_in[gidx])>$signed({{{DI_BW-DO_BW+1}{1'b0}},{{DO_BW-1}{1'b1}}})) begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= {1'b0,{{DO_BW-1}{1'b1}}} ;
                end
                else if($signed(r_in[gidx])<$signed({{{DI_BW-DO_BW+1}{1'b1}},{{DO_BW-1}{1'b0}}})) begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= {1'b1,{{DO_BW-1}{1'b0}}} ;
                end
                else begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= r_in[gidx][DO_BW-1:0] ;
                end
            end
        end
    end
    else begin //"SYMMETRIC"
        always@(posedge i_clk) begin
            if(i_in_en) begin
                if($signed(r_in[gidx])>$signed({{{DI_BW-DO_BW+1}{1'b0}},{{DO_BW-1}{1'b1}}})) begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= {1'b0,{{DO_BW-1}{1'b1}}} ;
                end
                else if($signed(r_in[gidx])<$signed({{{DI_BW-DO_BW+1}{1'b1}},{{DO_BW-2}{1'b0}},1'b1})) begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= {1'b1,{{DO_BW-2}{1'b0}},1'b1} ;
                end
                else begin
                    o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= r_in[gidx][DO_BW-1:0] ;
                end
            end
        end 
    end //"SYMMETRIC"
end
else begin//(DI_BW>DO_BW)
    always@(*) begin
        r_in[gidx] = i_in[(DI_BW*(gidx+1)-1)-:DI_BW] ;
    end
    always@(posedge i_clk) begin
        if(i_in_en) begin
            o_out[(DO_BW*(gidx+1)-1)-:DO_BW] <= {{{DO_BW-DI_BW}{r_in[gidx][DI_BW-1]}},r_in[gidx][DI_BW-1:0]} ;
        end
    end
end//(DI_BW>DO_BW)
end
endgenerate
always@(posedge i_clk) begin
    o_out_en    <=  i_in_en ;
end
endmodule
