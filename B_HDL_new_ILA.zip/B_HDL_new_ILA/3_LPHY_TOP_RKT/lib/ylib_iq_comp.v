////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_iq_comp
//  Author       : jyzoo.lee@samsung.com
//  Description  : iq data compression
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2021.08.02 | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2021.12.02 | jyzoo.lee     | Bug Fix, Algorithm modified 
//  ------------+---------------+-------------------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

module ylib_iq_comp
#(
    parameter  DI_BW        =   12 
   ,parameter  DO_BW        =   9
   ,parameter  BW_EXP       =   2
)(
        input   wire                                i_clk                      
    ,   input   wire    [0:0]                       i_in_en
    ,   input   wire    [2*DI_BW-1:0]               i_in_iq
    ,   output  wire    [0:0]                       o_out_en
    ,   output  wire    [2*DO_BW-1:0]               o_out_iq
    ,   output  wire    [BW_EXP-1:0]                o_out_exp
);

genvar gidx ;
integer i ;

reg  [2*DI_BW-1:0]      r_in_iq_abs     ;
reg  [1-1:0]            r_in_x_en       ;
reg  [DI_BW-1:0]        r_in_iq_x       ;
reg  [1-1:0]            r_in_iq_sgn     ;
reg  [2*DI_BW-1:0]      r_in_iq         ;
reg  [1-1:0]            rr_x_en         ;
reg  [DI_BW-1:0]        rr_x            ;
reg  [2-1:0]            rr_exp          ;
reg  [2*DI_BW-1:0]      rr_in_iq        ;
wire [1-1:0]            w_in_en_rnd     ;
wire [2*DI_BW-1:0]      w_in_iq_rnd     ;
always@(*) begin
    for(i=0;i<2;i=i+1) begin
        r_in_iq_abs[(DI_BW*(i+1)-1)-:DI_BW] = i_in_iq[DI_BW*(i+1)-1] ? ~i_in_iq[(DI_BW*(i+1)-1)-:DI_BW]+1'b1 : i_in_iq[(DI_BW*(i+1)-1)-:DI_BW] ;
    end
end
always@(posedge i_clk) begin
    r_in_x_en <= i_in_en ;
    if(i_in_en) begin
        r_in_iq <= i_in_iq ;
        if(r_in_iq_abs[(DI_BW*(1+1)-1)-:DI_BW]>=r_in_iq_abs[(DI_BW*(0+1)-1)-:DI_BW]) begin
            r_in_iq_x <=  r_in_iq_abs[(DI_BW*(1+1)-1)-:DI_BW] ;
            r_in_iq_sgn <= i_in_iq[DI_BW*(1+1)-1] ;
        end
        else begin
            r_in_iq_x <=  r_in_iq_abs[(DI_BW*(0+1)-1)-:DI_BW] ;
            r_in_iq_sgn <= i_in_iq[DI_BW*(0+1)-1] ;
        end
    end
end
always@(posedge i_clk) begin
    rr_x_en <= r_in_x_en ;
    if(r_in_x_en) begin
        rr_in_iq <= r_in_iq ;
        rr_x <= r_in_iq_x - r_in_iq_sgn ;
    end
end
always@(*) begin
    casex(rr_x[(DO_BW+1)-:BW_EXP+1]) 
        'b1xx   : rr_exp = {{BW_EXP}{1'b1}}&'d3 ;
        'b01x   : rr_exp = {{BW_EXP}{1'b1}}&'d2 ;
        'b001   : rr_exp = {{BW_EXP}{1'b1}}&'d1 ;
        default : rr_exp = {{BW_EXP}{1'b1}}&'d0 ;
    endcase
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   BW_EXP      )
 ,.IO_BW        (   DI_BW       ))
u00_shiftd_rnd 
(
     .i_clk     (   i_clk               )
    ,.i_in_en   (   rr_x_en             )
    ,.i_in      (   rr_in_iq            )
    ,.i_shiftd  (   rr_exp              )
    ,.o_out_en  (   w_in_en_rnd         )
    ,.o_out     (   w_in_iq_rnd         )
);
ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   DI_BW       )
 ,.DO_BW        (   DO_BW       ))
u01_sat
(
     .i_clk     (   i_clk               )
    ,.i_in_en   (   w_in_en_rnd         )
    ,.i_in      (   w_in_iq_rnd         )
    ,.o_out_en  (   o_out_en            )
    ,.o_out     (   o_out_iq            )
);
ylib_reg #(
     .WIDTH     (   BW_EXP      ) 
    ,.DEPTH     (   3           )) 
u02_exp_dly
(
     .i_clk      (  i_clk               )
    ,.i_in       (  rr_exp              )
    ,.o_out      (  o_out_exp           )
);
endmodule
