-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- ***************************************************************************** 
-- 
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part/H/W R&D Group
-- Author      : Kyoung Heo (k1340.heo@samsung.com)
-- 
-- *****************************************************************************
-- Function    : FFT_SAT_FUNC
-- Description : 1. Saturation library block 
-- *****************************************************************************
-- Revision History                                                           
-- *****************************************************************************
-- [2021.06.11, v1.00, k1340.heo] initial release for PKG SVR21D                                                    
-- *****************************************************************************

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_signed.all;

entity FFT_SAT_FUNC is
generic(
    SIGN_UNSIGN                 : string  := "S"; -- "S" : Signed, "U" : Unsigned
    INPUT_BIT                   : natural :=  18;
    OUTPUT_BIT                  : natural :=  16 
    );
port( 
    I_CLK                       : in  std_logic;
    I_DATA                      : in  std_logic_vector( INPUT_BIT-1 downto 0);
    O_DATA                      : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end FFT_SAT_FUNC;

architecture arc_FFT_SAT_FUNC of FFT_SAT_FUNC is

constant zeros                  : std_logic_vector(47 downto 0) := (others => '0');
constant ones                   : std_logic_vector(47 downto 0) := (others => '1');

constant up_sat                 : std_logic_vector( INPUT_BIT-1 downto OUTPUT_BIT) := zeros( INPUT_BIT-1 downto OUTPUT_BIT);
constant up_max                 : std_logic_vector(OUTPUT_BIT-1 downto 0) := ones(OUTPUT_BIT-1 downto 0);

constant sp_sat                 : std_logic_vector( INPUT_BIT-2 downto OUTPUT_BIT-1) := zeros( INPUT_BIT-2 downto OUTPUT_BIT-1);
constant sn_sat                 : std_logic_vector( INPUT_BIT-2 downto OUTPUT_BIT-1) := ones( INPUT_BIT-2 downto OUTPUT_BIT-1);

constant sp_max                 : std_logic_vector(OUTPUT_BIT-2 downto 0) := ones(OUTPUT_BIT-2 downto 0);
constant sn_max                 : std_logic_vector(OUTPUT_BIT-2 downto 0) := zeros(OUTPUT_BIT-2 downto 1) & '1';

constant sp_sat_out             : std_logic_vector(OUTPUT_BIT-1 downto 0) := '0' & sp_max;
constant sn_sat_out             : std_logic_vector(OUTPUT_BIT-1 downto 0) := '1' & sn_max;

signal u_sat_flag               : std_logic;

signal sp_sat_flag              : std_logic;
signal sn_sat_flag              : std_logic;
signal s_sat_flag               : std_logic_vector( 1 downto 0);

signal data_d1                  : std_logic_vector(OUTPUT_BIT-1 downto 0);
signal sat_out                  : std_logic_vector(OUTPUT_BIT-1 downto 0);

begin

    G_US_SAT : if (SIGN_UNSIGN = "U") generate begin
        -- 1st Clock
        P_US_SAT_Flag : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                if (I_DATA(INPUT_BIT-1 downto OUTPUT_BIT) = up_sat) then 
                    u_sat_flag <= '0';
                else
                    u_sat_flag <= '1';
                end if;
            end if;
        end process;
       
        P_US_Data_Clocking : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                data_d1 <= I_DATA(OUTPUT_BIT-1 downto 0);
            end if;
        end process;

        -- 2nd Clock
        P_US_SAT : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                if (u_sat_flag = '1') then
                    sat_out <= up_max;
                else
                    sat_out <= data_d1;
                end if;
            end if;
        end process;
    end generate;

    G_S_SAT : if (SIGN_UNSIGN = "S") generate begin
        -- 1st Clock
        P_S_SAT_Flag : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                if (I_DATA(INPUT_BIT-2 downto OUTPUT_BIT-1) = sp_sat) then 
                    sp_sat_flag <= '0';
                else
                    sp_sat_flag <= '0' nor I_DATA(INPUT_BIT-1);
                end if;

                if (I_DATA(INPUT_BIT-2 downto OUTPUT_BIT-1) = sn_sat) then 
                    if (I_DATA(OUTPUT_BIT-2 downto 0) = zeros(OUTPUT_BIT-2 downto 0)) then
                        sn_sat_flag <= '1'; 
                    else
                        sn_sat_flag <= '0'; 
                    end if;
                else
                    sn_sat_flag <= '1' and I_DATA(INPUT_BIT-1); 
                end if;
            end if;
        end process;

        s_sat_flag <= sn_sat_flag & sp_sat_flag;

        P_S_Data_Clocking : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                data_d1 <= I_DATA(INPUT_BIT-1) & I_DATA(OUTPUT_BIT-2 downto 0); 
            end if;
        end process;

        -- 2nd Clock
        P_U_SAT : process(I_CLK) begin
            if (I_CLK'event) and (I_CLK = '1') then
                case (s_sat_flag) is
                    when "01"   => sat_out <= sp_sat_out;
                    when "10"   => sat_out <= sn_sat_out;
                    when others => sat_out <= data_d1; 
                end case;
            end if;
        end process;
    end generate;

    O_DATA <= sat_out;

end arc_FFT_SAT_FUNC;
