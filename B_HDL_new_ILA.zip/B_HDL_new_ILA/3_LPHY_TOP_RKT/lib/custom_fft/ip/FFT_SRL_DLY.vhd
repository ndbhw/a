-- k1340.heo

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

library work;
use work.FFT_ARRAY_TYPE.all;
use work.FFT_FUNC.all;

entity FFT_SRL_DLY is
generic(
    DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    BIT_WIDTH                   : natural;
    DELAY_NUM                   : natural
    );
port(
    I_CLK                       : in  std_logic;
    I_DATA                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
    O_DATA                      : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end FFT_SRL_DLY;

architecture arc_FFT_SRL_DLY of FFT_SRL_DLY is

	constant srl_ctrl_dly0 : std_logic_vector(4 downto 0) := conv_std_logic_vector(DELAY_NUM-2, 5);

begin
        
    G_SRL16E_DLY : if ((DELAY_NUM < 17) and (DELAY_NUM > 1)) generate begin
    	G_SRL16E_GEN : for I in 0 to (BIT_WIDTH-1) generate begin
    	    SRL16E_inst : SRL16E
    	    generic map(
    	        -- INIT            => X"0000"       , -- Initial contents of shift register
    	        -- IS_CLK_INVERTED =>     '0'         -- Optional inversion for I_CLK
    	
    	        INIT            => X"0000"          -- Initial contents of shift register
    	        )
    	    port map(
    	        Q               => O_DATA(I), -- 1-bit output: SRL Data
    	        CE              => '1'            , -- 1-bit input: Clock enable
    	        CLK             => I_CLK          , -- 1-bit input: Clock
    	        D               => I_DATA(I)      , -- 1-bit input: SRL Data
    	        -- Depth Selection inputs: A0-A3 select SRL depth
    	        A0              => srl_ctrl_dly0(0),
    	        A1              => srl_ctrl_dly0(1),
    	        A2              => srl_ctrl_dly0(2),
    	        A3              => srl_ctrl_dly0(3) 
    	        );
    	    -- End of SRL16E_inst instantiation
    	end generate;
    end generate;

    G_SRLC32E_DLY : if ((DELAY_NUM > 16) and (DELAY_NUM < 33)) generate begin
    	G_SRLC32E_GEN : for I in 0 to (BIT_WIDTH-1) generate begin
    	    -- SRLC32E: 32-Bit Shift Register Look-Up Table (LUT)
    	    --          Kintex UltraScale+
    	    -- Xilinx HDL Language Template, version 2016.3
    	    SRLC32E_inst : SRLC32E
    	    generic map(
    	        -- INIT            => X"00000000"     , -- Initial contents of shift register
    	        -- IS_CLK_INVERTED =>         '0'       -- Optional inversion for I_CLK
    	
    	        INIT            => X"00000000"       -- Initial contents of shift register
    	        )
    	    port map (
    	        Q               => O_DATA(I) , -- 1-bit output: SRL Data
    	        Q31             => open, -- 1-bit output: SRL Cascade Data
    	        A               => srl_ctrl_dly0    , -- 5-bit input: Selects SRL depth
    	        CE              => '1'             , -- 1-bit input: Clock enable
    	        CLK             => I_CLK           , -- 1-bit input: Clock
    	        D               => I_DATA(I)         -- 1-bit input: SRL Data
    	        );
    	    -- End of SRLC32E_inst instantiation
    	end generate;
    end generate;
    
end arc_FFT_SRL_DLY;
