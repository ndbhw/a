Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library UNISIM;
use UNISIM.vcomponents.all;

Library work;
use work.FFT_ARRAY_TYPE.all;
use work.FFT_FUNC.all;

entity FFT_DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;
    DSP48_POSTADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    I_CLK                       : in  std_logic;

    I_ALUMODE                   : in  std_logic_vector(3 downto 0);
    I_OPMODE                    : in  std_logic_vector(8 downto 0);
    I_PREADDER_OP				: in  std_logic_vector(4 downto 0); -- "00101" - ADD, "01101" - SUB, "00001" - A1, "0011X" - D 

    I_C                         : in  std_logic_vector(47 downto 0); -- RND Value
    I_A                         : in  std_logic_vector(29 downto 0);
    I_D                         : in  std_logic_vector(26 downto 0);
    I_B                         : in  std_logic_vector(17 downto 0);

    I_P_C                       : in  std_logic_vector(47 downto 0);
    O_P_C                       : out std_logic_vector(47 downto 0);

    O_P                         : out std_logic_vector(47 downto 0);
    O_CRRY                      : out std_logic
    );
end FFT_DSP48E_MULT;

architecture arc_FFT_DSP48E_MULT of FFT_DSP48E_MULT is

constant zeros                  : std_logic_vector(47 downto 0) := (others => '0');

constant DSP48E2_AMULTSEL       : string                        := ternary_func(DSP48_PREADDER_USE  = TRUE , "AD"       , "A"        );
constant DSP48E_CREG            : integer                       := ternary_func(C_EN                = TRUE , 1          , 0          ); 
constant DSP48E_DREG            : integer                       := ternary_func(DSP48_PREADDER_USE  = TRUE , 1          , 0          ); 
constant DSP48E_CEC             : std_logic                     := ternary_func(C_EN                = TRUE , '1'        , '0'        ); 
constant DSP48E_CEAD            : std_logic                     := ternary_func(DSP48_PREADDER_USE  = TRUE , '1'        , '0'        ); 
constant DSP48E_CED             : std_logic                     := ternary_func(DSP48_PREADDER_USE  = TRUE , '1'        , '0'        ); 
constant DSP48E_ALUMODE         : std_logic_vector( 3 downto 0) := ternary_func(DSP48_POSTADDER_MODE = "ADD", "0000"    , "0011"    );
constant DSP48E_OPMODE_RND      : std_logic_vector( 8 downto 0) := ternary_func(C_EN                = TRUE , "000110101", "000000101");
constant DSP48E_OPMODE_PCIN     : std_logic_vector( 8 downto 0) := ternary_func(DSP48_PCIN_USE      = TRUE , "000010101", "000000101");
constant DSP48E_OPMODE          : std_logic_vector( 8 downto 0) := ternary_func(C_EN                = TRUE , DSP48E_OPMODE_RND, DSP48E_OPMODE_PCIN);
constant DSP48E_CARRYINSEL      : std_logic_vector( 2 downto 0) := ternary_func(RND_SYMMETRY        = TRUE , "110"      , "000"      );

signal alumode                  : std_logic_vector( 3 downto 0);
signal opmode                   : std_logic_vector( 8 downto 0);

signal pcin                     : std_logic_vector(47 downto 0);
signal pcout                    : std_logic_vector(47 downto 0);
signal pout                     : std_logic_vector(47 downto 0);
signal carryout                 : std_logic_vector( 3 downto 0);

attribute DONT_TOUCH : string;
-- attribute DONT_TOUCH of DSP48E_inst : label is "TRUE";
attribute DONT_TOUCH of G_DSP48E1 : label is ternary_func(DEVICE = "7SERISE"   , "TRUE", "FALSE");
attribute DONT_TOUCH of G_DSP48E2 : label is ternary_func(DEVICE = "ULTRASCALE", "TRUE", "FALSE");

begin

    -- DSP48 Mode Control 
    G_DSP48_MODE_CTRL : if (DSP48_MODECTRL = TRUE) generate begin         
        alumode <= I_ALUMODE;
        opmode  <= I_OPMODE; 
    end generate;

    G_DSP48_MODE_FIX : if (DSP48_MODECTRL = FALSE) generate begin         
        alumode <= DSP48E_ALUMODE;
        opmode  <= DSP48E_OPMODE ; 
    end generate;

    -- Result Chain In/Output
    G_PCIN_Use : if (DSP48_PCIN_USE = TRUE) generate begin 
        pcin <= I_P_C;
    end generate;

    G_PCIN_Unuse : if (DSP48_PCIN_USE = FALSE) generate begin 
        pcin <= (others => '0');
    end generate;

    G_PCOUT_Use : if (DSP48_PCOUT_USE = TRUE) generate begin 
        O_P_C <= pcout;
        O_P   <= pout;
    end generate;

    G_PCOUT_Unuse : if (DSP48_PCOUT_USE = FALSE) generate begin 
        O_P_C <= (others => '0');
        O_P   <= pout;
    end generate;

    -- Multiplier
    G_DSP48E1 : if (DEVICE = "7SERIES") generate begin
        DSP48E_inst : DSP48E1
        generic map (
            -- Feature Control Attributes: Data Path Selection
            A_INPUT                  => "DIRECT"                            , -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
            B_INPUT                  => "DIRECT"                            , -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
            USE_DPORT                => DSP48_PREADDER_USE                  , -- Select D port usage (TRUE or FALSE)
            USE_MULT                 => "MULTIPLY"                          , -- Select multiplier usage ("MULTIPLY", "DYNAMIC", or "NONE")
            USE_SIMD                 => "ONE48"                             , -- SIMD selection ("ONE48", "TWO24", "FOUR12")
            -- Pattern Detector Attributes: Pattern Detection Configuration
            AUTORESET_PATDET         => "NO_RESET"                          , -- "NO_RESET", "RESET_MATCH", "RESET_NOT_MATCH" 
            MASK                     => X"3fffffffffff"                     , -- 48-bit mask value for pattern detect (1=ignore)
            PATTERN                  => X"000000000000"                     , -- 48-bit pattern match for pattern detect
            SEL_MASK                 => "MASK"                              , -- "C", "MASK", "ROUNDING_MODE1", "ROUNDING_MODE2" 
            SEL_PATTERN              => "PATTERN"                           , -- Select pattern value ("PATTERN" or "C")
            USE_PATTERN_DETECT       => "NO_PATDET"                         , -- Enable pattern detect ("PATDET" or "NO_PATDET")
            -- Register Control Attributes: Pipeline Register Configuration
            ACASCREG                 => A_nREG                              , -- Number of pipeline stages between A/ACIN and ACOUT (0, 1 or 2)
            ADREG                    => 1                                   , -- Number of pipeline stages for pre-adder (0 or 1)
            ALUMODEREG               => 1                                   , -- Number of pipeline stages for ALUMODE (0 or 1)
            AREG                     => A_nREG                              , -- Number of pipeline stages for A (0, 1 or 2)
            BCASCREG                 => B_nREG                              , -- Number of pipeline stages between B/BCIN and BCOUT (0, 1 or 2)
            BREG                     => B_nREG                              , -- Number of pipeline stages for B (0, 1 or 2)
            CARRYINREG               => 0                                   , -- Number of pipeline stages for CARRYIN (0 or 1)
            CARRYINSELREG            => 0                                   , -- Number of pipeline stages for CARRYINSEL (0 or 1)
            CREG                     => DSP48E_CREG                         , -- Number of pipeline stages for C (0 or 1)
            DREG                     => DSP48E_DREG                         , -- Number of pipeline stages for D (0 or 1)
            INMODEREG                => 1                                   , -- Number of pipeline stages for INMODE (0 or 1)
            MREG                     => 1                                   , -- Number of multiplier pipeline stages (0 or 1)
            OPMODEREG                => 1                                   , -- Number of pipeline stages for OPMODE (0 or 1)
            PREG                     => 1                                     -- Number of pipeline stages for P (0 or 1)
            )
        port map (
            -- Cascade: 30-bit (each) output: Cascade Ports
            ACOUT                    => open                                , -- 30-bit output: A port cascade output
            BCOUT                    => open                                , -- 18-bit output: B port cascade output
            CARRYCASCOUT             => open                                , -- 1-bit output: Cascade carry output
            MULTSIGNOUT              => open                                , -- 1-bit output: Multiplier sign cascade output
            PCOUT                    => pcout                               , -- 48-bit output: Cascade output

            -- Control: 1-bit (each) output: Control Inputs/Status Bits
            OVERFLOW                 => open                                , -- 1-bit output: Overflow in add/acc output
            PATTERNBDETECT           => open                                , -- 1-bit output: Pattern bar detect output
            PATTERNDETECT            => open                                , -- 1-bit output: Pattern detect output
            UNDERFLOW                => open                                , -- 1-bit output: Underflow in add/acc output

            -- Data: 4-bit (each) output: Data Ports
            CARRYOUT                 => carryout                            , -- 4-bit output: Carry output
            P                        => pout                                , -- 48-bit output: Primary data output

            -- Cascade: 30-bit (each) input: Cascade Ports
            ACIN                     => (others => '0')                     , -- 30-bit input: A cascade data input
            BCIN                     => (others => '0')                     , -- 18-bit input: B cascade input
            CARRYCASCIN              => '0'                                 , -- 1-bit input: Cascade carry input
            MULTSIGNIN               => '0'                                 , -- 1-bit input: Multiplier sign input
            PCIN                     => (others => '0')                     , -- 48-bit input: P cascade input
	    
            -- Control: 4-bit (each) input: Control Inputs/Status Bits
            ALUMODE                  => alumode                             , -- 4-bit input: ALU control input
            CARRYINSEL               => DSP48E_CARRYINSEL                   , -- 3-bit input: Carry select input
            CLK                      => I_CLK                               , -- 1-bit input: Clock input
            INMODE                   => I_PREADDER_OP                       , -- 5-bit input: INMODE control input
            OPMODE                   => opmode(6 downto 0)                  , -- 7-bit input: Operation mode input

            -- Data: 30-bit (each) input: Data Ports
            A                        => I_A                                 , -- 30-bit input: A data input
            B                        => I_B                                 , -- 18-bit input: B data input
            C                        => I_C                                 , -- 48-bit input: C data input
            CARRYIN                  => '0'                                 , -- 1-bit input: Carry input signal
            D                        => I_D(24 downto 0)                   , -- 25-bit input: D data input

            -- Reset/Clock Enable: 1-bit (each) input: Reset/Clock Enable Inputs
            CEA1                     => '1'                                 , -- 1-bit input: Clock enable input for 1st stage AREG
            CEA2                     => '1'                                 , -- 1-bit input: Clock enable input for 2nd stage AREG
            CEAD                     => DSP48E_CEAD                         , -- 1-bit input: Clock enable input for ADREG
            CEALUMODE                => '1'                                 , -- 1-bit input: Clock enable input for ALUMODE
            CEB1                     => '1'                                 , -- 1-bit input: Clock enable input for 1st stage BREG
            CEB2                     => '1'                                 , -- 1-bit input: Clock enable input for 2nd stage BREG
            CEC                      => DSP48E_CEC                          , -- 1-bit input: Clock enable input for CREG
            CECARRYIN                => '0'                                 , -- 1-bit input: Clock enable input for CARRYINREG
            CECTRL                   => '1'                                 , -- 1-bit input: Clock enable input for OPMODEREG and CARRYINSELREG
            CED                      => DSP48E_CED                          , -- 1-bit input: Clock enable input for DREG
            CEINMODE                 => '1'                                 , -- 1-bit input: Clock enable input for INMODEREG
            CEM                      => '1'                                 , -- 1-bit input: Clock enable input for MREG
            CEP                      => '1'                                 , -- 1-bit input: Clock enable input for PREG
            RSTA                     => '0'                                 , -- 1-bit input: Reset input for AREG
            RSTALLCARRYIN            => '0'                                 , -- 1-bit input: Reset input for CARRYINREG
            RSTALUMODE               => '0'                                 , -- 1-bit input: Reset input for ALUMODEREG
           	RSTB                     => '0'                                 , -- 1-bit input: Reset input for BREG
            RSTC                     => '0'                                 , -- 1-bit input: Reset input for CREG
            RSTCTRL                  => '0'                                 , -- 1-bit input: Reset input for OPMODEREG and CARRYINSELREG
            RSTD                     => '0'                                 , -- 1-bit input: Reset input for DREG and ADREG
            RSTINMODE                => '0'                                 , -- 1-bit input: Reset input for INMODEREG
            RSTM                     => '0'                                 , -- 1-bit input: Reset input for MREG
            RSTP                     => '0'                                   -- 1-bit input: Reset input for PREG
            );
    end generate;

    G_DSP48E2 : if (DEVICE = "ULTRASCALE") generate begin
        DSP48E_inst : DSP48E2
        generic map (
           -- Feature Control Attributes: Data Path Selection
           AMULTSEL                  => DSP48E2_AMULTSEL                    , -- Selects A input to multiplier (A, AD)
           A_INPUT                   => "DIRECT"                            , -- Selects A input source, "DIRECT" (A port) or "CASCADE" (ACIN port)
           BMULTSEL                  => "B"                                 , -- Selects B input to multiplier (AD, B)
           B_INPUT                   => "DIRECT"                            , -- Selects B input source, "DIRECT" (B port) or "CASCADE" (BCIN port)
           PREADDINSEL               => "A"                                 , -- Selects input to pre-adder (A, B)
           RND                       => X"000000000000"                     , -- Rounding Constant
           USE_MULT                  => "MULTIPLY"                          , -- Select multiplier usage (DYNAMIC, MULTIPLY, NONE)
           USE_SIMD                  => "ONE48"                             , -- SIMD selection (FOUR12, ONE48, TWO24)
           USE_WIDEXOR               => "FALSE"                             , -- Use the Wide XOR function (FALSE, TRUE)
           XORSIMD                   => "XOR24_48_96"                       , -- Mode of operation for the Wide XOR (XOR12, XOR24_48_96)
           -- Pattern Detector Attributes: Pattern Detection Configuration
           AUTORESET_PATDET          => "NO_RESET"                          , -- NO_RESET, RESET_MATCH, RESET_NOT_MATCH
           AUTORESET_PRIORITY        => "RESET"                             , -- Priority of AUTORESET vs. CEP (CEP, RESET).
           MASK                      => X"3fffffffffff"                     , -- 48-bit mask value for pattern detect (1=ignore)
           PATTERN                   => X"000000000000"                     , -- 48-bit pattern match for pattern detect
           SEL_MASK                  => "MASK"                              , -- C, MASK, ROUNDING_MODE1, ROUNDING_MODE2
           SEL_PATTERN               => "PATTERN"                           , -- Select pattern value (C, PATTERN)
           USE_PATTERN_DETECT        => "NO_PATDET"                         , -- Enable pattern detect (NO_PATDET, PATDET)
           -- Programmable Inversion Attributes: Specifies built-in programmable inversion on specific pins
           IS_ALUMODE_INVERTED       => "0000"                              , -- Optional inversion for ALUMODE
           IS_CARRYIN_INVERTED       => '0'                                 , -- Optional inversion for CARRYIN
           IS_CLK_INVERTED           => '0'                                 , -- Optional inversion for I_CLK
           IS_INMODE_INVERTED        => "00000"                             , -- Optional inversion for INMODE
           IS_OPMODE_INVERTED        => "000000000"                         , -- Optional inversion for OPMODE
           IS_RSTALLCARRYIN_INVERTED => '0'                                 , -- Optional inversion for RSTALLCARRYIN
           IS_RSTALUMODE_INVERTED    => '0'                                 , -- Optional inversion for RSTALUMODE
           IS_RSTA_INVERTED          => '0'                                 , -- Optional inversion for RSTA
           IS_RSTB_INVERTED          => '0'                                 , -- Optional inversion for I_RSTB
           IS_RSTCTRL_INVERTED       => '0'                                 , -- Optional inversion for RSTCTRL
           IS_RSTC_INVERTED          => '0'                                 , -- Optional inversion for RSTC
           IS_RSTD_INVERTED          => '0'                                 , -- Optional inversion for RSTD
           IS_RSTINMODE_INVERTED     => '0'                                 , -- Optional inversion for RSTINMODE
           IS_RSTM_INVERTED          => '0'                                 , -- Optional inversion for RSTM
           IS_RSTP_INVERTED          => '0'                                 , -- Optional inversion for RSTP
           -- Register Control Attributes: Pipeline Register Configuration
           ACASCREG                  => A_nREG                              , -- Number of pipeline stages between A/ACIN and ACOUT (0-2)
           ADREG                     => 1                                   , -- Pipeline stages for pre-adder (0-1)
           ALUMODEREG                => 1                                   , -- Pipeline stages for ALUMODE (0-1)
           AREG                      => A_nREG                              , -- Pipeline stages for A (0-2)
           BCASCREG                  => B_nREG                              , -- Number of pipeline stages between B/BCIN and BCOUT (0-2)
           BREG                      => B_nREG                              , -- Pipeline stages for B (0-2)
           CARRYINREG                => 0                                   , -- Pipeline stages for CARRYIN (0-1)
           CARRYINSELREG             => 0                                   , -- Pipeline stages for CARRYINSEL (0-1)
           CREG                      => DSP48E_CREG                         , -- Pipeline stages for C (0-1)
           DREG                      => DSP48E_DREG                         , -- Pipeline stages for D (0-1)
           INMODEREG                 => 1                                   , -- Pipeline stages for INMODE (0-1)
           MREG                      => 1                                   , -- Multiplier pipeline stages (0-1)
           OPMODEREG                 => 1                                   , -- Pipeline stages for OPMODE (0-1)
           PREG                      => 1                                     -- Number of pipeline stages for P (0-1)
           )
        port map (
            -- Cascade outputs: Cascade Ports
            ACOUT                    => open                                , -- 30-bit output: A port cascade
            BCOUT                    => open                                , -- 18-bit output: B cascade
            CARRYCASCOUT             => open                                , -- 1-bit output: Cascade carry
            MULTSIGNOUT              => open                                , -- 1-bit output: Multiplier sign cascade
            PCOUT                    => pcout                               , -- 48-bit output: Cascade output
            -- Control outputs: Control Inputs/Status Bits
            OVERFLOW                 => open                                , -- 1-bit output: Overflow in add/acc
            PATTERNBDETECT           => open                                , -- 1-bit output: Pattern bar detect
            PATTERNDETECT            => open                                , -- 1-bit output: Pattern detect
            UNDERFLOW                => open                                , -- 1-bit output: Underflow in add/acc
            -- Data outputs: Data Ports
            CARRYOUT                 => carryout                            , -- 4-bit output: Carry
            P                        => pout                                , -- 48-bit output: Primary data
            XOROUT                   => open                                , -- 8-bit output: XOR data
            -- Cascade inputs: Cascade Ports
            ACIN                     => (others => '0')                     , -- 30-bit input: A cascade data
            BCIN                     => (others => '0')                     , -- 18-bit input: B cascade
            CARRYCASCIN              => '0'                                 , -- 1-bit input: Cascade carry
            MULTSIGNIN               => '0'                                 , -- 1-bit input: Multiplier sign cascade
            PCIN                     => pcin                                , -- 48-bit input: P cascade
            -- Control inputs: Control Inputs/Status Bits
            ALUMODE                  => alumode                             , -- 4-bit input: ALU control
            CARRYINSEL               => DSP48E_CARRYINSEL                   , -- 3-bit input: Carry select
            CLK                      => I_CLK                               , -- 1-bit input: Clock
            INMODE                   => I_PREADDER_OP                       , -- 5-bit input: INMODE control
            OPMODE                   => opmode                              , -- 9-bit input: Operation mode
            -- Data inputs: Data Ports
            A                        => I_A                                 , -- 30-bit input: A data
            B                        => I_B                                 , -- 18-bit input: B data
            C                        => I_C                                 , -- 48-bit input: C data
            CARRYIN                  => '0'                                 , -- 1-bit input: Carry-in
            D                        => I_D                                 , -- 27-bit input: D data
            -- Reset/Clock Enable inputs: Reset/Clock Enable Inputs
            CEA1                     => '1'                                 , -- 1-bit input: Clock enable for 1st stage AREG
            CEA2                     => '1'                                 , -- 1-bit input: Clock enable for 2nd stage AREG
            CEAD                     => DSP48E_CEAD                         , -- 1-bit input: Clock enable for ADREG
            CEALUMODE                => '1'                                 , -- 1-bit input: Clock enable for ALUMODE
            CEB1                     => '1'                                 , -- 1-bit input: Clock enable for 1st stage BREG
            CEB2                     => '1'                                 , -- 1-bit input: Clock enable for 2nd stage BREG
            CEC                      => DSP48E_CEC                          , -- 1-bit input: Clock enable for CREG
            CECARRYIN                => '0'                                 , -- 1-bit input: Clock enable for CARRYINREG
            CECTRL                   => '1'                                 , -- 1-bit input: Clock enable for OPMODEREG and CARRYINSELREG
            CED                      => DSP48E_CED                          , -- 1-bit input: Clock enable for DREG
            CEINMODE                 => '1'                                 , -- 1-bit input: Clock enable for INMODEREG
            CEM                      => '1'                                 , -- 1-bit input: Clock enable for MREG
            CEP                      => '1'                                 , -- 1-bit input: Clock enable for PREG
            RSTA                     => '0'                                 , -- 1-bit input: Reset for AREG
            RSTALLCARRYIN            => '0'                                 , -- 1-bit input: Reset for CARRYINREG
            RSTALUMODE               => '0'                                 , -- 1-bit input: Reset for ALUMODEREG
            RSTB                     => '0'                                 , -- 1-bit input: Reset for BREG
            RSTC                     => '0'                                 , -- 1-bit input: Reset for CREG
            RSTCTRL                  => '0'                                 , -- 1-bit input: Reset for OPMODEREG and CARRYINSELREG
            RSTD                     => '0'                                 , -- 1-bit input: Reset for DREG and ADREG
            RSTINMODE                => '0'                                 , -- 1-bit input: Reset for INMODEREG
            RSTM                     => '0'                                 , -- ternary_func(HS_MODE=FALSE, RST, '0')             , -- 1-bit input: Reset for MREG
            RSTP                     => '0'                                   -- ternary_func(HS_MODE=FALSE, RST, '0')               -- 1-bit input: Reset for PREG
            );
    
    end generate;

    O_CRRY <= carryout(3);

end arc_FFT_DSP48E_MULT;
