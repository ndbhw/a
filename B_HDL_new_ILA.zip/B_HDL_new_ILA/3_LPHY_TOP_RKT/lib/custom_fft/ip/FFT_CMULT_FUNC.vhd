-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************
--
-- ***************************************************************************** 
-- 
-- Copyright (C) 2021, Samsung Electronics Co., LTD. All Right Reserved.
--
-- Department  : FPGA Part/H/W R&D Group
-- Author      : Kyoung Heo (k1340.heo@samsung.com)
-- 
-- *****************************************************************************
-- Function    : FFT_CMULT_FUNC
-- Description : 1. Complex multiplication library block using DSP48E primitive 
-- *****************************************************************************
-- Revision History                                                           
-- *****************************************************************************
-- [2021.06.11, v1.00, k1340.heo ] initial release for PKG SVR21D                    
-- [2022.02.10, v2.00, jihoon.han] FFT/iFFT Commpon IP implementation                                
-- *****************************************************************************

Library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;

Library work;
use work.FFT_ARRAY_TYPE.all;
use work.FFT_FUNC.all;

entity FFT_CMULT_FUNC is
generic(
    DEVICE                      : string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
    N_DSP48               		: natural := 			3; 	-- 3 or 4
    RND_EN                      : boolean :=        TRUE ;
    SAT_BIT                     : natural :=          15 ;
    RND_BIT                     : natural :=          15 ;
    IN_A_BITWIDTH               : natural :=          16 ; -- MAX 26
    IN_B_BITWIDTH               : natural :=          16 ; -- MAX 17
    OUT_BITWIDTH                : natural :=          16
    );
port(
    I_CLK                       : in  std_logic;
    
    I_ADATA_I                   : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);
    I_ADATA_Q                   : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);

    I_BDATA_I                   : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);
    I_BDATA_Q                   : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);

    O_DATA_I                    : out std_logic_vector(OUT_BITWIDTH-1 downto 0);
    O_DATA_Q                    : out std_logic_vector(OUT_BITWIDTH-1 downto 0)
    );
end FFT_CMULT_FUNC;

architecture arc_FFT_CMULT_FUNC of FFT_CMULT_FUNC is

component FFT_DSP48E_MULT is
generic(
    DEVICE                      : string  := "ULTRASCALE";
    DSP48_MODECTRL              : boolean :=       FALSE ;
    DSP48_PREADDER_USE          : boolean :=        TRUE ;
    DSP48_PCIN_USE              : boolean :=       FALSE ;
    DSP48_PCOUT_USE             : boolean :=       FALSE ;
    DSP48_POSTADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 

    A_nREG                      : integer :=           2 ; -- 0, 1, 2
    B_nREG                      : integer :=           2 ; -- 0, 1, 2

    C_EN                        : boolean :=        TRUE ; -- RND ENable
    RND_SYMMETRY                : boolean :=       FALSE 
    );
port(
    I_CLK                       : in  std_logic;

    I_ALUMODE                   : in  std_logic_vector(3 downto 0);
    I_OPMODE                    : in  std_logic_vector(8 downto 0);
    I_PREADDER_OP				: in  std_logic_vector(4 downto 0); -- "00101" - ADD, "01101" - SUB, "00001" - A1, "0011X" - D 

    I_C                         : in  std_logic_vector(47 downto 0); -- RND Value
    I_A                         : in  std_logic_vector(29 downto 0);
    I_D                         : in  std_logic_vector(26 downto 0);
    I_B                         : in  std_logic_vector(17 downto 0);

    I_P_C                       : in  std_logic_vector(47 downto 0);
    O_P_C                       : out std_logic_vector(47 downto 0);

    O_P                         : out std_logic_vector(47 downto 0);
    O_CRRY                      : out std_logic
    );
end component;
    
component FFT_SAT_FUNC is
generic(
    SIGN_UNSIGN                 : string  := "S"; -- "S" : Signed, "U" : Unsigned
    INPUT_BIT                   : natural :=  18;
    OUTPUT_BIT                  : natural :=  16 
    );
port(
    I_CLK                       : in  std_logic;
    I_DATA                      : in  std_logic_vector( INPUT_BIT-1 downto 0);
    O_DATA                      : out std_logic_vector(OUTPUT_BIT-1 downto 0)
    );
end component;

constant zeros                  : std_logic_vector(47 downto 0) := (others => '0');
constant PREADDER_ADD			: std_logic_vector(4 downto 0) := "00101";
constant PREADDER_SUB			: std_logic_vector(4 downto 0) := "01101";
constant PREADDER_A1			: std_logic_vector(4 downto 0) := "00001";
constant PREADDER_D				: std_logic_vector(4 downto 0) := "00110";
constant PREADDER_NULL			: std_logic_vector(4 downto 0) := "00000";
		
signal rnd_qpoint               : std_logic_vector(47 downto 0);
signal se30_a_i                 : std_logic_vector(29 downto 0) := (others => '0');
signal se30_a_q                 : std_logic_vector(29 downto 0) := (others => '0');
signal se27_a_q                 : std_logic_vector(26 downto 0) := (others => '0');

signal se18_b_i                 : std_logic_vector(17 downto 0) := (others => '0');
signal se18_b_q                 : std_logic_vector(17 downto 0) := (others => '0');
signal tmp_se18_b_i_q			: std_logic_vector(IN_B_BITWIDTH downto 0) := (others => '0');
signal se18_b_i_q				: std_logic_vector(17 downto 0) := (others => '0');

signal pout_p					: std_logic_vector(47 downto 0) := (others => '0');
signal pout_p_d					: std_logic_vector((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) := (others => '0');

signal cascade_p				: std_logic_vector(47 downto 0) := (others => '0');
signal pout_m					: std_logic_vector(47 downto 0) := (others => '0');
signal pout_n					: std_logic_vector(47 downto 0) := (others => '0');
signal pout_o					: std_logic_vector(47 downto 0) := (others => '0');

signal do_cmult_re              : std_logic_vector((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) := (others => '0');
signal do_cmult_re_d            : std_logic_vector((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) := (others => '0');
signal do_cmult_im              : std_logic_vector((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) := (others => '0');

signal do_rnd_re                : std_logic_vector((OUT_BITWIDTH+SAT_BIT-1) downto 0) := (others => '0');
signal do_rnd_im                : std_logic_vector((OUT_BITWIDTH+SAT_BIT-1) downto 0) := (others => '0');

signal tmp_o_data_q				: std_logic_vector(OUT_BITWIDTH-1 downto 0) := (others => '0');

begin
	
    -- ************************************************************************
    -- Complex Mult used by 3 DSP Slice
    -- ************************************************************************
    G_Qpoint : if (RND_EN = TRUE) generate begin
        G_RND_0bit : if (RND_BIT = 0) generate begin
            rnd_qpoint <= zeros;
        end generate;

        G_RND_1bit : if (RND_BIT = 1) generate begin
            rnd_qpoint <= zeros(47 downto RND_BIT) & '1';
        end generate;

        G_RND_Nbit : if (RND_BIT > 1) generate begin
            rnd_qpoint <= zeros(47 downto RND_BIT) & '1' & zeros(RND_BIT-2 downto 0);
        end generate;
    end generate;

    G_Zero_Qpoint : if (RND_EN = FALSE) generate begin
        rnd_qpoint <= zeros;
    end generate;
    
    G_CMULT_DSP3 : if (N_DSP48 = 3) generate begin
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
			tmp_se18_b_i_q(IN_B_BITWIDTH downto 0) <= (I_BDATA_I(IN_B_BITWIDTH-1) & I_BDATA_I) + (I_BDATA_Q(IN_B_BITWIDTH-1) & I_BDATA_Q);
		end if;
	end process;
    
	se18_b_i_q <= sign_extension(tmp_se18_b_i_q, 18);
	
	se30_a_i    <= sign_extension(I_ADATA_I, 30);
	se27_a_q	<= sign_extension(I_ADATA_Q, 27);
	se18_b_i    <= sign_extension(I_BDATA_I, 18);
	se18_b_q    <= sign_extension(I_BDATA_Q, 18);
    					
    -- ************************************************************************
    -- A = Ar*I + Aj*Q
    -- B = Br*I + Bj*Q
    -- A * B = (Ar*I + Aj*Q)*(Br*I + Bj*Q) 
    --             = (Ar*Br-Aj*Bj)*I + (Ar*Bj+Aj*Br)*Q
    --             = [Ar*(Br+Bj) - (Ar+Aj)*Bj]*I + [Ar*(Br+Bj) + (-Ar+Aj)Br)*Q
    --           P = Ar*(Br+Bj)
    --           M = (+Ar+Aj)*Bj
    --           N = (-Ar+Aj)*Br
    -- 
    --           I = P - M
    --           Q = P + N
    -- ************************************************************************
    U_MULT_P : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,FALSE,TRUE,"ADD",1,0,RND_EN,FALSE) 
    port map(I_CLK,x"0",(others=>'0'), PREADDER_NULL, rnd_qpoint, se30_a_i, (others => '0'),se18_b_i_q,(others=>'0'),cascade_p, pout_p, open);
    U_MULT_M : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,FALSE,FALSE,"ADD",2,2,FALSE ,FALSE) 
    port map(I_CLK,x"0",(others=>'0'), PREADDER_ADD, (others =>'0'), se30_a_i, se27_a_q, se18_b_q, (others=>'0'),open,pout_m,open);
    U_MULT_N : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,TRUE,FALSE,"ADD",2,2,FALSE ,FALSE) 
    port map(I_CLK,x"0",(others=>'0'), PREADDER_SUB, (others =>'0'), se30_a_i, se27_a_q,se18_b_i, cascade_p,open,pout_n,open);
	
    
    G_CMULT3_RND_ON : if (RND_EN = TRUE) generate begin
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
			pout_p_d <= pout_p((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0);
			do_cmult_re <= pout_p_d - pout_m((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0);
			do_cmult_re_d <= do_cmult_re - do_cmult_re(OUT_BITWIDTH+RND_BIT+SAT_BIT-1);
			do_cmult_im <= pout_n((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) - pout_n(OUT_BITWIDTH+RND_BIT+SAT_BIT-1);
		end if;
	end process;

    do_rnd_re <= do_cmult_re_d((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
    do_rnd_im <= do_cmult_im((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
    end generate;
    
    G_CMULT3_RND_OFF : if (RND_EN = FALSE) generate begin
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
			pout_p_d <= pout_p((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0);
			do_cmult_re <= pout_p_d - pout_m((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0);
		    do_rnd_re <= do_cmult_re((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
		    do_rnd_im <= pout_n((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
		end if;
	end process;    
    end generate;
    
    G_CMULT3_SAT_ON : if (SAT_BIT > 0) generate begin
    U_CMULT3_SAT_I : FFT_SAT_FUNC generic map("S",(OUT_BITWIDTH+SAT_BIT),(OUT_BITWIDTH)) port map(I_CLK, do_rnd_re, O_DATA_I);
    U_CMULT3_SAT_Q : FFT_SAT_FUNC generic map("S",(OUT_BITWIDTH+SAT_BIT),(OUT_BITWIDTH)) port map(I_CLK, do_rnd_im, tmp_o_data_q);
    
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
			O_DATA_Q <= tmp_o_data_q;
		end if;
	end process;
    end generate;
    
    G_CMULT3_SAT_OFF : if (SAT_BIT = 0) generate begin
    O_DATA_I <= do_rnd_re;		
    process( I_CLK )
	begin	
		if I_CLK'event and I_CLK = '1' then
			O_DATA_Q <= do_rnd_im;				
		end if;
	end process;
    end generate;
    end generate;
    
    -- ************************************************************************
    -- Complex Mult used by 4 DSP Slice
    -- ************************************************************************
	
    G_CMULT_DSP4 : if (N_DSP48 = 4) generate begin
    
	se30_a_i    <= sign_extension(I_ADATA_I, 30);
	se30_a_q    <= sign_extension(I_ADATA_Q, 30);
	se18_b_i    <= sign_extension(I_BDATA_I, 18);
	se18_b_q    <= sign_extension(I_BDATA_Q, 18);
    					
    -- ************************************************************************
    -- A = Ar*I + Aj*Q
    -- B = Br*I + Bj*Q
    -- A * B = (Ar*I + Aj*Q)*(Br*I + Bj*Q) 
    --       = (Ar*Br-Aj*Bj)*I + (Ar*Bj+Aj*Br)*Q
    --     P = Ar*Br
    --     M = Aj*Bj
    --     N = Ar*Bj
    --     O = Aj*Br
    -- 
    --      I = P - M
    --      Q = N + O
    -- ************************************************************************
    U_MULT_P : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,FALSE,TRUE,"ADD",1,1,RND_EN,FALSE) 
    port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL, rnd_qpoint, se30_a_i, (others => '0'), se18_b_i, (others => '0'), pout_p, open, open);
    U_MULT_M : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,TRUE,FALSE,"SUB",2,2,FALSE,FALSE) 
    port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL, (others =>'0'), se30_a_q, (others => '0'), se18_b_q, pout_p,open,pout_m,open);
    U_MULT_N : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,FALSE,TRUE,"ADD",1,1,RND_EN,FALSE) 
    port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL, rnd_qpoint, se30_a_i, (others => '0'), se18_b_q, (others => '0'), pout_n, open, open);
    U_MULT_O : FFT_DSP48E_MULT generic map(DEVICE,FALSE,FALSE,TRUE,FALSE,"ADD",2,2,FALSE,FALSE) 
    port map(I_CLK,x"0",(others=>'0'),PREADDER_NULL, (others =>'0'), se30_a_q, (others => '0'), se18_b_i, pout_n,open,pout_o,open);
	
   	G_CMULT4_RND_ON : if (RND_EN = TRUE) generate begin
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
			do_cmult_re <= pout_m((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) - pout_m(OUT_BITWIDTH+RND_BIT+SAT_BIT-1);
			do_cmult_im <= pout_o((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto 0) - pout_o(OUT_BITWIDTH+RND_BIT+SAT_BIT-1);
		end if;
	end process;

    do_rnd_re <= do_cmult_re((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
    do_rnd_im <= do_cmult_im((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
    end generate;
    
    G_CMULT4_RND_OFF : if (RND_EN = FALSE) generate begin
    process( I_CLK )
	begin								
		if I_CLK'event and I_CLK = '1' then
		    do_rnd_re <= pout_m((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
		    do_rnd_im <= pout_o((OUT_BITWIDTH+RND_BIT+SAT_BIT-1) downto RND_BIT);
		end if;
	end process;    
    end generate;
    
    G_CMULT4_SAT_ON : if (SAT_BIT > 0) generate begin
    U_CMULT4_SAT_I : FFT_SAT_FUNC generic map("S",(OUT_BITWIDTH+SAT_BIT),(OUT_BITWIDTH)) port map(I_CLK, do_rnd_re, O_DATA_I);
    U_CMULT4_SAT_Q : FFT_SAT_FUNC generic map("S",(OUT_BITWIDTH+SAT_BIT),(OUT_BITWIDTH)) port map(I_CLK, do_rnd_im, O_DATA_Q);	
    end generate;
    
    G_CMULT4_SAT_OFF : if (SAT_BIT = 0) generate begin
    O_DATA_I <= do_rnd_re;	
	O_DATA_Q <= do_rnd_im;		
    end generate;
    end generate;

end arc_FFT_CMULT_FUNC;
