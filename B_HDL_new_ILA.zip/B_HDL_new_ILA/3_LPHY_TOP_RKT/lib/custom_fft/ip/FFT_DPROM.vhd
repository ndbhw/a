library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.std_logic_arith.all;
use IEEE.numeric_std.all;
use IEEE.math_real.all;

library XPM;
use XPM.vcomponents.all;

entity FFT_DPROM is
generic(
    RAM_TYPE                    : string  := "block"       ; -- "auto" or "distributed" or "block" or "ultra" 
    CLOCKING_MODE               : string  := "common_clock"; -- "common_clock" or "independent_clock"
    OPERATING_MODE              : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"

    A_ADDR_DEPTH                : integer :=  1024         ;
    A_DATA_WIDTH                : integer :=     8         ;
    A_READ_LATENCY              : integer :=     2         ;

    B_ADDR_DEPTH                : integer :=  1024         ;
    B_DATA_WIDTH                : integer :=     8         ;
    B_READ_LATENCY              : integer :=     2         ;

    RAM_INIT_FILE               : string  := "none"        ; 
    RAM_INIT_VALUE              : string  := "0" 
    );
port(
    I_CLK_A                       : in  std_logic;
    I_EN_A                        : in  std_logic := '1';
    I_WE_A                        : in  std_logic := '1';
    I_ADDR_A                      : in  std_logic_vector(integer(floor(log2(real(A_ADDR_DEPTH-1)))) downto 0);
    I_DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);
    O_Q_A	                      : out std_logic_vector(A_DATA_WIDTH-1 downto 0);

    I_CLK_B                       : in  std_logic;
    I_EN_B                        : in  std_logic := '1';
    I_WE_B                        : in  std_logic := '1';
    I_ADDR_B                      : in  std_logic_vector(integer(floor(log2(real(B_ADDR_DEPTH-1)))) downto 0);
    I_DATA_B                      : in  std_logic_vector(B_DATA_WIDTH-1 downto 0);
    O_Q_B	                      : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
    );
end FFT_DPROM;

architecture arc_FFT_DPROM of FFT_DPROM is

constant A_ADDR_WIDTH           : integer   := integer(floor(log2(real(A_ADDR_DEPTH-1))))+1;
constant B_ADDR_WIDTH           : integer   := integer(floor(log2(real(B_ADDR_DEPTH-1))))+1;

constant MEMORY_SIZE            : integer   := A_DATA_WIDTH*A_ADDR_DEPTH;

constant INJECTDBITERRA         : std_logic := '0';
constant INJECTDBITERRB         : std_logic := '0';
constant INJECTSBITERRA         : std_logic := '0';
constant INJECTSBITERRB         : std_logic := '0';
constant REGCEA                 : std_logic := '1';
constant REGCEB                 : std_logic := '1';
constant RSTA                   : std_logic := '0';
constant I_RSTB                   : std_logic := '0';
constant SLEEP                  : std_logic := '0';

begin

	xpm_memory_dprom_inst : xpm_memory_dprom
   	generic map (        
		ADDR_WIDTH_A => A_ADDR_WIDTH,               -- DECIMAL
		ADDR_WIDTH_B => B_ADDR_WIDTH,               -- DECIMAL
		AUTO_SLEEP_TIME => 0,            -- DECIMAL
		CASCADE_HEIGHT => 0,             -- DECIMAL
		CLOCKING_MODE => "common_clock", -- String
		ECC_MODE => "no_ecc",            -- String
		MEMORY_INIT_FILE => RAM_INIT_FILE,      -- String
		MEMORY_INIT_PARAM => RAM_INIT_VALUE,        -- String
		MEMORY_OPTIMIZATION => "true",   -- String
		MEMORY_PRIMITIVE => RAM_TYPE,      -- String
		MEMORY_SIZE => MEMORY_SIZE,             -- DECIMAL
		MESSAGE_CONTROL => 0,            -- DECIMAL
		READ_DATA_WIDTH_A => A_DATA_WIDTH,         -- DECIMAL
		READ_DATA_WIDTH_B => B_DATA_WIDTH,         -- DECIMAL
		READ_LATENCY_A => A_READ_LATENCY,             -- DECIMAL
		READ_LATENCY_B => B_READ_LATENCY,             -- DECIMAL
		READ_RESET_VALUE_A => "0",       -- String
		READ_RESET_VALUE_B => "0",       -- String
		RST_MODE_A => "SYNC",            -- String
		RST_MODE_B => "SYNC",            -- String
		SIM_ASSERT_CHK => 0,             -- DECIMAL; 0=disable simulation messages, 1=enable simulation messages
		USE_MEM_INIT => 1,               -- DECIMAL
		WAKEUP_TIME => "disable_sleep"   -- String
   	)
   	port map (
      	dbiterra => open,             -- 1-bit output: Leave open.
      	dbiterrb => open,             -- 1-bit output: Leave open.
      	douta => O_Q_A,                   -- READ_DATA_WIDTH_A-bit output: Data output for port A read operations.
      	doutb => O_Q_B,                   -- READ_DATA_WIDTH_B-bit output: Data output for port B read operations.
      	sbiterra => open,             -- 1-bit output: Leave open.
      	sbiterrb => open,             -- 1-bit output: Leave open.
      	addra => I_ADDR_A,                   -- ADDR_WIDTH_A-bit input: Address for port A read operations.
      	addrb => I_ADDR_B,                   -- ADDR_WIDTH_B-bit input: Address for port B read operations.
      	clka => I_CLK_A,                     -- 1-bit input: Clock signal for port A. Also clocks port B when
      	                                  -- parameter CLOCKING_MODE is "common_clock".
      	
      	clkb => I_CLK_B,                     -- 1-bit input: Clock signal for port B when parameter CLOCKING_MODE is
      	                                  -- "independent_clock". Unused when parameter CLOCKING_MODE is
      	                                  -- "common_clock".
      	
      	ena => I_EN_A,                       -- 1-bit input: Memory enable signal for port A. Must be high on clock
      	                                  -- cycles when read operations are initiated. Pipelined internally.
      	
      	enb => I_EN_B,                       -- 1-bit input: Memory enable signal for port B. Must be high on clock
      	                                  -- cycles when read operations are initiated. Pipelined internally.
      	
      	injectdbiterra => INJECTDBITERRA, -- 1-bit input: Do not change from the provided value.
      	injectdbiterrb => INJECTDBITERRB, -- 1-bit input: Do not change from the provided value.
      	injectsbiterra => INJECTSBITERRA, -- 1-bit input: Do not change from the provided value.
      	injectsbiterrb => INJECTSBITERRB, -- 1-bit input: Do not change from the provided value.
      	regcea => REGCEA,                 -- 1-bit input: Do not change from the provided value.
      	regceb => REGCEB,                 -- 1-bit input: Do not change from the provided value.
      	rsta => RSTA,                     -- 1-bit input: Reset signal for the final port A output register
      	                                  -- stage. Synchronously resets output port douta to the value specified
      	                                  -- by parameter READ_RESET_VALUE_A.
      	
      	rstb => I_RSTB,                     -- 1-bit input: Reset signal for the final port B output register
      	                                  -- stage. Synchronously resets output port doutb to the value specified
      	                                  -- by parameter READ_RESET_VALUE_B.
      	
      	sleep => SLEEP                    -- 1-bit input: sleep signal to enable the dynamic power saving feature.
   	);
   


-- XPM_MEMORY instantiation template for Dual Port ROM configurations
-- Refer to the targeted device family architecture libraries guide for XPM_MEMORY documentation
-- =======================================================================================================================

-- Parameter usage table, organized as follows:
-- +---------------------------------------------------------------------------------------------------------------------+
-- | Parameter name       | Data type          | Restrictions, if applicable                                             |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Description                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- +---------------------------------------------------------------------------------------------------------------------+
-- | ADDR_WIDTH_A         | Integer            | Range: 1 - 20. Default value = 6.                                       |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the width of the port A address port addra, in bits.                                                        |
-- | Must be large enough to access the entire memory from port A, i.e. = $clog2(MEMORY_SIZE/READ_DATA_WIDTH_A).         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | ADDR_WIDTH_B         | Integer            | Range: 1 - 20. Default value = 6.                                       |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the width of the port B address port addrb, in bits.                                                        |
-- | Must be large enough to access the entire memory from port B, i.e. = $clog2(MEMORY_SIZE/READ_DATA_WIDTH_B).         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | AUTO_SLEEP_TIME      | Integer            | Range: 0 - 15. Default value = 0.                                       |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Must be set to 0                                                                                                    |
-- | 0 - Disable auto-sleep feature                                                                                      |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | CASCADE_HEIGHT       | Integer            | Range: 0 - 64. Default value = 0.                                       |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | 0- No Cascade Height, Allow Vivado Synthesis to choose.                                                             |
-- | 1 or more - Vivado Synthesis sets the specified value as Cascade Height.                                            |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | CLOCKING_MODE        | String             | Allowed values: common_clock, independent_clock. Default value = common_clock.|
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Designate whether port A and port B are clocked with a common clock or with independent clocks-                     |
-- | "common_clock"- Common clocking; clock both port A and port B with clka                                             |
-- | "independent_clock"- Independent clocking; clock port A with clka and port B with clkb                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | ECC_MODE             | String             | Allowed values: no_ecc, both_encode_and_decode, decode_only, encode_only. Default value = no_ecc.|
-- |---------------------------------------------------------------------------------------------------------------------|
-- |                                                                                                                     |
-- |   "no_ecc" - Disables ECC                                                                                           |
-- |   "encode_only" - Enables ECC Encoder only                                                                          |
-- |   "decode_only" - Enables ECC Decoder only                                                                          |
-- |   "both_encode_and_decode" - Enables both ECC Encoder and Decoder                                                   |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MEMORY_INIT_FILE     | String             | Default value = none.                                                   |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify "none" (including quotes) for no memory initialization, or specify the name of a memory initialization file-|
-- | Enter only the name of the file with .mem extension, including quotes but without path (e.g. "my_file.mem").        |
-- | File format must be ASCII and consist of only hexadecimal values organized into the specified depth by              |
-- | narrowest data width generic value of the memory. See the Memory File (MEM) section for more                        |
-- | information on the syntax. Initialization of memory happens through the file name specified only when parameter     |
-- | MEMORY_INIT_PARAM value is equal to "".                                                                           | |
-- | When using XPM_MEMORY in a project, add the specified file to the Vivado project as a design source.                |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MEMORY_INIT_PARAM    | String             | Default value = 0.                                                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify "" or "0" (including quotes) for no memory initialization through parameter, or specify the string          |
-- | containing the hex characters. Enter only hex characters with each location separated by delimiter (,).             |
-- | Parameter format must be ASCII and consist of only hexadecimal values organized into the specified depth by         |
-- | narrowest data width generic value of the memory.For example, if the narrowest data width is 8, and the depth of    |
-- | memory is 8 locations, then the parameter value should be passed as shown below.                                    |
-- | parameter MEMORY_INIT_PARAM = "AB,CD,EF,1,2,34,56,78"                                                               |
-- | Where "AB" is the 0th location and "78" is the 7th location.                                                        |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MEMORY_OPTIMIZATION  | String             | Allowed values: true, false. Default value = true.                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify "true" to enable the optimization of unused memory or bits in the memory structure. Specify "false" to      |
-- | disable the optimization of unused memory or bits in the memory structure.                                          |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MEMORY_PRIMITIVE     | String             | Allowed values: auto, block, distributed, ultra. Default value = auto.  |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Designate the memory primitive (resource type) to use-                                                              |
-- | "auto"- Allow Vivado Synthesis to choose                                                                            |
-- | "distributed"- Distributed memory                                                                                   |
-- | "block"- Block memory                                                                                               |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MEMORY_SIZE          | Integer            | Range: 2 - 150994944. Default value = 2048.                             |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the total memory array size, in bits.                                                                       |
-- | For example, enter 65536 for a 2kx32 ROM.                                                                           |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | MESSAGE_CONTROL      | Integer            | Range: 0 - 1. Default value = 0.                                        |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify 1 to enable the dynamic message reporting such as collision warnings, and 0 to disable the message reporting|
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_DATA_WIDTH_A    | Integer            | Range: 1 - 4608. Default value = 32.                                    |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the width of the port A read data output port douta, in bits.                                               |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_DATA_WIDTH_B    | Integer            | Range: 1 - 4608. Default value = 32.                                    |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the width of the port B read data output port doutb, in bits.                                               |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_LATENCY_A       | Integer            | Range: 0 - 100. Default value = 2.                                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the number of register stages in the port A read data pipeline. Read data output to port douta takes this   |
-- | number of clka cycles.                                                                                              |
-- | To target block memory, a value of 1 or larger is required- 1 causes use of memory latch only; 2 causes use of      |
-- | output register. To target distributed memory, a value of 0 or larger is required- 0 indicates combinatorial output.|
-- | Values larger than 2 synthesize additional flip-flops that are not retimed into memory primitives.                  |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_LATENCY_B       | Integer            | Range: 0 - 100. Default value = 2.                                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the number of register stages in the port B read data pipeline. Read data output to port doutb takes this   |
-- | number of clkb cycles (clka when CLOCKING_MODE is "common_clock").                                                  |
-- | To target block memory, a value of 1 or larger is required- 1 causes use of memory latch only; 2 causes use of      |
-- | output register. To target distributed memory, a value of 0 or larger is required- 0 indicates combinatorial output.|
-- | Values larger than 2 synthesize additional flip-flops that are not retimed into memory primitives.                  |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_RESET_VALUE_A   | String             | Default value = 0.                                                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the reset value of the port A final output register stage in response to rsta input port is assertion.      |
-- | For example, to reset the value of port douta to all 0s when READ_DATA_WIDTH_A is 32, specify 32HHHHh0.             |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | READ_RESET_VALUE_B   | String             | Default value = 0.                                                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify the reset value of the port B final output register stage in response to rstb input port is assertion.      |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | RST_MODE_A           | String             | Allowed values: SYNC, ASYNC. Default value = SYNC.                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Describes the behaviour of the reset                                                                                |
-- |                                                                                                                     |
-- |   "SYNC" - when reset is applied, synchronously resets output port douta to the value specified by parameter READ_RESET_VALUE_A|
-- |   "ASYNC" - when reset is applied, asynchronously resets output port douta to zero                                  |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | RST_MODE_B           | String             | Allowed values: SYNC, ASYNC. Default value = SYNC.                      |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Describes the behaviour of the reset                                                                                |
-- |                                                                                                                     |
-- |   "SYNC" - when reset is applied, synchronously resets output port doutb to the value specified by parameter READ_RESET_VALUE_B|
-- |   "ASYNC" - when reset is applied, asynchronously resets output port doutb to zero                                  |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | SIM_ASSERT_CHK       | Integer            | Range: 0 - 1. Default value = 0.                                        |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | 0- Disable simulation message reporting. Messages related to potential misuse will not be reported.                 |
-- | 1- Enable simulation message reporting. Messages related to potential misuse will be reported.                      |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | USE_MEM_INIT         | Integer            | Range: 0 - 1. Default value = 1.                                        |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify 1 to enable the generation of below message and 0 to disable generation of the following message completely.|
-- | "INFO - MEMORY_INIT_FILE and MEMORY_INIT_PARAM together specifies no memory initialization.                         |
-- | Initial memory contents will be all 0s."                                                                            |
-- | NOTE: This message gets generated only when there is no Memory Initialization specified either through file or      |
-- | Parameter.                                                                                                          |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | WAKEUP_TIME          | String             | Allowed values: disable_sleep, use_sleep_pin. Default value = disable_sleep.|
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Specify "disable_sleep" to disable dynamic power saving option, and specify "use_sleep_pin" to enable the           |
-- | dynamic power saving option                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+

-- Port usage table, organized as follows:
-- +---------------------------------------------------------------------------------------------------------------------+
-- | Port name      | Direction | Size, in bits                         | Domain  | Sense       | Handling if unused     |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Description                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- +---------------------------------------------------------------------------------------------------------------------+
-- | addra          | Input     | ADDR_WIDTH_A                          | clka    | NA          | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Address for port A read operations.                                                                                 |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | addrb          | Input     | ADDR_WIDTH_B                          | clkb    | NA          | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Address for port B read operations.                                                                                 |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | clka           | Input     | 1                                     | NA      | Rising edge | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Clock signal for port A. Also clocks port B when parameter CLOCKING_MODE is "common_clock".                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | clkb           | Input     | 1                                     | NA      | Rising edge | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Clock signal for port B when parameter CLOCKING_MODE is "independent_clock".                                        |
-- | Unused when parameter CLOCKING_MODE is "common_clock".                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | dbiterra       | Output    | 1                                     | clka    | Active-high | DoNotCare              |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Leave open.                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | dbiterrb       | Output    | 1                                     | clkb    | Active-high | DoNotCare              |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Leave open.                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | douta          | Output    | READ_DATA_WIDTH_A                     | clka    | NA          | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Data output for port A read operations.                                                                             |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | doutb          | Output    | READ_DATA_WIDTH_B                     | clkb    | NA          | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Data output for port B read operations.                                                                             |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | ena            | Input     | 1                                     | clka    | Active-high | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Memory enable signal for port A.                                                                                    |
-- | Must be high on clock cycles when read operations are initiated. Pipelined internally.                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | enb            | Input     | 1                                     | clkb    | Active-high | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Memory enable signal for port B.                                                                                    |
-- | Must be high on clock cycles when read operations are initiated. Pipelined internally.                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | injectdbiterra | Input     | 1                                     | clka    | Active-high | Tie to 1'b0            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | injectdbiterrb | Input     | 1                                     | clkb    | Active-high | Tie to 1'b0            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | injectsbiterra | Input     | 1                                     | clka    | Active-high | Tie to 1'b0            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | injectsbiterrb | Input     | 1                                     | clkb    | Active-high | Tie to 1'b0            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | regcea         | Input     | 1                                     | clka    | Active-high | Tie to 1'b1            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | regceb         | Input     | 1                                     | clkb    | Active-high | Tie to 1'b1            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Do not change from the provided value.                                                                              |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | rsta           | Input     | 1                                     | clka    | Active-high | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Reset signal for the final port A output register stage.                                                            |
-- | Synchronously resets output port douta to the value specified by parameter READ_RESET_VALUE_A.                      |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | rstb           | Input     | 1                                     | clkb    | Active-high | Required               |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Reset signal for the final port B output register stage.                                                            |
-- | Synchronously resets output port doutb to the value specified by parameter READ_RESET_VALUE_B.                      |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | sbiterra       | Output    | 1                                     | clka    | Active-high | DoNotCare              |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Leave open.                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | sbiterrb       | Output    | 1                                     | clkb    | Active-high | DoNotCare              |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | Leave open.                                                                                                         |
-- +---------------------------------------------------------------------------------------------------------------------+
-- | sleep          | Input     | 1                                     | NA      | Active-high | Tie to 1'b0            |
-- |---------------------------------------------------------------------------------------------------------------------|
-- | sleep signal to enable the dynamic power saving feature.                                                            |
-- +---------------------------------------------------------------------------------------------------------------------+


-- xpm_memory_dprom : In order to incorporate this function into the design,
--       VHDL       : the following instance declaration needs to be placed
--     instance     : in the body of the design code.  The instance name
--   declaration    : (xpm_memory_dprom_inst) and/or the port declarations after the
--       code       : "=>" declaration maybe changed to properly reference and
--                  : connect this function to the design.  All inputs and outputs
--                  : must be connected.

--     Library      : In addition to adding the instance declaration, a use
--   declaration    : statement for the UNISIM.vcomponents library needs to be
--       for        : added before the entity declaration.  This library
--      Xilinx      : contains the component declarations for all Xilinx
--    primitives    : primitives and points to the models that will be used
--                  : for simulation.

--  Please reference the appropriate libraries guide for additional information on the XPM modules.

--  Copy the following two statements and paste them before the
--  Entity declaration, unless they already exist.

end arc_FFT_DPROM;
