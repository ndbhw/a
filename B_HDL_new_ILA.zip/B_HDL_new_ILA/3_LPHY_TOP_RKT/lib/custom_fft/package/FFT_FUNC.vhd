--***************************************
-- multi-uni function library
--***************************************

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
use IEEE.numeric_std.all;

use WORK.FFT_ARRAY_TYPE.ALL;

package FFT_FUNC is
    
    type integer_array                          is array(natural range <>) of integer;
    type stm_mode_type                          is (stm1,stm4,stm16);
    type stm_mode_array                         is array(natural range <>) of stm_mode_type;
    type ser_par_type                           is (serial,parallel);
    type ser_par_array                          is array(natural range <>) of ser_par_type;
    type bits_bytes_type                        is (bits,bytes);
    type bits_bytes_array                       is array(natural range <>) of bits_bytes_type;
    type frm_det_stat_type                      is (oof_state, pre_state, inf_state, fail_stat);
    type frm_det_stat_array                     is array(natural range <>) of frm_det_stat_type;
    
    -- inserted by AYJ begin
    type stm_mode_type_array                    is array(natural range <>) of stm_mode_type;
    type ptr_state_type                         is (norm_state, ais_state,lop_state);
    type ptr_state_type_array                   is array(natural range <>) of ptr_state_type;
    type ptr_state_type_array3                  is array(natural range <>) of ptr_state_type_array(2 downto 0);
    type ptr_state_type_array12                 is array(natural range <>) of ptr_state_type_array(11 downto 0);
    
    type au_mode_type                           is (vc3, vc4, vc4_2c, vc4_3c, vc4_4c, vc4_16c);
    type au_mode_type_array                     is array(natural range <>) of au_mode_type;
    type au_mode_type_array12                   is array(natural range <>) of au_mode_type_array(11 downto 0);
    type ptr_move_type                          is (norm, inc, dec, jump);
    type ptr_move_type_array                    is array(natural range <>) of ptr_move_type;
    
    type cmd_type                               is (rd_cmd, wr_cmd, vf_cmd, null_cmd);
    type test_blk_type                          is (alls,soh,pipg,hpom,lvds1,lvds2,msp,hpc,s_pi);
    
    -- inserted by AYJ, end
    
    constant vcc       : std_logic := '1';
    constant gnd       : std_logic := '0';
    constant period    : time := 3200 ps;
    constant stm_mode  : stm_mode_type := stm1;
    constant stm4_type : ser_par_type  := serial;
    --constant stm_n_num : integer := 1;
    constant all1      : std_logic_vector(7 downto 0) := "11111111";
    constant all0      : std_logic_vector(7 downto 0) := "00000000";
    constant all0_64   : std_logic_vector(63 downto 0) := (others => '0');
    
    --function "and" (dia : std_logic_vector; dib : std_logic) return std_logic_vector;
    --function "or" (dia : std_logic_vector; dib : std_logic) return std_logic_vector;
    --function "xor" (dia : std_logic_vector; dib : std_logic) return std_logic_vector;
    
    function "AND" (L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR ;
    function "AND" (L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR ;
    function "OR"  (L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR ;
    function "OR"  (L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR ;
    function "XOR" (L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR ;
    function "XOR" (L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR ;
    
    function zeros(N : natural) return std_logic_vector;
    function ones(N : natural) return std_logic_vector;
    
    function log2 (data_value : integer)  return integer;
    function count_bits(world : std_logic_vector;size:natural) return std_logic_vector;
    
    function dataread ( d : std_logic_vector) return std_logic_vector;
    function dataread ( d : std_logic        ) return std_logic_vector;
    function dataread ( d : integer        ) return std_logic_vector;
    
    function selector(data,sel :std_logic_vector) return std_logic_vector;
    function saturate_frac(value:std_logic_vector) return std_logic_vector;
    function exptobit(fxp_iq:std_logic_vector) return std_logic_vector;
    function bittoexp(i_data,q_data:std_logic_vector) return std_logic_vector;
    
    function grp3 ( di : std_logic_vector ) return std_logic_array3;
    function flt3 ( bit_n : integer; di : std_logic_array8 ) return std_logic_vector;
    --------------------------------------------------------------------------------
    -------------------------------------------------------------------------------
    
    -- Function Declarations
    
    -------------------------------------------------------------------------------
    function abs_diff2_zero (dia : std_logic_vector; dib : std_logic_vector) return std_logic_vector;
    function abs_diff2 (dia : std_logic_vector; dib : std_logic_vector) return std_logic_vector;
    function abs_diff4 (dia : std_logic_vector; dib : std_logic_vector; dic : std_logic_vector; did : std_logic_vector) return std_logic_vector;
    function scr_x7_x6_1 (di : std_logic_vector) return std_logic_vector;
    function crc_x7_x3_1 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;
    function crc_x8_x2_x_1 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;
    function crc_x8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;
    function hec_k1 (di : std_logic_vector) return std_logic_vector;
    function hec_k2 (di : std_logic_vector) return std_logic_vector;
    function hec_k3 (di : std_logic_vector) return std_logic_vector;
    function hec_k4 (di : std_logic_vector) return std_logic_vector;
    --crc16 = x16_x12_x5_1
    function crc16 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;
    function hec_g1 (di : std_logic_vector) return std_logic_vector;
    function crc32 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector;

    function crc_4_12 (D : std_logic_vector; X : std_logic_vector) return std_logic_vector;
    
    --function to_next (signal clk: std_logic; cnt: integer) return boolean ;
    function med3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector;
    function max3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector;
    function min3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector;
    function sign_add2 (d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector;
    --function sign_add2_(d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector;
    --function sign_sub2 (d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector;
    --function sign_sub2_(d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector;
    
    function sum_with_sat ( a : std_logic_vector; b : std_logic_vector; width : natural) return std_logic_vector;
    function sub_with_sat ( a : std_logic_vector; b : std_logic_vector; width : natural) return std_logic_vector;
    function right19_shifter(IQdata:std_logic_vector;shift:integer) return std_logic_vector;--attenuator
    
    function ternary_func(constant cond:Boolean;constant trueval:Boolean;constant falseval:Boolean)return Boolean;
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:integer)return integer;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic;constant falseval:std_logic)return std_logic;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic;
    function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic_vector)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:std_logic_vector)return std_logic_vector;
    function ternary_func(constant cond:Boolean;constant trueval:integer_array;constant falseval:integer_array)return integer_array;
    function ternary_func(constant cond:Boolean;constant trueval:string;constant falseval:string)return string;
    
    function ext_zero_integer_array(input:integer_array;size:integer)return integer_array;
    
    function sign_extension(input:integer;output:integer)return std_logic_vector;
    function sign_extension(input:std_logic_vector;output:integer)return std_logic_vector;
    function sign_extension(input:integer;output:std_logic_vector)return std_logic_vector;
    function sign_extension(input:std_logic_vector;output:std_logic_vector)return std_logic_vector;
    
    function sign_copy(input:std_logic_vector;output:integer)return std_logic_vector;
    
    function or_reduce(input:std_logic_vector)return std_logic;
    
    --arithmetic shift left
    function asl(input:std_logic_vector;shift:integer)return std_logic_vector;
    --arithmetic shift right
    function asr(input:std_logic_vector;shift:integer)return std_logic_vector;
    function BIT_SEL (data : natural) return std_logic_vector;

    function GEN_PRBS15_32 (DATA : std_logic_vector(15 downto 0)) return std_logic_vector;

    end FFT_FUNC;

package body FFT_FUNC is

    -- AND OVERLOADING
    function "AND"(L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(R'RANGE) ;
    begin
        for I in R'RANGE loop
            RESULT(I)    := L AND R(I) ;
        end loop;
        return RESULT;
    end;

    -- AND OVERLOADING
    function "AND"(L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(L'RANGE) ;
    begin
        for I in L'RANGE loop
            RESULT(I)    := L(I) AND R ;
        end loop;
        return RESULT;
    end;

    -- OR OVERLOADING
    function "OR"(L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(R'RANGE) ;
    begin
        for I in R'RANGE loop
            RESULT(I)    := L OR R(I) ;
        end loop;
        return RESULT;
    end;

    -- OR OVERLOADING
    function "OR"(L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(L'RANGE) ;
    begin
        for I in L'RANGE loop
            RESULT(I)    := L(I) OR R ;
        end loop;
        return RESULT;
    end;

    -- XOR OVERLOADING
    function "XOR"(L:STD_LOGIC; R:STD_LOGIC_VECTOR) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(R'RANGE) ;
    begin
        for I in R'RANGE loop
            RESULT(I)    := L XOR R(I) ;
        end loop;
        return RESULT;
    end;

    -- XOR OVERLOADING
    function "XOR"(L:STD_LOGIC_VECTOR; R:STD_LOGIC) return STD_LOGIC_VECTOR is
        variable result : std_logic_vector(L'RANGE) ;
    begin
        for I in L'RANGE loop
            RESULT(I)    := L(I) XOR R ;
        end loop;
        return RESULT;
    end;

    ----**  byte/bit and operation  **--
    --function "and" (dia : std_logic_vector; dib : std_logic) return std_logic_vector is
    --    variable result : std_logic_vector(dia'range);
    --begin
    --    for i in dia'range loop
    --        result(i) := dia(i) and dib;
    --    end loop;
    --    return result;
    --end "and";
    ----**  byte/bit or operation  **--
    --function "or" (dia : std_logic_vector; dib : std_logic) return std_logic_vector is
    --    variable result : std_logic_vector(dia'range);
    --begin
    --    for i in dia'range loop
    --        result(i) := dia(i) or dib;
    --    end loop;
    --    return result;
    --end "or";
    --
    ----**  byte/bit xor operation  **--
    --function "xor" (dia : std_logic_vector; dib : std_logic) return std_logic_vector is
    --    variable result : std_logic_vector(dia'range);
    --begin
    --    for i in dia'range loop
    --        result(i) := dia(i) xor dib;
    --    end loop;
    --    return result;
    --end "xor";
    
    
    --**  scrambler x7+x6+1  **--
    function scr_x7_x6_1 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 8) then
            assert FALSE
            report "operator length is not 8"
            severity failure;
        else
            result(7) := di(6) xor di(5);
            result(6) := di(5) xor di(4);
            result(5) := di(4) xor di(3);
            result(4) := di(3) xor di(2);
            result(3) := di(2) xor di(1);
            result(2) := di(1) xor di(0);
            result(1) := di(7) xor di(5);
            result(0) := di(6) xor di(4);
        end if;
        return result;
    end scr_x7_x6_1;
    
    --** crc x7+x3+1  **--
    function crc_x7_x3_1 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dih'range);
    begin
        if (dih'length /= dil'length) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := dih(7) xor dih(6) xor dih(3) xor dil(7);
            result(6) := dih(6) xor dih(5) xor dih(2) xor dil(6);
            result(5) := dih(5) xor dih(4) xor dih(1) xor dil(5);
            result(4) := dih(4) xor dih(3) xor dih(0) xor dil(4);
            result(3) := dih(6) xor dih(2)            xor dil(3);
            result(2) := dih(5) xor dih(1)            xor dil(2);
            result(1) := dih(7) xor dih(4) xor dih(0) xor dil(1);
            result(0) :=                                  dil(0);
        end if;
        return result;
    end crc_x7_x3_1;
    --** crc x8+x2+x+1  **--
    function crc_x8_x2_x_1 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dih'range);
    begin
        if (dih'length /= dil'length) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := dih(7) xor dih(6) xor dih(5)            xor dil(7);
            result(6) := dih(6) xor dih(5) xor dih(4)            xor dil(6);
            result(5) := dih(5) xor dih(4) xor dih(3)            xor dil(5);
            result(4) := dih(4) xor dih(3) xor dih(2)            xor dil(4);
            result(3) := dih(7) xor dih(3) xor dih(2) xor dih(1) xor dil(3);
            result(2) := dih(6) xor dih(2) xor dih(1) xor dih(0) xor dil(2);
            result(1) := dih(6) xor dih(1) xor dih(0)            xor dil(1);
            result(0) := dih(7) xor dih(6) xor dih(0)            xor dil(0);
        end if;
        return result;
    end crc_x8_x2_x_1;
    --** crc x8+x2+x+1  **--
    function crc_x8 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dih'range);
    begin
        if (dih'length /= dil'length) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := dih(7) xor dih(6) xor dih(5)            xor dil(7) xor dil(6) xor dil(5)           ;
            result(6) := dih(6) xor dih(5) xor dih(4)            xor dil(6) xor dil(5) xor dil(4)           ;
            result(5) := dih(5) xor dih(4) xor dih(3)            xor dil(5) xor dil(4) xor dil(3)           ;
            result(4) := dih(4) xor dih(3) xor dih(2)            xor dil(4) xor dil(3) xor dil(2)           ;
            result(3) := dih(7) xor dih(3) xor dih(2) xor dih(1) xor dil(7) xor dil(3) xor dil(2) xor dil(1);
            result(2) := dih(6) xor dih(2) xor dih(1) xor dih(0) xor dil(6) xor dil(2) xor dil(1) xor dil(0);
            result(1) := dih(6) xor dih(1) xor dih(0)            xor dil(6) xor dil(1) xor dil(0)           ;
            result(0) := dih(7) xor dih(6) xor dih(0)            xor dil(7) xor dil(6) xor dil(0)           ;
        end if;
        return result;
    end crc_x8;
    
    --** hec k1=(x8+x2+x+1)^8  **--
    function hec_k1 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 8) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := di(7) xor di(6) xor di(5);
            result(6) := di(6) xor di(5) xor di(4);
            result(5) := di(5) xor di(4) xor di(3);
            result(4) := di(4) xor di(3) xor di(2);
            result(3) := di(7) xor di(3) xor di(2) xor di(1);
            result(2) := di(6) xor di(2) xor di(1) xor di(0);
            result(1) := di(6) xor di(1) xor di(0);
            result(0) := di(7) xor di(6) xor di(0);
        end if;
        return result;
    end hec_k1;
    --** hec k2=(x8+x2+x+1)^16  **--
    function hec_k2 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 8) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := di(7) xor di(5) xor di(3);
            result(6) := di(6) xor di(4) xor di(2);
            result(5) := di(7) xor di(5) xor di(3) xor di(1);
            result(4) := di(7) xor di(6) xor di(4) xor di(2) xor di(0);
            result(3) := di(6) xor di(5) xor di(3) xor di(1);
            result(2) := di(7) xor di(5) xor di(4) xor di(2) xor di(0);
            result(1) := di(7) xor di(6) xor di(5) xor di(4) xor di(1);
            result(0) := di(6) xor di(4) xor di(0);
        end if;
        return result;
    end hec_k2;
    
    --** hec k3=(x8+x2+x+1)^24  **--
    function hec_k3 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 8) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := di(6) xor di(4) xor di(2) xor di(1);
            result(6) := di(5) xor di(3) xor di(1) xor di(0);
            result(5) := di(4) xor di(2) xor di(0);
            result(4) := di(3) xor di(1);
            result(3) := di(7) xor di(2) xor di(0);
            result(2) := di(6) xor di(1);
            result(1) := di(7) xor di(6) xor di(5) xor di(4) xor di(2) xor di(1) xor di(0);
            result(0) := di(7) xor di(5) xor di(3) xor di(2) xor di(0);
        end if;
        return result;
    end hec_k3;
    
    --** hec k4=(x8+x2+x+1)^32  **--
    function hec_k4 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 8) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(7) := di(6) xor di(5) xor di(3);
            result(6) := di(5) xor di(4) xor di(2);
            result(5) := di(7) xor di(4) xor di(3) xor di(1);
            result(4) := di(7) xor di(6) xor di(3) xor di(2) xor di(0);
            result(3) := di(6) xor di(5) xor di(2) xor di(1);
            result(2) := di(5) xor di(4) xor di(1) xor di(0);
            result(1) := di(6) xor di(5) xor di(4) xor di(0);
            result(0) := di(7) xor di(6) xor di(4);
        end if;
        return result;
    end hec_k4;
    
    --crc16 = x16_x12_x5_1
    function crc16 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dih'range);
    begin
        if (dih'length /= (dil'length * 2)) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(15) := dih(15) xor dih(11) xor dih( 7)             xor dil( 7) xor dil( 3);
            result(14) := dih(14) xor dih(10) xor dih( 6)             xor dil( 6) xor dil( 2);
            result(13) := dih(13) xor dih( 9) xor dih( 5)             xor dil( 5) xor dil( 1);
            result(12) := dih(15) xor dih(12) xor dih( 8) xor dih( 4) xor dil( 7) xor dil( 4) xor dil( 0);
            result(11) := dih(14) xor dih( 3)                         xor dil( 6);
            result(10) := dih(13) xor dih( 2)                         xor dil( 5);
            result( 9) := dih(12) xor dih( 1)                         xor dil( 4);
            result( 8) := dih(15) xor dih(11) xor dih( 0)             xor dil( 7) xor dil( 3);
            result( 7) := dih(15) xor dih(14) xor dih(10)             xor dil( 7) xor dil( 6) xor dil( 2);
            result( 6) := dih(14) xor dih(13) xor dih( 9)             xor dil( 6) xor dil( 5) xor dil( 1);
            result( 5) := dih(13) xor dih(12) xor dih( 8)             xor dil( 5) xor dil( 4) xor dil( 0);
            result( 4) := dih(12)                                     xor dil( 4);
            result( 3) := dih(15) xor dih(11)                         xor dil( 7) xor dil( 3);
            result( 2) := dih(14) xor dih(10)                         xor dil( 6) xor dil( 2);
            result( 1) := dih(13) xor dih( 9)                         xor dil( 5) xor dil( 1);
            result( 0) := dih(12) xor dih( 8)                         xor dil( 4) xor dil( 0);
        end if;
        return result;
    end crc16;
    --hec_g1 = (x16_x12_x5_1)^16
    function hec_g1 (di : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(di'range);
    begin
        if (di'length /= 16) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(15) := di(11) xor di(10) xor di( 7) xor di( 3);
            result(14) := di(10) xor di( 9) xor di( 6) xor di( 2);
            result(13) := di( 9) xor di( 8) xor di( 5) xor di( 1);
            result(12) := di( 8) xor di( 7) xor di( 4) xor di( 0);
            result(11) := di(15) xor di(14) xor di(11) xor di(10) xor di( 6);
            result(10) := di(14) xor di(13) xor di(10) xor di( 9) xor di( 5);
            result( 9) := di(15) xor di(13) xor di(12) xor di( 9) xor di( 8) xor di( 4);
            result( 8) := di(15) xor di(14) xor di(12) xor di(11) xor di( 8) xor di( 7) xor di( 3);
            result( 7) := di(15) xor di(14) xor di(13) xor di(11) xor di(10) xor di( 7) xor di( 6) xor di( 2);
            result( 6) := di(14) xor di(13) xor di(12) xor di(10) xor di( 9) xor di( 6) xor di( 5) xor di( 1);
            result( 5) := di(13) xor di(12) xor di(11) xor di( 9) xor di( 8) xor di( 5) xor di( 4) xor di( 0);
            result( 4) := di(15) xor di(12) xor di( 8) xor di( 4);
            result( 3) := di(15) xor di(14) xor di(11) xor di( 7) xor di( 3);
            result( 2) := di(14) xor di(13) xor di(10) xor di( 6) xor di( 2);
            result( 1) := di(13) xor di(12) xor di( 9) xor di( 5) xor di( 1);
            result( 0) := di(12) xor di(11) xor di( 8) xor di( 4) xor di( 0);
        end if;
        return result;
    end hec_g1;
    
    --crc32 = x32_x26_x23_x22_x16_x12_x11_x10_x8_x7_x5_x4_x2_x_1
    function crc32 (dih : std_logic_vector; dil : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dih'range);
    begin
        if (dih'length /= (dil'length * 4)) then
            assert FALSE
            report "arguments of overloaded 'and' operator are not of the same length"
            severity failure;
        else
            result(31) := dih(29) xor dih(23)                         xor dil( 5);
            result(30) := dih(31) xor dih(28) xor dih(22)             xor dil( 7) xor dil( 4);
            result(29) := dih(31) xor dih(30) xor dih(27) xor dih(21) xor dil( 7) xor dil( 6) xor dil( 3);
            result(28) := dih(30) xor dih(29) xor dih(26) xor dih(20) xor dil( 6) xor dil( 5) xor dil( 2);
            result(27) := dih(31) xor dih(29) xor dih(28) xor dih(25) xor dil( 7) xor dil( 5) xor dil( 4) xor
                          dih(19)                                     xor dil( 1);
            result(26) := dih(30) xor dih(28) xor dih(27) xor dih(24) xor dil( 6) xor dil( 4) xor dil( 3) xor
                          dih(18)                                     xor dil( 0);
            result(25) := dih(27) xor dih(26) xor dih(17)             xor dil( 3) xor dil( 2);
            result(24) := dih(31) xor dih(26) xor dih(25) xor dih(16) xor dil( 7) xor dil( 2) xor dil( 1);
            result(23) := dih(30) xor dih(25) xor dih(24) xor dih(15) xor dil( 6) xor dil( 1) xor dil( 0);
            result(22) := dih(24) xor dih(14)                         xor dil( 0);
            result(21) := dih(29) xor dih(13)                         xor dil( 5);
            result(20) := dih(28) xor dih(12)                         xor dil( 4);
            result(19) := dih(31) xor dih(27) xor dih(11)             xor dil( 7) xor dil( 3);
            result(18) := dih(31) xor dih(30) xor dih(26) xor dih(10) xor dil( 7) xor dil( 6) xor dil( 2);
            result(17) := dih(30) xor dih(29) xor dih(25) xor dih( 9) xor dil( 6) xor dil( 5) xor dil( 1);
            result(16) := dih(29) xor dih(28) xor dih(24) xor dih( 8) xor dil( 5) xor dil( 4) xor dil( 0);
            result(15) := dih(31) xor dih(29) xor dih(28) xor dih(27) xor dil( 7) xor dil( 5) xor dil( 4) xor
                          dih( 7)                                     xor dil( 3);
            result(14) := dih(31) xor dih(30) xor dih(28) xor dih(27) xor dil( 7) xor dil( 6) xor dil( 4) xor
                          dih(26) xor dih( 6)                         xor dil( 3) xor dil( 2);
            result(13) := dih(31) xor dih(30) xor dih(29) xor dih(27) xor dil( 7) xor dil( 6) xor dil( 5) xor
                          dih(26) xor dih(25) xor dih( 5)             xor dil( 3) xor dil( 2) xor dil( 1);
            result(12) := dih(30) xor dih(29) xor dih(28) xor dih(26) xor dil( 6) xor dil( 5) xor dil( 4) xor
                          dih(25) xor dih(24) xor dih(4)              xor dil( 2) xor dil( 1) xor dil( 0);
            result(11) := dih(28) xor dih(27) xor dih(25) xor dih(24) xor dil( 4) xor dil( 3) xor dil( 1) xor
                          dih( 3)                                     xor dil( 0);
            result(10) := dih(29) xor dih(27) xor dih(26) xor dih(24) xor dil( 5) xor dil( 3) xor dil( 2) xor
                          dih( 2)                                     xor dil( 0);
            result( 9) := dih(29) xor dih(28) xor dih(26) xor dih(25) xor dil( 5) xor dil( 4) xor dil( 2) xor
                          dih( 1)                                     xor dil( 1);
            result( 8) := dih(28) xor dih(27) xor dih(25) xor dih(24) xor dil( 4) xor dil( 3) xor dil( 1) xor
                          dih( 0)                                     xor dil( 0);
            result( 7) := dih(31) xor dih(29) xor dih(27) xor dih(26) xor dil( 7) xor dil( 5) xor dil( 3) xor
                          dih(24)                                     xor dil( 2) xor dil( 0);
            result( 6) := dih(31) xor dih(30) xor dih(29) xor dih(28) xor dil( 7) xor dil( 6) xor dil( 5) xor
                          dih(26) xor dih(25)                         xor dil( 4) xor dil( 2) xor dil( 1);
            result( 5) := dih(31) xor dih(30) xor dih(29) xor dih(28) xor dil( 7) xor dil( 6) xor dil( 5) xor
                          dih(27) xor dih(25) xor dih(24)             xor dil( 4) xor dil( 3) xor dil( 1) xor
                                                                          dil( 0);
            result( 4) := dih(30) xor dih(28) xor dih(27) xor dih(26) xor dil( 6) xor dil( 4) xor dil( 3) xor
                          dih(24)                                     xor dil( 2) xor dil( 0);
            result( 3) := dih(31) xor dih(27) xor dih(26) xor dih(25) xor dil( 7) xor dil( 3) xor dil( 2) xor
                                                                          dil( 1);
            result( 2) := dih(31) xor dih(30) xor dih(26) xor dih(25) xor dil( 7) xor dil( 6) xor dil( 2) xor
                          dih(24)                                     xor dil( 1) xor dil( 0);
            result( 1) := dih(31) xor dih(30) xor dih(25) xor dih(24) xor dil( 7) xor dil( 6) xor dil( 1) xor
                                                                          dil( 0);
            result( 0) := dih(30) xor dih(24)                         xor dil( 6) xor dil( 0);
        end if;
        return result;
    end crc32;

    function crc_4_12 (D : std_logic_vector; X : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(X'range);
    begin

        result(3) :=          X(2) xor X(1)                    xor D(10) xor D(9)                            xor D(5) xor D(4)                            xor D(0);
        result(2) :=          X(2)          xor X(0)           xor D(10)          xor D(8)                   xor D(5)          xor D(3)                   xor D(0);
        result(1) :=          X(2)                             xor D(10)                   xor D(7)          xor D(5)                   xor D(2)          xor D(0);
        result(0) := X(3) xor X(2)                   xor D(11) xor D(10)                            xor D(6) xor D(5)                            xor D(1) xor D(0);
    
        return result;
    end crc_4_12;

    
    function ZEROS(N : natural )
    return std_logic_vector is
        variable ZEROS_VECTOR : std_logic_vector(N-1 downto 0);
    begin
        for I in 0 to (N-1) loop
            ZEROS_VECTOR(I) := '0';
        end loop;
        return ZEROS_VECTOR;
    end;

    function ONES(N : natural )
    return std_logic_vector is
        variable ONES_VECTOR : std_logic_vector(N-1 downto 0);
    begin
        for I in 0 to (N-1) loop
            ONES_VECTOR(I) := '1';
        end loop;
        return ONES_VECTOR;
    end;
    
    --** to_next **--
    --function to_next (signal clk: std_logic; cnt: integer) return boolean is
    --begin
    --   return clk'event and clk = '1' and cnt = 3;
    --end to_next;
      ------------------------------------------------------------------------------
      -- FUNCTION : log2roundup
      -- This function takes the log base 2 of a number and then rounds up to the
      -- next integer value
      ------------------------------------------------------------------------------
      function log2 (data_value : integer)
        return integer is
    
        variable width       : integer := 0;
        variable cnt         : integer := 1;
    
      begin
        if (data_value <= 1) then
          width   := 0;
        else
          while (cnt < data_value) loop
            width := width + 1;
            cnt   := cnt *2;
          end loop;
        end if;
    
        return width;
      end log2;
    
        -- ternary function
        function ternary_func(constant cond:Boolean;constant trueval:Boolean;constant falseval:Boolean)return Boolean is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:integer)return integer is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:std_logic;constant falseval:std_logic)return std_logic is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic is
        begin
            if cond then
                return trueval(0);
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond : Boolean;constant trueval:std_logic_vector;constant falseval:std_logic)return std_logic_vector is
        variable result:std_logic_vector(0 downto 0);
        begin
            if cond then
                return trueval;
            else
                result(0):=falseval;
                return result;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond : Boolean;constant trueval:std_logic_vector;constant falseval:std_logic_vector)return std_logic_vector is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:integer;constant falseval:std_logic_vector)return std_logic_vector is
        begin
            if cond then
                return std_logic_vector(to_unsigned(trueval,falseval'length));
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:integer_array;constant falseval:integer_array)return integer_array is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        function ternary_func(constant cond:Boolean;constant trueval:string;constant falseval:string)return string is
        begin
            if cond then
                return trueval;
            else
                return falseval;
            end if;
        end ternary_func;
    
        --extent integer_array to zero
        function ext_zero_integer_array(input:integer_array;size:integer)return integer_array is
            variable result:integer_array(size-1 downto 0);
            variable input_size:natural;
        begin
            input_size := input'length;
            result:=(others=>0);
            result(size-1 downto size-input_size):=input;
            return result;
        end ext_zero_integer_array;
    
        --sign extensions
        function sign_extension(input:integer;output:integer)return std_logic_vector is
        begin
            return std_logic_vector(to_signed(input,output));
        end sign_extension;
    
        function sign_extension(input:std_logic_vector;output:integer)return std_logic_vector is
            variable widthi:integer;
            variable result:std_logic_vector(output-1 downto 0);
        begin
            widthi := input'length;
            result(widthi-2 downto 0):=input(widthi-2 downto 0);
            result(output-1 downto widthi-1):=(others=>input(widthi-1));
            return  result;
        end sign_extension;
    
        function sign_extension(input:integer;output:std_logic_vector)return std_logic_vector is
        begin
            return std_logic_vector(to_signed(input, output'length));
        end sign_extension;
    
        function sign_extension(input:std_logic_vector;output:std_logic_vector)return std_logic_vector is
            variable widthi:integer;
            variable result:std_logic_vector(output'length-1 downto 0);
        begin
            result(widthi-2 downto 0):=input(widthi-2 downto 0);
            result(output'length-1 downto widthi-1):=(others=>input(widthi-1));
            return result;
        end sign_extension;
    
        function sign_copy(input:std_logic_vector;output:integer)return std_logic_vector is
            variable widthi:integer;
        begin
            widthi := input'length;
            return input(widthi-1) & input(output-2 downto 0);
        end sign_copy;
    
        function or_reduce(input:std_logic_vector)return std_logic is
        begin
            if input/=0 then
                return '1';
            else
                return '0';
            end if;
        end or_reduce;
    
        --arithmetic shift left
        function asl(input:std_logic_vector;shift:integer)return std_logic_vector is
            variable result:std_logic_vector(input'length-1 downto 0);
        begin
            result:=input;
            if shift>0 then
                for i in 0 to input'length-1 loop
                    if i<shift then
                        result(i) :='0';
                    else
                        result(i) :=input(i-shift);
                    end if;
                end loop;
            end if;
            return result;
        end asl;
    
        --arithmetic shift right
        function asr(input:std_logic_vector;shift:integer)return std_logic_vector is
            variable result:std_logic_vector(input'length-1 downto 0);
            variable sign:std_logic;
        begin
            result:=input;
            sign:=input(input'length-1);
            if shift>0 then
                for i in 0 to input'length-1 loop
                    if i+shift<input'length-1 then
                        result(i) :=input(i+shift);
                    else
                        result(i) :=sign;
                    end if;
                end loop;
            end if;
            return result;
        end asr;
    
        function count_bits(world : std_logic_vector;size:natural) return std_logic_vector is
        variable c: natural range 0 to 128;
        begin
            c:=0;
            for i in world'left downto 0 loop
                if world(i)='1' then
                    c:=c+1;
                end if;
            end loop;
            return std_logic_vector(to_unsigned(c,size));
        end count_bits;
    
        function dataread ( d : std_logic_vector ) return std_logic_vector  is
        variable    result:std_logic_vector(31 downto 0);
        begin
            result:=(others=>'0');
            result(d'length-1 downto 0):=d;
            return result;
        end function dataread;
    
        function dataread ( d : std_logic) return std_logic_vector  is
        variable    result:std_logic_vector(31 downto 0);
        begin
            result:=(others=>'0');
            result(0):=d;
            return result;
        end function dataread;
    
        function dataread ( d : integer) return std_logic_vector  is
        begin
            return std_logic_vector(to_unsigned(d, 32));
        end function dataread;
    
        --exp format function
       function exptobit(fxp_iq:std_logic_vector) return std_logic_vector is--31-16  I, 15-0 Q
       variable f_q : std_logic_vector(15 downto 0);
       variable f_i : std_logic_vector(15 downto 0);
       begin
          --when 0 here
          f_q(15 downto 6):= (others=>fxp_iq(11));
          f_q(5 downto 0) :=   fxp_iq(11 downto 6);
    
          f_i(15 downto 6):=   (others=>fxp_iq(5));
          f_i(5 downto 0) :=   fxp_iq(5 downto 0);
    
          case to_integer(unsigned(fxp_iq(15 downto 12))) is
             when 1=>
                f_q:=f_q(14 downto 0)&"0";
                f_i:=f_i(14 downto 0)&"0";
             when 2=>
                f_q:=f_q(13 downto 0)&"00";
                f_i:=f_i(13 downto 0)&"00";
             when 3=>
                f_q:=f_q(12 downto 0)&"000";
                f_i:=f_i(12 downto 0)&"000";
             when 4=>
                f_q:=f_q(11 downto 0)&"0000";
                f_i:=f_i(11 downto 0)&"0000";
             when 5=>
                f_q:=f_q(10 downto 0)&"00000";
                f_i:=f_i(10 downto 0)&"00000";
             when 6=>
                f_q:=f_q(9 downto 0) &"000000";
                f_i:=f_i(9 downto 0) &"000000";
             when 7=>
                f_q:=f_q(8 downto 0) &"0000000";
                f_i:=f_i(8 downto 0) &"0000000";
             when 8=>
                f_q:=f_q(7 downto 0) &"00000000";
                f_i:=f_i(7 downto 0) &"00000000";
             when 9=>
                f_q:=f_q(6 downto 0) &"000000000";
                f_i:=f_i(6 downto 0) &"000000000";
             when 10=>
                f_q:=f_q(5 downto 0) &"0000000000";
                f_i:=f_i(5 downto 0) &"0000000000";
             when 11=>
                f_q:=f_q(4 downto 0) &"00000000000";
                f_i:=f_i(4 downto 0) &"00000000000";
             when 12=>
                f_q:=f_q(3 downto 0) &"000000000000";
                f_i:=f_i(3 downto 0) &"000000000000";
             when 13=>
                f_q:=f_q(2 downto 0) &"0000000000000";
                f_i:=f_i(2 downto 0) &"0000000000000";
             when 14=>
                f_q:=f_q(1 downto 0) &"00000000000000";
                f_i:=f_i(1 downto 0) &"00000000000000";
             when 15=>
                f_q:=f_q(0 downto 0) &"000000000000000";
                f_i:=f_i(0 downto 0) &"000000000000000";
             when others=>null;
          end case;
          return (f_q & f_i);
       end function exptobit;
    
       function selector(data,sel:std_logic_vector) return std_logic_vector is
       --variable
       begin
          case sel(3 downto 0) is
             when x"F"=>return data(15 downto 15-6);
             when x"E"=>return data(14 downto 14-6);
             when x"D"=>return data(13 downto 13-6);
             when x"C"=>return data(12 downto 12-6);
             when x"B"=>return data(11 downto 11-6);
             when x"A"=>return data(10 downto 10-6);
             when x"9"=>return data(9 downto 9-6);
             when x"8"=>return data(8 downto 8-6);
             when x"7"=>return data(7 downto 7-6);
             when x"6"=>return data(6 downto 6-6);
             when others=>return data(5 downto 0)&'0';
          end case;
       end function selector;
    
       function saturate_frac(value:std_logic_vector) return std_logic_vector is
       variable temp:std_logic_vector(6 downto 0);
       begin
          temp:=value;
          if(value/=b"0_111_111") then
             temp:=temp+1;
          end if;
          return temp(6 downto 1);
       end function saturate_frac;
    
    
       function bittoexp(i_data,q_data:std_logic_vector) return std_logic_vector is
       variable si,sq:signed(15 downto 0);
       variable i,q,max:unsigned(15 downto 0);
       variable lsb:std_logic_vector(3 downto 0);
       variable fxp_i,fxp_q:std_logic_vector(6 downto 0);
       variable fxp_is,fxp_qs:std_logic_vector(5 downto 0);
       begin
          --$display("I %d Q%d",i_data,q_data);
          si:=signed(i_data);
          sq:=signed(q_data);
    
          if(si>0)then
             i:=unsigned(si);
          else
             i:=unsigned(not si);
          end if;
    
          if(sq>0)then
             q:=unsigned(sq);
          else
             q:=unsigned(not sq);
          end if;
    
          max:=q;
          if(i>q)then
             max:=i;
          end if;
    
          --$display("I %d Q%d MAX %d",i,q,max);
    
          if   (max(14 downto 5)=0)then
             lsb:=x"5";
          elsif(max(14 downto 6)=0)then
             lsb:=x"6";
          elsif(max(14 downto 7)=0)then
             lsb:=x"7";
          elsif(max(14 downto 8)=0)then
             lsb:=x"8";
          elsif(max(14 downto 9)=0)then
             lsb:=x"9";
          elsif(max(14 downto 10)=0)then
             lsb:=x"A";
          elsif(max(14 downto 11)=0)then
             lsb:=x"B";
          elsif(max(14 downto 12)=0)then
             lsb:=x"C";
          elsif(max(14 downto 13)=0)then
             lsb:=x"D";
          elsif(max(14)='0')then
             lsb:=x"E";
          else
             lsb:=x"F";
          end if;
          fxp_i:=selector(i_data,lsb);
          fxp_q:=selector(q_data,lsb);
          --$display("fxp_i %0x fxp_q %0x",fxp_i,fxp_q);
          fxp_is:=saturate_frac(fxp_i);
          fxp_qs:=saturate_frac(fxp_q);
          lsb:=lsb-5;
          return lsb & fxp_is& fxp_qs;--must be exp, I and Q
       end function bittoexp;
    
      ------------------------------------------------------------------------------
      -- FUNCTION : grp3 / flt3
      -- grouping in 3 / flatting by 3
      ------------------------------------------------------------------------------
       function grp3 ( di : std_logic_vector )
          return std_logic_array3 is
          variable result : std_logic_array3(2 downto 0);
       begin
          if(di'length = 6) then
             result(0) := di(2 downto 0);
             result(1) := di(5 downto 3);
             result(2) := "000";
          elsif(di'length = 9) then
             result(0) := di(2 downto 0);
             result(1) := di(5 downto 3);
             result(2) := di(8 downto 6);
          else
             assert FALSE
             report "grp3 length is not matched"
        severity failure;
          end if;
          return result;
       end grp3;
    
       function flt3 ( bit_n : integer; di : std_logic_array8 )
          return std_logic_vector is
          variable result : std_logic_vector(bit_n-1 downto 0);
       begin
          if(bit_n = 6) then
             result := di(1)(2 downto 0) & di(0)(2 downto 0);
          elsif(bit_n = 9) then
             result := di(2)(2 downto 0) & di(1)(2 downto 0) & di(0)(2 downto 0);
          elsif(bit_n = 10) then
             result := '0' & di(2)(2 downto 0) & di(1)(2 downto 0) & di(0)(2 downto 0);
          else
             assert FALSE
             report "flt3 length is not matched"
        severity failure;
          end if;
          return result;
       end flt3;
    
    
    function abs_diff2_zero (dia : std_logic_vector; dib : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dia'range);
    begin
        if dia > dib then
            result := dia - dib;
        else
            result := (others => '0');
        end if;
        return result;
    end abs_diff2_zero;
    
    --function abs_diff2 (dia : std_logic_vector; dib : std_logic_vector) return std_logic_vector;
    function abs_diff2 (dia : std_logic_vector; dib : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dia'range);
    begin
        if dia >= dib then
            result := dia - dib;
        else
            result := dib - dia;
        end if;
        return result;
    end abs_diff2;
    
    function abs_diff4 (dia : std_logic_vector; dib : std_logic_vector; dic : std_logic_vector; did : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(dia'range);
    begin
        if (dia+dib) >= (dic+did) then
            result := (dia+dib) - (dic+did);
        else
            result := (dic+did) - (dia+dib);
        end if;
        return result;
    
    end abs_diff4;
    
    function med3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(d0'range);
    begin
        if d0 >= d1 then
            if d0 >= d2 then
                if d1 >= d2 then
                    result := d1;
                else
                    result := d2;
                end if;
            else
                 result := d0;
            end if;
        else
            if d0 >= d2 then
                result := d0;
            else
                if d1 >= d2 then
                    result := d2;
                else
                    result := d1;
                end if;
            end if;
        end if;
    
        return result;
    
    end med3;
    
    function max3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(d0'range);
    begin
        if d0 >= d1 then
            if d0 >= d2 then
                result := d0;
            else
                result := d2;
            end if;
        else
            if d1 >= d2 then
                result := d1;
            else
                result := d2;
            end if;
        end if;
    
        return result;
    
    end max3;
    
    function min3 (d0 : std_logic_vector; d1 : std_logic_vector;d2 : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(d0'range);
    begin
        if d0 <= d1 then
            if d0 <= d2 then
                result := d0;
            else
                result := d2;
            end if;
        else
            if d1 <= d2 then
                result := d1;
            else
                result := d2;
            end if;
        end if;
    
        return result;
    
    end min3;
    
    function sign_add2 (d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector is
    
        variable temp_result : std_logic_vector(d0'range);
        variable temp_sign   : std_logic;
        variable result      : std_logic_vector(d0'range);
    
    begin
    
        if (d0_sign = '0' and  d1_sign = '0') then
            temp_result := d0 + d1;
        elsif (d0_sign = '0' and  d1_sign = '1') then
            if  d0 >= d1 then
                temp_result := d0 - d1;
            else
                temp_result := (others => '0');
            end if;
        elsif (d0_sign = '1' and  d1_sign = '0')then
            if  d0 <= d1 then
                temp_result := d1 - d0;
            else
                temp_result := (others => '0');
            end if;
        else
            temp_result := (others => '0');
        end if;
        result:= temp_result;
    
        return result;
    end sign_add2;
    
    --function sign_add2 (d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector is
    --
    --    variable temp_result : std_logic_vector(d0'range + 1);
    --    variable temp_sign   : std_logic;
    --    variable result      : std_logic_vector(d0'range + 2);
    --
    --begin
    --    if (d0_sign = '0' and  d1_sign = '0') then
    --        temp_result := ('0' & d0) + ('0' & d1);
    --        temp_sign   :='0';
    --    elsif (d0_sign = '0' and  d1_sign = '1') then
    --        if  d0 >= d1 then
    --            temp_result := ('0' & d0) - ('0' & d1);
    --            temp_sign   :='0';
    --        else
    --            temp_result := ('0' & d1) - ('0' & d0);
    --            temp_sign   :='1';
    --        end if;
    --    elsif (d0_sign = '1' and  d1_sign = '0')then
    --        if  d0 <= d1 then
    --            temp_result := ('0' & d1) - ('0' & d0);
    --            temp_sign   :='0';
    --        else
    --            temp_result := ('0' & d0) - ('0' & d1);
    --            temp_sign   :='1';
    --        end if;
    --    else
    --        temp_result := (others => '0');
    --        temp_sign   := '0';
    --    end if;
    --
    --    result:= (temp_sign & temp_result);
    --end sign_add2;
    
    
    
    --function sign_sub2 (d0 : std_logic_vector;d0_sign : std_logic; d1 : std_logic_vector;d1_sign: std_logic) return std_logic_vector is
    --    variable temp_result : std_logic_vector(d0'range + 1);
    --    variable temp_sign   : std_logic;
    --    variable result      : std_logic_vector(d0'range + 2);
    --begin
    --    if (d0_sign = '0' and  d1_sign = '0')then
    --        if  d0 >= d1 then
    --            temp_result := ('0' & d0) - ('0' & d1);
    --            temp_sign   :='0';
    --        else
    --            temp_result := ('0' & d1) - ('0' & d0);
    --            temp_sign   :='1';
    --        end if;
    --    elsif (d0_sign = '0' and  d1_sign = '1') then
    --        temp_result := ('0' & d0) + ('0' & d1);
    --        temp_sign   :='0';
    --    elsif (d0_sign = '1' and  d1_sign = '0') then
    --        temp_result := ('0' & d0) + ('0' & d1);
    --        temp_sign   :='1';
    --    else
    --        if  d0 <= d1 then
    --            temp_result := ('0' & d1) - ('0' & d0);
    --            temp_sign   :='0';
    --        else
    --            temp_result := ('0' & d0) - ('0' & d1);
    --            temp_sign   :='1';
    --        end if;
    --    end if;
    --    result:= (temp_sign & temp_result);
    --end sign_sub2;

    ------------------------------------------------------------------------------
    -- FUNCTION : sum_with_sat
    -- 2010.11.29 SHT Lab
    -- a : data_in, b : data_in, width : bus_width
    ------------------------------------------------------------------------------
    function sum_with_sat ( a : std_logic_vector; b : std_logic_vector; width : natural)
    return std_logic_vector is
        variable cnt             : natural := 0;
        variable result_extended : std_logic_vector(width downto 0);
        variable result          : std_logic_vector(width-1 downto 0);
    begin
        if(a'length = b'length) then
            result_extended := (a(width-1) & a) + (b(width-1) & b);
            if (result_extended(width) = result_extended(width-1)) then
                result := result_extended(width-1 downto 0);
            else
                result(width-1) := result_extended(width);
                while (cnt < width-1) loop
                    result(cnt) := not result_extended(width);
                    cnt := cnt + 1;
                end loop;
            end if;
        else
            assert FALSE
            report "The length of array is not matched"
            severity failure;
        end if;
        return result;
    end sum_with_sat;

    ------------------------------------------------------------------------------
    -- FUNCTION : sub_with_sat
    -- 2010.11.29 SHT Lab
    -- a : data_in, b : data_in, width : bus_width
    ------------------------------------------------------------------------------
    function sub_with_sat ( a : std_logic_vector; b : std_logic_vector; width : natural)
    return std_logic_vector is
        variable cnt             : natural := 0;
        variable result_extended : std_logic_vector(width downto 0);
        variable result          : std_logic_vector(width-1 downto 0);
    begin
        if(a'length = b'length) then
            result_extended := (a(width-1) & a) - (b(width-1) & b);
            if (result_extended(width) = result_extended(width-1)) then
                result := result_extended(width-1 downto 0);
            else
                result(width-1) := result_extended(width);
                while (cnt < width-1) loop
                    result(cnt) := not result_extended(width);
                    cnt := cnt + 1;
                end loop;
            end if;
        else
            assert FALSE
            report "The length of array is not matched"
            severity failure;
        end if;
        return result;
    end sub_with_sat;

    ------------------------------------------------------------------------------
    -- FUNCTION : 19bit data signed right shifter
    -- 2010.11.29 SHT Lab
    -- a : data_in, b : data_in, width : bus_width
    ------------------------------------------------------------------------------
    function right19_shifter(IQdata:std_logic_vector;shift:integer) return std_logic_vector is--attenuator
    variable temp:signed(18 downto 0);
    begin
      temp := signed(IQdata);
      for i in 1 to 17 loop
          if(i<=shift) then
            temp:=temp(18)&temp(18 downto 1);
          end if;
      end loop;
      return std_logic_vector(temp);
    end function right19_shifter;

    function BIT_SEL (
        DATA                        : natural
    )
    return std_logic_vector is
    begin
        case DATA is
        when 1      => return x"00000001";
        when 2      => return x"00000003";
        when 3      => return x"00000007";
        when 4      => return x"0000000F";
        when 5      => return x"0000001F";
        when 6      => return x"0000003F";
        when 7      => return x"0000007F";
        when 8      => return x"000000FF";
        when 9      => return x"000001FF";
        when 10     => return x"000003FF";
        when 11     => return x"000007FF";
        when 12     => return x"00000FFF";
        when 13     => return x"00001FFF";
        when 14     => return x"00003FFF";
        when 15     => return x"00007FFF";
        when 16     => return x"0000FFFF";
        when 17     => return x"0001FFFF";
        when 18     => return x"0003FFFF";
        when 19     => return x"0007FFFF";
        when 20     => return x"000FFFFF";
        when 21     => return x"001FFFFF";
        when 22     => return x"003FFFFF";
        when 23     => return x"007FFFFF";
        when 24     => return x"00FFFFFF";
        when 25     => return x"01FFFFFF";
        when 26     => return x"03FFFFFF";
        when 27     => return x"07FFFFFF";
        when 28     => return x"0FFFFFFF";
        when 29     => return x"1FFFFFFF";
        when 30     => return x"3FFFFFFF";
        when 31     => return x"7FFFFFFF";
        when 32     => return x"FFFFFFFF";
        when others => return x"00000000";
        end case;
    end BIT_SEL;

    -- PRBS-15, X^14+X^13+1
    function GEN_PRBS15_32 (
        DATA                        : std_logic_vector(15 downto 0)
    )
    return std_logic_vector is
        variable result             : std_logic_vector(31 downto 0);
    begin
        result(0)  := DATA(13) xor DATA(12) xor DATA(11) xor DATA(10);
        result(1)  := DATA(14) xor DATA(13) xor DATA(12) xor DATA(11);
        result(2)  := DATA(0)               xor DATA(13) xor DATA(12);
        result(3)  := DATA(1)               xor DATA(14) xor DATA(13);
        result(4)  := DATA(2)               xor DATA(0);
        result(5)  := DATA(3)               xor DATA(1);
        result(6)  := DATA(4)               xor DATA(2);
        result(7)  := DATA(5)               xor DATA(3);
        result(8)  := DATA(6)               xor DATA(4);
        result(9)  := DATA(7)               xor DATA(5);
        result(10) := DATA(8)               xor DATA(6);
        result(11) := DATA(9)               xor DATA(7);
        result(12) := DATA(10)              xor DATA(8);
        result(13) := DATA(11)              xor DATA(9);
        result(14) := DATA(12)              xor DATA(10);
        result(15) := DATA(13)              xor DATA(11);
        result(16) := DATA(14)              xor DATA(12);
        result(17) := DATA(0)  xor DATA(14) xor DATA(13);
        result(18) := DATA(1)  xor DATA(0);
        result(19) := DATA(2)  xor DATA(1);
        result(20) := DATA(3)  xor DATA(2);
        result(21) := DATA(4)  xor DATA(3);
        result(22) := DATA(5)  xor DATA(4);
        result(23) := DATA(6)  xor DATA(5);
        result(24) := DATA(7)  xor DATA(6);
        result(25) := DATA(8)  xor DATA(7);
        result(26) := DATA(9)  xor DATA(8);
        result(27) := DATA(10) xor DATA(9);
        result(28) := DATA(11) xor DATA(10);
        result(29) := DATA(12) xor DATA(11);
        result(30) := DATA(13) xor DATA(12);
        result(31) := DATA(14) xor DATA(13);
        return result;
    end;

end FFT_FUNC;
