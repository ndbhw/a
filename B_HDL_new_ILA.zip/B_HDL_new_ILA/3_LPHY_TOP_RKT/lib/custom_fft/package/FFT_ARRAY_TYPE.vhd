library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use std.textio.all;
use IEEE.numeric_std.all;

package FFT_ARRAY_TYPE is

type std_logic_array1                 is array(natural range <>) of std_logic_vector(0   downto 0);
type std_logic_array2                 is array(natural range <>) of std_logic_vector(1   downto 0);
type std_logic_array3                 is array(natural range <>) of std_logic_vector(2   downto 0);
type std_logic_array4                 is array(natural range <>) of std_logic_vector(3   downto 0);
type std_logic_array5                 is array(natural range <>) of std_logic_vector(4   downto 0);
type std_logic_array6                 is array(natural range <>) of std_logic_vector(5   downto 0);
type std_logic_array7                 is array(natural range <>) of std_logic_vector(6   downto 0);
type std_logic_array8                 is array(natural range <>) of std_logic_vector(7   downto 0);
type std_logic_array9                 is array(natural range <>) of std_logic_vector(8   downto 0);
type std_logic_array10                is array(natural range <>) of std_logic_vector(9   downto 0);
type std_logic_array11                is array(natural range <>) of std_logic_vector(10  downto 0);
type std_logic_array12                is array(natural range <>) of std_logic_vector(11  downto 0);
type std_logic_array13                is array(natural range <>) of std_logic_vector(12  downto 0);
type std_logic_array14                is array(natural range <>) of std_logic_vector(13  downto 0);
type std_logic_array15                is array(natural range <>) of std_logic_vector(14  downto 0);
type std_logic_array16                is array(natural range <>) of std_logic_vector(15  downto 0);
type std_logic_array17                is array(natural range <>) of std_logic_vector(16  downto 0);
type std_logic_array18                is array(natural range <>) of std_logic_vector(17  downto 0);
type std_logic_array19                is array(natural range <>) of std_logic_vector(18  downto 0);
type std_logic_array20                is array(natural range <>) of std_logic_vector(19  downto 0);
type std_logic_array21                is array(natural range <>) of std_logic_vector(20  downto 0);
type std_logic_array22                is array(natural range <>) of std_logic_vector(21  downto 0);
type std_logic_array23                is array(natural range <>) of std_logic_vector(22  downto 0);
type std_logic_array24                is array(natural range <>) of std_logic_vector(23  downto 0);
type std_logic_array25                is array(natural range <>) of std_logic_vector(24  downto 0);
type std_logic_array26                is array(natural range <>) of std_logic_vector(25  downto 0);
type std_logic_array27                is array(natural range <>) of std_logic_vector(26  downto 0);
type std_logic_array28                is array(natural range <>) of std_logic_vector(27  downto 0);
type std_logic_array29                is array(natural range <>) of std_logic_vector(28  downto 0);
type std_logic_array30                is array(natural range <>) of std_logic_vector(29  downto 0);
type std_logic_array31                is array(natural range <>) of std_logic_vector(30  downto 0);
type std_logic_array32                is array(natural range <>) of std_logic_vector(31  downto 0);
type std_logic_array33                is array(natural range <>) of std_logic_vector(32  downto 0);
type std_logic_array34                is array(natural range <>) of std_logic_vector(33  downto 0);
type std_logic_array35                is array(natural range <>) of std_logic_vector(34  downto 0);
type std_logic_array36                is array(natural range <>) of std_logic_vector(35  downto 0);
type std_logic_array37                is array(natural range <>) of std_logic_vector(36  downto 0);
type std_logic_array38                is array(natural range <>) of std_logic_vector(37 downto  0);
type std_logic_array39                is array(natural range <>) of std_logic_vector(38 downto  0);
type std_logic_array40                is array(natural range <>) of std_logic_vector(39  downto 0);
type std_logic_array41                is array(natural range <>) of std_logic_vector(40  downto 0);
type std_logic_array42                is array(natural range <>) of std_logic_vector(41  downto 0);
type std_logic_array43                is array(natural range <>) of std_logic_vector(42 downto  0);
type std_logic_array44                is array(natural range <>) of std_logic_vector(43  downto 0);
type std_logic_array45                is array(natural range <>) of std_logic_vector(44  downto 0);
type std_logic_array46                is array(natural range <>) of std_logic_vector(45  downto 0);
type std_logic_array47                is array(natural range <>) of std_logic_vector(46  downto 0);
type std_logic_array48                is array(natural range <>) of std_logic_vector(47  downto 0);
type std_logic_array50                is array(natural range <>) of std_logic_vector(49  downto 0);
type std_logic_array51                is array(natural range <>) of std_logic_vector(50  downto 0);
type std_logic_array52                is array(natural range <>) of std_logic_vector(51  downto 0);
type std_logic_array53                is array(natural range <>) of std_logic_vector(52  downto 0);
type std_logic_array60                is array(natural range <>) of std_logic_vector(59  downto 0);
type std_logic_array63                is array(natural range <>) of std_logic_vector(62 downto  0);
type std_logic_array64                is array(natural range <>) of std_logic_vector(63  downto 0);
type std_logic_array72                is array(natural range <>) of std_logic_vector(71  downto 0);
type std_logic_array80                is array(natural range <>) of std_logic_vector(79  downto 0);
type std_logic_array96                is array(natural range <>) of std_logic_vector(95 downto  0);
type std_logic_array100               is array(natural range <>) of std_logic_vector(99  downto 0);
type std_logic_array128               is array(natural range <>) of std_logic_vector(127 downto 0);
type std_logic_array160               is array(natural range <>) of std_logic_vector(159 downto 0);
type std_logic_array192               is array(natural range <>) of std_logic_vector(191 downto 0);
type std_logic_array256               is array(natural range <>) of std_logic_vector(255 downto 0);
type std_logic_array273               is array(natural range <>) of std_logic_vector(272 downto 0);
type std_logic_array240               is array(natural range <>) of std_logic_vector(239 downto 0);
type std_logic_array512               is array(natural range <>) of std_logic_vector(511 downto 0);
type std_logic_array768               is array(natural range <>) of std_logic_vector(767 downto 0);
type std_logic_array960               is array(natural range <>) of std_logic_vector(960 downto 0);
type std_logic_array3276              is array(natural range <>) of std_logic_vector(3275 downto 0);

type std_logic_array4_array1          is array(natural range <>) of std_logic_array1(3    downto 0);
type std_logic_array8_array1          is array(natural range <>) of std_logic_array1(7    downto 0);
type std_logic_array21_array1         is array(natural range <>) of std_logic_array1( 20 downto 0);

type std_logic_array2_array2          is array(natural range <>) of std_logic_array2(1    downto 0);
type std_logic_array3_array2          is array(natural range <>) of std_logic_array2(2    downto 0);
type std_logic_array4_array2          is array(natural range <>) of std_logic_array2(3    downto 0);
type std_logic_array12_array2         is array(natural range <>) of std_logic_array2(11   downto 0);
type std_logic_array32_array2         is array(natural range <>) of std_logic_array2(31   downto 0);

type std_logic_array8_array3          is array(natural range <>) of std_logic_array3(7    downto 0);
type std_logic_array12_array3         is array(natural range <>) of std_logic_array3(11   downto 0);
type std_logic_array15_array3         is array(natural range <>) of std_logic_array3(14   downto 0);
type std_logic_array16_array3         is array(natural range <>) of std_logic_array3(15   downto 0);

type std_logic_array2_array4          is array(natural range <>) of std_logic_array4(1    downto 0); 
type std_logic_array3_array4          is array(natural range <>) of std_logic_array4(2    downto 0);
type std_logic_array5_array4          is array(natural range <>) of std_logic_array4(4    downto 0);                                                                                         
type std_logic_array8_array4          is array(natural range <>) of std_logic_array4(7    downto 0);
type std_logic_array12_array4         is array(natural range <>) of std_logic_array4(11   downto 0);
type std_logic_array16_array4         is array(natural range <>) of std_logic_array4(15   downto 0);
type std_logic_array23_array4         is array(natural range <>) of std_logic_array4(22   downto 0);
type std_logic_array32_array4         is array(natural range <>) of std_logic_array4(31   downto 0);
type std_logic_array273_array4        is array(natural range <>) of std_logic_array4(272  downto 0);
                                                                                          
type std_logic_array3_array5          is array(natural range <>) of std_logic_array5(2    downto 0);
type std_logic_array5_array5          is array(natural range <>) of std_logic_array5(4    downto 0);
type std_logic_array12_array5         is array(natural range <>) of std_logic_array5(11   downto 0);
type std_logic_array16_array5         is array(natural range <>) of std_logic_array5(15   downto 0);
type std_logic_array22_array5               is array(natural range <>) of std_logic_array5( 21 downto 0);

type std_logic_array2_array6          is array(natural range <>) of std_logic_array6(1    downto 0);
type std_logic_array3_array6          is array(natural range <>) of std_logic_array6(2    downto 0);
type std_logic_array16_array6         is array(natural range <>) of std_logic_array6(15   downto 0);
type std_logic_array23_array6         is array(natural range <>) of std_logic_array6(22   downto 0);
type std_logic_array32_array6         is array(natural range <>) of std_logic_array6(31   downto 0);
type std_logic_array3276_array6       is array(natural range <>) of std_logic_array6(3275 downto 0);

type std_logic_array2_array7          is array(natural range <>) of std_logic_array7(1    downto 0);
type std_logic_array3_array7          is array(natural range <>) of std_logic_array7(2    downto 0);
type std_logic_array4_array7          is array(natural range <>) of std_logic_array7(3    downto 0);
type std_logic_array8_array7          is array(natural range <>) of std_logic_array7(7    downto 0);
type std_logic_array12_array7         is array(natural range <>) of std_logic_array7(11   downto 0);
type std_logic_array16_array7         is array(natural range <>) of std_logic_array7(15   downto 0);
                                                                                          
type std_logic_array2_array8          is array(natural range <>) of std_logic_array8(1    downto 0);
type std_logic_array3_array8          is array(natural range <>) of std_logic_array8(2    downto 0);
type std_logic_array4_array8          is array(natural range <>) of std_logic_array8(3    downto 0);
type std_logic_array5_array8          is array(natural range <>) of std_logic_array8(4    downto 0);
type std_logic_array7_array8          is array(natural range <>) of std_logic_array8(6    downto 0);
type std_logic_array8_array8          is array(natural range <>) of std_logic_array8(7    downto 0);
type std_logic_array12_array8         is array(natural range <>) of std_logic_array8(11   downto 0);
type std_logic_array16_array8         is array(natural range <>) of std_logic_array8(15   downto 0);
type std_logic_array32_array8         is array(natural range <>) of std_logic_array8(31   downto 0);

type std_logic_array3_array9          is array(natural range <>) of std_logic_array9(2    downto 0);
type std_logic_array4_array9          is array(natural range <>) of std_logic_array9(3    downto 0);
type std_logic_array5_array9          is array(natural range <>) of std_logic_array9(4    downto 0);
type std_logic_array6_array9          is array(natural range <>) of std_logic_array9(5    downto 0);
type std_logic_array8_array9          is array(natural range <>) of std_logic_array9(7    downto 0);
type std_logic_array9_array9          is array(natural range <>) of std_logic_array9(8    downto 0);
type std_logic_array10_array9         is array(natural range <>) of std_logic_array9(9    downto 0);
type std_logic_array11_array9         is array(natural range <>) of std_logic_array9(10   downto 0);
type std_logic_array12_array9         is array(natural range <>) of std_logic_array9(11   downto 0);
type std_logic_array13_array9         is array(natural range <>) of std_logic_array9(12   downto 0);
type std_logic_array14_array9         is array(natural range <>) of std_logic_array9(13   downto 0);
type std_logic_array15_array9         is array(natural range <>) of std_logic_array9(14   downto 0);
type std_logic_array16_array9         is array(natural range <>) of std_logic_array9(15   downto 0);
type std_logic_array17_array9         is array(natural range <>) of std_logic_array9(16   downto 0);
type std_logic_array20_array9         is array(natural range <>) of std_logic_array9(19   downto 0);
type std_logic_array32_array9         is array(natural range <>) of std_logic_array9(31   downto 0);
type std_logic_array35_array9         is array(natural range <>) of std_logic_array9(34   downto 0);
type std_logic_array40_array9         is array(natural range <>) of std_logic_array9(39   downto 0);
                                                                                          
type std_logic_array2_array10         is array(natural range <>) of std_logic_array10(1   downto 0);
type std_logic_array3_array10         is array(natural range <>) of std_logic_array10(2   downto 0);
type std_logic_array5_array10         is array(natural range <>) of std_logic_array10(4   downto 0);
type std_logic_array6_array10         is array(natural range <>) of std_logic_array10(5   downto 0);
type std_logic_array7_array10         is array(natural range <>) of std_logic_array10(6   downto 0);
type std_logic_array8_array10         is array(natural range <>) of std_logic_array10(7   downto 0);
type std_logic_array9_array10         is array(natural range <>) of std_logic_array10(8   downto 0);
type std_logic_array10_array10        is array(natural range <>) of std_logic_array10(9   downto 0);
type std_logic_array12_array10        is array(natural range <>) of std_logic_array10(11  downto 0);
type std_logic_array16_array10        is array(natural range <>) of std_logic_array10(15  downto 0);
type std_logic_array17_array10        is array(natural range <>) of std_logic_array10(16  downto 0);
type std_logic_array20_array10        is array(natural range <>) of std_logic_array10(19  downto 0);
type std_logic_array24_array10        is array(natural range <>) of std_logic_array10(23  downto 0);
type std_logic_array32_array10        is array(natural range <>) of std_logic_array10(31  downto 0);
type std_logic_array35_array10        is array(natural range <>) of std_logic_array10(34  downto 0);

type std_logic_array2_array11         is array(natural range <>) of std_logic_array11(1   downto 0);
type std_logic_array3_array11         is array(natural range <>) of std_logic_array11(2   downto 0);
type std_logic_array8_array11         is array(natural range <>) of std_logic_array11(7   downto 0);
type std_logic_array16_array11        is array(natural range <>) of std_logic_array11(15  downto 0);
type std_logic_array32_array11        is array(natural range <>) of std_logic_array11(31  downto 0);
type std_logic_array273_array11       is array(natural range <>) of std_logic_array11(272 downto 0);

type std_logic_array2_array12         is array(natural range <>) of std_logic_array12(1   downto 0);
type std_logic_array3_array12         is array(natural range <>) of std_logic_array12(2   downto 0);
type std_logic_array4_array12         is array(natural range <>) of std_logic_array12(3   downto 0);
type std_logic_array5_array12         is array(natural range <>) of std_logic_array12(4   downto 0);
type std_logic_array8_array12         is array(natural range <>) of std_logic_array12(7   downto 0);
type std_logic_array12_array12        is array(natural range <>) of std_logic_array12(11  downto 0);
type std_logic_array16_array12        is array(natural range <>) of std_logic_array12(15  downto 0);
type std_logic_array32_array12        is array(natural range <>) of std_logic_array12(31  downto 0);

type std_logic_array2_array13         is array(natural range <>) of std_logic_array13(1   downto 0);
type std_logic_array3_array13         is array(natural range <>) of std_logic_array13(2   downto 0);
type std_logic_array5_array13         is array(natural range <>) of std_logic_array13(4   downto 0);
type std_logic_array16_array13        is array(natural range <>) of std_logic_array13(15  downto 0);
type std_logic_array32_array13        is array(natural range <>) of std_logic_array13(31  downto 0);

type std_logic_array2_array14         is array(natural range <>) of std_logic_array14(1   downto 0);
type std_logic_array3_array14         is array(natural range <>) of std_logic_array14(2   downto 0);
type std_logic_array4_array14         is array(natural range <>) of std_logic_array14(3   downto 0);
type std_logic_array5_array14         is array(natural range <>) of std_logic_array14(4   downto 0);
type std_logic_array8_array14         is array(natural range <>) of std_logic_array14(7   downto 0);
type std_logic_array16_array14        is array(natural range <>) of std_logic_array14(15  downto 0);
type std_logic_array24_array14        is array(natural range <>) of std_logic_array14(23  downto 0);
                                                                                          
type std_logic_array2_array15         is array(natural range <>) of std_logic_array15(1   downto 0);
type std_logic_array3_array15         is array(natural range <>) of std_logic_array15(2   downto 0);
type std_logic_array4_array15         is array(natural range <>) of std_logic_array15(3   downto 0);
type std_logic_array5_array15         is array(natural range <>) of std_logic_array15(4   downto 0);
type std_logic_array6_array15         is array(natural range <>) of std_logic_array15(5   downto 0);
type std_logic_array7_array15         is array(natural range <>) of std_logic_array15(6   downto 0);
type std_logic_array8_array15         is array(natural range <>) of std_logic_array15(7   downto 0);
type std_logic_array12_array15        is array(natural range <>) of std_logic_array15(11  downto 0);
type std_logic_array15_array15        is array(natural range <>) of std_logic_array15(14  downto 0);
type std_logic_array16_array15        is array(natural range <>) of std_logic_array16(14  downto 0);
type std_logic_array64_array15        is array(natural range <>) of std_logic_array15(63  downto 0);

type std_logic_array2_array16         is array(natural range <>) of std_logic_array16(1   downto 0); 
type std_logic_array3_array16         is array(natural range <>) of std_logic_array16(2   downto 0);
type std_logic_array4_array16         is array(natural range <>) of std_logic_array16(3   downto 0);
type std_logic_array5_array16         is array(natural range <>) of std_logic_array16(4   downto 0);
type std_logic_array6_array16         is array(natural range <>) of std_logic_array16(5   downto 0);
type std_logic_array7_array16         is array(natural range <>) of std_logic_array16(6   downto 0);
type std_logic_array8_array16         is array(natural range <>) of std_logic_array16(7   downto 0);
type std_logic_array10_array16        is array(natural range <>) of std_logic_array16(9   downto 0);
type std_logic_array12_array16        is array(natural range <>) of std_logic_array16(11  downto 0);
type std_logic_array13_array16        is array(natural range <>) of std_logic_array16(12  downto 0);
type std_logic_array14_array16        is array(natural range <>) of std_logic_array16(13  downto 0);
type std_logic_array15_array16        is array(natural range <>) of std_logic_array16(14  downto 0);
type std_logic_array16_array16        is array(natural range <>) of std_logic_array16(15  downto 0);
type std_logic_array17_array16        is array(natural range <>) of std_logic_array16(16  downto 0);
type std_logic_array20_array16        is array(natural range <>) of std_logic_array16(19  downto 0);
type std_logic_array24_array16        is array(natural range <>) of std_logic_array16(23  downto 0);
type std_logic_array28_array16              is array(natural range <>) of std_logic_array16(27 downto 0);
type std_logic_array29_array16        is array(natural range <>) of std_logic_array16(28  downto 0);
type std_logic_array30_array16        is array(natural range <>) of std_logic_array16(29  downto 0);
type std_logic_array32_array16        is array(natural range <>) of std_logic_array16(31  downto 0);
type std_logic_array35_array16        is array(natural range <>) of std_logic_array16(34  downto 0);
type std_logic_array48_array16        is array(natural range <>) of std_logic_array16(47  downto 0);
type std_logic_array60_array16        is array(natural range <>) of std_logic_array16(59  downto 0);
type std_logic_array64_array16        is array(natural range <>) of std_logic_array16(63  downto 0);
                      
type std_logic_array2_array17         is array(natural range <>) of std_logic_array17(1   downto 0);
type std_logic_array3_array17         is array(natural range <>) of std_logic_array17(2   downto 0);
type std_logic_array5_array17         is array(natural range <>) of std_logic_array17(4   downto 0);		                                                                          
type std_logic_array15_array17        is array(natural range <>) of std_logic_array17(14  downto 0);

type std_logic_array2_array18         is array(natural range <>) of std_logic_array18(1   downto 0);
type std_logic_array5_array18         is array(natural range <>) of std_logic_array18(4   downto 0);

type std_logic_array2_array19         is array(natural range <>) of std_logic_array19(1   downto 0);
type std_logic_array5_array19         is array(natural range <>) of std_logic_array19(4   downto 0);
type std_logic_array6_array19         is array(natural range <>) of std_logic_array19(5   downto 0);
type std_logic_array8_array19         is array(natural range <>) of std_logic_array19(7   downto 0);
                               
type std_logic_array2_array20         is array(natural range <>) of std_logic_array20( 1 downto 0);
type std_logic_array3_array20         is array(natural range <>) of std_logic_array20( 2 downto 0);
type std_logic_array4_array20         is array(natural range <>) of std_logic_array20( 3 downto 0);
type std_logic_array5_array20         is array(natural range <>) of std_logic_array20( 4 downto 0);
type std_logic_array9_array20         is array(natural range <>) of std_logic_array20( 8 downto 0);
type std_logic_array12_array20        is array(natural range <>) of std_logic_array20(11 downto 0);

type std_logic_array5_array22         is array(natural range <>) of std_logic_array22( 4 downto 0);
type std_logic_array16_array22        is array(natural range <>) of std_logic_array22(15 downto 0);
    
type std_logic_array8_array24         is array(natural range <>) of std_logic_array24(7   downto 0);
type std_logic_array16_array24        is array(natural range <>) of std_logic_array24(15  downto 0);
type std_logic_array32_array24        is array(natural range <>) of std_logic_array24(31 downto 0);

type std_logic_array3_array25         is array(natural range <>) of std_logic_array25( 2 downto 0);
type std_logic_array5_array25         is array(natural range <>) of std_logic_array25( 4 downto 0);

type std_logic_array2_array26         is array(natural range <>) of std_logic_array26( 1 downto 0);
type std_logic_array3_array26         is array(natural range <>) of std_logic_array26( 2 downto 0);

type std_logic_array2_array27         is array(natural range <>) of std_logic_array27( 1 downto 0);
type std_logic_array3_array27         is array(natural range <>) of std_logic_array27( 2 downto 0);
type std_logic_array4_array27         is array(natural range <>) of std_logic_array27( 3 downto 0);
type std_logic_array8_array27         is array(natural range <>) of std_logic_array27( 7 downto 0);
type std_logic_array10_array27        is array(natural range <>) of std_logic_array27( 9 downto 0);
type std_logic_array13_array27        is array(natural range <>) of std_logic_array27(12 downto 0);
type std_logic_array14_array27        is array(natural range <>) of std_logic_array27(13 downto 0);
type std_logic_array16_array27        is array(natural range <>) of std_logic_array27(15 downto 0);
type std_logic_array29_array27        is array(natural range <>) of std_logic_array27(28 downto 0);
             
type std_logic_array2_array29         is array(natural range <>) of std_logic_array29(1   downto 0);
type std_logic_array3_array29         is array(natural range <>) of std_logic_array29(2   downto 0);

type std_logic_array2_array30         is array(natural range <>) of std_logic_array30(1 downto 0);   	                                                                                      
type std_logic_array3_array30         is array(natural range <>) of std_logic_array30(2   downto 0);
type std_logic_array5_array30         is array(natural range <>) of std_logic_array30(4   downto 0);
type std_logic_array6_array30         is array(natural range <>) of std_logic_array30(5   downto 0);
type std_logic_array7_array30         is array(natural range <>) of std_logic_array30(6   downto 0);
type std_logic_array8_array30         is array(natural range <>) of std_logic_array30(7   downto 0);
type std_logic_array9_array30         is array(natural range <>) of std_logic_array30(8   downto 0);
type std_logic_array12_array30        is array(natural range <>) of std_logic_array30(11  downto 0);
type std_logic_array14_array30        is array(natural range <>) of std_logic_array30(13  downto 0);
type std_logic_array15_array30        is array(natural range <>) of std_logic_array30(14  downto 0);
type std_logic_array16_array30        is array(natural range <>) of std_logic_array30(15  downto 0);
type std_logic_array17_array30        is array(natural range <>) of std_logic_array30(16  downto 0);
type std_logic_array18_array30        is array(natural range <>) of std_logic_array30(17  downto 0);
type std_logic_array22_array30        is array(natural range <>) of std_logic_array30(21  downto 0);
type std_logic_array23_array30        is array(natural range <>) of std_logic_array30(22  downto 0);
type std_logic_array25_array30        is array(natural range <>) of std_logic_array30(24  downto 0);
type std_logic_array29_array30        is array(natural range <>) of std_logic_array30(28  downto 0);
type std_logic_array31_array30        is array(natural range <>) of std_logic_array30(30  downto 0);

type std_logic_array4_array31               is array(natural range <>) of std_logic_array31(3   downto 0);
type std_logic_array5_array31               is array(natural range <>) of std_logic_array31(4   downto 0);

type std_logic_array2_array32               is array(natural range <>) of std_logic_array32(1   downto 0);
type std_logic_array4_array32               is array(natural range <>) of std_logic_array32(3   downto 0);
type std_logic_array6_array32               is array(natural range <>) of std_logic_array32(5   downto 0);
type std_logic_array8_array32               is array(natural range <>) of std_logic_array32(7   downto 0);
type std_logic_array10_array32              is array(natural range <>) of std_logic_array32(9   downto 0);
type std_logic_array12_array32              is array(natural range <>) of std_logic_array32(11  downto 0);
type std_logic_array14_array32              is array(natural range <>) of std_logic_array32(13 downto 0);
type std_logic_array16_array32              is array(natural range <>) of std_logic_array32(15  downto 0);
type std_logic_array17_array32              is array(natural range <>) of std_logic_array32(16  downto 0);
type std_logic_array20_array32              is array(natural range <>) of std_logic_array32(19  downto 0);
type std_logic_array22_array32              is array(natural range <>) of std_logic_array32(21 downto 0);
type std_logic_array24_array32              is array(natural range <>) of std_logic_array32(23  downto 0);
type std_logic_array28_array32              is array(natural range <>) of std_logic_array32(27 downto  0);
type std_logic_array32_array32              is array(natural range <>) of std_logic_array32(31  downto 0);
type std_logic_array35_array32              is array(natural range <>) of std_logic_array32(34  downto 0);
type std_logic_array40_array32              is array(natural range <>) of std_logic_array32(39  downto 0);
type std_logic_array64_array32              is array(natural range <>) of std_logic_array32(63  downto 0);
                                                                                                
--type std_logic_array24_array32              is array(natural range <>) of std_logic_array32(23  downto 0);
--type std_logic_array32_array32              is array(natural range <>) of std_logic_array32(31  downto 0);
type std_logic_array5_array34               is array(natural range <>) of std_logic_array34(4   downto 0);
type std_logic_array4_array47               is array(natural range <>) of std_logic_array47(3   downto 0);

type std_logic_array2_array48               is array(natural range <>) of std_logic_array48(1   downto 0);
type std_logic_array8_array48               is array(natural range <>) of std_logic_array48(7   downto 0);
type std_logic_array16_array48              is array(natural range <>) of std_logic_array48(15  downto 0);

type std_logic_array16_array60              is array(natural range <>) of std_logic_array60(15  downto 0);

type std_logic_array4_array64               is array(natural range <>) of std_logic_array64( 3 downto 0);
type std_logic_array5_array64               is array(natural range <>) of std_logic_array64(4   downto 0);
type std_logic_array8_array64               is array(natural range <>) of std_logic_array64(7   downto 0);
    
type std_logic_array14_array12_array4       is array(natural range <>) of std_logic_array12_array4(13    downto 0);
type std_logic_array32_array16_array6       is array(natural range <>) of std_logic_array16_array6(31    downto 0);
type std_logic_array4_array12_array7        is array(natural range <>) of std_logic_array12_array7(3     downto 0);
type std_logic_array8_array12_array7        is array(natural range <>) of std_logic_array12_array7(7     downto 0);
type std_logic_array8_array32_array8        is array(natural range <>) of std_logic_array32_array8( 7 downto 0);
type std_logic_array16_array16_array7       is array(natural range <>) of std_logic_array16_array7(15    downto 0);
type std_logic_array8_array24_array10       is array(natural range <>) of std_logic_array24_array10(7    downto 0);
type std_logic_array8_array8_array11        is array(natural range <>) of std_logic_array8_array11(7     downto 0);
type std_logic_array32_array8_array11       is array(natural range <>) of std_logic_array8_array11(31 downto 0);
type std_logic_array2_array16_array12       is array(natural range <>) of std_logic_array16_array12(   1 downto 0);
type std_logic_array8_array8_array24        is array(natural range <>) of std_logic_array8_array24(7     downto 0);
type std_logic_array32_array8_array24       is array(natural range <>) of std_logic_array8_array24(31 downto 0);
type std_logic_array2_array8_array32        is array(natural range <>) of std_logic_array8_array32(    1 downto 0);
type std_logic_array8_array8_array32        is array(natural range <>) of std_logic_array8_array32(    7 downto 0);
type std_logic_array32_array8_array32       is array(natural range <>) of std_logic_array8_array32(31 downto 0);
type std_logic_array4_array12_array32       is array(natural range <>) of std_logic_array12_array32(3    downto 0);
type std_logic_array8_array12_array32       is array(natural range <>) of std_logic_array12_array32(7    downto 0);
type std_logic_array32_array12_array32      is array(natural range <>) of std_logic_array12_array32(31   downto 0);
type std_logic_array16_array16_array32      is array(natural range <>) of std_logic_array16_array32(15   downto 0);
type std_logic_array32_array16_array32      is array(natural range <>) of std_logic_array16_array32(31   downto 0);
type std_logic_array8_array24_array32       is array(natural range <>) of std_logic_array24_array32(7    downto 0);
type std_logic_array8_array32_array32       is array(natural range <>) of std_logic_array32_array32( 7 downto 0);
type std_logic_array1200_array32_array32    is array(natural range <>) of std_logic_array32_array32(1199 downto 0);
    
type std_logic_array256_array32_array10   is array(natural range <>) of std_logic_array32_array10(255 downto 0);

type std_logic_array136_array16       is array(natural range <>) of std_logic_array16(135 downto 0);

type std_logic_array2_array24_array32   is array(natural range <>) of std_logic_array24_array32(1 downto 0);

type std_logic_array8_array32_array8_array11 is array(natural range <>) of std_logic_array32_array8_array11(7 downto 0);
type std_logic_array8_array32_array8_array24 is array(natural range <>) of std_logic_array32_array8_array24(7 downto 0);
type std_logic_array8_array32_array8_array32 is array(natural range <>) of std_logic_array32_array8_array32(7 downto 0);

type natural1228800_array             is array(natural range <>) of natural range 0 to 1228800;      

end FFT_ARRAY_TYPE;



package body FFT_ARRAY_TYPE is

end FFT_ARRAY_TYPE;
