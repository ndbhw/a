-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: DLFE
-- File Name		: fft_1024_512.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- Available for 1024/512 FFT Size
-- Number of DSP Slice:       THREE			|      	FOUR			|      	Xtreme			|       
-- Latency at 1024: 	1076 clock cycle	|	1072 clock cycle	|	1096 clock cycle	|
-- Latency at 512 : 	 563 clock cycle	|	 559 clock cycle	|	 580 clock cycle	|
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)     
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_signed.all;
use work.FFT_FUNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity fft_1024_512 is 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "FOUR";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 26);				-- [ Output Data Bit Width Parameter  	]  
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic;	-- "0" = 512, "1" = 1024, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end fft_1024_512;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of fft_1024_512 is

	component r22_sdf
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		IN_WIDTH			: integer;						-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;						-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);						-- [ O_SYNC Timing Delay Parameter	 ]     
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;
	
	component hybrid_r22_sdf
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Extreme dsp mode					] false or true 
		IN_WIDTH			: integer;						-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;						-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);						-- [ O_SYNC Timing Delay Parameter	 ]       
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;	
		
	component hybrid_tw_phaser
	generic (
		DEVICE          : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component tw_phaser
	generic (
		DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		BF_TYPE			: string  := "Radix22"; 	-- "Radix22" or "Radix2"  
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
		
	constant nIFFT_FFT_SEL      : boolean := ternary_func(FFT_TYPE = "FFT", true, false);    
	constant N_DSP48_XTREME_CHECK : string := ternary_func(XTREME_DSP_MODE = false, N_DSP48_PER_CMULT, "FOUR");
	constant CMULT_N_DSP48		: natural := ternary_func(N_DSP48_XTREME_CHECK = "THREE", 3, 4);
	constant STG5_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG4_IN_WIDTH 		: integer := (IN_WIDTH + 2);
	constant STG3_IN_WIDTH 		: integer := (IN_WIDTH + 4);
	constant STG2_IN_WIDTH 		: integer := (IN_WIDTH + 6);
	constant STG1_IN_WIDTH 		: integer := (IN_WIDTH + 8);
	
	constant STG5_N_SIZE	: integer := 1024;
	constant STG4_N_SIZE	: integer := 256;
	constant STG3_N_SIZE	: integer := 64;
	constant STG2_N_SIZE	: integer := 16;
	constant STG1_N_SIZE	: integer := 4;
	
	
	constant R22_SDF_O_SYNC_TIMING						: integer := ternary_func(XTREME_DSP_MODE = true, 2, -5); 
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP	: integer := ternary_func(XTREME_DSP_MODE = true, 10, 11);   
	constant TW_PHASER_O_SYNC_TIMING_FOUR_DSP			: integer := ternary_func(XTREME_DSP_MODE = true, 9, 10);   
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP	: integer := ternary_func(XTREME_DSP_MODE = true, 11, 12);  
	constant TW_PHASER_O_SYNC_TIMING_THREE_DSP			: integer := ternary_func(XTREME_DSP_MODE = true, 10, 11); 
	
	constant HYBRID_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP, HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   
	constant TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", TW_PHASER_O_SYNC_TIMING_THREE_DSP, TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   
	constant LAST_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_XTREME_CHECK = "THREE", 11, 10);   

	
	signal stg5_radix2_radix22_sel	: std_logic;
	
	signal stg5_isync		: std_logic;
	signal stg5_di_re		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_di_im		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_osync		: std_logic;
	signal stg5_do_re		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal stg5_do_im		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal tw5_osync		: std_logic;                                   
	signal tw5_do_re		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal tw5_do_im		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal stg4_osync		: std_logic;
	signal stg4_do_re		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal stg4_do_im		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal tw4_osync		: std_logic;                                   
	signal tw4_do_re		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal tw4_do_im		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal stg3_osync		: std_logic;
	signal stg3_do_re		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal stg3_do_im		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal tw3_osync		: std_logic;                                   
	signal tw3_do_re		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal tw3_do_im		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal stg2_osync		: std_logic;
	signal stg2_do_re		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal stg2_do_im		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal tw2_osync		: std_logic;                                   
	signal tw2_do_re		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal tw2_do_im		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal stg1_osync		: std_logic;
	signal stg1_do_re		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	signal stg1_do_im		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	
begin
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			stg5_radix2_radix22_sel <= I_NFFT_SEL;
		end if;
	end process;	
	
	g_FFT_IN : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then			
			stg5_di_re <= I_DATA_RE;
			stg5_di_im <= I_DATA_IM;
		end if;
	end process;
    end generate;
    
    g_iFFT_IN : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			stg5_di_re <= I_DATA_RE;
			stg5_di_im <= (not I_DATA_IM) + 1;
		end if;	
	end process;
	end generate;	
	
	g_FFT_IN_DSP : if XTREME_DSP_MODE = true generate -- DSP Butterfly(Xtream DSP) Mode		
	stg5_isync <= I_SYNC;
    end generate;
    
    g_FFT_IN_LUT : if XTREME_DSP_MODE = false generate -- LUT Butterfly mode
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			stg5_isync <= I_SYNC;
		end if;	
	end process;
	end generate;	
	
	U_FFT_STG5: hybrid_r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		IN_WIDTH		=> STG5_IN_WIDTH			,	-- [ Input Data Bit Width Parameter	]                 
		N_SIZE			=> STG5_N_SIZE				,	-- [ FFT Point Size Parameter      	]   
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_isync,
		I_DATA_RE	=> stg5_di_re,  
		I_DATA_IM	=> stg5_di_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel, 
		O_SYNC		=> stg5_osync,
		O_DATA_RE	=> stg5_do_re,
		O_DATA_IM	=> stg5_do_im);		
		
	U_FFT_STG5_TW : hybrid_tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "block", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_256.mem", 
		IN_WIDTH		=> (STG5_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG5_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG5_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> HYBRID_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_osync,
		I_DATA_RE	=> stg5_do_re,
		I_DATA_IM	=> stg5_do_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel,
		O_SYNC		=> tw5_osync,
		O_DATA_RE	=> tw5_do_re,
		O_DATA_IM	=> tw5_do_im);
			
	U_FFT_STG4: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		IN_WIDTH		=> STG4_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG4_N_SIZE		,			-- [ FFT Point Size Parameter       ]   
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]     
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw5_osync,
		I_DATA_RE	=> tw5_do_re,  
		I_DATA_IM	=> tw5_do_im,  
		O_SYNC		=> stg4_osync,
		O_DATA_RE	=> stg4_do_re,
		O_DATA_IM	=> stg4_do_im);		
		
	U_FFT_STG4_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_64.mem", 
		IN_WIDTH		=> (STG4_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG4_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG4_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg4_osync,
		I_DATA_RE	=> stg4_do_re,
		I_DATA_IM	=> stg4_do_im, 
		O_SYNC		=> tw4_osync,
		O_DATA_RE	=> tw4_do_re,
		O_DATA_IM	=> tw4_do_im);
	
	U_FFT_STG3: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		IN_WIDTH		=> STG3_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG3_N_SIZE		,			-- [ FFT Point Size Parameter       ]    
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]  
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw4_osync,
		I_DATA_RE	=> tw4_do_re,  
		I_DATA_IM	=> tw4_do_im,  
		O_SYNC		=> stg3_osync,
		O_DATA_RE	=> stg3_do_re,
		O_DATA_IM	=> stg3_do_im);		
				
	U_FFT_STG3_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_16.mem", 
		IN_WIDTH		=> (STG3_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG3_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG3_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg3_osync,
		I_DATA_RE	=> stg3_do_re,
		I_DATA_IM	=> stg3_do_im, 
		O_SYNC		=> tw3_osync,
		O_DATA_RE	=> tw3_do_re,
		O_DATA_IM	=> tw3_do_im);	
	
	U_FFT_STG2: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 					-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> XTREME_DSP_MODE			,	-- [ Extream dsp mode				] false or true 
		IN_WIDTH		=> STG2_IN_WIDTH	,			-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG2_N_SIZE		,			-- [ FFT Point Size Parameter       ]   
		OSYNC_DELAY		=> R22_SDF_O_SYNC_TIMING	)	-- [ O_SYNC Timing Delay Parameter	]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw3_osync,
		I_DATA_RE	=> tw3_do_re,  
		I_DATA_IM	=> tw3_do_im,  
		O_SYNC		=> stg2_osync,
		O_DATA_RE	=> stg2_do_re,
		O_DATA_IM	=> stg2_do_im);		
				
	U_FFT_STG2_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_4.mem", 
		IN_WIDTH		=> (STG2_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG2_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG2_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> LAST_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg2_osync,
		I_DATA_RE	=> stg2_do_re,
		I_DATA_IM	=> stg2_do_im, 
		O_SYNC		=> tw2_osync,
		O_DATA_RE	=> tw2_do_re,
		O_DATA_IM	=> tw2_do_im);			
		
	U_FFT_STG1: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE	=> false			,	-- [ Extream dsp mode		] false or true 
		IN_WIDTH		=> STG1_IN_WIDTH	,	-- [ Input Data Bit Width Parameter ]                 
		N_SIZE			=> STG1_N_SIZE		,	-- [ FFT Point Size Parameter       ]   
		OSYNC_DELAY		=> -1        )			-- [ O_SYNC Timing Delay Parameter	]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw2_osync,
		I_DATA_RE	=> tw2_do_re,  
		I_DATA_IM	=> tw2_do_im,  
		O_SYNC		=> stg1_osync,
		O_DATA_RE	=> stg1_do_re  ,
		O_DATA_IM	=> stg1_do_im  );			
		
	g_FFT_OUT : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC	<= stg1_osync; 
			O_DATA_RE	<= stg1_do_re; 
			O_DATA_IM	<= stg1_do_im; 
		end if;
	end process;
    end generate;
    
    g_iFFT_OUT : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC	<= stg1_osync; 
			O_DATA_RE	<= stg1_do_re; 
			O_DATA_IM	<= (not stg1_do_im) + 1; 
		end if;
	end process;
	end generate;
		
end struct;
-------------------------------------------------------------------------------------------------------------------------------

