-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix22 SDF Component
-- File Name		: r22_bf_ctrl.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)     
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all; use ieee.std_logic_arith.all;
use work.FFT_FUNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity r22_bf_ctrl is 
	generic (           
		N_SIZE			: integer;		-- [ FFT Point Size Parameter   	] 
		XTREME_DSP_MODE	: boolean;		-- [ Xtreme dsp mode				] false or true 	
		OSYNC_DELAY		: integer);		-- [ O_SYNC Timing Delay Parameter	]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB  		: in std_logic; 	-- system reset(low activated)
		I_CLK	  		: in std_logic;		-- main clock
		I_SYNC			: in std_logic;
      	-- *************************************************************
      	-- TO FFT_STG0 module
      	-- *************************************************************
		O_BFI_CTRL_S	: out std_logic;
		O_BFII_CTRL_S	: out std_logic;
		O_BFII_CTRL_T	: out std_logic;
		O_SYNC	  		: out std_logic
	);
end r22_bf_ctrl;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of r22_bf_ctrl is
		
	constant MSBIT				: integer := integer(ceil(log2(real(N_SIZE))));
	constant CNT_MSB        	: integer := ternary_func(N_SIZE /= 4, (MSBIT-1), MSBIT);    
	constant BFII_STAGE_TRIGGER	: integer := ternary_func(XTREME_DSP_MODE = true, (N_SIZE/2 + 3), (N_SIZE/2 - 1));  
	
	signal osync_timing_cnt	: std_logic_vector(CNT_MSB downto 0) := conv_std_logic_vector(((N_SIZE/2) + (N_SIZE/4) + OSYNC_DELAY + 1), (CNT_MSB+1));
	signal osync_en			: std_logic;
	signal bfi_stage_cnt	: std_logic_vector(CNT_MSB downto 0);
	signal bfii_stage_cnt	: std_logic_vector(CNT_MSB downto 0);
	
begin

	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				osync_en <= '0';
			elsif I_SYNC = '1' then
				osync_en <= '1';
			elsif bfi_stage_cnt = osync_timing_cnt then
				osync_en <= '0';
			end if;
		end if;
	end process;
	
	-- *************************************************************
    -- Butterfly I Control
   	-- *************************************************************
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' or I_SYNC = '1' then
				bfi_stage_cnt <= (others => '0');	
			else
				bfi_stage_cnt <= bfi_stage_cnt + '1';
			end if;
		end if;
	end process;
	
	O_BFI_CTRL_S 	<= bfi_stage_cnt(MSBIT - 1);
	
	-- *************************************************************
    -- Butterfly II Control
   	-- *************************************************************
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' or bfi_stage_cnt = BFII_STAGE_TRIGGER then
				bfii_stage_cnt <= (others => '0');	
			else
				bfii_stage_cnt <= bfii_stage_cnt + '1';
			end if;
		end if;
	end process;
	
	O_BFII_CTRL_S 	<= bfii_stage_cnt(MSBIT - 1);
	O_BFII_CTRL_T 	<= bfii_stage_cnt(MSBIT - 2);
	-- *************************************************************
    -- Out Sync
   	-- *************************************************************	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if bfi_stage_cnt = osync_timing_cnt and osync_en = '1' and I_RSTB = '1' then
				O_SYNC <= '1';
			else 
				O_SYNC <= '0'; 
			end if;
		end if;
	end process;
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------
