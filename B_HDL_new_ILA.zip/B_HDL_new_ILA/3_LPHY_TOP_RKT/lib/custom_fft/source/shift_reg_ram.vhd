-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: General FFT Component
-- File Name		: shift_reg_ram.VHD
-- Date				: 2022.01.04
-- Revision			: 1
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 	  The block include list below
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all;

-------------------------------------------------------------------------------------------------------------------------------
entity shift_reg_ram is 
	generic (
    	RAM_TYPE            : string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
    	OPERATING_MODE      : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"
		MEM_WIDTH			: integer;  -- [ Input Data Bit Width Parameter  ]
		MEM_DEPTH			: integer; 	-- [ Shift Register Depth        ]
		SHFT_DEPTH			: integer); -- [ Shift Register Depth        ]
	PORT (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA			: in std_logic_vector((MEM_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA			: out std_logic_vector((MEM_WIDTH-1) downto 0));
end shift_reg_ram;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of shift_reg_ram is

	constant DELAY_OFFSET : integer := (MEM_DEPTH - SHFT_DEPTH) + 3;
	constant ADDR_MSB	  : integer := integer(floor(log2(real(MEM_DEPTH-1))));
	
	component FFT_SIMPLE_DPRAM
	generic (
    	RAM_TYPE                    : string  := "block"       ; -- "auto" or "distributed" or "block" or "ultra" 
    	CLOCKING_MODE               : string  := "common_clock"; -- "common_clock" or "independent_clock"
    	OPERATING_MODE              : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"
    	ADDR_DEPTH                  : integer :=  1024         ;
    	DATA_WIDTH                  : integer :=     8         ;
    	READ_LATENCY                : integer :=     2         ;
    	RAM_INIT_FILE               : string  := "none"        ; 
    	RAM_INIT_VALUE              : string  := "0"    	  );         
	port (	
    	I_CLK_A                       : in  std_logic;
    	I_EN_A                        : in  std_logic;
    	I_WE_A                        : in  std_logic;
    	I_ADDR_A                      : in  std_logic_vector(integer(floor(log2(real(ADDR_DEPTH-1)))) downto 0);
    	I_DATA_A                      : in  std_logic_vector(DATA_WIDTH-1 downto 0);
    	
    	I_CLK_B                       : in  std_logic;
    	I_EN_B                        : in  std_logic;
    	I_ADDR_B                      : in  std_logic_vector(integer(floor(log2(real(ADDR_DEPTH-1)))) downto 0);
    	I_DATA_B                      : out std_logic_vector(DATA_WIDTH-1 downto 0));  
	end component;
	
	signal addr_a   : std_logic_vector(ADDR_MSB downto 0) := (others => '0');
	signal addr_b   : std_logic_vector(ADDR_MSB downto 0) := (others => '0');
	
begin
			
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			addr_a <= addr_a + '1';
			addr_b <= addr_a + DELAY_OFFSET;
		end if;
	end process;
	
    U_SHFT : FFT_SIMPLE_DPRAM
	generic map ( 
    	RAM_TYPE           => RAM_TYPE       	, -- "auto" or "distributed" or "block" or "ultra" 
    	CLOCKING_MODE      => "common_clock"	, -- "common_clock" or "independent_clock"
    	OPERATING_MODE     => OPERATING_MODE	, -- "no_change" or "read_first" or "write_first"
    	ADDR_DEPTH         => MEM_DEPTH       	,
    	DATA_WIDTH         => MEM_WIDTH        	,
    	READ_LATENCY       =>     2         	,
    	RAM_INIT_FILE      => "none"        	, 
    	RAM_INIT_VALUE     => "0"    	    	)
	port map (
		I_CLK_A   => I_CLK,   
	    I_EN_A    => '1',   
	    I_WE_A    => '1',   
	    I_ADDR_A  => addr_a,  
	    I_DATA_A  => I_DATA,   
	    I_CLK_B   => I_CLK,  
	    I_EN_B    => '1',    
	    I_ADDR_B  => addr_b,  
	    I_DATA_B  => O_DATA);

end struct;
-------------------------------------------------------------------------------------------------------------------------------

