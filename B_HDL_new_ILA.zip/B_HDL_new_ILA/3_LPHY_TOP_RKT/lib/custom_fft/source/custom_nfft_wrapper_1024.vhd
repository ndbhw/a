-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: DLFE
-- File Name		: nfft_wrapper.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- Available for 1024/512 FFT Size
-- Number of DSP Slice:       THREE			|      	FOUR			|      	Xtreme			|       
-- Latency at 1024: 	1076 clock cycle	|	1072 clock cycle	|	1096 clock cycle	|
-- Latency at 512 : 	 563 clock cycle	|	 559 clock cycle	|	 580 clock cycle	|
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)     
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_signed.all;
use work.FFT_FUNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity custom_nfft_wrapper_1024 is 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "FOUR";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= True;			-- [ Xtreme dsp mode					] false or true 
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 26);				-- [ Output Data Bit Width Parameter  	] OUT_WIDTH = IN_WIDTH + log2(N_FFT)  
	port (
		I_RSTB			: in std_logic; 									-- Synchronous Active High Reset
		I_CLK			: in std_logic;										-- System Clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_DATA_SYNC		: in std_logic;										-- 1 clk cycle prior to input data [idx 0]
		I_DATA_VLD		: in std_logic;										-- input data aligned enable
		I_DATA_I  		: in std_logic_vector((IN_WIDTH-1) downto 0);		-- input data i
		I_DATA_Q  		: in std_logic_vector((IN_WIDTH-1) downto 0);		-- input data q
		-- *************************************************************
		-- Control DATA
		-- *************************************************************	-- [I_nFFT_TYPE] received on [I_DATA_SYNC]	
		I_nFFT_TYPE		: in std_logic; 									-- "0" = 512, "1" = 1024
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_DATA_SYNC		: out std_logic;									-- 1 clk cycle prior to input data [idx 0]
		O_DATA_VLD		: out std_logic;									-- output data aligned enable
		O_DATA_IDX		: out std_logic_vector(9 downto 0);					-- output data index
		O_DATA_I  		: out std_logic_vector((OUT_WIDTH-1) downto 0); 	-- output data i
		O_DATA_Q 		: out std_logic_vector((OUT_WIDTH-1) downto 0);		-- output data q
		O_DATA_LAST		: out std_logic;	
		-- *************************************************************
		-- STATUS DATA
		-- *************************************************************	
		O_STATUS_NOT_READY_TO_CHANGE_MODE				: out std_logic;    -- processing on previous symbol, unacceptable with new fft size
		O_STATUS_EXTENDED_INPUT_DATA					: out std_logic;	-- given input data is longer than expected, then extended data just ignored
		O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED		: out std_logic;	-- given input data is shorter or discounited, then system halt 
		O_EVENT_I_SYNC_UNEXPECTED						: out std_logic;	-- given input sync is too early, then ignore previous symbol, restart with current symbol 
		O_EVENT_NOT_READY_TO_CHANGE_TYPE				: out std_logic);   -- not ready to change mode, then ignore current symbol, countinue working on previous symbol 
end custom_nfft_wrapper_1024;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of custom_nfft_wrapper_1024 is	

	component fft_1024_512 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "FOUR";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		XTREME_DSP_MODE		: boolean	:= false;			-- [ Xtreme dsp mode					] false or true 
		IN_WIDTH			: integer 	:= 16;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 26);				-- [ Output Data Bit Width Parameter  	] OUT_WIDTH = IN_WIDTH + log2(N_FFT)
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic;						-- "0" = 512, "1" = 1024
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	signal i_data_sync_d1		: std_logic;							
	signal i_data_i_d1	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d1	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_sync_d2		: std_logic;							
	signal i_data_i_d2	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d2	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_sync_d3		: std_logic;							
	signal i_data_i_d3	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_data_q_d3	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_fft_sync			: std_logic;							
	signal i_fft_data_i	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal i_fft_data_q	  		: std_logic_vector((IN_WIDTH-1) downto 0);
	signal o_fft_sync       	: std_logic := '0';							       
	signal n_fft_sel 			: std_logic := '0';	
	signal tmp_n_fft_sel		: std_logic := '0';	
	signal i_data_idx_max 		: std_logic_vector(9 downto 0)	:= (others => '0');
	signal i_data_idx 			: std_logic_vector(9 downto 0)	:= (others => '0');
	signal i_sync_unexpected 	: std_logic := '0'; 
	signal i_data_vld_missing 	: std_logic := '0'; 
	signal fft_reset_en 		: std_logic := '0';
	signal fft_reset_en_d 		: std_logic := '0';
	signal fft_nRSTB 			: std_logic := '0';
	signal o_data_cnt 			: std_logic_vector(9 downto 0)	:= (others => '0');
	signal tmp_o_data_vld		: std_logic := '0';
	signal no_change_mode			: std_logic_vector(1 downto 0)	:= (others => '0');
	signal prior_n_prev_new			: std_logic := '0';
	signal not_ready_to_change_mode	: std_logic := '0';
	signal input_receiving			: std_logic := '0';
	signal out_data_last			: std_logic := '0';
	signal input_receiving_d		: std_logic := '0';
	signal proc_cnt					: std_logic_vector(1 downto 0) := (others => '0');
				
begin
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				i_data_sync_d1	<= I_DATA_SYNC;
				i_data_sync_d2	<= i_data_sync_d1;
				i_data_sync_d3	<= i_data_sync_d2 and prior_n_prev_new;
				i_fft_sync		<= i_data_sync_d3;
			else 
				i_data_sync_d1	<= '0';
				i_data_sync_d2	<= '0';
				i_data_sync_d3	<= '0';
				i_fft_sync		<= '0';
			end if;
			
		    i_data_i_d1	  	<= I_DATA_I   ;
		    i_data_q_d1	  	<= I_DATA_Q   ;
		    i_data_i_d2	  	<= i_data_i_d1	  ;
		    i_data_q_d2	  	<= i_data_q_d1	  ;
		    i_data_i_d3	  	<= i_data_i_d2	   ;
		    i_data_q_d3	  	<= i_data_q_d2	   ;
		    i_fft_data_i  	<= i_data_i_d3	   ;
		    i_fft_data_q	<= i_data_q_d3	   ;
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '1' or (i_data_sync_d1 = '1' and not_ready_to_change_mode = '0') then
				prior_n_prev_new <= '1';	-- Priority to new data
			elsif input_receiving = '0' then
				prior_n_prev_new <= '0';	-- Priority to previous data, output is outting
			end if;
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_EVENT_NOT_READY_TO_CHANGE_TYPE <= '0';
			elsif i_data_sync_d1 = '1' and prior_n_prev_new = '0' and not_ready_to_change_mode = '1' then
				O_EVENT_NOT_READY_TO_CHANGE_TYPE <= '1';
			end if;		
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then	
			if I_RSTB = '1' or fft_reset_en = '0' then
				proc_cnt <= (others => '0');
			elsif no_change_mode = "11" and input_receiving_d = '1' and input_receiving = '0' then
				proc_cnt <= proc_cnt + 1;
			elsif no_change_mode = "10" and out_data_last = '1' and proc_cnt /= "00" then
				proc_cnt <= proc_cnt - 1;
			end if;
			
			if I_RSTB = '1' or fft_reset_en = '0' or (no_change_mode = "10" and out_data_last = '1' and proc_cnt(1) = '0') then
				no_change_mode <= "00";
			elsif i_data_sync_d3 = '1' then
				no_change_mode <= "11";
			elsif input_receiving_d = '1' and input_receiving = '0' then
				no_change_mode <= "10";
			end if;
			
			if I_DATA_SYNC = '1' and no_change_mode(1) = '1' and n_fft_sel /= I_nFFT_TYPE then
				not_ready_to_change_mode <= '1';
			else
				not_ready_to_change_mode <= '0';
			end if;
		end if;
	end process;
	
	O_STATUS_NOT_READY_TO_CHANGE_MODE <= no_change_mode(1);
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' then
				tmp_n_fft_sel <= I_nFFT_TYPE;
			end if;
			
			if i_data_sync_d2 = '1' and prior_n_prev_new = '1' then
				n_fft_sel <= tmp_n_fft_sel;
			end if;
			
			if i_data_sync_d2 = '1' and prior_n_prev_new = '1' then
				i_data_idx_max(9) <= I_nFFT_TYPE;
			end if;
		end if;
	end process;
		                        
	i_data_idx_max(8 downto 0) <= "111111111";
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' then
				i_data_idx <= (others => '0');
			elsif i_data_idx /= i_data_idx_max then
				i_data_idx <= i_data_idx + 1;
			end if;
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				input_receiving_d <= input_receiving;
			else 
				input_receiving_d <= '0';
			end if;
			
			if I_DATA_SYNC = '1' and I_RSTB = '0' then
				input_receiving <= '1';
			elsif (i_data_idx = (i_data_idx_max(9 downto 1) & '0')) or (I_RSTB = '1') then
				input_receiving <= '0';			
			end if;
			
			if I_DATA_SYNC = '1' and input_receiving = '1' and I_RSTB = '0' then
				i_sync_unexpected <= '1';
			else
				i_sync_unexpected <= '0';
			end if;
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_EVENT_I_SYNC_UNEXPECTED <= '0';
			elsif i_sync_unexpected = '1' then
				O_EVENT_I_SYNC_UNEXPECTED <= '1';
			end if;				
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				i_data_vld_missing <= '0';
			elsif I_DATA_VLD = '0' and (input_receiving = '1' or input_receiving_d = '1') then
				i_data_vld_missing <= '1';
			end if;
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED <= '0';
			elsif i_data_vld_missing = '1' then
				O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED <= '1';
			end if;		    
			
			if I_DATA_SYNC = '1' or I_RSTB = '1' then
				O_STATUS_EXTENDED_INPUT_DATA <= '0';
			elsif I_DATA_VLD = '1' and (input_receiving_d = '0' and input_receiving = '0') then
				O_STATUS_EXTENDED_INPUT_DATA <= '1';
			end if;
		end if;
	end process; 
	
	fft_nRSTB <= fft_reset_en and fft_reset_en_d;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			fft_reset_en <= not (i_sync_unexpected or i_data_vld_missing);	
		    fft_reset_en_d <= (not I_RSTB) and fft_reset_en;
		end if;
	end process; 	
	
	U_nFFT: fft_1024_512
	generic map(
	    DEVICE        		=> DEVICE   ,
		FFT_TYPE 			=> FFT_TYPE ,     
		N_DSP48_PER_CMULT  	=> N_DSP48_PER_CMULT,
		XTREME_DSP_MODE		=> XTREME_DSP_MODE,
		IN_WIDTH 			=> IN_WIDTH ,   
		OUT_WIDTH			=> OUT_WIDTH )   
	port map (
		I_RSTB		=> fft_nRSTB,
		I_CLK		=> I_CLK,
		I_SYNC	  	=> i_fft_sync		,
		I_DATA_RE	=> i_fft_data_i		 ,  
		I_DATA_IM	=> i_fft_data_q		 ,  
		I_NFFT_SEL	=> n_fft_sel		,
		O_SYNC	  	=> o_fft_sync		,
		O_DATA_RE	=> O_DATA_I	    ,
		O_DATA_IM	=> O_DATA_Q	    );		
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if o_fft_sync = '1' then
				o_data_cnt <= (others => '0');
			elsif o_data_cnt /= i_data_idx_max then
				o_data_cnt <= o_data_cnt + 1;
			end if;
			
			if o_fft_sync = '1' and I_RSTB = '0' then
				tmp_o_data_vld <= '1';
			elsif o_data_cnt = i_data_idx_max or I_RSTB = '1' then
				tmp_o_data_vld <= '0';
			end if;			
			
			if (o_data_cnt = i_data_idx_max) and (tmp_o_data_vld = '1') then
				out_data_last <= '1';
			else 
				out_data_last <= '0';
			end if;			
			
			O_DATA_VLD <= tmp_o_data_vld and (not I_RSTB);	
			O_DATA_SYNC <= o_fft_sync and (not I_RSTB);
		end if;
	end process; 
	
	O_DATA_LAST <= out_data_last;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if n_fft_sel = '0' then
				O_DATA_IDX  <= '0' & o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & o_data_cnt(3) & o_data_cnt(4) &
					  	 	   o_data_cnt(5) & o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8);
			else
				O_DATA_IDX  <= o_data_cnt(0) & o_data_cnt(1) & o_data_cnt(2) & o_data_cnt(3) & o_data_cnt(4) &
					  	 	   o_data_cnt(5) & o_data_cnt(6) & o_data_cnt(7) & o_data_cnt(8) & o_data_cnt(9);
			
			end if;
		end if;
	end process; 	
		
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------

