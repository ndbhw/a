-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix22 SDF Component
-- File Name		: hybrid_tw_phaser.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 	  The block include list below
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)     
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all;
use work.FFT_FUNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity hybrid_tw_phaser is 
	generic (       
		DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"    
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; 		-- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; 	-- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB				: in std_logic; 	-- system reset(low activated)
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC				: in std_logic;
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end hybrid_tw_phaser;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of hybrid_tw_phaser is
		
	constant RND_WIDTH	  		: natural := (TW_WIDTH-1);
	constant SAT_WIDTH	  		: natural := 1;
	constant CMULT_OUT_WIDTH	: natural := OUT_WIDTH-SAT_WIDTH;
	constant TW_DEPTH	  : integer := (N_FFT/4);
	constant CNT_MSB	  : integer := (integer(floor(log2(real(N_FFT- 1)))));
	constant ADDR_MSB	  : integer := (CNT_MSB - 2);
	
 	component FFT_DPROM is
	generic(
	    RAM_TYPE                    : string  := "block"       ; -- "auto" or "distributed" or "block" or "ultra" 
	    CLOCKING_MODE               : string  := "common_clock"; -- "common_clock" or "independent_clock"
	    OPERATING_MODE              : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"
	    A_ADDR_DEPTH                : integer :=  1024         ;
	    A_DATA_WIDTH                : integer :=     8         ;
	    A_READ_LATENCY              : integer :=     2         ;
	    B_ADDR_DEPTH                : integer :=  1024         ;
	    B_DATA_WIDTH                : integer :=     8         ;
	    B_READ_LATENCY              : integer :=     2         ;
	    RAM_INIT_FILE               : string  := "none"        ; 
	    RAM_INIT_VALUE              : string  := "0" 
	    );
	port(
	    I_CLK_A                       : in  std_logic;
	    I_EN_A                        : in  std_logic := '1';
	    I_WE_A                        : in  std_logic := '1';
	    I_ADDR_A                      : in  std_logic_vector(integer(floor(log2(real(A_ADDR_DEPTH-1)))) downto 0);
	    I_DATA_A                      : in  std_logic_vector(A_DATA_WIDTH-1 downto 0);
	    O_Q_A	                        : out std_logic_vector(A_DATA_WIDTH-1 downto 0);

	    I_CLK_B                       : in  std_logic;
	    I_EN_B                        : in  std_logic := '1';
	    I_WE_B                        : in  std_logic := '1';
	    I_ADDR_B                      : in  std_logic_vector(integer(floor(log2(real(B_ADDR_DEPTH-1)))) downto 0);
	    I_DATA_B                      : in  std_logic_vector(B_DATA_WIDTH-1 downto 0);
	    O_Q_B	                        : out std_logic_vector(B_DATA_WIDTH-1 downto 0)
	);
	end component;

	component FFT_CMULT_FUNC is
	generic(
	    DEVICE                      : string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
	    N_DSP48               		: natural := 		  3	 ; 	-- 3 or 4
	    SAT_BIT                     : natural :=          15 ;
	    RND_BIT                     : natural :=          15 ;
	    IN_A_BITWIDTH               : natural :=          16 ; -- MAX 26
	    IN_B_BITWIDTH               : natural :=          16 ; -- MAX 17
	    OUT_BITWIDTH                : natural :=          16);
	port(
	    I_CLK                       : in  std_logic;
	    
	    I_ADATA_I                   : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);
	    I_ADATA_Q                   : in  std_logic_vector(IN_A_BITWIDTH-1 downto 0);
	
	    I_BDATA_I                   : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);
	    I_BDATA_Q                   : in  std_logic_vector(IN_B_BITWIDTH-1 downto 0);
	
	    O_DATA_I                    : out std_logic_vector(OUT_BITWIDTH-1 downto 0);
	    O_DATA_Q                    : out std_logic_vector(OUT_BITWIDTH-1 downto 0)
	);
	end component;

	signal osync_en 	: std_logic;
	signal stage_cnt 	: std_logic_vector(CNT_MSB downto 0);
	signal stage		: std_logic_vector(1 downto 0);
	signal stage_d		: std_logic_vector(1 downto 0);
	signal ph_idx_inc 	: std_logic_vector(1 downto 0);
	signal ph_idx 		: std_logic_vector(CNT_MSB downto 0);
	signal ph_idx0 		: std_logic_vector(CNT_MSB downto 0);
	signal ph_idx1 		: std_logic_vector(CNT_MSB downto 0);
	signal addr_a 		: std_logic_vector(ADDR_MSB downto 0);
	signal addr_b 		: std_logic_vector(ADDR_MSB downto 0);
	signal quad_dir 	: std_logic_vector(1 downto 0);
	signal quad_dir_d1 	: std_logic_vector(1 downto 0);
	signal quad_dir_d2 	: std_logic_vector(1 downto 0);
	signal null_addr 	: std_logic;
	signal null_addr_d 	: std_logic;
	
	signal data_rd_a 	: std_logic_vector((TW_WIDTH - 1) downto 0);
	signal data_rd_b 	: std_logic_vector((TW_WIDTH - 1) downto 0);
	signal tw_re 		: std_logic_vector((TW_WIDTH - 1) downto 0);
	signal tw_im 		: std_logic_vector((TW_WIDTH - 1) downto 0);
	
begin
 	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				osync_en <= '0';
			elsif I_SYNC = '1' then
				osync_en <= '1';
			elsif stage_cnt = OSYNC_TIMING then
				osync_en <= '0';
			end if;
		end if;
	end process;
	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then		
			if I_RSTB = '0' or I_SYNC = '1' then
				stage_cnt <= (others => '0');
			else
				stage_cnt <= stage_cnt + 1;
			end if;
		end if;
	end process;
	
	stage <= stage_cnt(CNT_MSB downto (CNT_MSB - 1));
	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then		
		
			case stage is
				when "00" => 	ph_idx_inc <= "00"; 			
				when "01" => 	ph_idx_inc <= "10"; 		
				when "10" => 	ph_idx_inc <= "01"; 			
				when others => 	ph_idx_inc <= "11";
			end case;
			
			stage_d <= stage;
		end if;
	end process;

	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if stage_d /= stage then
				ph_idx1 <= (others => '0');
			else 
				ph_idx1 <= ph_idx1 + ph_idx_inc;
			end if;
			
			if stage = "00" then
				ph_idx0 <= (others => '0');
			else 
				ph_idx0 <= '0' & stage_cnt((CNT_MSB - 2) downto 0) & '0';
			end if;
			
			if I_CTRL_MODE = '1' then
				ph_idx <= ph_idx1;
			else
				ph_idx <= ph_idx0;
			end if;
		end if;
	end process;
	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if ph_idx((CNT_MSB-1)) = '0' then 
				addr_a <= ph_idx(ADDR_MSB downto 0);
			else
				addr_a <= (not ph_idx(ADDR_MSB downto 0)) + 1;
			end if; 
			
			if ph_idx((CNT_MSB-1)) = '0' then 
				addr_b <= (not ph_idx(ADDR_MSB downto 0)) + 1;
			else
				addr_b <= ph_idx(ADDR_MSB downto 0);
			end if; 
			
			quad_dir <= ph_idx(CNT_MSB downto (CNT_MSB-1));
			quad_dir_d1 <= quad_dir;
			quad_dir_d2 <= quad_dir_d1;
		end if;
	end process;
	
	U_TW_ROM : FFT_DPROM 
	generic map(
		RAM_TYPE       	=> RAM_TYPE        		, 
		CLOCKING_MODE  	=> "common_clock"		, 
		OPERATING_MODE 	=> "no_change"      	, 
		A_ADDR_DEPTH   	=> TW_DEPTH 			, 
		A_DATA_WIDTH   	=> TW_WIDTH    			, 
		A_READ_LATENCY 	=> TW_LATENCY    		, 
		B_ADDR_DEPTH   	=> TW_DEPTH				, 
		B_DATA_WIDTH   	=> TW_WIDTH				, 
		B_READ_LATENCY 	=> TW_LATENCY         	, 
		RAM_INIT_FILE  	=> RAM_INIT_FILE   		, 
		RAM_INIT_VALUE 	=> "0"                  )
	port map(
		I_CLK_A    		=> I_CLK      		, 
		I_EN_A     		=> '1'        		, 
		I_WE_A     		=> '0'      		, 
		I_ADDR_A   		=> addr_a      		, 
		I_DATA_A   		=> (others => '0')  ,
		O_Q_A	     		=> data_rd_a    	, 
		I_CLK_B    		=> I_CLK        		, 
		I_EN_B     		=> '1'  			, 
		I_WE_B     		=> '0'              , 
		I_ADDR_B   		=> addr_b 			, 
		I_DATA_B   		=> (others => '0')  ,
		O_Q_B	     		=> data_rd_b 		);
	  
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if addr_a = 0 then
				null_addr <= '1';
			else 
				null_addr <= '0';
			end if;
			null_addr_d <= null_addr;
		end if;
	end process;
        	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if null_addr_d = '1' and quad_dir_d2(0) = '1' then
			   	tw_re <= (others => '0');
			elsif quad_dir_d2(1) /= quad_dir_d2(0) then
		   		tw_re <= (not data_rd_a) + 1;   			
			else
		   		tw_re <= data_rd_a;
			end if;
			
			if null_addr_d = '1' and quad_dir_d2(0) = '0' then
			   	tw_im <= (others => '0');
			elsif quad_dir_d2(1) = '0' then
		   		tw_im <= (not data_rd_b) + 1;
			else
		   		tw_im <= data_rd_b;
			end if;
		end if;
	end process;

	U_CMULT : FFT_CMULT_FUNC 
	generic map(
		DEVICE      	=> DEVICE     		, 
		N_DSP48			=> CMULT_N_DSP48	,
		SAT_BIT      	=> SAT_WIDTH		, 
		RND_BIT     	=> RND_WIDTH		, 
		IN_A_BITWIDTH 	=> IN_WIDTH   		, 
		IN_B_BITWIDTH 	=> TW_WIDTH			, 
		OUT_BITWIDTH	=> OUT_WIDTH		)
	port map(
		I_CLK       	=> I_CLK      		, 
		I_ADATA_I   	=> I_DATA_RE		, 
		I_ADATA_Q   	=> I_DATA_IM  		, 
		I_BDATA_I   	=> tw_re			,
		I_BDATA_Q   	=> tw_im			, 
		O_DATA_I    	=> O_DATA_RE  		, 
		O_DATA_Q    	=> O_DATA_IM       );
		
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if stage_cnt = OSYNC_TIMING and osync_en = '1' then
				O_SYNC <= '1';
			else
				O_SYNC <= '0';
			end if;
		end if;
	end process;
		
end struct;
-------------------------------------------------------------------------------------------------------------------------------

