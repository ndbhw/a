-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix2 SDF Component
-- File Name		: r2_bf_ctrl.VHD
-- Date				: 2022.03.15
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 
		
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;use ieee.math_real.all; use ieee.std_logic_arith.all;
use work.FFT_FUNC.all;
-------------------------------------------------------------------------------------------------------------------------------
entity r2_bf_ctrl is 
	generic (           
		N_SIZE			: integer;			-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY		: integer);			-- [ O_SYNC Timing Delay Parameter	 ]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB  		: in std_logic; 	-- system reset(low activated)
		I_CLK	  		: in std_logic;		-- main clock
		I_SYNC			: in std_logic;
      	-- *************************************************************
      	-- TO FFT_STG0 module
      	-- *************************************************************
		O_BF_CTRL_S	 	: out std_logic;
		O_SYNC	  		: out std_logic
	);
end r2_bf_ctrl;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of r2_bf_ctrl is
		
	constant MSBIT			: integer := integer(ceil(log2(real(N_SIZE))));
	constant CNT_MSB        : integer := ternary_func(N_SIZE /= 4, (MSBIT-1), MSBIT);    
	
	signal osync_timing_cnt	: std_logic_vector(CNT_MSB downto 0) := conv_std_logic_vector(((N_SIZE/2) + OSYNC_DELAY - 1), (CNT_MSB+1));
	signal osync_en		: std_logic;
	signal bf_stage_cnt	: std_logic_vector(CNT_MSB downto 0);
	
begin

	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' then
				osync_en <= '0';
			elsif I_SYNC = '1' then
				osync_en <= '1';
			elsif bf_stage_cnt = osync_timing_cnt then
				osync_en <= '0';
			end if;
		end if;
	end process;
	
	-- *************************************************************
    -- Butterfly I Control
   	-- *************************************************************
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_RSTB = '0' or I_SYNC = '1' then
				bf_stage_cnt <= (others => '0');	
			else
				bf_stage_cnt <= bf_stage_cnt + '1';
			end if;
		end if;
	end process;
	
	O_BF_CTRL_S 	<= bf_stage_cnt(MSBIT - 1);
	-- *************************************************************
    -- Out Sync
   	-- *************************************************************	
	process( I_CLK )
	begin
		if I_CLK'event and I_CLK = '1' then
			if bf_stage_cnt = osync_timing_cnt and osync_en = '1' and I_RSTB = '1' then
				O_SYNC <= '1';
			else 
				O_SYNC <= '0'; 
			end if;
		end if;
	end process;
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------
