-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix2 SDF Component
-- File Name		: radix2_bf.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 	  The block include list below
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)     
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;

Library work;
use work.FFT_ARRAY_TYPE.all;
use work.FFT_FUNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity radix2_bf is 
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean;					-- [ Xtreme dsp mode				] false or true 	
		IN_WIDTH			: integer;					-- [ Input Data Bit Width Parameter	]                       
		N_SIZE				: integer);					-- [ FFT Point Size Parameter    	]   
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- INTERNAL (BLOCK) INTERFACE SIGNALS --------------------------
		I_CTRL_S			: in std_logic;		-- Control Bit 'S'
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE			: out std_logic_vector((IN_WIDTH-1) downto 0);
		O_DATA_IM			: out std_logic_vector((IN_WIDTH-1) downto 0));
end radix2_bf;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of radix2_bf is
	
	component FFT_SRL_DLY
	generic(
	    DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
	    BIT_WIDTH                   : natural;
	    DELAY_NUM                   : natural);
	port(
	    I_CLK                       : in  std_logic;
	    I_DATA                      : in  std_logic_vector(BIT_WIDTH-1 downto 0);
	    O_DATA                      : out std_logic_vector(BIT_WIDTH-1 downto 0));
	end component;

	component shift_reg_ram
	generic (
    	RAM_TYPE            : string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
    	OPERATING_MODE      : string  := "read_first"  ; -- "no_change" or "read_first" or "write_first"
		MEM_WIDTH			: integer;  -- [ Input Data Bit Width Parameter ]
		MEM_DEPTH			: integer; 	-- [ Shift Register Depth        	]
		SHFT_DEPTH			: integer); -- [ Shift Register Depth        	]
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA			: in std_logic_vector((MEM_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA			: out std_logic_vector((MEM_WIDTH-1) downto 0));
	end component;
	
	component FFT_DSP48E_MULT is
	generic(
	    DEVICE                      : string  := "ULTRASCALE";
	    DSP48_MODECTRL              : boolean :=       FALSE ;
	    DSP48_PREADDER_USE          : boolean :=        TRUE ;
	    DSP48_PCIN_USE              : boolean :=       FALSE ;
	    DSP48_PCOUT_USE             : boolean :=       FALSE ;
	    DSP48_POSTADDER_MODE         : string  :=        "ADD"; -- "ADD" or "SUB" 
	
	    A_nREG                      : integer :=           2 ; -- 0, 1, 2
	    B_nREG                      : integer :=           2 ; -- 0, 1, 2
	
	    C_EN                        : boolean :=        TRUE ; -- RND ENable
	    RND_SYMMETRY                : boolean :=       FALSE 
	    );
	port(
	    I_CLK                       : in  std_logic;
	
	    I_ALUMODE                   : in  std_logic_vector( 3 downto 0);
	    I_OPMODE                    : in  std_logic_vector( 8 downto 0);
    	I_PREADDER_OP				: in  std_logic_vector(4 downto 0); -- "00101" - ADD, "01101" - SUB, "00001" - A1, "0011X" - D 
	
	    I_C                         : in  std_logic_vector(47 downto 0); -- RND Value
	    I_A                         : in  std_logic_vector(29 downto 0);
	    I_D                         : in  std_logic_vector(26 downto 0);
	    I_B                         : in  std_logic_vector(17 downto 0);
	
	    I_P_C                       : in  std_logic_vector(47 downto 0);
	    O_P_C                       : out std_logic_vector(47 downto 0);
	
	    O_P                         : out std_logic_vector(47 downto 0);
	    O_CRRY                      : out std_logic
	    );
	end component;

	constant SHFT_DELAY	: integer := ternary_func(XTREME_DSP_MODE = true, ((N_SIZE/2) - 3), (N_SIZE/2));   
	constant DSP_18_B 		: std_logic_vector(17 downto 0) := "000000000000000001";
	constant PREADDER_ADD	: std_logic_vector(4 downto 0) := "00101";
	constant PREADDER_SUB	: std_logic_vector(4 downto 0) := "01101";
	constant PREADDER_A1	: std_logic_vector(4 downto 0) := "00001";
	constant PREADDER_D		: std_logic_vector(4 downto 0) := "00110";

	signal shift_di_re : std_logic_vector((IN_WIDTH-1) downto 0);
	signal shift_di_im : std_logic_vector((IN_WIDTH-1) downto 0);
	signal shift_do_re : std_logic_vector((IN_WIDTH-1) downto 0);
	signal shift_do_im : std_logic_vector((IN_WIDTH-1) downto 0);
	signal shift_di    : std_logic_vector(((IN_WIDTH*2) - 1) downto 0);
	signal shift_do    : std_logic_vector(((IN_WIDTH*2) - 1) downto 0);
	
	signal DSP_ADD30_A_RE : std_logic_vector(29 downto 0);
	signal DSP_ADD27_D_RE : std_logic_vector(26 downto 0);
	signal DSP_ADD48_OUT_RE : std_logic_vector(47 downto 0);
	signal DSP_ADD30_A_IM : std_logic_vector(29 downto 0);
	signal DSP_ADD27_D_IM : std_logic_vector(26 downto 0);
	signal DSP_ADD48_OUT_IM : std_logic_vector(47 downto 0);
	signal dsp_add_op		: std_logic_vector(4 downto 0);
	
	signal DSP_SUB30_A_RE : std_logic_vector(29 downto 0);
	signal DSP_SUB27_D_RE : std_logic_vector(26 downto 0);
	signal DSP_SUB48_OUT_RE : std_logic_vector(47 downto 0);
	signal DSP_SUB30_A_IM : std_logic_vector(29 downto 0);
	signal DSP_SUB27_D_IM : std_logic_vector(26 downto 0);
	signal DSP_SUB48_OUT_IM : std_logic_vector(47 downto 0);
	signal dsp_sub_op		: std_logic_vector(4 downto 0);
	
begin
	
	g_BF_LUT : if XTREME_DSP_MODE = false generate
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_S = '1' then
				O_DATA_RE 		<= shift_do_re + I_DATA_RE;
				O_DATA_IM 		<= shift_do_im + I_DATA_IM;
				shift_di_re <= shift_do_re - I_DATA_RE;
				shift_di_im <= shift_do_im - I_DATA_IM;
			else
				O_DATA_RE 		<= shift_do_re;
			    O_DATA_IM 		<= shift_do_im;
				shift_di_re <= I_DATA_RE;	
				shift_di_im <= I_DATA_IM;
			end if;
		end if;
	end process;
    end generate;
	
    g_BF_DSP : if XTREME_DSP_MODE = true generate
    
    U_ADD_RE : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,FALSE,FALSE,"ADD",2,2,FALSE, FALSE) 
	port map(I_CLK,x"0",(others=>'0'), dsp_add_op, (others =>'0'), DSP_ADD30_A_RE, DSP_ADD27_D_RE, DSP_18_B, (others=>'0'), open, DSP_ADD48_OUT_RE, open);  	    
	U_ADD_IM : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,FALSE,FALSE,"ADD",2,2,FALSE, FALSE) 
	port map(I_CLK,x"0",(others=>'0'), dsp_add_op, (others =>'0'), DSP_ADD30_A_IM, DSP_ADD27_D_IM, DSP_18_B, (others=>'0'), open, DSP_ADD48_OUT_IM, open);
    U_SUB_RE : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,FALSE,FALSE,"ADD",2,2,FALSE ,FALSE) 
    port map(I_CLK,x"0",(others=>'0'), dsp_sub_op, (others =>'0'), DSP_SUB30_A_RE, DSP_SUB27_D_RE, DSP_18_B, (others=>'0'), open, DSP_SUB48_OUT_RE, open);
    U_SUB_IM : FFT_DSP48E_MULT generic map(DEVICE,FALSE,TRUE,FALSE,FALSE,"ADD",2,2,FALSE ,FALSE) 
    port map(I_CLK,x"0",(others=>'0'), dsp_sub_op, (others =>'0'), DSP_SUB30_A_IM, DSP_SUB27_D_IM, DSP_18_B, (others=>'0'), open, DSP_SUB48_OUT_IM, open);
	
	DSP_ADD30_A_RE <= sign_extension(I_DATA_RE, 30);
	DSP_ADD27_D_RE <= sign_extension(shift_do_re, 27);
	DSP_ADD30_A_IM <= sign_extension(I_DATA_IM, 30);
	DSP_ADD27_D_IM <= sign_extension(shift_do_im, 27);
	O_DATA_RE <= DSP_ADD48_OUT_RE((IN_WIDTH-1) downto 0);
	O_DATA_IM <= DSP_ADD48_OUT_IM((IN_WIDTH-1) downto 0);
	
	DSP_SUB30_A_RE <= sign_extension(I_DATA_RE, 30);
	DSP_SUB27_D_RE <= sign_extension(shift_do_re, 27);
	DSP_SUB30_A_IM <= sign_extension(I_DATA_IM, 30);
	DSP_SUB27_D_IM <= sign_extension(shift_do_im, 27);
	shift_di_re <= DSP_SUB48_OUT_RE((IN_WIDTH-1) downto 0);
	shift_di_im <= DSP_SUB48_OUT_IM((IN_WIDTH-1) downto 0);	
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_S = '1' then
				dsp_add_op	<=	PREADDER_ADD;
				dsp_sub_op  <=  PREADDER_SUB;
			else
				dsp_add_op	<=	PREADDER_D;
				dsp_sub_op  <=  PREADDER_A1;
			end if;
		end if;
	end process;
	
    end generate;
    
	g_BF_NO_SHFT : if ((XTREME_DSP_MODE = true) and (N_SIZE = 8)) or ((XTREME_DSP_MODE = false) and (N_SIZE = 2)) generate
	shift_do_re <= shift_di_re;
	shift_do_im <= shift_di_im;	
    end generate;
	
    g_SRL_SHFT : if ((XTREME_DSP_MODE = true) and (N_SIZE < 128) and (N_SIZE > 8)) or ((XTREME_DSP_MODE = false) and (N_SIZE < 128) and (N_SIZE > 2)) generate -- LUT Based Shift Register	
    U_SHFT_BUT : FFT_SRL_DLY
	generic map ( 
		DEVICE 		=> DEVICE,
		BIT_WIDTH 	=> (IN_WIDTH*2),
		DELAY_NUM 	=> SHFT_DELAY)
	port map (
        I_CLK		=> I_CLK         ,                           
        I_DATA  	=> shift_di ,                                 
        O_DATA      => shift_do);	
        
    shift_di <= (shift_di_re & shift_di_im);
    shift_do_re <= shift_do(((IN_WIDTH*2) - 1) downto IN_WIDTH);
    shift_do_im <= shift_do((IN_WIDTH-1) downto 0);
	end generate;
	
	g_LRAM_SHFT : if (N_SIZE = 128) generate -- LUT Based Shift Register
    U_SHFT_BUT : shift_reg_ram
	generic map ( 
    	RAM_TYPE    =>  "distributed", -- "auto" or "distributed" or "block" or "ultra" 
    	OPERATING_MODE => "read_first", -- "no_change" or "read_first" or "write_first"
		MEM_WIDTH	=> (IN_WIDTH*2),
		MEM_DEPTH	=> (N_SIZE/2)     ,
		SHFT_DEPTH	=> SHFT_DELAY - 1) 
	port map (
        I_CLK		=> I_CLK         ,                           
        I_DATA     => shift_di 	,                                 
        O_DATA     => shift_do );
		
    shift_di <= (shift_di_re & shift_di_im);
    shift_do_re <= shift_do(((IN_WIDTH*2) - 1) downto IN_WIDTH);
    shift_do_im <= shift_do((IN_WIDTH-1) downto 0);
    end generate;
    
    g_BRAM_SHFT : if (N_SIZE > 128) generate -- RAM Based Shift Register
    U_SHFT_BUT : shift_reg_ram
	generic map ( 
    	RAM_TYPE        => "block", -- "auto" or "distributed" or "block" or "ultra" 
    	OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
		MEM_WIDTH	=> (IN_WIDTH*2),
		MEM_DEPTH	=> (N_SIZE/2)     ,
		SHFT_DEPTH	=> SHFT_DELAY - 1)
	port map (
        I_CLK			=> I_CLK         ,                           
        I_DATA     => shift_di 	,                                 
        O_DATA     => shift_do );
        
    shift_di <= (shift_di_re & shift_di_im);
    shift_do_re <= shift_do(((IN_WIDTH*2) - 1) downto IN_WIDTH);
    shift_do_im <= shift_do((IN_WIDTH-1) downto 0);
	end generate;
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------

