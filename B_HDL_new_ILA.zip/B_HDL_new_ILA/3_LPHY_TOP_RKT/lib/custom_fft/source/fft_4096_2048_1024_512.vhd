-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: FFT
-- File Name		: fft_4096_2048_1024_512.VHD
-- Date				: 2022.02.18
-- Revision			: 2
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- Available for 4096/2048/1024/512 FFT Size
-- Number of DSP Slice:       THREE			|      	FOUR			|   
-- Latency at 4096: 	4160 clock cycle	|	4155 clock cycle	|
-- Latency at 2048: 	2111 clock cycle	|	2106 clock cycle	|
-- Latency at 1024: 	1076 clock cycle	|	1072 clock cycle	|
-- Latency at 512 : 	 563 clock cycle	|	 559 clock cycle	|
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang           
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_signed.all;
use work.FFT_FUNC.all;

-------------------------------------------------------------------------------------------------------------------------------
entity fft_4096_2048_1024_512 is 
	generic (
	    DEVICE          	: string  	:= "ULTRASCALE";	-- "7SERIES" or "ULTRASCALE"
		FFT_TYPE			: string 	:= "FFT";  			-- [ Forward or Inverse FFT			 	] "iFFT" or "FFT"
		N_DSP48_PER_CMULT   : string	:= "THREE";			-- [ Number of DSP48E per Complex Mult 	] "THREE" or "FOUR"	
		IN_WIDTH			: integer 	:= 15;				-- [ Input Data Bit Width Parameter  	]  
		OUT_WIDTH			: integer 	:= 27);				-- [ Output Data Bit Width Parameter  	]  
	port (
		I_RSTB			: in std_logic; 	
		I_CLK			: in std_logic;	
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************		
		I_SYNC			: in std_logic;
		I_DATA_RE	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM	  	: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_NFFT_SEL		: in std_logic_vector(1 downto 0);	-- "00" = 512, "01" = 1024, "10" = 2048, "11" = 4096, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************	
		O_SYNC			: out std_logic;			
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
end fft_4096_2048_1024_512;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of fft_4096_2048_1024_512 is

	component r22_sdf
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		IN_WIDTH			: integer;				-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;				-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);				-- [ O_SYNC Timing Delay Parameter	 ]     
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;
	
	component hybrid_r22_sdf
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		IN_WIDTH			: integer;				-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;				-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);				-- [ O_SYNC Timing Delay Parameter	 ]       
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
	end component;	
		
	component hybrid_tw_phaser
	generic (
		DEVICE          : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	component tw_phaser
	generic (
		DEVICE                      : string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		BF_TYPE			: string  := "Radix22"; 	-- "Radix22" or "Radix2"  
    	CMULT_N_DSP48   : natural := 		3; 		-- 3 or 4
	    RAM_TYPE      	: string  := "block"; -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  : string  := "read_first"; -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   : string  := "none"        ; 
		IN_WIDTH		: integer := 15;	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		: integer;			-- [ Output Data Bit Width Parameter ]
		N_FFT			: integer := 4096;			
		TW_WIDTH		: integer := 16;			
		TW_LATENCY		: integer := 2;				
		OSYNC_TIMING	: integer := 10);
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE	  	: out std_logic_vector((OUT_WIDTH-1) downto 0);
		O_DATA_IM	  	: out std_logic_vector((OUT_WIDTH-1) downto 0));
	end component;
	
	constant nIFFT_FFT_SEL      : boolean := ternary_func(FFT_TYPE = "FFT", true, false);    
	constant CMULT_N_DSP48		: natural := ternary_func(N_DSP48_PER_CMULT = "THREE", 3, 4);
	constant STG6_IN_WIDTH 		: integer := IN_WIDTH;
	constant STG5_IN_WIDTH 		: integer := (IN_WIDTH + 2);
	constant STG4_IN_WIDTH 		: integer := (IN_WIDTH + 4);
	constant STG3_IN_WIDTH 		: integer := (IN_WIDTH + 6);
	constant STG2_IN_WIDTH 		: integer := (IN_WIDTH + 8);
	constant STG1_IN_WIDTH 		: integer := (IN_WIDTH + 10);
	
	constant STG6_N_SIZE	: integer := 4096;
	constant STG5_N_SIZE	: integer := 1024;
	constant STG4_N_SIZE	: integer := 256;
	constant STG3_N_SIZE	: integer := 64;
	constant STG2_N_SIZE	: integer := 16;
	constant STG1_N_SIZE	: integer := 4;
	
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP	: integer := 11;
	constant TW_PHASER_O_SYNC_TIMING_FOUR_DSP	: integer := 10;
	constant HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP	: integer := 12;
	constant TW_PHASER_O_SYNC_TIMING_THREE_DSP	: integer := 11;
	
	constant HYBRID_TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_PER_CMULT = "THREE", HYBRID_TW_PHASER_O_SYNC_TIMING_THREE_DSP, HYBRID_TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   
	constant TW_PHASER_O_SYNC_TIMING	: integer := ternary_func(N_DSP48_PER_CMULT = "THREE", TW_PHASER_O_SYNC_TIMING_THREE_DSP, TW_PHASER_O_SYNC_TIMING_FOUR_DSP);   

	signal stg6_radix2_radix22_sel	: std_logic;
	signal stg5_radix2_radix22_sel	: std_logic;
	signal di_mux					: std_logic;
	
	signal stg6_isync		: std_logic;
	signal stg6_di_re		: std_logic_vector((STG6_IN_WIDTH-1) downto 0);
	signal stg6_di_im		: std_logic_vector((STG6_IN_WIDTH-1) downto 0);
	signal stg6_osync		: std_logic;
	signal stg6_do_re		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal stg6_do_im		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal tw6_osync		: std_logic;
	signal tw6_do_re		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal tw6_do_im		: std_logic_vector((STG6_IN_WIDTH+1) downto 0);
	signal stg5_isync		: std_logic;
	signal stg5_di_re		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_di_im		: std_logic_vector((STG5_IN_WIDTH-1) downto 0);
	signal stg5_osync		: std_logic;
	signal stg5_do_re		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal stg5_do_im		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal tw5_osync		: std_logic;                                   
	signal tw5_do_re		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal tw5_do_im		: std_logic_vector((STG5_IN_WIDTH+1) downto 0);
	signal stg4_osync		: std_logic;
	signal stg4_do_re		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal stg4_do_im		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal tw4_osync		: std_logic;                                   
	signal tw4_do_re		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal tw4_do_im		: std_logic_vector((STG4_IN_WIDTH+1) downto 0);
	signal stg3_osync		: std_logic;
	signal stg3_do_re		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal stg3_do_im		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal tw3_osync		: std_logic;                                   
	signal tw3_do_re		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal tw3_do_im		: std_logic_vector((STG3_IN_WIDTH+1) downto 0);
	signal stg2_osync		: std_logic;
	signal stg2_do_re		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal stg2_do_im		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal tw2_osync		: std_logic;                                   
	signal tw2_do_re		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal tw2_do_im		: std_logic_vector((STG2_IN_WIDTH+1) downto 0);
	signal stg1_osync		: std_logic;
	signal stg1_do_re		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	signal stg1_do_im		: std_logic_vector((STG1_IN_WIDTH+1) downto 0);
	
begin
		
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			stg6_radix2_radix22_sel <= I_NFFT_SEL(0);
			stg5_radix2_radix22_sel <= I_NFFT_SEL(1) or I_NFFT_SEL(0);
			di_mux <= I_NFFT_SEL(1);
		end if;
	end process;	
	
	g_FFT_IN : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if di_mux = '1' then
				stg6_isync <= I_SYNC;
				stg6_di_re <= I_DATA_RE;
				stg6_di_im <= I_DATA_IM;
			else
				stg6_isync <= '0';
				stg6_di_re <= (others => '0');
				stg6_di_im <= (others => '0');
			end if;
			
			if di_mux = '0' then
				stg5_isync <= I_SYNC;
				stg5_di_re <= I_DATA_RE(IN_WIDTH-1) & I_DATA_RE(IN_WIDTH-1) & I_DATA_RE;
				stg5_di_im <= I_DATA_IM(IN_WIDTH-1) & I_DATA_IM(IN_WIDTH-1) & I_DATA_IM;
			else 
				stg5_isync <= tw6_osync;
				stg5_di_re <= tw6_do_re;
				stg5_di_im <= tw6_do_im;
			end if;				
		end if;
	end process;
    end generate;
    
    g_iFFT_IN : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if di_mux = '1' then
				stg6_isync <= I_SYNC;
				stg6_di_re <= I_DATA_RE;
				stg6_di_im <= (not I_DATA_IM) + 1;
			else
				stg6_isync <= '0';
				stg6_di_re <= (others => '0');
				stg6_di_im <= (others => '0');
			end if;
			
			if di_mux = '0' then
				stg5_isync <= I_SYNC;
				stg5_di_re <= I_DATA_RE(IN_WIDTH-1) & I_DATA_RE(IN_WIDTH-1) & I_DATA_RE;
				stg5_di_im <= (not (I_DATA_IM(IN_WIDTH-1) & I_DATA_IM(IN_WIDTH-1) & I_DATA_IM)) + 1;
			else 
				stg5_isync <= tw6_osync;
				stg5_di_re <= tw6_do_re;
				stg5_di_im <= tw6_do_im;
			end if;	
		end if;	
	end process;
	end generate;	
	
	U_FFT_STG6: hybrid_r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG6_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG6_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -5        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg6_isync,
		I_DATA_RE	=> stg6_di_re,  
		I_DATA_IM	=> stg6_di_im,  
		I_CTRL_MODE	=> stg6_radix2_radix22_sel,
		O_SYNC		=> stg6_osync,
		O_DATA_RE	=> stg6_do_re,
		O_DATA_IM	=> stg6_do_im);
    	
	U_FFT_STG6_TW : hybrid_tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "block", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_1024.mem", 
		IN_WIDTH		=> (STG6_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG6_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG6_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> HYBRID_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg6_osync,
		I_DATA_RE	=> stg6_do_re,
		I_DATA_IM	=> stg6_do_im, 
		I_CTRL_MODE	=> stg6_radix2_radix22_sel,
		O_SYNC		=> tw6_osync,
		O_DATA_RE	=> tw6_do_re,
		O_DATA_IM	=> tw6_do_im);
	
	U_FFT_STG5: hybrid_r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG5_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG5_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -5        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_isync,
		I_DATA_RE	=> stg5_di_re,  
		I_DATA_IM	=> stg5_di_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel, 
		O_SYNC		=> stg5_osync,
		O_DATA_RE	=> stg5_do_re,
		O_DATA_IM	=> stg5_do_im);		
		
	U_FFT_STG5_TW : hybrid_tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "block", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_256.mem", 
		IN_WIDTH		=> (STG5_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG5_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG5_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> HYBRID_TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg5_osync,
		I_DATA_RE	=> stg5_do_re,
		I_DATA_IM	=> stg5_do_im, 
		I_CTRL_MODE	=> stg5_radix2_radix22_sel,
		O_SYNC		=> tw5_osync,
		O_DATA_RE	=> tw5_do_re,
		O_DATA_IM	=> tw5_do_im);
			
	U_FFT_STG4: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG4_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG4_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -5        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw5_osync,
		I_DATA_RE	=> tw5_do_re,  
		I_DATA_IM	=> tw5_do_im,  
		O_SYNC		=> stg4_osync,
		O_DATA_RE	=> stg4_do_re,
		O_DATA_IM	=> stg4_do_im);		
		
	U_FFT_STG4_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_64.mem", 
		IN_WIDTH		=> (STG4_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG4_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG4_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg4_osync,
		I_DATA_RE	=> stg4_do_re,
		I_DATA_IM	=> stg4_do_im, 
		O_SYNC		=> tw4_osync,
		O_DATA_RE	=> tw4_do_re,
		O_DATA_IM	=> tw4_do_im);
	
	U_FFT_STG3: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG3_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG3_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -5        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw4_osync,
		I_DATA_RE	=> tw4_do_re,  
		I_DATA_IM	=> tw4_do_im,  
		O_SYNC		=> stg3_osync,
		O_DATA_RE	=> stg3_do_re,
		O_DATA_IM	=> stg3_do_im);		
				
	U_FFT_STG3_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_16.mem", 
		IN_WIDTH		=> (STG3_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG3_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG3_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg3_osync,
		I_DATA_RE	=> stg3_do_re,
		I_DATA_IM	=> stg3_do_im, 
		O_SYNC		=> tw3_osync,
		O_DATA_RE	=> tw3_do_re,
		O_DATA_IM	=> tw3_do_im);	
	
	U_FFT_STG2: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG2_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG2_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -5        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw3_osync,
		I_DATA_RE	=> tw3_do_re,  
		I_DATA_IM	=> tw3_do_im,  
		O_SYNC		=> stg2_osync,
		O_DATA_RE	=> stg2_do_re,
		O_DATA_IM	=> stg2_do_im);		
				
	U_FFT_STG2_TW : tw_phaser
	generic map(
		DEVICE			=> DEVICE,
		BF_TYPE			=> "Radix22",
		CMULT_N_DSP48	=> CMULT_N_DSP48,
		RAM_TYPE      	=> "distributed", -- "auto" or "distributed" or "block" or "ultra" 
	    OPERATING_MODE  => "no_change", -- "no_change" or "read_first" or "write_first"
	    RAM_INIT_FILE   => "tw_4.mem", 
		IN_WIDTH		=> (STG2_IN_WIDTH+2),	-- [ Input Data Bit Width Parameter  ] 
		OUT_WIDTH		=> (STG2_IN_WIDTH+2),	-- [ Output Data Bit Width Parameter ]
		N_FFT			=> STG2_N_SIZE,			
		TW_WIDTH		=> 16,			
		TW_LATENCY		=> 2,				
		OSYNC_TIMING	=> TW_PHASER_O_SYNC_TIMING)
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> stg2_osync,
		I_DATA_RE	=> stg2_do_re,
		I_DATA_IM	=> stg2_do_im, 
		O_SYNC		=> tw2_osync,
		O_DATA_RE	=> tw2_do_re,
		O_DATA_IM	=> tw2_do_im);			
		
	U_FFT_STG1: r22_sdf
	generic map(
	    DEVICE          => DEVICE,	 			-- "7SERIES" or "ULTRASCALE"
		IN_WIDTH		=> STG1_IN_WIDTH	,	-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE			=> STG1_N_SIZE		,	-- [ FFT Point Size Parameter        ]   
		OSYNC_DELAY		=> -1        )			-- [ O_SYNC Timing Delay Parameter	 ]    
	port map (
		I_RSTB		=> I_RSTB,
		I_CLK		=> I_CLK,
		I_SYNC		=> tw2_osync,
		I_DATA_RE	=> tw2_do_re,  
		I_DATA_IM	=> tw2_do_im,  
		O_SYNC		=> stg1_osync,
		O_DATA_RE	=> stg1_do_re  ,
		O_DATA_IM	=> stg1_do_im  );			
		
	g_FFT_OUT : if nIFFT_FFT_SEL = true generate -- FFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC	<= stg1_osync; 
			O_DATA_RE	<= stg1_do_re; 
			O_DATA_IM	<= stg1_do_im; 
		end if;
	end process;
    end generate;
    
    g_iFFT_OUT : if nIFFT_FFT_SEL = false generate -- iFFT
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			O_SYNC	<= stg1_osync; 
			O_DATA_RE	<= stg1_do_re; 
			O_DATA_IM	<= (not stg1_do_im) + 1; 
		end if;
	end process;
	end generate;
		
end struct;
-------------------------------------------------------------------------------------------------------------------------------

