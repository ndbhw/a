-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix2 SDF Component
-- File Name		: r2_sdf.VHD
-- Date				: 2022.01.11
-- Revision			: 1
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 	  The block include list below
		
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;

-------------------------------------------------------------------------------------------------------------------------------
entity r2_sdf is 
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		IN_WIDTH			: integer;				-- [ Input Data Bit Width Parameter  ]                
		N_SIZE				: integer;				-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);				-- [ O_SYNC Timing Delay Parameter	 ]      
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector(IN_WIDTH downto 0);
		O_DATA_IM		: out std_logic_vector(IN_WIDTH downto 0));
end r2_sdf;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of r2_sdf is

	component r2_bf_ctrl
	generic (                          
		N_SIZE				: integer;		-- [ FFT Point Size Parameter        ] 
		OSYNC_DELAY			: integer);		-- [ O_SYNC Timing Delay Parameter	 ]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB  			: in std_logic; 	-- system reset(low activated)
		I_CLK	  			: in std_logic;		-- main clock
		I_SYNC			: in std_logic;
      	-- *************************************************************
      	-- TO FFT_STG0 module
      	-- *************************************************************
		O_BF_CTRL_S	 	: out std_logic;
		O_SYNC	  		: out std_logic
	);
	end component;

	component radix2_bf
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; -- "7SERIES" or "ULTRASCALE"
		IN_WIDTH			: integer;			-- [ Input Data Bit Width Parameter  ]                 
		N_SIZE				: integer);			-- [ FFT Point Size Parameter        ]    
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- INTERNAL (BLOCK) INTERFACE SIGNALS --------------------------
		I_CTRL_S			: in std_logic;		-- Control Bit 'S'
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE			: out std_logic_vector((IN_WIDTH-1) downto 0);
		O_DATA_IM			: out std_logic_vector((IN_WIDTH-1) downto 0));
	end component;
		
	-- *************************************************************
	-- 		Control Signal
	-- *************************************************************
	signal bfi_ctrl_s		: std_logic;

	-- *************************************************************
	-- 		Data Path
	-- *************************************************************
	signal bfi_di_re 		: std_logic_vector((IN_WIDTH) downto 0);
	signal bfi_di_im 		: std_logic_vector((IN_WIDTH) downto 0);
			
begin

	bfi_di_re <= I_DATA_RE(IN_WIDTH-1) & I_DATA_RE;
	bfi_di_im <= I_DATA_IM(IN_WIDTH-1) & I_DATA_IM;
	
	U_R22_CTL: r2_bf_ctrl
	generic map(           
		N_SIZE		=> N_SIZE,	
		OSYNC_DELAY	=> OSYNC_DELAY)	
	port map (
		I_RSTB 		=> I_RSTB,
		I_CLK	 		=> I_CLK,
		I_SYNC		=> I_SYNC,
		O_BF_CTRL_S	=> bfi_ctrl_s,
		O_SYNC	  	=> O_SYNC);
		
	U_R22_BFI: radix2_bf
	generic map ( 
		DEVICE		=> DEVICE,
		IN_WIDTH	=> (IN_WIDTH+1),	
		N_SIZE		=> N_SIZE)
	port map (
		I_CLK		=> I_CLK,
		I_CTRL_S	=> bfi_ctrl_s,
		I_DATA_RE	=> bfi_di_re,
		I_DATA_IM	=> bfi_di_im,
		O_DATA_RE		=> O_DATA_RE,
		O_DATA_IM		=> O_DATA_IM);
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------
		