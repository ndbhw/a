-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- Project Name		: Radix22 SDF Component
-- File Name		: hybrid_r22_sdf.VHD
-- Date				: 2022.04.08
-- Revision			: 4
-- Engineer			: Jihoon Han
-- Company			: Samsung Electronics
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Functional Description
-- 	  The block include list below      
-- ****************************************************************************************************************************
-- ****************************************************************************************************************************
-- (X)Revision History    
-- [2021.01.24, v1.00, jihoon.han] initial release                           
-- [2022.02.18, v2.00, jihoon.han] Vector Cross checked with Hyeri-Bang         
-- [2022.03.15, v2.10, jihoon.han] Revised on Failure Diagnosis System, Entity Name Changed(dlfe_nfft_wrapper => nfft_wrapper)               
-- [2022.04.01, v2.11, jihoon.han] sign extension error corrected  
-- [2022.04.19, v2.20, jihoon.han] Add Xtreme Mode(DSP Butterfly)
-- ****************************************************************************************************************************
library ieee; use ieee.std_logic_1164.all; use ieee.std_logic_unsigned.all;

-------------------------------------------------------------------------------------------------------------------------------
entity hybrid_r22_sdf is 
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean;					-- [ Xtreme dsp mode				] false or true 
		IN_WIDTH			: integer;					-- [ Input Data Bit Width Parameter ]                
		N_SIZE				: integer;					-- [ FFT Point Size Parameter       ] 
		OSYNC_DELAY			: integer);					-- [ O_SYNC Timing Delay Parameter	]      
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB			: in std_logic; 	-- system reset(low activated)
		I_CLK			: in std_logic;		-- main clock
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_SYNC			: in std_logic;
		I_DATA_RE		: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM		: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_SYNC			: out std_logic;
		O_DATA_RE		: out std_logic_vector((IN_WIDTH+1) downto 0);
		O_DATA_IM		: out std_logic_vector((IN_WIDTH+1) downto 0));
end hybrid_r22_sdf;
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
architecture struct of hybrid_r22_sdf is

	component hybrid_r22_bf_ctrl
	generic (                          
		N_SIZE				: integer;		-- [ FFT Point Size Parameter        ] 
		XTREME_DSP_MODE		: boolean;		-- [ Xtreme dsp mode			] false or true 
		OSYNC_DELAY			: integer);		-- [ O_SYNC Timing Delay Parameter	 ]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_RSTB  		: in std_logic; 	-- system reset(low activated)
		I_CLK	  		: in std_logic;		-- main clock
		I_SYNC			: in std_logic;
		-- *************************************************************
		-- Control DATA
		-- *************************************************************		
		I_CTRL_MODE		: in std_logic;	-- '0' = Radix-2 , '1' = Radix-2^2, 
      	-- *************************************************************
      	-- TO FFT_STG0 module
      	-- *************************************************************
		O_BFI_CTRL_S	: out std_logic;
		O_BFI_CTRL_T	: out std_logic;
		O_BFII_CTRL_S	: out std_logic;
		O_BFII_CTRL_T	: out std_logic;
		O_SYNC	  		: out std_logic
	);
	end component;

	component radix2_bf
	generic (
	    DEVICE          	: string  := "ULTRASCALE"; 	-- "7SERIES" or "ULTRASCALE"
		XTREME_DSP_MODE		: boolean;					-- [ Xtreme dsp mode				] false or true 
		IN_WIDTH			: integer;					-- [ Input Data Bit Width Parameter ]                 
		N_SIZE				: integer);					-- [ FFT Point Size Parameter       ]  
	port (
		-- EXTERNAL/INTERNAL INTERFACE SIGNALS -------------------------
		I_CLK				: in std_logic;		-- main clock
		-- INTERNAL (BLOCK) INTERFACE SIGNALS --------------------------
		I_CTRL_S			: in std_logic;		-- Control Bit 'S'
		-- *************************************************************
		-- INPUT DATA
		-- *************************************************************
		I_DATA_RE			: in std_logic_vector((IN_WIDTH-1) downto 0);
		I_DATA_IM			: in std_logic_vector((IN_WIDTH-1) downto 0);
		-- *************************************************************
		-- OUTPUT DATA
		-- *************************************************************
		O_DATA_RE			: out std_logic_vector((IN_WIDTH-1) downto 0);
		O_DATA_IM			: out std_logic_vector((IN_WIDTH-1) downto 0));
	end component;
		
	-- *************************************************************
	-- 		Control Signal
	-- *************************************************************
	signal bfi_ctrl_s		: std_logic;
	signal bfi_ctrl_t		: std_logic;
	signal bfii_ctrl_s		: std_logic;
	signal bfii_ctrl_t		: std_logic;
	signal bfii_ctrl_t_d1	: std_logic;
	signal bfii_ctrl_t_d2	: std_logic;
	signal minus_j_mul_en	: std_logic;
	
	-- *************************************************************
	-- 		Data Path
	-- *************************************************************
	signal bfi_di_re 		: std_logic_vector((IN_WIDTH) downto 0);
	signal bfi_di_im 		: std_logic_vector((IN_WIDTH) downto 0);
	signal bfi_do_re		: std_logic_vector((IN_WIDTH) downto 0);
	signal bfi_do_im		: std_logic_vector((IN_WIDTH) downto 0);
	signal tmp_bfii_di_re	: std_logic_vector((IN_WIDTH) downto 0);
	signal tmp_bfii_di_im	: std_logic_vector((IN_WIDTH) downto 0);
	signal bfii_di_re		: std_logic_vector((IN_WIDTH+1) downto 0);
	signal bfii_di_im		: std_logic_vector((IN_WIDTH+1) downto 0);
			
begin

	bfi_di_re <= (I_DATA_RE(IN_WIDTH-1) & I_DATA_RE);
	bfi_di_im <= (I_DATA_IM(IN_WIDTH-1) & I_DATA_IM);
	
	
	g_BF_LUT : if XTREME_DSP_MODE = false generate
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			bfii_ctrl_t_d1 <= bfii_ctrl_t;
			if I_CTRL_MODE = '0' then
				bfii_ctrl_t_d2 <= bfi_ctrl_t;
			else 
				bfii_ctrl_t_d2 <= bfii_ctrl_t_d1;
			end if;
		end if;
	end process;
    end generate;
    
    g_BF_DSP : if XTREME_DSP_MODE = true generate
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_MODE = '0' then
				bfii_ctrl_t_d2 <= bfi_ctrl_t;
			else 
				bfii_ctrl_t_d2 <= bfii_ctrl_t;
			end if;
		end if;
	end process;
    end generate;
    
    process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			minus_j_mul_en <= bfii_ctrl_s and bfii_ctrl_t;
		end if;
	end process;
	
	process(I_CLK)
	begin
		if I_CLK'event and I_CLK = '1' then
			if I_CTRL_MODE = '0' then
				tmp_bfii_di_re	<= (I_DATA_RE(IN_WIDTH-1) & I_DATA_RE);
				tmp_bfii_di_im	<= (I_DATA_IM(IN_WIDTH-1) & I_DATA_IM);			
			elsif minus_j_mul_en = '1' then
				tmp_bfii_di_re	<= bfi_do_im;
			    tmp_bfii_di_im	<= (not bfi_do_re) + 1;
			else
				tmp_bfii_di_re	<= bfi_do_re;
			    tmp_bfii_di_im	<= bfi_do_im;
			end if;
		end if;
	end process;

	bfii_di_re <= tmp_bfii_di_re(IN_WIDTH) & tmp_bfii_di_re;
	bfii_di_im <= tmp_bfii_di_im(IN_WIDTH) & tmp_bfii_di_im;
	
	U_R22_CTL: hybrid_r22_bf_ctrl
	generic map(           
		N_SIZE			=> N_SIZE,
		XTREME_DSP_MODE	=> XTREME_DSP_MODE,	
		OSYNC_DELAY		=> OSYNC_DELAY)	
	port map (
		I_RSTB  		=> I_RSTB,
		I_CLK	  		=> I_CLK,
		I_SYNC	 		=> I_SYNC,
		I_CTRL_MODE		=> I_CTRL_MODE,		
		O_BFI_CTRL_S	=> bfi_ctrl_s,
		O_BFI_CTRL_T	=> bfi_ctrl_t,
		O_BFII_CTRL_S	=> bfii_ctrl_s,
		O_BFII_CTRL_T	=> bfii_ctrl_t,
		O_SYNC	  		=> O_SYNC);
		
	U_R22_BFI: radix2_bf
	generic map ( 
		DEVICE			=> DEVICE,
		XTREME_DSP_MODE	=> XTREME_DSP_MODE,
		IN_WIDTH		=> (IN_WIDTH+1),	
		N_SIZE			=> N_SIZE)
	port map (
		I_CLK		=> I_CLK,
		I_CTRL_S	=> bfi_ctrl_s,
		I_DATA_RE	=> bfi_di_re,
		I_DATA_IM	=> bfi_di_im,
		O_DATA_RE	=> bfi_do_re,
		O_DATA_IM	=> bfi_do_im);
		
	U_R22_BFII: radix2_bf
	generic map ( 
		DEVICE			=> DEVICE,
		XTREME_DSP_MODE	=> XTREME_DSP_MODE,
		IN_WIDTH		=> (IN_WIDTH+2),	
		N_SIZE			=> (N_SIZE/2))
	port map (
		I_CLK		=> I_CLK,
		I_CTRL_S 	=> bfii_ctrl_t_d2,
		I_DATA_RE	=> bfii_di_re,
		I_DATA_IM	=> bfii_di_im,
		O_DATA_RE	=> O_DATA_RE,
		O_DATA_IM	=> O_DATA_IM);
	
end struct;
-------------------------------------------------------------------------------------------------------------------------------
		