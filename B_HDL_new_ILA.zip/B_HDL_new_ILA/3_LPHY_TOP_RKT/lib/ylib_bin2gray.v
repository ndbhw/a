////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_bin2gray
//  Author       : jyzoo.lee@samsung.com 
//  Description  : binary to gray converter
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.28 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_bin2gray #(
    parameter WIDTH         =   32
)(
        input	wire    [WIDTH-1:0]     i_in
    ,   output	wire    [WIDTH-1:0]     o_out
);
function [WIDTH-1:0] bin2gray; 
input [WIDTH-1:0] value; 
integer i; 
begin  
   bin2gray[WIDTH-1] = value[WIDTH-1]; 
   for (i=WIDTH-1;i>0;i=i-1) 
      bin2gray[i-1] = value[i]^value[i-1]; 
end 
endfunction 
assign o_out = bin2gray(i_in); 
endmodule 
