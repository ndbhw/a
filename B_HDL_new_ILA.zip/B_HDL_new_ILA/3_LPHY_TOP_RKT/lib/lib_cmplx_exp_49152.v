////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : lib_cmplx_exp
//  Author       : Song, Moon-Gun
//  Description  : Bit-Reverse Order Seril Input to Natural Parallel Output
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2019.07.15 |Daye Won       | 49152 ver. Release
//  ------------+---------------+-----------------------------------------------
//   2019.10.21 |ms1206.choi    | Delete Reset
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module lib_cmplx_exp_49152
#(
      parameter CJ = 0              // 0: cos + j*sin , 1: cos -j*sin
    , parameter SIN_TABLE_BW = 16   // 16 or 13 
) 
(
      input  wire                            i_clk       // Clock 

    , input  wire                            i_phase_vld // phase enable
    , input  wire        [          16-1:0]  i_phase     // Input Phase

    , output reg                             o_vld
    , output reg  signed [SIN_TABLE_BW-1:0]  o_cos       // Output Cosine
    , output reg  signed [SIN_TABLE_BW-1:0]  o_sin       // Output Sine        
);

reg [16-1:0] r_phase_14_00;
reg          r_phase_15;
reg          r_phase_16;

always @(posedge i_clk ) begin
    if(i_phase_vld) begin
        if (i_phase < 16'd12288) begin
            r_phase_16      <=  1'b0    ;
            r_phase_15      <=  1'b0    ;
            r_phase_14_00   <=  i_phase ;
        end
        else if (i_phase < 16'd24576) begin
            r_phase_16      <=  1'b0    ;
            r_phase_15      <=  1'b1    ;
            r_phase_14_00   <=  i_phase - 16'd12288  ;
        end
        else if (i_phase < 16'd36864) begin
            r_phase_16      <=  1'b1    ;
            r_phase_15      <=  1'b0    ;
            r_phase_14_00   <=  i_phase - 16'd24576  ;
        end
        else begin
            r_phase_16      <=  1'b1    ;
            r_phase_15      <=  1'b1    ;
            r_phase_14_00   <=  i_phase - 16'd36864  ;
        end
    end
end

reg r_vld_1d, r_vld_2d, r_vld_3d;

always @(posedge i_clk ) begin
        r_vld_1d <= i_phase_vld;
        r_vld_2d <= r_vld_1d;
        r_vld_3d <= r_vld_2d;
        o_vld    <= r_vld_3d;
end


wire [14-1:0] w_phase_14_00_0 = $signed(14'd12288) - $signed(r_phase_14_00[14-1:0]);
wire [14-1:0] w_phase_14_00_1 = (r_phase_14_00[14-1:0] == 14'd0) ? 14'd12287 : w_phase_14_00_0 ;
reg  [14-1:0] r_cos_idx_1d  ;
reg  [14-1:0] r_sin_idx_1d  ;
reg           r_phase_15_1d ;
reg           r_phase_16_1d ;

always @(posedge i_clk ) begin
    if(r_vld_1d) begin
        if(r_phase_15 == 1'b0) begin
            r_cos_idx_1d <= w_phase_14_00_1         ;
            r_sin_idx_1d <= r_phase_14_00[14-1:0]   ;
        end
        else begin
            r_cos_idx_1d <= r_phase_14_00[14-1:0]   ;
            r_sin_idx_1d <= w_phase_14_00_1         ;
        end
        r_phase_15_1d <= r_phase_15;
        r_phase_16_1d <= r_phase_16;
    end
end

wire signed [SIN_TABLE_BW-1:0] w_cos_2d;
wire signed [SIN_TABLE_BW-1:0] w_sin_2d;
reg                  r_cos_sel_2d;
reg                  r_sin_sel_2d;


lib_sin_table_16_1 u00_cos(.i_clk(i_clk), .i_idx(r_cos_idx_1d), .o_sin(w_cos_2d));
lib_sin_table_16_1 u01_sin(.i_clk(i_clk), .i_idx(r_sin_idx_1d), .o_sin(w_sin_2d));


always @(posedge i_clk ) begin
    if(r_vld_2d) begin
        r_cos_sel_2d <= r_phase_15_1d^r_phase_16_1d;
        r_sin_sel_2d <= r_phase_16_1d;
    end
end

always @(posedge i_clk ) begin
    if(r_vld_3d) begin
        o_cos <= (r_cos_sel_2d == 1'b0) ? w_cos_2d : -w_cos_2d;
        o_sin <= (r_sin_sel_2d == CJ  ) ? w_sin_2d : -w_sin_2d;
    end
end


endmodule


