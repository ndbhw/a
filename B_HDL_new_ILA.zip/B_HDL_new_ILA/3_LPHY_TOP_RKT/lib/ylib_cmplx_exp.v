////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : lib_cmplx_exp
//  Author       : Song, Moon-Gun
//  Description  : Bit-Reverse Order Seril Input to Natural Parallel Output
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2019.02.04 |Soocheol Kyeong| addition of new phase size with 14bit
//  ------------+---------------+-----------------------------------------------
//   2019.03.30 |Donggeun Jo    | Change table from lib_sin4096_table_16_fpga to 
//
////////////////////////////////////////////////////////////////////////////////

// 4 delay
module ylib_cmplx_exp
#(
      parameter CJ = 0              // 0: cos + j*sin , 1: cos -j*sin
    , parameter SIN_TABLE_BW = 16   // 16 or 13 
    , parameter PW			 = 14	// 12 or 14 /bitwidth of phase
) 
(
      input  wire                            i_clk       // Clock 

    , input  wire                            i_phase_vld // phase enable
    , input  wire        [         PW-1:0]   i_phase     // Input Phase

    , output reg                             o_vld	=0
    , output reg  signed [SIN_TABLE_BW-1:0]  o_cos  =0     // Output Cosine
    , output reg  signed [SIN_TABLE_BW-1:0]  o_sin  =0     // Output Sine        
);

localparam PW_1Q	= PW-2;

reg [PW_1Q-1:0]		r_phase_09_00	= 0;
reg					r_phase_10		= 0;
reg          		r_phaee_11		= 0;

always @(posedge i_clk) begin
    if(i_phase_vld) begin
        {r_phaee_11,r_phase_10, r_phase_09_00} <= i_phase;
    end
end

reg r_vld_1d=0;
reg r_vld_2d=0;
reg r_vld_3d=0;
always @(posedge i_clk) begin
        r_vld_1d <= i_phase_vld;
        r_vld_2d <= r_vld_1d;
        r_vld_3d <= r_vld_2d;
        o_vld    <= r_vld_3d;
end


wire [  PW_1Q:0] w_phase_09_00_0 = $signed(2**PW_1Q) - $signed({1'b0,r_phase_09_00});
wire [PW_1Q-1:0] w_phase_09_00_1 = (w_phase_09_00_0[PW_1Q] == 1'b1) ? {(PW_1Q){1'b1}} : w_phase_09_00_0[PW_1Q-1:0];
reg  [PW_1Q-1:0] r_cos_idx_1d=0;
reg  [PW_1Q-1:0] r_sin_idx_1d=0;
reg  [PW_1Q-1:0] r_phase_10_1d=0;
reg  [PW_1Q-1:0] r_phase_11_1d=0;

always @(posedge i_clk) begin
     if(r_vld_1d) begin
        if(r_phase_10 == 1'b0) begin
            r_cos_idx_1d <= w_phase_09_00_1;
            r_sin_idx_1d <= r_phase_09_00;
        end
        else begin
            r_cos_idx_1d <= r_phase_09_00;
            r_sin_idx_1d <= w_phase_09_00_1;
        end
        r_phase_10_1d <= r_phase_10;
        r_phase_11_1d <= r_phaee_11;
    end
end

wire signed [SIN_TABLE_BW-1:0] w_cos_2d;
wire signed [SIN_TABLE_BW-1:0] w_sin_2d;
reg                  r_cos_sel_2d=0;
reg                  r_sin_sel_2d=0;
//wire signed [16-1:0] w_cos_2d_16b;
//wire signed [16-1:0] w_sin_2d_16b;


generate 
if( (SIN_TABLE_BW == 16) && (PW==12)) begin
ylib_sin_table_expj_d16b u00_cos(.i_clk(i_clk), .i_idx(r_cos_idx_1d), .o_sin(w_cos_2d));
ylib_sin_table_expj_d16b u01_sin(.i_clk(i_clk), .i_idx(r_sin_idx_1d), .o_sin(w_sin_2d));
end
else if( (SIN_TABLE_BW == 13) && (PW==12)) begin
//lib_sin_table_13_fpga u00_cos(.i_clk(i_clk), .i_idx(r_cos_idx_1d), .o_sin(w_cos_2d));
//lib_sin_table_13_fpga u01_sin(.i_clk(i_clk), .i_idx(r_sin_idx_1d), .o_sin(w_sin_2d));
end
else if( (SIN_TABLE_BW == 16) && (PW==14)) begin
//lib_sin4096_table_16_fpga u00_cos(.i_clk(i_clk), .i_idx(r_cos_idx_1d), .o_sin(w_cos_2d));
//lib_sin4096_table_16_fpga u01_sin(.i_clk(i_clk), .i_idx(r_sin_idx_1d), .o_sin(w_sin_2d));
ylib_sin_table_expj14_d16b u00_cos(.i_clk(i_clk), .i_idx(r_cos_idx_1d), .o_sin(w_cos_2d));
ylib_sin_table_expj14_d16b u01_sin(.i_clk(i_clk), .i_idx(r_sin_idx_1d), .o_sin(w_sin_2d));
end
endgenerate


always @(posedge i_clk) begin
    if(r_vld_2d) begin
        r_cos_sel_2d <= r_phase_10_1d^r_phase_11_1d;
        r_sin_sel_2d <= r_phase_11_1d;
    end
end

always @(posedge i_clk) begin
    if(r_vld_3d) begin
        o_cos <= (r_cos_sel_2d == 1'b0) ? w_cos_2d : -w_cos_2d;
        o_sin <= (r_sin_sel_2d == CJ  ) ? w_sin_2d : -w_sin_2d;
    end
end


endmodule


