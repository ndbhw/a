////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_shift_reg
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Shift Register (recommended template)
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.9.17  |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_shift_reg #(
    parameter WIDTH = 32
   ,parameter VENDOR = "Intel"  // Xilinx or Intel
)(
	input clk, enable,
	input sr_in,
	output sr_out
);
generate if(VENDOR == "Intel") begin
// Declare the shift register
reg [WIDTH-1:0] sr;
// Shift everything over, load the incoming bit
always @ (posedge clk)
begin
	if (enable == 1'b1)
	begin
		sr[WIDTH-1:1] <= sr[WIDTH-2:0];
		sr[0] <= sr_in;
	end
end
// Catch the outgoing bit
assign sr_out = sr[WIDTH-1];
end
else begin //Xilinx
(* srl_style = "reg_srl_reg" *)reg [WIDTH-1:0] shreg;
integer i;
always @(posedge clk)
begin
for (i = 0; i < WIDTH-1; i = i+1)
shreg[i+1] <= shreg[i];
shreg[0] <= sr_in;
end
assign sr_out = shreg[WIDTH-1];
end
endgenerate
endmodule
