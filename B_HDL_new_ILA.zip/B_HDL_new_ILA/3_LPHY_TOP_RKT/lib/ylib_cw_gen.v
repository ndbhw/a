////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_cw_gen
//  Author       : jyzoo.lee@samsung.com
//  Description  : single tone continuous wave generator
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.21 |jyzoo.lee      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cw_gen 
(
        input   wire                    i_rst
    ,   input   wire                    i_clk
    ,   input	wire                    i_cw_on
    ,   output	reg                     o_cw_sig_en
    ,   output	reg     [2*16-1:0]      o_cw_sig_iq
);

reg  [11:0]             r_phase         ;
reg  [1:0]              r_cw_ind        ;
wire [13:0]             w_tone_i_tmp    ; 
wire [13:0]             w_tone_q_tmp    ; 
reg  [13:0]             r_tone_i_tmp    ; 
reg  [13:0]             r_tone_q_tmp    ; 
reg  [14:0]             r_tone_i        ;
reg  [14:0]             r_tone_q        ;
always@(posedge i_clk) begin 
    if(i_rst) begin
        r_phase  <=  12'd0   ;
        r_cw_ind <=  2'd0    ;
    end
    else if(i_cw_on) begin
        r_phase  <=  r_phase + 1'd1 ;
        r_cw_ind <=  r_phase[11:10] ;
    end
end
ylib_cw_rom u00_cw_i 
(
    .clk    (   i_clk                                               )
   ,.en     (   i_cw_on                                             )
   ,.addr   (   r_phase[10] ? 10'h3FF-r_phase[9:0] : r_phase[9:0]   )
   ,.dout   (   w_tone_i_tmp                                        )
);    
ylib_cw_rom u01_cw_q 
(
    .clk    (   i_clk                                               )
   ,.en     (   i_cw_on                                             )
   ,.addr   (   r_phase[10] ? r_phase[9:0] : 10'h3FF-r_phase[9:0]   )
   ,.dout   (   w_tone_q_tmp                                        )
);    
always@(posedge i_clk) begin 
    r_tone_i_tmp    <=  w_tone_i_tmp  ; 
    r_tone_q_tmp    <=  w_tone_q_tmp  ; 
end
always@(posedge i_clk) begin 
    if(i_cw_on) begin
        if(r_cw_ind[1]==1'b0) begin
            r_tone_i    <=  {1'd0,r_tone_i_tmp}         ;
        end
        else if(r_cw_ind[1]==1'b1) begin
            r_tone_i    <=  ~{1'd0,r_tone_i_tmp}+1'b1   ;
        end
    end
end
always@(posedge i_clk) begin 
    if(i_cw_on) begin
        if(r_cw_ind==2'b00||r_cw_ind==2'b11) begin
            r_tone_q    <=  {1'd0,r_tone_q_tmp}         ;
        end
        else if(r_cw_ind==2'b01||r_cw_ind==2'b10) begin
            r_tone_q    <=  ~{1'd0,r_tone_q_tmp}+1'b1   ;
        end
    end
end
always@(posedge i_clk) begin  
    o_cw_sig_en <= i_cw_on ;
    if(i_cw_on) begin
        o_cw_sig_iq <=  {r_tone_i[14],r_tone_i,r_tone_q[14],r_tone_q}   ;
    end
end

endmodule
