////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20 
//  Module       : ylib_xssi
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Calculate xssi
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.21 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.06.22 |jyzoo.lee      | auto set delay corresponding XSSI ID
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_xssi
#(
    parameter  [6:0]    NUM_FRAME       =   7'd8          
   ,parameter  [6:0]    RPT_FRAME       =   7'd0          
   ,parameter           BW_SIG          =   15
   ,parameter  [6:0]    ID_XSSI         =   7'h0 
)(
        input   wire                                i_rst                      
    ,   input   wire                                i_clk                      
    ,   input   wire    [0:0]                       i_frame_sync
    ,   input   wire    [0:0]                       i_sig_en
    ,   input   wire    [BW_SIG-1:0]                i_sig_i
    ,   input   wire    [BW_SIG-1:0]                i_sig_q
    ,   output  reg     [01-1:0]                    o_xssi_en
    ,   output  reg     [07-1:0]                    o_xssi_id
    ,   output  reg     [32-1:0]                    o_xssi
);

integer i ;

reg [6:0] r_xssi_frame ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_xssi_frame <= 7'd0 ;
    end
    else if(i_frame_sync) begin
        r_xssi_frame <= (r_xssi_frame == NUM_FRAME-7'd1) ? 7'd0 : r_xssi_frame + 1'd1 ;
    end
end
reg r_xssi_report_sync  ;
always@(posedge i_clk) begin
    r_xssi_report_sync  <=  (r_xssi_frame==RPT_FRAME)&&i_frame_sync   ;
end
reg [0:0]           r_pow2_en       ;
reg [2*BW_SIG-1:0]  r_pow2_i        ;
reg [2*BW_SIG-1:0]  r_pow2_q        ;
reg [0:0]           r_pow2_iq_en    ;
reg [2*BW_SIG:0]    r_pow2_iq       ;
reg [63:0]          r_xssi          ;
reg [0:0]           r_xssi_rpt_en   ;
reg [63:0]          r_xssi_rpt      ;
always@(posedge i_clk) begin 
    r_pow2_en   <=  i_sig_en    ;
    if(i_sig_en) begin
        r_pow2_i    <=  $signed({{{BW_SIG}{i_sig_i[BW_SIG-1]}},i_sig_i})*$signed({{{BW_SIG}{i_sig_i[BW_SIG-1]}},i_sig_i})   ;
        r_pow2_q    <=  $signed({{{BW_SIG}{i_sig_q[BW_SIG-1]}},i_sig_q})*$signed({{{BW_SIG}{i_sig_q[BW_SIG-1]}},i_sig_q})   ;
    end
end
always@(posedge i_clk) begin 
    r_pow2_iq_en    <=  r_pow2_en  ;
    if(r_xssi_report_sync&&r_pow2_en==1'd0) begin
        r_pow2_iq       <=  {{2*BW_SIG+1}{1'd0}} ;
    end
    else if(r_pow2_en) begin
        r_pow2_iq       <=  {1'd0,r_pow2_i}+{1'd0,r_pow2_q}   ;
    end
end
always@(posedge i_clk) begin 
    if(r_xssi_report_sync&&r_pow2_iq_en==1'd0) begin
        r_xssi  <= 64'd0    ;
    end
    else if(r_pow2_iq_en) begin
        r_xssi  <= r_xssi_report_sync ? 64'd0 : r_xssi + r_pow2_iq  ;
    end        
end
always@(posedge i_clk) begin 
    r_xssi_rpt_en <= r_xssi_report_sync ;
    if(r_xssi_report_sync) begin
        r_xssi_rpt  <= r_xssi     ;
    end
end

wire    w_done_out  ;
wire    [31:0] w_mantissa_out   ;
MANTISSA_FRAMER u00_mantissa
(
     .RST               (   i_rst               )
    ,.CLK               (   i_clk               )
    ,.START_IN          (   r_xssi_rpt_en       )
    ,.DATA_IN           (   r_xssi_rpt          )
    ,.DONE_OUT          (   w_done_out          )
    ,.MANTISSA_OUT      (   w_mantissa_out      )
);

wire         w_dly_done_out      ;
wire [31:0]  w_dly_mantissa_out  ;
ylib_reg #(
     .WIDTH(    33              ) 
    ,.DEPTH(    ID_XSSI[3:2]    )) 
u01_out_reg
(
     .i_clk      (  i_clk                                   )
    ,.i_in       (  {w_done_out     ,w_mantissa_out     }   )
    ,.o_out      (  {w_dly_done_out ,w_dly_mantissa_out }   )
);
always@(posedge i_clk) begin 
    o_xssi_en   <= w_done_out     ;
    if(w_dly_done_out) begin
        o_xssi      <= w_dly_mantissa_out   ;
        o_xssi_id   <= ID_XSSI              ;
    end
end
endmodule
