////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_rams_sdp
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Simple Dual-Port Block RAM (recommended template)
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.7.07  | taeyeong      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.7.09  | jyzoo.lee     | Xilinx Compatible
//  ------------+---------------+-----------------------------------------------
//   2021.2.02  | donggeun Jo   | Add Xilinx Ram style option
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_rams_sdp #(  
     parameter  WIDTH        =   32 
    ,parameter  DEPTH        =   1024 
    ,parameter  VENDOR       =   "Intel"
    ,parameter  RAM_STYLE    =   "auto"     // "ultra" "block"
)(
        input                                   clk
    ,   input                                   ena
    ,   input                                   enb
    ,   input                                   wea
    ,   input       [$clog2(DEPTH)-1:0]         addra
    ,   input       [$clog2(DEPTH)-1:0]         addrb
    ,   input       [WIDTH-1:0]                 dia
    ,   output  reg [WIDTH-1:0]                 dob
);

generate if (VENDOR == "Xilinx" && RAM_STYLE == "ultra") begin : Xilinx_uram
(* ram_style = "ultra" *) reg [WIDTH-1:0] ram [DEPTH-1:0] ;


integer i;
initial begin
    for (i=0; i<DEPTH; i=i+1) ram[i] = 0;
end

always@(posedge clk) begin 
    if(ena) begin
        if(wea)
            ram[addra] <= dia;
    end
end
always @(posedge clk) begin 
    if(enb)
        dob <= ram[addrb];
end
end


else if((VENDOR == "Xilinx" && RAM_STYLE == "block")) begin : Xilinx_bram
(* ram_style = "block" *) reg [WIDTH-1:0] ram [DEPTH-1:0] ;


integer i;
initial begin
    for (i=0; i<DEPTH; i=i+1) ram[i] = 0;
end

always@(posedge clk) begin 
    if(ena) begin
        if(wea)
            ram[addra] <= dia;
    end
end
always @(posedge clk) begin 
    if(enb)
        dob <= ram[addrb];
end
end

else if((VENDOR == "Xilinx" && RAM_STYLE != "ultra" && RAM_STYLE != "block" )) begin : Xilinx_auto
reg [WIDTH-1:0] ram [DEPTH-1:0] ;


integer i;
initial begin
    for (i=0; i<DEPTH; i=i+1) ram[i] = 0;
end

always@(posedge clk) begin 
    if(ena) begin
        if(wea)
            ram[addra] <= dia;
    end
end
always @(posedge clk) begin 
    if(enb)
        dob <= ram[addrb];
end
end


else begin : Intel
reg [WIDTH-1:0] ram [DEPTH-1:0] ;

initial 
begin : INIT
    integer i;
    for(i = 0; i < DEPTH; i = i + 1)
    begin
        ram[i]          = {WIDTH{1'b0}};
    end
end
     

always@(posedge clk)
begin
	if (ena&wea)
		ram[addra] <= dia;
    if (enb)
	    dob <= ram[addrb];
end

end
endgenerate

endmodule
