////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ref_vsync_gen
//  Author       : jyzoo.lee@samsung.com
//  Description  : reference sync generator for ORAN 
//                 minimum delay == 3
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.05.22 | jyzoo.lee     | initial release
//  ------------+---------------+-----------------------------------------------
//   2020.06.02 | jyzoo.lee     | Subframe Index Support
//  ------------+---------------+-----------------------------------------------
//   2020.06.11 | jyzoo.lee     | 15k Bug Fix
//  ------------+---------------+-----------------------------------------------
//   2020.09.11 | jyzoo.lee     | add internal enable resync
//  ------------+---------------+-----------------------------------------------
//   2020.11.17 | jyzoo.lee     | Add option to change slot increment type
//  ------------+---------------+-----------------------------------------------
//   2020.04.16 | jyzoo.lee     | 60k Bug Fix
//  ------------+---------------+-----------------------------------------------
//   2020.06.21 | jyzoo.lee     | Fix Bug when SLOT_INC_TYPE is Subframe
//  ------------+---------------+-----------------------------------------------
//   2021.10.21 | jyzoo.lee     | using ylib_pshift, minimum delay == 3
//  ------------+---------------+-----------------------------------------------
//   2021.10.25 | jyzoo.lee     | 3.75k support
//  ------------+---------------+-----------------------------------------------
//   2021.11.01 | jyzoo.lee     | reduce logic level, minimum delay == 4
//  ------------+---------------+-----------------------------------------------
//   2022.06.21 | jyzoo.lee     | reduce logic level
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ref_vsync_gen
#(
    parameter  SLOT_INC_TYPE   =   "FRAME"
)(
        input   wire                i_clk           
    ,   input   wire   [3:0]        i_mu 
    ,   input   wire   [21:0]       i_retard
    ,   input   wire                i_frame_sync           
    ,   input   wire                i_en            
    ,   output  reg                 o_frame_sync           
    ,   output  reg                 o_subfrm_sync          
    ,   output  reg                 o_slot_sync            
    ,   output  reg                 o_symbol_sync          
    ,   output  reg    [3:0]        o_subfrm                 
    ,   output  reg    [7:0]        o_slot                 
    ,   output  reg    [3:0]        o_symbol               
);

localparam      MU_SCS_015K             =   4'h0            ;
localparam      MU_SCS_030K             =   4'h1            ;
localparam      MU_SCS_060K             =   4'h2            ;
localparam      MU_SCS_120K             =   4'h3            ;
localparam      MU_SCS_240K             =   4'h4            ;
localparam      MU_SCS_3_75K            =   4'hd            ;
localparam      LEN_SUB_FRAME           =   18'd245760      ;       
localparam      NUM_SUBFRM_FRAME        =   4'd10           ;       
localparam      NUM_SYM_SLOT            =   4'd14           ;       
localparam      DLY_COMP                =   22'd3           ;       

reg [0:0]   r_frame_sync        ;
reg [7:0]   r_num_slot_frame    ;
reg [17:0]  r_len_lcp_sym       ;
reg [17:0]  r_len_ncp_sym       ;
reg [18:0]  r_len_lcp_slot      ;
reg [18:0]  r_len_ncp_slot      ;
reg [21:0]  r_retard            ;
reg [3:0]   r_mu                ; 
always@(posedge i_clk) begin
    r_frame_sync <= i_frame_sync ;
    if(i_frame_sync) begin
        r_mu <= i_mu ;
        r_retard <= i_retard-DLY_COMP ;
        case(i_mu)
            MU_SCS_015K : begin r_num_slot_frame <= 8'd10  ; r_len_lcp_sym <= 18'd17664; r_len_ncp_sym <= 18'd17536; r_len_lcp_slot <= 19'd17792+19'd17536*(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd17536*(NUM_SYM_SLOT  ); end
            MU_SCS_030K : begin r_num_slot_frame <= 8'd20  ; r_len_lcp_sym <= 18'd8896 ; r_len_ncp_sym <= 18'd8768 ; r_len_lcp_slot <= 19'd8896 +19'd8768 *(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd8768 *(NUM_SYM_SLOT  ); end
            MU_SCS_060K : begin r_num_slot_frame <= 8'd40  ; r_len_lcp_sym <= 18'd4512 ; r_len_ncp_sym <= 18'd4384 ; r_len_lcp_slot <= 19'd4512 +19'd4384 *(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd4384 *(NUM_SYM_SLOT  ); end
            MU_SCS_120K : begin r_num_slot_frame <= 8'd80  ; r_len_lcp_sym <= 18'd2320 ; r_len_ncp_sym <= 18'd2192 ; r_len_lcp_slot <= 19'd2320 +19'd2192 *(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd2192 *(NUM_SYM_SLOT  ); end
            MU_SCS_240K : begin r_num_slot_frame <= 8'd160 ; r_len_lcp_sym <= 18'd1224 ; r_len_ncp_sym <= 18'd1096 ; r_len_lcp_slot <= 19'd1224 +19'd1096 *(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd1096 *(NUM_SYM_SLOT  ); end
            MU_SCS_3_75K: begin r_num_slot_frame <= 8'd5   ; r_len_lcp_sym <= 18'd86016; r_len_ncp_sym <= 18'd67584; r_len_lcp_slot <= 19'd86016+19'd67584*(NUM_SYM_SLOT/2-1'd1); r_len_ncp_slot <= 19'd67584*(NUM_SYM_SLOT/2); end
            default     : begin r_num_slot_frame <= 8'd80  ; r_len_lcp_sym <= 18'd2320 ; r_len_ncp_sym <= 18'd2192 ; r_len_lcp_slot <= 19'd2320 +19'd2192 *(NUM_SYM_SLOT-1'd1)  ; r_len_ncp_slot <= 19'd2192 *(NUM_SYM_SLOT  ); end
        endcase
    end
end
reg [7:0]   NUM_SLOT_FRAME  ;
reg [17:0]  LEN_LCP_SYM     ;
reg [17:0]  LEN_NCP_SYM     ;
reg [18:0]  LEN_LCP_SLOT    ;
reg [18:0]  LEN_NCP_SLOT    ;
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        NUM_SLOT_FRAME  <=  r_num_slot_frame ;
        LEN_LCP_SYM     <=  r_len_lcp_sym    ;
        LEN_NCP_SYM     <=  r_len_ncp_sym    ;
        LEN_LCP_SLOT    <=  r_len_lcp_slot   ;
        LEN_NCP_SLOT    <=  r_len_ncp_slot   ;
    end
end

wire w_frame_sync_retard ;
ylib_pshift #(.BW_SHIFT(22)) u00_fsync_dly (.i_clk(i_clk),.i_shift(r_retard),.i_in(r_frame_sync ),.o_out(w_frame_sync_retard ));

//retard sync
reg r_frame_sync_retard  ;
reg rr_frame_sync_retard  ;
always@(posedge i_clk) begin
    r_frame_sync_retard  <= w_frame_sync_retard  ;
    rr_frame_sync_retard <= r_frame_sync_retard  ;
end

reg [17:0]  r_smp_subfrm_cnt  ;
reg [0:0]   r_smp_subfrm_init ;
always@(posedge i_clk) begin
    r_smp_subfrm_init <= (r_smp_subfrm_cnt==LEN_SUB_FRAME-2) ? 1'b1 : 1'b0 ;  
end
always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_smp_subfrm_cnt <= 18'd0 ;    
    end
    else if(r_smp_subfrm_init) begin
        r_smp_subfrm_cnt <= 18'd0 ;    
    end
    else begin
        r_smp_subfrm_cnt <= r_smp_subfrm_cnt + 1'd1 ;    
    end
end

reg [3:0]  r_subfrm ;
always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_subfrm <=  4'd0 ;    
    end
    else if(r_smp_subfrm_init) begin
        r_subfrm <= (r_subfrm==NUM_SUBFRM_FRAME-1'd1) ? 4'd0 : r_subfrm + 1'd1 ;
    end
end

reg [18:0]  r_smp_slot_cnt  ;
reg [7:0]   r_slot          ; 
reg [2:0]   r_slot_lcp      ;
always@(*) begin
    case(r_mu) 
        MU_SCS_015K : r_slot_lcp = 3'd0 ;
        MU_SCS_030K : r_slot_lcp = 3'd0 ;
        MU_SCS_060K : r_slot_lcp = {2'd0,r_slot[0:0]} ;
        MU_SCS_120K : r_slot_lcp = {1'd0,r_slot[1:0]} ;
        MU_SCS_240K : r_slot_lcp = r_slot[2:0] ;
        MU_SCS_3_75K: r_slot_lcp = 3'd6 ;
        default     : r_slot_lcp = {1'd0,r_slot[1:0]} ;
    endcase
end

reg [0:0] r_smp_slot_init ;
always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_smp_slot_init <= 1'b0 ;  
    end
    else if(r_slot_lcp==3'd0) begin
        r_smp_slot_init <= (r_smp_slot_cnt==LEN_LCP_SLOT-2) ;  
    end
    else begin
        r_smp_slot_init <= (r_smp_slot_cnt==LEN_NCP_SLOT-2) ;  
    end
end

always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_smp_slot_cnt <= 19'd0 ;    
    end
    else if(r_smp_slot_init) begin
        r_smp_slot_cnt <= 19'd0 ;    
    end
    else begin
        r_smp_slot_cnt <= r_smp_slot_cnt + 1'd1 ;    
    end
end

always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_slot <= 8'd0 ;    
    end
    else if(r_smp_slot_init) begin
        if(r_slot==NUM_SLOT_FRAME-1) begin
            r_slot <= 8'd0 ;    
        end
        else begin
            r_slot <= r_slot + 1'd1 ;
        end
    end
end

reg [17:0]  r_smp_symbol_cnt ;
reg [3:0]   r_symbol ;
reg [0:0]   r_smp_symbol_init ;
reg [0:0]   r_symbol_flag0 ; //3.75k lcp
reg [0:0]   r_symbol_flag1 ; //15,30,60,120,240k lcp
reg [0:0]   r_symbol_flag2 ; //ncp
always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_smp_symbol_init  <= 1'b0 ;  
        r_symbol_flag0 <= 1'b0 ;  
        r_symbol_flag1 <= 1'b0 ;  
        r_symbol_flag2 <= 1'b0 ;  
    end
    else if(r_mu==MU_SCS_3_75K) begin
        r_smp_symbol_init <= (r_symbol==4'd6) ? (r_smp_symbol_cnt==LEN_LCP_SYM-2) : (r_smp_symbol_cnt==LEN_NCP_SYM-2) ;  
        r_symbol_flag0 <= 1'b1 ;  
        r_symbol_flag1 <= 1'b0 ;  
        r_symbol_flag2 <= 1'b0 ;  
    end
    else if(r_slot_lcp==3'd0) begin
        r_smp_symbol_init <= (r_symbol==4'd0||(r_mu==MU_SCS_015K&&r_symbol==4'd7)) ? (r_smp_symbol_cnt==LEN_LCP_SYM-2) : (r_smp_symbol_cnt==LEN_NCP_SYM-2) ;
        r_symbol_flag0 <= 1'b0 ;  
        r_symbol_flag1 <= 1'b1 ;  
        r_symbol_flag2 <= 1'b0 ;  
    end
    else begin
        r_smp_symbol_init <= (r_smp_symbol_cnt==LEN_NCP_SYM-2) ;
        r_symbol_flag0 <= 1'b0 ;  
        r_symbol_flag1 <= 1'b0 ;  
        r_symbol_flag2 <= 1'b1 ;  
    end
end

always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_smp_symbol_cnt <= 18'd0 ;    
    end
    else if(r_smp_symbol_init) begin
        r_smp_symbol_cnt <= 18'd0 ;    
    end
    else begin
        r_smp_symbol_cnt <= r_smp_symbol_cnt + 1'd1 ;    
    end
end

always@(posedge i_clk) begin
    if(r_frame_sync_retard) begin
        r_symbol <= 4'd0  ;    
    end
    else if(r_smp_symbol_init) begin
        if(r_symbol_flag0) begin
            r_symbol <= (r_symbol==NUM_SYM_SLOT/2-1) ? 4'd0 : r_symbol + 1'd1 ;    
        end
        else if(r_symbol_flag1||r_symbol_flag2) begin
            r_symbol <= (r_symbol==NUM_SYM_SLOT-1) ? 4'd0 : r_symbol + 1'd1 ;    
        end
    end
end

reg [3:0]   r_slot_subfrm   ;
always@(*) begin
    case(r_mu) 
        MU_SCS_015K : r_slot_subfrm = 4'd0                  ;
        MU_SCS_030K : r_slot_subfrm = {3'd0,r_slot[0:0]}    ;
        MU_SCS_060K : r_slot_subfrm = {2'd0,r_slot[1:0]}    ;
        MU_SCS_120K : r_slot_subfrm = {1'd0,r_slot[2:0]}    ;
        MU_SCS_240K : r_slot_subfrm = r_slot[3:0]           ;
        MU_SCS_3_75K: r_slot_subfrm = 4'd0                  ;
        default     : r_slot_subfrm = 4'd0                  ;
    endcase
end

always@(posedge i_clk) begin
    if(i_en) begin
        o_frame_sync  <= rr_frame_sync_retard ;
        o_subfrm_sync <= r_smp_subfrm_cnt==18'd0 ;
        o_slot_sync   <= r_symbol==8'd0&&r_smp_slot_cnt==19'd0 ;
        o_symbol_sync <= r_smp_symbol_cnt==18'd0 ;
        if(r_smp_subfrm_cnt==18'd0              ) o_subfrm  <=  r_subfrm    ;
        if(r_symbol==8'd0&&r_smp_slot_cnt==19'd0) o_slot    <=  SLOT_INC_TYPE == "SUBFRAME" ?  {4'd0,r_slot_subfrm} : r_slot ;
        if(r_smp_symbol_cnt==18'd0              ) o_symbol  <=  r_symbol    ;
    end
    else begin
        o_frame_sync  <= 1'b0 ;
        o_subfrm_sync <= 1'b0 ;
        o_slot_sync   <= 1'b0 ;
        o_symbol_sync <= 1'b0 ;
    end
end
endmodule
