////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : lib_sshftvd_sat
//  Author       : Song, Moon-Gun
//  Description  : Signed Variable Shift Down and Saturation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

//dly4
module ylib_sshftvd_sat
#(
      parameter   IB            =  33                    // Input Bit Width
    , parameter   SB            =   4                    // Bit Shift Variable Bit Width
    , parameter   OB            =  16                    // Saturation Bit Width Output Bit Width
    , parameter   ROUND_TYPE    =  "SYMMETRIC_ROUND"     // SYMMETRIC_ROUND or ROUND or TRUNC
    , parameter   SAT_TYPE      =  "SYMMETRIC"           // SYMMETRIC or NONSYMMETRIC
)
(
      input  wire                  i_clk          // i_clk 
    
    , input  wire        [SB-1:0]  i_shft         // Bit Shift
    , input  wire                  i_din_vld      // Input Siganl Enable
    , input  wire signed [IB-1:0]  i_din          // Input Signal

    , output wire                  o_dout_vld     // Output Signal Enable
    , output wire signed [OB-1:0]  o_dout         // Output Signal
);

genvar i;
localparam  RNDBW = (ROUND_TYPE == "SYMMETRIC_ROUND") ? 2 : (ROUND_TYPE == "ROUND") ? 1 : 0;

wire signed [IB+RNDBW-1:0]  w_shft_din[2**SB-1:0];
wire                        w_shft_din_vld_1d    ;
wire signed [IB+RNDBW-1:0]  w_shft_din_1d        ;

generate
if(ROUND_TYPE == "SYMMETRIC_ROUND") begin
    assign w_shft_din[0] = {i_din, 2'b00};
    assign w_shft_din[1] = {i_din[IB-1], i_din, 1'b0};
    for(i = RNDBW; i < 2**SB; i = i + 1) begin : SYMMETRIC_ROUND_INPUT
        if(IB-1 >= i-RNDBW+1) assign w_shft_din[i] = {{(i){i_din[IB-1]}}, i_din[IB-1:i-RNDBW+1], (|i_din[i-RNDBW:0])};
        else                  assign w_shft_din[i] = 0;
    end
end
else if(ROUND_TYPE == "ROUND") begin
    assign w_shft_din[0] = {i_din, 1'b0};
    for(i = RNDBW; i < 2**SB; i = i + 1) begin : ROUND_INPUT
        if(IB-1 >= i-RNDBW) assign w_shft_din[i] = {{(i){i_din[IB-1]}}, i_din[IB-1:i-RNDBW]};
        else                assign w_shft_din[i] = 0;
    end
end
else begin
    for(i = RNDBW; i < 2**SB; i = i + 1) begin : TRUNC_INPUT
        if(i == 0)               assign w_shft_din[i] = i_din;
        else if(IB-1 >= i-RNDBW) assign w_shft_din[i] = {{(i){i_din[IB-1]}}, i_din[IB-1:i-RNDBW]};
        else                     assign w_shft_din[i] = 0;
    end
end
endgenerate

//dly1
ylib_reg #(.WIDTH(1),.DEPTH(1)) u00_lib_reg
(
     .i_clk       (    i_clk              )                        
    ,.i_in        (    i_din_vld          )
    ,.o_out       (    w_shft_din_vld_1d  )
);

ylib_reg #(.WIDTH(IB+RNDBW),.DEPTH(1)) u01_lib_reg
(
     .i_clk       (    i_clk              )                        
    ,.i_in        (    w_shft_din[i_shft] )
    ,.o_out       (    w_shft_din_1d      )
);

//dly3
ylib_sshftd_sat # (
     .IB          (    IB+RNDBW           )
    ,.SF          (    RNDBW              )
    ,.OB          (    OB                 )
    ,.ROUND_TYPE  (    ROUND_TYPE         )
    ,.SAT_TYPE    (    SAT_TYPE           )
)
u_lib_sshftd_sat
(
     .i_clk       (    i_clk              )                        
    
    ,.i_din_vld   (    w_shft_din_vld_1d  ) 
    ,.i_din       (    w_shft_din_1d      ) 

    ,.o_dout_vld  (    o_dout_vld         ) 
    ,.o_dout      (    o_dout             ) 
);


endmodule

