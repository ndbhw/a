////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2019 Samsung Electronics Inc. All rights reserved
//
//  Project      : Verizon FSU20
//  Module       : ylib_bus_split_cc
//  Author       : taeyeong
//  Description  : bus split 1 to 24
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.03 | taeyeong      | Inital Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_bus_split_cc #(
     parameter  IB          =   16
    ,parameter  OB          =   16
    ,parameter  DLY         =    0          
)(
     input   wire                              i_clk
    ,input   wire    [IB*2*24  -1:0]           i_in

    ,output  wire    [OB*2     -1:0]           o_out_00 
    ,output  wire    [OB*2     -1:0]           o_out_01 
    ,output  wire    [OB*2     -1:0]           o_out_02 
    ,output  wire    [OB*2     -1:0]           o_out_03 

    ,output  wire    [OB*2     -1:0]           o_out_10 
    ,output  wire    [OB*2     -1:0]           o_out_11 
    ,output  wire    [OB*2     -1:0]           o_out_12 
    ,output  wire    [OB*2     -1:0]           o_out_13 

    ,output  wire    [OB*2     -1:0]           o_out_20 
    ,output  wire    [OB*2     -1:0]           o_out_21 
    ,output  wire    [OB*2     -1:0]           o_out_22 
    ,output  wire    [OB*2     -1:0]           o_out_23 

    ,output  wire    [OB*2     -1:0]           o_out_30 
    ,output  wire    [OB*2     -1:0]           o_out_31 
    ,output  wire    [OB*2     -1:0]           o_out_32 
    ,output  wire    [OB*2     -1:0]           o_out_33 

    ,output  wire    [OB*2     -1:0]           o_out_40 
    ,output  wire    [OB*2     -1:0]           o_out_41 
    ,output  wire    [OB*2     -1:0]           o_out_42 
    ,output  wire    [OB*2     -1:0]           o_out_43 

    ,output  wire    [OB*2     -1:0]           o_out_50 
    ,output  wire    [OB*2     -1:0]           o_out_51 
    ,output  wire    [OB*2     -1:0]           o_out_52 
    ,output  wire    [OB*2     -1:0]           o_out_53 
);

// signal
wire    [OB*2     -1:0]           w_out_00; 
wire    [OB*2     -1:0]           w_out_01; 
wire    [OB*2     -1:0]           w_out_02; 
wire    [OB*2     -1:0]           w_out_03; 

wire    [OB*2     -1:0]           w_out_10; 
wire    [OB*2     -1:0]           w_out_11; 
wire    [OB*2     -1:0]           w_out_12; 
wire    [OB*2     -1:0]           w_out_13; 

wire    [OB*2     -1:0]           w_out_20; 
wire    [OB*2     -1:0]           w_out_21; 
wire    [OB*2     -1:0]           w_out_22; 
wire    [OB*2     -1:0]           w_out_23; 

wire    [OB*2     -1:0]           w_out_30; 
wire    [OB*2     -1:0]           w_out_31; 
wire    [OB*2     -1:0]           w_out_32; 
wire    [OB*2     -1:0]           w_out_33; 

wire    [OB*2     -1:0]           w_out_40; 
wire    [OB*2     -1:0]           w_out_41; 
wire    [OB*2     -1:0]           w_out_42; 
wire    [OB*2     -1:0]           w_out_43; 

wire    [OB*2     -1:0]           w_out_50; 
wire    [OB*2     -1:0]           w_out_51; 
wire    [OB*2     -1:0]           w_out_52; 
wire    [OB*2     -1:0]           w_out_53; 

// generate
generate
if(IB > OB) begin : left
    assign w_out_00 = {i_in[IB* 2 -1],i_in[IB* 1+OB -2: IB* 1],i_in[IB* 1 -1],i_in[IB* 0+OB -2: IB* 0]};
    assign w_out_01 = {i_in[IB* 4 -1],i_in[IB* 3+OB -2: IB* 3],i_in[IB* 3 -1],i_in[IB* 2+OB -2: IB* 2]};
    assign w_out_02 = {i_in[IB* 6 -1],i_in[IB* 5+OB -2: IB* 5],i_in[IB* 5 -1],i_in[IB* 4+OB -2: IB* 4]};
    assign w_out_03 = {i_in[IB* 8 -1],i_in[IB* 7+OB -2: IB* 7],i_in[IB* 7 -1],i_in[IB* 6+OB -2: IB* 6]};

    assign w_out_10 = {i_in[IB*10 -1],i_in[IB* 9+OB -2: IB* 9],i_in[IB* 9 -1],i_in[IB* 8+OB -2: IB* 8]};
    assign w_out_11 = {i_in[IB*12 -1],i_in[IB*11+OB -2: IB*11],i_in[IB*11 -1],i_in[IB*10+OB -2: IB*10]};
    assign w_out_12 = {i_in[IB*14 -1],i_in[IB*13+OB -2: IB*13],i_in[IB*13 -1],i_in[IB*12+OB -2: IB*12]};
    assign w_out_13 = {i_in[IB*16 -1],i_in[IB*15+OB -2: IB*15],i_in[IB*15 -1],i_in[IB*14+OB -2: IB*14]};

    assign w_out_20 = {i_in[IB*18 -1],i_in[IB*17+OB -2: IB*17],i_in[IB*17 -1],i_in[IB*16+OB -2: IB*16]};
    assign w_out_21 = {i_in[IB*20 -1],i_in[IB*19+OB -2: IB*19],i_in[IB*19 -1],i_in[IB*18+OB -2: IB*18]};
    assign w_out_22 = {i_in[IB*22 -1],i_in[IB*21+OB -2: IB*21],i_in[IB*21 -1],i_in[IB*20+OB -2: IB*20]};
    assign w_out_23 = {i_in[IB*24 -1],i_in[IB*23+OB -2: IB*23],i_in[IB*23 -1],i_in[IB*22+OB -2: IB*22]};

    assign w_out_30 = {i_in[IB*26 -1],i_in[IB*25+OB -2: IB*25],i_in[IB*25 -1],i_in[IB*24+OB -2: IB*24]};
    assign w_out_31 = {i_in[IB*28 -1],i_in[IB*27+OB -2: IB*27],i_in[IB*27 -1],i_in[IB*26+OB -2: IB*26]};
    assign w_out_32 = {i_in[IB*30 -1],i_in[IB*29+OB -2: IB*29],i_in[IB*29 -1],i_in[IB*28+OB -2: IB*28]};
    assign w_out_33 = {i_in[IB*32 -1],i_in[IB*31+OB -2: IB*31],i_in[IB*31 -1],i_in[IB*30+OB -2: IB*30]};

    assign w_out_40 = {i_in[IB*34 -1],i_in[IB*33+OB -2: IB*33],i_in[IB*33 -1],i_in[IB*32+OB -2: IB*32]};
    assign w_out_41 = {i_in[IB*36 -1],i_in[IB*35+OB -2: IB*35],i_in[IB*35 -1],i_in[IB*34+OB -2: IB*34]};
    assign w_out_42 = {i_in[IB*38 -1],i_in[IB*37+OB -2: IB*37],i_in[IB*37 -1],i_in[IB*36+OB -2: IB*36]};
    assign w_out_43 = {i_in[IB*40 -1],i_in[IB*39+OB -2: IB*39],i_in[IB*39 -1],i_in[IB*38+OB -2: IB*38]};

    assign w_out_50 = {i_in[IB*42 -1],i_in[IB*41+OB -2: IB*41],i_in[IB*41 -1],i_in[IB*40+OB -2: IB*40]};
    assign w_out_51 = {i_in[IB*44 -1],i_in[IB*43+OB -2: IB*43],i_in[IB*43 -1],i_in[IB*42+OB -2: IB*42]};
    assign w_out_52 = {i_in[IB*46 -1],i_in[IB*45+OB -2: IB*45],i_in[IB*45 -1],i_in[IB*44+OB -2: IB*44]};
    assign w_out_53 = {i_in[IB*48 -1],i_in[IB*47+OB -2: IB*47],i_in[IB*47 -1],i_in[IB*46+OB -2: IB*46]};
end
else if(IB < OB) begin : right
    localparam DIFF = OB-IB    ;

    assign w_out_00 = {  {DIFF{i_in[IB* 2 -1]}} ,i_in[IB* 2 -1:IB* 1], {DIFF{i_in[IB* 1 -1]}} ,i_in[IB* 1 -1:IB* 0]  };
    assign w_out_01 = {  {DIFF{i_in[IB* 4 -1]}} ,i_in[IB* 4 -1:IB* 3], {DIFF{i_in[IB* 3 -1]}} ,i_in[IB* 3 -1:IB* 2]  };
    assign w_out_02 = {  {DIFF{i_in[IB* 6 -1]}} ,i_in[IB* 6 -1:IB* 5], {DIFF{i_in[IB* 5 -1]}} ,i_in[IB* 5 -1:IB* 4]  };
    assign w_out_03 = {  {DIFF{i_in[IB* 8 -1]}} ,i_in[IB* 8 -1:IB* 7], {DIFF{i_in[IB* 7 -1]}} ,i_in[IB* 7 -1:IB* 6]  };
                                                                                                                  
    assign w_out_10 = {  {DIFF{i_in[IB*10 -1]}} ,i_in[IB*10 -1:IB* 9], {DIFF{i_in[IB* 9 -1]}} ,i_in[IB* 9 -1:IB* 8]  };
    assign w_out_11 = {  {DIFF{i_in[IB*12 -1]}} ,i_in[IB*12 -1:IB*11], {DIFF{i_in[IB*11 -1]}} ,i_in[IB*11 -1:IB*10]  };
    assign w_out_12 = {  {DIFF{i_in[IB*14 -1]}} ,i_in[IB*14 -1:IB*13], {DIFF{i_in[IB*13 -1]}} ,i_in[IB*13 -1:IB*12]  };
    assign w_out_13 = {  {DIFF{i_in[IB*16 -1]}} ,i_in[IB*16 -1:IB*15], {DIFF{i_in[IB*15 -1]}} ,i_in[IB*15 -1:IB*14]  };
                                                                                                                  
    assign w_out_20 = {  {DIFF{i_in[IB*18 -1]}} ,i_in[IB*18 -1:IB*17], {DIFF{i_in[IB*17 -1]}} ,i_in[IB*17 -1:IB*16]  };
    assign w_out_21 = {  {DIFF{i_in[IB*20 -1]}} ,i_in[IB*20 -1:IB*19], {DIFF{i_in[IB*19 -1]}} ,i_in[IB*19 -1:IB*18]  };
    assign w_out_22 = {  {DIFF{i_in[IB*22 -1]}} ,i_in[IB*22 -1:IB*21], {DIFF{i_in[IB*21 -1]}} ,i_in[IB*21 -1:IB*20]  };
    assign w_out_23 = {  {DIFF{i_in[IB*24 -1]}} ,i_in[IB*24 -1:IB*23], {DIFF{i_in[IB*23 -1]}} ,i_in[IB*23 -1:IB*22]  };
                                                                                                                  
    assign w_out_30 = {  {DIFF{i_in[IB*26 -1]}} ,i_in[IB*26 -1:IB*25], {DIFF{i_in[IB*25 -1]}} ,i_in[IB*25 -1:IB*24]  };
    assign w_out_31 = {  {DIFF{i_in[IB*28 -1]}} ,i_in[IB*28 -1:IB*27], {DIFF{i_in[IB*27 -1]}} ,i_in[IB*27 -1:IB*26]  };
    assign w_out_32 = {  {DIFF{i_in[IB*30 -1]}} ,i_in[IB*30 -1:IB*29], {DIFF{i_in[IB*29 -1]}} ,i_in[IB*29 -1:IB*28]  };
    assign w_out_33 = {  {DIFF{i_in[IB*32 -1]}} ,i_in[IB*32 -1:IB*31], {DIFF{i_in[IB*31 -1]}} ,i_in[IB*31 -1:IB*30]  };
                                                                                                                  
    assign w_out_40 = {  {DIFF{i_in[IB*34 -1]}} ,i_in[IB*34 -1:IB*33], {DIFF{i_in[IB*33 -1]}} ,i_in[IB*33 -1:IB*32]  };
    assign w_out_41 = {  {DIFF{i_in[IB*36 -1]}} ,i_in[IB*36 -1:IB*35], {DIFF{i_in[IB*35 -1]}} ,i_in[IB*35 -1:IB*34]  };
    assign w_out_42 = {  {DIFF{i_in[IB*38 -1]}} ,i_in[IB*38 -1:IB*37], {DIFF{i_in[IB*37 -1]}} ,i_in[IB*37 -1:IB*36]  };
    assign w_out_43 = {  {DIFF{i_in[IB*40 -1]}} ,i_in[IB*40 -1:IB*39], {DIFF{i_in[IB*39 -1]}} ,i_in[IB*39 -1:IB*38]  };
                                                                                                                  
    assign w_out_50 = {  {DIFF{i_in[IB*42 -1]}} ,i_in[IB*42 -1:IB*41], {DIFF{i_in[IB*41 -1]}} ,i_in[IB*41 -1:IB*40]  };
    assign w_out_51 = {  {DIFF{i_in[IB*44 -1]}} ,i_in[IB*44 -1:IB*43], {DIFF{i_in[IB*43 -1]}} ,i_in[IB*43 -1:IB*42]  };
    assign w_out_52 = {  {DIFF{i_in[IB*46 -1]}} ,i_in[IB*46 -1:IB*45], {DIFF{i_in[IB*45 -1]}} ,i_in[IB*45 -1:IB*44]  };
    assign w_out_53 = {  {DIFF{i_in[IB*48 -1]}} ,i_in[IB*48 -1:IB*47], {DIFF{i_in[IB*47 -1]}} ,i_in[IB*47 -1:IB*46]  };
end
else begin : same
    assign w_out_00 = {  i_in[IB* 2 -1:IB* 1], i_in[IB* 1 -1:IB* 0]  };
    assign w_out_01 = {  i_in[IB* 4 -1:IB* 3], i_in[IB* 3 -1:IB* 2]  };
    assign w_out_02 = {  i_in[IB* 6 -1:IB* 5], i_in[IB* 5 -1:IB* 4]  };
    assign w_out_03 = {  i_in[IB* 8 -1:IB* 7], i_in[IB* 7 -1:IB* 6]  };
                                                                  
    assign w_out_10 = {  i_in[IB*10 -1:IB* 9], i_in[IB* 9 -1:IB* 8]  };
    assign w_out_11 = {  i_in[IB*12 -1:IB*11], i_in[IB*11 -1:IB*10]  };
    assign w_out_12 = {  i_in[IB*14 -1:IB*13], i_in[IB*13 -1:IB*12]  };
    assign w_out_13 = {  i_in[IB*16 -1:IB*15], i_in[IB*15 -1:IB*14]  };
                                                                  
    assign w_out_20 = {  i_in[IB*18 -1:IB*17], i_in[IB*17 -1:IB*16]  };
    assign w_out_21 = {  i_in[IB*20 -1:IB*19], i_in[IB*19 -1:IB*18]  };
    assign w_out_22 = {  i_in[IB*22 -1:IB*21], i_in[IB*21 -1:IB*20]  };
    assign w_out_23 = {  i_in[IB*24 -1:IB*23], i_in[IB*23 -1:IB*22]  };
                                                                  
    assign w_out_30 = {  i_in[IB*26 -1:IB*25], i_in[IB*25 -1:IB*24]  };
    assign w_out_31 = {  i_in[IB*28 -1:IB*27], i_in[IB*27 -1:IB*26]  };
    assign w_out_32 = {  i_in[IB*30 -1:IB*29], i_in[IB*29 -1:IB*28]  };
    assign w_out_33 = {  i_in[IB*32 -1:IB*31], i_in[IB*31 -1:IB*30]  };
                                                                  
    assign w_out_40 = {  i_in[IB*34 -1:IB*33], i_in[IB*33 -1:IB*32]  };
    assign w_out_41 = {  i_in[IB*36 -1:IB*35], i_in[IB*35 -1:IB*34]  };
    assign w_out_42 = {  i_in[IB*38 -1:IB*37], i_in[IB*37 -1:IB*36]  };
    assign w_out_43 = {  i_in[IB*40 -1:IB*39], i_in[IB*39 -1:IB*38]  };
                                                                  
    assign w_out_50 = {  i_in[IB*42 -1:IB*41], i_in[IB*41 -1:IB*40]  };
    assign w_out_51 = {  i_in[IB*44 -1:IB*43], i_in[IB*43 -1:IB*42]  };
    assign w_out_52 = {  i_in[IB*46 -1:IB*45], i_in[IB*45 -1:IB*44]  };
    assign w_out_53 = {  i_in[IB*48 -1:IB*47], i_in[IB*47 -1:IB*46]  };
end
endgenerate

// output
generate
if (DLY == 0) begin : zero_dly
    assign o_out_00 = w_out_00 ; 
    assign o_out_01 = w_out_01 ; 
    assign o_out_02 = w_out_02 ; 
    assign o_out_03 = w_out_03 ; 

    assign o_out_10 = w_out_10 ; 
    assign o_out_11 = w_out_11 ; 
    assign o_out_12 = w_out_12 ; 
    assign o_out_13 = w_out_13 ; 

    assign o_out_20 = w_out_20 ; 
    assign o_out_21 = w_out_21 ; 
    assign o_out_22 = w_out_22 ; 
    assign o_out_23 = w_out_23 ; 

    assign o_out_30 = w_out_30 ; 
    assign o_out_31 = w_out_31 ; 
    assign o_out_32 = w_out_32 ; 
    assign o_out_33 = w_out_33 ; 

    assign o_out_40 = w_out_40 ; 
    assign o_out_41 = w_out_41 ; 
    assign o_out_42 = w_out_42 ; 
    assign o_out_43 = w_out_43 ; 

    assign o_out_50 = w_out_50 ; 
    assign o_out_51 = w_out_51 ; 
    assign o_out_52 = w_out_52 ; 
    assign o_out_53 = w_out_53 ; 
end
else begin : fix_dly
    ylib_reg #(.WIDTH(OB*2*24) ,.DEPTH(DLY)) u_out_reg(
         .i_clk      (i_clk     )
        ,.i_in       ( {w_out_00 ,w_out_01 ,w_out_02 ,w_out_03 ,w_out_10 ,w_out_11 ,w_out_12 ,w_out_13           
                       ,w_out_20 ,w_out_21 ,w_out_22 ,w_out_23 ,w_out_30 ,w_out_31 ,w_out_32 ,w_out_33 
                       ,w_out_40 ,w_out_41 ,w_out_42 ,w_out_43 ,w_out_50 ,w_out_51 ,w_out_52 ,w_out_53} )
        ,.o_out      ( {o_out_00 ,o_out_01 ,o_out_02 ,o_out_03 ,o_out_10 ,o_out_11 ,o_out_12 ,o_out_13      
                       ,o_out_20 ,o_out_21 ,o_out_22 ,o_out_23 ,o_out_30 ,o_out_31 ,o_out_32 ,o_out_33 
                       ,o_out_40 ,o_out_41 ,o_out_42 ,o_out_43 ,o_out_50 ,o_out_51 ,o_out_52 ,o_out_53} )
     );
end
endgenerate

endmodule
