//////////////////////////////////////////////////////////////////////////////// // 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Telus RT88xx
//  Module       : ylib_cpri_param_if
//  Author       : jyzoo.lee@samsung.com 
//  Description  : cpri param parser
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.27 | jyzoo.lee     | Created Initial Design for DL
//  ------------+---------------+-----------------------------------------------
//   2021.08.11 | jyzoo.lee     | Updated for MU-MIMO
//  ------------+---------------+-----------------------------------------------
//   2022.02.21 | jyzoo.lee     | Support Parameter Map Type1
//  ------------+---------------+-----------------------------------------------
//   2022.02.23 | jyzoo.lee     | Add Parameter Address Offset 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_cpri_param_if
#(
     parameter  DI_BW           =   32
    ,parameter  MAP_TYPE        =   "TYPE0"           
    ,parameter  RETARD          =   1           
)(
     input  wire                                i_clk
    ,input  wire                                i_frame_sync
    ,input  wire                                i_slot_sync
    ,input  wire                                i_symbol_sync
    ,input  wire                                i_en
    ,input  wire                                i_tdd_cfg
    ,input  wire   [16-1:0]                     i_addr_offset 
    ,input  wire                                i_p0_csync
    ,input  wire   [DI_BW-1:0]                  i_p0_cdata
    ,input  wire   [DI_BW-1:0]                  i_p1_cdata
    ,output reg    [01-1:0]                     o_rb_cbidx_en 
    ,output reg    [01-1:0]                     o_rb_nmusul_en
    ,output reg    [01-1:0]                     o_re_map_en 
    ,output reg    [01-1:0]                     o_rb_nmul_en        
    ,output reg    [01-1:0]                     o_rb_sch_srs_idx_en 
    ,output reg    [01-1:0]                     o_rb_null_lyr_ind_en
    ,output reg    [DI_BW-1:0]                  o_cparam0
    ,output reg    [01-1:0]                     o_h_en 
    ,output reg    [DI_BW-1:0]                  o_cparam1
);

//Parameter Local Logic
localparam  [06-1:0]    NUM_AXC                     =       64                  ;
localparam  [06-1:0]    NUM_AXC_DATA                =       60                  ;
localparam  [09-1:0]    IDX_CHIP_PARAM0_START       =       103                 ;
localparam  [09-1:0]    IDX_CHIP_PARAM0_END         =       136                 ;
localparam  [06-1:0]    IDX_AXC_PARAM0_START        =       0                   ;
localparam  [06-1:0]    IDX_AXC_PARAM0_END          =       17                  ;
localparam  [09-1:0]    IDX_CHIP_PARAM1_START       =       0                   ;
localparam  [09-1:0]    IDX_CHIP_PARAM1_END         =       135                 ;
localparam  [06-1:0]    IDX_AXC_PARAM1_START        =       0                   ;
localparam  [06-1:0]    IDX_AXC_PARAM1_END          =       39                  ;
localparam  [16-1:0]    CBIDX_ADDR_START            =       MAP_TYPE == "TYPE0" ? 'h00580 : 'h00040 ;
localparam  [16-1:0]    CBIDX_ADDR_END              =       MAP_TYPE == "TYPE0" ? 'h00CEF : 'h007AF ;
localparam  [16-1:0]    NMUSUL_ADDR_START           =       MAP_TYPE == "TYPE0" ? 'h00CF0 : 'h00040 ;
localparam  [16-1:0]    NMUSUL_ADDR_END             =       MAP_TYPE == "TYPE0" ? 'h010A7 : 'h007AF ;
localparam  [16-1:0]    REMAP_ADDR_START            =       MAP_TYPE == "TYPE0" ? 'h010C0 : 'h007B0 ;
localparam  [16-1:0]    REMAP_ADDR_END              =       MAP_TYPE == "TYPE0" ? 'h03D5F : 'h0344F ;
localparam  [16-1:0]    NMUL_ADDR_START             =       MAP_TYPE == "TYPE0" ? 'h00040 : 'h00000 ;
localparam  [16-1:0]    NMUL_ADDR_END               =       MAP_TYPE == "TYPE0" ? 'h00083 : 'h00000 ;
localparam  [16-1:0]    SCH_SRS_IDX_ADDR_START      =       MAP_TYPE == "TYPE0" ? 'h00084 : 'h00000 ;
localparam  [16-1:0]    SCH_SRS_IDX_ADDR_END        =       MAP_TYPE == "TYPE0" ? 'h004C3 : 'h00000 ;
localparam  [16-1:0]    NULL_LAYER_IND_ADDR_START   =       MAP_TYPE == "TYPE0" ? 'h004C4 : 'h00000 ;
localparam  [16-1:0]    NULL_LAYER_IND_ADDR_END     =       MAP_TYPE == "TYPE0" ? 'h0054B : 'h00000 ;
localparam  [20-1:0]    H_ADDR_START                =       MAP_TYPE == "TYPE0" ? 'h00000 : 'h00000 ;
localparam  [20-1:0]    H_ADDR_END                  =       MAP_TYPE == "TYPE0" ? 'h1107F : 'h00000 ;
localparam              DLY_CPARAM                  =       RETARD+2            ;      
localparam              TDD_ON                      =       0                   ;
localparam              ID_TDD_4_1                  =       0                   ;
localparam              ID_TDD_8_2                  =       1                   ;
localparam              TDD_4_1_SLOT0               =      'h4                  ;
localparam              TDD_8_2_SLOT0               =      'h8                  ;
localparam              TDD_8_2_SLOT1               =      'h9                  ;

//Logic Variable
integer i ;

reg [3:0] r_tdd_slot_idx ;
always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_tdd_slot_idx <= 4'd0 ;
    end
    else if(i_slot_sync) begin
        if(r_tdd_slot_idx==4'd9) begin
            r_tdd_slot_idx <= 4'd0 ;
        end 
        else begin
            r_tdd_slot_idx <= r_tdd_slot_idx + 1'd1 ;
        end
    end
end
reg [RETARD:0]      r_slot_sync     ;
reg [RETARD:0]      r_symbol_sync   ;
reg [RETARD:0]      r_csync         ;
reg [RETARD:0]      r_en            ;
reg [DI_BW-1:0]     r_p0_cdata [DLY_CPARAM:0]   ;
reg [DI_BW-1:0]     r_p1_cdata [DLY_CPARAM:0]   ;
always@(*) begin
    r_slot_sync     [0]   =  i_slot_sync    ;
    r_symbol_sync   [0]   =  i_symbol_sync  ;
    r_csync         [0]   =  i_p0_csync     ;
    r_en            [0]   =  i_en           ;
    r_p0_cdata      [0]   =  i_p0_cdata     ;
    r_p1_cdata      [0]   =  i_p1_cdata     ;
end
always@(posedge i_clk) begin
    for(i=1;i<=RETARD;i=i+1) begin
        r_slot_sync  [i]   <=  r_slot_sync  [i-1] ;
        r_symbol_sync[i]   <=  r_symbol_sync[i-1] ;
        r_en         [i]   <=  r_en         [i-1] ;
    end
    for(i=1;i<=DLY_CPARAM;i=i+1) begin
        r_csync      [i]   <=  r_csync      [i-1] ;
        r_p0_cdata   [i]   <=  r_p0_cdata   [i-1] ;
        r_p1_cdata   [i]   <=  r_p1_cdata   [i-1] ;
    end
end
reg [09-1:0]    r_chip_idx      ;
reg [06-1:0]    r_axc_idx       ;
reg [01-1:0]    r_din_en        ;
always@(posedge i_clk) begin
    r_din_en    <=  r_en[RETARD] ;
    if(r_en[RETARD]) begin
        if(r_symbol_sync[RETARD]) begin
            r_chip_idx   <= 9'd0    ;
            r_axc_idx    <= 6'd0    ;
        end
        else begin
            r_axc_idx    <= r_axc_idx + 1 ;
            if(r_csync[RETARD]) begin
                r_chip_idx  <=  r_chip_idx + 1'd1   ;
            end
        end
    end
end
reg [01-1:0]    r_param0_en   ;
always@(posedge i_clk) begin
    if(r_din_en) begin
        if((r_chip_idx>=IDX_CHIP_PARAM0_START&&r_chip_idx<IDX_CHIP_PARAM0_END)||(r_chip_idx==IDX_CHIP_PARAM0_END&&r_axc_idx<=IDX_AXC_PARAM0_END)) begin
            if(r_axc_idx<NUM_AXC_DATA) begin
                r_param0_en   <=  1'd1    ;
            end
            else begin
                r_param0_en   <=  1'd0    ;
            end
        end
        else begin
            r_param0_en   <=  1'd0    ;
        end
    end
end
reg [16-1:0]    r_param0_addr ;
always@(posedge i_clk) begin
    if(r_slot_sync[RETARD]) begin
        r_param0_addr <= 16'd0 ;
    end
    else if(r_param0_en) begin
        r_param0_addr <=  r_param0_addr+1'd1 ;
    end
end
reg r_param1_tdd_en ;
always@(posedge i_clk) begin
    if(TDD_ON==1) begin
        if(i_tdd_cfg==ID_TDD_8_2) begin
            r_param1_tdd_en <=  r_tdd_slot_idx==TDD_8_2_SLOT0||r_tdd_slot_idx==TDD_8_2_SLOT1 ;
        end
        else if(i_tdd_cfg==ID_TDD_4_1) begin
            r_param1_tdd_en <=  r_tdd_slot_idx==TDD_4_1_SLOT0 ;
        end
    end
    else begin
        r_param1_tdd_en <=  1'b1 ;
    end
end
reg [01-1:0]    r_param1_en   ;
always@(posedge i_clk) begin
    if(r_din_en&&r_param1_tdd_en) begin
        if((r_chip_idx>=IDX_CHIP_PARAM1_START&&r_chip_idx<IDX_CHIP_PARAM1_END)||(r_chip_idx==IDX_CHIP_PARAM1_END&&r_axc_idx<=IDX_AXC_PARAM1_END)) begin
            if(r_axc_idx<NUM_AXC_DATA) begin
                r_param1_en   <=  1'd1    ;
            end
            else begin
                r_param1_en   <=  1'd0    ;
            end
        end
        else begin
            r_param1_en   <=  1'd0    ;
        end
    end
    else begin
        r_param1_en   <=  1'd0    ;
    end
end
reg [20-1:0]    r_param1_addr ;
always@(posedge i_clk) begin
    if(r_slot_sync[RETARD]) begin
        r_param1_addr <= 20'd0 ;
    end
    else if(r_param1_en) begin
        r_param1_addr <=  r_param1_addr+1'd1 ;
    end
end
reg r_rb_cbidx_en           ;
reg r_rb_nmusul_en          ;
reg r_re_map_en             ;
reg r_rb_nmul_en            ;
reg r_rb_sch_srs_idx_en     ;
reg r_rb_null_lyr_ind_en    ;
reg r_h_en                  ;
generate if(MAP_TYPE=="TYPE0") begin : gen_map_type0
always@(posedge i_clk) begin
    if(r_slot_sync[RETARD]) begin
        r_rb_cbidx_en           <=   1'd0   ;
        r_rb_nmusul_en          <=   1'd0   ;
        r_re_map_en             <=   1'd0   ;
        r_rb_nmul_en            <=   1'd0   ;
        r_rb_sch_srs_idx_en     <=   1'd0   ;
        r_rb_null_lyr_ind_en    <=   1'd0   ;
    end
    else if(r_param0_en) begin
        o_cparam0   <=  r_p0_cdata[DLY_CPARAM] ;
        if(r_param0_addr>=CBIDX_ADDR_START&&r_param0_addr<=CBIDX_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd1    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
        else if(r_param0_addr>=NMUSUL_ADDR_START&&r_param0_addr<=NMUSUL_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd1    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
        else if(r_param0_addr>=REMAP_ADDR_START&&r_param0_addr<=REMAP_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd1    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
        else if(r_param0_addr>=NMUL_ADDR_START&&r_param0_addr<=NMUL_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd1    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
        else if(r_param0_addr>=SCH_SRS_IDX_ADDR_START&&r_param0_addr<=SCH_SRS_IDX_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd1    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
        else if(r_param0_addr>=NULL_LAYER_IND_ADDR_START&&r_param0_addr<=NULL_LAYER_IND_ADDR_END) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd1    ;
        end
        else begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
            r_rb_nmul_en            <=  1'd0    ;
            r_rb_sch_srs_idx_en     <=  1'd0    ;
            r_rb_null_lyr_ind_en    <=  1'd0    ;
        end
    end
    else begin
        r_rb_cbidx_en           <=   1'd0   ;
        r_rb_nmusul_en          <=   1'd0   ;
        r_re_map_en             <=   1'd0   ;
        r_rb_nmul_en            <=   1'd0   ;
        r_rb_sch_srs_idx_en     <=   1'd0   ;
        r_rb_null_lyr_ind_en    <=   1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(r_slot_sync[RETARD]) begin
        r_h_en     <=   1'd0   ;
    end
    else if(r_param1_en) begin
        o_cparam1   <=  r_p1_cdata[DLY_CPARAM] ;
        if(r_param1_addr>=H_ADDR_START&&r_param1_addr<=H_ADDR_END) begin
            r_h_en   <=  1'd1    ;
        end
        else begin
            r_h_en     <=  1'd0    ;
        end
    end
    else begin
        r_h_en  <=  1'd0    ;
    end
end
end
else begin : gen_map_type1
always@(posedge i_clk) begin
    if(r_slot_sync[RETARD]) begin
        r_rb_cbidx_en           <=   1'd0   ;
        r_rb_nmusul_en          <=   1'd0   ;
        r_re_map_en             <=   1'd0   ;
    end
    else if(r_param0_en) begin
        o_cparam0   <=  r_p0_cdata[DLY_CPARAM] ;
        if(r_param0_addr>=(CBIDX_ADDR_START+i_addr_offset)&&r_param0_addr<=(CBIDX_ADDR_END+i_addr_offset)) begin
            r_rb_cbidx_en           <=  1'd1    ;
            r_rb_nmusul_en          <=  1'd1    ;
            r_re_map_en             <=  1'd0    ;
        end
        else if(r_param0_addr>=(REMAP_ADDR_START+i_addr_offset)&&r_param0_addr<=(REMAP_ADDR_END+i_addr_offset)) begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd1    ;
        end
        else begin
            r_rb_cbidx_en           <=  1'd0    ;
            r_rb_nmusul_en          <=  1'd0    ;
            r_re_map_en             <=  1'd0    ;
        end
    end
    else begin
        r_rb_cbidx_en           <=   1'd0   ;
        r_rb_nmusul_en          <=   1'd0   ;
        r_re_map_en             <=   1'd0   ;
    end
end
end
endgenerate
always@(*) begin
    o_rb_cbidx_en           =  r_rb_cbidx_en        ;
    o_rb_nmusul_en          =  r_rb_nmusul_en       ;
    o_re_map_en             =  r_re_map_en          ;
    o_rb_nmul_en            =  r_rb_nmul_en         ;
    o_rb_sch_srs_idx_en     =  r_rb_sch_srs_idx_en  ;
    o_rb_null_lyr_ind_en    =  r_rb_null_lyr_ind_en ;
    o_h_en                  =  r_h_en               ;
end
endmodule
