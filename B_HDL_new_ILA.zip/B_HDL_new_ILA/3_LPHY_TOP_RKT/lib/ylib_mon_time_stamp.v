////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_mon_time_stamp
//  Author       : jyzoo.lee@samsung.com 
//  Description  : time stamp monitoring
//                 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.10.27 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_mon_time_stamp
# (
    parameter WIDTH         =   22   
)(
        input   wire                    i_clk
    ,   input   wire                    i_sync
    ,   output	reg     [WIDTH-1:0]     o_time_stamp
);

reg     [WIDTH-1:0] r_cnt   ;
always@(posedge i_clk) begin
    if(i_sync) begin
    	r_cnt           <=  {WIDTH{1'b0}}   ;
    	o_time_stamp    <=  r_cnt           ;
    end
    else begin
    	r_cnt           <=  r_cnt+1'b1      ;
    end
end
endmodule
