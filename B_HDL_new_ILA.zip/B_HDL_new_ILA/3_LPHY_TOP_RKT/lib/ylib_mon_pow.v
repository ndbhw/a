////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_mon_pow
//  Author       : jyzoo.lee@samsung.com 
//  Description  : This Module is Designed to Monitor Power
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.08.18 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_mon_pow
#(
     parameter  BW_POW       =   32 
)(
     input   wire                               i_clk
    ,input   wire    [01-1:0]                   i_init
    ,input   wire    [01-1:0]                   i_rsync
    ,input   wire    [BW_POW-1:0]               i_pow
    ,input   wire    [BW_POW-1:0]               i_min
    ,input   wire    [BW_POW-1:0]               i_max
    ,output  reg     [01-1:0]                   o_det
);
reg r_rsync ;
reg [BW_POW-1:0] r_pow ;
always@(posedge i_clk) begin
    r_rsync <= i_rsync ;
    if(i_rsync) begin
        r_pow <= i_pow ;
    end
end
reg r_init ;
always@(posedge i_clk) begin
    r_init <= i_init ;
end
reg r_det  ;
always@(posedge i_clk) begin
    if(r_init) begin
        r_det <= 1'b0 ;
    end
    else if(r_rsync) begin
        if(r_pow<i_min||r_pow>i_max) begin
            r_det <= 1'b1 ;
        end
    end
end
always@(posedge i_clk) begin
    if(i_init) begin
        o_det <= r_det ;
    end
end
endmodule
