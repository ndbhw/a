////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU
//  Module       : ylib_xdsp48
//  Author       : taeyeong
//  Description  : xilinx dsp48
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2022.03.31 | taeyeong      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

(* use_dsp48 = "yes" *) 
module ylib_xdsp48 #(
    parameter   MODE    = "ADD" // or "SUB"
)
(
    input  signed [26:0] a,
    input  signed [17:0] b,
    input  signed [47:0] c,
    input  signed [47:0] d,
    input  signed [47:0] e,
    output signed [47:0] out 
);

// wire signed [47:0] pcout;
// 
// assign pcout = a * b + c;

generate if(MODE == "SUB") begin // SUB

//    assign out = pcout + d - e;    
    assign out = d - e;    

end
else begin  // ADD

//    assign out = pcout + d + e;
    assign out = d + e;

end
endgenerate

endmodule
