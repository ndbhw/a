////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : lib_fxp_smult
//  Author       : Song, Moon-Gun
//  Description  : Linear Combination for Two vector
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

(* use_dsp = "yes" *) module lib_fxp_smult
#( 
       parameter   XB         = 15            // Input X Bit Width
     , parameter   YB         = 15            // Input Y Bit Width
     , parameter   NP         =  2            // Number of Pipe NP >= 2
)
(
      input  wire                    i_clk        // CLK 
    , input  wire                    i_rst        // Async. Reset Active High
    
    , input  wire signed             i_vld        // Input Valid
    , input  wire signed [  XB-1:0]  i_x          // Input X
    , input  wire signed [  YB-1:0]  i_y          // Input Y

    , output wire signed             o_vld        // Output Valid
    , output wire signed [XB+YB-1:0] o_z          // Ouput
);

genvar i;
reg  signed [   XB-1:0] r_x_1d   = 0;
reg  signed [   YB-1:0] r_y_1d   = 0;
reg  signed [XB+YB-1:0] r_z [NP-2:0];

always @ (posedge i_clk) begin
    r_x_1d    <= i_x;
    r_y_1d    <= i_y;
    r_z[0]    <= r_x_1d * r_y_1d;
end

generate
   if(NP > 2) begin
      for(i = 1; i < NP-1; i = i + 1) begin
          always @ (posedge i_clk) begin
              r_z[i] <= r_z[i-1];
          end
      end
   end
endgenerate

lib_shr #(.WIDTH(1), .DEPTH(NP)) u_lib_shr
(    
     .i_clk    (    i_clk   )                        
    ,.i_en     (    1'b1    )
    ,.i_in     (    i_vld   )
    ,.o_out    (    o_vld   )
);
assign o_z = r_z[NP-2];


endmodule





