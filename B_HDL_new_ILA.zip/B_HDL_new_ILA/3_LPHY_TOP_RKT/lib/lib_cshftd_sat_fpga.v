////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : lib_cshftd_sat
//  Author       : Song, Moon-Gun
//  Description  : Signed Complex Variable Shift Down and Saturation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////


//dly3
module lib_cshftd_sat_fpga
#(
      parameter   IB            =  33                    // Input Bit Width
    , parameter   SF            =   4                    // Shift Down
    , parameter   OB            =  16                    // Saturation Bit Width Output Bit Width
    , parameter   ROUND_TYPE    =  "SYMMETRIC_ROUND"     // SYMMETRIC_ROUND or ROUND or TRUNC
    , parameter   SAT_TYPE      =  "SYMMETRIC"           // SYMMETRIC or NONSYMMETRIC
)
(
      input  wire                  i_clk          // i_clk 
    
    , input  wire                  i_din_vld      // Input Siganl Enable
    , input  wire signed [IB-1:0]  i_din_i        // Input Signal I
    , input  wire signed [IB-1:0]  i_din_q        // Input Signal I

    , output wire                  o_dout_vld     // Output Signal Enable
    , output wire signed [OB-1:0]  o_dout_i       // Output Signal
    , output wire signed [OB-1:0]  o_dout_q       // Output Signal
);

lib_sshftd_sat_fpga
#(
     .IB          (    IB                 )
    ,.SF          (    SF                 )
    ,.OB          (    OB                 )
    ,.ROUND_TYPE  (    ROUND_TYPE         )
    ,.SAT_TYPE    (    SAT_TYPE           )
)
u00_lib_sshftd_sat
(
     .i_clk       (    i_clk              )                        
    
    ,.i_din_vld   (    i_din_vld          )
    ,.i_din       (    i_din_i            )

    ,.o_dout_vld  (    o_dout_vld         )
    ,.o_dout      (    o_dout_i           )
);

lib_sshftd_sat_fpga
#(
     .IB          (    IB                 )
    ,.SF          (    SF                 )
    ,.OB          (    OB                 )
    ,.ROUND_TYPE  (    ROUND_TYPE         )
    ,.SAT_TYPE    (    SAT_TYPE           )
)
u01_lib_sshftd_sat
(
     .i_clk       (    i_clk              )                        
    
    ,.i_din_vld   (    i_din_vld          )
    ,.i_din       (    i_din_q            )

    ,.o_dout_vld  (                       )
    ,.o_dout      (    o_dout_q           )
);


endmodule

