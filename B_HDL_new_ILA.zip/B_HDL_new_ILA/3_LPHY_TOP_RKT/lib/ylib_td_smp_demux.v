////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_td_smp_demux.v
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Demap SBIF AxC Signal to TD Signal
//                 Feature : CBW 20/15/10/5M 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.11.12 |jyzoo.lee      | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2022.02.16 |jyzoo.lee      | Support 3.84/1.92 Msps
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`define mlib_clog2(A) A > 1 ? $clog2(A) : 1 

module ylib_td_smp_demux
#(
        parameter   NUM_CC      =    1
   ,    parameter   NUM_ANT     =    4
   ,    parameter   CC_IDX      =    0 
   ,    parameter   DIO_BW      =    16
)(
        input   wire                                i_clk
    ,   input   wire    [04-1:0]                    i_bw_idx
    ,   input   wire    [01-1:0]                    i_bfn_strb
    ,   input   wire    [12-1:0]                    i_bfn
    ,   input   wire    [01-1:0]                    i_fsync
    ,   input   wire    [01-1:0]                    i_en
    ,   input   wire    [2*DIO_BW-1:0]              i_iq
    ,   output  wire    [01-1:0]                    o_bfn_strb
    ,   output  reg     [12-1:0]                    o_bfn
    ,   output  reg     [01-1:0]                    o_fsync
    ,   output  reg     [01*NUM_ANT-1:0]            o_en
    ,   output  reg     [2*DIO_BW*NUM_ANT-1:0]      o_iq
);

genvar  gidx    ;
integer i       ;

localparam      NUM_AXC             =           128                 ;
localparam      BW_AXC              =           $clog2(NUM_AXC)     ;
localparam      IDX_BW_NB           =           4'hd                ;
localparam      IDX_BW_020          =           4'h3                ;
localparam      IDX_BW_015          =           4'h2                ;
localparam      IDX_BW_010          =           4'h1                ;
localparam      IDX_BW_005          =           4'h0                ;
localparam      BW_SR_BW_030_72     =           $clog2(08)          ;
localparam      BW_SR_BW_015_36     =           $clog2(16)          ;
localparam      BW_SR_BW_007_68     =           $clog2(32)          ; 
localparam      BW_SR_BW_003_84     =           $clog2(64)          ; 
localparam      BW_SR_BW_001_92     =           $clog2(128)         ; 
localparam      CLK_STROBE          =           64                  ;
localparam      DLY_SYNC            =           2                   ;

reg [BW_AXC-1:0] r_axc_cnt ;
always@(posedge i_clk) begin
    if(i_fsync) begin
        r_axc_cnt <= {{BW_AXC}{1'd0}} ;
    end
    else begin
        r_axc_cnt <= r_axc_cnt+1'd1 ;
    end
end
reg r_en ;
reg rr_en ;
reg rrr_en ;
wire w_en ;
always@(posedge i_clk) begin
    r_en <= i_en ;
    rr_en <= r_en ;
    rrr_en <= rr_en ;
end
reg [2*DIO_BW-1:0] r_iq ;
always@(posedge i_clk) begin
    if(i_en) begin
        r_iq <= i_iq ;
    end
    else if(~i_en&r_en) begin
        r_iq <= {{2*DIO_BW}{1'b0}} ;
    end
end
reg r_ssync ;
always@(posedge i_clk) begin
    if(r_en) begin
        case(i_bw_idx)
            IDX_BW_020  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_030_72-1:0] ; 
            IDX_BW_015  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_030_72-1:0] ; 
            IDX_BW_010  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_015_36-1:0] ; 
            IDX_BW_005  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_007_68-1:0] ; 
            IDX_BW_NB   : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_001_92-1:0] ; 
            default     : r_ssync  <= {{2*DIO_BW}{1'd0}} ;            
        endcase
    end
end

reg [BW_AXC-1:0] r_sr_cnt ;
always@(*) begin
    case(i_bw_idx)
        IDX_BW_020  : r_sr_cnt = r_axc_cnt[BW_SR_BW_030_72-1:0] ; 
        IDX_BW_015  : r_sr_cnt = r_axc_cnt[BW_SR_BW_030_72-1:0] ; 
        IDX_BW_010  : r_sr_cnt = r_axc_cnt[BW_SR_BW_015_36-1:0] ; 
        IDX_BW_005  : r_sr_cnt = r_axc_cnt[BW_SR_BW_007_68-1:0] ; 
        IDX_BW_NB   : r_sr_cnt = r_axc_cnt[BW_SR_BW_001_92-1:0] ; 
        default     : r_sr_cnt = {{BW_AXC}{1'd0}} ; 
    endcase
end
reg [NUM_ANT-1:0]  r_iq_axc_demap_en ;
reg [2*DIO_BW-1:0] r_iq_axc_demap    [NUM_ANT-1:0] ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_demap_ant_split
always@(posedge i_clk) begin
    if(r_en) begin
        if((r_axc_cnt[$clog2(NUM_ANT)-1:0]==({{$clog2(NUM_ANT)}{1'b1}}&gidx))&&(r_axc_cnt[`mlib_clog2(NUM_CC)+$clog2(NUM_ANT)-1:$clog2(NUM_ANT)]==({{`mlib_clog2(NUM_CC)}{1'b1}}&CC_IDX))) begin
            if((r_sr_cnt>=({{BW_AXC}{1'd0}}+({{BW_AXC}{1'd1}}&(CC_IDX*NUM_ANT))))&&(r_sr_cnt<(({{BW_AXC}{1'd1}}&(NUM_ANT))+({{BW_AXC}{1'd1}}&(CC_IDX*NUM_ANT))))) begin
                r_iq_axc_demap_en [gidx] <= 1'b1 ;
                r_iq_axc_demap    [gidx] <= r_iq ;
            end
        end
        else begin
            r_iq_axc_demap_en [gidx] <= 1'b0 ;
        end
    end
    else begin
        r_iq_axc_demap_en [gidx] <= 1'b0 ;
    end
end
always@(posedge i_clk) begin
    o_en[gidx] <= rrr_en ;
    if(rr_en) begin
        if(r_iq_axc_demap_en[NUM_ANT-1]) begin
            o_iq [((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] <= r_iq_axc_demap [gidx] ;
        end
    end
    else if(w_en&~o_en) begin
        o_iq [((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] <= {{2*DIO_BW}{1'b0}} ;
    end
end
end
endgenerate
reg r_fsync_det ; 
always@(posedge i_clk) begin
    if(i_bfn_strb) begin
        if(i_fsync) begin
            r_fsync_det <= 1'b0 ; 
        end
        else if(r_iq_axc_demap_en[NUM_ANT-1]) begin
            r_fsync_det <= 1'b1 ; 
        end
    end
end
always@(posedge i_clk) begin
    if(i_bfn_strb) begin
        o_fsync <= r_fsync_det==1'b0 && r_iq_axc_demap_en[NUM_ANT-1] ;
    end
end
always@(posedge i_clk) begin
    if(i_bfn_strb && r_fsync_det==1'b0 && r_iq_axc_demap_en[NUM_ANT-1]) begin
        o_bfn <= i_bfn ;
    end
end
ylib_pwiden #(
    .CYCLE  (   CLK_STROBE      )) 
u00_bfn_strb
(
     .i_clk     (   i_clk           )
    ,.i_in      (   i_bfn_strb && r_fsync_det==1'b0 && r_iq_axc_demap_en[NUM_ANT-1]    )
    ,.o_out     (   o_bfn_strb      )
);
ylib_reg #(
     .WIDTH (   1               ) 
    ,.DEPTH (   DLY_SYNC        )) 
u01_sync
(
     .i_clk     (   i_clk           )
    ,.i_in      (   rrr_en          )
    ,.o_out     (   w_en            )
);
endmodule
