////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2019 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : ylib_pshift
//  Author       : jyzoo.lee@samsung.com
//  Description  : pulse shifter
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2019.10.23 |jyzoo.lee      | Inital Release
//  ------------+---------------+-----------------------------------------------
//   2020.02.19 |jyzoo.lee      | Reset Remove
//  ------------+---------------+-----------------------------------------------
//   2020.08.11 |jyzoo.lee      | Shift Value Generic -> Port
//  ------------+---------------+-----------------------------------------------
//   2020.10.08 |jyzoo.lee      | Zero Shift Support 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_pshift #(
    parameter   BW_SHIFT    =   8
)(
        input   wire                        i_clk
    ,   input   wire    [BW_SHIFT-1:0]      i_shift
    ,   input   wire    [0:0]               i_in
    ,   output  wire    [0:0]               o_out
);

reg     [0:0] r_shr_en;
reg     [BW_SHIFT-1:0] r_shr;
always@(posedge i_clk) begin
    if(i_in) begin
        r_shr_en <=  1'd1   ;
    end 
    else if(r_shr==i_shift-1'b1) begin
        r_shr_en <=  1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(i_in) begin
        r_shr <=  0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  (r_shr==i_shift-1'b1) ? 0 : r_shr+1'd1    ;
    end 
end

assign o_out = (i_shift=={{BW_SHIFT}{1'd0}}) ? i_in : r_shr_en&&(r_shr==i_shift-1'b1) ;

endmodule
