/*
////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
--  Module Name : lib_reg
--  Author      : Kilsik Ha
--  Date        : 2014/03/03
--  Abstract    : Multi-bit register
--  Revision
    2014/03/03  : First version created
*/

module lib_reg #(
    parameter                       WIDTH       = 1,
    parameter                       RESET_VAL   = {WIDTH{1'b0}}
) (
    input   wire                    i_clk,
    input   wire                    i_rst,
    input   wire                    i_en,
    input   wire    [WIDTH-1:0]     i_in,
    output  reg     [WIDTH-1:0]     o_out
);

always @ (posedge i_clk or posedge i_rst) begin
    if(i_rst) begin
        o_out   <= RESET_VAL;
    end
    else if(i_en) begin
        o_out   <= i_in;
    end
end

endmodule
