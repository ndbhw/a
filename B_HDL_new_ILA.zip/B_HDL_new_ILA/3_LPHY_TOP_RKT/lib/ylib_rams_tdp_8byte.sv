////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_rams_sdp
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Simple Dual-Port Block RAM (recommended template)
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.7.07  | taeyeong      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.7.09  | jyzoo.lee     | Xilinx Compatible
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_rams_tdp_8byte #(  
  //  parameter  WIDTH        =   64   ,//"FIXED"     //  bytes * byte_width
  //  parameter  DEPTH        =   1024, 
    parameter AWIDTH  = 12,  // Address Width
    parameter NUM_COL = 8,   // Number of columns
    parameter DWIDTH  = 64,  // Data Width, (Byte * NUM_COL) 
    parameter NBPIPE  = 3,    // Number of pipeline Registers
    parameter VENDOR  = "Xilinx"
)(

    input clk,                    // Clock
    
    // Port A
    input rsta,                   // Reset
    input [NUM_COL-1:0] wea,      // Write Enable
    input regcea,                 // Output Register Enable
    input mem_ena,                // Memory Enable
    input [DWIDTH-1:0] dina,      // Data Input  
    input [AWIDTH-1:0] addra,     // Address Input
    output reg [DWIDTH-1:0] douta,// Data Output

    // Port B
    input rstb,                   // Reset
    input [NUM_COL-1:0] web,      // Write Enable
    input regceb,                 // Output Register Enable
    input mem_enb,                // Memory Enable
    input [DWIDTH-1:0] dinb,      // Data Input  
    input [AWIDTH-1:0] addrb,     // Address Input
    output reg [DWIDTH-1:0] doutb // Data Output
    
);

//parameter WIDTH = 64;

//reg [8-1:0] ram [DEPTH-1:0][WIDTH/8-1:0] ;

generate if (VENDOR == "Xilinx") begin

    (* ram_style = "ultra" *)
    reg [DWIDTH-1:0] mem[(1<<AWIDTH)-1:0];        // Memory Declaration
    
    reg [DWIDTH-1:0] memrega;              
    reg [DWIDTH-1:0] mem_pipe_rega[NBPIPE-1:0];    // Pipelines for memory
    reg mem_en_pipe_rega[NBPIPE:0];                // Pipelines for memory enable  
    
    reg [DWIDTH-1:0] memregb;              
    reg [DWIDTH-1:0] mem_pipe_regb[NBPIPE-1:0];    // Pipelines for memory
    reg mem_en_pipe_regb[NBPIPE:0];                // Pipelines for memory enable  
    
    integer          i;
    localparam CWIDTH = DWIDTH/NUM_COL;
    
    // RAM : Read has one latency, Write has one latency as well.
    always @ (posedge clk)
    begin
     if(mem_ena) 
      begin
      for(i = 0;i<NUM_COL;i=i+1) 
         if(wea[i])
        mem[addra][i*CWIDTH +: CWIDTH] <= dina[i*CWIDTH +: CWIDTH];
      end     
    end
    
    always @ (posedge clk)
    begin
     if(mem_ena)
      if(~|wea)
        memrega <= mem[addra];
    end
    
    // The enable of the RAM goes through a pipeline to produce a
    // series of pipelined enable signals required to control the data
    // pipeline.
    always @ (posedge clk)
    begin
    mem_en_pipe_rega[0] <= mem_ena;
     for (i=0; i<NBPIPE; i=i+1)
      mem_en_pipe_rega[i+1] <= mem_en_pipe_rega[i];
    end
    
    // RAM output data goes through a pipeline.
    always @ (posedge clk)
    begin
     if (mem_en_pipe_rega[0])
      mem_pipe_rega[0] <= memrega;
    end
    
    always @ (posedge clk)
    begin
     for (i = 0; i < NBPIPE-1; i = i+1)
      if (mem_en_pipe_rega[i+1])
        mem_pipe_rega[i+1] <= mem_pipe_rega[i];
    end
    
    // Final output register gives user the option to add a reset and
    // an additional enable signal just for the data ouptut
    always @ (posedge clk)
    begin
     if (rsta)
      douta <= 0;
     else if (mem_en_pipe_rega[NBPIPE] && regcea)
      douta <= mem_pipe_rega[NBPIPE-1];
    end 
    
    // RAM : Read has one latency, Write has one latency as well.
    always @ (posedge clk)
    begin
     if(mem_enb) 
      begin
      for(i=0;i<NUM_COL;i=i+1)
         if(web[i])
        mem[addrb][i*CWIDTH +: CWIDTH] <= dinb[i*CWIDTH +: CWIDTH];
      end     
    end
    
    always @ (posedge clk)
    begin
     if(mem_enb)
      if(~|web)
        memregb <= mem[addrb];
    end
    
    // The enable of the RAM goes through a pipeline to produce a
    // series of pipelined enable signals required to control the data
    // pipeline.
    always @ (posedge clk)
    begin
    mem_en_pipe_regb[0] <= mem_enb;
     for (i=0; i<NBPIPE; i=i+1)
      mem_en_pipe_regb[i+1] <= mem_en_pipe_regb[i];
    end
    
    // RAM output data goes through a pipeline.
    always @ (posedge clk)
    begin
     if (mem_en_pipe_regb[0])
      mem_pipe_regb[0] <= memregb;
    end
    
    always @ (posedge clk)
    begin
     for (i = 0; i < NBPIPE-1; i = i+1)
      if (mem_en_pipe_regb[i+1])
        mem_pipe_regb[i+1] <= mem_pipe_regb[i];
    end
    
    // Final output register gives user the option to add a reset and
    // an additional enable signal just for the data ouptut
    always @ (posedge clk)
    begin
     if (rsta)
      doutb <= 0;
     else if (mem_en_pipe_regb[NBPIPE] && regceb)
      doutb <= mem_pipe_regb[NBPIPE-1];
    end 
    
        
    
    
    end

else begin : Intel


    logic [8-1:0][DWIDTH/8-1:0] ram[0:(2**AWIDTH)-1];
    logic [DWIDTH-1:0] mem_pipe_reg[NBPIPE:0];
    
    integer i,j,jj;
    
    initial 
    begin : INIT
        
        for(i = 0; i < 2**AWIDTH; i = i + 1)
        begin
            for(j = 0; j < DWIDTH/8 ; j = j + 1)
            begin
                ram[i][j]          = {8{1'b0}};
            end
        end
    end
         
    
    always@(posedge clk)
    begin
        if (mem_ena)
        begin
            //generate 
            for(j = 0; j < DWIDTH/8 ; j = j + 1)
            begin
                if(wea[0]) ram[addra][0] <= dina[(0+1)*8-1:(0)*8];
                if(wea[1]) ram[addra][1] <= dina[(1+1)*8-1:(1)*8];
                if(wea[2]) ram[addra][2] <= dina[(2+1)*8-1:(2)*8];
                if(wea[3]) ram[addra][3] <= dina[(3+1)*8-1:(3)*8];
                if(wea[4]) ram[addra][4] <= dina[(4+1)*8-1:(4)*8];
                if(wea[5]) ram[addra][5] <= dina[(5+1)*8-1:(5)*8];
                if(wea[6]) ram[addra][6] <= dina[(6+1)*8-1:(6)*8];
                if(wea[7]) ram[addra][7] <= dina[(7+1)*8-1:(7)*8];
                    
    //                     if(be[jj]) ram[addra][jj] <= dia[(8*(jj+1)-1)-:8]; 
            end
            //endgenerate
        end
        if (mem_enb)
            mem_pipe_reg[0] <= ram[addrb];
    end




    always @ (posedge clk)
    begin
     for (i = 0; i < NBPIPE; i = i+1)
      //if (mem_en_pipe_regb[i+1])
        mem_pipe_reg[i+1] <= mem_pipe_reg[i];
    end

    always @ (posedge clk)
    begin
     if (rstb)
      doutb <= 0;
     else //if (mem_en_pipe_regb[NBPIPE] && regceb)
      doutb <= mem_pipe_reg[NBPIPE];
    end 



end
endgenerate

endmodule
