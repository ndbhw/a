////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : Common
//  Module       : ylib_vfft_wrapper
//  Author       : jyzoo.lee@samsung.com
//  Description  : Intel/Xilinx FFT Wrapper
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.10 |jyzoo.lee      | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.07.31 |jyzoo.lee      | Add tuser port for Xilinx IP
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 |jyzoo.lee      | Supports Variable MAX_NFFT (Xilinx)
//  ------------+---------------+-----------------------------------------------
//   2021.10.14 |jyzoo.lee      | Supports 128pts fft and burst fft
//  ------------+---------------+-----------------------------------------------
//   2021.12.07 |jyzoo.lee      | Supports 16,64pts fft and burst fft
//  ------------+---------------+-----------------------------------------------
//   2022.01.13 |jyzoo.lee      | Support the custom FFT
//  ------------+---------------+-----------------------------------------------
//   2022.03.28 |jyzoo.lee      | Support the 1k custom FFT
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_vfft_wrapper #(
    parameter   MAX_NFFT  =   2048 
   ,parameter   VENDOR    =   "Intel" 
   ,parameter   ARC_MODE  =   "Stereaming" // or "Burst"
   ,parameter   FFT_TYPE  =   "FFT"
)(
     input  wire                            clk                    
    ,input  wire                            reset_n            
    ,input  wire                            sink_valid      
    ,output wire                            sink_ready      
    ,input  wire [1:0]                      sink_error      
    ,input  wire                            sink_sop          
    ,input  wire                            sink_eop          
    ,input  wire [15:0]                     sink_real        
    ,input  wire [15:0]                     sink_imag        
    ,input  wire [$clog2(MAX_NFFT):0]       fftpts_in        
    ,input  wire [0:0]                      inverse            
    ,output wire                            source_valid  
    ,input  wire                            source_ready  
    ,output wire [1:0]                      source_error  
    ,output wire                            source_sop      
    ,output wire                            source_eop      
    ,output wire [27:0]                     source_real    
    ,output wire [27:0]                     source_imag    
    ,output wire [$clog2(MAX_NFFT):0]       fftpts_out    
);

generate if(VENDOR == "Intel") begin
zip_vfft_bb_top u00_zip_vfft
(
     .clk          (    clk             ) 
    ,.reset_n      (    reset_n         ) 
    ,.sink_valid   (    sink_valid      ) 
    ,.sink_ready   (    sink_ready      ) 
    ,.sink_error   (    sink_error      ) 
    ,.sink_sop     (    sink_sop        ) 
    ,.sink_eop     (    sink_eop        ) 
    ,.sink_real    (    sink_real       ) 
    ,.sink_imag    (    sink_imag       ) 
    ,.fftpts_in    (    fftpts_in       ) 
    ,.inverse      (    inverse         ) 
    ,.source_valid (    source_valid    ) 
    ,.source_ready (    source_ready    ) 
    ,.source_error (    source_error    ) 
    ,.source_sop   (    source_sop      ) 
    ,.source_eop   (    source_eop      ) 
    ,.source_real  (    source_real     ) 
    ,.source_imag  (    source_imag     ) 
    ,.fftpts_out   (    fftpts_out      )  
);
end
else if(VENDOR == "Custom") begin
localparam  BW_IN_CUSTOM_FFT    =   16 ;
localparam  BW_OUT_CUSTOM_FFT   =  (MAX_NFFT==4096) ? 28 : (MAX_NFFT==2048) ? 27 : (MAX_NFFT==1024) ? 26 : 22 ;
reg [00:0] r_data_valid ; 
reg [BW_IN_CUSTOM_FFT-1:0] r_data_i     ; 
reg [BW_IN_CUSTOM_FFT-1:0] r_data_q     ; 
always@(posedge clk) begin
    r_data_valid <= sink_valid ; 
    if(sink_valid) begin
        r_data_i <= $signed(sink_real)>>>(16-BW_IN_CUSTOM_FFT) ; 
        r_data_q <= $signed(sink_imag)>>>(16-BW_IN_CUSTOM_FFT) ;
    end
end
wire [04:0] w_custom_fft_err ; 
assign  source_error = |w_custom_fft_err[4:1] ;
wire [$clog2(MAX_NFFT)-1:0] w_data_idx ; 
if(MAX_NFFT==4096) begin
reg [01:0] r_fft_type ; 
always@(*) begin
    case(fftpts_in) 
        'd512   : r_fft_type = 2'd0 ;
        'd1024  : r_fft_type = 2'd1 ;
        'd2048  : r_fft_type = 2'd2 ;
        'd4096  : r_fft_type = 2'd3 ;
        default : r_fft_type = 2'd0 ;
    endcase
end
custom_nfft_wrapper_4096 #(
      .IN_WIDTH   (   BW_IN_CUSTOM_FFT      )
     ,.OUT_WIDTH  (   BW_OUT_CUSTOM_FFT     )
     ,.FFT_TYPE   (   FFT_TYPE              ))
u00_custom_vfft
(
     .I_RSTB                                        (   ~reset_n                                )
    ,.I_CLK                                         (    clk                                    )
    ,.I_DATA_SYNC                                   (    sink_valid&~r_data_valid               )
    ,.I_DATA_VLD                                    (    r_data_valid                           )
    ,.I_DATA_I                                      (    r_data_i                               )
    ,.I_DATA_Q                                      (    r_data_q                               )
    ,.I_nFFT_TYPE                                   (    r_fft_type                             )
    ,.O_DATA_SYNC                                   (    source_sop                             )
    ,.O_DATA_VLD                                    (    source_valid                           )
    ,.O_DATA_IDX                                    (    w_data_idx                             )
    ,.O_DATA_I                                      (    source_real[BW_OUT_CUSTOM_FFT-1:0]     )
    ,.O_DATA_Q                                      (    source_imag[BW_OUT_CUSTOM_FFT-1:0]     )
    ,.O_DATA_LAST                                   (    source_eop                             )
    ,.O_STATUS_NOT_READY_TO_CHANGE_MODE             (    w_custom_fft_err[0]                    )
    ,.O_STATUS_EXTENDED_INPUT_DATA                  (    w_custom_fft_err[1]                    )
    ,.O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED	    (    w_custom_fft_err[2]                    )
    ,.O_EVENT_I_SYNC_UNEXPECTED                     (    w_custom_fft_err[3]                    )
    ,.O_EVENT_NOT_READY_TO_CHANGE_TYPE              (    w_custom_fft_err[4]                    )
);
end
else if(MAX_NFFT==2048) begin
reg [01:0] r_fft_type ; 
always@(*) begin
    case(fftpts_in) 
        'd512   : r_fft_type = 2'd0 ;
        'd1024  : r_fft_type = 2'd1 ;
        'd2048  : r_fft_type = 2'd2 ;
        default : r_fft_type = 2'd0 ;
    endcase
end
custom_nfft_wrapper_2048 #(
      .IN_WIDTH   (   BW_IN_CUSTOM_FFT      )
     ,.OUT_WIDTH  (   BW_OUT_CUSTOM_FFT     )
     ,.FFT_TYPE   (   FFT_TYPE              ))
u00_custom_vfft
(
     .I_RSTB                                        (   ~reset_n                                ) 
    ,.I_CLK                                         (    clk                                    ) 
    ,.I_DATA_SYNC                                   (    sink_valid&~r_data_valid               ) 
    ,.I_DATA_VLD                                    (    r_data_valid                           ) 
    ,.I_DATA_I                                      (    r_data_i                               ) 
    ,.I_DATA_Q                                      (    r_data_q                               ) 
    ,.I_nFFT_TYPE                                   (    r_fft_type                             ) 
    ,.O_DATA_SYNC                                   (    source_sop                             )
    ,.O_DATA_VLD                                    (    source_valid                           ) 
    ,.O_DATA_IDX                                    (    w_data_idx                             ) 
    ,.O_DATA_I                                      (    source_real[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_Q                                      (    source_imag[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_LAST                                   (    source_eop                             )
    ,.O_STATUS_NOT_READY_TO_CHANGE_MODE             (    w_custom_fft_err[0]                    ) 
    ,.O_STATUS_EXTENDED_INPUT_DATA                  (    w_custom_fft_err[1]                    ) 
    ,.O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED	    (    w_custom_fft_err[2]                    ) 
    ,.O_EVENT_I_SYNC_UNEXPECTED                     (    w_custom_fft_err[3]                    ) 
    ,.O_EVENT_NOT_READY_TO_CHANGE_TYPE              (    w_custom_fft_err[4]                    ) 
);
assign source_real[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_real[BW_OUT_CUSTOM_FFT-1]}} ;
assign source_imag[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_imag[BW_OUT_CUSTOM_FFT-1]}} ;
end //MAX_NFFT==2048
else if(MAX_NFFT==1024) begin
reg [00:0] r_fft_type ; 
always@(*) begin
    case(fftpts_in) 
        'd512   : r_fft_type = 1'd0 ;
        'd1024  : r_fft_type = 1'd1 ;
        default : r_fft_type = 1'd0 ;
    endcase
end
custom_nfft_wrapper_1024 #(
      .IN_WIDTH   (   BW_IN_CUSTOM_FFT      )
     ,.OUT_WIDTH  (   BW_OUT_CUSTOM_FFT     )
     ,.FFT_TYPE   (   FFT_TYPE              ))
u00_custom_vfft
(
     .I_RSTB                                        (   ~reset_n                                ) 
    ,.I_CLK                                         (    clk                                    ) 
    ,.I_DATA_SYNC                                   (    sink_valid&~r_data_valid               ) 
    ,.I_DATA_VLD                                    (    r_data_valid                           ) 
    ,.I_DATA_I                                      (    r_data_i                               ) 
    ,.I_DATA_Q                                      (    r_data_q                               ) 
    ,.I_nFFT_TYPE                                   (    r_fft_type                             ) 
    ,.O_DATA_SYNC                                   (    source_sop                             )
    ,.O_DATA_VLD                                    (    source_valid                           ) 
    ,.O_DATA_IDX                                    (    w_data_idx                             ) 
    ,.O_DATA_I                                      (    source_real[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_Q                                      (    source_imag[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_LAST                                   (    source_eop                             )
    ,.O_STATUS_NOT_READY_TO_CHANGE_MODE             (    w_custom_fft_err[0]                    ) 
    ,.O_STATUS_EXTENDED_INPUT_DATA                  (    w_custom_fft_err[1]                    ) 
    ,.O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED	    (    w_custom_fft_err[2]                    ) 
    ,.O_EVENT_I_SYNC_UNEXPECTED                     (    w_custom_fft_err[3]                    ) 
    ,.O_EVENT_NOT_READY_TO_CHANGE_TYPE              (    w_custom_fft_err[4]                    ) 
);
assign source_real[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_real[BW_OUT_CUSTOM_FFT-1]}} ;
assign source_imag[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_imag[BW_OUT_CUSTOM_FFT-1]}} ;
end //MAX_NFFT==1024
else if(MAX_NFFT==64) begin
reg [00:0] r_fft_type ; 
always@(*) begin
    case(fftpts_in) 
        'd16    : r_fft_type = 1'd0 ;
        'd64    : r_fft_type = 1'd1 ;
        default : r_fft_type = 1'd0 ;
    endcase
end
custom_nfft_wrapper_64_16 #(
      .IN_WIDTH   (   BW_IN_CUSTOM_FFT      )
     ,.OUT_WIDTH  (   BW_OUT_CUSTOM_FFT     )
     ,.FFT_TYPE   (   FFT_TYPE              ))
u00_custom_vfft
(
     .I_RSTB                                        (   ~reset_n                                ) 
    ,.I_CLK                                         (    clk                                    ) 
    ,.I_DATA_SYNC                                   (    sink_valid&~r_data_valid               ) 
    ,.I_DATA_VLD                                    (    r_data_valid                           ) 
    ,.I_DATA_I                                      (    r_data_i                               ) 
    ,.I_DATA_Q                                      (    r_data_q                               ) 
    ,.I_nFFT_TYPE                                   (    r_fft_type                             ) 
    ,.O_DATA_SYNC                                   (    source_sop                             )
    ,.O_DATA_VLD                                    (    source_valid                           ) 
    ,.O_DATA_IDX                                    (    w_data_idx                             ) 
    ,.O_DATA_I                                      (    source_real[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_Q                                      (    source_imag[BW_OUT_CUSTOM_FFT-1:0]     ) 
    ,.O_DATA_LAST                                   (    source_eop                             )
    ,.O_STATUS_NOT_READY_TO_CHANGE_MODE             (    w_custom_fft_err[0]                    ) 
    ,.O_STATUS_EXTENDED_INPUT_DATA                  (    w_custom_fft_err[1]                    ) 
    ,.O_EVENT_I_DATA_VLD_SHORT_OR_DISCOUNTINUED	    (    w_custom_fft_err[2]                    ) 
    ,.O_EVENT_I_SYNC_UNEXPECTED                     (    w_custom_fft_err[3]                    ) 
    ,.O_EVENT_NOT_READY_TO_CHANGE_TYPE              (    w_custom_fft_err[4]                    ) 
);
assign source_real[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_real[BW_OUT_CUSTOM_FFT-1]}} ;
assign source_imag[28-1:BW_OUT_CUSTOM_FFT] = {{28-BW_OUT_CUSTOM_FFT}{source_imag[BW_OUT_CUSTOM_FFT-1]}} ;
end //MAX_NFFT==64
end
else begin //Xilinx
reg [00:0] r_s_axis_config_tvalid ; 
reg [15:0] r_s_axis_config_tdata ; 
always@(posedge clk) begin
    if(!reset_n) begin
        r_s_axis_config_tvalid <= 1'd0  ; 
        r_s_axis_config_tdata  <= 16'd0 ; 
    end
    else if(sink_sop) begin
        r_s_axis_config_tvalid <= sink_sop  ; 
        case(fftpts_in) 
            'd16        :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b00100}   ;
            'd64        :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b00110}   ;
            'd128       :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b00111}   ;
            'd512       :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01001}   ;
            'd1024      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01010}   ;
            'd2048      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01011}   ;
            'd4096      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01100}   ;
            default     :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01010}   ;
        endcase
    end
    else begin
        r_s_axis_config_tvalid <= 1'd0  ; 
    end
end

reg [00:0] r_s_axis_data_tvalid ; 
reg [31:0] r_s_axis_data_tdata  ; 
reg [00:0] r_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(sink_valid) begin
        r_s_axis_data_tvalid    <= sink_valid  ; 
        r_s_axis_data_tdata     <= {sink_imag,sink_real}   ; 
        r_s_axis_data_tlast     <= sink_eop  ; 
    end
    else begin
        r_s_axis_data_tvalid    <= 1'd0  ; 
        r_s_axis_data_tlast     <= 1'd0  ; 
    end
end
reg [00:0] rr_s_axis_data_tvalid ; 
reg [31:0] rr_s_axis_data_tdata  ; 
reg [00:0] rr_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(r_s_axis_data_tvalid) begin
        rr_s_axis_data_tvalid   <= r_s_axis_data_tvalid ;
        rr_s_axis_data_tdata    <= r_s_axis_data_tdata  ;   
        rr_s_axis_data_tlast    <= r_s_axis_data_tlast  ;
    end
    else begin
        rr_s_axis_data_tvalid   <= 1'd0  ; 
        rr_s_axis_data_tlast    <= 1'd0  ; 
    end
end
reg [00:0] rrr_s_axis_data_tvalid ; 
reg [31:0] rrr_s_axis_data_tdata  ; 
reg [00:0] rrr_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(rr_s_axis_data_tvalid) begin
        rrr_s_axis_data_tvalid   <= rr_s_axis_data_tvalid ;
        rrr_s_axis_data_tdata    <= rr_s_axis_data_tdata  ;   
        rrr_s_axis_data_tlast    <= rr_s_axis_data_tlast  ;
    end
    else begin
        rrr_s_axis_data_tvalid   <= 1'd0  ; 
        rrr_s_axis_data_tlast    <= 1'd0  ; 
    end
end

wire w_s_axis_config_tready     ; 
wire w_s_axis_data_tready       ; 
wire [3:0]  source_real_dummy   ;
wire [3:0]  source_imag_dummy   ;
wire event_tlast_unexpected     ;
wire event_tlast_missing        ;
wire event_status_channel_halt  ;
wire event_data_in_channel_halt ;
wire event_data_out_channel_halt;
wire [0:0]  source_real_dummy_64 ;
wire [0:0]  source_imag_dummy_64 ;
wire [22:0] source_real_64 ;    
wire [22:0] source_imag_64 ;    
wire [2:0]  source_real_dummy_16 ;
wire [2:0]  source_imag_dummy_16 ;
wire [20:0] source_real_16 ;    
wire [20:0] source_imag_16 ;    
if(MAX_NFFT==16) begin
    if(ARC_MODE == "Burst") begin
    xip_vfft_bb_top_16_burst u00_xip_vfft_burst
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy_16,source_imag_16,source_real_dummy_16,source_real_16}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
    else begin
    xip_vfft_bb_top_16 u00_xip_vfft
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy_16,source_imag_16,source_real_dummy_16,source_real_16}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
    assign  source_real   =   {{7{source_real_16[20]}},source_real_16}   ;
    assign  source_imag   =   {{7{source_imag_16[20]}},source_imag_16}   ;
end
else if(MAX_NFFT==64) begin
    if(ARC_MODE == "Burst") begin
    xip_vfft_bb_top_64_burst u00_xip_vfft_burst
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy_64,source_imag_64,source_real_dummy_64,source_real_64}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
    else begin
    xip_vfft_bb_top_64 u00_xip_vfft
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy_64,source_imag_64,source_real_dummy_64,source_real_64}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
    assign  source_real   =   {{5{source_real_64[22]}},source_real_64}   ;
    assign  source_imag   =   {{5{source_imag_64[22]}},source_imag_64}   ;
end
else if(MAX_NFFT==128) begin
    if(ARC_MODE == "Burst") begin
    xip_vfft_bb_top_128_burst u00_xip_vfft_burst
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
    else begin
    xip_vfft_bb_top_128 u00_xip_vfft
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    ); 
    end
end
else if(MAX_NFFT==512) begin
    if(ARC_MODE == "Burst") begin
    xip_vfft_bb_top_512_burst u00_xip_vfft_burst
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    );
    end
    else begin
    xip_vfft_bb_top_512 u00_xip_vfft
    (
         .aclk                          (   clk                                                             )   
        ,.aresetn                       (   reset_n                                                         )
        ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
        ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
        ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
        ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
        ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
        ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
        ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
        ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
        ,.m_axis_data_tvalid            (   source_valid                                                    )
        ,.m_axis_data_tready            (   source_ready                                                    )
        ,.m_axis_data_tlast             (   source_eop                                                      )
        ,.event_frame_started           (   source_sop                                                      )
        ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
        ,.event_tlast_missing           (   event_tlast_missing                                             )   
        ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
        ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
        ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
    );
    end
end
else if(MAX_NFFT==1024) begin
xip_vfft_bb_top_1024 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
else if(MAX_NFFT==2048) begin
xip_vfft_bb_top_2048 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
else if(MAX_NFFT==4096) begin
xip_vfft_bb_top_4096 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
assign  source_error = event_tlast_unexpected|event_tlast_missing|event_status_channel_halt|event_data_in_channel_halt|event_data_out_channel_halt   ; 
assign  fftpts_out = fftpts_in ;
end
endgenerate
endmodule
