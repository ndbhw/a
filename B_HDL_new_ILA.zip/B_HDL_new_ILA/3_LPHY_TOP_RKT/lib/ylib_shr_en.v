////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : ylib_shr
//  Author       : 
//  Description  : Shift Register
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.08.12 |               |  
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_shr_en #(
      parameter                WIDTH = 1
    , parameter                DEPTH = 8
) (
      input  wire              i_clk
    , input  wire              i_en  
    , input  wire [WIDTH-1:0]  i_in  
    , output wire [WIDTH-1:0]  o_out
);

(* shreg_extract = "yes" *)reg     [WIDTH-1:0] r_shr[DEPTH-1:0];

integer i;
initial begin
	for(i=0; i<DEPTH; i=i+1) r_shr[i]	<=0;
end

integer k;

always @ (posedge i_clk) begin
    if(i_en) begin
        r_shr[0]  <= i_in;
        for(k = 1; k < DEPTH; k = k + 1) begin
            r_shr[k] <= r_shr[k-1];
        end
    end
    else
        for(k = 1; k < DEPTH; k = k + 1) begin
            r_shr[k] <= r_shr[k-1];
        end
end

assign o_out = r_shr[DEPTH-1];

endmodule
