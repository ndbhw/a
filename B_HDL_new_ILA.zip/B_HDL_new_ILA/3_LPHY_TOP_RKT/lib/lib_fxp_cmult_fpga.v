////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : lib_fxp_cmult
//  Author       : Song, Moon-Gun
//  Description  : Fixed Point Complex Multiplier which is Complied 3 DSP48s
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2018.05.25 |Song, Moon-Gun | Remove DSP Reg. Reset, Latency 5 -> 6 for PnR
//  ------------+---------------+-----------------------------------------------
////////////////////////////////////////////////////////////////////////////////


//dly6
(* use_dsp = "yes" *) module lib_fxp_cmult_fpga
#(
      parameter  XB = 16
    , parameter  YB = 16
    , parameter  OB = XB + YB + 1
)( 
      input                            i_clk   
   
    , input                            i_vld    
    , input  wire signed [     XB-1:0] i_x_i  
    , input  wire signed [     XB-1:0] i_x_q  
    , input  wire signed [     YB-1:0] i_y_i  
    , input  wire signed [     YB-1:0] i_y_q  
   
    , output wire                      o_vld    
    , output wire signed [     OB-1:0] o_z_i  
    , output wire signed [     OB-1:0] o_z_q  
);

localparam LATENCY = 6;

reg signed [     XB-1:0]  r_x_i_1d=0, r_x_i_2d=0, r_x_i_3d=0, r_x_i_4d=0;
reg signed [     XB-1:0]  r_x_q_1d=0, r_x_q_2d=0, r_x_q_3d=0, r_x_q_4d=0;
reg signed [     YB-1:0]  r_y_i_1d=0, r_y_i_2d=0, r_y_i_3d=0;
reg signed [     YB-1:0]  r_y_q_1d=0, r_y_q_2d=0, r_y_q_3d=0;
reg signed [   XB+1-1:0]  r_add=0;
reg signed [   YB+1-1:0]  r_add_i=0, r_add_q=0;
reg signed [XB+YB+1-1:0]  r_mult0=0, r_mult_i=0, r_mult_q=0;
reg signed [XB+YB+1-1:0]  r_common=0, r_common_i=0, r_common_q=0;
reg signed [XB+YB+1-1:0]  r_z_i=0;  
reg signed [XB+YB+1-1:0]  r_z_q=0;  

always @ (posedge i_clk) begin
    r_x_i_1d  <= i_x_i;
    r_x_i_2d  <= r_x_i_1d;
    r_x_q_1d  <= i_x_q;
    r_x_q_2d  <= r_x_q_1d;
    r_y_i_1d  <= i_y_i;
    r_y_i_2d  <= r_y_i_1d;
    r_y_i_3d  <= r_y_i_2d;
    r_y_q_1d  <= i_y_q;
    r_y_q_2d  <= r_y_q_1d;
    r_y_q_3d  <= r_y_q_2d;
end

always @ (posedge i_clk) begin
    r_add    <= r_x_i_1d - r_x_q_1d;
    r_mult0  <= r_add    * r_y_q_2d;
    r_common <= r_mult0;
end

always @ (posedge i_clk) begin
    r_x_i_3d   <= r_x_i_2d;
    r_x_i_4d   <= r_x_i_3d;
    r_add_i    <= r_y_i_3d - r_y_q_3d ;
    r_mult_i   <= r_add_i  * r_x_i_4d;
    r_common_i <= r_common;
    r_z_i      <= r_mult_i + r_common_i;
end

always @ (posedge i_clk) begin
    r_x_q_3d   <= r_x_q_2d;
    r_x_q_4d   <= r_x_q_3d;
    r_add_q    <= r_y_i_3d + r_y_q_3d;
    r_mult_q   <= r_add_q  * r_x_q_4d;
    r_common_q <= r_common;
    r_z_q      <= r_mult_q + r_common_q;
end

assign o_z_i = r_z_i[OB-1:0];
assign o_z_q = r_z_q[OB-1:0];

lib_shr_fpga #(.WIDTH(1), .DEPTH(LATENCY)) u_lib_shr
(    
     .i_clk    (    i_clk   )                        
    ,.i_en     (    1'b1    )
    ,.i_in     (    i_vld   )
    ,.o_out    (    o_vld   )
);


endmodule
