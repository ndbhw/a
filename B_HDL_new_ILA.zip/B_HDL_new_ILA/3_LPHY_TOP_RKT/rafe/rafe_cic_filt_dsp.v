// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU 20
//  Module       : rafe_cic_filt
//  Author       : jyzoo.lee@samsung.com
//  Description  : decimation filter (cascade integrator comb)
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.5.18  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

module rafe_cic_filt_dsp
#(
    parameter  NUM_ANT             =   4           
   ,parameter  MAX_OBW             =   100 
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16           
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from oran 
    ,   input   wire    [2      -1:0]               i_over_ratio      
    ,   input   wire    [7      -1:0]               i_deci_ratio   
    ,   input   wire    [5      -1:0]               i_cic_out_atten

    //--- from freq_shift
    ,   input   wire    [8      -1:0]               i_path_ratio
    ,   input   wire    [1      -1:0]               i_sub_rst
    ,   input   wire    [1      -1:0]               i_ce

    ,   input   wire    [1      -1:0]               i_frame_sync           
    ,   input   wire    [NUM_ANT-1:0]               i_rin_en           
    ,   input   wire    [2*DI_BW-1:0]               i_rin_iq           

    //--- to rach_config_map
    ,   output  reg     [1      -1:0]               o_frame_sync           
    ,   output  wire    [NUM_ANT-1:0]               o_rout_en
    ,   output  wire    [2*DO_BW-1:0]               o_rout_iq      
);

// local param

localparam  NUM_STAGE_INTG          =   3'd5                                    ;
localparam  NUM_STAGE_DIFF          =   3'd5                                    ;
//localparam  BW_CIC                  =   (MAX_OBW == 100 )? 38 : 32              ; // 34 bit @100 MBW x 4ms , FSU20 32 bit
localparam  BW_CIC                  =   44                                      ; // 1024 fft 
localparam  BW_PD_DSP               =   48 - BW_CIC                             ;
localparam  BW_DECI_FILT_DLY        =   3+6                                     ; // BW_SMP_RATE + BW_DECI_RATIO


// signal
genvar gidx,nidx,didx ;


// block

// param reg
reg [7 -1:0]  r_deci_ratio    ;    
reg [5 -1:0]  r_cic_out_atten ;

always@(posedge i_clk) begin
        r_deci_ratio    <=  i_deci_ratio    ;
        r_cic_out_atten <=  i_cic_out_atten ;
end

// oR -- TBD 0
reg [NUM_ANT-1:0]               r_rin_en;          
reg [2*DI_BW-1:0]               r_rin_iq;          


always @(posedge i_clk) begin
    r_rin_en    <= i_rin_en;          
    r_rin_iq    <= i_rin_iq;          
end

// frm sync dly
reg     [1      -1:0]               r_frame_sync_dly1;           
reg     [1      -1:0]               r_frame_sync_dly2;          

always @(posedge i_clk) begin
    r_frame_sync_dly1   <= ((~i_ce & i_frame_sync) | i_sub_rst);   
    r_frame_sync_dly2   <= r_frame_sync_dly1         ;                     
end

// integration


reg [NUM_ANT-1:0]   r_int_en   [1+NUM_STAGE_DIFF-1:0];             
reg [2*BW_CIC-1:0]  r_int_iq   [1+NUM_STAGE_DIFF-1:0][NUM_ANT-1:0];  
wire [2*48-1:0]  w_int_iq   [1+NUM_STAGE_DIFF-1:0][NUM_ANT-1:0];  

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_intg_ant
    always@(posedge i_clk) begin
        if (r_rin_en[gidx]) begin
            r_int_en[0][gidx] <= r_rin_en[gidx] ;
            r_int_iq[0][gidx][(BW_CIC*2-1)-:BW_CIC]  <=  {{{BW_CIC-DI_BW}{r_rin_iq[DI_BW*2-1]}},r_rin_iq[(DI_BW*2-1)-:DI_BW]}    ;
            r_int_iq[0][gidx][(BW_CIC*1-1)-:BW_CIC]  <=  {{{BW_CIC-DI_BW}{r_rin_iq[DI_BW*1-1]}},r_rin_iq[(DI_BW*1-1)-:DI_BW]}    ;
        end
        else begin
            r_int_en[0][gidx]   <= 0; 
            r_int_iq[0][gidx]   <= {{2*BW_CIC}{1'd0}}; 
        end
    end

    for(nidx=1;nidx<=NUM_STAGE_INTG;nidx=nidx+1) begin : n00_intg_stage
        always@(posedge i_clk) begin
            //r_int_en[nidx][gidx]    <=  r_int_en[nidx-1][gidx]  ;
            
            if(r_frame_sync_dly2) begin
                r_int_en[nidx][gidx]  <=   {NUM_ANT{1'd0}}      ;
            end
            else begin
                r_int_en[nidx][gidx]    <=  r_int_en[nidx-1][gidx]  ;
            end

            if(r_frame_sync_dly2) begin
                r_int_iq[nidx][gidx]  <=   {{2*BW_CIC}{1'd0}}   ;
            end
            else if(r_int_en[nidx-1][gidx]) begin
                // r_int_iq[nidx][gidx][(BW_CIC*2-1)-:BW_CIC]  <=   $signed(r_int_iq[nidx][gidx][(BW_CIC*2-1)-:BW_CIC])+$signed(r_int_iq[nidx-1][gidx][(BW_CIC*2-1)-:BW_CIC])    ;
                // r_int_iq[nidx][gidx][(BW_CIC*1-1)-:BW_CIC]  <=   $signed(r_int_iq[nidx][gidx][(BW_CIC*1-1)-:BW_CIC])+$signed(r_int_iq[nidx-1][gidx][(BW_CIC*1-1)-:BW_CIC])    ;
                r_int_iq[nidx][gidx][(BW_CIC*2-1)-:BW_CIC]  <= w_int_iq[nidx][gidx][(48*1)+:BW_CIC] ; 
                r_int_iq[nidx][gidx][(BW_CIC*1-1)-:BW_CIC]  <= w_int_iq[nidx][gidx][(48*0)+:BW_CIC] ; 
            end
        end
        
        ylib_xdsp48
        u00_ylib_xdsp48(
             .a     ( 27'b0           )   
            ,.b     ( 18'b0           )   
            ,.c     ( 48'b0           )   
            ,.d     ( {{BW_PD_DSP{r_int_iq[nidx  ][gidx][(BW_CIC*2-1)]}},r_int_iq[nidx  ][gidx][(BW_CIC*2-1)-:BW_CIC]}            )   
            ,.e     ( {{BW_PD_DSP{r_int_iq[nidx-1][gidx][(BW_CIC*2-1)]}},r_int_iq[nidx-1][gidx][(BW_CIC*2-1)-:BW_CIC]}            )   
            ,.out   ( w_int_iq[nidx][gidx][(48*2-1)-:48]            )   
        );
        ylib_xdsp48
        u01_ylib_xdsp48(
             .a     ( 27'b0           )   
            ,.b     ( 18'b0           )   
            ,.c     ( 48'b0           )   
            ,.d     ( {{BW_PD_DSP{r_int_iq[nidx  ][gidx][(BW_CIC*1-1)]}},r_int_iq[nidx  ][gidx][(BW_CIC*1-1)-:BW_CIC]}             )   
            ,.e     ( {{BW_PD_DSP{r_int_iq[nidx-1][gidx][(BW_CIC*1-1)]}},r_int_iq[nidx-1][gidx][(BW_CIC*1-1)-:BW_CIC]}             )   
            ,.out   ( w_int_iq[nidx][gidx][(48*1-1)-:48]           )   
        );
    end//n00_intg_stage
end//g01_intg_ant
endgenerate    


//decimation
reg [6:0]   r_dec_cnt = 0  ;             

always@(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_dec_cnt   <=  6'd0 ; 
    end
    else if(r_int_en[NUM_STAGE_INTG-1][0]) begin
        r_dec_cnt <=  (r_dec_cnt==r_deci_ratio-1'd1) ? 7'd0 : r_dec_cnt+1'd1 ; 
    end
end

reg     [0:0]           r_dec_en    [NUM_ANT-1:0]   ;  
reg     [2*BW_CIC-1:0]  r_dec_iq    [NUM_ANT-1:0]; //  = { 0, 0} ;             

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g02_deci
    always@(posedge i_clk) begin
        if(r_frame_sync_dly2) begin
            r_dec_iq[gidx]  <=  {{2*BW_CIC}{1'd0}}   ;
        end
        else if(r_int_en[NUM_STAGE_INTG][gidx]&&r_deci_ratio==7'd1) begin
            r_dec_en[gidx]  <=  r_int_en[NUM_STAGE_INTG][gidx]    ;
            r_dec_iq[gidx]  <=  r_int_iq[NUM_STAGE_INTG][gidx]    ;
        end
        else if(r_int_en[NUM_STAGE_INTG][gidx]&&r_dec_cnt==7'd1) begin
            r_dec_en[gidx]  <=  r_int_en[NUM_STAGE_INTG][gidx]    ;
            r_dec_iq[gidx]  <=  r_int_iq[NUM_STAGE_INTG][gidx]    ;
        end
        else begin
            r_dec_en[gidx]  <=  1'd0    ;
        end
    end
end

endgenerate



//differentiation
reg     [NUM_ANT    -1:0]  r_diff_en    ;  
reg     [NUM_ANT    -1:0]  rr_diff_en   ;  
reg     [2*BW_CIC   -1:0]  r_diff_iq   [1+NUM_STAGE_DIFF-1:0][NUM_ANT-1:0] ;  
reg     [2*BW_CIC   -1:0]  rr_diff_iq  [1+NUM_STAGE_DIFF-1:0][NUM_ANT-1:0] ;  

wire    [2*48       -1:0]  w_diff_iq   [1+NUM_STAGE_DIFF-1:0][NUM_ANT-1:0] ;             
reg     [8          -1:0]  r_diff_out_en  ;  
reg     [2*BW_CIC   -1:0]  r_diff_out_iq [8-1:0] ; 

reg [3  -1:0]   r_diff_stage_cnt  = 0  ;             

reg     [8          -1:0]  r_deci_filt_r_en ;  
reg     [2*BW_CIC   -1:0]  r_deci_filt_r_iq ;     

always@(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_diff_stage_cnt <= 3'd0    ;
    end
    else if(|rr_diff_en) begin
        if(r_diff_stage_cnt<NUM_STAGE_DIFF) begin
            r_diff_stage_cnt <= r_diff_stage_cnt+3'd1   ;
        end
    end
end
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_diff_ant
    always@(*) begin
        r_diff_en[gidx]     =  r_dec_en[gidx]   ;
        r_diff_iq[0][gidx]  =  r_dec_iq[gidx]   ;
    end
    always@(posedge i_clk) begin
        if(r_frame_sync_dly2) begin
            rr_diff_iq[0][gidx]  <=  {{2*BW_CIC}{1'd0}}   ;
        end
        else if(r_diff_en[gidx]) begin
            rr_diff_iq[0][gidx]  <=  r_diff_iq[0][gidx] ;
        end
    end
        for(nidx=1;nidx<=NUM_STAGE_DIFF;nidx=nidx+1) begin : n00_diff_stage
            always@(posedge i_clk) begin
                if(r_frame_sync_dly2) begin
                    r_diff_iq[nidx][gidx]   <=  {{2*BW_CIC}{1'd0}}  ;
                    rr_diff_iq[nidx][gidx]  <=  {{2*BW_CIC}{1'd0}}  ;
                end
                else if(r_diff_en[gidx]) begin
                    rr_diff_iq[nidx][gidx]   <= r_diff_iq[nidx][gidx]  ;
                //     r_diff_iq[nidx][gidx][(BW_CIC*2-1)-:BW_CIC]  <=   $signed(r_diff_iq[nidx-1][gidx][(BW_CIC*2-1)-:BW_CIC])-$signed(rr_diff_iq[nidx-1][gidx][(BW_CIC*2-1)-:BW_CIC])   ;
                //     r_diff_iq[nidx][gidx][(BW_CIC*1-1)-:BW_CIC]  <=   $signed(r_diff_iq[nidx-1][gidx][(BW_CIC*1-1)-:BW_CIC])-$signed(rr_diff_iq[nidx-1][gidx][(BW_CIC*1-1)-:BW_CIC])   ;
                    r_diff_iq[nidx][gidx][(BW_CIC*2-1)-:BW_CIC]  <= w_diff_iq[nidx][gidx][(48*1)+:BW_CIC]    ;
                    r_diff_iq[nidx][gidx][(BW_CIC*1-1)-:BW_CIC]  <= w_diff_iq[nidx][gidx][(48*0)+:BW_CIC]    ;
                end
            end
        end//n00_intg_stage

    always@(posedge i_clk) begin
        rr_diff_en[gidx] <=  r_diff_en[gidx]   ;
    end

    for(didx=1;didx<=NUM_STAGE_DIFF;didx=didx+1) begin : d00_diff_stage_dsp

        ylib_xdsp48 #(
             .MODE  ("SUB"))
        u02_ylib_xdsp48(
             .a     ( 27'b0           )   
            ,.b     ( 18'b0           )   
            ,.c     ( 48'b0           )   
            ,.d     ( {{BW_PD_DSP{r_diff_iq [didx-1][gidx][(BW_CIC*2-1)]}},r_diff_iq [didx-1][gidx][(BW_CIC*2-1)-:BW_CIC]}              )   
            ,.e     ( {{BW_PD_DSP{rr_diff_iq[didx-1][gidx][(BW_CIC*2-1)]}},rr_diff_iq[didx-1][gidx][(BW_CIC*2-1)-:BW_CIC]}              )   
            ,.out   ( w_diff_iq[didx][gidx][(48*2-1)-:48]            )   
        );
        ylib_xdsp48 #(
             .MODE  ("SUB"))
        u03_ylib_xdsp48(
             .a     ( 27'b0           )   
            ,.b     ( 18'b0           )   
            ,.c     ( 48'b0           )   
            ,.d     ( {{BW_PD_DSP{r_diff_iq [didx-1][gidx][(BW_CIC*1-1)]}},r_diff_iq [didx-1][gidx][(BW_CIC*1-1)-:BW_CIC]}              )   
            ,.e     ( {{BW_PD_DSP{rr_diff_iq[didx-1][gidx][(BW_CIC*1-1)]}},rr_diff_iq[didx-1][gidx][(BW_CIC*1-1)-:BW_CIC]}              )   
            ,.out   ( w_diff_iq[didx][gidx][(48*1-1)-:48]            )   
        );
    end
end//g01_intg_ant

endgenerate


always @(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_diff_out_iq[0]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[1]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[2]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[3]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[4]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[5]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[6]   <= {(2*BW_CIC){1'b0}};
        r_diff_out_iq[7]   <= {(2*BW_CIC){1'b0}};
    end
    else if(NUM_ANT > 1) begin
        r_diff_out_iq[0]  <=  r_diff_iq[NUM_STAGE_DIFF][0] ;
        r_diff_out_iq[1]  <=  r_diff_iq[NUM_STAGE_DIFF][1] ;
        if(NUM_ANT > 3) begin
            r_diff_out_iq[2]  <=  r_diff_iq[NUM_STAGE_DIFF][2] ;
            r_diff_out_iq[3]  <=  r_diff_iq[NUM_STAGE_DIFF][3] ;
            if(NUM_ANT > 7) begin
                r_diff_out_iq[4]  <=  r_diff_iq[NUM_STAGE_DIFF][4] ;
                r_diff_out_iq[5]  <=  r_diff_iq[NUM_STAGE_DIFF][5] ;
                r_diff_out_iq[6]  <=  r_diff_iq[NUM_STAGE_DIFF][6] ;
                r_diff_out_iq[7]  <=  r_diff_iq[NUM_STAGE_DIFF][7] ;
            end
        end
    end
end



always @(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_diff_out_en  <=   8'd0    ;
    end
    else if(r_diff_stage_cnt>=NUM_STAGE_DIFF-1'd1) begin
        r_diff_out_en  <=  {{(8-NUM_ANT){1'b0}},rr_diff_en};
    end
    else begin
        r_diff_out_en  <=   8'd0    ;   
    end                                 
end

always @(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_deci_filt_r_iq    <= {(2*BW_CIC){1'b0}}; 
    end
    else begin
        case(r_diff_out_en) 
            8'b0000_0001 : r_deci_filt_r_iq <= r_diff_out_iq[0][2*BW_CIC-1:0];
            8'b0000_0010 : r_deci_filt_r_iq <= r_diff_out_iq[1][2*BW_CIC-1:0];
            8'b0000_0100 : r_deci_filt_r_iq <= r_diff_out_iq[2][2*BW_CIC-1:0];
            8'b0000_1000 : r_deci_filt_r_iq <= r_diff_out_iq[3][2*BW_CIC-1:0];
            8'b0001_0000 : r_deci_filt_r_iq <= r_diff_out_iq[4][2*BW_CIC-1:0];
            8'b0010_0000 : r_deci_filt_r_iq <= r_diff_out_iq[5][2*BW_CIC-1:0];
            8'b0100_0000 : r_deci_filt_r_iq <= r_diff_out_iq[6][2*BW_CIC-1:0];
            8'b1000_0000 : r_deci_filt_r_iq <= r_diff_out_iq[7][2*BW_CIC-1:0];
            default      : r_deci_filt_r_iq <= {2*BW_CIC{1'b0}}              ;
        endcase
    end
end

always @(posedge i_clk) begin
    r_deci_filt_r_en    <=  r_diff_out_en; 
end


// // p2s

wire                    w_deci_filt_r_en     ;  
wire    [2*BW_CIC-1:0]  w_deci_filt_r_iq     ;  
wire                    w_sat_r_en           ;  
wire    [2*DO_BW-1:0]   w_sat_r_iq           ;  

ylib_shiftd_rnd #(
     .NUM_STREAM    (   2                   )
    ,.SHIFTD_BW     (   5                   )
    ,.IO_BW         (   BW_CIC              ))
u00_uout_shiftd_rnd 
(
     .i_clk         (   i_clk               )
    ,.i_in_en       (   |r_deci_filt_r_en   )
    ,.i_in          (   r_deci_filt_r_iq    )
    ,.i_shiftd      (   r_cic_out_atten     )
    ,.o_out_en      (   w_deci_filt_r_en    )
    ,.o_out         (   w_deci_filt_r_iq    )
);

ylib_sat #(
     .NUM_STREAM    (   2                   )
    ,.DI_BW         (   BW_CIC              )
    ,.DO_BW         (   DO_BW               ))
u01_uout_sat
(
     .i_clk         (   i_clk               )
    ,.i_in_en       (   w_deci_filt_r_en    )
    ,.i_in          (   w_deci_filt_r_iq    )
    ,.o_out_en      (   w_sat_r_en          )
    ,.o_out         (   o_rout_iq           )
);

// output vld
reg [NUM_ANT  -1:0] r_out_cnt;

always @(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_out_cnt           <= {NUM_ANT{1'b0}};
    end
    else if(w_deci_filt_r_en) begin
        r_out_cnt           <= (r_out_cnt == {NUM_ANT{1'b0}}) ? {{NUM_ANT-1{1'b0}},1'b1} : r_out_cnt << 1;
    end
    else begin
        r_out_cnt           <= {NUM_ANT{1'b0}};
    end
end

assign  o_rout_en = r_out_cnt;

// frame sync

reg [10  -1:0] r_cic_filt_dly; // 8 (i_path_ratio) * 12 (deci) * 4 (stage) + 8 (1st) + 6 (ff) -1  -- 20M BW

always @(posedge i_clk) begin
    if(r_frame_sync_dly2) begin
        r_cic_filt_dly  <= 10'd10; // -- TC 177 : 398
    end
end

reg     [1  -1:0] r_shr_en  ;
reg     [10 -1:0] r_shr     ;

always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr_en <=  1'd1   ;
        o_frame_sync    <= 1'b0;
    end 
    else if(r_shr==r_cic_filt_dly-1) begin
        r_shr_en <=  1'd0   ;
        o_frame_sync <= 1'b1;
    end
    else begin
        o_frame_sync <= 1'b0;
    end
end
always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr <=  10'd0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  r_shr+10'd1    ;
    end 
end

endmodule
