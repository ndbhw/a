// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : rafe_oran_param_if 
//  Author       : ty321.kim@samsung.com
//  Description  : oran parameter interface for RAFE
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | taeyeong      | Initial Release
//  ------------------------------------------------------------------------------------ 
//
////////////////////////////////////////////////////////////////////////////////////////

module rafe_oran_param_if
(
    //--- clk
        input   wire                                i_clk        
    ,   input   wire                                i_rin_frame_sync

    //--- from cpu_if
    ,   input   wire    [ 8     -1:0]               i_m_frm_str             // [3:0]:PUSCH SCS,[7:4]:PUSCH FFT Size       
    ,   input   wire    [ 1     -1:0]               i_freq_shift_7p5k
    ,   input   wire    [16     -1:0]               i_rach_freq_shift
    ,   input   wire    [ 1     -1:0]               i_rach_freq_shift_sel
    ,   input   wire    [16     -1:0]               i_adv_offset

    ,   input   wire    [ 1     -1:0]               i_par_debug_mode     
    ,   input   wire    [ 4     -1:0]               i_par_filter_idx     
    ,   input   wire    [16     -1:0]               i_par_time_offset    
    ,   input   wire    [ 8     -1:0]               i_par_frame_struct      
    ,   input   wire    [16     -1:0]               i_par_cp_length      
    ,   input   wire    [ 4     -1:0]               i_par_num_psymbol     
    ,   input   wire    [24     -1:0]               i_par_freq_offset    
    ,   input   wire    [ 3     -1:0]               i_par_num_ro    
    ,   input   wire    [ 8     -1:0]               i_par_num_prbc    
    ,   input   wire    [10     -1:0]               i_rin_start_prbc        // nuber of c-plane type3

    //--- from qm_top
    ,   input   wire    [ 1     -1:0]               i_rin_en                // enable
    ,   input   wire    [ 4     -1:0]               i_rin_filter_idx        // 1, 3                                    oRAN                                 
    ,   input   wire    [16     -1:0]               i_rin_time_offset       // 0 ~ 30720 : 1ms                         oRAN                                 
    ,   input   wire    [ 8     -1:0]               i_rin_frame_struct      // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,   input   wire    [16     -1:0]               i_rin_cp_length         //                                         oRAN                                 
    ,   input   wire    [ 4     -1:0]               i_rin_num_psymbol       //                                         oRAN                                  
    ,   input   wire    [24     -1:0]               i_rin_freq_offset       //                                         oRAN                                 
    ,   input   wire    [ 3     -1:0]               i_rin_num_ro            // nuber of c-plane type3
    ,   input   wire    [ 8     -1:0]               i_rin_num_prbc          // nuber of c-plane type3

    //--- to RAFE core
    ,   output  wire    [ 1     -1:0]               o_rafe_en
    ,   output  wire    [ 8     -1:0]               o_path_ratio            // operation clock/sampling rate

    ,   output  wire    [16     -1:0]               o_rach_freq_shift
    ,   output  wire    [ 7     -1:0]               o_deci_ratio           // PRACH SCS 60kHz : 4, 120kHz : 2
    ,   output  wire    [ 2     -1:0]               o_over_ratio
    ,   output  wire    [ 5     -1:0]               o_cic_out_atten   
    ,   output  wire    [ 1     -1:0]               o_rach_n_fft
    ,   output  wire    [ 2     -1:0]               o_rascsi                //  0:15kHz,1:30kHz,2:60kHz,3:120kHz
    ,   output  wire    [ 4     -1:0]               o_num_psym              // =i_num_symbol
    ,   output  wire    [14     -1:0]               o_ro_offset             //  R*(i_time_offset + i_cp_length) 
    ,   output  wire    [ 2     -1:0]               o_cic_offset            // 1 fixed
    ,   output  reg     [12     -1:0]               o_num_re

    ,   output  wire    [ 1     -1:0]               o_sub_rst

    ,   output  reg     [ 1     -1:0]               o_f0_case0              // 1: f0 case0, 0: else
    ,   output  reg     [ 8     -1:0]               o_al_kbar
    ,   output  wire    [ 1     -1:0]               o_ce
    ,   output  wire    [ 1     -1:0]               o_ce_trig
    ,   output  wire    [ 1     -1:0]               o_rec_trig

    //--- Read oRAN parameter
    ,   output  wire    [ 4     -1:0]               o_rin_filter_idx        
    ,   output  wire    [16     -1:0]               o_rin_time_offset       
    ,   output  wire    [ 8     -1:0]               o_rin_frame_struct      
    ,   output  wire    [16     -1:0]               o_rin_cp_length         
    ,   output  wire    [ 4     -1:0]               o_rin_num_psymbol       
    ,   output  wire    [24     -1:0]               o_rin_freq_offset       
    ,   output  wire    [ 3     -1:0]               o_rin_num_ro 
    ,   output  wire    [ 8     -1:0]               o_rin_num_prbc 
    ,   output  wire    [10     -1:0]               o_rin_start_prbc 
    ,   output  wire    [32     -1:0]               o_rin_rec_oran          // slot [15:8], symbol[3:0]    

);

// local param
 
localparam  SUBP5 = 21'd0122847 ; // 20'd122880 -1 -32 + 1symb     122847 / 127231
localparam  SUB1  = 21'd0245727 ; // 20'd245760 -1 -32 
localparam  SUB1P5= 21'd0368607 ;
localparam  SUB1P7= 21'd0417791 ;
localparam  SUB2  = 21'd0491487 ; // 20'd491520 -1 -32
localparam  SUB3  = 21'd0581459 ; // 21'd0737247 ; // 20'd737280 -1 -32
localparam  SUB4  = 21'd0983007 ; // 20'd983040 -1 -32
localparam  SUB5  = 21'd1228767 - 21'd122880; // 21'd122880 -1 -32
localparam  RSTD  = 15'd17536  ;

// signal
reg     [ 8     -1:0]               r_m_frm_str       ;
reg     [ 1     -1:0]               r_freq_shift_7p5k ;
reg     [ 4     -1:0]               r_pu_scs_idx      ;
reg     [ 4     -1:0]               r_pu_fft_idx      ;

reg     [ 4     -1:0]               r_rin_filter_idx  ;
reg     [16     -1:0]               r_rin_time_offset ;
reg     [16     -1:0]               r_rin_time_offset_t;
reg     [ 8     -1:0]               r_rin_frame_struct;


reg     [ 8     -1:0]               r_path_ratio      ;  

reg     [16     -1:0]               r_rach_freq_shift ;
reg     [24     -1:0]               r_shift_freq_tmp  ;
reg     [10     -1:0]               r_beta            ;
reg     [ 4     -1:0]               r_pu_stat         ;
reg     [22     -1:0]               r_shift_freq      ;
reg     [ 5     -1:0]               r_offst_b         ;
reg     [16     -1:0]               r_fs_tmp0         ;
reg     [16     -1:0]               r_fs_tmp1         ;

reg     [ 2     -1:0]               r_ra_scs_idx      ;

reg     [16     -1:0]               r_rin_cp_length   ;
reg     [ 4     -1:0]               r_rin_num_psymbol ;
reg     [24     -1:0]               r_rin_freq_offset ;
reg     [ 3     -1:0]               r_rin_num_ro      ;
reg     [ 8     -1:0]               r_rin_num_prbc    ;
reg     [10     -1:0]               r_rin_start_prbc  ;

reg     [ 7     -1:0]               r_deci_ratio      ;
reg     [ 2     -1:0]               r_over_ratio      ;
reg     [ 5     -1:0]               r_cic_out_atten   ;
reg     [ 1     -1:0]               r_rach_n_fft      ;

reg     [14     -1:0]               r_ro_offset       ;
reg     [16     -1:0]               r_ro_offs_tmp_sum ;
reg     [27     -1:0]               r_ro_offs_tmp_comp;
//reg     [10     -1:0]               r_ro_offs_coef    ;
reg     [12     -1:0]               r_ro_offs_coef    ;
reg     [ 2     -1:0]               r_cic_offset      ;
reg     [ 1     -1:0]               r_cic_offs_idx    ;

reg  r_sub_rst ; 

// input enable ctrl

// 245760 x1 x2 x4
wire                                w_sub_sync      ;
wire                                w_sym_sync      ;
reg                                 r_rafe_en       = 0 ;
reg     [21     -1:0]               r_en_cnt        = 0 ;
reg                                 r_hold          = 0 ;
reg     [21     -1:0]               r_en_len        ;
wire    [ 8     -1:0]               w_slot_num      ;
wire    [ 4     -1:0]               w_symb_num      ;
reg     [ 1     -1:0]               r_ce            = 0 ;

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
//    ,.i_mu                  ( 3'd0                  )  
    ,.i_mu                  ( i_m_frm_str[3:0]      )  
    ,.i_retard              ( 22'd4                 )  
    ,.i_frame_sync          ( i_rin_frame_sync      )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         (  w_sub_sync           )   
    ,.o_slot_sync           (                       )   
    ,.o_symbol_sync         (  w_sym_sync           )          
    ,.o_subfrm              (                       )
    ,.o_slot                (  w_slot_num           )          
    ,.o_symbol              (  w_symb_num           )          
);

always @(posedge i_clk) begin
    if (i_par_debug_mode) begin
        r_rin_filter_idx    <=  i_par_filter_idx    ;
        r_rin_time_offset   <=  i_par_time_offset   ;
        r_rin_time_offset_t <=  i_par_time_offset - i_adv_offset;
        r_rin_frame_struct  <=  i_par_frame_struct  ;
        r_rin_cp_length     <=  i_par_cp_length     ;
        r_rin_num_psymbol   <=  i_par_num_psymbol   ;
        r_rin_freq_offset   <=  i_par_freq_offset   ;
        r_rin_num_ro        <=  i_par_num_ro        ;
        r_rin_num_prbc      <=  i_par_num_prbc      ;
        r_rin_start_prbc    <=  0;
    end
    else if(w_sym_sync & (i_rin_filter_idx[0])) begin
        r_rin_filter_idx    <=  i_rin_filter_idx    ;
        r_rin_time_offset   <=  i_rin_time_offset   ;
        r_rin_time_offset_t <=  i_rin_time_offset - i_adv_offset;
        r_rin_frame_struct  <=  i_rin_frame_struct  ;
        r_rin_cp_length     <=  i_rin_cp_length     ;
        r_rin_num_psymbol   <=  i_rin_num_psymbol   ;
        r_rin_freq_offset   <=  i_rin_freq_offset + {i_rin_start_prbc, 3'b000} + {i_rin_start_prbc, 4'b0000};
        r_rin_num_ro        <=  i_rin_num_ro        ;
        r_rin_num_prbc      <=  i_rin_num_prbc      ;
        r_rin_start_prbc    <=  i_rin_start_prbc    ;
    end
end

// oRAN param input timing

reg                 r_filter_idx    ;
wire                r_rec_trig      ;
reg  [32    -1: 0]  r_rin_rec_oran  ;

always @(posedge i_clk) begin
    r_filter_idx    <= i_rin_filter_idx[0];
end

assign r_rec_trig = i_rin_filter_idx[0] & (~r_filter_idx );

always @(posedge i_clk) begin
    if(r_rec_trig) begin
        r_rin_rec_oran  <= {1'b0,i_m_frm_str[2:0],8'b0,w_slot_num,4'b0,w_symb_num};
    end
end

assign o_rin_rec_oran = r_rin_rec_oran;
assign o_rec_trig     = r_rec_trig;

// ce trig

reg         r_ce_trig;

always @(posedge i_clk) begin
    if((w_sym_sync) & (i_rin_filter_idx == 4'h1) & (i_rin_num_psymbol==4'h5) & (~r_hold)) begin
        r_ce_trig   <= w_sym_sync;
    end
    else begin
        r_ce_trig   <= 1'b0;
    end
end

ylib_pshift #(
    .BW_SHIFT   (9))
u03_ylib_pshift(
     .i_clk     (i_clk          )
    ,.i_shift   (9'd400         )
    ,.i_in      (r_ce_trig      )
    ,.o_out     (o_ce_trig      )
);

//assign  o_ce_tirg   =   r_ce_trig;


//enable ctrl

always @(posedge i_clk) begin
    if(w_sym_sync) begin
        if((i_rin_filter_idx == 4'h1) & (i_rin_num_psymbol==4'h1)) begin
//            r_en_len        <= SUB1P5;
            r_en_len        <= SUB1P7;
            r_ce            <=   1'b0;
        end
        else if((i_rin_filter_idx == 4'h1) & (i_rin_num_psymbol==4'h2)) begin
            r_en_len        <= SUB3;
            r_ce            <=   1'b0;            
        end
        else if((i_rin_filter_idx == 4'h1) & (i_rin_num_psymbol==4'h4)) begin
            r_en_len        <= SUB4;
            r_ce            <=   1'b0;            
        end
        else if((i_rin_filter_idx == 4'h1) & (i_rin_num_psymbol==4'h5)) begin
            r_en_len        <= SUB5;
            r_ce            <=   1'b1;            
        end
        //else if((i_rin_filter_idx == 4'h3) & (i_m_frm_str[2:0]==3'b001)) begin
        else if((i_rin_filter_idx == 4'h3) & (i_rin_frame_struct[2:0]==3'b000)) begin
            r_en_len        <= SUB1;
            r_ce            <=   1'b0;            
        end
        else if((i_rin_filter_idx == 4'h3) & (i_rin_frame_struct[2:0]==3'b001)) begin
            r_en_len        <= SUBP5;
            r_ce            <=   1'b0;            
        end
        else if (i_rin_filter_idx == 4'h5) begin
            r_en_len        <= SUB1;
            r_ce            <= 1'b0;
        end        
    end
end

assign o_ce = r_ce;

always @(posedge i_clk) begin
    //if(i_rin_frame_sync) begin
    if(r_sub_rst) begin
        r_rafe_en           <=  1'b0                ;
    end
    else if(w_sym_sync & (|i_rin_filter_idx[1:0]) & (~r_hold)) begin
        r_rafe_en           <=  i_rin_en            ;
    end
    else if(r_en_cnt== r_en_len) begin
        r_rafe_en           <=  1'b0                ;
    end
end
    

always @(posedge i_clk) begin
    //if(i_rin_frame_sync) begin
    if(r_sub_rst) begin        
        r_en_cnt        <=  21'b0;
        r_hold          <=   1'b0;
    end
    else if(r_en_cnt == r_en_len) begin
        r_en_cnt        <=  21'b0;
        r_hold          <=   1'b0;
    end
    else if(r_rafe_en) begin
        r_en_cnt        <=  r_en_cnt + 21'b1;
        r_hold          <=              1'b1;
    end
end

// o_rafe_en

assign o_rafe_en = r_rafe_en;

// // input reg
// always @(posedge i_clk) begin
//     if (i_par_debug_mode) begin
//         r_rin_filter_idx    <=  i_par_filter_idx    ;
//         r_rin_time_offset   <=  i_par_time_offset   ;
//         r_rin_frame_struct  <=  i_par_frame_struct  ;
//         r_rin_cp_length     <=  i_par_cp_length     ;
//         r_rin_num_psymbol   <=  i_par_num_psymbol   ;
//         r_rin_freq_offset   <=  i_par_freq_offset   ;
//         r_rin_num_ro        <=  i_par_num_ro        ;
//     end
//     else if (i_rin_en) begin
//         r_rin_filter_idx    <=  i_rin_filter_idx    ;
//         r_rin_time_offset   <=  i_rin_time_offset   ;
//         r_rin_frame_struct  <=  i_rin_frame_struct  ;
//         r_rin_cp_length     <=  i_rin_cp_length     ;
//         r_rin_num_psymbol   <=  i_rin_num_psymbol   ;
//         r_rin_freq_offset   <=  i_rin_freq_offset   ;
//         r_rin_num_ro        <=  i_rin_num_ro        ;
//     end
// end

always @(posedge i_clk) begin
        r_m_frm_str[3:0]    <=  {2'b0,i_m_frm_str[1:0]}         ; // SCS
        r_m_frm_str[6:4]    <=  {1'b0,i_m_frm_str[5:4]} + 3'b1  ; // FFT
        r_m_frm_str[7]      <=  1'b1                            ; // FFT
        r_freq_shift_7p5k   <=  i_freq_shift_7p5k               ;
end


// operation : sampling ratio

always @(posedge i_clk) begin
    case(r_m_frm_str)
        8'h90   : r_path_ratio    <= 8'd32;
        8'hA0   : r_path_ratio    <= 8'd16;
        8'hB0   : r_path_ratio    <= 8'd 8;
        8'h91   : r_path_ratio    <= 8'd16;
        8'hA1   : r_path_ratio    <= 8'd 8;
        8'hB1   : r_path_ratio    <= 8'd 4;
        8'hC1   : r_path_ratio    <= 8'd 2;
        8'h92   : r_path_ratio    <= 8'd 8;
        8'hA2   : r_path_ratio    <= 8'd 4;
        8'hB2   : r_path_ratio    <= 8'd 2;
        default : r_path_ratio    <= 8'd 8;
    endcase
end

assign o_path_ratio = r_path_ratio;

// o_rach_freq_shift
// reg     [24     -1:0]               rr_shift_freq_tmp  ;
// 
// always @(posedge i_clk) begin
//     case(r_rin_frame_struct[3:0])   // 2 dly
//         // 4'hC    : r_shift_freq_tmp <= $signed(r_rin_freq_offset) / 12 ;
//         4'hE    : rr_shift_freq_tmp <= $signed(r_rin_freq_offset) /  3 ;
//         4'h0    : rr_shift_freq_tmp <= $signed(r_rin_freq_offset) << 0 ;
//         4'h1    : rr_shift_freq_tmp <= $signed(r_rin_freq_offset) << 1 ;
//         4'h2    : rr_shift_freq_tmp <= $signed(r_rin_freq_offset) << 2 ;
//         default : rr_shift_freq_tmp <= $signed(r_rin_freq_offset) / 12 ;
//     endcase
// end
 
reg     [41     -1:0]               r_shift_freq_mult  ;

always @(posedge i_clk) begin
    r_shift_freq_mult <=    $signed(r_rin_freq_offset) * $signed(17'd43691)        ;
end

always @(posedge i_clk) begin
    case(r_rin_frame_struct[3:0])   // 2 dly
        4'hE    : r_shift_freq_tmp <= {23'b0,r_shift_freq_mult[38]} + $signed(r_shift_freq_mult[40:17]);
        4'h0    : r_shift_freq_tmp <= r_rin_freq_offset       ;
        4'h1    : r_shift_freq_tmp <= r_rin_freq_offset  << 1 ;
        4'h2    : r_shift_freq_tmp <= r_rin_freq_offset  << 2 ;
        default : r_shift_freq_tmp <= {23'b0,r_shift_freq_mult[40]} + $signed({r_shift_freq_mult[40],r_shift_freq_mult[40],r_shift_freq_mult[40:19]});
    endcase
end

// always @(posedge i_clk) begin       // 2 dly
//     case(r_rin_frame_struct[3:0])
//     //    4'hC    : r_beta <= 72;
//         4'hE    : r_beta <=288;
//         4'h0    : r_beta <=144;
//         4'h1    : r_beta <=288;
//         4'h2    : r_beta <=576;
//         default : r_beta <= 72;
//     endcase
// end

always @(posedge i_clk) begin       // 2 dly
    case(r_rin_frame_struct[3:0])
    //    4'hC    : r_beta <= 72;
        4'hC    : r_beta <= (i_m_frm_str[0]) ? 70 : 71 ;
        4'hE    : r_beta <= 288;
        4'h0    : r_beta <= 144;
        4'h1    : r_beta <= 288;
        4'h2    : r_beta <= 576;
        default : r_beta <=  71;
    endcase
end

always @(posedge i_clk) begin       // 2 dly , default 1
    r_pu_stat <= r_m_frm_str[7:4] + r_m_frm_str[3:0] + 4'd7;
end

always @(posedge i_clk) begin
    if ((r_rin_filter_idx == 4'd1) && (r_rin_frame_struct[3:0] == 4'd2)) begin
        r_offst_b   <= 5'd20;
    end
    else begin
        r_offst_b   <= 5'd0 ;
    end
end

always @(posedge i_clk) begin       // 3 dly
//    r_shift_freq <= $signed(r_shift_freq_tmp) + r_beta + r_freq_shift_7p5k + r_offst_b;
    r_shift_freq <= $signed(r_shift_freq_tmp) + r_beta;
end


always @(posedge i_clk) begin       // 4 dly
    case(r_pu_stat)
        4'b0000 : begin r_fs_tmp0 <= ({{ 6{1'b0}},r_shift_freq[ 9:0]}<<5) ; r_fs_tmp1 <= ({{ 6{1'b0}},r_shift_freq[ 9:0]}<<4) ; end 
        4'b0001 : begin r_fs_tmp0 <= ({{ 5{1'b0}},r_shift_freq[10:0]}<<4) ; r_fs_tmp1 <= ({{ 5{1'b0}},r_shift_freq[10:0]}<<3) ; end 
        4'b0010 : begin r_fs_tmp0 <= ({{ 4{1'b0}},r_shift_freq[11:0]}<<3) ; r_fs_tmp1 <= ({{ 4{1'b0}},r_shift_freq[11:0]}<<2) ; end 
        4'b0011 : begin r_fs_tmp0 <= ({{ 3{1'b0}},r_shift_freq[12:0]}<<2) ; r_fs_tmp1 <= ({{ 3{1'b0}},r_shift_freq[12:0]}<<1) ; end 
        4'b0100 : begin r_fs_tmp0 <= ({{ 2{1'b0}},r_shift_freq[13:0]}<<1) ; r_fs_tmp1 <= ({{ 2{1'b0}},r_shift_freq[13:0]}   ) ; end 
        default : begin r_fs_tmp0 <= ({{ 5{1'b0}},r_shift_freq[10:0]}<<2) ; r_fs_tmp1 <= ({{ 5{1'b0}},r_shift_freq[10:0]}<<1) ; end 
    endcase
end

always @(posedge i_clk) begin       // 5 dly
    if(i_rach_freq_shift_sel) begin
        r_rach_freq_shift   <= i_rach_freq_shift    ;        
    end
    else begin
        r_rach_freq_shift   <= r_fs_tmp0 + r_fs_tmp1;
    end
end

assign o_rach_freq_shift = r_rach_freq_shift;


// o_deci_ratio     

always @(posedge i_clk) begin
    case({r_rin_frame_struct[3:0],r_m_frm_str})
//        12'hC90 : r_deci_ratio <= 6'd3 ;  // PRACH SCS 1.25 kHz
//        12'hC81 : r_deci_ratio <= 6'd3 ;
//        12'hCA0 : r_deci_ratio <= 6'd6 ;
//        12'hC91 : r_deci_ratio <= 6'd6 ;
//        12'hC82 : r_deci_ratio <= 6'd6 ;
//        12'hCB0 : r_deci_ratio <= 6'd12;
//        12'hCA1 : r_deci_ratio <= 6'd12;
//        12'hC92 : r_deci_ratio <= 6'd12;
//        12'hCB1 : r_deci_ratio <= 6'd24;
//        12'hCA2 : r_deci_ratio <= 6'd24;
//        12'hCC1 : r_deci_ratio <= 6'd48;
//        12'hCB2 : r_deci_ratio <= 6'd48;

        12'hC90 : r_deci_ratio <= 7'd6 ;  // PRACH SCS 1.25 kHz 1024 fft
        12'hC81 : r_deci_ratio <= 7'd6 ;
        12'hCA0 : r_deci_ratio <= 7'd12;
        12'hC91 : r_deci_ratio <= 7'd12;
        12'hC82 : r_deci_ratio <= 7'd12;
        12'hCB0 : r_deci_ratio <= 7'd24;
        12'hCA1 : r_deci_ratio <= 7'd24;
        12'hC92 : r_deci_ratio <= 7'd24;
        12'hCB1 : r_deci_ratio <= 7'd48;
        12'hCA2 : r_deci_ratio <= 7'd48;
        12'hCC1 : r_deci_ratio <= 7'd96;
        12'hCB2 : r_deci_ratio <= 7'd96;

//        12'hE90 : r_deci_ratio <= 6'd3 ;  // PRACH SCS 5 kHz
//        12'hE81 : r_deci_ratio <= 6'd3 ;
//        12'hEA0 : r_deci_ratio <= 6'd3 ;
//        12'hE91 : r_deci_ratio <= 6'd3 ;
//        12'hE82 : r_deci_ratio <= 6'd3 ;
//        12'hEB0 : r_deci_ratio <= 6'd3 ;
//        12'hEA1 : r_deci_ratio <= 6'd3 ;
//        12'hE92 : r_deci_ratio <= 6'd3 ;
//        12'hEB1 : r_deci_ratio <= 6'd6 ;
//        12'hEA2 : r_deci_ratio <= 6'd6 ;
//        12'hEC1 : r_deci_ratio <= 6'd12;
//        12'hEB2 : r_deci_ratio <= 6'd12;

        12'h090 : r_deci_ratio <= 7'd1 ;  // PRACH SCS 15 kHz
        12'h081 : r_deci_ratio <= 7'd1 ;
        12'h0A0 : r_deci_ratio <= 7'd2 ;
        12'h091 : r_deci_ratio <= 7'd2 ;
        12'h082 : r_deci_ratio <= 7'd2 ;
        12'h0B0 : r_deci_ratio <= 7'd4 ;
        12'h0A1 : r_deci_ratio <= 7'd4 ;
        12'h092 : r_deci_ratio <= 7'd4 ;
        12'h0B1 : r_deci_ratio <= 7'd8 ;
        12'h0A2 : r_deci_ratio <= 7'd8 ;
        12'h0C1 : r_deci_ratio <= 7'd16;
        12'h0B2 : r_deci_ratio <= 7'd16;

        12'h190 : r_deci_ratio <= 7'd1 ;  // PRACH SCS 30 kHz
        12'h181 : r_deci_ratio <= 7'd1 ;
        12'h1A0 : r_deci_ratio <= 7'd1 ;
        12'h191 : r_deci_ratio <= 7'd1 ;
        12'h182 : r_deci_ratio <= 7'd1 ;
        12'h1B0 : r_deci_ratio <= 7'd2 ;
        12'h1A1 : r_deci_ratio <= 7'd2 ;
        12'h192 : r_deci_ratio <= 7'd2 ;
        12'h1B1 : r_deci_ratio <= 7'd4 ;
        12'h1A2 : r_deci_ratio <= 7'd4 ;
        12'h1C1 : r_deci_ratio <= 7'd8 ;
        12'h1B2 : r_deci_ratio <= 7'd8 ;

//        12'h2B0 : r_deci_ratio <= 6'd1 ;  // PRACH SCS 60 kHz
//        12'h2A1 : r_deci_ratio <= 6'd1 ;
//        12'h292 : r_deci_ratio <= 6'd1 ;
//        12'h2B1 : r_deci_ratio <= 6'd2 ;
//        12'h2A2 : r_deci_ratio <= 6'd2 ;
//        12'h2C1 : r_deci_ratio <= 6'd4 ;
//        12'h2B2 : r_deci_ratio <= 6'd4 ;

        default : r_deci_ratio <= 7'd1 ;
    endcase
end

assign  o_deci_ratio   =  r_deci_ratio ;




// o_over_ratio     

always @(posedge i_clk) begin
    case({r_rin_frame_struct[3:0],r_m_frm_str})
        // 12'hE90 : r_over_ratio <= 2'd2 ;  // PRACH SCS 5 kHz
        // 12'hE81 : r_over_ratio <= 2'd2 ;
        // 
        // 12'hEA0 : r_over_ratio <= 2'd1 ;
        // 12'hE91 : r_over_ratio <= 2'd1 ;
        // 12'hE82 : r_over_ratio <= 2'd1 ;
        
        12'h190 : r_over_ratio <= 2'd0 ;  // PRACH SCS 30 kHz

        default : r_over_ratio <= 2'd0 ;
    endcase
end

assign  o_over_ratio    = r_over_ratio ;


// o_cic_out_atten

always @(posedge i_clk) begin
    case ({r_rach_n_fft,r_deci_ratio,r_over_ratio}) 
        10'b0_0000001_00 : r_cic_out_atten   <= 5'd 0;
        10'b0_0000001_01 : r_cic_out_atten   <= 5'd 0;
        10'b0_0000010_00 : r_cic_out_atten   <= 5'd 3;

        10'b1_0000100_00 : r_cic_out_atten   <= 5'd 9;        

        10'b1_0000110_10 : r_cic_out_atten   <= 5'd10;
        10'b1_0000110_00 : r_cic_out_atten   <= 5'd11;
        10'b1_0000110_01 : r_cic_out_atten   <= 5'd11;

        10'b0_0000100_00 : r_cic_out_atten   <= 5'd 8;

        10'b1_0001100_00 : r_cic_out_atten   <= 5'd16;

        10'b0_0001000_00 : r_cic_out_atten   <= 5'd12;

        10'b1_0011000_00 : r_cic_out_atten   <= 5'd20;

        10'b0_0010000_00 : r_cic_out_atten   <= 5'd17;

        10'b1_0110000_00 : r_cic_out_atten   <= 5'd25;

        10'b1_1100000_00 : r_cic_out_atten   <= 5'd29;        

        default        : r_cic_out_atten   <= 5'd 20;
    endcase
end

assign o_cic_out_atten  = r_cic_out_atten ;

// o_rach_n_fft

always @(posedge i_clk) begin
    case(r_rin_frame_struct [7:4])
        4'd 8   : r_rach_n_fft    <= 0;
        4'd 9   : r_rach_n_fft    <= 0;
        4'd10   : r_rach_n_fft    <= 1;
        4'd11   : r_rach_n_fft    <= 1;
        default : r_rach_n_fft    <= 1; 
    endcase
end

assign  o_rach_n_fft    = r_rach_n_fft; 

// o_rach_scs

always @(posedge i_clk) begin
    r_ra_scs_idx    <= r_rin_frame_struct [1:0];
end

assign o_rascsi = r_ra_scs_idx;

// o_num_psym

assign  o_num_psym      = r_rin_num_psymbol;

// o_slot_offset    -- CPU


// o_ro_offset [14  -1:0]

always @(posedge i_clk) begin
    r_ro_offs_tmp_sum   <= r_rin_time_offset_t + r_rin_cp_length;
end

always @(posedge i_clk) begin
    if({r_rin_frame_struct[3:2],r_rin_frame_struct[0]} == 3'b110) begin
//        r_ro_offs_coef      <= 10'd683;
        r_ro_offs_coef      <= 12'd2731;

    end
    else begin
        r_ro_offs_coef      <= 12'd1;
    end
end

always @(posedge i_clk) begin
        r_ro_offs_tmp_comp <= {11'b0,r_ro_offs_tmp_sum} * {15'b0,r_ro_offs_coef}  ;
end

always @(posedge i_clk) begin
    case(r_rin_frame_struct[3:0] )
//        4'hC    : r_ro_offset <= {2'b0,r_ro_offs_tmp_comp[24:13]} ;       // 1/12
//        4'hC    : r_ro_offset <= {2'b0,r_ro_offs_tmp_comp[26:15]} ;       // 1/12
        4'hC    : r_ro_offset <= {3'b0,r_ro_offs_tmp_comp[26:16]} ;       // 1/12   - 1024fft
        4'hD    : r_ro_offset <=       r_ro_offs_tmp_comp[17: 4]  ;       // 0.06125 
//        4'hE    : r_ro_offset <= {4'b0,r_ro_offs_tmp_comp[24:15]} ;       // 1/12
        4'hE    : r_ro_offset <= {4'b0,r_ro_offs_tmp_comp[26:17]} ;       // 1/12
        4'hF    : r_ro_offset <=       r_ro_offs_tmp_comp[16: 3]  ;       // 0.125 
        4'h0    : r_ro_offset <=       r_ro_offs_tmp_comp[15: 2]  ;       // 0.25 
        4'h1    : r_ro_offset <=       r_ro_offs_tmp_comp[14: 1]  ;       // 0.5
        4'h2    : r_ro_offset <=       r_ro_offs_tmp_comp[13: 0]  ;       // 1
        default : r_ro_offset <=       r_ro_offs_tmp_comp[23:10]  ;
    endcase
end

assign  o_ro_offset = r_ro_offset;


// o_cic_offset


always @(posedge i_clk) begin
    if((r_rin_filter_idx == 4'b0001) && (r_rin_num_psymbol == 4'b0100)) begin
        r_cic_offs_idx <= 1'b1;
    end
    else begin
        r_cic_offs_idx <= 1'b0;
    end
end

always @(posedge i_clk) begin
    case({r_cic_offs_idx,r_deci_ratio[5:0]})
        8'b1000_0001 : r_cic_offset <= 0 ;
        8'b1000_0010 : r_cic_offset <= 1 ;
        8'b1000_0011 : r_cic_offset <= 2 ;
        8'b1000_0100 : r_cic_offset <= 2 ;
        8'b1000_0110 : r_cic_offset <= 2 ;
        8'b1000_1000 : r_cic_offset <= 2 ;
        8'b1000_1100 : r_cic_offset <= 2 ;
        8'b1001_0000 : r_cic_offset <= 3 ;
        8'b1001_1000 : r_cic_offset <= 3 ;
        8'b1011_0000 : r_cic_offset <= 3 ;
        8'b1110_0000 : r_cic_offset <= 3 ;

        8'b0000_0001 : r_cic_offset <= 0 ;
        8'b0000_0010 : r_cic_offset <= 1 ;
        8'b0000_0011 : r_cic_offset <= 1 ;
        8'b0000_0100 : r_cic_offset <= 1 ;
        8'b0000_0110 : r_cic_offset <= 2 ;
        8'b0000_1000 : r_cic_offset <= 2 ;
        8'b0000_1100 : r_cic_offset <= 2 ;
        8'b0001_0000 : r_cic_offset <= 2 ;
        8'b0001_1000 : r_cic_offset <= 2 ;
        8'b0011_0000 : r_cic_offset <= 2 ;
        8'b0110_0000 : r_cic_offset <= 2 ;
        default   : r_cic_offset <= 2 ;
    endcase
end

assign o_cic_offset = r_cic_offset;

// o_tagc_on        -- CPU    

// o_target_bo      -- CPU

// o_num_re
always @(posedge i_clk) begin
    o_num_re    <= {1'b0,r_rin_num_prbc,3'b0} + {2'b0,r_rin_num_prbc,2'b0};
end
 
// o_f0_case0
always @(posedge i_clk) begin
    if((r_rin_filter_idx == 4'b1) & (r_rin_num_psymbol == 4'b1) & (r_rin_time_offset == 16'b0)) begin 
        o_f0_case0  <= 1'b1;
    end
    else begin
        o_f0_case0  <= 1'b0;
    end
end

// o_al_kbar

always @(posedge i_clk) begin
    if((r_rin_frame_struct[3:0] == 4'hC) & (r_m_frm_str[3:0] == 4'h0)) begin
        o_al_kbar   <= 8'd6 ;
    end
    else if((r_rin_frame_struct[3:0] == 4'hC) & (r_m_frm_str[3:0] == 4'h1)) begin
        o_al_kbar   <= 8'd0 ;
    end
    else begin
        o_al_kbar   <= 8'd2 ;
    end
end


// oRAN param read
assign o_rin_filter_idx       = r_rin_filter_idx          ; 
assign o_rin_time_offset      = r_ro_offs_tmp_sum         ; 
assign o_rin_frame_struct     = r_rin_frame_struct        ; 
assign o_rin_cp_length        = r_rin_cp_length           ; 
assign o_rin_num_psymbol      = r_rin_num_psymbol         ; 
assign o_rin_freq_offset      = r_rin_freq_offset         ; 
assign o_rin_num_ro           = r_rin_num_ro              ; 
assign o_rin_num_prbc         = r_rin_num_prbc            ; 
assign o_rin_start_prbc       = r_rin_start_prbc          ; 

// rafe core reset each subframe

reg  rr_rafe_en;
//reg  r_sub_rst ; 
always @(posedge i_clk) begin
    rr_rafe_en  <= r_rafe_en;
end

always @(posedge i_clk) begin
    r_sub_rst   <= ~r_rafe_en & rr_rafe_en;
end

ylib_pshift #(
    .BW_SHIFT   (15))
u02_ylib_pshift(
     .i_clk     (i_clk          )
    ,.i_shift   (RSTD           )
    ,.i_in      (r_sub_rst      )
    ,.o_out     (o_sub_rst      )
);

endmodule                                                             
