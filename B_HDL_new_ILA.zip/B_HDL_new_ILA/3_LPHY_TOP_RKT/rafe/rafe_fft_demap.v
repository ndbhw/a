// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : rafe_fft_demap
//  Author       : jyzoo.lee@samsung.com
//  Description  : prach fft deampper
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.5.20  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.5.26  | jyzoo.lee     | applied double buffer 
//  ------------+---------------+-----------------------------------------------
//   2020.7.16  | taeyeong      | Modifiy for FSU20 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module rafe_fft_demap
#(
    parameter  NUM_CC              =    1 
   ,parameter  NUM_ANT             =    4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16           
   ,parameter  VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from oran
    ,   input   wire    [1      *NUM_CC    -1:0]           i_rach_nfft   
    ,   input   wire    [12     *NUM_CC    -1:0]           i_num_re    
    ,   input   wire    [8      *NUM_CC    -1:0]           i_al_kbar

    //--- from rafe_td_agc_buf
    ,   input   wire    [1      *NUM_CC    -1:0]           i_frame_sync           
    ,   input   wire    [1      *NUM_CC    -1:0]           i_ro_sync    
    ,   input   wire    [1      *NUM_CC    -1:0]           i_rin_en           
    ,   input   wire    [2*DI_BW*NUM_CC    -1:0]           i_rin_iq           

    //--- to rafe_gain_comp
    ,   output  wire    [1      *NUM_CC    -1:0]    o_frame_sync           
    ,   output  reg     [1          -1:0]           o_rout_en
    ,   output  reg     [2*DO_BW    -1:0]           o_rout_iq    
    ,   output  reg     [3          -1:0]           o_rout_cnt
);

//Parameter rafe fft demap local Logic
localparam      BW_FFT_OUT          =       28              ;   
localparam      NFFT_0512           =       12'd512         ;
localparam      NFFT_1024           =       12'd1024        ;
localparam      NFFT_2048           =       12'd2048        ;
localparam      DLY_NFFT_0512       =       22'd512 + 512+15;
localparam      DLY_NFFT_1024       =       22'd1024+1024+15;
localparam      DLY_NFFT_2048       =       22'd2048+2048+15;

localparam      ORAN_FFT0512        =       4'h9            ;
localparam      ORAN_FFT1024        =       4'ha            ;
localparam      ORAN_FFT2048        =       4'hb            ;
localparam      DLY_RST             =       3               ;
localparam      RAFE_FFT_SCALE1     =       8'd181          ;
localparam      NUM_MAX_SC          =       12'd1024        ; 
localparam      EOP_DELAY           =       4'd10           ; 

localparam      STAT2               =       NUM_ANT*2       ;
localparam      STAT3               =       NUM_ANT*3       ;
localparam      STAT4               =       NUM_ANT*4       ;
localparam      CNT_EOP_DELAY       =       8'd200          ;
//Logic Variable
genvar gidx ; 
integer i   ;

// Logic Variable
reg [1      -1:0]   r_ro_sync   ;
reg [1      -1:0]   rr_ro_sync  ;

reg [1      -1:0]   rr_rach_nfft ;

reg [12     -1:0]   r_fft_pts   ;
reg [4      -1:0]   r_fft_scale ;
reg [10     -1:0]   r_n_seq     ;
reg [9      -1:0]   r_scale_a   ;
reg [22     -1:0]   r_fft_dly   ;
reg [4      -1:0]   r_xfft_size ;
reg [10     -1:0]   r_start_addr;
reg [10     -1:0]   r_end_addr  ;

reg [1      -1:0]   r_rach_nfft ;

reg [1      -1:0]   r_rin_en    ;         
reg [2*DI_BW-1:0]   r_rin_iq    ;
reg [8      -1:0]   r_al_kbar = 0;

always @(posedge i_clk) begin
    r_ro_sync   <= |i_ro_sync;
    rr_ro_sync  <= r_ro_sync;
end

generate
    if (NUM_CC == 1)
    begin
        always @ (posedge i_clk)
            rr_rach_nfft <= i_rach_nfft[0];
    end
    if (NUM_CC == 2)
    begin
        always @ (posedge i_clk)
            if (i_ro_sync[0])
            begin
                rr_rach_nfft <= i_rach_nfft[0];
                r_al_kbar    <= i_al_kbar[7:0];
            end
            else if (i_ro_sync[1])
            begin
                rr_rach_nfft <= i_rach_nfft[1];
                r_al_kbar    <= i_al_kbar[15:8];
            end
    end
endgenerate



wire [4     -1:0]   w_frame_sync;
wire [4     -1:0]   w_rach_nfft ;
wire [4     -1:0]   w_ro_sync   ;
wire [4     -1:0]   w_rin_en    ;
wire [32*4  -1:0]   w_rin_iq    ;

assign  w_frame_sync = {{(4-NUM_CC){1'b0}},i_frame_sync} ;
assign  w_rach_nfft  = {{(4-NUM_CC){1'b0}},i_rach_nfft } ;
assign  w_ro_sync    = {{(4-NUM_CC){1'b0}},i_ro_sync   } ;
assign  w_rin_en     = {{(4-NUM_CC){1'b0}},i_rin_en    } ;
assign  w_rin_iq     = {{(4-NUM_CC){32'b0}},i_rin_iq   } ; 

always @(posedge i_clk) begin
    if(w_frame_sync[0]) begin
        if(w_rach_nfft[0]) begin r_fft_dly   <= DLY_NFFT_1024; end
        else               begin r_fft_dly   <= DLY_NFFT_0512; end
    end
    else if(w_frame_sync[1]) begin
        if(w_rach_nfft[1]) begin r_fft_dly   <= DLY_NFFT_1024; end
        else               begin r_fft_dly   <= DLY_NFFT_0512; end
    end
    else if(w_frame_sync[2]) begin
        if(w_rach_nfft[2]) begin r_fft_dly   <= DLY_NFFT_1024; end
        else               begin r_fft_dly   <= DLY_NFFT_0512; end
    end
    else if(w_frame_sync[3]) begin
        if(w_rach_nfft[3]) begin r_fft_dly   <= DLY_NFFT_1024; end
        else               begin r_fft_dly   <= DLY_NFFT_0512; end
    end
end

always @(posedge i_clk) begin
    if(w_ro_sync[0]) begin        
        if(w_rach_nfft[0]) begin
            r_fft_pts   <= NFFT_1024                    ;
            r_fft_scale <= 4'd05                        ; 
            r_n_seq     <= 10'd839                      ;
            r_xfft_size <= ORAN_FFT1024                 ;
        end
        else begin
            r_fft_pts   <= NFFT_0512                    ; 
            r_fft_scale <= 4'd12                        ; 
            r_n_seq     <= 10'd139                      ;
            r_xfft_size <= ORAN_FFT0512                 ;
        end
    end
    else if(w_ro_sync[1]) begin        
        if(w_rach_nfft[1]) begin
            r_fft_pts   <= NFFT_1024                    ;
            r_fft_scale <= 4'd05                        ; 
            r_n_seq     <= 10'd839                      ;
            r_xfft_size <= ORAN_FFT1024                 ;
        end
        else begin
            r_fft_pts   <= NFFT_0512                    ; 
            r_fft_scale <= 4'd12                        ; 
            r_n_seq     <= 10'd139                      ;
            r_xfft_size <= ORAN_FFT0512                 ;
        end
    end
    else if(w_ro_sync[2]) begin        
        if(w_rach_nfft[2]) begin
            r_fft_pts   <= NFFT_1024                    ;
            r_fft_scale <= 4'd05                        ; 
            r_n_seq     <= 10'd839                      ;
            r_xfft_size <= ORAN_FFT1024                 ;
        end
        else begin
            r_fft_pts   <= NFFT_0512                    ; 
            r_fft_scale <= 4'd12                        ; 
            r_n_seq     <= 10'd139                      ;
            r_xfft_size <= ORAN_FFT0512                 ;
        end
    end
    else if(w_ro_sync[3]) begin        
        if(w_rach_nfft[3]) begin
            r_fft_pts   <= NFFT_1024                    ;
            r_fft_scale <= 4'd05                        ; 
            r_n_seq     <= 10'd839                      ;
            r_xfft_size <= ORAN_FFT1024                 ;
        end
        else begin
            r_fft_pts   <= NFFT_0512                    ; 
            r_fft_scale <= 4'd12                        ; 
            r_n_seq     <= 10'd139                      ;
            r_xfft_size <= ORAN_FFT0512                 ;
        end
    end
end

always @(posedge i_clk) begin
    if     (w_ro_sync[0]) begin r_rach_nfft     <= w_rach_nfft[0]      ; end
    else if(w_ro_sync[1]) begin r_rach_nfft     <= w_rach_nfft[1]      ; end
    else if(w_ro_sync[2]) begin r_rach_nfft     <= w_rach_nfft[2]      ; end
    else if(w_ro_sync[3]) begin r_rach_nfft     <= w_rach_nfft[3]      ; end
end

always@(posedge i_clk) begin
    if      (w_rin_en[0]) begin r_rin_iq    <=  w_rin_iq[32*1 -1:32*0]    ; end
    else if (w_rin_en[1]) begin r_rin_iq    <=  w_rin_iq[32*2 -1:32*1]    ; end
    else if (w_rin_en[2]) begin r_rin_iq    <=  w_rin_iq[32*3 -1:32*2]    ; end
    else if (w_rin_en[3]) begin r_rin_iq    <=  w_rin_iq[32*4 -1:32*3]    ; end
end

reg [10 -1:0]   r_cntr_offs;

generate
    if (NUM_CC == 1)
    begin
        always @ (posedge i_clk)
            if (i_ro_sync[0])
                if (i_rach_nfft[0])
                    r_cntr_offs <= 10'd420;
                else
                    r_cntr_offs <= 10'd70;
    end
    if (NUM_CC == 2)
    begin
        always @ (posedge i_clk)
            if (i_ro_sync[0])
                if (i_rach_nfft[0])
                    r_cntr_offs <= 10'd420;
                else
                    r_cntr_offs <= 10'd70;
            else if (i_ro_sync[1])
                if (i_rach_nfft[1])
                    r_cntr_offs <= 10'd420;
                else
                    r_cntr_offs <= 10'd70;
    end
endgenerate

//always @(posedge i_clk) begin
//    if(i_rach_nfft[0]) begin
//        r_cntr_offs <= 10'd420;
//    end
//    else begin
//        r_cntr_offs <= 10'd70;
//    end
//end

always @(posedge i_clk) begin
    if((rr_rach_nfft) & (r_ro_sync)) begin
//        r_start_addr    <= r_fft_pts[10:1] - i_num_re[10:1] + i_al_kbar[7:0];
        r_start_addr    <= r_fft_pts[10:1] - r_cntr_offs - r_al_kbar;   
    end
    else if(r_ro_sync) begin
//        r_start_addr    <= r_fft_pts[11:2] - i_num_re[10:1] + i_al_kbar[7:0];
        r_start_addr    <= r_fft_pts[11:2] - r_cntr_offs - r_al_kbar;        
    end    
end

reg  [12 -1:0] r_num_re = 0;

generate
    if (NUM_CC == 1)
    begin
        always @ (posedge i_clk)
            r_num_re <= i_num_re[9:0];
    end
    else if (NUM_CC == 2)
    begin
        always @ (posedge i_clk)
            if (i_ro_sync[0])
                r_num_re <= i_num_re[0*12 +: 10];
            else if (i_ro_sync[1])
                r_num_re <= i_num_re[1*12 +: 10];
    end
endgenerate

always @(posedge i_clk) begin
    if(rr_ro_sync) begin
//        r_end_addr      <= r_start_addr + i_num_re[9:0] -1 ;
        r_end_addr      <= r_start_addr + r_num_re -1 ;
    end
end

// counter state
reg [NUM_CC -1:0]       r_en        ;
reg [4      -1:0]       r_cnt_trig  ;
reg [6      -1:0]       r_cnt       ;
reg [4      -1:0]       r_stat      ;
wire[4      -1:0]       w_en        ;

assign  w_en = {{(4-NUM_CC){1'b0}},r_en};

always @(posedge i_clk) begin
    r_en    <= i_rin_en;
end

always @(posedge i_clk) begin
//    if(|i_frame_sync) begin
    if(|i_ro_sync) begin
        r_cnt_trig          <= 4'b0;
    end
    else begin
        r_cnt_trig[0]    <= w_en[0]&~(w_rin_en[0]);
        r_cnt_trig[1]    <= w_en[1]&~(w_rin_en[1]);
        r_cnt_trig[2]    <= w_en[2]&~(w_rin_en[2]);
        r_cnt_trig[3]    <= w_en[3]&~(w_rin_en[3]);
    end
end

always @(posedge i_clk) begin
//    if(|i_frame_sync) begin
    if(|i_ro_sync) begin
        r_stat  <= 0;
        r_cnt   <= 0;
    end
    else if(r_stat==0) begin
        if(r_cnt_trig[0]) begin
            r_stat  <= 4'd1;
            r_cnt   <= 6'd0;
        end
        else if(r_cnt_trig[1]) begin
            r_stat  <= 4'd2;
            r_cnt   <= NUM_ANT;
        end
        else if(r_cnt_trig[2]) begin
            r_stat  <= 4'd3;
            r_cnt   <= STAT2;
        end
        else if(r_cnt_trig[3]) begin
            r_stat  <= 4'd4;
            r_cnt   <= STAT3;
        end
    end
    else if((r_stat==4'd1)&&(r_cnt_trig[0]))begin
        if(r_cnt==(NUM_ANT-2)) begin
            r_stat  <= 4'b0     ;
        end
        r_cnt   <= r_cnt+6'd1;
    end
    else if((r_stat==4'd2)&&(r_cnt_trig[1]))begin
        if(r_cnt==(STAT2-2)) begin
            r_stat  <= 4'b0     ;
        end
        r_cnt   <= r_cnt+6'd1;
    end
    else if((r_stat==4'd3)&&(r_cnt_trig[2]))begin
        if(r_cnt==(STAT3-2)) begin
            r_stat  <= 4'b0     ;
        end
        r_cnt   <= r_cnt+6'd1;
    end
    else if((r_stat==4'd4)&&(r_cnt_trig[3]))begin
        if(r_cnt==(STAT4-2)) begin
            r_stat  <= 4'b0     ;
        end
        r_cnt   <= r_cnt+6'd1;
    end
end


// input reg
         

always@(posedge i_clk) begin
    r_rin_en <= |i_rin_en            ;
end

// FFT

wire [0:0]              w_fft_rstn    ;
wire [0:0]              w_fft_ready   ;
reg  [0:0]              r_fft_sop     ;
wire [0:0]              w_fft_eop     ;
wire [0:0]              w_fft_out_en  ;
wire [1:0]              w_fft_out_err ;
wire [0:0]              w_fft_out_sop ;
wire [0:0]              w_fft_out_eop ;
wire [BW_FFT_OUT-1:0]   w_fft_out_i   ;
wire [BW_FFT_OUT-1:0]   w_fft_out_q   ;
wire [12        -1:0]   w_fft_out_pts ;
reg  [0:0]  r_fft_rstn [DLY_RST-1:0]  ;

always @(posedge i_clk) begin
    r_fft_sop <= (|i_rin_en)&~r_rin_en;
end

assign w_fft_eop = r_rin_en&~(|i_rin_en); 


always@(posedge i_clk) begin
    //r_fft_rstn[0] <=  ~(i_frame_sync[0]|(|w_fft_out_err))  ;
    r_fft_rstn[0] <=  ~(r_ro_sync|(|w_fft_out_err))  ;
    for(i=1;i<DLY_RST;i=i+1) begin
        r_fft_rstn[i] <=  r_fft_rstn[i-1] ;
    end
end

assign w_fft_rstn = r_fft_rstn[DLY_RST-2]&r_fft_rstn[DLY_RST-1]  ;

// fft ip
ylib_vfft_wrapper #(
     //.VENDOR     (    VENDOR         ))
     .MAX_NFFT   (    1024             )
    ,.VENDOR     (    "Custom"         ))
u01_fft
(
     .clk               (   i_clk                               ) // input  wire        
    ,.reset_n           (   w_fft_rstn                          ) // input  wire        
    ,.sink_valid        (   r_rin_en                            ) // input  wire        
    ,.sink_ready        (   w_ifft_ready                        ) // output wire        
    ,.sink_error        (   2'd0                                ) // input  wire [1:0]  
    ,.sink_sop          (   r_fft_sop                           ) // input  wire        
    ,.sink_eop          (   w_fft_eop                           ) // input  wire        
    ,.sink_real         (   r_rin_iq[31:16]                     ) // input  wire [15:0] 
    ,.sink_imag         (   r_rin_iq[15:0]                      ) // input  wire [15:0] 
    ,.fftpts_in         (   r_fft_pts                           ) // input  wire [11:0] 
    ,.inverse           (   1'd0                                ) // input  wire [0:0]  
    ,.source_valid      (   w_fft_out_en                        ) // output wire        
    ,.source_ready      (   1'd1                                ) // input  wire        
    ,.source_error      (   w_fft_out_err                       ) // output wire [1:0]  
    ,.source_sop        (   w_fft_out_sop                       ) // output wire        
    ,.source_eop        (   w_fft_out_eop                       ) // output wire        
    ,.source_real       (   w_fft_out_i                         ) // output wire [27:0] 
    ,.source_imag       (   w_fft_out_q                         ) // output wire [27:0] 
    ,.fftpts_out        (   w_fft_out_pts                       ) // output wire [11:0] 
);

// fft_out reg & scale R
reg  [ 1        -1:0]   r_fft_out_en    ;
reg  [28        -1:0]   r_fft_out_i     ; 
reg  [28        -1:0]   r_fft_out_q     ; 
reg  [ 1        -1:0]   r_fft_out_a_en  ;
reg  [36        -1:0]   r_fft_out_a_i   ; 
reg  [36        -1:0]   r_fft_out_a_q   ; 
reg  [ 1        -1:0]   rr_fft_out_a_en ;
reg  [36        -1:0]   rr_fft_out_a_i  ; 
reg  [36        -1:0]   rr_fft_out_a_q  ; 

wire [ 1        -1:0]   w_fft_out_a2_en ;
wire [36        -1:0]   w_fft_out_a2_i  ;
wire [36        -1:0]   w_fft_out_a2_q  ;
wire [ 1        -1:0]   w_fft_out_sat_en;
wire [2*DO_BW   -1:0]   w_fft_out_sat   ;
reg  [ 1        -1:0]   r_psym_tog = 0  ;


always@(posedge i_clk) begin
    r_fft_out_en <= w_fft_out_en          ;
    if(w_fft_out_en) begin
        r_fft_out_i    <=  w_fft_out_i    ;
        r_fft_out_q    <=  w_fft_out_q    ;
    end
end

always@(posedge i_clk) begin
    r_fft_out_a_en      <= r_fft_out_en   ;
    if(r_fft_out_en) begin
        if(i_rach_nfft[0]) begin
            r_fft_out_a_i   <= $signed({{8{r_fft_out_i[27]}},r_fft_out_i})                 ; 
            r_fft_out_a_q   <= $signed({{8{r_fft_out_q[27]}},r_fft_out_q})                 ; 
        end
        else begin
            r_fft_out_a_i   <= $signed({{8{r_fft_out_i[27]}},r_fft_out_i})*RAFE_FFT_SCALE1 ; 
            r_fft_out_a_q   <= $signed({{8{r_fft_out_q[27]}},r_fft_out_q})*RAFE_FFT_SCALE1 ; 
        end
    end
end

always@(posedge i_clk) begin
    rr_fft_out_a_en <= r_fft_out_a_en    ;
    if(r_fft_out_a_en) begin
        rr_fft_out_a_i  <= r_fft_out_a_i  ; 
        rr_fft_out_a_q  <= r_fft_out_a_q  ; 
    end
end


ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   4           )
 ,.IO_BW        (   36          ))
u01_shiftd_rnd 
(
     .i_clk     (   i_clk                           )
    ,.i_in_en   (   rr_fft_out_a_en                 )
    ,.i_in      (   {rr_fft_out_a_i,rr_fft_out_a_q} )
    ,.i_shiftd  (   r_fft_scale                     )
    ,.o_out_en  (   w_fft_out_a2_en                 )
    ,.o_out     (   {w_fft_out_a2_i,w_fft_out_a2_q} )
);

ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   36          )
 ,.DO_BW        (   DO_BW       ))
u02_sat
(
     .i_clk     (   i_clk                           )
    ,.i_in_en   (   w_fft_out_a2_en                 )
    ,.i_in      (   {w_fft_out_a2_i,w_fft_out_a2_q} )
    ,.o_out_en  (   w_fft_out_sat_en                )
    ,.o_out     (   w_fft_out_sat                   )
);

// fft_order_gen

wire w_fft_out_idx_en ;
wire [$clog2(NUM_MAX_SC-1)-1:0] w_fft_out_idx ;

ylib_xfft_order_gen #(.MAX_NFFT(NUM_MAX_SC))
u03_fft_order_gen
(
     .i_clk             (  i_clk                )
    ,.i_xfft_size       (  r_xfft_size          )
    ,.i_xfft_out_en     (  rr_fft_out_a_en      )
    ,.o_xfft_out_en     (  w_fft_out_idx_en     )
    ,.o_xfft_out_idx    (  w_fft_out_idx        )
);

// toggle gen

wire    [1  -1:0]   w_fft_out_eop_dly;

ylib_pshift #(
    .BW_SHIFT   ($clog2(EOP_DELAY)))
u04_ylib_pshift(
     .i_clk     (i_clk              )
    ,.i_shift   (EOP_DELAY          )
    ,.i_in      (w_fft_out_eop      )
    ,.o_out     (w_fft_out_eop_dly  )
);

always@(posedge i_clk) begin
    //if(i_frame_sync[0]) begin
    if(i_ro_sync[0]) begin        
        r_psym_tog <=  1'd0    ;
    end
    else if(w_fft_out_eop_dly) begin
        r_psym_tog <=  ~r_psym_tog    ;
    end
end 

// white address

reg  [1     -1:0]   r_fft_out_idx_en ;
reg  [12    -1:0]   r_fft_out_idx   ;

always @(posedge i_clk) begin
    r_fft_out_idx_en    <= w_fft_out_idx_en;

    if(w_fft_out_idx_en) begin
        if(r_rach_nfft) begin
            r_fft_out_idx   <= {1'b0,w_fft_out_idx} + 12'd0512;        
//            r_fft_out_idx   <= {1'b0,w_fft_out_idx} ;        
        end
        else begin
            r_fft_out_idx   <= {1'b0,w_fft_out_idx} + 12'd0128;     
        end
    end
end


reg  [1     -1:0]   rr_fft_out_idx_en ;
reg  [10    -1:0]   rr_fft_out_idx    ;

always @(posedge i_clk) begin
    if(r_fft_out_idx_en) begin
        if(r_rach_nfft) begin
            if(r_fft_out_idx[11:0] < 12'd2048) begin   
                rr_fft_out_idx_en   <= 1'b1;   
                rr_fft_out_idx      <= r_fft_out_idx[9:0];
            end
            else begin
                rr_fft_out_idx_en   <= 1'b0;   
                rr_fft_out_idx      <= 10'b0;
            end
        end
        else begin
            if(r_fft_out_idx[8:0] < 11'd256) begin   
                rr_fft_out_idx_en   <= 1'b1;   
                rr_fft_out_idx      <= {2'b0,r_fft_out_idx[7:0]};
            end
            else begin
                rr_fft_out_idx_en   <= 1'b0;   
                rr_fft_out_idx      <= 10'b0;
            end
        end
    end
    else begin
                rr_fft_out_idx_en   <= 1'b0 ;   
                rr_fft_out_idx      <= 10'b0;
    end
end

// read address

reg     [1      -1:0]           r_mem_ren = 0   ;
reg     [10     -1:0]           r_mem_raddr     ;

always @(posedge i_clk) begin
    //if(i_frame_sync[0]) begin
    if(|i_ro_sync) begin
        r_mem_ren   <= 1'b0         ;
        r_mem_raddr <= 10'b0        ;
    end
    else if(w_fft_out_eop_dly) begin
        r_mem_ren   <= 1'b1         ;
        r_mem_raddr <= r_start_addr ;
    end
    else if(r_mem_ren) begin
        if(r_mem_raddr  == r_end_addr) begin
            r_mem_ren   <= 1'b0         ;
            r_mem_raddr <= 10'b0        ;
        end
        else begin
            r_mem_raddr <= r_mem_raddr + 10'd1;
        end
    end
end

// memory interface

reg     [1      -1:0]           r_mem_even_en            ; 
reg     [1      -1:0]           r_mem_even_wen           ; 
reg     [10     -1:0]           r_mem_even_addr          ; 
reg     [2*DI_BW-1:0]           r_mem_even_din           ;
wire    [2*DI_BW-1:0]           w_mem_even_dout          ;


reg     [1      -1:0]           r_mem_odd_en             ; 
reg     [1      -1:0]           r_mem_odd_wen            ; 
reg     [10     -1:0]           r_mem_odd_addr           ; 
reg     [2*DI_BW-1:0]           r_mem_odd_din            ;
wire    [2*DI_BW-1:0]           w_mem_odd_dout           ;

always @(posedge i_clk) begin
    //if(i_frame_sync[0]) begin
    if(|i_ro_sync) begin
        r_mem_even_en   <=  1'b0; 
        r_mem_even_wen  <=  1'b0; 
        r_mem_even_addr <= 10'b0; 
        r_mem_odd_en    <=  1'b0; 
        r_mem_odd_wen   <=  1'b0; 
        r_mem_odd_addr  <= 10'b0; 
    end
    else if(r_psym_tog) begin
        r_mem_even_en   <= r_mem_ren        ;
        r_mem_even_wen  <= 1'b0             ;
        r_mem_even_addr <= r_mem_raddr      ;

        r_mem_odd_en    <= rr_fft_out_idx_en;
        r_mem_odd_wen   <= rr_fft_out_idx_en; 
        r_mem_odd_addr  <= rr_fft_out_idx   ;
    end
    else begin
        r_mem_even_en   <= rr_fft_out_idx_en;
        r_mem_even_wen  <= rr_fft_out_idx_en;
        r_mem_even_addr <= rr_fft_out_idx   ;

        r_mem_odd_en    <= r_mem_ren        ; 
        r_mem_odd_wen   <= 1'b0             ; 
        r_mem_odd_addr  <= r_mem_raddr      ; 
    end
end

always @(posedge i_clk) begin
    if(w_fft_out_sat_en) begin
        r_mem_even_din  <= w_fft_out_sat    ;   
        r_mem_odd_din   <= w_fft_out_sat    ;   
    end
end
   
ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   1024                )
    ,.VENDOR    (   VENDOR              )
)
u05_psym_buf_even
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_even_wen         ) 
    ,.en        (r_mem_even_en          ) 
    ,.addr      (r_mem_even_addr        ) 
    ,.di        (r_mem_even_din         ) 
    ,.dout      (w_mem_even_dout        ) 
);

ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   1024                )
    ,.VENDOR    (   VENDOR              )
)
u06_psym_buf_odd
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_odd_wen          ) 
    ,.en        (r_mem_odd_en           ) 
    ,.addr      (r_mem_odd_addr         ) 
    ,.di        (r_mem_odd_din          ) 
    ,.dout      (w_mem_odd_dout         ) 
);

// mem out

reg     [1      -1:0]           r_mem_dout_en_pre0  ; 
reg     [1      -1:0]           r_mem_dout_en_pre1  ; 
reg     [1      -1:0]           r_mem_dout_en       ; 
reg     [2*DI_BW-1:0]           r_mem_dout          ;

always @(posedge i_clk) begin
    r_mem_dout_en_pre0  <= r_mem_ren            ;
    r_mem_dout_en_pre1  <= r_mem_dout_en_pre0   ;
    o_rout_en           <= r_mem_dout_en_pre1   ;
end

always @(posedge i_clk) begin
    if(r_mem_dout_en_pre1) 
        o_rout_iq  <= w_mem_even_dout | w_mem_odd_dout;
    else 
        o_rout_iq  <= {(2*DI_BW){1'b0}};
end

// sync shift
reg     [18*NUM_CC -1:0] r_shr_val ;
reg     [1 *NUM_CC -1:0] r_shr_en  ;
reg     [18*NUM_CC -1:0] r_shr     ;

always@(posedge i_clk) begin
    for (i=0; i<NUM_CC; i=i+1)
    begin
        if(i_frame_sync[i]) begin
            r_shr_en[i] <=  1'd1   ;
    end 
        else if(r_shr[i*18+:18]==r_fft_dly-1) begin
            r_shr_en[i] <=  1'd0   ;
        end
    end
end
always@(posedge i_clk) begin
    for (i=0; i<NUM_CC; i=i+1)
    begin
        if(i_frame_sync[i]) begin
            r_shr[i*18+:18] <=  18'b0     ;
    end
        else if(r_shr_en[i]) begin
            r_shr[i*18+:18] <= (r_shr[i*18+:18]==r_fft_dly-1) ? 18'b0 : r_shr[i*18+:18]+1'd1    ;
    end 
    end
end

generate
    for (gidx=0; gidx<NUM_CC; gidx=gidx+1)
    begin
        assign o_frame_sync[gidx]  =  r_shr_en[gidx]&&(r_shr[gidx*18+:18]==r_fft_dly-1) ;
    end
endgenerate

// out cnt
wire    [0:0]   w_fft_eop_dly;

ylib_pshift #(
    .BW_SHIFT   ($clog2(CNT_EOP_DELAY)))
u07_ylib_pshift(
     .i_clk     (i_clk              )
    ,.i_shift   (CNT_EOP_DELAY      )
    ,.i_in      (w_fft_eop          )
    ,.o_out     (w_fft_eop_dly      )
);

always @(posedge i_clk) begin
//    if(|i_frame_sync) begin
    if(|i_ro_sync) begin
        o_rout_cnt  <= 3'd0;
    end
    else if(w_fft_eop_dly) begin
        o_rout_cnt  <=  r_cnt[2:0];
    end
end

endmodule
