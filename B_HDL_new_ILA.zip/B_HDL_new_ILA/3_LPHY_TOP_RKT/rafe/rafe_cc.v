// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU  
//  Module       : rafe_cc
//  Author       : sk614.kim@samsung.com
//                 ty321.kim@samsung.com
//  Description  : rafe cc top for VzW FSU
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.02 | jyzoo.lee     | IO Port Draft
//  ------------+---------------+-----------------------------------------------
//   2020.06.22 | taeyeong      | add prameter IF
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module rafe_cc
#( 
    parameter  NUM_CC               =   1  
   ,parameter  NUM_ANT              =   4  
   ,parameter  NUM_CHAIN            =   1
   ,parameter  MAX_OBW              =   100
   ,parameter  TOP_DIO_BW           =   16           
   ,parameter  DLY_REG_RD           =   7
   ,parameter  ADDR_OFFSET          =   16'h9000           
   ,parameter  VENDOR               =   "Intel"
   ,parameter  CPU_ADDR_BW          =   20
   ,parameter  BAND_IDX             =   0
)
(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  

    //--- from cpu interface
    ,   input   wire    [CPU_ADDR_BW*NUM_CC         -1:0]       i_cpu_addr
    ,   input   wire    [1          *NUM_CC         -1:0]       i_cpu_wren
    ,   input   wire    [32         *NUM_CC         -1:0]       i_cpu_wdata
    ,   input   wire    [1          *NUM_CC         -1:0]       i_cpu_rden
    ,   output  wire    [32         *NUM_CC         -1:0]       o_cpu_rdata
    ,   output  wire    [1          *NUM_CC         -1:0]       o_cpu_rd_valid

    //--- from qm_top
    ,   input   wire    [NUM_CC*NUM_ANT* 4          -1:0]       i_rin_filter_idx     
    ,   input   wire    [NUM_CC*NUM_ANT*16          -1:0]       i_rin_time_offset    
    ,   input   wire    [NUM_CC*NUM_ANT* 8          -1:0]       i_rin_frame_struct      
    ,   input   wire    [NUM_CC*NUM_ANT*16          -1:0]       i_rin_cp_length      
    ,   input   wire    [NUM_CC*NUM_ANT* 4          -1:0]       i_rin_num_psymbol     
    ,   input   wire    [NUM_CC*NUM_ANT*24          -1:0]       i_rin_freq_offset    
    ,   input   wire    [NUM_CC*NUM_ANT* 3          -1:0]       i_rin_num_ro    
    ,   input   wire    [NUM_CC*NUM_ANT* 8          -1:0]       i_rin_num_prbc
    ,   input   wire    [NUM_CC*NUM_ANT*10          -1:0]       i_rin_start_prbc

    //--- from bb_if
    ,   input   wire    [1*NUM_CC                   -1:0]       i_rin_frame_sync
    ,   input   wire    [8                          -1:0]       i_rin_frame_idx
    ,   input   wire    [NUM_CC*NUM_ANT             -1:0]       i_rin_en           
    ,   input   wire    [2*NUM_CC*NUM_ANT*TOP_DIO_BW-1:0]       i_rin_iq           

    //--- to bb_top
    ,   output  wire    [NUM_CC*1                   -1:0]       o_rout_frame_sync   
    ,   output  wire    [NUM_CC*8                   -1:0]       o_rout_frame_idx
    ,   output  wire    [NUM_CC*4                   -1:0]       o_rout_subfrm_idx
    ,   output  wire    [NUM_CC*6                   -1:0]       o_rout_slot_idx
    ,   output  wire    [NUM_CC*4                   -1:0]       o_rout_symbol_idx
    ,   output  wire    [NUM_CC*NUM_ANT             -1:0]       o_rout_en
    ,   output  wire    [NUM_CC*NUM_ANT*2*TOP_DIO_BW-1:0]       o_rout_iq      
    ,   output  wire    [NUM_CC*NUM_ANT*16          -1:0]       o_rout_start_re_idx
    ,   output  wire    [NUM_CC*NUM_ANT*1           -1:0]       o_rout_start_re    
    ,   output  wire    [NUM_CC*NUM_ANT*1           -1:0]       o_rout_last_re     
);

// signal

genvar  chidx, ccidx;

wire    [NUM_CC* 1                         -1:0]       w_par_rafe_en               ;
wire    [NUM_CC* 1                         -1:0]       w_par_rafe_band_en          ;
wire    [NUM_CC* 1                         -1:0]       w_par_sw_reset              ;
wire    [NUM_CC*17                         -1:0]       w_par_slot_offset           ;
wire    [NUM_CC* 1                         -1:0]       w_par_tagc_on               ;
wire    [NUM_CC* 5                         -1:0]       w_par_target_bo             ;
wire    [NUM_CC* 8                         -1:0]       w_par_mpframstruct          ;
wire    [NUM_CC* 1                         -1:0]       w_par_freq_7p5k             ;
wire    [NUM_CC*16                         -1:0]       w_par_rach_freq_shift       ;  
wire    [NUM_CC*16                         -1:0]       w_par_adv_offset            ;

wire    [NUM_CC* 1                         -1:0]       w_par_rach_freq_shift_sel   ;
wire    [NUM_CC* 1                         -1:0]       w_par_iq_swap               ;
wire    [NUM_CC* 1                         -1:0]       w_par_in_tp_gen             ; 
wire    [NUM_CC* 1                         -1:0]       w_par_out_tp_gen            ; 
wire    [NUM_CC* 1                         -1:0]       w_par_debug_mode            ; 
wire    [NUM_CC* 4                         -1:0]       w_par_debug_subfrm          ; 

wire    [NUM_CC* 4                         -1:0]       w_par_filter_idx            ;
wire    [NUM_CC*16                         -1:0]       w_par_time_offset           ;
wire    [NUM_CC* 8                         -1:0]       w_par_frame_struct          ;
wire    [NUM_CC*16                         -1:0]       w_par_cp_length             ;
wire    [NUM_CC* 4                         -1:0]       w_par_num_psymbol           ;
wire    [NUM_CC*24                         -1:0]       w_par_freq_offset           ;
wire    [NUM_CC* 3                         -1:0]       w_par_num_ro                ;
wire    [NUM_CC* 8                         -1:0]       w_par_num_prbc              ;

wire    [NUM_CC* 1                         -1:0]       w_par_freq_init_set         ;
wire    [NUM_CC*12                         -1:0]       w_par_freq_init_val         ;

wire    [NUM_CC* 4                         -1:0]       w_rin_filter_idx            ;
wire    [NUM_CC*16                         -1:0]       w_rin_time_offset           ;
wire    [NUM_CC* 8                         -1:0]       w_rin_frame_struct          ;
wire    [NUM_CC*16                         -1:0]       w_rin_cp_length             ;
wire    [NUM_CC* 4                         -1:0]       w_rin_num_psymbol           ;
wire    [NUM_CC*24                         -1:0]       w_rin_freq_offset           ;
wire    [NUM_CC* 3                         -1:0]       w_rin_num_ro                ;
wire    [NUM_CC* 8                         -1:0]       w_rin_num_prbc              ;
wire    [NUM_CC*10                         -1:0]       w_rin_start_prbc            ;
wire    [NUM_CC*32                         -1:0]       w_rin_rec_oran              ;

wire    [NUM_CC* 1                         -1:0]       w_rafe_den                  ;

wire    [NUM_CC* 8                         -1:0]       w_path_ratio                ;
wire    [NUM_CC*16                         -1:0]       w_rach_freq_shift           ;  
wire    [NUM_CC* 7                         -1:0]       w_deci_ratio                ;      // PRACH SCS 60kHz : 4, 120kHz : 2
wire    [NUM_CC* 2                         -1:0]       w_over_ratio                ;  
wire    [NUM_CC* 5                         -1:0]       w_cic_out_atten             ;  
wire    [NUM_CC* 1                         -1:0]       w_rach_n_fft                ;  
wire    [NUM_CC* 2                         -1:0]       w_rascsi                    ;       //  0:15kHz,1:30kHz,2:60kHz,3:120kHz
wire    [NUM_CC* 4                         -1:0]       w_num_psym                  ;       // =i_num_symbol
wire    [NUM_CC*14                         -1:0]       w_ro_offset                 ;       //  R*(i_time_offset + i_cp_length) 
wire    [NUM_CC* 2                         -1:0]       w_cic_offset                ;       // 1 fixed
wire    [NUM_CC*12                         -1:0]       w_num_re                    ;
wire    [NUM_CC* 1                         -1:0]       w_f0_case0                  ;
wire    [NUM_CC* 8                         -1:0]       w_al_kbar                   ;
wire    [NUM_CC* 1                         -1:0]       w_ce                        ;
wire    [NUM_CC* 1                         -1:0]       w_ce_trig                   ;
wire    [NUM_CC* 1                         -1:0]       w_rec_trig                  ;

wire    [NUM_CC* 1                         -1:0]       w_sub_rst                   ;

wire    [NUM_CC* 1                         -1:0]       w_input_ctrl_sync_pre       ;
wire    [NUM_CC* 1                         -1:0]       w_input_ctrl_sync           ;
wire    [NUM_CC* 1                         -1:0]       w_input_ctrl_en_pre         ;        
wire    [NUM_CC*NUM_ANT                    -1:0]       w_input_ctrl_en             ;        
wire    [NUM_CC*2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_input_ctrl_iq             ;   

wire    [NUM_CC* 1                         -1:0]       w_cmplx_exp_vld             ;
wire    [NUM_CC*16                         -1:0]       w_p_cos                     ;
wire    [NUM_CC*16                         -1:0]       w_n_sin                     ;

wire    [NUM_CC* 1          *NUM_CHAIN     -1:0]       w_fshift_sync               ;
wire    [NUM_CC*NUM_ANT                    -1:0]       w_fshift_vld                ;
wire    [NUM_CC*2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_fshift_iq                 ;

wire    [NUM_CC*1           *NUM_CHAIN     -1:0]       w_cic_filt_sync             ;             
wire    [NUM_CC*NUM_ANT                    -1:0]       w_cic_filt_en               ;           
wire    [NUM_CC*2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cic_filt_iq               ;           

wire    [NUM_CC*1           *NUM_CHAIN     -1:0]       w_cnfg_frame_sync           ;
wire    [NUM_CC*1           *NUM_CHAIN     -1:0]       w_cnfg_ro_sync              ;
wire    [NUM_CC*NUM_ANT                    -1:0]       w_cnfg_rout_en              ;
wire    [NUM_CC*2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cnfg_rout_iq              ;
wire    [NUM_CC*4           *NUM_CHAIN     -1:0]       w_start_sym                 ;
    
wire    [NUM_CC* 1          *NUM_CHAIN     -1:0]       w_psym_sync                 ;      
wire    [NUM_CC* 1          *NUM_CHAIN     -1:0]       w_rout_en                   ;
wire    [NUM_CC*2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_rout_iq                   ;
wire    [NUM_CC*NUM_ANT*4                  -1:0]       w_tagc_gain                 ;
wire    [NUM_CC*NUM_ANT*5                  -1:0]       w_tagc_lut_index            ;
wire    [       8*31                       -1:0]       w_rssi                      ;


wire    [NUM_CC* 1          *NUM_CHAIN     -1:0]       w_fft_demap_sync            ;   
wire    [        1          *NUM_CHAIN     -1:0]       w_fft_demap_rout_en         ;
wire    [       2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_fft_demap_rout_iq         ;
wire    [        3          *NUM_CHAIN     -1:0]       w_fft_demap_rout_cnt        ;

wire    [NUM_CC* 1          *NUM_CHAIN     -1:0]       w_gain_comp_sync            ;   
wire    [        4          *NUM_CHAIN     -1:0]       w_gain_comp_rout_en         ;
wire    [       2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_gain_comp_rout_iq         ;

wire    [NUM_CC*32                         -1:0]       w_cnt_sym00;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym01;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym02;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym03;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym04;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym05;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym06;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym07;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym08;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym09;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym10;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym11;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym12;
wire    [NUM_CC*32                         -1:0]       w_cnt_sym13;
wire    [NUM_CC*14*10                      -1:0]       w_output_log;

// input reg
wire    [1*NUM_CC                   -1:0]       w_rin_frame_sync   ; 
wire    [8                          -1:0]       w_rin_frame_idx    ;
reg     [8                          -1:0]       r_rin_frame_idx    ;
wire    [NUM_CC*NUM_ANT             -1:0]       w_rin_en           ;
wire    [NUM_CC*NUM_ANT*2*TOP_DIO_BW-1:0]       w_rin_iq           ;

ylib_reg #(.WIDTH(2*NUM_CC*NUM_ANT*TOP_DIO_BW + NUM_CC*NUM_ANT + 8 + NUM_CC) ,.DEPTH(1)) u99_input_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ({i_rin_frame_sync, i_rin_frame_idx, i_rin_en, i_rin_iq})
   ,.o_out      ({w_rin_frame_sync, w_rin_frame_idx, w_rin_en, w_rin_iq})
);

always @(posedge i_clk) begin
    if(|i_rin_frame_sync) begin  r_rin_frame_idx <= i_rin_frame_idx;    end
end

// ctrl module

generate for(ccidx=0;ccidx<NUM_CC;ccidx=ccidx+1) begin : g00_rafe_input_if

    rafe_cpu_param_if #(
        .ADDR_OFFSET    (   ADDR_OFFSET + 1024*NUM_ANT*ccidx    )       // CPU IF Address Offset    
       ,.DLY_REG_RD     (   DLY_REG_RD      )       // READ Latency
       ,.AW             (   CPU_ADDR_BW     )       // CPU IF Address Bit Width
       ,.DW             (   32              )       // CPU IF Data Bit Width 
       ,.RU_MODE        (   0               ))      
    u00_rafe_cpu_param_if(
        //--- reset & clk
         .i_clk                        ( i_clk                      )

        //--- cpu interface
        ,.i_cpu_addr                   ( i_cpu_addr    [CPU_ADDR_BW*ccidx+:CPU_ADDR_BW]           )
        ,.i_cpu_wren                   ( i_cpu_wren    [1          *ccidx+:1          ]           )
        ,.i_cpu_wdata                  ( i_cpu_wdata   [32         *ccidx+:32         ]           )
        ,.i_cpu_rden                   ( i_cpu_rden    [1          *ccidx+:1          ]           )
        ,.o_cpu_rdata                  ( o_cpu_rdata   [32         *ccidx+:32         ]           )
        ,.o_cpu_rd_valid               ( o_cpu_rd_valid[1          *ccidx+:1          ]           )
                                      
        //--- Parsed parameter 
        ,.o_par_rafe_en                ( w_par_rafe_en        [ 1*ccidx+: 1]    )
        ,.o_par_rafe_band_en           ( w_par_rafe_band_en   [ 1*ccidx+: 1]    )
        ,.o_par_sw_reset               ( w_par_sw_reset       [ 1*ccidx+: 1]    )
        ,.o_par_slot_offset            ( w_par_slot_offset    [17*ccidx+:17]    )
        ,.o_par_tagc_on                ( w_par_tagc_on        [ 1*ccidx+: 1]    )
        ,.o_par_target_bo              ( w_par_target_bo      [ 5*ccidx+: 5]    )
        ,.o_par_mpframstruct           ( w_par_mpframstruct   [ 8*ccidx+: 8]    )
        ,.o_par_freq_7p5k              ( w_par_freq_7p5k      [ 1*ccidx+: 1]    )
        ,.o_par_rach_freq_shift        ( w_par_rach_freq_shift[16*ccidx+:16]    ) 
        ,.o_par_adv_offset             ( w_par_adv_offset     [16*ccidx+:16]    )
    
        ,.o_par_ant_cal_bypass         (                            )   // output  [ 1     -1:0]
        ,.o_par_ant_cal_shift          (                            )   // output  [ 4     -1:0]
    
        ,.o_par_ant_cal_w00            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w01            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w02            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w03            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w04            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w05            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w06            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w07            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w08            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w09            (                            )   // output  [DW     -1:0]
    
        ,.o_par_ant_cal_w10            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w11            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w12            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w13            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w14            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w15            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w16            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w17            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w18            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w19            (                            )   // output  [DW     -1:0]
    
        ,.o_par_ant_cal_w20            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w21            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w22            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w23            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w24            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w25            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w26            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w27            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w28            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w29            (                            )   // output  [DW     -1:0]
    
        ,.o_par_ant_cal_w30            (                            )   // output  [DW     -1:0]
        ,.o_par_ant_cal_w31            (                            )   // output  [DW     -1:0]
    
        ,.o_par_freq_shift_sel         ( w_par_rach_freq_shift_sel[ 1*ccidx+:1]) 
        ,.o_par_iq_swap                ( w_par_iq_swap            [ 1*ccidx+:1]) 
        ,.o_par_in_tp_gen              ( w_par_in_tp_gen          [ 1*ccidx+:1]) 
        ,.o_par_out_tp_gen             ( w_par_out_tp_gen         [ 1*ccidx+:1]) 
        ,.o_par_debug_mode             ( w_par_debug_mode         [ 1*ccidx+:1]) 
        ,.o_par_debug_subfrm           ( w_par_debug_subfrm       [ 4*ccidx+:4])
    
        ,.o_par_filter_idx             ( w_par_filter_idx   [  4*ccidx+: 4]        ) 
        ,.o_par_time_offset            ( w_par_time_offset  [ 16*ccidx+:16]        ) 
        ,.o_par_frame_struct           ( w_par_frame_struct [  8*ccidx+: 8]        )    
        ,.o_par_cp_length              ( w_par_cp_length    [ 16*ccidx+:16]        ) 
        ,.o_par_num_psymbol            ( w_par_num_psymbol  [  4*ccidx+: 4]        )  
        ,.o_par_freq_offset            ( w_par_freq_offset  [ 24*ccidx+:24]        ) 
        ,.o_par_num_ro                 ( w_par_num_ro       [  3*ccidx+: 3]        )  
        ,.o_par_num_prbc               ( w_par_num_prbc     [  8*ccidx+: 8]        )  

        ,.o_par_freq_init_set          ( w_par_freq_init_set[  1*ccidx+: 1]        ) 
        ,.o_par_freq_init_val          ( w_par_freq_init_val[ 12*ccidx+:12]        ) 

        //--- Report Register
        ,.i_rpt_rssi_ro0               ({1'b0,w_rssi[31*1 -1: 31*0]})
        ,.i_rpt_rssi_ro1               ({1'b0,w_rssi[31*2 -1: 31*1]})
        ,.i_rpt_rssi_ro2               ({1'b0,w_rssi[31*3 -1: 31*2]})
        ,.i_rpt_rssi_ro3               ({1'b0,w_rssi[31*4 -1: 31*3]})
        ,.i_rpt_rssi_ro4               ({1'b0,w_rssi[31*5 -1: 31*4]})
        ,.i_rpt_rssi_ro5               ({1'b0,w_rssi[31*6 -1: 31*5]})
        ,.i_rpt_rssi_ro6               ({1'b0,w_rssi[31*7 -1: 31*6]})
        ,.i_rpt_rssi_ro7               ({1'b0,w_rssi[31*8 -1: 31*7]})
    
        //--- Read oRAN parameter
        
        ,.i_rin_filter_idx              ( w_rin_filter_idx  [ 4*ccidx+: 4 ]         ) 
        ,.i_rin_time_offset             ( w_rin_time_offset [16*ccidx+:16 ]         ) 
        ,.i_rin_frame_struct            ( w_rin_frame_struct[ 8*ccidx+: 8 ]         )    
        ,.i_rin_cp_length               ( w_rin_cp_length   [16*ccidx+:16 ]         ) 
        ,.i_rin_num_psymbol             ( w_rin_num_psymbol [ 4*ccidx+: 4 ]         )  
        ,.i_rin_freq_offset             ( w_rin_freq_offset [24*ccidx+:24 ]         ) 
        ,.i_rin_num_ro                  ( w_rin_num_ro      [ 3*ccidx+: 3 ]         )  
        ,.i_rin_num_prbc                ( w_rin_num_prbc    [ 8*ccidx+: 8 ]         )  
        ,.i_rin_start_prbc              ( w_rin_start_prbc  [10*ccidx+:10 ]         ) 
        ,.i_rin_rec_oran                ( w_rin_rec_oran    [32*ccidx+:32 ]         )    

        ,.i_cnt_s00                     ( w_cnt_sym00 [32*ccidx+: 32]           ) 
        ,.i_cnt_s01                     ( w_cnt_sym01 [32*ccidx+: 32]           ) 
        ,.i_cnt_s02                     ( w_cnt_sym02 [32*ccidx+: 32]           ) 
        ,.i_cnt_s03                     ( w_cnt_sym03 [32*ccidx+: 32]           ) 
        ,.i_cnt_s04                     ( w_cnt_sym04 [32*ccidx+: 32]           ) 
        ,.i_cnt_s05                     ( w_cnt_sym05 [32*ccidx+: 32]           ) 
        ,.i_cnt_s06                     ( w_cnt_sym06 [32*ccidx+: 32]           ) 
        ,.i_cnt_s07                     ( w_cnt_sym07 [32*ccidx+: 32]           ) 
        ,.i_cnt_s08                     ( w_cnt_sym08 [32*ccidx+: 32]           ) 
        ,.i_cnt_s09                     ( w_cnt_sym09 [32*ccidx+: 32]           ) 
        ,.i_cnt_s10                     ( w_cnt_sym10 [32*ccidx+: 32]           ) 
        ,.i_cnt_s11                     ( w_cnt_sym11 [32*ccidx+: 32]           ) 
        ,.i_cnt_s12                     ( w_cnt_sym12 [32*ccidx+: 32]           ) 
        ,.i_cnt_s13                     ( w_cnt_sym13 [32*ccidx+: 32]           ) 
        ,.i_output_log                  ( w_output_log[14*10*ccidx +: 14*10])
    );
    
    rafe_oran_param_if
    u01_rafe_oran_param_if(
        //--- reset & clk
         .i_clk                         ( i_clk                       )        
        ,.i_rin_frame_sync              ( w_rin_frame_sync          [ 1*ccidx+: 1 ]   )  
        //--- from cpu_if
        ,.i_m_frm_str                   ( w_par_mpframstruct        [ 8*ccidx+: 8 ]     )    // [3:0]:PUSCH SCS,[7:4]:PUSCH FFT Size       
        ,.i_freq_shift_7p5k             ( w_par_freq_7p5k           [ 1*ccidx+: 1 ]     )   
        ,.i_rach_freq_shift             ( w_par_rach_freq_shift     [16*ccidx+:16 ]     )   
        ,.i_rach_freq_shift_sel         ( w_par_rach_freq_shift_sel [ 1*ccidx+: 1 ]     )   
        ,.i_adv_offset                  ( w_par_adv_offset          [16*ccidx+:16 ]     )   
    
        ,.i_par_debug_mode              ( w_par_debug_mode   [ 1*ccidx+: 1]         )    // enable
        ,.i_par_filter_idx              ( w_par_filter_idx   [ 4*ccidx+: 4]         )    // 1, 3                                    oRAN                                 
        ,.i_par_time_offset             ( w_par_time_offset  [16*ccidx+:16]         )    // 0 ~ 30720 : 1ms                         oRAN                                 
        ,.i_par_frame_struct            ( w_par_frame_struct [ 8*ccidx+: 8]         )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
        ,.i_par_cp_length               ( w_par_cp_length    [16*ccidx+:16]         )    //                                         oRAN                                 
        ,.i_par_num_psymbol             ( w_par_num_psymbol  [ 4*ccidx+: 4]         )    //                                         oRAN                                  
        ,.i_par_freq_offset             ( w_par_freq_offset  [24*ccidx+:24]         )    //                                         oRAN                                 
        ,.i_par_num_ro                  ( w_par_num_ro       [ 3*ccidx+: 3]         )    // nuber of c-plane type3
        ,.i_par_num_prbc                ( w_par_num_prbc     [ 8*ccidx+: 8]         )
        ,.i_rin_start_prbc              ( i_rin_start_prbc  [10*NUM_ANT*ccidx+:10]  )

        //--- from qm_top
        ,.i_rin_en                      ( w_rin_en          [ 1*NUM_ANT*ccidx+: 1]  )    // enable
        ,.i_rin_filter_idx              ( i_rin_filter_idx  [ 4*NUM_ANT*ccidx+: 4]  )    // 1, 3                                    oRAN                                 
        ,.i_rin_time_offset             ( i_rin_time_offset [16*NUM_ANT*ccidx+:16]  )    // 0 ~ 30720 : 1ms                         oRAN                                 
        ,.i_rin_frame_struct            ( i_rin_frame_struct[ 8*NUM_ANT*ccidx+: 8]  )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
        ,.i_rin_cp_length               ( i_rin_cp_length   [16*NUM_ANT*ccidx+:16]  )    //                                         oRAN                                 
        ,.i_rin_num_psymbol             ( i_rin_num_psymbol [ 4*NUM_ANT*ccidx+: 4]  )    //                                         oRAN                                  
        ,.i_rin_freq_offset             ( i_rin_freq_offset [24*NUM_ANT*ccidx+:24]  )    //                                         oRAN                                 
        ,.i_rin_num_ro                  ( i_rin_num_ro      [ 3*NUM_ANT*ccidx+: 3]  )    // nuber of c-plane type3
        ,.i_rin_num_prbc                ( i_rin_num_prbc    [ 8*NUM_ANT*ccidx+: 8]  )    // nuber of c-plane type3
    
        //--- to RAFE core
        ,.o_rafe_en                     ( w_rafe_den        [ 1*ccidx+: 1]          )
        ,.o_path_ratio                  ( w_path_ratio      [ 8*ccidx+: 8]          )
    
        ,.o_rach_freq_shift             ( w_rach_freq_shift [16*ccidx+:16]          )   
        ,.o_deci_ratio                  ( w_deci_ratio      [ 7*ccidx+: 7]          )   // PRACH SCS 60kHz : 4, 120kHz : 2
        ,.o_over_ratio                  ( w_over_ratio      [ 2*ccidx+: 2]          )   
        ,.o_cic_out_atten               ( w_cic_out_atten   [ 5*ccidx+: 5]          )   
        ,.o_rach_n_fft                  ( w_rach_n_fft      [ 1*ccidx+: 1]          )   
        ,.o_rascsi                      ( w_rascsi          [ 2*ccidx+: 2]          )    //  0:15kHz,1:30kHz,2:60kHz,3:120kHz
        ,.o_num_psym                    ( w_num_psym        [ 4*ccidx+: 4]          )    // =i_num_symbol
        ,.o_ro_offset                   ( w_ro_offset       [14*ccidx+:14]          )    //  R*(i_time_offset + i_cp_length) 
        ,.o_cic_offset                  ( w_cic_offset      [ 2*ccidx+: 2]          )    // 1 fixed
        ,.o_num_re                      ( w_num_re          [12*ccidx+:12]          )
        ,.o_f0_case0                    ( w_f0_case0        [ 1*ccidx+: 1]          )    
        ,.o_al_kbar                     ( w_al_kbar         [ 8*ccidx+: 8]          )    
        ,.o_ce                          ( w_ce              [ 1*ccidx+: 1]          )    
        ,.o_ce_trig                     ( w_ce_trig         [ 1*ccidx+: 1]          )    
        ,.o_rec_trig                    ( w_rec_trig        [ 1*ccidx+: 1]          )    
        ,.o_sub_rst                     ( w_sub_rst         [ 1*ccidx+: 1]          )
    
        //--- Read oRAN parameter
        ,.o_rin_filter_idx              ( w_rin_filter_idx  [ 4*ccidx+: 4 ]         ) 
        ,.o_rin_time_offset             ( w_rin_time_offset [16*ccidx+:16 ]         ) 
        ,.o_rin_frame_struct            ( w_rin_frame_struct[ 8*ccidx+: 8 ]         )    
        ,.o_rin_cp_length               ( w_rin_cp_length   [16*ccidx+:16 ]         ) 
        ,.o_rin_num_psymbol             ( w_rin_num_psymbol [ 4*ccidx+: 4 ]         )  
        ,.o_rin_freq_offset             ( w_rin_freq_offset [24*ccidx+:24 ]         ) 
        ,.o_rin_num_ro                  ( w_rin_num_ro      [ 3*ccidx+: 3 ]         )  
        ,.o_rin_num_prbc                ( w_rin_num_prbc    [ 8*ccidx+: 8 ]         )  
        ,.o_rin_start_prbc              ( w_rin_start_prbc  [10*ccidx+:10 ]         ) 
        ,.o_rin_rec_oran                ( w_rin_rec_oran    [32*ccidx+:32 ]         )
    );
    
    // input ctrl
    rafe_input_ctrl #(
         .NUM_ANT   ( NUM_ANT   )
        ,.NUM_CHAIN ( NUM_CHAIN )
        ,.DI_BW     ( TOP_DIO_BW)
        ,.DO_BW     ( TOP_DIO_BW))
    u02_rafe_input_ctrl(
         .i_clk                     (i_clk                  )   //   input   wire                                
    
        ,.i_par_iq_swap             (w_par_iq_swap      [ 1*ccidx+:1]    )   //   input   wire    [ 1             -1:0]       
        ,.i_par_in_tp_gen           (w_par_in_tp_gen    [ 1*ccidx+:1]    )   //   input   wire    [ 1             -1:0]  
        ,.i_par_debug_mode          (w_par_debug_mode   [ 1*ccidx+:1]    )
        ,.i_par_debug_subfrm        (w_par_debug_subfrm [ 4*ccidx+:4]    )
        ,.i_path_ratio              (w_path_ratio       [ 8*ccidx+:8]    )
    
        ,.i_rin_frame_sync          (w_rin_frame_sync   [ 1*ccidx+:1]    )   //   input   wire    [ 1             -1:0]       
        ,.i_rin_en                  (w_rin_en           [ 1*NUM_ANT*ccidx+:NUM_ANT]    )   //   input   wire    [NUM_ANT        -1:0]       
        ,.i_rin_iq                  (w_rin_iq           [ NUM_ANT*2*TOP_DIO_BW*ccidx+:NUM_ANT*2*TOP_DIO_BW]    )   //   input   wire    [2*NUM_ANT*DI_BW-1:0]      
        
        ,.i_rafe_den                (w_rafe_den         [ 1*ccidx+:1]     )
    
        ,.o_rout_frame_sync_pre     (w_input_ctrl_sync_pre[ 1                    *ccidx+: 1                     ] )   //   input   wire    [ 1             -1:0]       
        ,.o_rout_frame_sync         (w_input_ctrl_sync    [ 1                    *ccidx+: 1                     ] )   //   input   wire    [ 1             -1:0]       
        ,.o_rout_en_pre             (w_input_ctrl_en_pre  [ 1                    *ccidx+: 1                     ] )   //   input   wire    [NUM_ANT        -1:0]       
        ,.o_rout_en                 (w_input_ctrl_en      [NUM_ANT               *ccidx+:NUM_ANT                ] )   //   input   wire    [NUM_ANT        -1:0]       
        ,.o_rout_iq                 (w_input_ctrl_iq      [2*TOP_DIO_BW*NUM_CHAIN*ccidx+:2*TOP_DIO_BW*NUM_CHAIN ] )   //   input   wire    [2*DO_BW        -1:0]       
    );
    
///////////////////////////
// RAFE core
///////////////////////////

// cmplx exp
    rafe_exp_49152  #(
        .DO_BW(TOP_DIO_BW))
    u03_rafe_exp_49152(
         .i_clk           (i_clk                )  //              input   wire                                
    
        ,.i_path_ratio    (w_path_ratio          [ 8*ccidx+: 8 ]  )  //              input   wire    [ 1             -1:0]       
        ,.i_freq_shift    (w_rach_freq_shift     [16*ccidx+:16 ]  )
        ,.i_frame_sync    (w_input_ctrl_sync_pre [ 1*ccidx+: 1 ]  )  //              input   wire    [1              -1:0]       
        ,.i_rin_en        (w_input_ctrl_en_pre   [ 1*ccidx+: 1 ]  )  //              input   wire    [1              -1:0]       
                                                              
        ,.o_cmplx_exp_vld ( w_cmplx_exp_vld      [ 1*ccidx+: 1 ]  )  //              input   wire                                
        ,.o_p_cos         ( w_p_cos              [16*ccidx+:16 ]  )  //              input   wire    [DO_BW          -1:0]       
        ,.o_n_sin         ( w_n_sin              [16*ccidx+:16 ]  )  //              input   wire    [DO_BW          -1:0]       
    );

    end
endgenerate

generate
    for (chidx=0;chidx<NUM_CHAIN;chidx=chidx+1) begin : g01_path_chain
        for(ccidx=0;ccidx<NUM_CC;ccidx=ccidx+1) begin : g02_cc_chain

    // freq shift

    rafe_freq_shift #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW(TOP_DIO_BW)
        ,.DO_BW(TOP_DIO_BW))
    u04_rafe_freq_shift(
       .i_clk        ( i_clk                    ) 
 //  [((01)*(gidx+1)-1)-:(01)] 
      ,.i_frame_sync ( w_input_ctrl_sync[(( 1)*(ccidx+1)-1)-: 1 ]        ) 
      ,.i_rin_en     ( w_input_ctrl_en  [(NUM_ANT/NUM_CHAIN*(ccidx+1)*(chidx+1)-1) -: NUM_ANT/NUM_CHAIN]        ) 
      ,.i_rin_iq     ( w_input_ctrl_iq  [(2*TOP_DIO_BW     *(ccidx+1)*(chidx+1)-1) -:      2*TOP_DIO_BW]        ) 
      ,.i_p_cos      ( w_p_cos          [(16*(ccidx+1)-1)-:16 ]        ) 
      ,.i_n_sin      ( w_n_sin          [(16*(ccidx+1)-1)-:16 ]        ) 
    
      ,.o_frame_sync ( w_fshift_sync    [(1                 *(ccidx+1)*(chidx+1)-1)-:                 1]        ) 
      ,.o_rout_en    ( w_fshift_vld     [(NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN]        ) 
      ,.o_rout_iq    ( w_fshift_iq      [(2*TOP_DIO_BW      *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW]        ) 
    );
    
    // CIC
    
    rafe_cic_filt_dsp #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.MAX_OBW (MAX_OBW          )
        ,.DI_BW   (TOP_DIO_BW       )
        ,.DO_BW   (TOP_DIO_BW       )) 
    u05_rafe_cic_filt(
         .i_clk           ( i_clk           )  
    
        ,.i_deci_ratio    ( w_deci_ratio   [ 7*ccidx+: 7] )  
        ,.i_over_ratio    ( w_over_ratio   [ 2*ccidx+: 2] )          
        ,.i_cic_out_atten ( w_cic_out_atten[ 5*ccidx+: 5] )  
        ,.i_ce            ( w_ce           [ 1*ccidx+: 1] )     

        ,.i_path_ratio    ( w_path_ratio   [ 8*ccidx+: 8] )  
        ,.i_sub_rst       ( w_sub_rst      [ 1*ccidx+: 1] )
        ,.i_frame_sync    ( w_fshift_sync[(1                *(ccidx+1)*(chidx+1)-1)-:                 1]  )  
        ,.i_rin_en        ( w_fshift_vld [(NUM_ANT/NUM_CHAIN*(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN]  )  
        ,.i_rin_iq        ( w_fshift_iq  [(2*TOP_DIO_BW     *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW]  )  
    
        ,.o_frame_sync    ( w_cic_filt_sync[(1                *(ccidx+1)*(chidx+1)-1)-:                 1] )  
        ,.o_rout_en       ( w_cic_filt_en  [(NUM_ANT/NUM_CHAIN*(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN] )  
        ,.o_rout_iq       ( w_cic_filt_iq  [(2*TOP_DIO_BW     *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW] )  
    );
    
    // Configuration Mapping
    
    rafe_cnfg_map #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW(TOP_DIO_BW)
        ,.DO_BW(TOP_DIO_BW)) 
    u06_rafe_cnfg_map(
         .i_clk             ( i_clk             )   //              input   wire                                
    
        ,.i_slot_offset     ( w_par_slot_offset [ 17*ccidx+:17] )   //              input   wire    [17     -1:0]               
        ,.i_m_frm_str       ( w_par_mpframstruct[  8*ccidx+: 8] )    // [3:0]:PUSCH SCS,[7:4]:PUSCH FFT Size       
        ,.i_rach_nfft       ( w_rach_n_fft      [  1*ccidx+: 1] )   //              input   wire    [ 1     -1:0]               
        ,.i_num_psym        ( w_num_psym        [  4*ccidx+: 4] )   //              input   wire    [ 4     -1:0]               
        ,.i_ro_offset       ( w_ro_offset       [ 14*ccidx+:14] )   //              input   wire    [14     -1:0]               
        ,.i_cic_offset      ( w_cic_offset      [  2*ccidx+: 2] )   //              input   wire    [ 2     -1:0]               
        ,.i_ra_scs          ( w_rin_frame_struct[  8*ccidx+: 4] )    // [3:0]:PRACH SCS, oRAN                                            
        ,.i_f0_case0        ( w_f0_case0        [  1*ccidx+: 1] )     
        ,.i_ce              ( w_ce              [  1*ccidx+: 1] )     
        ,.i_ce_trig         ( w_ce_trig         [  1*ccidx+: 1] )     
        ,.i_sub_rst         ( w_sub_rst         [  1*ccidx+: 1] )        
    
        ,.i_frame_sync      ( w_cic_filt_sync  [(1                 *(ccidx+1)*(chidx+1)-1)-:                 1] )   //              input   wire    [0:0]                       
        ,.i_rin_en          ( w_cic_filt_en    [(NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN] )   //              input   wire    [NUM_ANT-1:0]               
        ,.i_rin_iq          ( w_cic_filt_iq    [(2*TOP_DIO_BW      *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW] )   //              input   wire    [2*NUM_ANT*DI_BW-1:0]       
    
        ,.o_frame_sync      ( w_cnfg_frame_sync[(1                 *(ccidx+1)*(chidx+1)-1)-:                 1] )   //              output  reg     [0:0]                       
        ,.o_ro_sync         ( w_cnfg_ro_sync   [(1                 *(ccidx+1)*(chidx+1)-1)-:                 1] )   //              output  reg     [0:0]                       
        ,.o_rout_en         ( w_cnfg_rout_en   [(NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN] )   //              output  reg     [NUM_ANT-1:0]               
        ,.o_rout_iq         ( w_cnfg_rout_iq   [(2*TOP_DIO_BW      *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW] )   //              output  reg     [2*DO_BW-1:0]       

        ,.o_start_sym       ( w_start_sym      [(4                 *(ccidx+1)*(chidx+1)-1)-:                 4] )        
    );
    
    
    // TD AGC
    
    rafe_td_agc_buf #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW(TOP_DIO_BW)
        ,.DO_BW(TOP_DIO_BW)
        ,.VENDOR(VENDOR)
        ,.READ_DELAY(35200*BAND_IDX + 8768*NUM_ANT*ccidx + 39)
        ,.READ_DELAY_SHORT(519*NUM_ANT*ccidx+39))
    u07_rafe_td_agc_buf(
         .i_clk             ( i_clk                 )         //input   wire                                              
                       
        ,.i_tagc_back_off   ( w_par_target_bo   [ 5*ccidx+: 5]    )       //input   wire    [04:0]                      ff
        ,.i_tagc_on         ( w_par_tagc_on     [ 1*ccidx+: 1]    )       //input   wire    [00:0]                        
        ,.i_rach_nfft       ( w_rach_n_fft      [ 1*ccidx+: 1]    )       //input   wire    [ 1     -1:0]                                 
        ,.i_prach_scs       ( w_rascsi          [ 2*ccidx+: 2]    )       //input   wire    [1:0]                       
        ,.i_puxch_scs       ( w_par_mpframstruct[ 8*ccidx+: 2]    )
        ,.i_ce              ( w_ce              [ 1*ccidx+: 1]    )     

        ,.i_sub_rst         ( w_sub_rst         [ 1*ccidx+: 1]    )        
        ,.i_frame_sync      ( w_cnfg_frame_sync[(1                    *(ccidx+1)*(chidx+1)-1)-:                 1]     )       //input   wire    [0:0]                                 
        ,.i_ro_sync         ( w_cnfg_ro_sync   [(1                    *(ccidx+1)*(chidx+1)-1)-:                 1]     )       //input   wire    [0:0]                       
        ,.i_rin_en          ( w_cnfg_rout_en   [(NUM_ANT/NUM_CHAIN    *(ccidx+1)*(chidx+1)-1)-: NUM_ANT/NUM_CHAIN]     )       //input   wire    [NUM_ANT-1:0]                     
        ,.i_rin_iq          ( w_cnfg_rout_iq   [(2*TOP_DIO_BW         *(ccidx+1)*(chidx+1)-1)-:      2*TOP_DIO_BW]     )       //input   wire    [2*NUM_ANT*DI_BW-1:0]             
                       
        ,.o_frame_sync      ( w_psym_sync      [( 1                   *(ccidx+1)*(chidx+1)-1)-:                    1]     )       //output  reg     [0:0]                                
        ,.o_rout_en         ( w_rout_en        [( 1                   *(ccidx+1)*(chidx+1)-1)-:                    1]     )       //output  wire    [NUM_ANT-1:0]               
        ,.o_rout_iq         ( w_rout_iq        [( 2*TOP_DIO_BW        *(ccidx+1)*(chidx+1)-1)-:         2*TOP_DIO_BW]     )       //output  wire    [2*NUM_ANT*DO_BW-1:0]         
        ,.o_tagc_gain       ( w_tagc_gain      [( 4*NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-:  4*NUM_ANT/NUM_CHAIN]     )       //output  reg     [NUM_ANT*4-1:0]             
        ,.o_tagc_lut_index  ( w_tagc_lut_index [( 5*NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-:  5*NUM_ANT/NUM_CHAIN]     )       //output  reg     [NUM_ANT*5-1:0]             
        ,.o_rssi            ( w_rssi           [(31*NUM_ANT/NUM_CHAIN *(ccidx+1)*(chidx+1)-1)-: 31*NUM_ANT/NUM_CHAIN]     )       // 31*NUM_ANT
    );
    
    end
    
    // FFT demap
    
    rafe_fft_demap #(
         .NUM_CC  (NUM_CC)
        ,.NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW(TOP_DIO_BW)
        ,.DO_BW(TOP_DIO_BW)
        ,.VENDOR(VENDOR)) 
    u08_rafe_fft_demap(    
         .i_clk             ( i_clk                 )       //                  input   wire                               
    
        ,.i_num_re          (w_num_re                             )
        ,.i_rach_nfft       (w_rach_n_fft                         )     
        ,.i_al_kbar         (w_al_kbar                            )

        ,.i_frame_sync      (w_psym_sync        [ NUM_CC*1                   *chidx+:      NUM_CC*              1]   )       //              ,   input   wire    [0:0]                      
        ,.i_ro_sync         (w_cnfg_ro_sync     [ NUM_CC*1                   *chidx+:      NUM_CC*              1]   )       //              ,   input   wire    [0:0]                       
        ,.i_rin_en          (w_rout_en          [ NUM_CC*1                   *chidx+:      NUM_CC*              1]   )       //              ,   input   wire    [NUM_ANT-1:0]              
        ,.i_rin_iq          (w_rout_iq          [ NUM_CC*2*TOP_DIO_BW        *chidx+:      NUM_CC*   2*TOP_DIO_BW]   )       //              ,   input   wire    [2*NUM_ANT*DI_BW-1:0]      
    
        ,.o_frame_sync      (w_fft_demap_sync   [ NUM_CC*1                   *chidx+:      NUM_CC*              1]   )       //              ,   output  reg     [0:0]                      
        ,.o_rout_en         (w_fft_demap_rout_en[ 1                   *chidx+:                    1]   )       //              ,   output  reg     [NUM_ANT-1:0]              
        ,.o_rout_iq         (w_fft_demap_rout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]   )       //              ,   output  reg     [2*NUM_ANT*DO_BW-1:0]      
        ,.o_rout_cnt        (w_fft_demap_rout_cnt[3                   *chidx+:                    3]   )
    );
    
    // Gain comp
    
    rafe_gain_comp #(
         .NUM_CC    ( NUM_CC)
        ,.NUM_ANT   ( (NUM_ANT*NUM_CC)   /NUM_CHAIN)
        ,.NUM_PATH  ( NUM_ANT   ) 
        ,.DI_BW     ( TOP_DIO_BW)
        ,.DO_BW     ( TOP_DIO_BW)
        ,.DLY_SYNC  ( 3'd5       ))
    u09_rafe_gain_comp(
         .i_clk                 (i_clk                  )
    
        ,.i_tagc_gain           (w_tagc_gain        [ 4*NUM_ANT*NUM_CC/NUM_CHAIN *chidx+:  4*NUM_ANT*NUM_CC/NUM_CHAIN]    )
        ,.i_tagc_lut_index      (w_tagc_lut_index   [ 5*NUM_ANT*NUM_CC/NUM_CHAIN *chidx+:  5*NUM_ANT*NUM_CC/NUM_CHAIN]    )
    
        ,.i_frame_sync          (w_fft_demap_sync   [ NUM_CC*1                   *chidx+:      NUM_CC*              1]    )
        ,.i_ro_sync             (w_cnfg_ro_sync     [ 1                   *chidx+:                    1]    )
        ,.i_uin_en              (w_fft_demap_rout_en[ 1                   *chidx+:                    1]    )
        ,.i_uin_iq              (w_fft_demap_rout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]    )
        ,.i_uin_cnt             (w_fft_demap_rout_cnt[3                   *chidx+:                    3]    )
                                                                                                        
        ,.o_frame_sync          (w_gain_comp_sync   [ NUM_CC*1                   *chidx+:      NUM_CC*              1]    )
        ,.o_uout_en             (w_gain_comp_rout_en[ 4                   *chidx+:                    4]    )
        ,.o_uout_iq             (w_gain_comp_rout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]    )
    );

    end
endgenerate

generate for(ccidx=0;ccidx<NUM_CC;ccidx=ccidx+1) begin : g03_rafe_output_if
    // Output ctrl
    
    rafe_output_ctrl #(
         .NUM_ANT   ( NUM_ANT   )
        ,.NUM_CHAIN ( NUM_CHAIN ) 
        ,.DI_BW     ( TOP_DIO_BW)
        ,.DO_BW     ( TOP_DIO_BW))
    u10_rafe_output_ctrl(
         .i_clk                 ( i_clk                         )   //         input   wire                                
    
        ,.i_par_out_tp_gen      ( w_par_out_tp_gen  [ 1*ccidx+: 1]       )   //         input   wire    [ 6     -1:0]               
        ,.i_rin_filter_idx      ( w_rin_filter_idx  [ 4*ccidx+: 4]       ) 
        ,.i_rin_num_psymbol     ( w_rin_num_psymbol [ 4*ccidx+: 4]       ) 
        ,.i_rin_prach_scs       ( w_rin_frame_struct[ 8*ccidx+: 4]       )   //input   wire    [ 4             -1:0]       
        ,.i_par_pusch_scs       ( w_par_mpframstruct[ 8*ccidx+: 2]       )   //input   wire    [ 2             -1:0]       
        ,.i_start_sym           ( w_start_sym       [ 4*NUM_CHAIN*ccidx+: 4]       )        
        ,.i_sub_rst             ( w_sub_rst         [ 1*ccidx+: 1] )    
        ,.i_ce                  ( w_ce              [ 1*ccidx+: 1] )     
        ,.i_rin_frame_idx       ( r_rin_frame_idx               )   //         input   wire    [ 8     -1:0]               
    
        ,.i_frame_sync          ( w_gain_comp_sync[ccidx]              )   //         input   wire    [1      -1:0]               
        ,.i_ro_sync             ( w_cnfg_ro_sync[ccidx]            )
        ,.i_rin_en              ( w_gain_comp_rout_en[ 1*ccidx+: 1])   //         input   wire    [NUM_ANT-1:0]               
        ,.i_rin_iq              ( w_gain_comp_rout_iq           )   //         input   wire    [2*DO_BW-1:0]               
    
        ,.o_frm_sync            ( o_rout_frame_sync  [1          *ccidx+:1           ]       )
        ,.o_frm_idx             ( o_rout_frame_idx   [8          *ccidx+:8           ]       )   //         output  wire    [8      -1:0]               
        ,.o_subfrm_idx          ( o_rout_subfrm_idx  [4          *ccidx+:4           ]       )   //         output  wire    [4      -1:0]               
        ,.o_slot_idx            ( o_rout_slot_idx    [6          *ccidx+:6           ]       )   //         output  wire    [6      -1:0]               
        ,.o_symb_idx            ( o_rout_symbol_idx  [4          *ccidx+:4           ]       )   //         output  wire    [4      -1:0]               
        ,.o_rout_en             ( o_rout_en          [NUM_ANT    *ccidx+:NUM_ANT     ]       )   //         output  wire    [NUM_ANT-1:0]               
        ,.o_rout_iq             ( o_rout_iq          [2*NUM_ANT*TOP_DIO_BW    *ccidx+:2*NUM_ANT*TOP_DIO_BW     ]       )   //         output  wire    [2*DO_BW-1:0]               
        ,.o_rout_start_re_idx   ( o_rout_start_re_idx[NUM_ANT*16 *ccidx+:NUM_ANT*16  ]       )   //         output  wire    [NUM_ANT*16-1:0]            
        ,.o_rout_start_re       ( o_rout_start_re    [NUM_ANT    *ccidx+:NUM_ANT     ]       )   //         output  wire    [NUM_ANT*1-1:0]             
        ,.o_rout_last_re        ( o_rout_last_re     [NUM_ANT    *ccidx+:NUM_ANT     ]       )   //         output  wire    [NUM_ANT*1-1:0]             

        ,.o_cnt_sym00           ( w_cnt_sym00 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym01           ( w_cnt_sym01 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym02           ( w_cnt_sym02 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym03           ( w_cnt_sym03 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym04           ( w_cnt_sym04 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym05           ( w_cnt_sym05 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym06           ( w_cnt_sym06 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym07           ( w_cnt_sym07 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym08           ( w_cnt_sym08 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym09           ( w_cnt_sym09 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym10           ( w_cnt_sym10 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym11           ( w_cnt_sym11 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym12           ( w_cnt_sym12 [32*ccidx+: 32]    ) 
        ,.o_cnt_sym13           ( w_cnt_sym13 [32*ccidx+: 32]    ) 
        ,.o_log                 ( w_output_log[14*10*ccidx +: 14*10])
    );

end
endgenerate

endmodule
