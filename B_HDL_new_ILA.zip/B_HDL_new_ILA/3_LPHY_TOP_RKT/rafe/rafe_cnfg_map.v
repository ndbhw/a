// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : config map
//  Author       : jyzoo.lee@samsung.com
//  Description  : configuration mapping for valid rach data 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.5.22  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.7.10  | taeyeong      | Modify for FSU20
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module rafe_cnfg_map
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16  
   ,parameter  CNT_BW              =   17
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from cpu
    ,   input   wire    [CNT_BW -1:0]               i_slot_offset
    ,   input   wire    [ 8     -1:0]               i_m_frm_str             // [3:0]:PUSCH SCS,[7:4]:PUSCH FFT Size       

    //--- from oran 
    ,   input   wire    [ 1     -1:0]               i_rach_nfft
    ,   input   wire    [ 4     -1:0]               i_num_psym  
    ,   input   wire    [14     -1:0]               i_ro_offset 
    ,   input   wire    [ 2     -1:0]               i_cic_offset
    ,   input   wire    [ 4     -1:0]               i_ra_scs       // [3:0]:PRACH SCS, oRAN                                    

    ,   input   wire    [ 1     -1:0]               i_sub_rst 
    ,   input   wire    [ 1     -1:0]               i_f0_case0
    ,   input   wire    [ 1     -1:0]               i_ce
    ,   input   wire    [ 1     -1:0]               i_ce_trig

    //--- from deci_filt
    ,   input   wire                                i_frame_sync           
    ,   input   wire    [NUM_ANT-1:0]               i_rin_en           
    ,   input   wire    [2*DI_BW-1:0]               i_rin_iq           

    //--- to rach_td_agc
    ,   output  reg                                 o_frame_sync           
    ,   output  reg                                 o_ro_sync           
    ,   output  reg     [NUM_ANT-1:0]               o_rout_en
    ,   output  reg     [2*DO_BW-1:0]               o_rout_iq      

    //--- to output_ctrl            
    ,   output  reg     [ 4     -1:0]               o_start_sym    
);

//Parameter config_map
localparam  MAX_LEN                 =       17'H1E000       ;
localparam  MP_PUSCH_FFT_0512       =       4'd9            ;
localparam  MP_PUSCH_FFT_1024       =       4'd10           ;
localparam  MP_PUSCH_FFT_2048       =       4'd11           ;
localparam  DLY_SYNC                =       22'd4           ;
localparam  MAX_PATH                =       8               ;

//logic variable
genvar gidx ;

// slot sync gen
wire [0:0]  w_slot_sync_15k ;
wire [3:0]  w_symb_numb_15k ;
wire [0:0]  w_slot_sync_30k ;

reg     [ 3     -1:0]               r_set_mu       ;

always @(posedge i_clk) begin
    case(i_ra_scs) 
        4'b0000 : r_set_mu <= 3'b000;
        4'b0001 : r_set_mu <= 3'b001;
        4'b0010 : r_set_mu <= 3'b010;
        4'b1100 : r_set_mu <= 3'b000;
        4'b1110 : r_set_mu <= 3'b000;
        default : r_set_mu <= 3'b000;
    endcase
end

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'd0                  ) 
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         (                       )   
    ,.o_slot_sync           ( w_slot_sync_15k       )   
    ,.o_subfrm              (                       )
    ,.o_symbol_sync         (                       )          
    ,.o_slot                (                       )          
    ,.o_symbol              ( w_symb_numb_15k       )          
);

ref_vsync_gen u01_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'd1                  )
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         (                       )   
    ,.o_slot_sync           ( w_slot_sync_30k       )   
    ,.o_subfrm              (                       )
    ,.o_symbol_sync         (                       )          
    ,.o_slot                (                       )          
    ,.o_symbol              (                       )          
);


// cnt

reg              r_psym_done    = 1;

reg [20 -1:0] r_cnt_m0_p1       ;
reg [20 -1:0] r_cnt_m0_p3       ;
reg [ 2 -1:0] r_cnt_m0_p3_tmp   ;
reg [20 -1:0] r_cnt_m1_p1       ;

always @(posedge i_clk) begin
    if(w_slot_sync_15k & r_psym_done) begin
        r_cnt_m0_p1    <= 20'b0            ; 
    end
    else begin
        r_cnt_m0_p1    <= r_cnt_m0_p1 +20'b1  ;
    end
end

always @(posedge i_clk) begin
    if(w_slot_sync_15k & r_psym_done) begin
        r_cnt_m0_p3    <=  20'b0;
        r_cnt_m0_p3_tmp<=   2'b0;
    end
    else if(r_cnt_m0_p3_tmp == 2'b10 ) begin
        r_cnt_m0_p3    <= r_cnt_m0_p3     +20'b1;
        r_cnt_m0_p3_tmp<=  2'b0;
    end
    else begin
        r_cnt_m0_p3_tmp<= r_cnt_m0_p3_tmp + 2'b1;
    end
end

always @(posedge i_clk) begin
    if(w_slot_sync_30k & r_psym_done) begin
        r_cnt_m1_p1    <= 20'b0            ; 
    end
    else begin
        r_cnt_m1_p1    <= r_cnt_m1_p1 +20'b1  ;
    end
end

// i_path_ratio 2 4 8 16 32
// i_deci_ratio 3 6 12 24 48 / 1 2 4 16

reg [20 -1:0] r_offs_cnt;

always @(posedge i_clk) begin
    case(i_ra_scs)
        4'b0000 : r_offs_cnt <= {5'b0,r_cnt_m0_p1[19:5]}; // x32 
        4'b0001 : r_offs_cnt <= {4'b0,r_cnt_m1_p1[19:4]}; // x16 
        4'b0010 : r_offs_cnt <= {3'b0,r_cnt_m0_p1[19:3]}; // x 8  TBD
        4'b1100 : r_offs_cnt <= {6'b0,r_cnt_m0_p3[19:6]}; // x96  x192
        4'b1110 : r_offs_cnt <= {3'b0,r_cnt_m0_p3[19:3]}; // x24 
        default : r_offs_cnt <= {6'b0,r_cnt_m0_p3[19:6]}; // x96  x192
    endcase
end

// input reg
reg [NUM_ANT-1:0]   r_rin_en         ;  
reg [NUM_ANT-1:0]   rr_rin_en        ;  
reg [NUM_ANT-1:0]   rrr_rin_en       ;  
reg [2*DI_BW-1:0]   r_rin_iq    [NUM_ANT-1:0]   ;             

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_in_sep
    always@(posedge i_clk) begin
        r_rin_en[gidx]   <= i_rin_en[gidx]     ;
        rr_rin_en[gidx]  <= r_rin_en[gidx]     ;  
        rrr_rin_en[gidx] <= rr_rin_en[gidx]    ;  
        if(i_rin_en[gidx]) begin
            r_rin_iq[gidx]  <=  i_rin_iq[(2*DI_BW-1)-:2*DI_BW] ;
        end
    end
end
endgenerate

// calculate offset
reg [4     -1:0] r_nfft         ;
reg [CNT_BW-1:0] r_tot_ro_offset;
reg [CNT_BW-1:0] r_tot_psym_len ;
reg [CNT_BW-1:0] r_scs_offset   ;

always@(posedge i_clk) begin
    case({i_m_frm_str[7:0],i_ra_scs})
        12'b0011_0001_0000  : r_scs_offset <= 17'd5;        
        default             : r_scs_offset <= 17'd3;
    endcase
end

always@(posedge i_clk) begin
    if(i_rach_nfft) 
        r_nfft  <= MP_PUSCH_FFT_1024;
    else
        r_nfft  <= MP_PUSCH_FFT_0512;
end

always@(posedge i_clk) begin
    if(|r_rin_en) begin
        r_tot_ro_offset <= i_slot_offset+{3'd0,i_ro_offset}+{15'd0,i_cic_offset} + r_scs_offset ;
        r_tot_psym_len  <= {13'd0,i_num_psym}<<r_nfft  ;
    end
end

reg [0:0] r_ro_start ;
always@(posedge i_clk) begin
    if(r_rin_en[0] && (r_offs_cnt==r_tot_ro_offset)) begin
        r_ro_start <= 1'd1 ;
    end
    else begin
        r_ro_start <= 1'd0 ;
    end
end

reg [CNT_BW-1:0] r_psym_smp_cnt = 0 ;


always@(posedge i_clk) begin
//    if(i_frame_sync | i_sub_rst) begin
//    if((i_frame_sync & ~i_ce) | i_sub_rst) begin
    if(i_sub_rst) begin
        r_psym_smp_cnt  <=  18'd0  ;
        r_psym_done     <=   1'b1  ;    
    end
    else if(r_ro_start) begin
        if(i_ce) begin
            r_psym_smp_cnt  <=  18'd147;     // cp 876/1024
            r_psym_done     <=   1'b0  ;    
        end
        else begin
            r_psym_smp_cnt  <=  18'd0  ;
            r_psym_done     <=   1'b0  ;    
        end
    end
    else if((~r_psym_done)&&(rr_rin_en[0])&&(r_psym_smp_cnt<r_tot_psym_len)) begin
        r_psym_smp_cnt  <=  r_psym_smp_cnt + 1'd1   ;
    end
    else if(r_psym_smp_cnt == r_tot_psym_len) begin
        r_psym_done     <=   1'b1  ;    
    end
end

// add zero padding

// i_ce_trig
reg [9  -1: 0]  r_zcnt;
reg             r_zen;
reg             r_ce_trig;

always @(posedge i_clk) begin
    if(i_ce_trig) begin
        r_zen   <= 1;
        r_zcnt  <= 0;
    end
    else if(r_zcnt == 9'd295) begin
        r_zen   <= 0;
    end
    else if(r_zen) begin
        r_zcnt  <=  r_zcnt  + 9'b1;
    end
end

always @(posedge i_clk) begin
    r_ce_trig   <=  i_ce_trig;
end

// capture fft size sample

reg [MAX_PATH -1:0]   r_rout_en                     ;  
reg [2*DO_BW  -1:0]   r_rout_iq    [MAX_PATH-1:0];//   = { 0, 0, 0, 0, 0, 0, 0, 0} ;        

always @(posedge i_clk) begin
//    if(i_frame_sync | i_sub_rst) begin
    if(i_sub_rst) begin
        r_rout_en   <= {MAX_PATH{1'b0}};
    end
    else if(r_zen) begin
        r_rout_en   <= {7'b0,r_zen} + r_zcnt[0];
    end
    else if((~r_psym_done)&&(|rrr_rin_en) && (r_psym_smp_cnt < r_tot_psym_len)) begin
        r_rout_en   <= {{(8-NUM_ANT){1'b0}},rrr_rin_en};
    end
    else begin
        r_rout_en   <= {MAX_PATH{1'b0}};
    end
end

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_cnfg_map_out
    always@(posedge i_clk) begin
        //if(i_frame_sync | i_sub_rst) begin
        if(i_sub_rst) begin            
            r_rout_iq[gidx]     <=  {2*DO_BW{1'b0}};
            r_rout_iq[gidx+4]   <=  {2*DO_BW{1'b0}};
        end
        else if(r_zen) begin
            r_rout_iq[gidx]     <=  {2*DO_BW{1'b0}};
            r_rout_iq[gidx+4]   <=  {2*DO_BW{1'b0}};
        end
        else if((rrr_rin_en[gidx])&&(r_psym_smp_cnt<r_tot_psym_len)) begin
            r_rout_iq[gidx]     <=  r_rin_iq[gidx]   ;
        end
    end
end
endgenerate


// output reg

always@(posedge i_clk) begin
    o_rout_en <=  r_rout_en[NUM_ANT-1:0] ;
end

always@(posedge i_clk) begin
    case(r_rout_en)
        8'b0000_0001 : o_rout_iq <= r_rout_iq[0];
        8'b0000_0010 : o_rout_iq <= r_rout_iq[1];
        8'b0000_0100 : o_rout_iq <= r_rout_iq[2];
        8'b0000_1000 : o_rout_iq <= r_rout_iq[3];
        8'b0001_0000 : o_rout_iq <= r_rout_iq[4];
        8'b0010_0000 : o_rout_iq <= r_rout_iq[5];
        8'b0100_0000 : o_rout_iq <= r_rout_iq[6];
        8'b1000_0000 : o_rout_iq <= r_rout_iq[7];
        default      : o_rout_iq <= {(2*DO_BW){1'b0}};
    endcase
end

// always@(posedge i_clk) begin
//     if((~r_psym_done)&&(rrr_rin_en[0])&&(r_psym_smp_cnt==0)) begin
//         o_ro_sync  <= 1'd1 ;
//     end
//     else begin
//         o_ro_sync  <= 1'd0 ;
//     end
// end
always@(posedge i_clk) begin
    if((i_f0_case0)&&(~r_psym_done)&&(rrr_rin_en[0])&&(r_psym_smp_cnt==0)) begin
        o_ro_sync   <= 1'd1                   ;
        o_start_sym <= w_symb_numb_15k - 4'b1 ;
    end
    else if((~r_psym_done)&&(rrr_rin_en[0])&&(r_psym_smp_cnt==0)) begin
        o_ro_sync  <= 1'd1 ;
        o_start_sym <= w_symb_numb_15k  ;
    end
    else if((i_ce) & (r_ce_trig)) begin
        o_ro_sync  <= r_ce_trig ;
//        o_start_sym <= w_symb_numb_15k  ;
        o_start_sym <= 4'b0  ;
    end
    else begin
        o_ro_sync  <= 1'd0 ;
        o_start_sym <= o_start_sym  ;
    end
end

reg r_frame_sync ;
reg rr_frame_sync ;
reg rrr_frame_sync ;
reg rrrr_frame_sync ;

always@(posedge i_clk) begin
    r_frame_sync    <=  i_frame_sync      ;
    rr_frame_sync   <=  r_frame_sync      ;
    rrr_frame_sync  <=  rr_frame_sync     ;
    rrrr_frame_sync <=  rrr_frame_sync    ;
    o_frame_sync    <=  rrrr_frame_sync   ;
end

endmodule
