// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : rafe_cpu_param_if 
//  Author       : jyzoo.lee@samsung.com
//  Description  : cpu parameter interface for RAFE
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | taeyeong      | Modify to RAFE
//  ------------------------------------------------------------------------------------ 
//
////////////////////////////////////////////////////////////////////////////////////////

module rafe_cpu_param_if
#(
    parameter   ADDR_OFFSET         =16'h9000       // CPU IF Address Offset    
   ,parameter   DLY_REG_RD          =       5       // READ Latency
   ,parameter   AW                  =      16       // CPU IF Address Bit Width
   ,parameter   DW                  =      32       // CPU IF Data Bit Width 
   ,parameter   RU_MODE             =       0
)(
    //--- reset & clk
        input   wire                                i_clk 
    //,   input   wire                                i_rst

    //--- cpu interface
    ,   input   wire    [AW     -1:0]               i_cpu_addr
    ,   input   wire    [ 1     -1:0]               i_cpu_wren
    ,   input   wire    [DW     -1:0]               i_cpu_wdata
    ,   input   wire    [ 1     -1:0]               i_cpu_rden
    ,   output  wire    [DW     -1:0]               o_cpu_rdata
    ,   output  wire    [ 1     -1:0]               o_cpu_rd_valid

    //--- Parsed parameter 
    ,   output  reg     [ 1     -1:0]               o_par_freq_shift_sel 
    ,   output  reg     [ 1     -1:0]               o_par_iq_swap        
    ,   output  reg     [ 1     -1:0]               o_par_in_tp_gen      
    ,   output  reg     [ 1     -1:0]               o_par_out_tp_gen     
    ,   output  reg     [ 1     -1:0]               o_par_debug_mode 
    ,   output  reg     [ 4     -1:0]               o_par_debug_subfrm 

    ,   output  reg     [ 1     -1:0]               o_par_rafe_en        
    ,   output  reg     [ 1     -1:0]               o_par_rafe_band_en   
    ,   output  reg     [ 1     -1:0]               o_par_sw_reset       
    ,   output  reg     [17     -1:0]               o_par_slot_offset    
    ,   output  reg     [ 1     -1:0]               o_par_tagc_on        
    ,   output  reg     [ 5     -1:0]               o_par_target_bo      
    ,   output  reg     [ 8     -1:0]               o_par_mpframstruct   
    ,   output  reg     [ 1     -1:0]               o_par_freq_7p5k      
    ,   output  reg     [16     -1:0]               o_par_rach_freq_shift
    ,   output  reg     [16     -1:0]               o_par_adv_offset

    ,   output  reg     [ 1     -1:0]               o_par_ant_cal_bypass
    ,   output  reg     [ 4     -1:0]               o_par_ant_cal_shift

    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w00
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w01
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w02
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w03
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w04
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w05
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w06
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w07
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w08
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w09

    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w10
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w11
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w12
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w13
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w14
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w15
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w16
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w17
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w18
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w19

    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w20
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w21
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w22
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w23
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w24
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w25
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w26
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w27
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w28
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w29

    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w30
    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w31
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w32
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w33
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w34
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w35
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w36
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w37
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w38
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w39
//
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w40
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w41
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w42
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w43
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w44
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w45
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w46
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w47
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w48
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w49
//
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w50
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w51
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w52
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w53
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w54
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w55
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w56
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w57
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w58
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w59
//
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w60
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w61
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w62
//    ,   output  reg     [DW     -1:0]               o_par_ant_cal_w63

    ,   output  reg     [4      -1:0]               o_par_filter_idx     
    ,   output  reg     [16     -1:0]               o_par_time_offset    
    ,   output  reg     [8      -1:0]               o_par_frame_struct      
    ,   output  reg     [16     -1:0]               o_par_cp_length      
    ,   output  reg     [4      -1:0]               o_par_num_psymbol     
    ,   output  reg     [24     -1:0]               o_par_freq_offset    
    ,   output  reg     [3      -1:0]               o_par_num_ro   
    ,   output  reg     [8      -1:0]               o_par_num_prbc

    ,   output  reg     [1      -1:0]               o_par_freq_init_set
    ,   output  reg     [12     -1:0]               o_par_freq_init_val

    //--- Report Register
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro0
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro1
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro2
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro3
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro4
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro5
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro6
    ,   input   wire    [DW     -1:0]               i_rpt_rssi_ro7

    //--- oRAN param read
    ,   input   wire    [4      -1:0]               i_rin_filter_idx     
    ,   input   wire    [16     -1:0]               i_rin_time_offset    
    ,   input   wire    [8      -1:0]               i_rin_frame_struct      
    ,   input   wire    [16     -1:0]               i_rin_cp_length      
    ,   input   wire    [4      -1:0]               i_rin_num_psymbol     
    ,   input   wire    [24     -1:0]               i_rin_freq_offset    
    ,   input   wire    [3      -1:0]               i_rin_num_ro    
    ,   input   wire    [8      -1:0]               i_rin_num_prbc  
    ,   input   wire    [10     -1:0]               i_rin_start_prbc   
    ,   input   wire    [32     -1:0]               i_rin_rec_oran    

    //--- output sym cnt
    ,   input   wire    [32     -1:0]               i_cnt_s00
    ,   input   wire    [32     -1:0]               i_cnt_s01
    ,   input   wire    [32     -1:0]               i_cnt_s02
    ,   input   wire    [32     -1:0]               i_cnt_s03
    ,   input   wire    [32     -1:0]               i_cnt_s04
    ,   input   wire    [32     -1:0]               i_cnt_s05
    ,   input   wire    [32     -1:0]               i_cnt_s06
    ,   input   wire    [32     -1:0]               i_cnt_s07
    ,   input   wire    [32     -1:0]               i_cnt_s08
    ,   input   wire    [32     -1:0]               i_cnt_s09
    ,   input   wire    [32     -1:0]               i_cnt_s10
    ,   input   wire    [32     -1:0]               i_cnt_s11
    ,   input   wire    [32     -1:0]               i_cnt_s12
    ,   input   wire    [32     -1:0]               i_cnt_s13
    ,   input   wire    [14*10  -1:0]               i_output_log
);

//Parameter
localparam DLY_REG_RD_OUT = (DLY_REG_RD == 2)? 0 : DLY_REG_RD -3;
localparam ADD_OFFSET     = (RU_MODE == 1)? 16'h0000 : 16'h4000;

//Logic Variable
genvar gidx ;

reg [  AW       -1:0]  r_cpu_addr                        ;    
reg [   1       -1:0]  r_cpu_wren                        ;
reg [  DW       -1:0]  r_cpu_wdata                       ;
reg [   1       -1:0]  r_cpu_rden                        ;

always@(posedge i_clk) begin
    if(i_cpu_wren) begin
        r_cpu_wren      <=    i_cpu_wren    ;
        r_cpu_wdata     <=    i_cpu_wdata   ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else if(i_cpu_rden) begin
        r_cpu_rden      <=    i_cpu_rden    ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else begin
        r_cpu_wren      <=    1'd0    ;
        r_cpu_rden      <=    1'd0    ;
    end
end

reg [   1       -1:0]  rr_cpu_rden [2   -1:0] ;
reg [  AW       -1:0]  rr_cpu_addr [2   -1:0] ; 

always@(posedge i_clk) begin
    if(i_cpu_rden) begin
        rr_cpu_rden[0] <=     i_cpu_rden    ;
        rr_cpu_addr[0] <=     i_cpu_addr    ; 
        rr_cpu_rden[1] <=     i_cpu_rden    ;
        rr_cpu_addr[1] <=     i_cpu_addr    ; 
    end
    else begin
        rr_cpu_rden[0] <=     1'b0    ;
        rr_cpu_rden[1] <=     1'b0    ;
    end
end


//demux & parsing
always@(posedge i_clk) begin
    //if(i_rst) begin
    //    o_par_iq_swap           <=   1'b0; 
    //    o_par_freq_shift_sel    <=   1'b0; 
    //    o_par_in_tp_gen         <=   1'b0;
    //    o_par_out_tp_gen        <=   1'b0;
    //    o_par_debug_mode        <=   1'b0;
    //    o_par_debug_subfrm      <=   4'd7;

    //    o_par_filter_idx        <=   4'b1;     
    //    o_par_time_offset       <=  16'h0c60;     
    //    o_par_frame_struct      <=   8'hbc;     
    //    o_par_cp_length         <=  16'b0;     
    //    o_par_num_psymbol       <=   4'b1;     
    //    o_par_freq_offset       <=  24'hffeaa0;     
    //    o_par_num_ro            <=   3'b1;     

    //    o_par_rafe_en           <=  1'b1;
    //    o_par_rafe_band_en      <=  1'b1;
    //    o_par_sw_reset          <=  1'b0; 
    //    o_par_slot_offset       <= 17'b0; 
    //    o_par_tagc_on           <=  1'b1; 
    //    o_par_target_bo         <=  5'b0; 
    //    o_par_mpframstruct      <= 32'b0; 
    //    o_par_freq_7p5k         <=  1'b0; 
    //    o_par_rach_freq_shift   <= 16'b0; 
    //    o_par_rach_k_bar        <=  8'b1; 
    //end
    if(r_cpu_wren) begin
        case(r_cpu_addr)
            ADDR_OFFSET+ADD_OFFSET+16'h0080    :   o_par_iq_swap           <=  r_cpu_wdata[ 1     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h0084    :   o_par_in_tp_gen         <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h0088    :   o_par_out_tp_gen        <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h008C    :   o_par_freq_shift_sel    <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h0090    :   o_par_rach_freq_shift   <=  r_cpu_wdata[16     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0138    :   o_par_adv_offset        <=  r_cpu_wdata[16     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0098    :   o_par_debug_mode        <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h009C    :   o_par_debug_subfrm      <=  r_cpu_wdata[ 4     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h00A0    :   o_par_filter_idx        <=  r_cpu_wdata[ 4     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00A4    :   o_par_time_offset       <=  r_cpu_wdata[16     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00A8    :   o_par_frame_struct      <=  r_cpu_wdata[ 8     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00AC    :   o_par_cp_length         <=  r_cpu_wdata[16     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B0    :   o_par_num_psymbol       <=  r_cpu_wdata[ 4     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B4    :   o_par_freq_offset       <=  r_cpu_wdata[24     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B8    :   o_par_num_ro            <=  r_cpu_wdata[ 3     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00BC    :   o_par_num_prbc          <=  r_cpu_wdata[ 8     -1:0];   

            ADDR_OFFSET+ADD_OFFSET+16'h00F0    :   o_par_freq_init_set     <=  r_cpu_wdata[ 1     -1:0];              
            ADDR_OFFSET+ADD_OFFSET+16'h00F4    :   o_par_freq_init_val     <=  r_cpu_wdata[12     -1:0];              

            ADDR_OFFSET+ADD_OFFSET+16'h0100    :   o_par_rafe_en           <=  r_cpu_wdata[ 1     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h0104    :   o_par_rafe_band_en      <=  r_cpu_wdata[ 1     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h0108    :   o_par_sw_reset          <=  r_cpu_wdata[ 1     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h010C    :   o_par_mpframstruct[3:0] <=  r_cpu_wdata[ 4     -1:0];  // PUSCH SCS
            ADDR_OFFSET+ADD_OFFSET+16'h0110    :   o_par_mpframstruct[7:4] <=  r_cpu_wdata[ 4     -1:0];  // PUSCH FFT

            ADDR_OFFSET+ADD_OFFSET+16'h0120    :   o_par_freq_7p5k         <=  r_cpu_wdata[ 1     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0304    :   o_par_slot_offset       <=  r_cpu_wdata[17     -1:0];  

            ADDR_OFFSET+ADD_OFFSET+16'h0388    :   o_par_target_bo         <=  r_cpu_wdata[ 5     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h038C    :   o_par_tagc_on           <=  r_cpu_wdata[ 1     -1:0];  

            ADDR_OFFSET+ADD_OFFSET+16'h0484    :   o_par_ant_cal_bypass    <=  r_cpu_wdata[ 1     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0480    :   o_par_ant_cal_shift     <=  r_cpu_wdata[ 4     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0400    :   o_par_ant_cal_w00       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0404    :   o_par_ant_cal_w01       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0408    :   o_par_ant_cal_w02       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h040C    :   o_par_ant_cal_w03       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0410    :   o_par_ant_cal_w04       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0414    :   o_par_ant_cal_w05       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0418    :   o_par_ant_cal_w06       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h041C    :   o_par_ant_cal_w07       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0420    :   o_par_ant_cal_w08       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0424    :   o_par_ant_cal_w09       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0428    :   o_par_ant_cal_w10       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h042C    :   o_par_ant_cal_w11       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0430    :   o_par_ant_cal_w12       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0434    :   o_par_ant_cal_w13       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0438    :   o_par_ant_cal_w14       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h043C    :   o_par_ant_cal_w15       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0440    :   o_par_ant_cal_w16       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0444    :   o_par_ant_cal_w17       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0448    :   o_par_ant_cal_w18       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h044C    :   o_par_ant_cal_w19       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0450    :   o_par_ant_cal_w20       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0454    :   o_par_ant_cal_w21       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0458    :   o_par_ant_cal_w22       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h045C    :   o_par_ant_cal_w23       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0460    :   o_par_ant_cal_w24       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0464    :   o_par_ant_cal_w25       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0468    :   o_par_ant_cal_w26       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h046C    :   o_par_ant_cal_w27       <=  r_cpu_wdata[DW     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0470    :   o_par_ant_cal_w28       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0474    :   o_par_ant_cal_w29       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h0478    :   o_par_ant_cal_w30       <=  r_cpu_wdata[DW     -1:0]; 
            ADDR_OFFSET+ADD_OFFSET+16'h047C    :   o_par_ant_cal_w31       <=  r_cpu_wdata[DW     -1:0]; 

//            ADDR_OFFSET+ADD_OFFSET+16'h02C0    :   o_par_ant_cal_w32       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02C4    :   o_par_ant_cal_w33       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02C8    :   o_par_ant_cal_w34       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02CC    :   o_par_ant_cal_w35       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02D0    :   o_par_ant_cal_w36       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02D4    :   o_par_ant_cal_w37       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02D8    :   o_par_ant_cal_w38       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02DC    :   o_par_ant_cal_w39       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02E0    :   o_par_ant_cal_w40       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02E4    :   o_par_ant_cal_w41       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02E8    :   o_par_ant_cal_w42       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02EC    :   o_par_ant_cal_w43       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02F0    :   o_par_ant_cal_w44       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02F4    :   o_par_ant_cal_w45       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02F8    :   o_par_ant_cal_w46       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h02FC    :   o_par_ant_cal_w47       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0300    :   o_par_ant_cal_w48       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0304    :   o_par_ant_cal_w49       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0308    :   o_par_ant_cal_w50       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h030C    :   o_par_ant_cal_w51       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0310    :   o_par_ant_cal_w52       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0314    :   o_par_ant_cal_w53       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0318    :   o_par_ant_cal_w54       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h031C    :   o_par_ant_cal_w55       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0320    :   o_par_ant_cal_w56       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0324    :   o_par_ant_cal_w57       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0328    :   o_par_ant_cal_w58       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h032C    :   o_par_ant_cal_w59       <=  r_cpu_wdata[DW     -1:0]; 
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0330    :   o_par_ant_cal_w60       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0334    :   o_par_ant_cal_w61       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h0338    :   o_par_ant_cal_w62       <=  r_cpu_wdata[DW     -1:0]; 
//            ADDR_OFFSET+ADD_OFFSET+16'h033C    :   o_par_ant_cal_w63       <=  r_cpu_wdata[DW     -1:0]; 
        endcase                                                      
    end                                                               
end                                                                   

reg [0:0]     r_mux_rd0_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd0_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(rr_cpu_rden[0]) begin
        case(rr_cpu_addr[0])
            ADDR_OFFSET+ADD_OFFSET+16'h0040    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s00    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0044    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s01    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0048    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s02    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h004C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s03    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0050    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s04    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0054    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s05    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0058    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s06    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h005C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s07    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0060    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s08    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0064    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s09    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0068    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s10    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h006C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s11    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0070    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s12    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0074    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_s13    ; end
            
            ADDR_OFFSET+ADD_OFFSET+16'h0200    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {i_output_log[14*0+10 +: 4], 2'b0, i_output_log[14*0+4 +: 6], i_output_log[14*0+0 +: 4], i_output_log[14*1+10 +: 4], 2'b0, i_output_log[14*1+4 +: 6], i_output_log[14*1+0 +: 4]}    ; end
            ADDR_OFFSET+ADD_OFFSET+16'h0204    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {i_output_log[14*2+10 +: 4], 2'b0, i_output_log[14*2+4 +: 6], i_output_log[14*2+0 +: 4], i_output_log[14*3+10 +: 4], 2'b0, i_output_log[14*3+4 +: 6], i_output_log[14*3+0 +: 4]}    ; end
            ADDR_OFFSET+ADD_OFFSET+16'h0208    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {i_output_log[14*4+10 +: 4], 2'b0, i_output_log[14*4+4 +: 6], i_output_log[14*4+0 +: 4], i_output_log[14*5+10 +: 4], 2'b0, i_output_log[14*5+4 +: 6], i_output_log[14*5+0 +: 4]}    ; end
            ADDR_OFFSET+ADD_OFFSET+16'h020C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {i_output_log[14*6+10 +: 4], 2'b0, i_output_log[14*6+4 +: 6], i_output_log[14*6+0 +: 4], i_output_log[14*7+10 +: 4], 2'b0, i_output_log[14*7+4 +: 6], i_output_log[14*7+0 +: 4]}    ; end
            ADDR_OFFSET+ADD_OFFSET+16'h0210    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {i_output_log[14*8+10 +: 4], 2'b0, i_output_log[14*8+4 +: 6], i_output_log[14*8+0 +: 4], i_output_log[14*9+10 +: 4], 2'b0, i_output_log[14*9+4 +: 6], i_output_log[14*9+0 +: 4]}    ; end

            ADDR_OFFSET+ADD_OFFSET+16'h0080    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_iq_swap         }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h008C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_freq_shift_sel  }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h0084    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_in_tp_gen       }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h0088    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_out_tp_gen      }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h0098    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_debug_mode      }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h009C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_debug_subfrm    }; end 
                                
            ADDR_OFFSET+ADD_OFFSET+16'h00A0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}},o_par_filter_idx       }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00A4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}},o_par_time_offset      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00A8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 8){1'b0}},o_par_frame_struct     }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00AC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}},o_par_cp_length        }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}},o_par_num_psymbol      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-24){1'b0}},o_par_freq_offset      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}},o_par_num_ro           }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00BC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}},o_par_num_prbc         }; end

            ADDR_OFFSET+ADD_OFFSET+16'h00F0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}},o_par_freq_init_set    }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00F4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-12){1'b0}},o_par_freq_init_val    }; end
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0100    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_rafe_en         }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0104    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_rafe_band_en    }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0108    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_sw_reset        }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0304    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-17){1'b0}}, o_par_slot_offset     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h038C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_tagc_on         }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0388    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 5){1'b0}}, o_par_target_bo       }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h010C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_mpframstruct[3:0]}; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0110    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_mpframstruct[7:4]}; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0120    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_freq_7p5k       }; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0138    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, o_par_adv_offset      }; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0090    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, o_par_rach_freq_shift }; end  
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0484    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_ant_cal_bypass  }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0480    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_ant_cal_shift   }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0390    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro0    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0394    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro1    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0398    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro2    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h039C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro3    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A0    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro4    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A4    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro5    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A8    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro6    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03AC    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro7    ; end 

            ADDR_OFFSET+ADD_OFFSET+16'h00C0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}},i_rin_filter_idx       }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00C4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-24){1'b0}},i_rin_rec_oran[3:0],4'b0,i_rin_time_offset      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00C8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 8){1'b0}},i_rin_frame_struct     }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00CC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}},i_rin_cp_length        }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}},i_rin_num_psymbol      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-24){1'b0}},i_rin_freq_offset      }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}},i_rin_num_ro           }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00DC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-18){1'b0}},i_rin_start_prbc, i_rin_num_prbc}; end
            ADDR_OFFSET+ADD_OFFSET+16'h00E0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <=                  i_rin_rec_oran          ; end

            default                 :   begin r_mux_rd0_en[0] <= 1'd0; r_mux_rd0_data[0] <= 32'hEFEF_EFEF     ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd0_en [0]  <=  1'd0    ;    
    end
end                               



reg [0:0]     r_mux_rd1_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd1_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(rr_cpu_rden[1]) begin
        case(rr_cpu_addr[1])
            ADDR_OFFSET+ADD_OFFSET+16'h0400    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w00     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0404    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w01     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0408    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w02     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h040C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w03     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0410    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w04     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0414    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w05     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0418    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w06     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h041C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w07     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0420    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w08     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0424    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w09     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0428    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w10     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h042C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w11     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0430    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w12     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0434    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w13     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0438    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w14     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h043C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w15     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0440    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w16     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0444    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w17     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0448    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w18     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h044C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w19     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0450    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w20     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0454    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w21     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0458    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w22     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h045C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w23     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0460    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w24     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0464    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w25     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0468    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w26     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h046C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w27     }; end    
                                
            ADDR_OFFSET+ADD_OFFSET+16'h0470    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w28     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0474    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w29     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0478    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w30     }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h047C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w31     }; end    

//            ADDR_OFFSET+ADD_OFFSET+16'h02C0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w32     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02C4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w33     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02C8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w34     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02CC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w35     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02D0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w36     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02D4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w37     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02D8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w38     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02DC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w39     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02E0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w40     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02E4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w41     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02E8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w42     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02EC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w43     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h02F0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w44     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02F4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w45     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02F8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w46     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h02FC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w47     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0300    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w48     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0304    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w49     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0308    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w50     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h030C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w51     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0310    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w52     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0314    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w53     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0318    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w54     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h031C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w55     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0320    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w56     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0324    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w57     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0328    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w58     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h032C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w59     }; end    
//
//            ADDR_OFFSET+ADD_OFFSET+16'h0330    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w60     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0334    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w61     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h0338    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w62     }; end    
//            ADDR_OFFSET+ADD_OFFSET+16'h033C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {                 o_par_ant_cal_w63     }; end    

            default                 :   begin r_mux_rd1_en[0] <= 1'd0; r_mux_rd1_data[0] <= 32'hEFEF_EFEF     ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd1_en [0]  <=  1'd0    ;    
    end
end                               

reg [0:0]     r_mux_rd_en    [DLY_REG_RD_OUT+1:0]  ;
reg [DW-1:0]  r_mux_rd_data  [DLY_REG_RD_OUT+1:0]  ;

always @(posedge i_clk) begin
    if     (r_mux_rd0_en[0]) begin r_mux_rd_en[0] <= r_mux_rd0_en[0]; r_mux_rd_data[0] <= r_mux_rd0_data[0]; end
    else if(r_mux_rd1_en[0]) begin r_mux_rd_en[0] <= r_mux_rd1_en[0]; r_mux_rd_data[0] <= r_mux_rd1_data[0]; end
    else                     begin r_mux_rd_en[0] <= 1'b0;  end
end

generate for(gidx=1;gidx<DLY_REG_RD_OUT+2;gidx=gidx+1) begin : g00_reg_rd_dly 
always@(posedge i_clk) begin
    if(r_mux_rd_en    [gidx-1]) begin
        r_mux_rd_en    [gidx]  <=  r_mux_rd_en    [gidx-1]    ;    
        r_mux_rd_data  [gidx]  <=  r_mux_rd_data  [gidx-1]    ;    
    end  
    else begin
        r_mux_rd_en    [gidx]  <=  1'd0    ;    
    end
end                               
end
endgenerate

assign  o_cpu_rd_valid  =   r_mux_rd_en    [DLY_REG_RD_OUT]   ;   
assign  o_cpu_rdata     =   r_mux_rd_data  [DLY_REG_RD_OUT]   ;   

endmodule                                                             
