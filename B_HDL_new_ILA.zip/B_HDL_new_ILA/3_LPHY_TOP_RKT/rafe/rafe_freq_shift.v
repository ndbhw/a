// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : freq_shift
//  Author       : jyzoo.lee@samsung.com
//  Description  : frequency shift for prach
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.5.18  | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2020.6.29  | taeyeong      | Modify for FSU20                                       
//  ------------+---------------+-------------------------------------------------------
/////////////////////////////////////////////////////////////////////////////////////////

module rafe_freq_shift
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16           
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from rafe_cc_top
    ,   input   wire                                i_frame_sync           
    ,   input   wire    [NUM_ANT-1:0]               i_rin_en           
    ,   input   wire    [2*DI_BW-1:0]               i_rin_iq           
    ,   input   wire    [  DI_BW-1:0]               i_p_cos              
    ,   input   wire    [  DI_BW-1:0]               i_n_sin           

    //--- to deci_filt
    ,   output  wire                                o_frame_sync           
    ,   output  wire    [NUM_ANT-1:0]               o_rout_en
    ,   output  wire    [2*DO_BW-1:0]               o_rout_iq      
);

//Parameter freq_shift
localparam  BW_SIN                  =   16                  ;
localparam  FS_OUT_SHIFTD           =   4'd15               ;
localparam  DLY_SYNC                =   4'd9                ;
localparam  DLY_PSYNC               =   4'd9               ;


// signal
wire                                w_fshift_en     ;
wire [2*(DI_BW+BW_SIN+1)  -1:0]     w_fshift_iq     ;
wire                                w_fshift_rnd_en ;
wire [2*(DI_BW+BW_SIN+1)  -1:0]     w_fshift_rnd_iq ;
reg  [$clog2(NUM_ANT)     -1:0]     r_cnt           ;

// logic
ylib_cmult  #(
    .AWIDTH     (   DI_BW        )
   ,.BWIDTH     (   BW_SIN       ))
u00_xlib_freq_shift
(
    .clk        ( i_clk                                              )
   ,.en         ( |i_rin_en                                          )
   ,.ar         ( i_rin_iq[DI_BW*2-1:DI_BW]                          )
   ,.ai         ( i_rin_iq[DI_BW  -1:    0]                          )
   ,.br         ( i_p_cos                                            )
   ,.bi         ( i_n_sin                                            )
   ,.pen        ( w_fshift_en                                        )
   ,.pr         ( w_fshift_iq[(DI_BW+BW_SIN+1)*2-1:(DI_BW+BW_SIN+1)] )
   ,.pi         ( w_fshift_iq[(DI_BW+BW_SIN+1)  -1:               0] )
);

ylib_shiftd_rnd #(
     .NUM_STREAM (   2               )
    ,.SHIFTD_BW  (   4               )
    ,.IO_BW      (   DI_BW+BW_SIN+1  ))
u02_uout_shiftd_rnd 
(
     .i_clk      (   i_clk           )
    ,.i_in_en    (   w_fshift_en     )
    ,.i_in       (   w_fshift_iq     )
    ,.i_shiftd   (   FS_OUT_SHIFTD   )
    ,.o_out_en   (   w_fshift_rnd_en )
    ,.o_out      (   w_fshift_rnd_iq )
);

ylib_sat #(
     .NUM_STREAM    (   2               )
    ,.DI_BW         (   DI_BW+BW_SIN+1  )
    ,.DO_BW         (   DO_BW           )
    ,.SAT_TYPE      ( "ASSYMETRIC"      ))
u03_uout_sat
(
     .i_clk         (   i_clk           )
    ,.i_in_en       (   w_fshift_rnd_en )
    ,.i_in          (   w_fshift_rnd_iq )
    ,.o_out_en      (                   )
    ,.o_out         (   o_rout_iq       )
);

// output

// o_frame_sync           
ylib_pshift #( 
    .BW_SHIFT   (4))
u05_fsync_shift
(
     .i_clk     (   i_clk           )
    ,.i_shift   (   DLY_PSYNC       )
    ,.i_in      (   i_frame_sync    )
    ,.o_out     (   o_frame_sync    )
);

// o_rout_en
ylib_reg #(
    .WIDTH(NUM_ANT) ,.DEPTH(DLY_SYNC)) 
u06_out_reg(
    .i_clk      ( i_clk             )
   ,.i_in       ( i_rin_en          )
   ,.o_out      ( o_rout_en         )
);

endmodule
