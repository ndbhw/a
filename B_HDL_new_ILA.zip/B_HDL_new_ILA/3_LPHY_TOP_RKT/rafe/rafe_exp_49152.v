// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU  
//  Module       : rafe_exp_49152
//  Author       : ty321.kim@samsung.com
//  Description  : rafe exp 49152 for VzW FSU
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.20 | taeyeong      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module rafe_exp_49152
#(
     parameter DO_BW        =   16
    )(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from CPU IF
    ,   input   wire    [ 8             -1:0]       i_path_ratio
    ,   input   wire    [16             -1:0]       i_freq_shift

    //--- from input ctrl
    ,   input   wire    [ 1             -1:0]       i_frame_sync           
    ,   input   wire    [ 1             -1:0]       i_rin_en

    //--- to freq shift
    ,   output  wire                                o_cmplx_exp_vld             
    ,   output  wire    [DO_BW          -1:0]       o_p_cos                     
    ,   output  wire    [DO_BW          -1:0]       o_n_sin                     
);

localparam SHIFT_BW = 17        ;
localparam MOD1     = 17'h0C000 ;
localparam MOD2     = 17'h18000 ;


// signal
reg     [ 8         -1:0]               r_shift_cnt                ;
reg     [SHIFT_BW   -1:0]               r_shift                    ;
reg                                     r_shift_en                 ;
wire    [SHIFT_BW   -1:0]               r_shift_ext                ;
wire    [SHIFT_BW   -1:0]               w_shift_1d_0               ;
wire    [SHIFT_BW   -1:0]               w_shift_1d_1               ;
wire    [SHIFT_BW   -1:0]               w_shift_1d_2               ;


always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shift_cnt     <= 0;
    end
    else if(r_shift_cnt == i_path_ratio-1) begin      
        r_shift_cnt     <= 0;
    end
    else begin
        r_shift_cnt     <= r_shift_cnt + 1;
    end
end

reg    [SHIFT_BW   -1:0]               r_shift_1d_0               ;

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shift         <=  0;
        r_shift_1d_0    <=  i_freq_shift;
    end
//    else if((i_rin_en) & (r_shift_cnt == 8'b0)) begin
    else if((i_rin_en) & (r_shift_cnt == i_path_ratio-1)) begin
        if     (r_shift_1d_0 >= MOD2)   begin r_shift <= r_shift_1d_0 - MOD2      ; end 
        else if(r_shift_1d_0 >= MOD1)   begin r_shift <= r_shift_1d_0 - MOD1      ; end 
        else                            begin r_shift <= r_shift_1d_0             ; end 
        //r_shift_1d_0    <= r_shift + {1'b0,i_freq_shift};
    end
//    else if((i_rin_en) & (r_shift_cnt == 8'b1)) begin
    else if((i_rin_en) & (r_shift_cnt == i_path_ratio-2)) begin
        r_shift_1d_0    <= r_shift + {1'b0,i_freq_shift};
    end
end

always @(posedge i_clk) begin
    r_shift_en      <= i_rin_en;
end

lib_cmplx_exp_49152 #(.CJ( 1 )) u00_lib_cmplx_exp
(
     .i_clk         ( i_clk           )
    ,.i_phase_vld   ( i_rin_en        )
    ,.i_phase       ( r_shift[15:0]   )
    ,.o_vld         ( o_cmplx_exp_vld )
    ,.o_cos         ( o_p_cos         )
    ,.o_sin         ( o_n_sin         )
);

endmodule
