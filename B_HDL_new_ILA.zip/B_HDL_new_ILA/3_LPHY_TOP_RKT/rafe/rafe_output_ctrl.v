// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU  
//  Module       : rafe_output_ctrl
//  Author       : ty321.kim@samsung.com
//  Description  : rafe output control for VzW FSU
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.20 | taeyeong      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module rafe_output_ctrl
#(
     parameter NUM_ANT      =   8
    ,parameter NUM_CHAIN    =   4 
    ,parameter DI_BW        =   16
    ,parameter DO_BW        =   16
    )(
    //--- reset & clk
        input   wire                                    i_clk                      

    //--- from CPU IF
    ,   input   wire    [ 1                 -1:0]       i_par_out_tp_gen
    ,   input   wire    [ 4                 -1:0]       i_rin_filter_idx  
    ,   input   wire    [ 4                 -1:0]       i_rin_num_psymbol 

    ,   input   wire    [ 4                 -1:0]       i_rin_prach_scs
    ,   input   wire    [ 2                 -1:0]       i_par_pusch_scs
    ,   input   wire    [ 4                 -1:0]       i_start_sym
    ,   input   wire    [ 1                 -1:0]       i_sub_rst      
    ,   input   wire    [ 1                 -1:0]       i_ce
    //--- from BB IF
    ,   input   wire    [ 8                 -1:0]       i_rin_frame_idx

    //--- from gain comp
    ,   input   wire    [1                  -1:0]       i_frame_sync           
    ,   input   wire    [1                  -1:0]       i_ro_sync               
    ,   input   wire    [1      *NUM_CHAIN  -1:0]       i_rin_en
    ,   input   wire    [2*DO_BW*NUM_CHAIN  -1:0]       i_rin_iq     

    //--- to rach_config_map
    ,   output  reg     [1                  -1:0]       o_frm_sync  
    ,   output  reg     [8                  -1:0]       o_frm_idx
    ,   output  reg     [4                  -1:0]       o_subfrm_idx
    ,   output  reg     [6                  -1:0]       o_slot_idx
    ,   output  reg     [4                  -1:0]       o_symb_idx
    ,   output  reg     [NUM_ANT            -1:0]       o_rout_en
    ,   output  reg     [2*DO_BW*NUM_ANT    -1:0]       o_rout_iq      

    ,   output  reg     [NUM_ANT*16         -1:0]       o_rout_start_re_idx
    ,   output  reg     [NUM_ANT*1          -1:0]       o_rout_start_re    
    ,   output  reg     [NUM_ANT*1          -1:0]       o_rout_last_re     

    ,   output  reg     [32                 -1:0]       o_cnt_sym00 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym01 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym02 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym03 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym04 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym05 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym06 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym07 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym08 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym09 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym10 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym11 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym12 = 0 
    ,   output  reg     [32                 -1:0]       o_cnt_sym13 = 0 
    ,   output  reg     [14*10              -1:0]       o_log = 0
);

localparam DLY_SYNC = 22'd4;

// signal
genvar chidx ;


// input reg
reg    [1      *NUM_CHAIN -1:0]               r_rin_en;
reg    [2*DO_BW*NUM_CHAIN -1:0]               r_rin_iq;     

always @(posedge i_clk) begin
    r_rin_en    <= i_rin_en         ;
end

always @(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
        r_rin_iq    <= {2*DO_BW{1'b0}}  ;
    end
    else if(i_rin_en) begin
        r_rin_iq    <= i_rin_iq;
    end
end


// k_bar 

reg     [ 8     -1:0]               r_calc_k_bar    ;

always@(posedge i_clk) begin
    if(i_rin_filter_idx == 4'd3) begin
        r_calc_k_bar        <=  8'd2;
    end
    else if(i_rin_filter_idx == 4'd1) begin
        case({i_rin_prach_scs,i_par_pusch_scs})
            6'b1100_00 : r_calc_k_bar   <= 8'd7;
            6'b1100_01 : r_calc_k_bar   <= 8'd1;
            6'b1100_10 : r_calc_k_bar   <= 8'd133;
            6'b1110_00 : r_calc_k_bar   <= 8'd12;
            6'b1110_01 : r_calc_k_bar   <= 8'd10;
            6'b1110_10 : r_calc_k_bar   <= 8'd7;
            default    : r_calc_k_bar   <= 8'd7;
        endcase
    end
end


reg    [ 1     -1:0]               r_par_out_tp_gen;
reg    [ 8     -1:0]               r_par_rach_k_bar;
reg    [ 8     -1:0]               r_rin_frame_idx ;

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_par_out_tp_gen    <=               i_par_out_tp_gen  ;
//        r_rin_frame_idx     <=               i_rin_frame_idx   ;
        r_par_rach_k_bar    <=               r_calc_k_bar  ;
    end
end


always @(posedge i_clk) begin
    if(i_ro_sync) begin
        r_rin_frame_idx     <=               i_rin_frame_idx   ;
    end
end

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        o_rout_start_re_idx <= 16'b0;       
    end
end

// gen sop

wire    [1      -1:0]    w_sop;
wire    [1      -1:0]    w_eop;
reg     [1      -1:0]    r_sop;
reg     [1      -1:0]    r_eop;

assign w_sop = i_rin_en[0] & (~r_rin_en[0]);
assign w_eop = ~i_rin_en[0] & r_rin_en[0]  ;


always@(posedge i_clk) begin
    r_sop   <= w_sop;
    r_eop   <= w_eop;
end


// ant align
reg    [4-1:0]             r_ant_cnt       ; 
reg    [4-1:0]             r_repet_cnt     ;

always @(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
        r_ant_cnt          <= {4{1'b0}}; 
        r_repet_cnt        <= {4{1'b0}}; 
    end
    if(i_sub_rst) begin
        r_ant_cnt          <= {4{1'b0}}; 
        r_repet_cnt        <= {4{1'b0}}; 
    end
    else if(w_sop & (r_ant_cnt == NUM_ANT/NUM_CHAIN) & (r_repet_cnt == (i_rin_num_psymbol -1)) ) begin
        r_ant_cnt          <= 4'b1;
        r_repet_cnt        <= {4{1'b0}}; 
    end
    else if(w_sop & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) begin
        r_ant_cnt          <= 4'b1;
        r_repet_cnt        <= r_repet_cnt + 4'b1;
    end
    else if(w_sop) begin
        r_ant_cnt          <= r_ant_cnt +4'b1;
    end
end

 
// slot sync gen
wire [1     -1:0]  w_frm_sync       ;
wire [4     -1:0]  w_subfrm_idx     ;

reg  [3     -1:0]  r_set_mu         ;

wire [8     -1:0]  w_slot_idx_15k   ;
wire [4     -1:0]  w_symb_idx_15k   ;

wire [8     -1:0]  w_slot_idx_30k   ;
wire [4     -1:0]  w_symb_idx_30k   ;


always @(posedge i_clk) begin
    case(i_rin_prach_scs) 
        4'b0000 : r_set_mu <= 3'b000;
        4'b0001 : r_set_mu <= 3'b001;
        4'b0010 : r_set_mu <= 3'b010;
//        4'b1100 : r_set_mu <= i_par_pusch_scs;
        4'b1100 : r_set_mu <= 3'b000;
        4'b1110 : r_set_mu <= i_par_pusch_scs;
        default : r_set_mu <= 3'b000;
    endcase
end

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'b0                  )  // 0:15, 1:30, 2:60 ... TBD
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          ( w_frm_sync            )  // wire          
    ,.o_subfrm_sync         (                       )  // wire          
    ,.o_slot_sync           (                       )  //w_slot_sync           )  // wire          
    ,.o_symbol_sync         (                       )  //w_symb_sync           )  // wire  
    ,.o_subfrm              ( w_subfrm_idx          )  // wire   [3:0]     
    ,.o_slot                ( w_slot_idx_15k        )  // wire   [7:0]         
    ,.o_symbol              ( w_symb_idx_15k        )  // wire   [3:0]         
);

ref_vsync_gen u01_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'b1                  )  // 0:15, 1:30, 2:60 ... TBD
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )  // wire          
    ,.o_subfrm_sync         (                       )  // wire          
    ,.o_slot_sync           (                       )  //w_slot_sync           )  // wire          
    ,.o_symbol_sync         (                       )  //w_symb_sync           )  // wire  
    ,.o_subfrm              (                       )  // wire   [3:0]     
    ,.o_slot                ( w_slot_idx_30k        )  // wire   [7:0]         
    ,.o_symbol              ( w_symb_idx_30k        )  // wire   [3:0]         
);


// oRAN output pattern gen

reg [10 -1:0]   r_smp_cnt;

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_smp_cnt   <= 10'b0;
    end
    else if(w_sop) begin
        r_smp_cnt   <= {2'b0,r_calc_k_bar};
    end
    else if(i_rin_en) begin
        r_smp_cnt   <= r_smp_cnt + 10'b1;
    end
    else begin
        r_smp_cnt   <= 10'b0;
    end
end

// long preamble symbol idx
reg [ 4 -1:0]   r_long_sidx;
reg [ 4 -1:0]   r_short_sidx;
reg [ 1 -1:0]   r_short_shold;

// always @(posedge i_clk) begin
//     if(i_frame_sync) begin
//         r_long_sidx <= 4'b0;
//     end
//     else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN & r_long_sidx == (i_rin_num_psymbol-1)) begin
//         r_long_sidx <= 4'b0 ;
//     end
//     else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN) begin
//         r_long_sidx <= r_long_sidx + 1 ;
//     end
// end

always @(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
        r_long_sidx     <= 4'b0;
        r_short_sidx    <= 4'b0;
        r_short_shold   <= 1'b0;
    end
    else if(w_sop & (~r_short_shold)) begin
        r_short_shold   <= 1'b1;
        r_long_sidx     <= i_start_sym  ; //oRAN ver 5.0 CR
//        r_long_sidx     <= 4'b0  ;
        if(r_set_mu[0]) 
            r_short_sidx      <=  w_symb_idx_30k      ; 
        else
            r_short_sidx      <=  w_symb_idx_15k      ; 
    end
    else if((r_eop & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) & r_repet_cnt == (i_rin_num_psymbol -1)) begin
        r_short_sidx <= r_short_sidx + 1 ;
        r_short_shold   <= 1'b0;
    end
    else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN) begin
        r_long_sidx <= r_long_sidx + 1 ;
        r_short_sidx <= r_short_sidx + 1 ;
    end
end





// long preamble subframe idx

reg [4  -1:0]   r_long_sfidx;
reg [1  -1:0]   r_long_sfhold;

always @(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
        r_long_sfidx    <= 4'b0         ;
        r_long_sfhold   <= 1'b0         ;
    end
    else if(r_eop & (r_repet_cnt==i_rin_num_psymbol-1) & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) begin
        r_long_sfidx    <= 4'b0         ;
        r_long_sfhold   <= 1'b0         ;
    end
    // else if(w_sop & (~r_long_sfhold) & (i_ce)) begin
    //     r_long_sfidx    <= w_subfrm_idx + 4'd1;
    //     r_long_sfhold   <= 1'b1         ;
    // end
    else if(w_sop & (~r_long_sfhold)) begin
        r_long_sfidx    <= w_subfrm_idx ;
        r_long_sfhold   <= 1'b1         ;
    end
end





// output ctrl

generate for(chidx=0;chidx<NUM_CHAIN;chidx=chidx+1) begin : g00_out_en_iq

    always@(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
            o_rout_en      [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
            o_rout_start_re[NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
            o_rout_last_re [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
        end
        else begin
            o_rout_en      [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},r_rin_en[chidx]}<< (r_ant_cnt - 1);  
            o_rout_start_re[NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},r_sop          }<< (r_ant_cnt - 1);  
            o_rout_last_re [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},w_eop          }<< (r_ant_cnt - 1);  
        end
    end


    always@(posedge i_clk) begin
    //if(i_frame_sync) begin
    if(i_ro_sync) begin
            o_rout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(2*DO_BW*NUM_ANT/NUM_CHAIN){1'b0}};
        end
        else if(r_par_out_tp_gen) begin
            if(r_set_mu[0])
                o_rout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){{r_rin_frame_idx,w_subfrm_idx,w_slot_idx_30k[5:0],w_symb_idx_30k,r_smp_cnt}}};
            else
                o_rout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){{r_rin_frame_idx,w_subfrm_idx,w_slot_idx_15k[5:0],w_symb_idx_15k,r_smp_cnt}}};
        end
        else begin
            o_rout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){r_rin_iq[2*DO_BW*chidx+:2*DO_BW]}};
        end
    end

end
endgenerate


always @(posedge i_clk) begin
    if(i_rin_filter_idx == 4'd1) begin
        o_symb_idx  <=  r_long_sidx     ;
    end
    else if(i_rin_filter_idx == 4'd3) begin
        if(r_set_mu[0]) 
            o_symb_idx      <=  w_symb_idx_30k      ; 
        else
            o_symb_idx      <=  w_symb_idx_15k      ; 
    end
end

always @(posedge i_clk) begin
    o_frm_sync      <=  w_frm_sync      ;   
    o_frm_idx       <=  r_rin_frame_idx ;    
//    o_subfrm_idx    <=  w_subfrm_idx    ;    
end


always @(posedge i_clk) begin
    if(i_rin_filter_idx == 4'd1) begin
        o_subfrm_idx    <=  r_long_sfidx    ;    
    end
    else begin
        o_subfrm_idx    <=  w_subfrm_idx    ;    
    end
end

always @(posedge i_clk) begin
    if(r_set_mu[2:0] == 3'b001) begin
        o_slot_idx  <=    {5'b0,w_slot_idx_30k[0]} ;
    end
    else if(r_set_mu[2:0] == 3'b010) begin
        o_slot_idx  <=    {4'b0,w_slot_idx_15k[1:0]} ;
    end
    else begin
        o_slot_idx  <=    6'b0      ;
    end
end

// symbol counter

reg [1  -1:0]   rr_rout_en      = 0 ;
reg [1  -1:0]   rr_rout_last_re = 0 ;
reg [4  -1:0]   rr_symb_idx     = 0 ;

always @(posedge i_clk) begin
    rr_rout_en      <= o_rout_en     [0];
    rr_rout_last_re <= o_rout_last_re[0];
    rr_symb_idx     <= o_symb_idx       ;
end

always @(posedge i_clk) begin
    if(rr_rout_en & rr_rout_last_re) begin
        if     (rr_symb_idx   == 4'h0) begin o_cnt_sym00 <= o_cnt_sym00 + 1; end
        else if(rr_symb_idx   == 4'h1) begin o_cnt_sym01 <= o_cnt_sym01 + 1; end
        else if(rr_symb_idx   == 4'h2) begin o_cnt_sym02 <= o_cnt_sym02 + 1; end
        else if(rr_symb_idx   == 4'h3) begin o_cnt_sym03 <= o_cnt_sym03 + 1; end
        else if(rr_symb_idx   == 4'h4) begin o_cnt_sym04 <= o_cnt_sym04 + 1; end
        else if(rr_symb_idx   == 4'h5) begin o_cnt_sym05 <= o_cnt_sym05 + 1; end
        else if(rr_symb_idx   == 4'h6) begin o_cnt_sym06 <= o_cnt_sym06 + 1; end
        else if(rr_symb_idx   == 4'h7) begin o_cnt_sym07 <= o_cnt_sym07 + 1; end
        else if(rr_symb_idx   == 4'h8) begin o_cnt_sym08 <= o_cnt_sym08 + 1; end
        else if(rr_symb_idx   == 4'h9) begin o_cnt_sym09 <= o_cnt_sym09 + 1; end
        else if(rr_symb_idx   == 4'ha) begin o_cnt_sym10 <= o_cnt_sym10 + 1; end
        else if(rr_symb_idx   == 4'hb) begin o_cnt_sym11 <= o_cnt_sym11 + 1; end
        else if(rr_symb_idx   == 4'hc) begin o_cnt_sym12 <= o_cnt_sym12 + 1; end
        else if(rr_symb_idx   == 4'hd) begin o_cnt_sym13 <= o_cnt_sym13 + 1; end
    end
end

// debug
always @ (posedge i_clk)
begin
    if (o_rout_start_re)
    begin
        o_log <= {o_log[14*9 -1:0], o_subfrm_idx, o_slot_idx, o_symb_idx};
    end
end

endmodule
