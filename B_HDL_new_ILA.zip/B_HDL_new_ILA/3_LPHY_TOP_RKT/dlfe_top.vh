////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW RF4440d_13AB 
//  Module       : dlfe_top 
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe_top Configuration header
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////
//////PROJECT
`define DLFE_PROJECT_NAME   `LPHY_PROJECT_NAME
`define DLFE_SW_PKG_NAME    `LPHY_SW_PKG_NAME 

//////DLFE IMPLEMENTATION CONFIGURATION
`define DLFE_AIE_DISABLE
`define DLFE_BF_DISABLE
`define DLFE_CAL_DISABLE
`define DLFE_IFFT_MAP_DISABLE
//`define DLFE_CELL_MUX_DISABLE
`define DLFE_DSS_DISABLE
`define DLFE_MU_MIMO_DISABLE
//`define DLFE_OFDM_MOD_DISABLE
`define DLFE_XSSI_DISABLE
//`define DLFE_LSSI_DISABLE
//`define DLFE_TSSI_DISABLE
`define DLFE_MON_SMP_DISABLE
`define DLFE_WDOG_DISABLE
`define DLFE_EXT_BFCAL_DISABLE
`define DLFE_VENDOR_FFT_DISABLE    
`define DLFE_MAX_MU                 0    
`define DLFE_MAX_NIFFT              1024 
`define DLFE_DO_BW_IN_IF            16        
`define DLFE_DO_BW_BFW_MULT         16        
`define DLFE_DO_BW_CAL_SCHDLR       16        
`define DLFE_DO_BW_CALW_MULT        16        
`define DLFE_DO_BW_PHASE_COMP       16        
`define DLFE_DO_BW_IFFT_MAP_BUF     16        
`define DLFE_DO_BW_OFDM_MOD         16        
`define DLFE_DO_BW_ANT_SCALE        15        
`define DLFE_DO_BW_CDD_CP_BUF       15        
`define DLFE_NUM_CHAIN_IN_IF        1       
`define DLFE_NUM_CHAIN_BFW_MULT     1
`define DLFE_NUM_CHAIN_CAL_SCHDLR   1
`define DLFE_NUM_CHAIN_CALW_MULT    1
`define DLFE_NUM_CHAIN_PHASE_COMP   1
`define DLFE_NUM_CHAIN_IFFT_MAP_BUF 1
`define DLFE_NUM_CHAIN_OFDM_MOD     1
`define DLFE_NUM_CHAIN_ANT_SCALE    1

`ifndef DLFE_CELL_MUX_DISABLE
`define DLFE_NUM_CC_MUX             2
`else //DLFE_CELL_MUX_DISABLE
`define DLFE_NUM_CC_MUX             1
`endif //DLFE_CELL_MUX_DISABLE
`define DLFE_TARGET_DLY             22'h44c0
`define DLFE_NUM_FRAME_XSSI         7'd16    

//////MACRO
`define mlib_clog2(A) A > 1 ? $clog2(A) : 1 
