////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : Vzw RF4440d_13AB_TYPE01, MSTR_V02
//                       VF RF4448/RF4449/RF2221d/RF2222d
//  Module       : LPHY_TOP 
//  Author       : jyzoo.lee@samsung.com
//  Description  : Baseband LPHY TOP
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Create Initial Design                 (SVR21D)
//  ------------+---------------+-----------------------------------------------
//   2021.06.15 | jyzoo.lee     | UL Sync-Data Aligned
//  ------------+---------------+-----------------------------------------------
//   2021.06.18 | jyzoo.lee     | sig_cap redesigned 
//  ------------+---------------+-----------------------------------------------
//   2021.10.01 | jyzoo.lee     | Generics of ULFE,RAFE Separated       (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.10.14 | jyzoo.lee     | NB-IoT Support for RF4440d            (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.11.04 | jyzoo.lee     | DLFE 2T4CC/Core Support               (SVR22B)
//  ------------+---------------+-----------------------------------------------
//   2021.11.12 | jyzoo.lee     | SBIF Support for RF2221/2d,RF4448/9   (SVR22B)
//  ------------+---------------+-----------------------------------------------
//   2021.12.16 | jyzoo.lee     | eMTC Support for RF4440d              (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.12.27 | jyzoo.lee     | Support that DL cell is odd number    (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2022.01.03 | jyzoo.lee     | RAFE & eMTC Sector Split Support      (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2022.05.12 | jyzoo.lee     | RACH Multi band Support               (SVR22C)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "LPHY_TOP.vh"

module LPHY_TOP
#(
    parameter   DL_NUM_CC           =  `DL_NUM_CC          
   ,parameter   UL_NUM_CC           =  `UL_NUM_CC          
   ,parameter   RA_NUM_CC           =  `RA_NUM_CC          
   ,parameter   NB_NUM_CC           =  `NB_NUM_CC          
   ,parameter   MT_NUM_CC           =  `MT_NUM_CC          
   ,parameter   DL_MAX_CC           =  `DL_MAX_CC
   ,parameter   UL_MAX_CC           =  `UL_MAX_CC
   ,parameter   RA_MAX_CC           =  `RA_MAX_CC
   ,parameter   NB_MAX_CC           =  `NB_MAX_CC
   ,parameter   MT_MAX_CC           =  `MT_MAX_CC
   ,parameter   DL_NUM_LAYER        =  `DL_NUM_LAYER 
   ,parameter   DL_NUM_ANT          =  `DL_NUM_ANT    
   ,parameter   UL_NUM_PATH         =  `UL_NUM_PATH 
   ,parameter   UL_NUM_ANT          =  `UL_NUM_ANT
   ,parameter   RA_NUM_PATH         =  `RA_NUM_PATH 
   ,parameter   RA_NUM_ANT          =  `RA_NUM_ANT
   ,parameter   NB_NUM_PATH         =  `NB_NUM_PATH 
   ,parameter   NB_NUM_ANT          =  `NB_NUM_ANT
   ,parameter   MT_NUM_PATH         =  `MT_NUM_PATH 
   ,parameter   MT_NUM_ANT          =  `MT_NUM_ANT
   ,parameter   TOP_DIO_BW          =   16
   ,parameter   CPUIF_ADDR_BW       =   20 
   ,parameter   CPUIF_DATA_BW       =   32
`ifdef SBIF_ENABLE
   ,parameter   DL_NUM_SBIF         =  `DL_NUM_SBIF 
   ,parameter   UL_NUM_SBIF         =  `UL_NUM_SBIF 
`ifndef NBIOT_CORE_DISABLE
   ,parameter   NB_NUM_SBIF         =  `NB_NUM_SBIF 
`endif//NBIOT_CORE_DISABLE
`endif// SBIF_ENABLE
)(
    //--- From SYSCTRL_TOP
        input   wire                                                i_core_clk              //core clock 245.76MHz 
    ,   input   wire    [DL_MAX_CC-1:0]                             i_core_arst_lphy_top    //lphy_top active high async reset 
    ,   input   wire    [DL_MAX_CC-1:0]                             i_core_arst_dlfe        //dlfe active high async reset 
    ,   input   wire    [UL_MAX_CC-1:0]                             i_core_arst_ulfe        //ulfe active high async reset 
    ,   input   wire    [RA_MAX_CC-1:0]                             i_core_arst_rafe        //rafe active high async reset 

    //--- From/To CPU IF
    ,   input   wire                                                i_cpu_clk               //CPU Interface clock 100MHz
    ,   input   wire                                                i_cpu_arst              //CPU Interface async reset
    ,   input   wire    [00:0]                                      i_cpu_cs                //CPU Interface chip sync
    ,   input   wire    [CPUIF_ADDR_BW-1:0]                         i_cpu_addr              //CPU Interface address of lphy_top registers
    ,   input   wire    [00:0]                                      i_cpu_wren              //CPU Interface write enable of lphy_top registers 
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_cpu_wdata             //CPU Interface write data of lphy_top registers 
    ,   input   wire    [00:0]                                      i_cpu_rden              //CPU Interface read enable of lphy_top registers 
    ,   output  wire    [CPUIF_DATA_BW-1:0]                         o_cpu_rdata             //CPU Interface read data of lphy_top registers 
    ,   output  wire    [00:0]                                      o_cpu_rd_valid          //CPU Interface read data vaild of lphy_top registers 

    //--- From/To ORAN_TOP(DL)
    ,   input   wire    [01*DL_MAX_CC-1:0]                          i_din_frame_sync        //ccx dl input frame sync (1 pulse of 245.76MHz every 10ms)
    ,   input   wire    [08*DL_MAX_CC-1:0]                          i_din_frame_idx         //ccx dl input frame index (oran)
    ,   input   wire    [01*DL_NUM_LAYER*DL_MAX_CC-1:0]             i_din_en                //ccx dl input u-plane data valid (oran)
    ,   input   wire    [01*DL_NUM_LAYER*DL_MAX_CC-1:0]             i_din_re_mask           //ccx dl input re mask (oran)
    ,   input   wire    [2*TOP_DIO_BW*DL_NUM_LAYER*DL_MAX_CC-1:0]   i_din_iq                //ccx dl input u-plane data (oran)      
    ,   output  wire    [01*DL_MAX_CC-1:0]                          o_dout_dl_sys_mode      //ccx dl output system mode   
    ,   output  wire    [12*DL_MAX_CC-1:0]                          o_dout_dl_ntone         //ccx dl output ntone   
    ,   output  wire    [02*DL_MAX_CC-1:0]                          o_dout_dl_fft_type      //ccx dl output fft_type
    ,   output  wire    [12*DL_MAX_CC-1:0]                          o_dout_dl_k0            //ccx dl output k0  
                                                                                            
    //--- To ORAN_TOP (PUxCH)
    ,   output  wire    [08*UL_MAX_CC-1:0]                          o_uout_frame_idx        //ccx ul output frame index (oran)       
    ,   output  wire    [04*UL_MAX_CC-1:0]                          o_uout_subfrm_idx       //ccx ul output subframe index (oran)
    ,   output  wire    [06*UL_MAX_CC-1:0]                          o_uout_slot_idx         //ccx ul output slot index (oran)
    ,   output  wire    [06*UL_MAX_CC-1:0]                          o_uout_symbol_idx       //ccx ul output symbol index (oran)
    ,   output  wire    [16*UL_NUM_PATH*UL_MAX_CC-1:0]              o_uout_start_re_idx     //ccx ul output start re index (oran)
    ,   output  wire    [01*UL_NUM_PATH*UL_MAX_CC-1:0]              o_uout_en               //ccx ul output u-plane data valid (oran)
    ,   output  wire    [01*UL_NUM_PATH*UL_MAX_CC-1:0]              o_uout_start_re         //ccx ul output start re indicator (oran)    
    ,   output  wire    [01*UL_NUM_PATH*UL_MAX_CC-1:0]              o_uout_last_re          //ccx ul output last re indicator (oran)
    ,   output  wire    [2*TOP_DIO_BW*UL_NUM_PATH*UL_MAX_CC-1:0]    o_uout_iq               //ccx ul output u-plane data (oran)

    //--- From/To ORAN_TOP (PRACH)
    ,   input   wire	[04*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_filter_idx        //ccx prach input filter index
    ,   input   wire  	[16*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_time_offset       //ccx prach input time offset
    ,   input   wire  	[08*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_frame_struct      //ccx prach input frame structure
    ,   input   wire  	[16*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_cp_length         //ccx prach input cp length
    ,   input   wire  	[24*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_freq_offset       //ccx prach input frequency offset
    ,   input   wire  	[04*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_num_psymbol       //ccx prach input preamble symbol number
    ,   input   wire  	[03*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_num_ro            //ccx prach input occasion number
    ,   input   wire  	[08*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_num_prbc          //ccx prach input c-plane physical rb size 
    ,   input   wire  	[10*RA_NUM_PATH*RA_MAX_CC-1:0]              i_rin_start_prbc        //ccx prach input c-plane
    ,   output  wire    [08*RA_MAX_CC-1:0]                          o_rout_frame_idx        //ccx prach output frame index (oran)  
    ,   output  wire    [04*RA_MAX_CC-1:0]                          o_rout_subfrm_idx       //ccx prach output subframe index (oran)
    ,   output  wire    [06*RA_MAX_CC-1:0]                          o_rout_slot_idx         //ccx prach output slot index (oran)
    ,   output  wire    [06*RA_MAX_CC-1:0]                          o_rout_symbol_idx       //ccx prach output symbol index (oran)
    ,   output  wire    [16*RA_NUM_PATH*RA_MAX_CC-1:0]              o_rout_start_re_idx     //ccx prach output start re index (oran)
    ,   output  wire    [01*RA_NUM_PATH*RA_MAX_CC-1:0]              o_rout_en               //ccx prach output u-plane data valid (oran)
    ,   output  wire    [01*RA_NUM_PATH*RA_MAX_CC-1:0]              o_rout_start_re         //ccx prach output start re indicator (oran)    
    ,   output  wire    [01*RA_NUM_PATH*RA_MAX_CC-1:0]              o_rout_last_re          //ccx prach output last re indicator (oran)
    ,   output  wire    [2*TOP_DIO_BW*RA_NUM_PATH*RA_MAX_CC-1:0]    o_rout_iq               //ccx prach output u-plane data (oran)  
`ifndef SBIF_ENABLE
    //--- To BBCTRL(DL)
    ,   output  reg     [01*DL_MAX_CC-1:0]                          o_dout_frame_sync       //ccx dl output frame sync (1 pulse of 245.76MHz every 10ms)
    ,   output  reg     [01*DL_NUM_ANT*DL_MAX_CC-1:0]               o_dout_en               //ccx dl output td data valid 
    ,   output  reg     [TOP_DIO_BW*DL_NUM_ANT*DL_MAX_CC-1:0]       o_dout_i                //ccx dl output td in-phase sample
    ,   output  reg     [TOP_DIO_BW*DL_NUM_ANT*DL_MAX_CC-1:0]       o_dout_q                //ccx dl output td quadrature sample

    //--- FROM BBCTRL(UL)
    ,   input   wire    [01*UL_MAX_CC-1:0]                          i_uin_frame_sync        //ccx ul input frame sync (1 pulse of 245.76MHz every 10ms)
    ,   input   wire    [01*UL_NUM_ANT*UL_MAX_CC-1:0]               i_uin_en                //ccx ul input td data valid 
    ,   input   wire    [TOP_DIO_BW*UL_NUM_ANT*UL_MAX_CC-1:0]       i_uin_i                 //ccx ul input td in-phase sample
    ,   input   wire    [TOP_DIO_BW*UL_NUM_ANT*UL_MAX_CC-1:0]       i_uin_q                 //ccx ul input td quadrature sample
`else //SBIF_ENABLE
    //--- To SBIF(DL)
    ,   output  wire    [01*DL_NUM_SBIF-1:0]                        o_dsbif_bfn_strb        //sbif dl output bfn strobe
    ,   output  wire    [12*DL_NUM_SBIF-1:0]                        o_dsbif_bfn             //sbif dl output bfn 
    ,   output  wire    [01*DL_NUM_SBIF-1:0]                        o_dsbif_csync           //sbif dl output chip sync
    ,   output  wire    [TOP_DIO_BW*DL_NUM_SBIF-1:0]                o_dsbif_idata           //sbif dl output interleaved in-phase sample
    ,   output  wire    [TOP_DIO_BW*DL_NUM_SBIF-1:0]                o_dsbif_qdata           //sbif dl output interleaved quadrature sample

    //--- FROM SBIF(UL)
    ,   input   wire    [01*UL_NUM_SBIF-1:0]                        i_usbif_bfn_strb        //sbif ul input bfn strobe
    ,   input   wire    [01*UL_NUM_SBIF-1:0]                        i_usbif_csync           //sbif ul input chip sync
    ,   input   wire    [TOP_DIO_BW*UL_NUM_SBIF-1:0]                i_usbif_idata           //sbif ul input interleaved in-phase sample
    ,   input   wire    [TOP_DIO_BW*UL_NUM_SBIF-1:0]                i_usbif_qdata           //sbif ul input interleaved quadrature sample
`endif //SBIF_ENABLE
`ifndef NBIOT_CORE_DISABLE
    //--- From/To ORAN_TOP (NPRACH,NPUSCH)
    ,   input   wire	[04*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_filter_idx        //ccx ul nprach,npuxch input filter index
    ,   input   wire  	[16*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_time_offset       //ccx ul nprach,npuxch input time offset
    ,   input   wire  	[08*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_frame_struct      //ccx ul nprach,npuxch input frame structure
    ,   input   wire  	[16*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_cp_length         //ccx ul nprach,npuxch input cp length
    ,   input   wire  	[24*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_freq_offset       //ccx ul nprach,npuxch input frequency offset
    ,   input   wire  	[04*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_num_psymbol       //ccx ul nprach,npuxch input preamble symbol number
    ,   input   wire  	[03*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_num_ro            //ccx ul nprach,npuxch input occasion number
    ,   input   wire  	[08*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_num_prbc          //ccx ul nprach,npuxch input c-plane physical rb size
    ,   input   wire    [10*NB_NUM_PATH*NB_MAX_CC-1:0]              i_nin_start_prbc        //ccx ul nprach,npuxch input
    ,   output  wire    [01*2-1:0]                                  o_nout_nco_valid        //ccx ul nprach,npuxch nco valid (ddc) 
    ,   output  wire    [08*2-1:0]                                  o_nout_frame_struct     //ccx ul nprach,npuxch frame structure (ddc) 
    ,   output  wire    [24*2-1:0]                                  o_nout_freq_offset      //ccx ul nprach,npuxch frequency offset (ddc) 
    ,   output  wire    [08*NB_MAX_CC-1:0]                          o_nout_frame_idx        //ccx ul nprach,npuxch output frame index (oran)  
    ,   output  wire    [04*NB_MAX_CC-1:0]                          o_nout_subfrm_idx       //ccx ul nprach,npuxch output subframe index (oran)
    ,   output  wire    [06*NB_MAX_CC-1:0]                          o_nout_slot_idx         //ccx ul nprach,npuxch output slot index (oran)
    ,   output  wire    [06*NB_MAX_CC-1:0]                          o_nout_symbol_idx       //ccx ul nprach,npuxch output symbol index (oran)
    ,   output  wire    [16*NB_NUM_PATH*NB_MAX_CC-1:0]              o_nout_start_re_idx     //ccx ul nprach,npuxch output start re index (oran)
    ,   output  wire    [01*NB_NUM_PATH*NB_MAX_CC-1:0]              o_nout_en               //ccx ul nprach,npuxch output u-plane data valid (oran)
    ,   output  wire    [01*NB_NUM_PATH*NB_MAX_CC-1:0]              o_nout_start_re         //ccx ul nprach,npuxch output start re indicator (oran)    
    ,   output  wire    [01*NB_NUM_PATH*NB_MAX_CC-1:0]              o_nout_last_re          //ccx ul nprach,npuxch output last re indicator (oran)
    ,   output  wire    [2*TOP_DIO_BW*NB_NUM_PATH*NB_MAX_CC-1:0]    o_nout_iq               //ccx ul nprach,npuxch output u-plane data (oran)  
`ifndef SBIF_ENABLE
    //--- FROM BBCTRL (UL NB-IoT)
    ,   input   wire    [ 1                      * 2 -1:0]          i_nin_frame_sync        //ccx ul nprach,npuxch input frame sync (1 pulse of 245.76MHz every 10ms)
    ,   input   wire    [ 1         * NB_NUM_ANT * 2 -1:0]          i_nin_en                //ccx ul nprach,npuxch input td data valid 
    ,   input   wire    [TOP_DIO_BW * NB_NUM_ANT * 2 -1:0]          i_nin_i                 //ccx ul nprach,npuxch input td in-phase sample
    ,   input   wire    [TOP_DIO_BW * NB_NUM_ANT * 2 -1:0]          i_nin_q                 //ccx ul nprach,npuxch input td quadrature sample
`else //SBIF_ENABLE
    //--- FROM SBIF (UL NB-IoT)
    ,   input   wire    [01*NB_NUM_SBIF-1:0]                        i_nsbif_bfn_strb        //sbif nprach,npuxch input bfn strobe
    ,   input   wire    [01*NB_NUM_SBIF-1:0]                        i_nsbif_csync           //sbif nprach,npuxch input chip sync
    ,   input   wire    [TOP_DIO_BW*NB_NUM_SBIF-1:0]                i_nsbif_idata           //sbif nprach,npuxch input interleaved in-phase sample
    ,   input   wire    [TOP_DIO_BW*NB_NUM_SBIF-1:0]                i_nsbif_qdata           //sbif nprach,npuxch input interleaved quadrature sample
`endif //SBIF_ENABLE
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
    //--- From/To ORAN_TOP (eMTC PRACH)
    ,   input   wire	[04*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_filter_idx        //ccx emtc prach input filter index
    ,   input   wire  	[16*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_time_offset       //ccx emtc prach input time offset
    ,   input   wire  	[08*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_frame_struct      //ccx emtc prach input frame structure
    ,   input   wire  	[16*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_cp_length         //ccx emtc prach input cp length
    ,   input   wire  	[24*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_freq_offset       //ccx emtc prach input frequency offset
    ,   input   wire  	[04*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_num_psymbol       //ccx emtc prach input preamble symbol number
    ,   input   wire  	[03*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_num_ro            //ccx emtc prach input occasion number
    ,   input   wire  	[08*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_num_prbc          //ccx emtc prach input c-plane physical rb size 
    ,   input   wire  	[10*MT_NUM_PATH*MT_MAX_CC-1:0]              i_min_start_prbc        //ccx emtc prach input c-plane physical rb size 
    ,   output  wire    [08*MT_MAX_CC-1:0]                          o_mout_frame_idx        //ccx emtc prach output frame index (oran)  
    ,   output  wire    [04*MT_MAX_CC-1:0]                          o_mout_subfrm_idx       //ccx emtc prach output subframe index (oran)
    ,   output  wire    [06*MT_MAX_CC-1:0]                          o_mout_slot_idx         //ccx emtc prach output slot index (oran)
    ,   output  wire    [06*MT_MAX_CC-1:0]                          o_mout_symbol_idx       //ccx emtc prach output symbol index (oran)
    ,   output  wire    [16*MT_NUM_PATH*MT_MAX_CC-1:0]              o_mout_start_re_idx     //ccx emtc prach output start re index (oran)
    ,   output  wire    [01*MT_NUM_PATH*MT_MAX_CC-1:0]              o_mout_en               //ccx emtc prach output u-plane data valid (oran)
    ,   output  wire    [01*MT_NUM_PATH*MT_MAX_CC-1:0]              o_mout_start_re         //ccx emtc prach output start re indicator (oran)    
    ,   output  wire    [01*MT_NUM_PATH*MT_MAX_CC-1:0]              o_mout_last_re          //ccx emtc prach output last re indicator (oran)
    ,   output  wire    [2*TOP_DIO_BW*MT_NUM_PATH*MT_MAX_CC-1:0]    o_mout_iq               //ccx emtc prach output u-plane data (oran)  
`ifndef SBIF_ENABLE
    //--- FROM BBCTRL (UL eMTC)
    ,   input   wire    [01*MT_MAX_CC-1:0]                          i_min_frame_sync        //ccx ul emtc prach input frame sync (1 pulse of 245.76MHz every 10ms)
    ,   input   wire    [01*MT_NUM_ANT*MT_MAX_CC-1:0]               i_min_en                //ccx ul emtc prach input td data valid 
    ,   input   wire    [TOP_DIO_BW*MT_NUM_ANT*MT_MAX_CC-1:0]       i_min_i                 //ccx ul emtc prach input td in-phase sample
    ,   input   wire    [TOP_DIO_BW*MT_NUM_ANT*MT_MAX_CC-1:0]       i_min_q                 //ccx ul emtc prach input td quadrature sample
`endif //SBIF_ENABLE
`endif//EMTC_CORE_DISABLE
);

//local parameter
localparam  DL_NUM_SECTOR           =      `DL_NUM_SECTOR                                                   ;
localparam  UL_NUM_SECTOR           =      `UL_NUM_SECTOR                                                   ;
localparam  RA_NUM_SECTOR           =      `RA_NUM_SECTOR                                                   ;
localparam  NB_NUM_SECTOR           =      `NB_NUM_SECTOR                                                   ;
localparam  MT_NUM_SECTOR           =      `MT_NUM_SECTOR                                                   ;
localparam  ID_SECTOR00             =       0                                                               ;
localparam  ID_SECTOR01             =       1                                                               ;
localparam  DLY_RST                 =       4                                                               ;
localparam  CPUIF_LPHY_ADDR_BW      =       20                                                              ;
localparam  DUMP_MEM_ADDR_BW        =       15                                                              ;
localparam  DLY_REG_RD              =       5                                                               ;
localparam  DLFE_ADDR_OFFSET        =       20'h00000                                                       ;           
localparam  ULFE_ADDR_OFFSET        =       20'h05000                                                       ;           
localparam  RAFE_ADDR_OFFSET        =       20'h09000                                                       ;           
localparam  EMTC_ADDR_OFFSET        =       20'h0A000                                                       ;           
localparam  NBIOT_ADDR_OFFSET       =       20'h0B000                                                       ;           
localparam  CC_REF                  =       0                                                               ;
localparam  MAX_CC                  =      `mlib_max5(DL_MAX_CC,UL_MAX_CC,RA_MAX_CC,MT_MAX_CC,NB_MAX_CC)    ;
localparam  MAX_ANT                 =      `mlib_max2(DL_NUM_ANT,UL_NUM_ANT)                                ;
localparam  DLFE_NUM_CC_MUX         =      `DLFE_NUM_CC_MUX                                                 ;
localparam  CORE_CLK_FRAME          =       2457600                                                         ;
localparam  VENDOR                  =       "Xilinx"                                                        ;
`ifndef SBIF_ENABLE
`ifndef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       13              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       10              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       10              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       7               ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`else //SBIF_ENABLE
`ifndef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       13              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       11              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       10              ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
localparam  NUM_DUMP_ITEM           =       8               ;
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
localparam  SBIF_REF                =       0               ;
localparam  MAX_BW_IDX              =      `MAX_BW_IDX      ;
`endif //SBIF_ENABLE

//logic variable
genvar  gidx, gcc, gant ;
integer ant ;

//module signal declaration
//u00_dlfe_core_cc
wire    [12-1:0]                                w_cc_din_bfn            [DL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_din_frame_sync     [DL_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_din_frame_idx      [DL_MAX_CC-1:0]             ; 
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_en             [DL_MAX_CC-1:0]             ;
wire    [08*DL_NUM_ANT-1:0]                     w_cc_din_frame_struct   [DL_MAX_CC-1:0]             ;        
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_re_mask        [DL_MAX_CC-1:0]             ;            
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_sys_mode_dss   [DL_MAX_CC-1:0]             ;            
wire    [2*TOP_DIO_BW*DL_NUM_ANT-1:0]           w_cc_din_iq             [DL_MAX_CC-1:0]             ; 
wire    [15*DL_NUM_ANT-1:0]                     w_cc_din_beam_id        [DL_MAX_CC-1:0]             ;            
wire    [10*DL_NUM_ANT-1:0]                     w_cc_din_start_prbu     [DL_MAX_CC-1:0]             ;            
wire    [08*DL_NUM_ANT-1:0]                     w_cc_din_num_prbu       [DL_MAX_CC-1:0]             ;            
wire    [24*DL_NUM_ANT-1:0]                     w_cc_din_freq_offset    [DL_MAX_CC-1:0]             ;            
wire    [05-1:0]                                w_cc_din_nlayer         [DL_MAX_CC-1:0]             ;            
wire    [01-1:0]                                w_cc_dout_bfn_strb      [DL_MAX_CC-1:0]             ;
wire    [12-1:0]                                w_cc_dout_bfn           [DL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_dout_frame_sync    [DL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_dout_subfrm_sync   [DL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_dout_slot_sync     [DL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_dout_symbol_sync   [DL_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_dout_frame_idx     [DL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_dout_subfrm_idx    [DL_MAX_CC-1:0]             ; 
wire    [06-1:0]                                w_cc_dout_slot_idx      [DL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_dout_symbol_idx    [DL_MAX_CC-1:0]             ;
wire    [01*DL_NUM_ANT-1:0]                     w_cc_dout_en            [DL_MAX_CC-1:0]             ;             
wire    [2*TOP_DIO_BW*DL_NUM_ANT-1:0]           w_cc_dout_iq            [DL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_dout_dl_bw_idx     [DL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_dout_dl_sys_mode   [DL_MAX_CC-1:0]             ;
wire    [12-1:0]                                w_cc_dout_dl_ntone      [DL_MAX_CC-1:0]             ;
wire    [02-1:0]                                w_cc_dout_dl_fft_type   [DL_MAX_CC-1:0]             ;
wire    [12-1:0]                                w_cc_dout_dl_k0         [DL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_dout_bcf_en        [DL_MAX_CC-1:0]             ;
reg     [01-1:0]                                r_cc_dout_frame_sync    [DL_MAX_CC-1:0]             ; 

//u01_ulfe_core_cc
wire    [01-1:0]                                w_cc_uin_frame_sync     [UL_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_uin_frame_idx      [UL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_uin_symbol_idx     [UL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_uin_en_technology  [UL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_uin_technology_dss [UL_MAX_CC-1:0]             ;
wire    [01-1:0]                                w_cc_uout_frame_sync    [UL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_uout_symbol_sync   [UL_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_uout_frame_idx     [UL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_uout_subfrm_idx    [UL_MAX_CC-1:0]             ; 
wire    [06-1:0]                                w_cc_uout_slot_idx      [UL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_uout_symbol_idx    [UL_MAX_CC-1:0]             ;
wire    [16*UL_NUM_ANT-1:0]                     w_cc_uout_start_re_idx  [UL_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_en            [UL_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_start_re      [UL_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_last_re       [UL_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_uout_iq            [UL_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_uout_ul_bw_idx     [UL_MAX_CC-1:0]             ;
reg     [01-1:0]                                r_cc_uin_frame_sync     [UL_MAX_CC-1:0]             ; 
reg     [01*UL_NUM_ANT-1:0]                     r_cc_uin_en             [UL_MAX_CC-1:0]             ; 
reg     [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           r_cc_uin_iq             [UL_MAX_CC-1:0]             ; 

//u02_rafe_core_cc
wire    [01-1:0]                                w_cc_rin_frame_sync     [RA_MAX_CC-1:0]             ; 
wire    [04*RA_NUM_ANT-1:0]                     w_cc_rin_filter_idx     [RA_MAX_CC-1:0]             ; 
wire    [16*RA_NUM_ANT-1:0]                     w_cc_rin_time_offset    [RA_MAX_CC-1:0]             ; 
wire    [08*RA_NUM_ANT-1:0]                     w_cc_rin_frame_struct   [RA_MAX_CC-1:0]             ; 
wire    [16*RA_NUM_ANT-1:0]                     w_cc_rin_cp_length      [RA_MAX_CC-1:0]             ;
wire    [24*RA_NUM_ANT-1:0]                     w_cc_rin_freq_offset    [RA_MAX_CC-1:0]             ; 
wire    [04*RA_NUM_ANT-1:0]                     w_cc_rin_num_psymbol    [RA_MAX_CC-1:0]             ; 
wire    [03*RA_NUM_ANT-1:0]                     w_cc_rin_num_ro         [RA_MAX_CC-1:0]             ; 
wire    [08*RA_NUM_ANT-1:0]                     w_cc_rin_num_prbc       [RA_MAX_CC-1:0]             ; 
wire    [10*RA_NUM_ANT-1:0]                     w_cc_rin_start_prbc     [RA_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_rout_frame_sync    [RA_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_rout_frame_idx     [RA_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_rout_subfrm_idx    [RA_MAX_CC-1:0]             ; 
wire    [06-1:0]                                w_cc_rout_slot_idx      [RA_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_rout_symbol_idx    [RA_MAX_CC-1:0]             ;
wire    [01*RA_NUM_ANT-1:0]                     w_cc_rout_en            [RA_MAX_CC-1:0]             ; 
wire    [16*RA_NUM_ANT-1:0]                     w_cc_rout_start_re_idx  [RA_MAX_CC-1:0]             ; 
wire    [01*RA_NUM_ANT-1:0]                     w_cc_rout_start_re      [RA_MAX_CC-1:0]             ; 
wire    [01*RA_NUM_ANT-1:0]                     w_cc_rout_last_re       [RA_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*RA_NUM_ANT-1:0]           w_cc_rout_iq            [RA_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_sect_rout_frame_sync  [RA_MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ; 
wire    [08-1:0]                                w_sect_rout_frame_idx   [RA_MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ; 
wire    [04-1:0]                                w_sect_rout_subfrm_idx  [RA_MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ; 
wire    [06-1:0]                                w_sect_rout_slot_idx    [RA_MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ; 
wire    [04-1:0]                                w_sect_rout_symbol_idx  [RA_MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ;

`ifndef NBIOT_CORE_DISABLE
//u03_nbiot_core_cc
reg     [ 1                                       -1:0] r_cc_nin_frame_sync [2  -1:0]              ; 
reg     [ 1 * NB_NUM_ANT                          -1:0] r_cc_nin_en         [2  -1:0]              ; 
reg     [ 2 * TOP_DIO_BW * NB_NUM_ANT             -1:0] r_cc_nin_iq         [2  -1:0]              ; 

// nbiot_wrapper
wire    [ 1 * NB_MAX_CC * CPUIF_LPHY_ADDR_BW      -1:0] w_cc_s_nw_core_addr                        ;
wire    [ 1 * NB_MAX_CC                           -1:0] w_cc_s_nw_core_wren                        ;
wire    [ 1 * NB_MAX_CC * CPUIF_DATA_BW           -1:0] w_cc_s_nw_core_wdata                       ;
wire    [ 1 * NB_MAX_CC                           -1:0] w_cc_s_nw_core_rden                        ;
wire    [ 1 * NB_MAX_CC * CPUIF_DATA_BW           -1:0] w_cc_s_nw_rdata                            ;
wire    [ 1 * NB_MAX_CC                           -1:0] w_cc_s_nw_rd_valid                         ;

wire    [ 4 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_filter_idx                        ; 
wire    [16 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_time_offset                       ; 
wire    [ 8 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_frame_struct                      ; 
wire    [16 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_cp_length                         ;
wire    [24 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_freq_offset                       ; 
wire    [ 4 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_num_psymbol                       ; 
wire    [ 3 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_num_ro                            ; 
wire    [ 8 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_num_prbc                          ; 
wire    [10 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nin_start_prbc                        ; 
wire    [ 1 *  2                                  -1:0] w_cc_nin_frame_sync                        ; 
wire    [ 8 *  2                                  -1:0] w_cc_nin_frame_idx                         ; 
wire    [ 1 *  2        * NB_NUM_ANT              -1:0] w_cc_nin_en                                ; 
wire    [ 2 *  2        * NB_NUM_ANT * TOP_DIO_BW -1:0] w_cc_nin_iq                                ; 
wire    [ 1 *  2                                  -1:0] w_cc_nout_nco_valid                        ;
wire    [ 8 *  2                                  -1:0] w_cc_nout_frame_struct                     ;
wire    [24 *  2                                  -1:0] w_cc_nout_freq_offset                      ;
wire    [ 1 * NB_MAX_CC                           -1:0] w_cc_nout_frame_sync                       ; 
wire    [ 8 * NB_MAX_CC                           -1:0] w_cc_nout_frame_idx                        ; 
wire    [ 4 * NB_MAX_CC                           -1:0] w_cc_nout_subfrm_idx                       ; 
wire    [ 6 * NB_MAX_CC                           -1:0] w_cc_nout_slot_idx                         ; 
wire    [ 6 * NB_MAX_CC                           -1:0] w_cc_nout_symbol_idx                       ;
wire    [ 1 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nout_en                               ; 
wire    [ 2 * NB_MAX_CC * NB_NUM_ANT * TOP_DIO_BW -1:0] w_cc_nout_iq                               ; 
wire    [16 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nout_start_re_idx                     ; 
wire    [ 1 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nout_start_re                         ; 
wire    [ 1 * NB_MAX_CC * NB_NUM_ANT              -1:0] w_cc_nout_last_re                          ; 
wire    [ 4 * NB_MAX_CC                           -1:0] w_cc_nout_nb_bw_idx                        ; 

`endif//NBIOT_CORE_DISABLE

`ifndef EMTC_CORE_DISABLE
//u04_emtc_core_cc
wire    [01-1:0]                                w_cc_min_frame_sync     [MT_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_min_frame_idx      [MT_MAX_CC-1:0]             ; 
wire    [04*MT_NUM_ANT-1:0]                     w_cc_min_filter_idx     [MT_MAX_CC-1:0]             ; 
wire    [16*MT_NUM_ANT-1:0]                     w_cc_min_time_offset    [MT_MAX_CC-1:0]             ; 
wire    [08*MT_NUM_ANT-1:0]                     w_cc_min_frame_struct   [MT_MAX_CC-1:0]             ; 
wire    [16*MT_NUM_ANT-1:0]                     w_cc_min_cp_length      [MT_MAX_CC-1:0]             ;
wire    [24*MT_NUM_ANT-1:0]                     w_cc_min_freq_offset    [MT_MAX_CC-1:0]             ; 
wire    [04*MT_NUM_ANT-1:0]                     w_cc_min_num_psymbol    [MT_MAX_CC-1:0]             ; 
wire    [03*MT_NUM_ANT-1:0]                     w_cc_min_num_ro         [MT_MAX_CC-1:0]             ; 
wire    [08*MT_NUM_ANT-1:0]                     w_cc_min_num_prbc       [MT_MAX_CC-1:0]             ; 
wire    [10*MT_NUM_ANT-1:0]                     w_cc_min_start_prbc     [MT_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_mout_frame_sync    [MT_MAX_CC-1:0]             ; 
wire    [08-1:0]                                w_cc_mout_frame_idx     [MT_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_mout_subfrm_idx    [MT_MAX_CC-1:0]             ; 
wire    [06-1:0]                                w_cc_mout_slot_idx      [MT_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_mout_symbol_idx    [MT_MAX_CC-1:0]             ;
wire    [01*MT_NUM_ANT-1:0]                     w_cc_mout_en            [MT_MAX_CC-1:0]             ; 
wire    [16*MT_NUM_ANT-1:0]                     w_cc_mout_start_re_idx  [MT_MAX_CC-1:0]             ; 
wire    [01*MT_NUM_ANT-1:0]                     w_cc_mout_start_re      [MT_MAX_CC-1:0]             ; 
wire    [01*MT_NUM_ANT-1:0]                     w_cc_mout_last_re       [MT_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*MT_NUM_ANT-1:0]           w_cc_mout_iq            [MT_MAX_CC-1:0]             ; 
wire    [04-1:0]                                w_cc_mout_mt_bw_idx     [MT_MAX_CC-1:0]             ; 
reg     [01-1:0]                                r_cc_min_frame_sync     [MT_MAX_CC-1:0]             ; 
reg     [01*MT_NUM_ANT-1:0]                     r_cc_min_en             [MT_MAX_CC-1:0]             ; 
reg     [2*TOP_DIO_BW*MT_NUM_ANT-1:0]           r_cc_min_iq             [MT_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_sect_mout_frame_sync  [MT_MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ; 
wire    [08-1:0]                                w_sect_mout_frame_idx   [MT_MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ; 
wire    [04-1:0]                                w_sect_mout_subfrm_idx  [MT_MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ; 
wire    [06-1:0]                                w_sect_mout_slot_idx    [MT_MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ; 
wire    [04-1:0]                                w_sect_mout_symbol_idx  [MT_MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ;
`endif//EMTC_CORE_DISABLE

//u05_ul_sync

//u06_lphy_top_cpu_if
wire    [CPUIF_LPHY_ADDR_BW*MAX_CC-1:0]         w_core_addr                                         ;
wire    [01*MAX_CC-1:0]                         w_core_wren                                         ;
wire    [CPUIF_DATA_BW*MAX_CC-1:0]              w_core_wdata                                        ;
wire    [01*MAX_CC-1:0]                         w_core_rden                                         ;
wire    [CPUIF_DATA_BW*MAX_CC-1:0]              w_core_rdata                                        ;
wire    [01*MAX_CC-1:0]                         w_core_rd_valid                                     ;
wire    [CPUIF_LPHY_ADDR_BW-1:0]                w_cc_s_core_addr        [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_s_core_wren        [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_core_wdata       [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_s_core_rden        [MAX_CC-1:0]                ;
reg     [CPUIF_DATA_BW-1:0]                     r_cc_s_core_rdata       [MAX_CC-1:0]                ;
reg     [01-1:0]                                r_cc_s_core_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_dlfe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_dlfe_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_ulfe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_ulfe_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_rafe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_rafe_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_nbiot_rdata      [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_nbiot_rd_valid   [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_emtc_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_emtc_rd_valid    [MAX_CC-1:0]                ;
reg     [CPUIF_DATA_BW-1:0]                     r_cc_s_rafe_rdata       [MAX_CC-1:0]                ;
reg     [00:0]                                  r_cc_s_rafe_rd_valid    [MAX_CC-1:0]                ;
reg     [CPUIF_DATA_BW-1:0]                     r_cc_s_emtc_rdata       [MAX_CC-1:0]                ;
reg     [00:0]                                  r_cc_s_emtc_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_sect_s_rafe_rdata     [MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ;
wire    [00:0]                                  w_sect_s_rafe_rd_valid  [MAX_CC-1:0][RA_NUM_SECTOR-1:0]         ;
wire    [CPUIF_DATA_BW-1:0]                     w_sect_s_emtc_rdata     [MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ;
wire    [00:0]                                  w_sect_s_emtc_rd_valid  [MAX_CC-1:0][MT_NUM_SECTOR-1:0]         ;
wire    [22*MAX_CC-1:0]                         w_cc_ul_retard                                      ;
wire    [22*MAX_CC-1:0]                         w_cc_nb_retard                                      ;
wire    [22*MAX_CC-1:0]                         w_cc_mt_retard                                      ;
wire    [01-1:0]                                w_lphy_top_par_100008                               ;
wire    [01-1:0]                                w_sigcap_par_180000                                 ;
wire    [$clog2(MAX_CC)-1:0]                    w_sigcap_par_180004                                 ;
wire    [$clog2(MAX_ANT)-1:0]                   w_sigcap_par_180008                                 ;
wire    [12-1:0]                                w_sigcap_par_18000c                                 ;
wire    [04-1:0]                                w_sigcap_par_180010                                 ;
wire    [08-1:0]                                w_sigcap_par_180014                                 ;
wire    [04-1:0]                                w_sigcap_par_180018                                 ;
wire    [$clog2(NUM_DUMP_ITEM)-1:0]             w_sigcap_par_18001c                                 ;
wire    [03-1:0]                                w_sigcap_par_180020                                 ;
wire    [04-1:0]                                w_sigcap_par_180024                                 ;
wire    [03-1:0]                                w_sigcap_par_180028                                 ;
wire    [32-1:0]                                w_sigcap_par_18002c                                 ;

//u07_proc_dly
wire    [22*MAX_CC-1:0]                         w_cc_dl_proc_dly                                    ;
wire    [22*MAX_CC-1:0]                         w_cc_ul_proc_dly                                    ;
wire    [22*MAX_CC-1:0]                         w_cc_ra_proc_dly                                    ;
wire    [22*MAX_CC-1:0]                         w_cc_nb_proc_dly                                    ;
wire    [22*MAX_CC-1:0]                         w_cc_mt_proc_dly                                    ;
wire    [01*MAX_CC-1:0]                         w_cc_dl_fsync                                       ;
wire    [01*MAX_CC-1:0]                         w_cc_ul_fsync                                       ;
wire    [01*MAX_CC-1:0]                         w_cc_nb_fsync                                       ;
wire    [01*MAX_CC-1:0]                         w_cc_mt_fsync                                       ;

//u08_cpu_rst_sync
wire                                            w_cpu_rst                                           ; 

//u08_lphy_rst_sync
wire    [MAX_CC-1:0]                            w_core_rst_lphy_top                                 ; 
wire    [MAX_CC-1:0]                            w_core_rst_dlfe                                     ; 
wire    [MAX_CC-1:0]                            w_core_rst_ulfe                                     ;
wire    [MAX_CC-1:0]                            w_core_rst_rafe                                     ;

//u09_sig_cap
wire    [00:0]                                  w_dump_wr_en                                        ;
wire    [DUMP_MEM_ADDR_BW-1:0]                  w_dump_wr_addr                                      ; 
wire    [CPUIF_DATA_BW-1:0]                     w_dump_wr_data                                      ; 
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_dl_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_ra_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_nb_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_mt_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW-1:0]                      w_nr_dl_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
wire    [2*TOP_DIO_BW-1:0]                      w_nr_ra_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
wire    [2*TOP_DIO_BW-1:0]                      w_nr_nb_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
wire    [2*TOP_DIO_BW-1:0]                      w_nr_mt_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
reg     [12*MAX_CC-1:0]                         r_sig_cap_bfn                                       ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_din_frame_sync                            ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_din_en                                    ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_din_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_dout_frame_sync                           ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_dout_en                                   ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_dout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_uout_frame_sync                           ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_uout_en                                   ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_uout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_uin_frame_sync                            ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_uin_en                                    ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_uin_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_rout_frame_sync                           ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_rout_en                                   ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_rout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_nin_frame_sync                            ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_nin_en                                    ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nin_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_nout_frame_sync                           ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_nout_en                                   ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_min_frame_sync                            ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_min_en                                    ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_min_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_mout_frame_sync                           ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_mout_en                                   ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_mout_iq                                   ; 
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_dl_cp_data                             ;
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_ra_cp_data                             ;
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_nb_cp_data                             ;
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_mt_cp_data                             ;
`ifdef SBIF_ENABLE
reg     [01*MAX_CC-1:0]                         r_sig_cap_usbif_frame_sync                          ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_usbif_en                                  ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_usbif_iq                                  ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_nsbif_frame_sync                          ; 
reg     [01*MAX_ANT*MAX_CC-1:0]                 r_sig_cap_nsbif_en                                  ;             
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nsbif_iq                                  ; 
`endif //SBIF_ENABLE
wire    [01*MAX_CC*NUM_DUMP_ITEM-1:0]                         w_sig_cap_frame_sync                  ; 
wire    [01*MAX_ANT*MAX_CC*NUM_DUMP_ITEM-1:0]                 w_sig_cap_en                          ;             
wire    [2*TOP_DIO_BW*MAX_ANT*MAX_CC*NUM_DUMP_ITEM-1:0]       w_sig_cap_iq                          ; 

reg     [01-1:0]                                r_sigcap_par_180000                                 ;
reg     [$clog2(MAX_CC)-1:0]                    r_sigcap_par_180004                                 ;
reg     [$clog2(MAX_ANT)-1:0]                   r_sigcap_par_180008                                 ;
reg     [12-1:0]                                r_sigcap_par_18000c                                 ;
reg     [04-1:0]                                r_sigcap_par_180010                                 ;
reg     [08-1:0]                                r_sigcap_par_180014                                 ;
reg     [04-1:0]                                r_sigcap_par_180018                                 ;
reg     [$clog2(NUM_DUMP_ITEM)-1:0]             r_sigcap_par_18001c                                 ;
reg     [03-1:0]                                r_sigcap_par_180020                                 ;
reg     [04-1:0]                                r_sigcap_par_180024                                 ;
reg     [03-1:0]                                r_sigcap_par_180028                                 ;
reg     [32-1:0]                                r_sigcap_par_18002c                                 ;

`ifdef SBIF_ENABLE
//g12_0_0_dl_sbif_sig_map
wire    [01-1:0]                                w_dsbif_out_bfn_strb    [DL_MAX_CC-1:0]             ;
wire    [12-1:0]                                w_dsbif_out_bfn         [DL_MAX_CC-1:0]             ;
wire    [01*DL_MAX_CC-1:0]                      w_dsbif_out_en                                      ;             
wire    [2*TOP_DIO_BW-1:0]                      w_dsbif_out_iq          [DL_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW-1:0]                      w_dsbif_out_iq_mux      [DL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_dsbif_fsync           [DL_NUM_SBIF-1:0]           ;
wire    [01-1:0]                                w_dsbif_data_en         [DL_NUM_SBIF-1:0]           ;

//g12_1_0_ul_sbif_sig_in
reg     [01-1:0]                                r_usbif_in_fsync        [UL_NUM_SBIF-1:0]           ; 
reg     [01-1:0]                                r_usbif_in_bfn_strb     [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_in_bfn_strb     [UL_NUM_SBIF-1:0]           ; 
wire    [12-1:0]                                w_usbif_in_bfn          [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_in_csync        [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_in_en           [UL_NUM_SBIF-1:0]           ; 
wire    [2*TOP_DIO_BW-1:0]                      w_usbif_in_iq_mux       [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_out_bfn_strb    [UL_NUM_SBIF-1:0]           ; 
wire    [12-1:0]                                w_usbif_out_bfn         [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_out_fsync       [UL_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_usbif_out_en          [UL_NUM_SBIF-1:0]           ; 
wire    [2*TOP_DIO_BW-1:0]                      w_usbif_out_iq_mux      [UL_NUM_SBIF-1:0]           ; 

//g12_1_1_ul_sbif_sig_demap
wire    [01-1:0]                                w_cc_usbif_bfn_strb     [UL_MAX_CC-1:0]             ; 
wire    [12-1:0]                                w_cc_usbif_bfn          [UL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_usbif_frame_sync   [UL_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_usbif_en           [UL_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_usbif_iq           [UL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_usbif_a_bfn_strb   [UL_MAX_CC-1:0]             ; 
wire    [12-1:0]                                w_cc_usbif_a_bfn        [UL_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_usbif_a_frame_sync [UL_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_usbif_a_en         [UL_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_usbif_a_iq         [UL_MAX_CC-1:0]             ; 

`ifndef NBIOT_CORE_DISABLE
//g12_2_0_nb_sbif_sig_in
reg     [01-1:0]                                r_nsbif_in_fsync        [NB_NUM_SBIF-1:0]           ; 
reg     [01-1:0]                                r_nsbif_in_bfn_strb     [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_in_bfn_strb     [NB_NUM_SBIF-1:0]           ; 
wire    [12-1:0]                                w_nsbif_in_bfn          [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_in_csync        [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_in_en           [NB_NUM_SBIF-1:0]           ; 
wire    [2*TOP_DIO_BW-1:0]                      w_nsbif_in_iq_mux       [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_out_bfn_strb    [NB_NUM_SBIF-1:0]           ; 
wire    [12-1:0]                                w_nsbif_out_bfn         [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_out_fsync       [NB_NUM_SBIF-1:0]           ; 
wire    [01-1:0]                                w_nsbif_out_en          [NB_NUM_SBIF-1:0]           ; 
wire    [2*TOP_DIO_BW-1:0]                      w_nsbif_out_iq_mux      [NB_NUM_SBIF-1:0]           ; 

//g12_2_1_nb_sbif_sig_demap
wire    [01-1:0]                                w_cc_nsbif_bfn_strb     [NB_MAX_CC-1:0]             ; 
wire    [12-1:0]                                w_cc_nsbif_bfn          [NB_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_nsbif_frame_sync   [NB_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_nsbif_en           [NB_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_nsbif_iq           [NB_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_nsbif_a_bfn_strb   [NB_MAX_CC-1:0]             ; 
wire    [12-1:0]                                w_cc_nsbif_a_bfn        [NB_MAX_CC-1:0]             ; 
wire    [01-1:0]                                w_cc_nsbif_a_frame_sync [NB_MAX_CC-1:0]             ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_nsbif_a_en         [NB_MAX_CC-1:0]             ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_nsbif_a_iq         [NB_MAX_CC-1:0]             ; 
`endif//NBIOT_CORE_DISABLE
`endif //SBIF_ENABLE

`ifndef DLFE_CORE_DISABLE
//u00_dlfe_core_cc
`ifndef DLFE_CELL_MUX_DISABLE
generate for(gcc=0; gcc<DL_NUM_CC/DLFE_NUM_CC_MUX; gcc=gcc+1) begin : g00_0_dlfe_core_ncc
if(DLFE_NUM_CC_MUX==2) begin : g00_0_0_dlfe_core_2cc_mux
if(((DL_NUM_CC%DLFE_NUM_CC_MUX)==0)||(((DL_NUM_CC%DLFE_NUM_CC_MUX)!=0)&&(gcc<=DL_NUM_CC/DLFE_NUM_CC_MUX-1))) begin : g00_0_0_0_dlfe_core_2cc
dlfe_cc 
`ifndef NSIM
#(   .NUM_CC                ( DLFE_NUM_CC_MUX       )          
    ,.NUM_LAYER             ( DL_NUM_ANT            )          
    ,.NUM_ANT               ( DL_NUM_ANT            )          
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-4          )
    ,.ADDR_OFFSET           ( DLFE_ADDR_OFFSET      )
    ,.VENDOR                ( VENDOR                ))
`endif //NSIM
u00_dlfe_core_2cc
(
    .i_clk                  ( i_core_clk                    ) 
   ,.i_rst                  ({w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+1], w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_addr             ({w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_wren             ({w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_wdata            ({w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_rden             ({w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_cpu_rdata            ({w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_cpu_rd_valid         ({w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_bfn              ({w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_sync       ({w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_idx        ({w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_en               ({w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_struct     ({w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_re_mask          ({w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_sys_mode_dss     ({w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_iq               ({w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_beam_id          ({w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_start_prbu       ({w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_num_prbu         ({w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_freq_offset      ({w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_nlayer           ({w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bfn_strb        ({w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bfn             ({w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_frame_sync      ({w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_subfrm_sync     ({w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_slot_sync       ({w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_symbol_sync     ({w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_frame_idx       ({w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_subfrm_idx      ({w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_slot_idx        ({w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_symbol_idx      ({w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_en              ({w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_iq              ({w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_bw_idx       ({w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_sys_mode     ({w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+0]} )
   ,.o_dout_dl_ntone        ({w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_fft_type     ({w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_k0           ({w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bcf_en          ({w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+0]} )
);
end
if (((DL_NUM_CC%DLFE_NUM_CC_MUX)!=0)&&(gcc==DL_NUM_CC/DLFE_NUM_CC_MUX-1)) begin : g00_0_0_1_dlfe_core_1cc
dlfe_cc 
`ifndef NSIM
#(   .NUM_CC                ( 1                     )          
    ,.NUM_LAYER             ( DL_NUM_ANT            )          
    ,.NUM_ANT               ( DL_NUM_ANT            )          
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-4          )
    ,.ADDR_OFFSET           ( DLFE_ADDR_OFFSET      )
    ,.VENDOR                ( VENDOR                ))
`endif //NSIM
u00_dlfe_core_cc
(
    .i_clk                  ( i_core_clk                            ) 
   ,.i_rst                  ( w_core_rst_dlfe       [DL_NUM_CC-1]   ) 
   ,.i_cpu_addr             ( w_cc_s_core_addr      [DL_NUM_CC-1]   ) 
   ,.i_cpu_wren             ( w_cc_s_core_wren      [DL_NUM_CC-1]   ) 
   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [DL_NUM_CC-1]   ) 
   ,.i_cpu_rden             ( w_cc_s_core_rden      [DL_NUM_CC-1]   ) 
   ,.o_cpu_rdata            ( w_cc_s_dlfe_rdata     [DL_NUM_CC-1]   ) 
   ,.o_cpu_rd_valid         ( w_cc_s_dlfe_rd_valid  [DL_NUM_CC-1]   ) 
   ,.i_din_bfn              ( w_cc_din_bfn          [DL_NUM_CC-1]   ) 
   ,.i_din_frame_sync       ( w_cc_din_frame_sync   [DL_NUM_CC-1]   ) 
   ,.i_din_frame_idx        ( w_cc_din_frame_idx    [DL_NUM_CC-1]   ) 
   ,.i_din_en               ( w_cc_din_en           [DL_NUM_CC-1]   ) 
   ,.i_din_frame_struct     ( w_cc_din_frame_struct [DL_NUM_CC-1]   ) 
   ,.i_din_re_mask          ( w_cc_din_re_mask      [DL_NUM_CC-1]   ) 
   ,.i_din_sys_mode_dss     ( w_cc_din_sys_mode_dss [DL_NUM_CC-1]   ) 
   ,.i_din_iq               ( w_cc_din_iq           [DL_NUM_CC-1]   ) 
   ,.i_din_beam_id          ( w_cc_din_beam_id      [DL_NUM_CC-1]   ) 
   ,.i_din_start_prbu       ( w_cc_din_start_prbu   [DL_NUM_CC-1]   ) 
   ,.i_din_num_prbu         ( w_cc_din_num_prbu     [DL_NUM_CC-1]   ) 
   ,.i_din_freq_offset      ( w_cc_din_freq_offset  [DL_NUM_CC-1]   ) 
   ,.i_din_nlayer           ( w_cc_din_nlayer       [DL_NUM_CC-1]   ) 
   ,.o_dout_bfn_strb        ( w_cc_dout_bfn_strb    [DL_NUM_CC-1]   ) 
   ,.o_dout_bfn             ( w_cc_dout_bfn         [DL_NUM_CC-1]   ) 
   ,.o_dout_frame_sync      ( w_cc_dout_frame_sync  [DL_NUM_CC-1]   ) 
   ,.o_dout_subfrm_sync     ( w_cc_dout_subfrm_sync [DL_NUM_CC-1]   ) 
   ,.o_dout_slot_sync       ( w_cc_dout_slot_sync   [DL_NUM_CC-1]   ) 
   ,.o_dout_symbol_sync     ( w_cc_dout_symbol_sync [DL_NUM_CC-1]   ) 
   ,.o_dout_frame_idx       ( w_cc_dout_frame_idx   [DL_NUM_CC-1]   ) 
   ,.o_dout_subfrm_idx      ( w_cc_dout_subfrm_idx  [DL_NUM_CC-1]   ) 
   ,.o_dout_slot_idx        ( w_cc_dout_slot_idx    [DL_NUM_CC-1]   ) 
   ,.o_dout_symbol_idx      ( w_cc_dout_symbol_idx  [DL_NUM_CC-1]   ) 
   ,.o_dout_en              ( w_cc_dout_en          [DL_NUM_CC-1]   ) 
   ,.o_dout_iq              ( w_cc_dout_iq          [DL_NUM_CC-1]   ) 
   ,.o_dout_dl_bw_idx       ( w_cc_dout_dl_bw_idx   [DL_NUM_CC-1]   ) 
   ,.o_dout_dl_sys_mode     ( w_cc_dout_dl_sys_mode [DL_NUM_CC-1]   )
   ,.o_dout_dl_ntone        ( w_cc_dout_dl_ntone    [DL_NUM_CC-1]   ) 
   ,.o_dout_dl_fft_type     ( w_cc_dout_dl_fft_type [DL_NUM_CC-1]   ) 
   ,.o_dout_dl_k0           ( w_cc_dout_dl_k0       [DL_NUM_CC-1]   ) 
   ,.o_dout_bcf_en          ( w_cc_dout_bcf_en      [DL_NUM_CC-1]   )
);
end
end //DLFE_NUM_CC_MUX==2
else if(DLFE_NUM_CC_MUX==4) begin : g00_0_0_dlfe_core_4cc
dlfe_cc 
`ifndef NSIM
#(   .NUM_CC                ( DLFE_NUM_CC_MUX       )          
    ,.NUM_LAYER             ( DL_NUM_ANT            )          
    ,.NUM_ANT               ( DL_NUM_ANT            )          
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-4          )
    ,.ADDR_OFFSET           ( DLFE_ADDR_OFFSET      )
    ,.VENDOR                ( VENDOR                ))
`endif //NSIM
u00_dlfe_core_4cc
(
    .i_clk                  ( i_core_clk                    ) 
   ,.i_rst                  ({w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+3], w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+2], w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+1], w_core_rst_dlfe       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_addr             ({w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_addr      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_wren             ({w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_wren      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_wdata            ({w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_wdata     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_cpu_rden             ({w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_core_rden      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_cpu_rdata            ({w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_dlfe_rdata     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_cpu_rd_valid         ({w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+3], w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+2], w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+1], w_cc_s_dlfe_rd_valid  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_bfn              ({w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_bfn          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_sync       ({w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_sync   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_idx        ({w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_idx    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_en               ({w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_en           [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_frame_struct     ({w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_frame_struct [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_re_mask          ({w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_re_mask      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_sys_mode_dss     ({w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_sys_mode_dss [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_iq               ({w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_iq           [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_beam_id          ({w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_beam_id      [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_start_prbu       ({w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_start_prbu   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_num_prbu         ({w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_num_prbu     [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_freq_offset      ({w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_freq_offset  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.i_din_nlayer           ({w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+3], w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+2], w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+1], w_cc_din_nlayer       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bfn_strb        ({w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bfn_strb    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bfn             ({w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bfn         [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_frame_sync      ({w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_frame_sync  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_subfrm_sync     ({w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_subfrm_sync [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_slot_sync       ({w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_slot_sync   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_symbol_sync     ({w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_symbol_sync [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_frame_idx       ({w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_frame_idx   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_subfrm_idx      ({w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_subfrm_idx  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_slot_idx        ({w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_slot_idx    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_symbol_idx      ({w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_symbol_idx  [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_en              ({w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_en          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_iq              ({w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_iq          [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_bw_idx       ({w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_bw_idx   [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_sys_mode     ({w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_sys_mode [gcc*DLFE_NUM_CC_MUX+0]} )
   ,.o_dout_dl_ntone        ({w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_ntone    [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_fft_type     ({w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_fft_type [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_dl_k0           ({w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_dl_k0       [gcc*DLFE_NUM_CC_MUX+0]} ) 
   ,.o_dout_bcf_en          ({w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+3], w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+2], w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+1], w_cc_dout_bcf_en      [gcc*DLFE_NUM_CC_MUX+0]} )
);
end //DLFE_NUM_CC_MUX==4
end
endgenerate
`else// DLFE_CELL_MUX_DISABLE
generate for(gcc=0; gcc<DL_NUM_CC; gcc=gcc+1) begin : g00_dlfe_core_cc
dlfe_cc 
`ifndef NSIM
#(   .NUM_CC                ( 1                             )          
    ,.NUM_LAYER             ( DL_NUM_ANT                    )          
    ,.NUM_ANT               ( DL_NUM_ANT                    )          
    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-4                  )
    ,.ADDR_OFFSET           ( DLFE_ADDR_OFFSET              )
    ,.VENDOR                ( VENDOR                        ))
`endif //NSIM
u00_dlfe_core_cc
(
    .i_clk                  ( i_core_clk                    ) 
   ,.i_rst                  ( w_core_rst_dlfe       [gcc]   ) 
   ,.i_cpu_addr             ( w_cc_s_core_addr      [gcc]   ) 
   ,.i_cpu_wren             ( w_cc_s_core_wren      [gcc]   ) 
   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [gcc]   ) 
   ,.i_cpu_rden             ( w_cc_s_core_rden      [gcc]   ) 
   ,.o_cpu_rdata            ( w_cc_s_dlfe_rdata     [gcc]   ) 
   ,.o_cpu_rd_valid         ( w_cc_s_dlfe_rd_valid  [gcc]   ) 
   ,.i_din_bfn              ( w_cc_din_bfn          [gcc]   ) 
   ,.i_din_frame_sync       ( w_cc_din_frame_sync   [gcc]   ) 
   ,.i_din_frame_idx        ( w_cc_din_frame_idx    [gcc]   ) 
   ,.i_din_en               ( w_cc_din_en           [gcc]   ) 
   ,.i_din_frame_struct     ( w_cc_din_frame_struct [gcc]   ) 
   ,.i_din_re_mask          ( w_cc_din_re_mask      [gcc]   ) 
   ,.i_din_sys_mode_dss     ( w_cc_din_sys_mode_dss [gcc]   ) 
   ,.i_din_iq               ( w_cc_din_iq           [gcc]   ) 
   ,.i_din_beam_id          ( w_cc_din_beam_id      [gcc]   ) 
   ,.i_din_start_prbu       ( w_cc_din_start_prbu   [gcc]   ) 
   ,.i_din_num_prbu         ( w_cc_din_num_prbu     [gcc]   ) 
   ,.i_din_freq_offset      ( w_cc_din_freq_offset  [gcc]   ) 
   ,.i_din_nlayer           ( w_cc_din_nlayer       [gcc]   ) 
   ,.o_dout_bfn_strb        ( w_cc_dout_bfn_strb    [gcc]   ) 
   ,.o_dout_bfn             ( w_cc_dout_bfn         [gcc]   ) 
   ,.o_dout_frame_sync      ( w_cc_dout_frame_sync  [gcc]   ) 
   ,.o_dout_subfrm_sync     ( w_cc_dout_subfrm_sync [gcc]   ) 
   ,.o_dout_slot_sync       ( w_cc_dout_slot_sync   [gcc]   ) 
   ,.o_dout_symbol_sync     ( w_cc_dout_symbol_sync [gcc]   ) 
   ,.o_dout_frame_idx       ( w_cc_dout_frame_idx   [gcc]   ) 
   ,.o_dout_subfrm_idx      ( w_cc_dout_subfrm_idx  [gcc]   ) 
   ,.o_dout_slot_idx        ( w_cc_dout_slot_idx    [gcc]   ) 
   ,.o_dout_symbol_idx      ( w_cc_dout_symbol_idx  [gcc]   ) 
   ,.o_dout_en              ( w_cc_dout_en          [gcc]   ) 
   ,.o_dout_iq              ( w_cc_dout_iq          [gcc]   ) 
   ,.o_dout_dl_bw_idx       ( w_cc_dout_dl_bw_idx   [gcc]   ) 
   ,.o_dout_dl_sys_mode     ( w_cc_dout_dl_sys_mode [gcc]   )
   ,.o_dout_dl_ntone        ( w_cc_dout_dl_ntone    [gcc]   ) 
   ,.o_dout_dl_fft_type     ( w_cc_dout_dl_fft_type [gcc]   ) 
   ,.o_dout_dl_k0           ( w_cc_dout_dl_k0       [gcc]   ) 
   ,.o_dout_bcf_en          ( w_cc_dout_bcf_en      [gcc]   )
);
end
endgenerate
`endif// DLFE_CELL_MUX_DISABLE
`endif //DLFE_CORE_DISABLE 

`ifndef ULFE_CORE_DISABLE
//u01_ulfe_core_cc
generate for(gcc=0; gcc<UL_NUM_CC; gcc=gcc+1) begin : g01_ulfe_core_cc
ulfe_cc 
`ifndef NSIM
#(   .NUM_ANT               ( UL_NUM_ANT                    )   
    ,.NUM_CHAIN             ( 1                             )         
    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
    ,.DLY_REG_RD            ( DLY_REG_RD                    )
    ,.ADDR_OFFSET           ( ULFE_ADDR_OFFSET              )
    ,.VENDOR                ( VENDOR                        )
)
`endif //NSIM
u01_ulfe_core_cc
(                                                               
    .i_clk                  ( i_core_clk                    )          
   ,.i_rst                  ( w_core_rst_ulfe         [gcc] )          
   ,.i_cpu_addr             ( w_cc_s_core_addr        [gcc] )          
   ,.i_cpu_wren             ( w_cc_s_core_wren        [gcc] )          
   ,.i_cpu_wdata            ( w_cc_s_core_wdata       [gcc] )          
   ,.i_cpu_rden             ( w_cc_s_core_rden        [gcc] )          
   ,.o_cpu_rdata            ( w_cc_s_ulfe_rdata       [gcc] )          
   ,.o_cpu_rd_valid         ( w_cc_s_ulfe_rd_valid    [gcc] )          
   ,.i_uin_frame_sync       ( w_cc_uin_frame_sync     [gcc] )          
   ,.i_uin_frame_idx        ( w_cc_uin_frame_idx      [gcc] )          
   ,.i_uin_en               ( r_cc_uin_en             [gcc] )          
   ,.i_uin_iq               ( r_cc_uin_iq             [gcc] )       
// ,.i_uin_symbol_idx       ( w_cc_uin_symbol_idx     [gcc] )
// ,.i_uin_en_technology    ( w_cc_uin_en_technology  [gcc] )
// ,.i_uin_technology_dss   ( w_cc_uin_technology_dss [gcc] )
   ,.o_uout_frame_sync      ( w_cc_uout_frame_sync    [gcc] )          
   ,.o_uout_symbol_sync     ( w_cc_uout_symbol_sync   [gcc] )          
   ,.o_uout_frame_idx       ( w_cc_uout_frame_idx     [gcc] )          
   ,.o_uout_subfrm_idx      ( w_cc_uout_subfrm_idx    [gcc] )          
   ,.o_uout_slot_idx        ( w_cc_uout_slot_idx      [gcc] )          
   ,.o_uout_symbol_idx      ( w_cc_uout_symbol_idx    [gcc] )          
   ,.o_uout_en              ( w_cc_uout_en            [gcc] )          
   ,.o_uout_iq              ( w_cc_uout_iq            [gcc] )          
   ,.o_uout_start_re_idx    ( w_cc_uout_start_re_idx  [gcc] )          
   ,.o_uout_start_re        ( w_cc_uout_start_re      [gcc] )          
   ,.o_uout_last_re         ( w_cc_uout_last_re       [gcc] )          
   ,.o_uout_ul_bw_idx       ( w_cc_uout_ul_bw_idx     [gcc] )         
);
end
endgenerate
`endif //ULFE_CORE_DISABLE

`ifndef RAFE_CORE_DISABLE
//u02_rafe_core_cc
generate for(gcc=0; gcc<RA_NUM_CC; gcc=gcc+1) begin : g02_rafe_core_cc
if(RA_NUM_SECTOR==1) begin : g02_0_rafe_core_cc
rafe_cc 
`ifndef NSIM
#(   .NUM_CC                ( 1                             )          
    ,.NUM_ANT               ( RA_NUM_ANT                    )          
    ,.NUM_CHAIN             ( 1                             )
    ,.MAX_OBW               (`MAX_OBW                       )
    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-3                  )
    ,.ADDR_OFFSET           ( RAFE_ADDR_OFFSET              )
    ,.VENDOR                ( VENDOR                        )
    ,.BAND_IDX              ( (gcc < UL_NUM_CC) ? 0 : 1     ))
`endif //NSIM
u02_rafe_core_cc
(                                                               
    .i_clk                  ( i_core_clk                    )          
   ,.i_rst                  ( w_core_rst_rafe       [gcc]   )          
   ,.i_cpu_addr             ( w_cc_s_core_addr      [gcc]   )          
   ,.i_cpu_wren             ( w_cc_s_core_wren      [gcc]   )          
   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [gcc]   )          
   ,.i_cpu_rden             ( w_cc_s_core_rden      [gcc]   )          
   ,.o_cpu_rdata            ( w_cc_s_rafe_rdata     [gcc]   )          
   ,.o_cpu_rd_valid         ( w_cc_s_rafe_rd_valid  [gcc]   )          
   ,.i_rin_frame_sync       ( w_cc_uin_frame_sync   [gcc]   )
   ,.i_rin_frame_idx        ( w_cc_uin_frame_idx    [gcc]   )
   ,.i_rin_en               ( r_cc_uin_en           [gcc]   )
   ,.i_rin_iq               ( r_cc_uin_iq           [gcc]   )
   ,.i_rin_filter_idx       ( w_cc_rin_filter_idx   [gcc]   )          
   ,.i_rin_time_offset      ( w_cc_rin_time_offset  [gcc]   )          
   ,.i_rin_frame_struct     ( w_cc_rin_frame_struct [gcc]   )          
   ,.i_rin_cp_length        ( w_cc_rin_cp_length    [gcc]   )          
   ,.i_rin_num_psymbol      ( w_cc_rin_num_psymbol  [gcc]   )          
   ,.i_rin_freq_offset      ( w_cc_rin_freq_offset  [gcc]   )          
   ,.i_rin_num_ro           ( w_cc_rin_num_ro       [gcc]   )          
   ,.i_rin_num_prbc         ( w_cc_rin_num_prbc     [gcc]   )    
   ,.i_rin_start_prbc       ( w_cc_rin_start_prbc   [gcc]   )       
   ,.o_rout_frame_sync      ( w_cc_rout_frame_sync  [gcc]   )          
   ,.o_rout_frame_idx       ( w_cc_rout_frame_idx   [gcc]   )          
   ,.o_rout_subfrm_idx      ( w_cc_rout_subfrm_idx  [gcc]   )          
   ,.o_rout_slot_idx        ( w_cc_rout_slot_idx    [gcc]   )          
   ,.o_rout_symbol_idx      ( w_cc_rout_symbol_idx  [gcc]   )          
   ,.o_rout_en              ( w_cc_rout_en          [gcc]   )          
   ,.o_rout_iq              ( w_cc_rout_iq          [gcc]   )          
   ,.o_rout_start_re_idx    ( w_cc_rout_start_re_idx[gcc]   )          
   ,.o_rout_start_re        ( w_cc_rout_start_re    [gcc]   )          
   ,.o_rout_last_re         ( w_cc_rout_last_re     [gcc]   )          
);
end //RA_NUM_SECTOR==1
else if(RA_NUM_SECTOR==2) begin : g02_1_rafe_core_2sect_cc
rafe_cc 
`ifndef NSIM
#(   .NUM_CC                ( RA_NUM_SECTOR                 )          
    ,.NUM_ANT               ( RA_NUM_ANT/RA_NUM_SECTOR      )          
    ,.NUM_CHAIN             ( 1                             )
    ,.MAX_OBW               (`MAX_OBW                       )
    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-3                  )
    ,.ADDR_OFFSET           ( RAFE_ADDR_OFFSET              )
    ,.VENDOR                ( VENDOR                        )
    ,.BAND_IDX              ( (gcc < UL_NUM_CC) ? 0 : 1     ))
`endif //NSIM
u02_rafe_core_cc
(                                                               
    .i_clk                  ( i_core_clk                                                                            )          
   ,.i_rst                  ( w_core_rst_rafe       [gcc]                                                           )          
   ,.i_cpu_addr             ({{RA_NUM_SECTOR}{w_cc_s_core_addr      [gcc]}}                                         )          
   ,.i_cpu_wren             ({{RA_NUM_SECTOR}{w_cc_s_core_wren      [gcc]}}                                         )          
   ,.i_cpu_wdata            ({{RA_NUM_SECTOR}{w_cc_s_core_wdata     [gcc]}}                                         )          
   ,.i_cpu_rden             ({{RA_NUM_SECTOR}{w_cc_s_core_rden      [gcc]}}                                         )          
   ,.o_cpu_rdata            ({w_sect_s_rafe_rdata   [gcc][ID_SECTOR01],w_sect_s_rafe_rdata   [gcc][ID_SECTOR00]}    )
   ,.o_cpu_rd_valid         ({w_sect_s_rafe_rd_valid[gcc][ID_SECTOR01],w_sect_s_rafe_rd_valid[gcc][ID_SECTOR00]}    )
   ,.i_rin_frame_sync       ({{RA_NUM_SECTOR}{w_cc_uin_frame_sync   [gcc%UL_MAX_CC]}}                               )
   ,.i_rin_frame_idx        ( w_cc_uin_frame_idx    [gcc%UL_MAX_CC]                                                 )
   ,.i_rin_en               ( r_cc_uin_en           [gcc%UL_MAX_CC]                                                 )
   ,.i_rin_iq               ( r_cc_uin_iq           [gcc%UL_MAX_CC]                                                 )
   ,.i_rin_filter_idx       ( w_cc_rin_filter_idx   [gcc]                                                           )
   ,.i_rin_time_offset      ( w_cc_rin_time_offset  [gcc]                                                           )
   ,.i_rin_frame_struct     ( w_cc_rin_frame_struct [gcc]                                                           )
   ,.i_rin_cp_length        ( w_cc_rin_cp_length    [gcc]                                                           )
   ,.i_rin_num_psymbol      ( w_cc_rin_num_psymbol  [gcc]                                                           )
   ,.i_rin_freq_offset      ( w_cc_rin_freq_offset  [gcc]                                                           )
   ,.i_rin_num_ro           ( w_cc_rin_num_ro       [gcc]                                                           )
   ,.i_rin_num_prbc         ( w_cc_rin_num_prbc     [gcc]                                                           )
   ,.i_rin_start_prbc       ( w_cc_rin_start_prbc   [gcc]                                                           )
   ,.o_rout_frame_sync      ({w_sect_rout_frame_sync[gcc][ID_SECTOR01],w_sect_rout_frame_sync[gcc][ID_SECTOR00]}    )
   ,.o_rout_frame_idx       ({w_sect_rout_frame_idx [gcc][ID_SECTOR01],w_sect_rout_frame_idx [gcc][ID_SECTOR00]}    )
   ,.o_rout_subfrm_idx      ({w_sect_rout_subfrm_idx[gcc][ID_SECTOR01],w_sect_rout_subfrm_idx[gcc][ID_SECTOR00]}    )
   ,.o_rout_slot_idx        ({w_sect_rout_slot_idx  [gcc][ID_SECTOR01],w_sect_rout_slot_idx  [gcc][ID_SECTOR00]}    )
   ,.o_rout_symbol_idx      ({w_sect_rout_symbol_idx[gcc][ID_SECTOR01],w_sect_rout_symbol_idx[gcc][ID_SECTOR00]}    )
   ,.o_rout_en              ( w_cc_rout_en          [gcc]                                                           )
   ,.o_rout_iq              ( w_cc_rout_iq          [gcc]                                                           )
   ,.o_rout_start_re_idx    ( w_cc_rout_start_re_idx[gcc]                                                           )
   ,.o_rout_start_re        ( w_cc_rout_start_re    [gcc]                                                           )
   ,.o_rout_last_re         ( w_cc_rout_last_re     [gcc]                                                           )
);
assign w_cc_rout_frame_sync  [gcc] = |w_cc_rout_en[gcc][((RA_NUM_ANT/RA_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(RA_NUM_ANT/RA_NUM_SECTOR)] ? w_sect_rout_frame_sync[gcc][ID_SECTOR00] : w_sect_rout_frame_sync[gcc][ID_SECTOR01];
assign w_cc_rout_frame_idx   [gcc] = |w_cc_rout_en[gcc][((RA_NUM_ANT/RA_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(RA_NUM_ANT/RA_NUM_SECTOR)] ? w_sect_rout_frame_idx [gcc][ID_SECTOR00] : w_sect_rout_frame_idx [gcc][ID_SECTOR01];
assign w_cc_rout_subfrm_idx  [gcc] = |w_cc_rout_en[gcc][((RA_NUM_ANT/RA_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(RA_NUM_ANT/RA_NUM_SECTOR)] ? w_sect_rout_subfrm_idx[gcc][ID_SECTOR00] : w_sect_rout_subfrm_idx[gcc][ID_SECTOR01];
assign w_cc_rout_slot_idx    [gcc] = |w_cc_rout_en[gcc][((RA_NUM_ANT/RA_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(RA_NUM_ANT/RA_NUM_SECTOR)] ? w_sect_rout_slot_idx  [gcc][ID_SECTOR00] : w_sect_rout_slot_idx  [gcc][ID_SECTOR01];
assign w_cc_rout_symbol_idx  [gcc] = |w_cc_rout_en[gcc][((RA_NUM_ANT/RA_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(RA_NUM_ANT/RA_NUM_SECTOR)] ? w_sect_rout_symbol_idx[gcc][ID_SECTOR00] : w_sect_rout_symbol_idx[gcc][ID_SECTOR01];
assign w_cc_s_rafe_rd_valid  [gcc] = r_cc_s_rafe_rd_valid  [gcc] ;
assign w_cc_s_rafe_rdata     [gcc] = r_cc_s_rafe_rdata     [gcc] ;
always@(posedge i_core_clk) begin
    if(w_sect_s_rafe_rd_valid[gcc][ID_SECTOR00]) begin
        r_cc_s_rafe_rd_valid[gcc] <= w_sect_s_rafe_rd_valid[gcc][ID_SECTOR00] ;
        r_cc_s_rafe_rdata   [gcc] <= w_sect_s_rafe_rdata   [gcc][ID_SECTOR00] ;
    end
    else if(w_sect_s_rafe_rd_valid[gcc][ID_SECTOR01]) begin
        r_cc_s_rafe_rd_valid[gcc] <= w_sect_s_rafe_rd_valid[gcc][ID_SECTOR01] ;
        r_cc_s_rafe_rdata   [gcc] <= w_sect_s_rafe_rdata   [gcc][ID_SECTOR01] ;
    end
    else begin
        r_cc_s_rafe_rd_valid[gcc] <= 1'd0 ;
    end
end
end //RA_NUM_SECTOR==2
end
endgenerate
`endif //RAFE_CORE_DISABLE

`ifndef NBIOT_CORE_DISABLE
//u03_nbiot_wrapper
//generate for(gcc=0; gcc<NB_NUM_CC; gcc=gcc+1) begin : g03_nbiot_core_cc
//// cpuif
//assign w_cc_s_nw_core_addr  [ 1 * CPUIF_LPHY_ADDR_BW * gcc +:  1 * CPUIF_LPHY_ADDR_BW]  =  w_cc_s_core_addr  [gcc] ;
//assign w_cc_s_nw_core_wren  [ 1                      * gcc +:  1                     ]  =  w_cc_s_core_wren  [gcc] ;
//assign w_cc_s_nw_core_wdata [ 1 * CPUIF_DATA_BW      * gcc +:  1 * CPUIF_DATA_BW     ]  =  w_cc_s_core_wdata [gcc] ;
//assign w_cc_s_nw_core_rden  [ 1                      * gcc +:  1                     ]  =  w_cc_s_core_rden  [gcc] ;
//assign w_cc_s_nbiot_rdata    [gcc]  =  w_cc_s_nw_rdata    [ 1 * CPUIF_DATA_BW * gcc +:  1 * CPUIF_DATA_BW] ; 
//assign w_cc_s_nbiot_rd_valid [gcc]  =  w_cc_s_nw_rd_valid [ 1                 * gcc +:  1                ] ; 
  
//end
//endgenerate 

//nbiot_wrapper
//`ifndef NSIM                                                           
//#(   .NB_NUM_CC             ( NB_NUM_CC                     )           
//    ,.NUM_ANT               ( NB_NUM_ANT                    )           
//    ,.NUM_CHAIN             ( 1                             )          
//    ,.MAX_OBW               (`MAX_OBW                       )          
//    ,.TOP_DIO_BW            ( TOP_DIO_BW                    )          
//    ,.DLY_REG_RD            ( DLY_REG_RD-3                  )          
//    ,.ADDR_OFFSET           ( NBIOT_ADDR_OFFSET             )          
//    ,.VENDOR                ( VENDOR                        ))         
//`endif //NSIM                                                          
//u03_nbiot_wrapper
//(
//    .i_rst                  (|w_core_rst_rafe               )
//   ,.i_clk                  ( i_core_clk                    )
//   ,.i_cpu_addr             ( w_cc_s_nw_core_addr           )
//   ,.i_cpu_wren             ( w_cc_s_nw_core_wren           )
//   ,.i_cpu_wdata            ( w_cc_s_nw_core_wdata          )
//   ,.i_cpu_rden             ( w_cc_s_nw_core_rden           )
//   ,.o_cpu_rdata            ( w_cc_s_nw_rdata               )
//   ,.o_cpu_rd_valid         ( w_cc_s_nw_rd_valid            )
//   ,.i_nin_filter_idx       ( w_cc_nin_filter_idx           )
//   ,.i_nin_time_offset      ( w_cc_nin_time_offset          )
//   ,.i_nin_frame_struct     ( w_cc_nin_frame_struct         )
//   ,.i_nin_cp_length        ( w_cc_nin_cp_length            )
//   ,.i_nin_num_psymbol      ( w_cc_nin_num_psymbol          )
//   ,.i_nin_freq_offset      ( w_cc_nin_freq_offset          )
//   ,.i_nin_num_prbc         ( w_cc_nin_num_prbc             )
//   ,.i_nin_num_ro           ( w_cc_nin_num_ro               )
//   ,.i_nin_start_prbc       ( w_cc_nin_start_prbc           )
//   ,.i_nin_frame_sync       ( w_cc_nin_frame_sync           )
//   ,.i_nin_frame_idx        ( w_cc_nin_frame_idx            )
//   ,.i_nin_en               ( w_cc_nin_en                   )
//   ,.i_nin_iq               ( w_cc_nin_iq                   )
//   ,.o_nout_nco_valid       ( w_cc_nout_nco_valid           )
//   ,.o_nout_frame_struct    ( w_cc_nout_frame_struct        )
//   ,.o_nout_freq_offset     ( w_cc_nout_freq_offset         )
//   ,.o_nout_frame_sync      ( w_cc_nout_frame_sync          )
//   ,.o_nout_frame_idx       ( w_cc_nout_frame_idx           )
//   ,.o_nout_subfrm_idx      ( w_cc_nout_subfrm_idx          )
//   ,.o_nout_slot_idx        ( w_cc_nout_slot_idx            )
//   ,.o_nout_symbol_idx      ( w_cc_nout_symbol_idx          )
//   ,.o_nout_en              ( w_cc_nout_en                  )
//   ,.o_nout_iq              ( w_cc_nout_iq                  )
//   ,.o_nout_start_re_idx    ( w_cc_nout_start_re_idx        )
//   ,.o_nout_start_re        ( w_cc_nout_start_re            )
//   ,.o_nout_last_re         ( w_cc_nout_last_re             )
//   ,.o_nout_nb_bw_idx       ( w_cc_nout_nb_bw_idx           )
//);
`endif //NBIOT_CORE_DISABLE

`ifndef EMTC_CORE_DISABLE
////u04_emtc_core_cc
//generate for(gcc=0; gcc<MT_NUM_CC; gcc=gcc+1) begin : g04_emtc_core_cc
//if(MT_NUM_SECTOR==1) begin : g04_0_emtc_core_cc
//rafe_cc 
//`ifndef NSIM
//#(   .NUM_CC                ( 1                             )          
//    ,.NUM_ANT               ( MT_NUM_ANT                    )          
//    ,.NUM_CHAIN             ( 1                             )
//    ,.MAX_OBW               (`MAX_OBW                       )
//    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
//    ,.DLY_REG_RD            ( DLY_REG_RD-3                  )
//    ,.ADDR_OFFSET           ( EMTC_ADDR_OFFSET              )
//    ,.VENDOR                ( VENDOR                        ))
//`endif //NSIM
//u04_emtc_core_cc
//(                                                               
//    .i_clk                  ( i_core_clk                    )          
//   ,.i_rst                  ( w_core_rst_rafe       [gcc]   )          
//   ,.i_cpu_addr             ( w_cc_s_core_addr      [gcc]   )          
//   ,.i_cpu_wren             ( w_cc_s_core_wren      [gcc]   )          
//   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [gcc]   )          
//   ,.i_cpu_rden             ( w_cc_s_core_rden      [gcc]   )          
//   ,.o_cpu_rdata            ( w_cc_s_emtc_rdata     [gcc]   )          
//   ,.o_cpu_rd_valid         ( w_cc_s_emtc_rd_valid  [gcc]   )          
//   ,.i_rin_frame_sync       ( w_cc_min_frame_sync   [gcc]   )
//   ,.i_rin_frame_idx        ( w_cc_min_frame_idx    [gcc]   )
//   ,.i_rin_en               ( r_cc_min_en           [gcc]   )
//   ,.i_rin_iq               ( r_cc_min_iq           [gcc]   )
//   ,.i_rin_filter_idx       ( w_cc_min_filter_idx   [gcc]   )          
//   ,.i_rin_time_offset      ( w_cc_min_time_offset  [gcc]   )          
//   ,.i_rin_frame_struct     ( w_cc_min_frame_struct [gcc]   )          
//   ,.i_rin_cp_length        ( w_cc_min_cp_length    [gcc]   )          
//   ,.i_rin_num_psymbol      ( w_cc_min_num_psymbol  [gcc]   )          
//   ,.i_rin_freq_offset      ( w_cc_min_freq_offset  [gcc]   )          
//   ,.i_rin_num_ro           ( w_cc_min_num_ro       [gcc]   )          
//   ,.i_rin_num_prbc         ( w_cc_min_num_prbc     [gcc]   )          
//   ,.i_rin_start_prbc       ( w_cc_min_start_prbc   [gcc]   )          
//   ,.o_rout_frame_sync      ( w_cc_mout_frame_sync  [gcc]   )          
//   ,.o_rout_frame_idx       ( w_cc_mout_frame_idx   [gcc]   )          
//   ,.o_rout_subfrm_idx      ( w_cc_mout_subfrm_idx  [gcc]   )          
//   ,.o_rout_slot_idx        ( w_cc_mout_slot_idx    [gcc]   )          
//   ,.o_rout_symbol_idx      ( w_cc_mout_symbol_idx  [gcc]   )          
//   ,.o_rout_en              ( w_cc_mout_en          [gcc]   )          
//   ,.o_rout_start_re_idx    ( w_cc_mout_start_re_idx[gcc]   )          
//   ,.o_rout_start_re        ( w_cc_mout_start_re    [gcc]   )          
//   ,.o_rout_last_re         ( w_cc_mout_last_re     [gcc]   )          
//   ,.o_rout_iq              ( w_cc_mout_iq          [gcc]   )          
//);
//end //MT_NUM_SECTOR==1
//else if(MT_NUM_SECTOR==2) begin : g04_1_emtc_core_2sect_cc
//rafe_cc 
//`ifndef NSIM
//#(   .NUM_CC                ( MT_NUM_SECTOR                 )          
//    ,.NUM_ANT               ( MT_NUM_ANT/MT_NUM_SECTOR      )          
//    ,.NUM_CHAIN             ( 1                             )
//    ,.MAX_OBW               (`MAX_OBW                       )
//    ,.TOP_DIO_BW            ( TOP_DIO_BW                    ) 
//    ,.DLY_REG_RD            ( DLY_REG_RD-3                  )
//    ,.ADDR_OFFSET           ( EMTC_ADDR_OFFSET              )
//    ,.VENDOR                ( VENDOR                        ))
//`endif //NSIM
//u02_rafe_core_cc
//(                                                               
//    .i_clk                  ( i_core_clk                                                                            )
//   ,.i_rst                  ( w_core_rst_rafe       [gcc]                                                           )
//   ,.i_cpu_addr             ({{MT_NUM_SECTOR}{w_cc_s_core_addr      [gcc]}}                                         )
//   ,.i_cpu_wren             ({{MT_NUM_SECTOR}{w_cc_s_core_wren      [gcc]}}                                         )
//   ,.i_cpu_wdata            ({{MT_NUM_SECTOR}{w_cc_s_core_wdata     [gcc]}}                                         )
//   ,.i_cpu_rden             ({{MT_NUM_SECTOR}{w_cc_s_core_rden      [gcc]}}                                         )
//   ,.o_cpu_rdata            ({w_sect_s_emtc_rdata   [gcc][ID_SECTOR01],w_sect_s_emtc_rdata   [gcc][ID_SECTOR00]}    )
//   ,.o_cpu_rd_valid         ({w_sect_s_emtc_rd_valid[gcc][ID_SECTOR01],w_sect_s_emtc_rd_valid[gcc][ID_SECTOR00]}    )
//   ,.i_rin_frame_sync       ({{MT_NUM_SECTOR}{w_cc_min_frame_sync   [gcc]}}                                         )
//   ,.i_rin_frame_idx        ( w_cc_min_frame_idx    [gcc]                                                           )
//   ,.i_rin_en               ( r_cc_min_en           [gcc]                                                           )
//   ,.i_rin_iq               ( r_cc_min_iq           [gcc]                                                           )
//   ,.i_rin_filter_idx       ( w_cc_min_filter_idx   [gcc]                                                           )
//   ,.i_rin_time_offset      ( w_cc_min_time_offset  [gcc]                                                           )
//   ,.i_rin_frame_struct     ( w_cc_min_frame_struct [gcc]                                                           )
//   ,.i_rin_cp_length        ( w_cc_min_cp_length    [gcc]                                                           )
//   ,.i_rin_num_psymbol      ( w_cc_min_num_psymbol  [gcc]                                                           )
//   ,.i_rin_freq_offset      ( w_cc_min_freq_offset  [gcc]                                                           )
//   ,.i_rin_num_ro           ( w_cc_min_num_ro       [gcc]                                                           )
//   ,.i_rin_num_prbc         ( w_cc_min_num_prbc     [gcc]                                                           )
//   ,.i_rin_start_prbc       ( w_cc_min_start_prbc   [gcc]                                                           )
//   ,.o_rout_frame_sync      ({w_sect_mout_frame_sync[gcc][ID_SECTOR01],w_sect_mout_frame_sync[gcc][ID_SECTOR00]}    )
//   ,.o_rout_frame_idx       ({w_sect_mout_frame_idx [gcc][ID_SECTOR01],w_sect_mout_frame_idx [gcc][ID_SECTOR00]}    )
//   ,.o_rout_subfrm_idx      ({w_sect_mout_subfrm_idx[gcc][ID_SECTOR01],w_sect_mout_subfrm_idx[gcc][ID_SECTOR00]}    )
//   ,.o_rout_slot_idx        ({w_sect_mout_slot_idx  [gcc][ID_SECTOR01],w_sect_mout_slot_idx  [gcc][ID_SECTOR00]}    )
//   ,.o_rout_symbol_idx      ({w_sect_mout_symbol_idx[gcc][ID_SECTOR01],w_sect_mout_symbol_idx[gcc][ID_SECTOR00]}    )
//   ,.o_rout_en              ( w_cc_mout_en          [gcc]                                                           )
//   ,.o_rout_start_re_idx    ( w_cc_mout_start_re_idx[gcc]                                                           )
//   ,.o_rout_start_re        ( w_cc_mout_start_re    [gcc]                                                           )
//   ,.o_rout_last_re         ( w_cc_mout_last_re     [gcc]                                                           )
//   ,.o_rout_iq              ( w_cc_mout_iq          [gcc]                                                           )
//);
//assign w_cc_mout_frame_sync  [gcc] = |w_cc_mout_en[gcc][((MT_NUM_ANT/MT_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(MT_NUM_ANT/MT_NUM_SECTOR)] ? w_sect_mout_frame_sync[gcc][ID_SECTOR00] : w_sect_mout_frame_sync[gcc][ID_SECTOR01];
//assign w_cc_mout_frame_idx   [gcc] = |w_cc_mout_en[gcc][((MT_NUM_ANT/MT_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(MT_NUM_ANT/MT_NUM_SECTOR)] ? w_sect_mout_frame_idx [gcc][ID_SECTOR00] : w_sect_mout_frame_idx [gcc][ID_SECTOR01];
//assign w_cc_mout_subfrm_idx  [gcc] = |w_cc_mout_en[gcc][((MT_NUM_ANT/MT_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(MT_NUM_ANT/MT_NUM_SECTOR)] ? w_sect_mout_subfrm_idx[gcc][ID_SECTOR00] : w_sect_mout_subfrm_idx[gcc][ID_SECTOR01];
//assign w_cc_mout_slot_idx    [gcc] = |w_cc_mout_en[gcc][((MT_NUM_ANT/MT_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(MT_NUM_ANT/MT_NUM_SECTOR)] ? w_sect_mout_slot_idx  [gcc][ID_SECTOR00] : w_sect_mout_slot_idx  [gcc][ID_SECTOR01];
//assign w_cc_mout_symbol_idx  [gcc] = |w_cc_mout_en[gcc][((MT_NUM_ANT/MT_NUM_SECTOR)*(ID_SECTOR00+1)-1)-:(MT_NUM_ANT/MT_NUM_SECTOR)] ? w_sect_mout_symbol_idx[gcc][ID_SECTOR00] : w_sect_mout_symbol_idx[gcc][ID_SECTOR01];
//assign w_cc_s_emtc_rd_valid  [gcc] = r_cc_s_emtc_rd_valid  [gcc] ;
//assign w_cc_s_emtc_rdata     [gcc] = r_cc_s_emtc_rdata     [gcc] ;
//always@(posedge i_core_clk) begin
//    if(w_sect_s_emtc_rd_valid[gcc][ID_SECTOR00]) begin
//        r_cc_s_emtc_rd_valid[gcc] <= w_sect_s_emtc_rd_valid[gcc][ID_SECTOR00] ;
//        r_cc_s_emtc_rdata   [gcc] <= w_sect_s_emtc_rdata   [gcc][ID_SECTOR00] ;
//    end
//    else if(w_sect_s_emtc_rd_valid[gcc][ID_SECTOR01]) begin
//        r_cc_s_emtc_rd_valid[gcc] <= w_sect_s_emtc_rd_valid[gcc][ID_SECTOR01] ;
//        r_cc_s_emtc_rdata   [gcc] <= w_sect_s_emtc_rdata   [gcc][ID_SECTOR01] ;
//    end
//    else begin
//        r_cc_s_emtc_rd_valid[gcc] <= 1'd0 ;
//    end
//end
//end //MT_NUM_SECTOR==2
//end
//endgenerate
`endif //EMTC_CORE_DISABLE

//u05_ul_sync
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g04_0_ul_sync
ylib_pshift #(
     .BW_SHIFT  (   $clog2(CORE_CLK_FRAME)  ))
u05_0_ul_sync
(
    .i_clk        ( i_core_clk                                  )          
   ,.i_shift      ( w_cc_ul_retard[((22)*(gcc+1)-1)-:(22)]      )
`ifndef SBIF_ENABLE
   ,.i_in         ( i_uin_frame_sync        [gcc]               )
`else //SBIF_ENABLE
   ,.i_in         ( w_cc_usbif_a_frame_sync [gcc]               )
`endif //SBIF_ENABLE
   ,.o_out        ( w_cc_uin_frame_sync     [gcc]               )
);
assign  w_cc_uin_frame_idx [gcc] = w_cc_din_frame_idx [CC_REF]  ;
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gcc=0; gcc< 2; gcc=gcc+1) begin : g04_1_nb_sync
ylib_pshift #(
     .BW_SHIFT  (   $clog2(CORE_CLK_FRAME)  ))
u05_1_nb_sync
(
    .i_clk        ( i_core_clk                                  )          
   ,.i_shift      ( w_cc_nb_retard[((22)*(gcc+1)-1)-:(22)]      )
`ifndef SBIF_ENABLE
   ,.i_in         ( i_nin_frame_sync    [gcc]                   )
`else //SBIF_ENABLE
   ,.i_in         ( w_cc_nsbif_a_frame_sync [gcc]               )
`endif //SBIF_ENABLE
   ,.o_out        ( w_cc_nin_frame_sync [gcc]                   )
);
assign  w_cc_nin_frame_idx [8 * gcc +: 8] = w_cc_din_frame_idx [CC_REF]  ;
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g04_2_mt_sync
ylib_pshift #(
     .BW_SHIFT  (   $clog2(CORE_CLK_FRAME)  ))
u05_2_mt_sync
(
    .i_clk        ( i_core_clk                                  )          
   ,.i_shift      ( w_cc_mt_retard[((22)*(gcc+1)-1)-:(22)]      )
`ifndef SBIF_ENABLE
   ,.i_in         ( i_min_frame_sync    [gcc]                   )
`else //SBIF_ENABLE
   ,.i_in         ( w_cc_usbif_a_frame_sync [gcc]               )
`endif //SBIF_ENABLE
   ,.o_out        ( w_cc_min_frame_sync [gcc]                   )
);
assign  w_cc_min_frame_idx [gcc] = w_cc_din_frame_idx [CC_REF]  ;
end
endgenerate
`endif //NBIOT_CORE_DISABLE

//u06_lphy_top_cpu_if(cpu/oran)
lphy_top_cpu_if #(
     .NUM_CC                ( MAX_CC                )
    ,.NUM_PATH              ( MAX_ANT               )
    ,.CPUIF_ADDR_BW         ( CPUIF_ADDR_BW         )
    ,.CPUIF_LPHY_ADDR_BW    ( CPUIF_LPHY_ADDR_BW    )
    ,.CPUIF_DATA_BW         ( CPUIF_DATA_BW         )
    ,.NUM_DUMP_ITEM         ( NUM_DUMP_ITEM         )
    ,.DUMP_MEM_ADDR_BW      ( DUMP_MEM_ADDR_BW      )
    ,.DLY_REG_RD            ( DLY_REG_RD-1          )
    ,.P4V_VERSION           (`P4V_VERSION           )
    ,.VENDOR                ( VENDOR                ))
u06_lphy_top_cpu_if
(                                                               
    .i_rst                  ( w_core_rst_lphy_top[0]        )          
   ,.i_clk                  ( i_core_clk                    )          
   ,.i_cpu_clk              ( i_cpu_clk                     )          
   ,.i_cpu_rst              ( w_cpu_rst                     )          
   ,.i_cpu_cs               ( i_cpu_cs                      )          
   ,.i_cpu_addr             ( i_cpu_addr                    )          
   ,.i_cpu_wren             ( i_cpu_wren                    )          
   ,.i_cpu_wdata            ( i_cpu_wdata                   )          
   ,.i_cpu_rden             ( i_cpu_rden                    )          
   ,.o_cpu_rdata            ( o_cpu_rdata                   )          
   ,.o_cpu_rd_valid         ( o_cpu_rd_valid                )          
   ,.o_core_addr            ( w_core_addr                   )          
   ,.o_core_wren            ( w_core_wren                   )          
   ,.o_core_wdata           ( w_core_wdata                  )          
   ,.o_core_rden            ( w_core_rden                   )          
   ,.i_core_rdata           ( w_core_rdata                  )          
   ,.i_core_rd_valid        ( w_core_rd_valid               )          
   ,.o_lphy_top_par_100008  ( w_lphy_top_par_100008         )          
   ,.o_sigcap_par_180000    ( w_sigcap_par_180000           )          
   ,.o_sigcap_par_180004    ( w_sigcap_par_180004           )          
   ,.o_sigcap_par_180008    ( w_sigcap_par_180008           )          
   ,.o_sigcap_par_18000c    ( w_sigcap_par_18000c           )          
   ,.o_sigcap_par_180010    ( w_sigcap_par_180010           )          
   ,.o_sigcap_par_180014    ( w_sigcap_par_180014           )          
   ,.o_sigcap_par_180018    ( w_sigcap_par_180018           )          
   ,.o_sigcap_par_18001c    ( w_sigcap_par_18001c           )          
   ,.o_sigcap_par_180020    ( w_sigcap_par_180020           )          
   ,.o_sigcap_par_180024    ( w_sigcap_par_180024           )          
   ,.o_sigcap_par_180028    ( w_sigcap_par_180028           )          
   ,.o_sigcap_par_18002c    ( w_sigcap_par_18002c           )          
   ,.i_cc_dl_proc_dly       ( w_cc_dl_proc_dly              )
   ,.i_cc_ul_proc_dly       ( w_cc_ul_proc_dly              )
   ,.i_cc_ra_proc_dly       ( w_cc_ra_proc_dly              )
   ,.i_cc_nb_proc_dly       ( w_cc_nb_proc_dly              )
   ,.i_cc_mt_proc_dly       ( w_cc_mt_proc_dly              )
   ,.i_din_fsync            ( w_cc_dl_fsync                 )
   ,.i_uin_fsync            ( w_cc_ul_fsync                 )
   ,.i_nin_fsync            ( w_cc_nb_fsync                 )
   ,.i_min_fsync            ( w_cc_mt_fsync                 )
   ,.o_cc_ul_retard         ( w_cc_ul_retard                )
   ,.o_cc_nb_retard         ( w_cc_nb_retard                )
   ,.o_cc_mt_retard         ( w_cc_mt_retard                )
   ,.i_dump_wr_en           ( w_dump_wr_en                  )          
   ,.i_dump_wr_addr         ( w_dump_wr_addr                )          
   ,.i_dump_wr_data         ( w_dump_wr_data                )          
);
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g05_core_reg_mux
always@(posedge i_core_clk) begin
    if(w_cc_s_dlfe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_dlfe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_dlfe_rd_valid[gcc] ;
    end
    else if(w_cc_s_ulfe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_ulfe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_ulfe_rd_valid[gcc] ;
    end
    else if(w_cc_s_rafe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_rafe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_rafe_rd_valid[gcc] ;
    end
`ifndef NBIOT_CORE_DISABLE
    else if(w_cc_s_nbiot_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_nbiot_rdata[gcc]   ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_nbiot_rd_valid[gcc];
    end
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
    else if(w_cc_s_emtc_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_emtc_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_emtc_rd_valid[gcc] ;
    end
`endif //EMTC_CORE_DISABLE
    else begin
        r_cc_s_core_rd_valid[gcc]  <=  1'd0    ;
    end
end
end
endgenerate

//u07_proc_dly
`ifndef SBIF_ENABLE
generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g06_0_dl_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_0_dproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_din_frame_sync[gcc]),.i_sync1(w_cc_dout_frame_sync[gcc]),.o_diff(w_cc_dl_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_dl_fsync[gcc] = w_cc_din_frame_sync[gcc] ;
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g06_1_ul_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_1_uproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_uin_frame_sync[gcc]),.i_sync1(w_cc_uout_frame_sync[gcc]),.o_diff(w_cc_ul_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_ul_fsync[gcc] = w_cc_uin_frame_sync[gcc] ;
end
endgenerate
generate for(gcc=0; gcc<RA_MAX_CC; gcc=gcc+1) begin : g06_2_ra_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_2_rproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_uin_frame_sync[gcc%UL_MAX_CC]),.i_sync1(w_cc_rout_frame_sync[gcc]),.o_diff(w_cc_ra_proc_dly[((22)*(gcc+1)-1)-:(22)]));
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gcc=0; gcc<2; gcc=gcc+1) begin : g06_3_nb_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_3_nproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_nin_frame_sync[gcc]),.i_sync1(w_cc_nout_frame_sync[gcc]),.o_diff(w_cc_nb_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_nb_fsync[gcc] = w_cc_nin_frame_sync[gcc] ;
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g06_4_mt_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_4_mproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_min_frame_sync[gcc]),.i_sync1(w_cc_mout_frame_sync[gcc]),.o_diff(w_cc_mt_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_mt_fsync[gcc] = w_cc_min_frame_sync[gcc] ;
end
endgenerate
`endif //EMTC_CORE_DISABLE
`else //SBIF_ENABLE
generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g07_0_dl_sbif_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_0_dproc_dly(.i_clk(i_core_clk),.i_sync0(w_cc_din_frame_sync[gcc]),.i_sync1(w_dsbif_fsync[SBIF_REF]),.o_diff(w_cc_dl_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_dl_fsync[gcc] = w_cc_din_frame_sync[gcc] ;
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g07_1_ul_sbif_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_1_uproc_dly(.i_clk(i_core_clk),.i_sync0(r_usbif_in_fsync[SBIF_REF]),.i_sync1(w_cc_uout_frame_sync[gcc]),.o_diff(w_cc_ul_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_ul_fsync[gcc] = w_cc_uin_frame_sync[gcc] ;
end
endgenerate
generate for(gcc=0; gcc<RA_MAX_CC; gcc=gcc+1) begin : g07_2_ra_sbif_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_2_rproc_dly(.i_clk(i_core_clk),.i_sync0(r_usbif_in_fsync[SBIF_REF]),.i_sync1(w_cc_rout_frame_sync[gcc]),.o_diff(w_cc_ra_proc_dly[((22)*(gcc+1)-1)-:(22)]));
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gcc=0; gcc<NB_MAX_CC; gcc=gcc+1) begin : g07_3_nb_sbif_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_3_nproc_dly(.i_clk(i_core_clk),.i_sync0(r_nsbif_in_fsync[SBIF_REF]),.i_sync1(w_cc_nout_frame_sync[gcc]),.o_diff(w_cc_nb_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_nb_fsync[gcc] = w_cc_nin_frame_sync[gcc] ;
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g07_4_mt_sbif_proc_dly
ylib_mon_sync_diff  #(.WIDTH(22)) u07_4_mproc_dly(.i_clk(i_core_clk),.i_sync0(r_usbif_in_fsync[SBIF_REF]),.i_sync1(w_cc_mout_frame_sync[gcc]),.o_diff(w_cc_mt_proc_dly[((22)*(gcc+1)-1)-:(22)]));
assign w_cc_mt_fsync[gcc] = w_cc_min_frame_sync[gcc] ;
end
endgenerate
`endif //EMTC_CORE_DISABLE
`endif //SBIF_ENABLE

//u08_cpu_rst_sync
ylib_rst_sync #(
     .DELAY         (   DLY_RST         ))
u08_0_cpu_rst_sync
(
     .i_clk                 ( i_cpu_clk                     )
    ,.i_in                  ( i_cpu_arst                    )
    ,.o_out                 ( w_cpu_rst                     )
);

//u08_lphy_rst_sync
generate for(gcc=0;gcc<DL_MAX_CC;gcc=gcc+1) begin : g08_0_rst_sync
ylib_rst_sync #(
    .DELAY          (   DL_MAX_CC       ))
u09_1_top_rst_sync
(
    .i_clk                  ( i_core_clk                    )
   ,.i_in                   ( i_core_arst_lphy_top [gcc]    )
   ,.o_out                  ( w_core_rst_lphy_top  [gcc]    )
);
ylib_rst_sync #(
    .DELAY          (   DL_MAX_CC       ))
u09_2_dlfe_rst_sync
(
    .i_clk                  ( i_core_clk                    )
   ,.i_in                   ( i_core_arst_dlfe      [gcc]   )
   ,.o_out                  ( w_core_rst_dlfe       [gcc]   )
);
end
endgenerate
generate for(gcc=0;gcc<UL_MAX_CC;gcc=gcc+1) begin : g08_1_rst_sync
ylib_rst_sync #(
    .DELAY          (   UL_MAX_CC       ))
u09_3_ulfe_rst_sync
(
    .i_clk                  ( i_core_clk                    )
   ,.i_in                   ( i_core_arst_ulfe     [gcc]    )
   ,.o_out                  ( w_core_rst_ulfe      [gcc]    )
);
end
endgenerate
generate for(gcc=0;gcc<RA_MAX_CC;gcc=gcc+1) begin : g08_2_rst_sync
ylib_rst_sync #(
    .DELAY          (   RA_MAX_CC       ))
u09_4_rafe_rst_sync
(
    .i_clk                  ( i_core_clk                    )
   ,.i_in                   ( i_core_arst_rafe      [gcc]   )
   ,.o_out                  ( w_core_rst_rafe       [gcc]   )
);
end
endgenerate

//u09_sig_cap(signal, parameter capture hub)
ylib_sig_cap #(   
    .NUM_ITEM               ( NUM_DUMP_ITEM         )
   ,.NUM_CC                 ( MAX_CC                )
   ,.NUM_PATH               ( MAX_ANT               )
   ,.BW_ADDR                ( DUMP_MEM_ADDR_BW      )
   ,.BW_DATA                ( 2*TOP_DIO_BW          ))
u09_sig_cap
(
    .i_clk                  ( i_core_clk                            )          
   ,.i_cap_en               ( r_sigcap_par_180000                   )
   ,.i_cap_cc_id            ( r_sigcap_par_180004                   )
   ,.i_cap_path_id          ( r_sigcap_par_180008                   )
   ,.i_cap_frame_id         ( r_sigcap_par_18000c                   )
   ,.i_cap_subfrm_id        ( r_sigcap_par_180010                   )
   ,.i_cap_slot_id          ( r_sigcap_par_180014                   )
   ,.i_cap_symbol_id        ( r_sigcap_par_180018                   )
   ,.i_cap_item_id          ( r_sigcap_par_18001c                   )
   ,.i_cap_mode             ( r_sigcap_par_180020                   )
   ,.i_cap_mu               ( r_sigcap_par_180024                   )
   ,.i_cap_sr               ( r_sigcap_par_180028                   )
   ,.i_cap_thres            ( r_sigcap_par_18002c                   )
   ,.i_sig_frame_id         ({{NUM_DUMP_ITEM}{r_sig_cap_bfn}}       )
   ,.i_sig_frame_sync       ( w_sig_cap_frame_sync                  )        
   ,.i_sig_data_en          ( w_sig_cap_en                          )
   ,.i_sig_data             ( w_sig_cap_iq                          )
   ,.o_cap_data_en          ( w_dump_wr_en                          )
   ,.o_cap_data_addr        ( w_dump_wr_addr                        )
   ,.o_cap_data             ( w_dump_wr_data                        )
);
always@(posedge i_core_clk) begin
    if(w_cc_din_frame_sync[0]) begin
        r_sigcap_par_180000 <=  w_sigcap_par_180000   ; 
        r_sigcap_par_180004 <=  w_sigcap_par_180004   ; 
        r_sigcap_par_180008 <=  w_sigcap_par_180008   ; 
        r_sigcap_par_18000c <=  w_sigcap_par_18000c   ; 
        r_sigcap_par_180010 <=  w_sigcap_par_180010   ; 
        r_sigcap_par_180014 <=  w_sigcap_par_180014   ;             
        r_sigcap_par_180018 <=  w_sigcap_par_180018   ; 
        r_sigcap_par_18001c <=  w_sigcap_par_18001c   ; 
        r_sigcap_par_180020 <=  w_sigcap_par_180020   ;             
        r_sigcap_par_180024 <=  w_sigcap_par_180024   ; 
        r_sigcap_par_180028 <=  w_sigcap_par_180028   ; 
        r_sigcap_par_18002c <=  w_sigcap_par_18002c   ;             
    end
end

//--- IO-Signal Mapping
generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g09_0_dl_io_map
//oran_top to dlfe : pdxch uplane
assign w_cc_din_bfn             [gcc]   =   {4'd0,i_din_frame_idx   [((08                     )*(gcc+1)-1)-:(08                     )]} ;   
assign w_cc_din_frame_sync      [gcc]   =   i_din_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )]  ;   
assign w_cc_din_frame_idx       [gcc]   =   i_din_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  ;   
assign w_cc_din_en              [gcc]   =   i_din_en                [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )]  ;   
assign w_cc_din_iq              [gcc]   =   i_din_iq                [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)]  ;   
assign w_cc_din_frame_struct    [gcc]   =   {{08*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_re_mask         [gcc]   =   i_din_re_mask           [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )]  ;   
//assign w_cc_din_sys_mode_dss    [gcc]   =   i_din_sys_mode_dss      [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )]  ;   
assign w_cc_din_beam_id         [gcc]   =   {{15*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_start_prbu      [gcc]   =   {{10*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_num_prbu        [gcc]   =   {{08*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_freq_offset     [gcc]   =   {{24*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_nlayer          [gcc]   =   5'd0                                                                                        ;
//dlfe to oran_top : k0
assign o_dout_dl_sys_mode       [((01                     )*(gcc+1)-1)-:(01                     )]  =   w_cc_dout_dl_sys_mode    [gcc]  ;
assign o_dout_dl_ntone          [((12                     )*(gcc+1)-1)-:(12                     )]  =   w_cc_dout_dl_ntone       [gcc]  ;
assign o_dout_dl_fft_type       [((02                     )*(gcc+1)-1)-:(02                     )]  =   w_cc_dout_dl_fft_type    [gcc]  ;
assign o_dout_dl_k0             [((12                     )*(gcc+1)-1)-:(12                     )]  =   w_cc_dout_dl_k0          [gcc]  ;
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g09_1_ul_io_map
//ulfe to oran_top : puxch uplane
assign o_uout_start_re_idx      [((16*UL_NUM_ANT          )*(gcc+1)-1)-:(16*UL_NUM_ANT          )]  =   w_cc_uout_start_re_idx   [gcc]  ;   
assign o_uout_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_en             [gcc]  ;   
assign o_uout_start_re          [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_start_re       [gcc]  ;   
assign o_uout_last_re           [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_last_re        [gcc]  ;   
assign o_uout_iq                [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)]  =   w_cc_uout_iq             [gcc]  ;   
//ulfe to oran_top : puxch cuplane 
//assign w_cc_uin_symbol_idx      [gcc]   =   i_uin_symbol_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  ;   
//assign w_cc_uin_en_technology   [gcc]   =   i_uin_en_technology     [((01                     )*(gcc+1)-1)-:(01                     )]  ;   
//assign w_cc_uin_technology_dss  [gcc]   =   i_uin_technology_dss    [((01                     )*(gcc+1)-1)-:(01                     )]  ;   
assign o_uout_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  =   w_cc_uout_frame_idx      [gcc]  ;   
assign o_uout_subfrm_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  =   w_cc_uout_subfrm_idx     [gcc]  ;   
assign o_uout_slot_idx          [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_uout_slot_idx       [gcc]  ;   
assign o_uout_symbol_idx        [((06                     )*(gcc+1)-1)-:(06                     )]  =  {2'd0,w_cc_uout_symbol_idx[gcc]} ;   
end
endgenerate
generate for(gcc=0; gcc<RA_MAX_CC; gcc=gcc+1) begin : g09_2_ra_io_map
//oran_top to rafe : rach cplane
assign w_cc_rin_frame_sync      [gcc]   =   1'd0  ;   
assign w_cc_rin_filter_idx      [gcc]   =   i_rin_filter_idx        [((04*RA_NUM_ANT          )*(gcc+1)-1)-:(04*RA_NUM_ANT          )]  ;   
assign w_cc_rin_time_offset     [gcc]   =   i_rin_time_offset       [((16*RA_NUM_ANT          )*(gcc+1)-1)-:(16*RA_NUM_ANT          )]  ;   
assign w_cc_rin_frame_struct    [gcc]   =   i_rin_frame_struct      [((08*RA_NUM_ANT          )*(gcc+1)-1)-:(08*RA_NUM_ANT          )]  ;   
assign w_cc_rin_cp_length       [gcc]   =   i_rin_cp_length         [((16*RA_NUM_ANT          )*(gcc+1)-1)-:(16*RA_NUM_ANT          )]  ;   
assign w_cc_rin_freq_offset     [gcc]   =   i_rin_freq_offset       [((24*RA_NUM_ANT          )*(gcc+1)-1)-:(24*RA_NUM_ANT          )]  ;   
assign w_cc_rin_num_psymbol     [gcc]   =   i_rin_num_psymbol       [((04*RA_NUM_ANT          )*(gcc+1)-1)-:(04*RA_NUM_ANT          )]  ;   
assign w_cc_rin_num_ro          [gcc]   =   i_rin_num_ro            [((03*RA_NUM_ANT          )*(gcc+1)-1)-:(03*RA_NUM_ANT          )]  ;   
assign w_cc_rin_num_prbc        [gcc]   =   i_rin_num_prbc          [((08*RA_NUM_ANT          )*(gcc+1)-1)-:(08*RA_NUM_ANT          )]  ;   
assign w_cc_rin_start_prbc      [gcc]   =   i_rin_start_prbc        [((10*RA_NUM_ANT          )*(gcc+1)-1)-:(10*RA_NUM_ANT          )]  ;   
//rafe to oran_top : rach uplane
assign o_rout_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  =   w_cc_rout_frame_idx      [gcc]  ;     
assign o_rout_subfrm_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  =   w_cc_rout_subfrm_idx     [gcc]  ;     
assign o_rout_slot_idx          [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_rout_slot_idx       [gcc]  ;     
assign o_rout_symbol_idx        [((06                     )*(gcc+1)-1)-:(06                     )]  =   {2'd0,w_cc_rout_symbol_idx[gcc]};     
assign o_rout_start_re_idx      [((16*RA_NUM_ANT          )*(gcc+1)-1)-:(16*RA_NUM_ANT          )]  =   w_cc_rout_start_re_idx   [gcc]  ;     
assign o_rout_en                [((01*RA_NUM_ANT          )*(gcc+1)-1)-:(01*RA_NUM_ANT          )]  =   w_cc_rout_en             [gcc]  ;     
assign o_rout_start_re          [((01*RA_NUM_ANT          )*(gcc+1)-1)-:(01*RA_NUM_ANT          )]  =   w_cc_rout_start_re       [gcc]  ;     
assign o_rout_last_re           [((01*RA_NUM_ANT          )*(gcc+1)-1)-:(01*RA_NUM_ANT          )]  =   w_cc_rout_last_re        [gcc]  ;     
assign o_rout_iq                [((2*TOP_DIO_BW*RA_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*RA_NUM_ANT)]  =   w_cc_rout_iq             [gcc]  ;      
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
//oran_top to nbiot : nprach cplane
assign w_cc_nin_filter_idx    =   i_nin_filter_idx       ;   
assign w_cc_nin_time_offset   =   i_nin_time_offset      ;   
assign w_cc_nin_frame_struct  =   i_nin_frame_struct     ;   
assign w_cc_nin_cp_length     =   i_nin_cp_length        ;   
assign w_cc_nin_num_psymbol   =   i_nin_num_psymbol      ;   
assign w_cc_nin_freq_offset   =   i_nin_freq_offset      ;   
assign w_cc_nin_num_prbc      =   i_nin_num_prbc         ; 
assign w_cc_nin_num_ro        =   i_nin_num_ro           ;   
assign w_cc_nin_start_prbc    =   i_nin_start_prbc       ; 
generate for(gcc=0; gcc<2; gcc=gcc+1) begin : g09_3_nb_io_map
assign w_cc_nin_en         [ 1              * NB_NUM_ANT * gcc +:  1              * NB_NUM_ANT ]  =  r_cc_nin_en         [gcc] ;
assign w_cc_nin_iq         [ 2 * TOP_DIO_BW * NB_NUM_ANT * gcc +:  2 * TOP_DIO_BW * NB_NUM_ANT ]  =  r_cc_nin_iq         [gcc] ;
end
endgenerate
//rafe to oran_top : nprach npusch uplane
assign o_nout_nco_valid       =   w_cc_nout_nco_valid    ;
assign o_nout_frame_struct    =   w_cc_nout_frame_struct ;
assign o_nout_freq_offset     =   w_cc_nout_freq_offset  ;
assign o_nout_frame_idx       =   w_cc_nout_frame_idx    ;     
assign o_nout_subfrm_idx      =   w_cc_nout_subfrm_idx   ;     
assign o_nout_slot_idx        =   w_cc_nout_slot_idx     ;     
assign o_nout_symbol_idx      =   w_cc_nout_symbol_idx   ;     
assign o_nout_start_re_idx    =   w_cc_nout_start_re_idx ;     
assign o_nout_en              =   w_cc_nout_en           ;     
assign o_nout_start_re        =   w_cc_nout_start_re     ;     
assign o_nout_last_re         =   w_cc_nout_last_re      ;     
assign o_nout_iq              =   w_cc_nout_iq           ; 
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g09_4_mt_io_map
//oran_top to emtc rafe : emtc prach cplane
assign w_cc_min_filter_idx      [gcc]   =   i_min_filter_idx        [((04*MT_NUM_ANT          )*(gcc+1)-1)-:(04*MT_NUM_ANT          )]  ;   
assign w_cc_min_time_offset     [gcc]   =   i_min_time_offset       [((16*MT_NUM_ANT          )*(gcc+1)-1)-:(16*MT_NUM_ANT          )]  ;   
assign w_cc_min_frame_struct    [gcc]   =   i_min_frame_struct      [((08*MT_NUM_ANT          )*(gcc+1)-1)-:(08*MT_NUM_ANT          )]  ;   
assign w_cc_min_cp_length       [gcc]   =   i_min_cp_length         [((16*MT_NUM_ANT          )*(gcc+1)-1)-:(16*MT_NUM_ANT          )]  ;   
assign w_cc_min_freq_offset     [gcc]   =   i_min_freq_offset       [((24*MT_NUM_ANT          )*(gcc+1)-1)-:(24*MT_NUM_ANT          )]  ;   
assign w_cc_min_num_psymbol     [gcc]   =   i_min_num_psymbol       [((04*MT_NUM_ANT          )*(gcc+1)-1)-:(04*MT_NUM_ANT          )]  ;   
assign w_cc_min_num_ro          [gcc]   =   i_min_num_ro            [((03*MT_NUM_ANT          )*(gcc+1)-1)-:(03*MT_NUM_ANT          )]  ;   
assign w_cc_min_num_prbc        [gcc]   =   i_min_num_prbc          [((08*MT_NUM_ANT          )*(gcc+1)-1)-:(08*MT_NUM_ANT          )]  ;   
assign w_cc_min_start_prbc      [gcc]   =   i_min_start_prbc        [((10*MT_NUM_ANT          )*(gcc+1)-1)-:(10*MT_NUM_ANT          )]  ;   
//emtc rafe to oran_top : emtc prach uplane
assign o_mout_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  =   w_cc_mout_frame_idx      [gcc]  ;     
assign o_mout_subfrm_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  =   w_cc_mout_subfrm_idx     [gcc]  ;     
assign o_mout_slot_idx          [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_mout_slot_idx       [gcc]  ;     
assign o_mout_symbol_idx        [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_mout_symbol_idx     [gcc]  ;     
assign o_mout_start_re_idx      [((16*MT_NUM_ANT          )*(gcc+1)-1)-:(16*MT_NUM_ANT          )]  =   w_cc_mout_start_re_idx   [gcc]  ;     
assign o_mout_en                [((01*MT_NUM_ANT          )*(gcc+1)-1)-:(01*MT_NUM_ANT          )]  =   w_cc_mout_en             [gcc]  ;     
assign o_mout_start_re          [((01*MT_NUM_ANT          )*(gcc+1)-1)-:(01*MT_NUM_ANT          )]  =   w_cc_mout_start_re       [gcc]  ;     
assign o_mout_last_re           [((01*MT_NUM_ANT          )*(gcc+1)-1)-:(01*MT_NUM_ANT          )]  =   w_cc_mout_last_re        [gcc]  ;     
assign o_mout_iq                [((2*TOP_DIO_BW*MT_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*MT_NUM_ANT)]  =   w_cc_mout_iq             [gcc]  ;      
end
endgenerate
`endif //EMTC_CORE_DISABLE
//--- CPU IF Mapping
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g10_cpu_if_map
assign w_cc_s_core_addr         [gcc]   =   w_core_addr             [((CPUIF_LPHY_ADDR_BW     )*(gcc+1)-1)-:(CPUIF_LPHY_ADDR_BW     )]  ;   
assign w_cc_s_core_wren         [gcc]   =   w_core_wren             [((1                      )*(gcc+1)-1)-:(1                      )]  ;   
assign w_cc_s_core_wdata        [gcc]   =   w_core_wdata            [((CPUIF_DATA_BW          )*(gcc+1)-1)-:(CPUIF_DATA_BW          )]  ;   
assign w_cc_s_core_rden         [gcc]   =   w_core_rden             [((1                      )*(gcc+1)-1)-:(1                      )]  ;   
assign w_core_rdata             [((CPUIF_DATA_BW          )*(gcc+1)-1)-:(CPUIF_DATA_BW          )]  =   r_cc_s_core_rdata        [gcc]  ;   
assign w_core_rd_valid          [((1                      )*(gcc+1)-1)-:(1                      )]  =   r_cc_s_core_rd_valid     [gcc]  ;   
end
endgenerate

`ifndef SBIF_ENABLE
//--- From/To BBCTRL : TD DL UL
generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g11_0_dl_if_sig_map
always@(posedge i_core_clk) begin
    o_dout_frame_sync [((01           )*(gcc+1)-1)-:(01           )] <= w_cc_dout_frame_sync[gcc]   ;
    o_dout_en         [((01*DL_NUM_ANT)*(gcc+1)-1)-:(01*DL_NUM_ANT)] <= w_cc_dout_en        [gcc]   ;
    for(ant=0;ant<DL_NUM_ANT;ant=ant+1) begin
        if(w_cc_dout_en[gcc][ant]) begin
            o_dout_i    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= w_cc_dout_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              ;
            o_dout_q    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= w_cc_dout_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   ;
        end
        else if(~w_cc_dout_en[gcc][ant]&o_dout_en[(((01)*(gcc*DL_NUM_ANT+ant+1)-1))-:(01)]) begin
            o_dout_i    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= {{TOP_DIO_BW}{1'b0}} ;
            o_dout_q    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= {{TOP_DIO_BW}{1'b0}} ;
        end
    end
end
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g11_1_ul_if_sig_map
always@(posedge i_core_clk) begin
    r_cc_uin_frame_sync [gcc] <= w_cc_uin_frame_sync    [gcc] ;
    r_cc_uin_en         [gcc] <= i_uin_en               [((01*UL_NUM_ANT)*(gcc+1)-1)-:(01*UL_NUM_ANT)]  ;
    for(ant=0;ant<UL_NUM_ANT;ant=ant+1) begin
        if(i_uin_en[(((01)*(gcc*UL_NUM_ANT+ant+1)-1))-:(01)]) begin
            r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= i_uin_i [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
            r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= i_uin_q [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
        end
        else if(~i_uin_en[(((01)*(gcc*UL_NUM_ANT+ant+1)-1))-:(01)]&r_cc_uin_en[gcc][ant]) begin
            r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= {{TOP_DIO_BW}{1'b0}} ;
            r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= {{TOP_DIO_BW}{1'b0}} ;
        end
    end
end
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gcc=0; gcc<2; gcc=gcc+1) begin : g11_2_nb_if_sig_map
always@(posedge i_core_clk) begin
    r_cc_nin_frame_sync [gcc] <= w_cc_nin_frame_sync    [gcc] ;
    r_cc_nin_en         [gcc] <= i_nin_en               [((01*NB_NUM_ANT)*(gcc+1)-1)-:(01*NB_NUM_ANT)]  ;
    for(ant=0;ant<UL_NUM_ANT;ant=ant+1) begin
        if(i_nin_en[(((01)*(gcc*UL_NUM_ANT+ant+1)-1))-:(01)]) begin
            r_cc_nin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= i_nin_i [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
            r_cc_nin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= i_nin_q [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
        end
        else if(~i_nin_en[(((01)*(gcc*NB_NUM_ANT+ant+1)-1))-:(01)]&r_cc_nin_en[gcc][ant]) begin
            r_cc_nin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= {{TOP_DIO_BW}{1'b0}} ;
            r_cc_nin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= {{TOP_DIO_BW}{1'b0}} ;
        end
    end
end
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g11_3_mt_if_sig_map
always@(posedge i_core_clk) begin
    r_cc_min_frame_sync [gcc] <= w_cc_min_frame_sync    [gcc] ;
    r_cc_min_en         [gcc] <= i_min_en               [((01*MT_NUM_ANT)*(gcc+1)-1)-:(01*MT_NUM_ANT)]  ;
    for(ant=0;ant<MT_NUM_ANT;ant=ant+1) begin
        if(i_min_en[(((01)*(gcc*MT_NUM_ANT+ant+1)-1))-:(01)]) begin
            r_cc_min_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= i_min_i [(((TOP_DIO_BW)*(gcc*MT_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
            r_cc_min_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= i_min_q [(((TOP_DIO_BW)*(gcc*MT_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
        end
        else if(~i_min_en[(((01)*(gcc*MT_NUM_ANT+ant+1)-1))-:(01)]&r_cc_min_en[gcc][ant]) begin
            r_cc_min_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= {{TOP_DIO_BW}{1'b0}} ;
            r_cc_min_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= {{TOP_DIO_BW}{1'b0}} ;
        end
    end
end
end
endgenerate
`endif //EMTC_CORE_DISABLE
`else //SBIF_ENABLE
generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g12_0_0_dl_sbif_sig_map
ylib_td_smp_mux #(   
     .NUM_ANT    (   DL_NUM_ANT          )
    ,.CC_IDX     (  `LPHY_PROJECT_NAME=="RF2221d" ? gcc : 0 )
    ,.DIO_BW     (   TOP_DIO_BW          ))
u10_0_0_dl_td_smp_mux
(
     .i_clk          ( i_core_clk                    )          
    ,.i_bw_idx       ( w_cc_dout_dl_bw_idx   [gcc]   )
    ,.i_bfn_strb     ( w_cc_dout_bfn_strb    [gcc]   )
    ,.i_bfn          ( w_cc_dout_bfn         [gcc]   )
    ,.i_fsync        ( w_cc_dout_frame_sync  [gcc]   )
    ,.i_en           ( w_cc_dout_en          [gcc]   )
    ,.i_iq           ( w_cc_dout_iq          [gcc]   )
    ,.o_bfn_strb     ( w_dsbif_out_bfn_strb  [gcc]   )
    ,.o_bfn          ( w_dsbif_out_bfn       [gcc]   )
    ,.o_en           ( w_dsbif_out_en        [gcc]   )
    ,.o_iq           ( w_dsbif_out_iq        [gcc]   )
);
end
endgenerate
generate for(gidx=0; gidx<DL_NUM_SBIF; gidx=gidx+1) begin : g12_0_1_dl_sbif_sig_out
if(`LPHY_PROJECT_NAME=="RF2221d") begin : g12_0_0_0_dl_cc2sbif_mux 
    if(DL_MAX_CC==1)      assign  w_dsbif_out_iq_mux[gidx] = w_dsbif_out_iq[0];
    else if(DL_MAX_CC==2) assign  w_dsbif_out_iq_mux[gidx] = w_dsbif_out_iq[0]|w_dsbif_out_iq[1];
    else if(DL_MAX_CC==3) assign  w_dsbif_out_iq_mux[gidx] = w_dsbif_out_iq[0]|w_dsbif_out_iq[1]|w_dsbif_out_iq[2];
    else if(DL_MAX_CC==4) assign  w_dsbif_out_iq_mux[gidx] = w_dsbif_out_iq[0]|w_dsbif_out_iq[1]|w_dsbif_out_iq[2]|w_dsbif_out_iq[3];
    else                  assign  w_dsbif_out_iq_mux[gidx] = {{TOP_DIO_BW*DL_NUM_SBIF}{1'b0}} ;
end //RF2221d
else if(`LPHY_PROJECT_NAME=="RF4448") begin
    assign  w_dsbif_out_iq_mux[gidx] = w_dsbif_out_iq[gidx];
end //RF4448
ylib_conv_15to16 #(   
     .DI_BW         (   TOP_DIO_BW          )
    ,.NUM_STREAM    (   2                   ))
u10_0_1_dl_td_15to16
(
     .i_clk          ( i_core_clk                                               )
    ,.i_bfn_strb     ( w_dsbif_out_bfn_strb  [CC_REF]                           )
    ,.i_bfn          ( w_dsbif_out_bfn       [CC_REF]                           )
    ,.i_en           (|w_dsbif_out_en                                           )
    ,.i_in           ( w_dsbif_out_iq_mux    [gidx]                             )
    ,.o_bfn_strb     ( o_dsbif_bfn_strb      [gidx]                             )
    ,.o_bfn          ( o_dsbif_bfn[((12)*(gidx+1)-1)-:(12)]                     )
    ,.o_fsync        ( w_dsbif_fsync         [gidx]                             )
    ,.o_csync        ( o_dsbif_csync         [gidx]                             )
    ,.o_en           ( w_dsbif_data_en       [gidx]                             )
    ,.o_out          ({o_dsbif_idata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]
                      ,o_dsbif_qdata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]}  )
);
end
endgenerate
generate for(gidx=0; gidx<UL_NUM_SBIF; gidx=gidx+1) begin : g12_1_0_ul_sbif_sig_in
assign  w_usbif_in_bfn_strb [gidx] = w_lphy_top_par_100008 ? o_dsbif_bfn_strb [gidx] : i_usbif_bfn_strb [gidx]  ;
assign  w_usbif_in_bfn      [gidx] = w_lphy_top_par_100008 ? o_dsbif_bfn      [((12)*(gidx+1)-1)-:(12)] : 12'd0 ;
assign  w_usbif_in_csync    [gidx] = w_lphy_top_par_100008 ? o_dsbif_csync    [gidx] : i_usbif_csync    [gidx]  ;
assign  w_usbif_in_en       [gidx] = w_lphy_top_par_100008 ? w_dsbif_data_en  [gidx] : 1'd1 ;
assign  w_usbif_in_iq_mux   [gidx] = w_lphy_top_par_100008 ? {o_dsbif_idata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)],o_dsbif_qdata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]} 
                                                            :{i_usbif_idata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)],i_usbif_qdata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]};
always@(posedge i_core_clk) r_usbif_in_bfn_strb [gidx] <= w_usbif_in_bfn_strb [gidx] ;
always@(*) r_usbif_in_fsync [gidx] <= w_usbif_in_bfn_strb [gidx] & ~r_usbif_in_bfn_strb [gidx] ;
ylib_conv_16to15 #(   
     .DO_BW         (   TOP_DIO_BW          )
    ,.NUM_STREAM    (   2                   ))
u10_1_0_ul_td_16to15
(
     .i_clk          ( i_core_clk                       )
    ,.i_bfn_strb     ( w_usbif_in_bfn_strb   [gidx]     )
    ,.i_bfn          ( w_usbif_in_bfn        [gidx]     )
    ,.i_csync        ( w_usbif_in_csync      [gidx]     )
    ,.i_en           ( w_usbif_in_en         [gidx]     )
    ,.i_in           ( w_usbif_in_iq_mux     [gidx]     )
    ,.o_bfn_strb     ( w_usbif_out_bfn_strb  [gidx]     )
    ,.o_bfn          ( w_usbif_out_bfn       [gidx]     )
    ,.o_fsync        ( w_usbif_out_fsync     [gidx]     )
    ,.o_en           ( w_usbif_out_en        [gidx]     )
    ,.o_out          ( w_usbif_out_iq_mux    [gidx]     )
);
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g12_1_1_ul_sbif_sig_demap
if(`LPHY_PROJECT_NAME=="RF2221d") begin : g12_1_1_0_ul_sbif2cc_demux    
ylib_td_smp_demux #(   
     .NUM_CC    (   UL_MAX_CC               )
    ,.NUM_ANT   (   UL_NUM_ANT              )
    ,.CC_IDX    (   gcc                     )
    ,.DIO_BW    (   TOP_DIO_BW              ))
u10_1_1_ul_td_smp_demux
(
     .i_clk          ( i_core_clk                       )
    ,.i_bw_idx       ( w_lphy_top_par_100008 ? 
                       w_cc_dout_dl_bw_idx[gcc] 
                      :w_cc_uout_ul_bw_idx[gcc]         )
    ,.i_bfn_strb     ( w_usbif_out_bfn_strb  [0]        )
    ,.i_bfn          ( w_usbif_out_bfn       [0]        )
    ,.i_fsync        ( w_usbif_out_fsync     [0]        )
    ,.i_en           ( w_usbif_out_en        [0]        )
    ,.i_iq           ( w_usbif_out_iq_mux    [0]        )
    ,.o_bfn_strb     ( w_cc_usbif_bfn_strb   [gcc]      )
    ,.o_bfn          ( w_cc_usbif_bfn        [gcc]      )
    ,.o_fsync        ( w_cc_usbif_frame_sync [gcc]      )
    ,.o_en           ( w_cc_usbif_en         [gcc]      )
    ,.o_iq           ( w_cc_usbif_iq         [gcc]      )
);
end //RF2221d
else if(`LPHY_PROJECT_NAME=="RF4448") begin
ylib_td_smp_demux #(   
     .NUM_CC    (   1                       )
    ,.NUM_ANT   (   UL_NUM_ANT              )
    ,.CC_IDX    (   0                       )
    ,.DIO_BW    (   TOP_DIO_BW              ))
u10_1_1_ul_td_smp_demux
(
     .i_clk          ( i_core_clk                       )
    ,.i_bw_idx       ( w_lphy_top_par_100008 ? 
                       w_cc_dout_dl_bw_idx[gcc] 
                      :w_cc_uout_ul_bw_idx[gcc]         )
    ,.i_bfn_strb     ( w_usbif_out_bfn_strb  [gcc]      )
    ,.i_bfn          ( w_usbif_out_bfn       [gcc]      )
    ,.i_fsync        ( w_usbif_out_fsync     [gcc]      )
    ,.i_en           ( w_usbif_out_en        [gcc]      )
    ,.i_iq           ( w_usbif_out_iq_mux    [gcc]      )
    ,.o_bfn_strb     ( w_cc_usbif_bfn_strb   [gcc]      )
    ,.o_bfn          ( w_cc_usbif_bfn        [gcc]      )
    ,.o_fsync        ( w_cc_usbif_frame_sync [gcc]      )
    ,.o_en           ( w_cc_usbif_en         [gcc]      )
    ,.o_iq           ( w_cc_usbif_iq         [gcc]      )
);
end //RF4448
ylib_cc_bw_align #(   
     .MAX_BW_IDX    (   MAX_BW_IDX              )
    ,.NUM_ANT       (   UL_NUM_ANT              )
    ,.DIO_BW        (   TOP_DIO_BW              ))
u10_1_2_ul_cc_bw_align
(
     .i_clk          ( i_core_clk                       )
    ,.i_bfn_strb     ( w_cc_usbif_bfn_strb      [CC_REF])
    ,.i_bfn          ( w_cc_usbif_bfn           [CC_REF])
    ,.i_fsync        ( w_cc_usbif_frame_sync    [CC_REF])
    ,.i_en           ( w_cc_usbif_en            [gcc]   )
    ,.i_iq           ( w_cc_usbif_iq            [gcc]   )
    ,.o_bfn_strb     ( w_cc_usbif_a_bfn_strb    [gcc]   )
    ,.o_bfn          ( w_cc_usbif_a_bfn         [gcc]   )
    ,.o_fsync        ( w_cc_usbif_a_frame_sync  [gcc]   )
    ,.o_en           ( w_cc_usbif_a_en          [gcc]   )
    ,.o_iq           ( w_cc_usbif_a_iq          [gcc]   )
);
always@(posedge i_core_clk) begin
    r_cc_uin_frame_sync [gcc] <= w_cc_usbif_a_frame_sync[gcc] ;
    r_cc_uin_en         [gcc] <= w_cc_usbif_a_en        [gcc] ;
    if(|w_cc_usbif_a_en[gcc]) begin
        r_cc_uin_iq     [gcc] <= w_cc_usbif_a_iq        [gcc] ;
    end
    else if((~|w_cc_usbif_a_en[gcc])&(|r_cc_uin_en[gcc])) begin
        r_cc_uin_iq     [gcc] <= {{2*TOP_DIO_BW}{1'b0}} ;
    end
end
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gidx=0; gidx<NB_NUM_SBIF; gidx=gidx+1) begin : g12_2_0_nb_sbif_sig_in
assign  w_nsbif_in_bfn_strb [gidx] = w_lphy_top_par_100008 ? o_dsbif_bfn_strb [gidx] : i_nsbif_bfn_strb [gidx]  ;
assign  w_nsbif_in_bfn      [gidx] = w_lphy_top_par_100008 ? o_dsbif_bfn      [((12)*(gidx+1)-1)-:(12)] : 12'd0 ;
assign  w_nsbif_in_csync    [gidx] = w_lphy_top_par_100008 ? o_dsbif_csync    [gidx] : i_nsbif_csync    [gidx]  ;
assign  w_nsbif_in_en       [gidx] = w_lphy_top_par_100008 ? w_dsbif_data_en  [gidx] : 1'd1  ;
assign  w_nsbif_in_iq_mux   [gidx] = w_lphy_top_par_100008 ? {o_dsbif_idata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)],o_dsbif_qdata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]} 
                                                            :{i_nsbif_idata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)],i_nsbif_qdata[((TOP_DIO_BW)*(gidx+1)-1)-:(TOP_DIO_BW)]};
always@(posedge i_core_clk) r_nsbif_in_bfn_strb [gidx] <= w_nsbif_in_bfn_strb [gidx] ;
always@(*) r_nsbif_in_fsync [gidx] <= w_nsbif_in_bfn_strb [gidx] & ~r_nsbif_in_bfn_strb [gidx] ;
ylib_conv_16to15 #(   
     .DO_BW         (   TOP_DIO_BW          )
    ,.NUM_STREAM    (   2                   ))
u10_2_0_nb_td_16to15
(
     .i_clk          ( i_core_clk                       )
    ,.i_bfn_strb     ( w_nsbif_in_bfn_strb   [gidx]     )
    ,.i_bfn          ( w_nsbif_in_bfn        [gidx]     )
    ,.i_csync        ( w_nsbif_in_csync      [gidx]     )
    ,.i_en           ( w_nsbif_in_en         [gidx]     )
    ,.i_in           ( w_nsbif_in_iq_mux     [gidx]     )
    ,.o_bfn_strb     ( w_nsbif_out_bfn_strb  [gidx]     )
    ,.o_bfn          ( w_nsbif_out_bfn       [gidx]     )
    ,.o_fsync        ( w_nsbif_out_fsync     [gidx]     )
    ,.o_en           ( w_nsbif_out_en        [gidx]     )
    ,.o_out          ( w_nsbif_out_iq_mux    [gidx]     )
);
end
endgenerate
generate for(gcc=0; gcc<NB_MAX_CC; gcc=gcc+1) begin : g12_2_1_nb_sbif_sig_demap
if(NB_NUM_SBIF==1) begin : g12_2_1_0_nb_sbif2cc_demux    
if(`LPHY_PROJECT_NAME=="RF2221d") begin : g12_2_1_1_nb_sbif2cc_demux
ylib_td_smp_demux #(   
     .NUM_CC    (   NB_MAX_CC                       )
    ,.NUM_ANT   (   NB_NUM_ANT                      )
    ,.CC_IDX    (   gcc/2                           )   
    ,.DIO_BW    (   TOP_DIO_BW                      ))
u10_2_1_nb_td_smp_demux
(
     .i_clk          ( i_core_clk                       )
    ,.i_bw_idx       ( w_lphy_top_par_100008 ? 
                       4'hd 
                      :w_cc_nout_nb_bw_idx[gcc]         )
    ,.i_bfn_strb     ( w_nsbif_out_bfn_strb  [0]        )
    ,.i_bfn          ( w_nsbif_out_bfn       [0]        )
    ,.i_fsync        ( w_nsbif_out_fsync     [0]        )
    ,.i_en           ( w_nsbif_out_en        [0]        )
    ,.i_iq           ( w_nsbif_out_iq_mux    [0]        )
    ,.o_bfn_strb     ( w_cc_nsbif_bfn_strb   [gcc]      )
    ,.o_bfn          ( w_cc_nsbif_bfn        [gcc]      )
    ,.o_fsync        ( w_cc_nsbif_frame_sync [gcc]      )
    ,.o_en           ( w_cc_nsbif_en         [gcc]      )
    ,.o_iq           ( w_cc_nsbif_iq         [gcc]      )
);
end //LPHY_PROJECT_NAME=="RF2221d"
end //NB_NUM_SBIF==1
ylib_cc_bw_align #(   
     .MAX_BW_IDX    (   MAX_BW_IDX              )
    ,.NUM_ANT       (   NB_NUM_ANT              )
    ,.DIO_BW        (   TOP_DIO_BW              ))
u10_2_2_nb_cc_bw_align
(
     .i_clk          ( i_core_clk                       )
    ,.i_bfn_strb     ( w_cc_nsbif_bfn_strb      [CC_REF])
    ,.i_bfn          ( w_cc_nsbif_bfn           [CC_REF])
    ,.i_fsync        ( w_cc_nsbif_frame_sync    [CC_REF])
    ,.i_en           ( w_cc_nsbif_en            [gcc]   )
    ,.i_iq           ( w_cc_nsbif_iq            [gcc]   )
    ,.o_bfn_strb     ( w_cc_nsbif_a_bfn_strb    [gcc]   )
    ,.o_bfn          ( w_cc_nsbif_a_bfn         [gcc]   )
    ,.o_fsync        ( w_cc_nsbif_a_frame_sync  [gcc]   )
    ,.o_en           ( w_cc_nsbif_a_en          [gcc]   )
    ,.o_iq           ( w_cc_nsbif_a_iq          [gcc]   )
);
always@(posedge i_core_clk) begin
    r_cc_nin_frame_sync [gcc] <= w_cc_nsbif_a_frame_sync[gcc] ;
    r_cc_nin_en         [gcc] <= w_cc_nsbif_a_en        [gcc] ;
    if(|w_cc_nsbif_a_en[gcc]) begin
        r_cc_nin_iq     [gcc] <= w_cc_nsbif_a_iq        [gcc] ;
    end
    else if((~|w_cc_nsbif_a_en[gcc])&(|r_cc_nin_en[gcc])) begin
        r_cc_nin_iq     [gcc] <= {{2*TOP_DIO_BW}{1'b0}} ;
    end
end
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g12_3_1_mt_sbif_sig_demap
always@(posedge i_core_clk) begin
    r_cc_min_frame_sync [gcc] <= w_cc_usbif_a_frame_sync[gcc] ;
    r_cc_min_en         [gcc] <= w_cc_usbif_a_en        [gcc] ;
    if(|w_cc_usbif_a_en[gcc]) begin
        r_cc_min_iq     [gcc] <= w_cc_usbif_a_iq        [gcc] ;
    end
    else if((~|w_cc_usbif_a_en[gcc])&(|r_cc_min_en[gcc])) begin
        r_cc_min_iq     [gcc] <= {{2*TOP_DIO_BW}{1'b0}} ;
    end
end
end
endgenerate
`endif //EMTC_CORE_DISABLE
`endif //SBIF_ENABLE

generate for(gcc=0; gcc<DL_MAX_CC; gcc=gcc+1) begin : g13_0_dl_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_din_frame_sync    [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_din_frame_sync      [gcc]  ;
    r_sig_cap_din_en            [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )] <=  w_cc_din_en              [gcc]  ;
    r_sig_cap_din_iq            [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_cc_din_iq              [gcc]  ;
    r_sig_cap_dout_frame_sync   [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_dout_frame_sync     [gcc]  ;
    r_sig_cap_dout_en           [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )] <=  w_cc_dout_en             [gcc]  ;
    r_sig_cap_dout_iq           [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_cc_dout_iq             [gcc]  ;
    r_sig_cap_nr_dl_cp_data     [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_nr_dl_cp_data_cc       [gcc]  ;
end
end
endgenerate
generate for(gcc=0; gcc<UL_MAX_CC; gcc=gcc+1) begin : g13_1_ul_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_uin_frame_sync    [((01                     )*(gcc+1)-1)-:(01                     )] <=  r_cc_uin_frame_sync      [gcc]  ; 
    r_sig_cap_uin_en            [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )] <=  r_cc_uin_en              [gcc]  ;
    r_sig_cap_uin_iq            [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  r_cc_uin_iq              [gcc]  ;
    r_sig_cap_uout_frame_sync   [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_uout_frame_sync     [gcc]  ; 
    r_sig_cap_uout_en           [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )] <=  w_cc_uout_en             [gcc]  ;
    r_sig_cap_uout_iq           [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  w_cc_uout_iq             [gcc]  ;
end
end
endgenerate
generate for(gcc=0; gcc<RA_MAX_CC; gcc=gcc+1) begin : g13_2_ra_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_rout_frame_sync   [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_rout_frame_sync     [gcc]  ;
    r_sig_cap_rout_en           [((01*RA_NUM_ANT          )*(gcc+1)-1)-:(01*RA_NUM_ANT          )] <=  w_cc_rout_en             [gcc]  ;
    r_sig_cap_rout_iq           [((2*TOP_DIO_BW*RA_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*RA_NUM_ANT)] <=  w_cc_rout_iq             [gcc]  ;
    r_sig_cap_nr_ra_cp_data     [((2*TOP_DIO_BW*RA_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*RA_NUM_ANT)] <=  w_nr_ra_cp_data_cc       [gcc]  ;
end
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gcc=0; gcc<2; gcc=gcc+1) begin : g13_3_nb_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_nin_frame_sync    [((01                     )*(gcc+1)-1)-:(01                     )] <=  r_cc_nin_frame_sync      [gcc]  ; 
    r_sig_cap_nin_en            [((01*NB_NUM_ANT          )*(gcc+1)-1)-:(01*NB_NUM_ANT          )] <=  r_cc_nin_en              [gcc]  ;
    r_sig_cap_nin_iq            [((2*TOP_DIO_BW*NB_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*NB_NUM_ANT)] <=  r_cc_nin_iq              [gcc]  ;
end
end
endgenerate
generate for(gcc=0; gcc<NB_MAX_CC; gcc=gcc+1) begin : g13_4_nb_sig_cap_map
always@(posedge i_core_clk) begin   
    r_sig_cap_nout_frame_sync   [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_nout_frame_sync     [gcc]  ; 
    r_sig_cap_nout_en           [((01*NB_NUM_ANT          )*(gcc+1)-1)-:(01*NB_NUM_ANT          )] <=  w_cc_nout_en             [gcc]  ;
    r_sig_cap_nout_iq           [((2*TOP_DIO_BW*NB_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*NB_NUM_ANT)] <=  w_cc_nout_iq             [gcc]  ;
    r_sig_cap_nr_nb_cp_data     [((2*TOP_DIO_BW*NB_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*NB_NUM_ANT)] <=  w_nr_nb_cp_data_cc       [gcc]  ;
end
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MT_MAX_CC; gcc=gcc+1) begin : g13_4_mt_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_min_frame_sync    [((01                     )*(gcc+1)-1)-:(01                     )] <=  r_cc_min_frame_sync      [gcc]  ; 
    r_sig_cap_min_en            [((01*MT_NUM_ANT          )*(gcc+1)-1)-:(01*MT_NUM_ANT          )] <=  r_cc_min_en              [gcc]  ;
    r_sig_cap_min_iq            [((2*TOP_DIO_BW*MT_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*MT_NUM_ANT)] <=  r_cc_min_iq              [gcc]  ;
    r_sig_cap_mout_frame_sync   [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_mout_frame_sync     [gcc]  ; 
    r_sig_cap_mout_en           [((01*MT_NUM_ANT          )*(gcc+1)-1)-:(01*MT_NUM_ANT          )] <=  w_cc_mout_en             [gcc]  ;
    r_sig_cap_mout_iq           [((2*TOP_DIO_BW*MT_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*MT_NUM_ANT)] <=  w_cc_mout_iq             [gcc]  ;
    r_sig_cap_nr_mt_cp_data     [((2*TOP_DIO_BW*MT_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*MT_NUM_ANT)] <=  w_nr_mt_cp_data_cc       [gcc]  ;
end
end
endgenerate
`endif //EMTC_CORE_DISABLE
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g13_5_bfn_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_bfn               [((12                     )*(gcc+1)-1)-:(12                     )] <=  w_cc_din_bfn          [CC_REF]  ;
end
end
endgenerate
`ifdef SBIF_ENABLE
generate for(gidx=0; gidx<UL_MAX_CC; gidx=gidx+1) begin : g13_5_usbif_sig_cap_map
if(gidx<UL_NUM_SBIF) begin
always@(posedge i_core_clk) begin
    r_sig_cap_usbif_frame_sync   [((01                     )*(gidx+1)-1)-:(01                     )] <=  r_usbif_in_fsync        [gidx] ; 
    r_sig_cap_usbif_en           [((01*UL_NUM_ANT          )*(gidx+1)-1)-:(01*UL_NUM_ANT          )] <=  {{UL_NUM_ANT}{w_usbif_in_en[gidx]}};
    r_sig_cap_usbif_iq           [((2*TOP_DIO_BW*UL_NUM_ANT)*(gidx+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  {{UL_NUM_ANT}{w_usbif_in_iq_mux[gidx][2*TOP_DIO_BW-1:1],w_usbif_in_csync[gidx]}};
end
end //if(gidx<UL_NUM_SBIF)
else begin //if(gidx<UL_NUM_SBIF)
always@(posedge i_core_clk) begin
    r_sig_cap_usbif_frame_sync   [((01                     )*(gidx+1)-1)-:(01                     )] <=  1'b0 ;
    r_sig_cap_usbif_en           [((01*UL_NUM_ANT          )*(gidx+1)-1)-:(01*UL_NUM_ANT          )] <=  {{01*UL_NUM_ANT          }{1'b0}};
    r_sig_cap_usbif_iq           [((2*TOP_DIO_BW*UL_NUM_ANT)*(gidx+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  {{2*TOP_DIO_BW*UL_NUM_ANT}{1'b0}};
end
end //if(gidx<UL_NUM_SBIF)
end
endgenerate
`ifndef NBIOT_CORE_DISABLE
generate for(gidx=0; gidx<NB_MAX_CC; gidx=gidx+1) begin : g13_6_nsbif_sig_cap_map
if(gidx<NB_NUM_SBIF) begin
always@(posedge i_core_clk) begin
    r_sig_cap_nsbif_frame_sync   [((01                     )*(gidx+1)-1)-:(01                     )] <=  r_nsbif_in_fsync        [gidx] ; 
    r_sig_cap_nsbif_en           [((01*NB_NUM_ANT          )*(gidx+1)-1)-:(01*NB_NUM_ANT          )] <=  {{NB_NUM_ANT}{w_nsbif_in_en[gidx]}};
    r_sig_cap_nsbif_iq           [((2*TOP_DIO_BW*NB_NUM_ANT)*(gidx+1)-1)-:(2*TOP_DIO_BW*NB_NUM_ANT)] <=  {{NB_NUM_ANT}{w_nsbif_in_iq_mux[gidx][2*TOP_DIO_BW-1:1],w_nsbif_in_csync[gidx]}};
end
end //if(gidx<NB_NUM_SBIF)
else begin //if(gidx<NB_NUM_SBIF)
always@(posedge i_core_clk) begin
    r_sig_cap_nsbif_frame_sync   [((01                     )*(gidx+1)-1)-:(01                     )] <=  1'b0 ;
    r_sig_cap_nsbif_en           [((01*NB_NUM_ANT          )*(gidx+1)-1)-:(01*NB_NUM_ANT          )] <=  {{01*NB_NUM_ANT          }{1'b0}};
    r_sig_cap_nsbif_iq           [((2*TOP_DIO_BW*NB_NUM_ANT)*(gidx+1)-1)-:(2*TOP_DIO_BW*NB_NUM_ANT)] <=  {{2*TOP_DIO_BW*NB_NUM_ANT}{1'b0}};
end
end //if(gidx<NB_NUM_SBIF)
end
endgenerate
`endif //NBIOT_CORE_DISABLE
`endif //SBIF_ENABLE

//--- C-Plane Internal Mapping
generate for(gcc=0;gcc<DL_MAX_CC;gcc=gcc+1) begin : g14_0_dl_cp_cap_map
for(gant=0;gant<DL_NUM_ANT;gant=gant+1) begin : g14_0_0_cp_sig_map_ant
assign  w_nr_dl_cp_data_cc_ant [gcc][gant]  =   {w_cc_din_frame_idx[gcc],{3'd0,w_cc_din_en[gcc][gant]},w_cc_din_iq[gcc][((gant+1)*2*TOP_DIO_BW-1)-:8],{2'd0,w_cc_din_sys_mode_dss[gcc][(1*(gant+1)-1)-:1],w_cc_din_re_mask[gcc][(1*(gant+1)-1)-:1]},w_cc_din_frame_struct[gcc][(8*(gant+1)-1)-:8]} ;   
assign  w_nr_dl_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_dl_cp_data_cc_ant[gcc][gant];   
end
end
endgenerate
generate for(gcc=0;gcc<RA_MAX_CC;gcc=gcc+1) begin : g14_1_ul_cp_cap_map
for(gant=0;gant<RA_NUM_ANT;gant=gant+1) begin : g14_1_0_cp_sig_map_ant
if(gant==0) begin    
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {w_cc_rin_num_prbc[gcc][(8*(gant+1)-1)-:8],w_cc_rin_freq_offset[gcc][(24*(gant+1)-1)-:24],w_cc_rin_num_ro[gcc][(3*(gant+1)-1)-:3]} ;   
end
else if(gant==1) begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {w_cc_rin_filter_idx[gcc][(4*(gant+1)-1)-:4],w_cc_rin_frame_struct[gcc][(8*(gant+1)-1)-:8],w_cc_rin_cp_length[gcc][(16*(gant+1)-1)-:16],w_cc_rin_num_psymbol[gcc][(4*(gant+1)-1)-:4]} ;   
end
else if(gant==2) begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {w_cc_uin_frame_idx[gcc],8'd0,w_cc_rin_time_offset[gcc][(16*(gant+1)-1)-:16]}   ;   
end
else begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {{3'd0,w_cc_uin_frame_sync[gcc%UL_MAX_CC]},{3'd0,w_cc_rin_frame_sync[gcc]},4'd0,{3'd0,w_cc_uout_frame_sync[gcc]},{3'd0,w_cc_rout_frame_sync[gcc]},4'd0,{3'd0,w_cc_din_frame_sync[gcc]},{3'd0,w_cc_dout_frame_sync[gcc]}}   ;   
end
assign  w_nr_ra_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_ra_cp_data_cc_ant[gcc][gant];   
end
end
endgenerate
//`ifndef NBIOT_CORE_DISABLE
//generate for(gcc=0;gcc<NB_MAX_CC;gcc=gcc+1) begin : g14_2_nb_cp_cap_map
//for(gant=0;gant<NB_NUM_ANT;gant=gant+1) begin : g14_2_0_cp_sig_map_ant
//if(gant==0) begin    
//assign  w_nr_nb_cp_data_cc_ant [gcc][gant]  =   {w_cc_nin_num_prbc[gcc][(8*(gant+1)-1)-:8],w_cc_nin_freq_offset[gcc][(24*(gant+1)-1)-:24],3'd0} ;   
//end
//else if(gant==1) begin
//assign  w_nr_nb_cp_data_cc_ant [gcc][gant]  =   {w_cc_nin_filter_idx[gcc][(4*(gant+1)-1)-:4],w_cc_nin_frame_struct[gcc][(8*(gant+1)-1)-:8],w_cc_nin_cp_length[gcc][(16*(gant+1)-1)-:16],w_cc_nin_num_psymbol[gcc][(4*(gant+1)-1)-:4]} ;   
//end
//else if(gant==2) begin
//assign  w_nr_nb_cp_data_cc_ant [gcc][gant]  =   {w_cc_uin_frame_idx[gcc],5'd0,w_cc_nin_num_ro[gcc][(3*(gant+1)-1)-:3],w_cc_nin_time_offset[gcc][(16*(gant+1)-1)-:16]} ;   
//end
//else begin
//assign  w_nr_nb_cp_data_cc_ant [gcc][gant]  =   {{3'd0,w_cc_uin_frame_sync[gcc]},{3'd0,w_cc_nin_frame_sync[gcc]},4'd0,{3'd0,w_cc_uout_frame_sync[gcc]},{3'd0,w_cc_nout_frame_sync[gcc]},4'd0,{3'd0,w_cc_din_frame_sync[gcc]},{3'd0,w_cc_dout_frame_sync[gcc]}}   ;   
//end
//assign  w_nr_nb_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_nb_cp_data_cc_ant[gcc][gant];   
//end
//end
//endgenerate
//`endif //NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
generate for(gcc=0;gcc<MT_MAX_CC;gcc=gcc+1) begin : g14_3_mt_cp_cap_map
for(gant=0;gant<MT_NUM_ANT;gant=gant+1) begin : g14_3_0_cp_sig_map_ant
if(gant==0) begin    
assign  w_nr_mt_cp_data_cc_ant [gcc][gant]  =   {w_cc_min_num_prbc[gcc][(8*(gant+1)-1)-:8],w_cc_min_freq_offset[gcc][(24*(gant+1)-1)-:24],w_cc_min_num_ro[gcc][(3*(gant+1)-1)-:3]} ;   
end
else if(gant==1) begin
assign  w_nr_mt_cp_data_cc_ant [gcc][gant]  =   {w_cc_min_filter_idx[gcc][(4*(gant+1)-1)-:4],w_cc_min_frame_struct[gcc][(8*(gant+1)-1)-:8],w_cc_min_cp_length[gcc][(16*(gant+1)-1)-:16],w_cc_min_num_psymbol[gcc][(4*(gant+1)-1)-:4]} ;   
end
else if(gant==2) begin
assign  w_nr_mt_cp_data_cc_ant [gcc][gant]  =   {w_cc_min_frame_idx[gcc],8'd0,w_cc_min_time_offset[gcc][(16*(gant+1)-1)-:16]}   ;   
end
else begin
assign  w_nr_mt_cp_data_cc_ant [gcc][gant]  =   {{3'd0,w_cc_min_frame_sync[gcc]},{3'd0,w_cc_min_frame_sync[gcc]},4'd0,{3'd0,w_cc_uout_frame_sync[gcc]},{3'd0,w_cc_mout_frame_sync[gcc]},4'd0,{3'd0,w_cc_din_frame_sync[gcc]},{3'd0,w_cc_dout_frame_sync[gcc]}}   ;   
end
assign  w_nr_mt_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_mt_cp_data_cc_ant[gcc][gant];   
end
end
endgenerate
`endif //EMTC_CORE_DISABLE

`ifndef SBIF_ENABLE
`ifndef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_min_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_mout_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync};
assign w_sig_cap_en         = {r_sig_cap_min_en ,r_sig_cap_min_en ,r_sig_cap_mout_en ,r_sig_cap_nin_en ,r_sig_cap_nin_en ,r_sig_cap_nout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en};
assign w_sig_cap_iq         = {r_sig_cap_nr_mt_cp_data ,r_sig_cap_min_iq ,r_sig_cap_mout_iq ,r_sig_cap_nr_nb_cp_data ,r_sig_cap_nin_iq ,r_sig_cap_nout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_nin_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync};
assign w_sig_cap_en         = {r_sig_cap_nin_en ,r_sig_cap_nin_en ,r_sig_cap_nout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en};
assign w_sig_cap_iq         = {r_sig_cap_nr_nb_cp_data ,r_sig_cap_nin_iq ,r_sig_cap_nout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_min_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_mout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync};
assign w_sig_cap_en         = {r_sig_cap_min_en ,r_sig_cap_min_en ,r_sig_cap_mout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en};
assign w_sig_cap_iq         = {r_sig_cap_nr_mt_cp_data ,r_sig_cap_min_iq ,r_sig_cap_mout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//NBIOT_CORE_DISABLE
`endif//EMTC_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync}; 
assign w_sig_cap_en         = {r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en}; 
assign w_sig_cap_iq         = {r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`else //SBIF_ENABLE/
`ifndef NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_nsbif_frame_sync ,r_sig_cap_usbif_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_mout_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync}; 
assign w_sig_cap_en         = {r_sig_cap_nsbif_en ,r_sig_cap_usbif_en ,r_sig_cap_min_en ,r_sig_cap_min_en ,r_sig_cap_mout_en ,r_sig_cap_nin_en ,r_sig_cap_nin_en ,r_sig_cap_nout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en}; 
assign w_sig_cap_iq         = {r_sig_cap_nsbif_iq ,r_sig_cap_usbif_iq ,r_sig_cap_nr_mt_cp_data ,r_sig_cap_min_iq ,r_sig_cap_mout_iq ,r_sig_cap_nr_nb_cp_data ,r_sig_cap_nin_iq ,r_sig_cap_nout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_nsbif_frame_sync ,r_sig_cap_usbif_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nin_frame_sync ,r_sig_cap_nout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync}; 
assign w_sig_cap_en         = {r_sig_cap_nsbif_en ,r_sig_cap_usbif_en ,r_sig_cap_nin_en ,r_sig_cap_nin_en ,r_sig_cap_nout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en}; 
assign w_sig_cap_iq         = {r_sig_cap_nsbif_iq ,r_sig_cap_usbif_iq ,r_sig_cap_nr_nb_cp_data ,r_sig_cap_nin_iq ,r_sig_cap_nout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_usbif_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_min_frame_sync ,r_sig_cap_mout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync}; 
assign w_sig_cap_en         = {r_sig_cap_usbif_en ,r_sig_cap_min_en ,r_sig_cap_min_en ,r_sig_cap_mout_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en}; 
assign w_sig_cap_iq         = {r_sig_cap_usbif_iq ,r_sig_cap_nr_mt_cp_data ,r_sig_cap_min_iq ,r_sig_cap_mout_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//NBIOT_CORE_DISABLE
`endif//EMTC_CORE_DISABLE
`ifdef NBIOT_CORE_DISABLE
`ifdef EMTC_CORE_DISABLE
assign w_sig_cap_frame_sync = {r_sig_cap_usbif_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_rout_frame_sync ,r_sig_cap_uin_frame_sync ,r_sig_cap_uout_frame_sync ,r_sig_cap_din_frame_sync ,r_sig_cap_dout_frame_sync ,r_sig_cap_din_frame_sync}; 
assign w_sig_cap_en         = {r_sig_cap_usbif_en ,r_sig_cap_uin_en ,r_sig_cap_rout_en ,r_sig_cap_uin_en ,r_sig_cap_uout_en ,r_sig_cap_din_en ,r_sig_cap_dout_en ,r_sig_cap_din_en}; 
assign w_sig_cap_iq         = {r_sig_cap_usbif_iq ,r_sig_cap_nr_ra_cp_data ,r_sig_cap_rout_iq ,r_sig_cap_uin_iq ,r_sig_cap_uout_iq ,r_sig_cap_nr_dl_cp_data ,r_sig_cap_dout_iq ,r_sig_cap_din_iq}; 
`endif//EMTC_CORE_DISABLE
`endif//NBIOT_CORE_DISABLE
`endif //SBIF_ENABLE//
endmodule
