////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : Vzw RF4440d_13AB_TYPE01, MSTR_V02
//                       VF RF4448/RF4449/RF2221d/RF2222d
//  Module       : LPHY_TOP 
//  Author       : jyzoo.lee@samsung.com
//  Description  : Baseband LPHY TOP Header
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Create Initial Design                 (SVR21D)
//  ------------+---------------+-----------------------------------------------
//   2021.10.01 | jyzoo.lee     | Capaticy Expansion up to 3ccX2sect    (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.10.14 | jyzoo.lee     | NB-IoT Support                        (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.11.15 | jyzoo.lee     | SBIF Support                          (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.12.16 | jyzoo.lee     | eMTC Support                          (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2022.01.03 | jyzoo.lee     | Sector Split Support                  (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2022.05.12 | jyzoo.lee     | RACH 2 Band Support                   (SVR22C)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////
//////PROJECT
`define LPHY_PROJECT_NAME   "RF4440d"
`define LPHY_SW_PKG_NAME    "22C"

//////VERSION
`define P4V_VERSION  32'h6518009

//////CAPACITY
`define DL_MAX_CC       2
`define DL_NUM_CC       2
`define UL_MAX_CC       2
`define UL_NUM_CC       2
`define RA_MAX_CC       2
`define RA_NUM_CC       2
`define NB_MAX_CC       3
`define NB_NUM_CC       3
`define MT_MAX_CC       1
`define MT_NUM_CC       1
`define DL_NUM_LAYER    4
`define DL_NUM_ANT      4
`define UL_NUM_PATH     4
`define UL_NUM_ANT      4
`define RA_NUM_PATH     4
`define RA_NUM_ANT      4
`define NB_NUM_PATH     4
`define NB_NUM_ANT      4
`define MT_NUM_PATH     4
`define MT_NUM_ANT      4

//////SECTOR
`define DL_NUM_SECTOR   1
`define UL_NUM_SECTOR   1
`define RA_NUM_SECTOR   1
`define NB_NUM_SECTOR   1
`define MT_NUM_SECTOR   2

//////LPHY DISABLE
//`define DLFE_CORE_DISABLE
//`define ULFE_CORE_DISABLE
//`define RAFE_CORE_DISABLE
//`define NBIOT_CORE_DISABLE
//`define EMTC_CORE_DISABLE

//`define SBIF_ENABLE 
//////SBIF CONFIGURATION
`ifdef SBIF_ENABLE 
`define DL_NUM_SBIF     1
`define UL_NUM_SBIF     1
`define NB_NUM_SBIF     1
`define MT_NUM_SBIF     1
`define MAX_BW_IDX      3
`endif

//////BB_TOP CONFIGURATION
////DLFE
`include "dlfe_top.vh"

////ULFE
`include "ulfe_cc.vh"

////RAFE
`define MAX_OBW 10

//////MACRO
`define mlib_max2(v1, v2) ((v1) > (v2) ? (v1) : (v2))
`define mlib_max3(v1, v2, v3) `mlib_max2((v1), `mlib_max2((v2), (v3)))
`define mlib_max4(v1, v2, v3, v4) `mlib_max3((v1), (v2), `mlib_max2((v3), (v4)))
`define mlib_max5(v1, v2, v3, v4, v5) `mlib_max4((v1), (v2), (v3), `mlib_max2((v4), (v5)))
