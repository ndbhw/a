////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : RF4440d_13AB_TYPE01
//  Module       : lphy_top_cpu_if 
//  Author       : jyzoo.lee@samsung.com
//  Description  : cpu interface for lphy
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Create Initial Design                 (SVR21D)
//  ------------+---------------+-----------------------------------------------
//   2021.09.30 | jyzoo.lee     | Capaticy Expansion up to 4cc          (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.10.15 | jyzoo.lee     | NB-IoT Support                        (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.11.12 | jyzoo.lee     | SBIF Support                          (SVR22A)
//  ------------+---------------+-----------------------------------------------
//   2021.11.29 | jyzoo.lee     | eMTC Support                          (SVR22A)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "LPHY_TOP.vh"

module lphy_top_cpu_if 
#(
    parameter   NUM_CC                  =    1          
   ,parameter   NUM_PATH                =    1          
   ,parameter   BW_ADDR_HEAD            =    8  
   ,parameter   CPUIF_ADDR_BW           =   20  
   ,parameter   CPUIF_TOP_ADDR_BW       =   24  
   ,parameter   CPUIF_LPHY_ADDR_BW      =   20  
   ,parameter   CPUIF_DATA_BW           =   32
   ,parameter   NUM_DUMP_ITEM           =    7 
   ,parameter   DUMP_MEM_ADDR_BW        =   15 
   ,parameter   DLY_REG_RD              =   10 
   ,parameter   P4V_VERSION             =   32'hffff_ffff 
   ,parameter   VENDOR                  =   "Xilinx" 
)(
    //--- From SYSCTRL_TOP
        input   wire                                                i_clk  
    ,   input   wire                                                i_rst  

    //--- From/To CPU IF
    ,   input   wire                                                i_cpu_clk  
    ,   input   wire                                                i_cpu_rst  
    ,   input   wire    [0:0]                                       i_cpu_cs
    ,   input   wire    [CPUIF_ADDR_BW-1:0]                         i_cpu_addr
    ,   input   wire    [0:0]                                       i_cpu_wren
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_cpu_wdata
    ,   input   wire    [0:0]                                       i_cpu_rden
    ,   output  reg     [CPUIF_DATA_BW-1:0]                         o_cpu_rdata
    ,   output  wire    [0:0]                                       o_cpu_rd_valid

    //--- From/To DLFE,ULFE,RAFE
    ,   output  wire    [CPUIF_LPHY_ADDR_BW*NUM_CC-1:0]             o_core_addr
    ,   output  wire    [01*NUM_CC-1:0]                             o_core_wren
    ,   output  wire    [CPUIF_DATA_BW*NUM_CC-1:0]                  o_core_wdata
    ,   output  wire    [01*NUM_CC-1:0]                             o_core_rden
    ,   input   wire    [CPUIF_DATA_BW*NUM_CC-1:0]                  i_core_rdata
    ,   input   wire    [01*NUM_CC-1:0]                             i_core_rd_valid

    //--- From/To LPHY_TOP 
    ,   output  reg     [01-1:0]                                    o_lphy_top_par_100008
    ,   output  reg     [01-1:0]                                    o_sigcap_par_180000
    ,   output  reg     [$clog2(NUM_CC)-1:0]                        o_sigcap_par_180004
    ,   output  reg     [$clog2(NUM_PATH)-1:0]                      o_sigcap_par_180008
    ,   output  reg     [12-1:0]                                    o_sigcap_par_18000c
    ,   output  reg     [04-1:0]                                    o_sigcap_par_180010
    ,   output  reg     [08-1:0]                                    o_sigcap_par_180014
    ,   output  reg     [04-1:0]                                    o_sigcap_par_180018
    ,   output  reg     [$clog2(NUM_DUMP_ITEM)-1:0]                 o_sigcap_par_18001c
    ,   output  reg     [03-1:0]                                    o_sigcap_par_180020
    ,   output  reg     [04-1:0]                                    o_sigcap_par_180024
    ,   output  reg     [03-1:0]                                    o_sigcap_par_180028
    ,   output  reg     [32-1:0]                                    o_sigcap_par_18002c

    //--- From DLFE/ULFE/RAFE/NBIOT/EMTC
    ,   input   wire    [22*NUM_CC-1:0]                             i_cc_dl_proc_dly
    ,   input   wire    [22*NUM_CC-1:0]                             i_cc_ul_proc_dly
    ,   input   wire    [22*NUM_CC-1:0]                             i_cc_ra_proc_dly
    ,   input   wire    [22*NUM_CC-1:0]                             i_cc_nb_proc_dly
    ,   input   wire    [22*NUM_CC-1:0]                             i_cc_mt_proc_dly

    //--- From/To LPHY_TOP
    ,   input   wire    [01*NUM_CC-1:0]                             i_din_fsync
    ,   input   wire    [01*NUM_CC-1:0]                             i_uin_fsync
    ,   input   wire    [01*NUM_CC-1:0]                             i_nin_fsync
    ,   input   wire    [01*NUM_CC-1:0]                             i_min_fsync
    ,   output  reg     [22*NUM_CC-1:0]                             o_cc_ul_retard
    ,   output  reg     [22*NUM_CC-1:0]                             o_cc_nb_retard
    ,   output  reg     [22*NUM_CC-1:0]                             o_cc_mt_retard
    
    //--- From DUMP
    ,   input   wire    [0:0]                                       i_dump_wr_en
    ,   input   wire    [DUMP_MEM_ADDR_BW-1:0]                      i_dump_wr_addr
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_dump_wr_data
);

//local parameter
localparam  [CPUIF_TOP_ADDR_BW-1:0]     LPHY_TOP_BASE_ADDR      =      'h100000             ;
localparam  [CPUIF_TOP_ADDR_BW-1:0]     SIGCAP_BASE_ADDR        =      'h180000             ;
localparam  [CPUIF_TOP_ADDR_BW-1:0]     DUMP_BASE_ADDR          =      'h1A0000             ;
localparam  [BW_ADDR_HEAD-1:0]          CC00_ADDR_OFFSET        =      'h10                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC01_ADDR_OFFSET        =      'h11                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC02_ADDR_OFFSET        =      'h12                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC03_ADDR_OFFSET        =      'h13                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC04_ADDR_OFFSET        =      'h14                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC05_ADDR_OFFSET        =      'h15                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC06_ADDR_OFFSET        =      'h16                 ;
localparam  [BW_ADDR_HEAD-1:0]          CC07_ADDR_OFFSET        =      'h17                 ;
localparam  [BW_ADDR_HEAD-1:0]          DUMP0_ADDR_OFFSET       =      'h1A                 ;
localparam  [BW_ADDR_HEAD-1:0]          DUMP1_ADDR_OFFSET       =      'h1B                 ;
localparam  CPUIF_LPHY_CC_ADDR_BW       =       16                  ; 
localparam  CC00_DEMUX_INDEX            =       00                  ;
localparam  CC01_DEMUX_INDEX            =       01                  ;
localparam  CC02_DEMUX_INDEX            =       02                  ;
localparam  CC03_DEMUX_INDEX            =       03                  ;
localparam  CC04_DEMUX_INDEX            =       04                  ;
localparam  CC05_DEMUX_INDEX            =       05                  ;
localparam  CC06_DEMUX_INDEX            =       06                  ;
localparam  CC07_DEMUX_INDEX            =       07                  ;
localparam  DUMP_DEMUX_INDEX            =       NUM_CC              ;
localparam  MAX_CC                      =       8                   ;
localparam  DLY_REG_RD_DUMP             =       1                   ;
localparam  DEPTH_DUMP                  =       2**15               ;   
localparam  BW_DEPTH_DUMP               =       $clog2(DEPTH_DUMP)  ;   

//Logic Variable
genvar gidx ;
integer i   ;

////lphy_top reg 
reg [32-1:0]  r_lphy_top_rpt_100004 ;
reg [22*MAX_CC-1:0]  r_lphy_top_par_1000n0_ul_retard   ;
reg [32*MAX_CC-1:0]  r_lphy_top_rpt_1000n4_dl_proc_dly ;
reg [32*MAX_CC-1:0]  r_lphy_top_rpt_1000n8_ul_proc_dly ;
reg [32*MAX_CC-1:0]  r_lphy_top_rpt_1000nc_ra_proc_dly ;
reg [22*MAX_CC-1:0]  r_lphy_top_par_1000n0_nb_retard   ;
reg [32*MAX_CC-1:0]  r_lphy_top_rpt_1000nc_nb_proc_dly ;
reg [22*MAX_CC-1:0]  r_lphy_top_par_1000n0_mt_retard   ;
reg [32*MAX_CC-1:0]  r_lphy_top_rpt_1000nc_mt_proc_dly ;

always@(posedge i_clk) begin
    for(i=0;i<MAX_CC;i=i+1) begin    
        if(i<NUM_CC) begin
            if(i_din_fsync[0]) begin
                o_cc_ul_retard[((22)*(i+1)-1)-:(22)] <= r_lphy_top_par_1000n0_ul_retard  [((22)*(i+1)-1)-:(22)] ;
                r_lphy_top_rpt_1000n4_dl_proc_dly[((32)*(i+1)-1)-:(32)] <= {8'd8,2'd0,i_cc_dl_proc_dly[((22)*(i+1)-1)-:(22)]} ;
                r_lphy_top_rpt_1000n8_ul_proc_dly[((32)*(i+1)-1)-:(32)] <= {8'd8,2'd0,i_cc_ul_proc_dly[((22)*(i+1)-1)-:(22)]} ;
                r_lphy_top_rpt_1000nc_ra_proc_dly[((32)*(i+1)-1)-:(32)] <= {8'd8,2'd0,i_cc_ra_proc_dly[((22)*(i+1)-1)-:(22)]} ;
`ifndef NBIOT_CORE_DISABLE
    	        o_cc_nb_retard[((22)*(i+1)-1)-:(22)] <= r_lphy_top_par_1000n0_nb_retard  [((22)*(i+1)-1)-:(22)] ;
                r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(i+1)-1)-:(32)] <= {8'd8,2'd0,i_cc_nb_proc_dly[((22)*(i+1)-1)-:(22)]} ;
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
    	        o_cc_mt_retard[((22)*(i+1)-1)-:(22)] <= r_lphy_top_par_1000n0_mt_retard  [((22)*(i+1)-1)-:(22)] ;
                r_lphy_top_rpt_1000nc_mt_proc_dly[((32)*(i+1)-1)-:(32)] <= {8'd8,2'd0,i_cc_mt_proc_dly[((22)*(i+1)-1)-:(22)]} ;
`endif//EMTC_CORE_DISABLE
            end
        end
    end
end

//cpu if cdc
reg [0:0]                       r_cpu2lphy_wren     ;
reg [0:0]                       r_cpu2lphy_rden     ;
reg [0:0]                       rr_cpu2lphy_wren    ;
reg [0:0]                       rr_cpu2lphy_rden    ;
reg [0:0]                       rrr_cpu2lphy_wren   ;
reg [0:0]                       rrr_cpu2lphy_rden   ;
reg [0:0]                       rrrr_cpu2lphy_wren  ;
reg [0:0]                       rrrr_cpu2lphy_rden  ;
reg [CPUIF_TOP_ADDR_BW-1:0]     r_cpu2lphy_addr     ;
reg [CPUIF_DATA_BW-1:0]         r_cpu2lphy_wdata    ;
reg [0:0]                       r_lphy_wren         ;
reg [CPUIF_DATA_BW-1:0]         r_lphy_wdata        ;
reg [0:0]                       r_lphy_rden         ;
reg [CPUIF_TOP_ADDR_BW-1:0]     r_lphy_addr         ;
always@(posedge i_cpu_clk) begin
    if(i_cpu_cs) begin
        r_cpu2lphy_addr   <=  i_cpu_addr<<2 ;
        r_cpu2lphy_wdata  <=  i_cpu_wdata   ;
        r_cpu2lphy_wren   <=  i_cpu_wren    ;
        r_cpu2lphy_rden   <=  i_cpu_rden    ;
    end
    else begin
        r_cpu2lphy_wren   <=  1'd0    ;
        r_cpu2lphy_rden   <=  1'd0    ;
    end
end
always@(posedge i_clk) begin
    rr_cpu2lphy_wren    <=  r_cpu2lphy_wren     ;
    rr_cpu2lphy_rden    <=  r_cpu2lphy_rden     ;
    rrr_cpu2lphy_wren   <=  rr_cpu2lphy_wren    ;
    rrr_cpu2lphy_rden   <=  rr_cpu2lphy_rden    ;
    rrrr_cpu2lphy_wren  <=  rrr_cpu2lphy_wren   ;
    rrrr_cpu2lphy_rden  <=  rrr_cpu2lphy_rden   ;
    r_lphy_wren         <=  rrr_cpu2lphy_wren & ~rrrr_cpu2lphy_wren ;
    r_lphy_rden         <=  rrr_cpu2lphy_rden & ~rrrr_cpu2lphy_rden ;
    if(rrr_cpu2lphy_wren & ~rrrr_cpu2lphy_wren) begin
        r_lphy_addr   <=  r_cpu2lphy_addr  ;
        r_lphy_wdata  <=  r_cpu2lphy_wdata ;
    end
    else if(rrr_cpu2lphy_rden & ~rrrr_cpu2lphy_rden) begin
        r_lphy_addr   <=  r_cpu2lphy_addr  ;
    end
end

reg [CPUIF_TOP_ADDR_BW-1:0]    r_demux_core_addr   [MAX_CC+1-1:0]      ; //CC+dump
reg [0:0]                      r_demux_core_wren   [MAX_CC+1-1:0]      ;
reg [CPUIF_DATA_BW-1:0]        r_demux_core_wdata  [MAX_CC+1-1:0]      ;
reg [0:0]                      r_demux_core_rden   [MAX_CC+1-1:0]      ;
reg [CPUIF_TOP_ADDR_BW-0:0]    r_demux_dump_addr                       ; //Dump
reg [0:0]                      r_demux_dump_rden                       ;
always@(posedge i_clk) begin
    if(r_lphy_wren||r_lphy_rden) begin
        case(r_lphy_addr[(CPUIF_TOP_ADDR_BW-1)-:BW_ADDR_HEAD]) 
            CC00_ADDR_OFFSET                    :   begin r_demux_core_addr[CC00_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC00_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC00_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC00_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC01_ADDR_OFFSET                    :   begin r_demux_core_addr[CC01_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC01_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC01_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC01_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC02_ADDR_OFFSET                    :   begin r_demux_core_addr[CC02_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC02_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC02_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC02_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC03_ADDR_OFFSET                    :   begin r_demux_core_addr[CC03_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC03_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC03_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC03_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC04_ADDR_OFFSET                    :   begin r_demux_core_addr[CC04_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC04_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC04_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC04_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC05_ADDR_OFFSET                    :   begin r_demux_core_addr[CC05_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC05_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC05_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC05_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC06_ADDR_OFFSET                    :   begin r_demux_core_addr[CC06_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC06_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC06_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC06_DEMUX_INDEX] <= r_lphy_wdata ; end 
            CC07_ADDR_OFFSET                    :   begin r_demux_core_addr[CC07_DEMUX_INDEX] <= {{{CPUIF_LPHY_ADDR_BW-CPUIF_LPHY_CC_ADDR_BW}{1'd0}},r_lphy_addr[CPUIF_LPHY_CC_ADDR_BW-1:0]} ; r_demux_core_wren[CC07_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[CC07_DEMUX_INDEX] <= r_lphy_rden ; r_demux_core_wdata[CC07_DEMUX_INDEX] <= r_lphy_wdata ; end 
            DUMP0_ADDR_OFFSET,DUMP1_ADDR_OFFSET :   begin r_demux_core_addr[DUMP_DEMUX_INDEX] <= (r_lphy_addr-DUMP_BASE_ADDR)>>2; r_demux_core_wren[DUMP_DEMUX_INDEX] <= r_lphy_wren ; r_demux_core_rden[DUMP_DEMUX_INDEX] <= r_lphy_rden ; end 
            default                             :   for(i=0;i<NUM_CC+1;i=i+1) begin r_demux_core_wren [i] <= 1'd0 ; r_demux_core_rden [i] <= 1'd0 ; end 
        endcase
    end
    else begin
        for(i=0;i<NUM_CC+1;i=i+1) begin r_demux_core_wren [i] <= 1'd0 ; r_demux_core_rden [i] <= 1'd0 ; end
    end
end

wire [CPUIF_DATA_BW-1:0] w_cc_core_rdata     [NUM_CC-1:0]   ;
wire [01-1:0]            w_cc_core_rd_valid  [NUM_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin
assign  o_core_addr     [((CPUIF_LPHY_ADDR_BW   )*(gidx+1)-1)-:(CPUIF_LPHY_ADDR_BW  )]   =   r_demux_core_addr [gidx][CPUIF_LPHY_ADDR_BW-1:0]  ;
assign  o_core_wren     [((01                   )*(gidx+1)-1)-:(01                  )]   =   r_demux_core_wren [gidx]  ;
assign  o_core_wdata    [((CPUIF_DATA_BW        )*(gidx+1)-1)-:(CPUIF_DATA_BW       )]   =   r_demux_core_wdata[gidx]  ;
assign  o_core_rden     [((01                   )*(gidx+1)-1)-:(01                  )]   =   r_demux_core_rden [gidx]  ;
assign  w_cc_core_rdata     [gidx]  =   i_core_rdata        [((CPUIF_DATA_BW )*(gidx+1)-1)-:(CPUIF_DATA_BW )]   ;
assign  w_cc_core_rd_valid  [gidx]  =   i_core_rd_valid     [((01            )*(gidx+1)-1)-:(01            )]   ;
end
endgenerate

//sync existence mon
reg [NUM_CC-1:0] r_dl_sync_exist ;
reg [NUM_CC-1:0] r_ul_sync_exist ;
reg [NUM_CC-1:0] r_nb_sync_exist ;
reg [NUM_CC-1:0] r_mt_sync_exist ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin
always@(posedge i_clk) begin
    if(i_din_fsync[gidx]) begin
        r_dl_sync_exist[gidx] <=  1'd1 ;
    end
    else if(r_lphy_rden&&r_lphy_addr==LPHY_TOP_BASE_ADDR+16'h0004) begin
        r_dl_sync_exist[gidx] <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(i_uin_fsync[gidx]) begin
        r_ul_sync_exist[gidx] <=  1'd1 ;
    end
    else if(r_lphy_rden&&r_lphy_addr==LPHY_TOP_BASE_ADDR+16'h0004) begin
        r_ul_sync_exist[gidx] <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(i_nin_fsync[gidx]) begin
        r_nb_sync_exist[gidx] <=  1'd1 ;
    end
    else if(r_lphy_rden&&r_lphy_addr==LPHY_TOP_BASE_ADDR+16'h0004) begin
        r_nb_sync_exist[gidx] <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(i_min_fsync[gidx]) begin
        r_mt_sync_exist[gidx] <=  1'd1 ;
    end
    else if(r_lphy_rden&&r_lphy_addr==LPHY_TOP_BASE_ADDR+16'h0004) begin
        r_mt_sync_exist[gidx] <=  1'd0 ;
    end
end
end
endgenerate
always@(*) begin
    r_lphy_top_rpt_100004 = {16'h0,4'hf&r_mt_sync_exist,4'hf&r_nb_sync_exist,4'hf&r_ul_sync_exist,4'hf&r_dl_sync_exist} ;
end

//sig_cap
reg    [00:0]                   r_dump_en_map       ;
reg    [00:0]                   r_dump_wen_map      ;
reg    [00:0]                   r_dump_ren_map      ;
reg    [BW_DEPTH_DUMP-1:0]      r_dump_addr_map     ;
reg    [31:0]                   r_dump_wdata_map    ;
always@(posedge i_clk) begin
    if(i_dump_wr_en) begin
        r_dump_en_map       <=  i_dump_wr_en                        ;    
        r_dump_wen_map      <=  i_dump_wr_en                        ;    
        r_dump_ren_map      <=  1'd0                                ;    
        r_dump_addr_map     <=  i_dump_wr_addr[BW_DEPTH_DUMP-1:0]   ;    
        r_dump_wdata_map    <=  i_dump_wr_data                      ;    
    end  
    else if(r_demux_core_rden[DUMP_DEMUX_INDEX]) begin
        r_dump_en_map       <=  r_demux_core_rden[DUMP_DEMUX_INDEX] ;   
        r_dump_wen_map      <=  1'd0              ;    
        r_dump_ren_map      <=  r_demux_core_rden[DUMP_DEMUX_INDEX] ;   
        r_dump_addr_map     <=  r_demux_core_addr[DUMP_DEMUX_INDEX][BW_DEPTH_DUMP-1:0] ;    
    end
    else begin
        r_dump_en_map       <=  1'd0            ;    
        r_dump_wen_map      <=  1'd0            ;    
        r_dump_ren_map      <=  1'd0            ;    
    end
end                              

wire [31:0] w_dump_rdata ;
ylib_rams_sp_wf #(
     .WIDTH      (   32             )
    ,.DEPTH      (   DEPTH_DUMP     )
    ,.VENDOR     (   VENDOR         ))
u01_zip_sig_dump_mem 
(
    .clk    (i_clk                      )
   ,.we     (r_dump_wen_map             )
   ,.en     (r_dump_en_map              )
   ,.addr   (r_dump_addr_map            )
   ,.di     (r_dump_wdata_map           )   
   ,.dout   (w_dump_rdata               )
);

reg [0:0]   r_mux_dump_rd_en    [DLY_REG_RD_DUMP-1:0]   ;
reg [31:0]  r_mux_dump_rd_data  [0:0]                   ;
always@(posedge i_clk) begin
    r_mux_dump_rd_en[0]  <=  r_dump_ren_map ;    
end                              
always@(*) begin
    r_mux_dump_rd_data[0] <= w_dump_rdata  ;
end
always@(posedge i_clk) begin
    for(i=1;i<DLY_REG_RD_DUMP;i=i+1) begin 
        r_mux_dump_rd_en[i]  <=  r_mux_dump_rd_en[i-1]    ;    
    end
end                               

//lphy_top parameter wr demux
reg [04-1:0] r_lphy_top_par_100200 ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_lphy_top_par_100200 <= 4'd8 ;
    end
    else if(r_lphy_wren) begin
        case(r_lphy_addr)
            LPHY_TOP_BASE_ADDR+16'h0008 :   o_lphy_top_par_100008   <=  r_lphy_wdata[01-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0010 :   r_lphy_top_par_1000n0_ul_retard  [((22)*(0+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0020 :   r_lphy_top_par_1000n0_ul_retard  [((22)*(1+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0030 :   r_lphy_top_par_1000n0_ul_retard  [((22)*(2+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0040 :   r_lphy_top_par_1000n0_ul_retard  [((22)*(3+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
`ifndef NBIOT_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0110 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(0+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0120 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(1+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0130 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(2+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0140 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(3+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0150 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(4+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0160 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(5+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0170 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(6+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0180 :   r_lphy_top_par_1000n0_nb_retard  [((22)*(7+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0210 :   r_lphy_top_par_1000n0_mt_retard  [((22)*(0+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0220 :   r_lphy_top_par_1000n0_mt_retard  [((22)*(1+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0230 :   r_lphy_top_par_1000n0_mt_retard  [((22)*(2+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
            LPHY_TOP_BASE_ADDR+16'h0240 :   r_lphy_top_par_1000n0_mt_retard  [((22)*(3+1)-1)-:(22)]   <=  r_lphy_wdata[22-1:0]    ;
`endif//EMTC_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0200 :   r_lphy_top_par_100200   <=  r_lphy_wdata[04-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0000 :   o_sigcap_par_180000     <=  r_lphy_wdata[01-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0004 :   o_sigcap_par_180004     <=  r_lphy_wdata[$clog2(NUM_CC)-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0008 :   o_sigcap_par_180008     <=  r_lphy_wdata[$clog2(NUM_PATH)-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h000c :   o_sigcap_par_18000c     <=  r_lphy_wdata[12-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0010 :   o_sigcap_par_180010     <=  r_lphy_wdata[04-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0014 :   o_sigcap_par_180014     <=  r_lphy_wdata[08-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0018 :   o_sigcap_par_180018     <=  r_lphy_wdata[04-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h001c :   o_sigcap_par_18001c     <=  r_lphy_wdata[$clog2(NUM_DUMP_ITEM)-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0020 :   o_sigcap_par_180020     <=  r_lphy_wdata[03-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0024 :   o_sigcap_par_180024     <=  r_lphy_wdata[04-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h0028 :   o_sigcap_par_180028     <=  r_lphy_wdata[03-1:0]    ;
            SIGCAP_BASE_ADDR  +16'h002c :   o_sigcap_par_18002c     <=  r_lphy_wdata[32-1:0]    ;
        endcase                                                      
    end                                                               
end                                                                   

//lphy_top parameter rd mux
reg [0:0]   r_par_rd_en    [DLY_REG_RD-1:0]  ;
reg [31:0]  r_par_rd_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(r_lphy_rden) begin
        case(r_lphy_addr)
            LPHY_TOP_BASE_ADDR+16'h0000 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},P4V_VERSION          }   ; end 
            LPHY_TOP_BASE_ADDR+16'h0004 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_100004}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0008 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(01-1+1)}{1'd0}},o_lphy_top_par_100008}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0010 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_ul_retard  [((22)*(0+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0014 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n4_dl_proc_dly[((32)*(0+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0018 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n8_ul_proc_dly[((32)*(0+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h001c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_ra_proc_dly[((32)*(0+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0020 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_ul_retard  [((22)*(1+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0024 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n4_dl_proc_dly[((32)*(1+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0028 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n8_ul_proc_dly[((32)*(1+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h002c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_ra_proc_dly[((32)*(1+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0030 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_ul_retard  [((22)*(2+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0034 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n4_dl_proc_dly[((32)*(2+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0038 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n8_ul_proc_dly[((32)*(2+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h003c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_ra_proc_dly[((32)*(2+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0040 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_ul_retard  [((22)*(3+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0044 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n4_dl_proc_dly[((32)*(3+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0048 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000n8_ul_proc_dly[((32)*(3+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h004c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_ra_proc_dly[((32)*(3+1)-1)-:(32)]}   ; end 
`ifndef NBIOT_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0110 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(0+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h011c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(0+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0120 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(1+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h012c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(1+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0130 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(2+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h013c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(2+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0140 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(3+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h014c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(3+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0150 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(4+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h015c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(4+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0160 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(5+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h016c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(5+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0170 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(6+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h017c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(6+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0180 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_nb_retard  [((22)*(7+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h018c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_nb_proc_dly[((32)*(7+1)-1)-:(32)]}   ; end 
`endif//NBIOT_CORE_DISABLE
`ifndef EMTC_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0210 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_mt_retard  [((22)*(0+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h021c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_mt_proc_dly[((32)*(0+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0220 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_mt_retard  [((22)*(1+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h022c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_mt_proc_dly[((32)*(1+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0230 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_mt_retard  [((22)*(2+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h023c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_mt_proc_dly[((32)*(2+1)-1)-:(32)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h0240 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},r_lphy_top_par_1000n0_mt_retard  [((22)*(3+1)-1)-:(22)]}   ; end 
            LPHY_TOP_BASE_ADDR+16'h024c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},r_lphy_top_rpt_1000nc_mt_proc_dly[((32)*(3+1)-1)-:(32)]}   ; end 
`endif//EMTC_CORE_DISABLE
            LPHY_TOP_BASE_ADDR+16'h0200 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},r_lphy_top_par_100200}   ; end 
            SIGCAP_BASE_ADDR  +16'h0000 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(01-1+1)}{1'd0}},o_sigcap_par_180000  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0004 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-($clog2(NUM_CC)-1+1)}{1'd0}},o_sigcap_par_180004  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0008 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-($clog2(NUM_PATH)-1+1)}{1'd0}},o_sigcap_par_180008  }   ; end 
            SIGCAP_BASE_ADDR  +16'h000c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(12-1+1)}{1'd0}},o_sigcap_par_18000c  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0010 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},o_sigcap_par_180010  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0014 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(08-1+1)}{1'd0}},o_sigcap_par_180014  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0018 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},o_sigcap_par_180018  }   ; end 
            SIGCAP_BASE_ADDR  +16'h001c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-($clog2(NUM_DUMP_ITEM)-1+1)}{1'd0}},o_sigcap_par_18001c  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0020 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_180020  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0024 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},o_sigcap_par_180024  }   ; end 
            SIGCAP_BASE_ADDR  +16'h0028 :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_180028  }   ; end 
            SIGCAP_BASE_ADDR  +16'h002c :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},o_sigcap_par_18002c  }   ; end 
            default                     :   begin r_par_rd_en[0] <= 1'd0; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},32'd0                }   ; end 
        endcase
    end
    else begin
        r_par_rd_en[0] <= 1'd0;
    end
end                                                                   
always@(posedge i_clk) begin
    for(i=1;i<DLY_REG_RD;i=i+1) begin 
        r_par_rd_en [i]  <=  r_par_rd_en [i-1]  ;    
        if(r_par_rd_en[i-1]) begin
            r_par_rd_data  [i]  <=  r_par_rd_data  [i-1]  ;    
        end  
    end
end

reg [CPUIF_DATA_BW-1:0]    r_mux_rdata              ; 
reg [0:0]                  r_mux_rd_valid           ;
reg [CPUIF_DATA_BW-1:0]    r_dump_mem_rdata         ; 
reg [0:0]                  r_dump_mem_rd_valid      ;
always@(*) begin
    r_dump_mem_rdata    = r_mux_dump_rd_data[0]               ;
    r_dump_mem_rd_valid = r_mux_dump_rd_en[DLY_REG_RD_DUMP-1] ;
end

wire [0:0]   w_core_rd_init    ;
ylib_reg #(
     .WIDTH     (    1          ) 
    ,.DEPTH     (    10         )) 
u02_rd_init_dly
(
     .i_clk      ( i_clk                                    )
    ,.i_in       ( ~rr_cpu2lphy_rden & rrr_cpu2lphy_rden    )
    ,.o_out      ( w_core_rd_init                           )
);
always@(posedge i_clk) begin
    if     (w_cc_core_rd_valid[CC00_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC00_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC00_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC01_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC01_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC01_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC02_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC02_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC02_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC03_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC03_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC03_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC04_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC04_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC04_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC05_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC05_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC05_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC06_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC06_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC06_DEMUX_INDEX] ; end 
    else if(w_cc_core_rd_valid[CC07_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC07_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC07_DEMUX_INDEX] ; end 
    else if(r_dump_mem_rd_valid)                    begin r_mux_rdata <= r_dump_mem_rdata                   ; r_mux_rd_valid <= r_dump_mem_rd_valid                  ; end 
    else if(r_par_rd_en[DLY_REG_RD-1])              begin r_mux_rdata <= r_par_rd_data[DLY_REG_RD-1]        ; r_mux_rd_valid <= r_par_rd_en[DLY_REG_RD-1]            ; end
    else if(w_core_rd_init)                         begin r_mux_rdata <= 32'd0 ; end
    else begin r_mux_rd_valid <= 1'd0 ; end
end

reg [CPUIF_DATA_BW-1:0]    rr_cpu_mux_rdata         ; 
always@(posedge i_cpu_clk) begin
    rr_cpu_mux_rdata    <=  r_mux_rdata             ; 
    o_cpu_rdata <=  rr_cpu_mux_rdata ; 
end

reg [0:0] r_cpu_rden ;
always@(posedge i_cpu_clk) begin
    r_cpu_rden <= i_cpu_rden ;
end

ylib_pshift #(
     .BW_SHIFT  (   4   ))
u03_rd_valid_dly
(
    .i_clk       ( i_cpu_clk                )
   ,.i_shift     ( r_lphy_top_par_100200    )
   ,.i_in        ( i_cpu_rden&~r_cpu_rden   )
   ,.o_out       ( o_cpu_rd_valid           )
);

endmodule
