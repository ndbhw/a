////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : 
//  Module       : 
//  Author       : 
//  Description  : ulfe_cc Configuration header
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//              |               |                            
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

//Product : RF4440d_TYPE1_P


`define ULFE_ORAN       
//`define UL_NUM_ANT_8  
//// 8t8r
`define Custom_FFT
`define MAX_FFT_ULFE 1024 
////1024 2048 4096
`define MAX_SCS_u_ULFE 0 
//// 0 1 
//`define SCS0_u_ULFE_disable 
`define SCS1_u_ULFE_disable 
`define SCS2_u_ULFE_disable 
//`define ULFE_AIE_8RX_4CHAIN
//// versal
//`define ULFE_CAL

`define ULFE_LTE
//`define ULFE_Cp
//`define ULFE_DSS

//`define attr_type_intel
////FSU20
//`define TD_RSSI_disable
//`define FD_RSSI_disable
//`define ulfe_fdd

//`define ULFE_input_tvrom
//`define ULFE_AIE_ILADBG
//`define ULFE_inputctrl_ILADBG
//`define ULFE_outputctrl_ILADBG