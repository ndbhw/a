// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

module ulfe_cpu_param_post_proc(
    input i_clk
    ,input i_rst

    ,input [32-1:0]              i_par_rbsize
    ,input  [2-1:0]              i_par_scstype
,output [4-1:0]              o_bw_type  //for BBIF and so on
,output [4-1:0]              o_fs_type  // 0-7.68MHz , 1-15.36MHz , 2-30.72MHz , 3-61.44MHz , 4-122.88MHz
,output [6-1:0]              o_osr      // (operationg clock / sampling clock) ratio
,output [3-1:0]              o_osr_quotient
//    input [15:0]                i_par_mpfrmstruct_fftsize,
//    output [1:0]                o_fft_type

);

    reg [4-1:0]             r_bw_type;  //5mhz-0, 10mhz-1, 15mhz-2, 20mhz-3

//    always @(posedge i_clk)
//    begin
//        case(i_par_rbsize[8:0])
//            9'd25: begin
//                r_bw_type <= 4'd0;
//            end
//            9'd52 : begin
//                r_bw_type <= 4'd1;
//            end
//            9'd79 : begin
//                r_bw_type <= 4'd2;
//            end
//            9'd106 : begin
//                r_bw_type <= 4'd3;
//            end
//            default : begin
//                r_bw_type <= 4'd0;
//            end
//        endcase
//    end

//    assign o_bw_type = r_bw_type;




    reg [4-1:0]             r_fs_type; // 0-7.68MHz , 1-15.36MHz , 2-30.72MHz , 3-61.44MHz , 4-122.88MHz
    reg [6-1:0]             r_osr; //over sampling ratio , operating clock = 245.76MHz
    reg [3-1:0]             r_osr_quotient;    
        
    always @(posedge i_clk)
    begin
        case({i_par_scstype , i_par_rbsize[8:0]})
            {2'd0,9'd15} : begin
                    r_fs_type   <= 4'd0;
                    r_osr       <= 6'd32;
                    r_osr_quotient<= 3'd5;
                    r_bw_type   <= 4'd0;
                    end
        
            {2'd0,9'd25} : begin
                            r_fs_type   <= 4'd0;
                            r_osr       <= 6'd32;
                            r_osr_quotient<= 3'd5;
                            r_bw_type   <= 4'd0;
                            end
//            {2'd0,9'b0_0011_0???} : begin
//                            r_fs_type   <= 4'd1;
//                            r_osr       <= 6'd16;
//                            r_osr_quotient<= 3'd4;
//                            end
            {2'd0,9'd50} : begin
                            r_fs_type   <= 4'd1;
                            r_osr       <= 6'd16;
                            r_osr_quotient<= 3'd4;
                            r_bw_type   <= 4'd1;
                            end
            {2'd0,9'd52} : begin
                            r_fs_type   <= 4'd1;
                            r_osr       <= 6'd16;
                            r_osr_quotient<= 3'd4;
                            r_bw_type   <= 4'd1;
                            end
//            {2'd0,9'b0_0100_1???} : begin
//                            r_fs_type   <= 4'd2;
//                            r_osr       <= 6'd8;
//                            r_osr_quotient<= 3'd3;
//                            end
            {2'd0,9'd75} : begin
                            r_fs_type   <= 4'd2;
                            r_osr       <= 6'd8;
                            r_osr_quotient<= 3'd3;
                            r_bw_type   <= 4'd2;
                            end
            {2'd0,9'd79} : begin
                            r_fs_type   <= 4'd2;
                            r_osr       <= 6'd8;
                            r_osr_quotient<= 3'd3;
                            r_bw_type   <= 4'd2;
                            end
//            {2'd0,9'b0_0110_????} : begin
//                            r_fs_type   <= 4'd2;
//                            r_osr       <= 6'd8;
//                            r_osr_quotient<= 3'd3;
//                            end
            {2'd0,9'd100} : begin
                            r_fs_type   <= 4'd2;
                            r_osr       <= 6'd8;
                            r_osr_quotient<= 3'd3;
                            r_bw_type   <= 4'd3;
                            end
            {2'd0,9'd106} : begin
                            r_fs_type   <= 4'd2;
                            r_osr       <= 6'd8;
                            r_osr_quotient<= 3'd3;
                            r_bw_type   <= 4'd3;
                            end
            {2'd1,9'd51} : begin
                            r_fs_type   <= 4'd2;
                            r_osr       <= 6'd8;
                            r_osr_quotient<= 3'd3;
                            r_bw_type   <= 4'd15;
                            end
            {2'd1,9'd106} : begin
                            r_fs_type   <= 4'd3;
                            r_osr       <= 6'd4;
                            r_osr_quotient<= 3'd2;
                            r_bw_type   <= 4'd15;
                            end
            {2'd1,9'd162} : begin
                            r_fs_type   <= 4'd4;
                            r_osr       <= 6'd2;
                            r_osr_quotient<= 3'd1;
                            r_bw_type   <= 4'd15;
                            end
            {2'd1,9'd217} : begin
                            r_fs_type   <= 4'd4;
                            r_osr       <= 6'd2;
                            r_osr_quotient<= 3'd1;
                            r_bw_type   <= 4'd15;
                            end
            {2'd1,9'd273} : begin
                            r_fs_type   <= 4'd4;
                            r_osr       <= 6'd2;
                            r_osr_quotient<= 3'd1;
                            r_bw_type   <= 4'd15;
                            end
            default       : begin
                            r_fs_type   <= 4'd4;
                            r_osr       <= 6'd2;
                            r_osr_quotient<= 3'd1;
                            r_bw_type   <= 4'd0;
                            end
        endcase
    end    

    assign o_fs_type    = r_fs_type;
    assign o_osr        = r_osr;
    assign o_osr_quotient = r_osr_quotient;
    assign o_bw_type    = r_bw_type;

//
//
//    reg [2-1:0]             r_fft_type;
//
//    always @(posedge i_clk)
//    begin
//        case(i_par_mpfrmstruct_fftsize[3:0])
//            4'd9    : r_fft_type<=2'd0;
//            4'd10   : r_fft_type<=2'd1;
//            4'd11   : r_fft_type<=2'd2;
//            4'd12   : r_fft_type<=2'd3;
//            default : r_fft_type<=2'd0;
//        endcase
//    end
//    
//    assign o_fft_type = r_fft_type;


endmodule
