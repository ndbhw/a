// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ORAN RU/MISC
//  Module       : ulfe_input_ctrl
//  Author       : dg0110.jo@samsung.com
//  Description  : ulfe input control for ORAN RU/MISC
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.   | Donggeun Jo   | Update achitecture : add num_chain
//  ------------+---------------+-----------------------------------------------
//   2020.07.   | Donggeun Jo   | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////
`include "ulfe_cc.vh"

module ulfe_input_ctrl
#(
     parameter  NUM_ANT             =   4 
    ,parameter  NUM_CHAIN           =   2 //NUM_ANT/OVS     
    ,parameter  TOP_DIO_BW          =   16
//    ,parameter  DLY_REG_RD          =   7
//    ,parameter  ADDR_OFFSET         =   16'h5000
//    ,parameter  OVS                 =   2
    
)(
     input i_clk
    ,input i_rst

    ,input      [0:0]                               i_uin_frame_sync
    ,input      [NUM_ANT-1:0]                       i_uin_en
    ,input      [2*NUM_ANT*TOP_DIO_BW-1:0]          i_uin_iq
,output     [0:0]                               o_uin_frame_sync
,output     [NUM_ANT-1:0]                       o_uin_en
,output     [2*NUM_CHAIN*TOP_DIO_BW-1:0]        o_uin_iq

`ifdef ULFE_SRS
    ,input   [3:0]                              i_cp_symbol_idx
    ,input                                      i_srs_sym_flag
,output                                         o_srs_sym_flag
    ,input                                      i_dl_start_tick
,output                                         o_dl_start_tick
`endif

    ,input                                          tp_on //0:normal , 1:tp on
    ,input      [3:0]                               tp_mode //01:test pattern #0 , 10:test pattern #1
    ,input      [2-1:0]                             sig_ctrl_mode //00:normal   , 01:block  , 10:iq swap
    ,input      [1:0]                               i_scstype
    ,input      [4-1:0]                             i_fs_type
    ,input      [8-1:0]                             i_osr
,output     [32*NUM_ANT-1:0]                    o_xssi  

    ,input      [31:0]                              i_frm_chk_gap                 
,output     [15:0]                              o_inout_frm_syncfail_count    
,output     [31:0]                              o_inputsync_time_stamp    


);

localparam OSR = (NUM_ANT / NUM_CHAIN);
localparam dly_st0 = 1; //latch
localparam dly_st1 = 1; //tp
localparam dly_st2 = 2; //swap

genvar i, j, gcore;
integer k;

reg     [1-1:0]                         r_uin_frame_sync            ;
reg     [NUM_ANT-1:0]                   r_uin_en                    ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      r_uin_iq                    ;

reg     [1-1:0]                         r_vld_frame_sync            ;
reg     [NUM_ANT-1:0]                   r_vld_en                    ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      r_vld_iq                    ;

reg     [1-1:0]                         tt_tp_frame_sync            ;
reg     [NUM_ANT-1:0]                   tt_tp_en                    ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      tt_tp_iq                    ;
reg     [1-1:0]                         t_tp_frame_sync             ;
reg     [NUM_ANT-1:0]                   t_tp_en                     ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      t_tp_iq                     ;
reg     [TOP_DIO_BW-1:0]                t_tp_i                      ;
reg     [TOP_DIO_BW-1:0]                t_tp_q                      ;
reg     [8-1:0]                         t_cnt_osr                   ;        
reg     [1-1:0]                         r_tp_frame_sync             ;
reg     [NUM_ANT-1:0]                   r_tp_en                     ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      r_tp_iq                     ;

reg     [1-1:0]                         t_frame_sync                ;
reg     [NUM_ANT-1:0]                   t_iq_swap_en                ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      t_iq_swap_iq                ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      t_iq_ori_iq                 ;

reg     [1-1:0]                         r_frame_sync                ;
reg     [NUM_ANT-1:0]                   r_iq_swap_en                ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      r_iq_swap_iq                ;

wire    [NUM_ANT-1:0]                       w_inte_leav_frame_sync;
wire    [NUM_ANT-1:0]                       w_inte_leav_iq_en   ;
wire    [2*NUM_CHAIN*TOP_DIO_BW-1:0]        w_inte_leav_iq      ;

wire    [NUM_ANT-1:0]                       w_xssi_en                   ;
wire    [32-1:0]                            w_xssi  [NUM_ANT-1:0]       ;
reg     [32-1:0]                            r_xssi  [NUM_ANT-1:0]       ;

reg     [8-1:0]                         r_osr;

///srs

///dbg
wire                w_slot_sync_input       ;
wire                w_sym_sync_input        ;
wire    [3:0]       w_subfrm_idx_input      ;                     
wire    [7:0]       w_slot_idx_input        ;         
wire    [3:0]       w_symbol_idx_input      ;      
wire    [63:0]      w_dat_ulfe_input_tvrom  ;

    //wire                                        w_slot_sync_tvinput         ;
//wire                                        w_sym_sync_tvinput          ;
//stage 0 : 1clk

reg [21:0]  cnt_245mh76_10ms_tp;
reg         r_10ms_sync_tp;

always @(posedge i_clk)
begin
    if(!tp_mode[3])
    begin
        cnt_245mh76_10ms_tp <= 22'd0;
        r_10ms_sync_tp      <=  1'b0;
    end
    else if(cnt_245mh76_10ms_tp == 22'd2457600-22'd1)
    begin
        cnt_245mh76_10ms_tp <= 22'd0;
        r_10ms_sync_tp      <=  1'b0;
    end         
    else if(cnt_245mh76_10ms_tp == 22'd1)
    begin
        cnt_245mh76_10ms_tp <= cnt_245mh76_10ms_tp + 22'd1;
        r_10ms_sync_tp      <=  1'b1;
    end         
    else
    begin
        cnt_245mh76_10ms_tp <= cnt_245mh76_10ms_tp + 22'd1;
        r_10ms_sync_tp      <=  1'b0;
    end
end

always @(posedge i_clk) begin
    if(tp_mode[3])
        r_uin_frame_sync    <=  r_10ms_sync_tp;
    else
        r_uin_frame_sync    <=  i_uin_frame_sync;
    
    r_uin_en    <=  i_uin_en;
    r_uin_iq    <=  i_uin_iq;
end

//stage 1 : 2clk
always @(posedge i_clk) begin
    r_vld_frame_sync        <=  r_uin_frame_sync;
    if(tp_mode[2]) begin
        if(r_vld_frame_sync) 
            r_vld_en        <=  {NUM_ANT{1'b1}} ;
    end
    else begin
            r_vld_en        <=  r_uin_en        ;
    end
    r_vld_iq                <=  r_uin_iq        ;
end
always @(posedge i_clk) begin
    tt_tp_frame_sync    <=  r_vld_frame_sync    ;
    tt_tp_en            <=  r_vld_en            ;
    tt_tp_iq            <=  r_vld_iq            ;
    t_tp_frame_sync     <=  tt_tp_frame_sync    ;
    t_tp_en             <=  tt_tp_en            ;
    t_tp_iq             <=  tt_tp_iq            ;
end



always @(posedge i_clk) begin
    if(tt_tp_frame_sync) 
    begin
        t_tp_i      <= {{2'b00},{(TOP_DIO_BW-2){1'b0}}};
        t_tp_q      <= {{2'b11},{(TOP_DIO_BW-2){1'b0}}};
        t_cnt_osr   <=  8'd0;
    end
    else if(t_cnt_osr == r_osr)
    begin
        t_tp_i[TOP_DIO_BW-1:TOP_DIO_BW-1-1] <= 2'b00;
        t_tp_q[TOP_DIO_BW-1:TOP_DIO_BW-1-1] <= 2'b11;
        t_tp_i[TOP_DIO_BW-1-2:0] <= t_tp_i[TOP_DIO_BW-1-2:0] + {{(TOP_DIO_BW-1-2){1'b0}},1'd1};
        t_tp_q[TOP_DIO_BW-1-2:0] <= t_tp_q[TOP_DIO_BW-1-2:0] + {{(TOP_DIO_BW-1-2){1'b0}},1'd1};
        t_cnt_osr   <=  8'd1;
    end
    else 
    begin
//        t_tp_i[TOP_DIO_BW-1:TOP_DIO_BW-1-1] <= 2'b00;
//        t_tp_q[TOP_DIO_BW-1:TOP_DIO_BW-1-1] <= 2'b11;
//        t_tp_i[TOP_DIO_BW-1-2:0] <= t_tp_i[TOP_DIO_BW-1-2:0] + {{(TOP_DIO_BW-1-2){1'b0}},1'd1};
//        t_tp_q[TOP_DIO_BW-1-2:0] <= t_tp_q[TOP_DIO_BW-1-2:0] + {{(TOP_DIO_BW-1-2){1'b0}},1'd1};
        t_tp_i  <=  t_tp_i;
        t_tp_q  <=  t_tp_q;
        t_cnt_osr   <=  t_cnt_osr + 8'd1;
    end
end


always @(posedge i_clk) begin
    if(tp_mode[1:0]==2'b01)
        begin
            r_tp_frame_sync     <=  t_tp_frame_sync;
//            if(r_tp_frame_sync)
            r_tp_en             <=  t_tp_en;//{NUM_ANT{1'b1}}         ;
            r_tp_iq             <=  {NUM_ANT{t_tp_i,t_tp_q}};
        end
    else if(tp_mode[1:0]==2'b10)
        begin
            r_tp_frame_sync     <=  t_tp_frame_sync;
//            if(r_tp_frame_sync)
            r_tp_en             <=  t_tp_en;//{NUM_ANT{1'b1}}         ;
            r_tp_iq             <=  {NUM_ANT{t_tp_i,t_tp_i}};
        end
    else if(tp_mode[1:0]==2'b11)
        begin
            r_tp_frame_sync     <=  t_tp_frame_sync;
//            if(r_tp_frame_sync)
            r_tp_en             <=  t_tp_en;//{NUM_ANT{1'b1}}         ;
            r_tp_iq             <=  {NUM_ANT{w_dat_ulfe_input_tvrom[63:32]}} ;//
        end
    else
        begin
            r_tp_frame_sync     <=  t_tp_frame_sync;
            r_tp_en             <=  t_tp_en        ;
            r_tp_iq             <=  t_tp_iq        ;
        end
end

always @(posedge i_clk) begin
    t_frame_sync        <=  r_tp_frame_sync;
    t_iq_swap_en        <=  r_tp_en;

    for(k=0 ; k<NUM_ANT ; k=k+1)
    begin
//        t_iq_swap_iq[TOP_DIO_BW*2*(k+1)-1:TOP_DIO_BW*2*k] <=   {r_tp_iq[TOP_DIO_BW*(2*k)+16-1:TOP_DIO_BW*2*k], r_tp_iq[TOP_DIO_BW*2*(k+1)-1:TOP_DIO_BW*(2*k+1)]};
        t_iq_swap_iq[TOP_DIO_BW*2*(k+1)-1 -: TOP_DIO_BW*2] <=   {r_tp_iq[TOP_DIO_BW*(2*k)+16-1 -: TOP_DIO_BW], r_tp_iq[TOP_DIO_BW*2*(k+1)-1 -: TOP_DIO_BW]};
    end
     t_iq_ori_iq <= r_tp_iq;
 end


always @(posedge i_clk) begin
    if(sig_ctrl_mode == 2'd2) begin
        r_frame_sync    <= t_frame_sync ;
        r_iq_swap_en    <= t_iq_swap_en ;
        r_iq_swap_iq    <= t_iq_swap_iq ;
    end
    else if(sig_ctrl_mode == 2'd1) begin
        r_frame_sync    <= t_frame_sync ;
        r_iq_swap_en    <= t_iq_swap_en ;
        r_iq_swap_iq    <= 0 ;
    end
//    else if(sig_ctrl_mode == 2'd3) begin
//        r_frame_sync    <= t_frame_sync ;
//        if(r_frame_sync)
//            r_iq_swap_en    <= t_iq_swap_en;//{NUM_ANT{1'b1}} ;
//        r_iq_swap_iq    <= {NUM_ANT{w_dat_ulfe_input_tvrom[63:32]}} ;
//    end
    else begin
        r_frame_sync    <= t_frame_sync ;
        r_iq_swap_en    <= t_iq_swap_en ;
        r_iq_swap_iq    <= t_iq_ori_iq  ;
    end
end


always @(posedge i_clk) begin
    r_osr <= i_osr;
end
    

generate for(gcore=0 ; gcore<NUM_CHAIN ; gcore=gcore+1 ) begin : g_ulfe_pre_processing_core

    // input interleaving
ylib_inter_leav
#(
.WIDTH      (   TOP_DIO_BW          )
,.NUM_ANT   (   NUM_ANT/NUM_CHAIN   )
,.DLY       (    1                  )
//    ,.OFFSET    (    0                  )
)
u_ylib_inter_leav
(
    .i_clk      ( i_clk                 )
    ,.i_sync    ( r_frame_sync          )
    ,.i_ratio   ( r_osr                 )
    ,.i_en      ( r_iq_swap_en[(gcore+1)*OSR-1:gcore*OSR]          )
    ,.i_in      ( r_iq_swap_iq[(gcore+1)*OSR*2*TOP_DIO_BW-1:gcore*OSR*2*TOP_DIO_BW]          )
    ,.o_sync    ( w_inte_leav_frame_sync[gcore])
    ,.o_vld     ( w_inte_leav_iq_en[(gcore+1)*OSR-1:gcore*OSR]     )
    ,.o_out     ( w_inte_leav_iq[(gcore+1)*2*TOP_DIO_BW-1:gcore*2*TOP_DIO_BW]        )
);
end
endgenerate

assign o_uin_frame_sync     = w_inte_leav_frame_sync[0];    
assign o_uin_en             = w_inte_leav_iq_en;
assign o_uin_iq             = w_inte_leav_iq;


reg [5:0]   r_rssi_ant_cnt;
always @(posedge i_clk)
begin
    if(i_rst)
    begin
        r_rssi_ant_cnt  <=  6'd0;
    end
    else if(w_inte_leav_frame_sync[0])
    begin
        if(r_rssi_ant_cnt == NUM_ANT[5:0]-6'd1)
            r_rssi_ant_cnt  <=  6'd0;
        else
            r_rssi_ant_cnt  <=  r_rssi_ant_cnt + 6'd0;
    end
    else
    begin
            r_rssi_ant_cnt  <=  r_rssi_ant_cnt;
    end
end

reg    [1-1:0]                       r_rssi_iq_en   ;
reg    [2*1*TOP_DIO_BW-1:0]          r_rssi_iq      ;

//always @(posedge i_clk)
//begin
//    case(r_rssi_ant_cnt)
//        3'd0 : 
//        3'd1 : 
//        3'd2 : 
//        3'd3 :
//        3'd4 :
//        3'
//    endcase
//end

`ifndef TD_RSSI_disable
generate for(i=0; i<NUM_ANT; i=i+1) 
//generate for(i=0; i<1; i=i+1) 
begin : input_rssi    
    ylib_xssi #(
        .NUM_FRAME(7'd1),
        .RPT_FRAME(7'd0),
        .BW_SIG(TOP_DIO_BW-1),
        .ID_XSSI(0)
    ) ylib_xssi_instance (
        .i_rst          (i_rst),
        .i_clk          (i_clk),
        .i_frame_sync   (w_inte_leav_frame_sync[0]),
        .i_sig_en       (w_inte_leav_iq_en[i]),
//        .i_sig_i        (w_inte_leav_iq[($floor(i/OSR)*2+2)*TOP_DIO_BW-2 : ($floor(i/OSR)*2+1)*TOP_DIO_BW]),
//        .i_sig_q        (w_inte_leav_iq[($floor(i/OSR)*2+1)*TOP_DIO_BW-2 : ($floor(i/OSR)*2)*TOP_DIO_BW]  ),
        .i_sig_i        (w_inte_leav_iq[((i/OSR)*2+2)*TOP_DIO_BW-2 : ((i/OSR)*2+1)*TOP_DIO_BW]),
        .i_sig_q        (w_inte_leav_iq[((i/OSR)*2+1)*TOP_DIO_BW-2 : ((i/OSR)*2)*TOP_DIO_BW]  ),
        .o_xssi_id      (),
        .o_xssi_en      (w_xssi_en[i]),
        .o_xssi         (w_xssi[i])
    );
end
endgenerate
`endif

always @(posedge i_clk) begin
    for(k=0 ; k<NUM_ANT ; k=k+1)
    if(w_xssi_en[k])
        r_xssi[k] <= w_xssi[k];
end


generate for (i=0 ; i<NUM_ANT ; i=i+1)
begin
    assign o_xssi[(i+1)*2*TOP_DIO_BW-1:(i)*2*TOP_DIO_BW] = r_xssi[i];
end
endgenerate



////DBG
reg [31:0] r_frm_chk_gap;
reg dbg_uin_frame_sync;

always @(posedge i_clk)
begin
    r_frm_chk_gap       <= i_frm_chk_gap;
    dbg_uin_frame_sync  <= i_uin_frame_sync;
end

reg [21:0] cnt_245mh76_10ms;
reg [15:0] syncfail_10ms_count;
reg [15:0] r_syncfail_10ms_count;

always @(posedge i_clk)
begin
    if(dbg_uin_frame_sync)
        cnt_245mh76_10ms <= 22'd0;
    else
        cnt_245mh76_10ms <= cnt_245mh76_10ms + 22'd1;    
end

always @(posedge i_clk)
begin
    if(i_rst)
        syncfail_10ms_count     <=  16'd0;
    else if(dbg_uin_frame_sync)
    begin
        if(cnt_245mh76_10ms >= 22'd2457600-22'd1-r_frm_chk_gap[21:0] && cnt_245mh76_10ms <= 22'd2457600-22'd1+r_frm_chk_gap[21:0] ) 
        begin       
            syncfail_10ms_count     <= syncfail_10ms_count;
        end
        else
        begin
            syncfail_10ms_count     <= syncfail_10ms_count + 16'd1;
        end
    end
    else         
    begin
        syncfail_10ms_count     <= syncfail_10ms_count;
    end
end

always @(posedge i_clk)
begin
    r_syncfail_10ms_count   <=  syncfail_10ms_count; 
end

assign o_inout_frm_syncfail_count = r_syncfail_10ms_count;

wire [31:0] w_inputsync_time_stamp;

ylib_mon_time_stamp #(
    .WIDTH(32)
) ylib_mon_time_stamp_inputinstance (
    .i_clk(i_clk),
    .i_sync(dbg_uin_frame_sync),
    .o_time_stamp(w_inputsync_time_stamp)
);
assign o_inputsync_time_stamp = w_inputsync_time_stamp;


//ref_vsync_gen #(
//) u_input_ctrl_ref_vsync_gen (
//    .i_clk(i_clk),
//    .i_mu({1'b0,i_scstype}),
//    .i_retard({{20{1'b0}},2'd3}),
//    .i_frame_sync(i_uin_frame_sync),
//    .i_en(1'b1),
//    .o_frame_sync(),
//    .o_subfrm_sync(),
//    .o_slot_sync(w_slot_sync_input),
//    .o_symbol_sync(w_sym_sync_input),
//    .o_subfrm(w_subfrm_idx_input),
//    .o_slot(w_slot_idx_input),
//    .o_symbol(w_symbol_idx_input)
//);

`ifdef ULFE_SRS

reg     r_srs_sym_flag  ;
reg     w_dly_srs_sym_flag  ;

always @(posedge i_clk)
begin
    r_srs_sym_flag  <=  i_srs_sym_flag;
end


ylib_reg_clk_en 
#(.WIDTH(1   ), .DEPTH(3)) 
ylib_dl_start_tick_reg_clk_en   
(.i_clk(i_clk),  .i_en(w_sym_sync_input), .i_in(r_srs_sym_flag), .o_out(w_dly_srs_sym_flag));


assign o_srs_sym_flag = w_dly_srs_sym_flag;




wire w_dl_start_tick;
reg  r_dl_start_tick;
wire w_dly_dl_start_tick;
//parameter 

ylib_pshift #(
    .BW_SHIFT($clog2(2+1))
) ylib_pshift_dl_start_tick_instance (
    .i_clk(i_clk),
    .i_shift(2'd2),
    .i_in(i_dl_start_tick),
    .o_out(w_dl_start_tick)
);

always @(posedge i_clk)
begin
    if(w_dl_start_tick) 
        r_dl_start_tick <= 1'b1;
    else if(w_sym_sync_input)
        r_dl_start_tick <= 1'b0;
    else
        r_dl_start_tick <= r_dl_start_tick;
end



ylib_reg_clk_en 
#(.WIDTH(1   ), .DEPTH(2)) 
ylib_dl_start_tick_reg_clk_en   
(.i_clk(i_clk),  .i_en(w_sym_sync_input), .i_in(r_dl_start_tick), .o_out(w_dly_dl_start_tick));

assign o_dly_dl_start_tick = w_dly_dl_start_tick;

`endif

`ifdef ULFE_input_tvrom

//wire [3:0] w_sym_idx_u_input_ctrl_ref_vsync_gen;
//
//ref_vsync_gen #(
//) u_input_ctrl_ref_vsync_gen (
//    .i_clk(i_clk),
//    .i_mu(3'd1),
//    .i_retard({{20{1'b0}},2'd2}),
//    .i_frame_sync(i_uin_frame_sync),
//    .i_en(1'b1),
//    .o_frame_sync(),
//    .o_subfrm_sync(),
//    .o_slot_sync(w_slot_sync_tvinput),
//    .o_symbol_sync(w_sym_sync_tvinput),
//    .o_subfrm(),
//    .o_slot(),
//    .o_symbol(w_sym_idx_u_input_ctrl_ref_vsync_gen)
//);


reg [13:0]      r_cnt_tv;
reg [15:0]      r_cnt_tv_sample;
reg [ 3:0]      r_cnt_tv_sym;

always @(posedge i_clk)
begin
    if(r_uin_frame_sync)
    begin
        r_cnt_tv_sample <= 15'd0;
        r_cnt_tv_sym    <= 4'd0;
    end
    else if(r_cnt_tv_sample==(15'd8895)) 
    begin
        r_cnt_tv_sample <= r_cnt_tv_sample+15'd1;
        r_cnt_tv_sym    <= r_cnt_tv_sym + 4'd1;
    end
    else if(r_cnt_tv_sample==(15'd17663)) 
    begin
        if(r_cnt_tv_sym == 4'd13)
        begin
            r_cnt_tv_sample <= 15'd0;
            r_cnt_tv_sym    <= 4'd0;
        end
        else
        begin
            r_cnt_tv_sample <= 15'd8896;
            r_cnt_tv_sym    <= r_cnt_tv_sym + 4'd1;
        end
    end
    else
    begin
        r_cnt_tv_sample <= r_cnt_tv_sample+15'd1;
        r_cnt_tv_sym    <= r_cnt_tv_sym;
    end
end




ulfe_input_tvrom #(
    .AWIDTH(14),
    .DWIDTH(64),
    .NBPIPE(1)
) ulfe_input_tvrom_instance (
    .clk(i_clk),
    .rst(i_rst),
    .we(1'b0),
    .regce(1'b1),
    .mem_en(1'b1),
    .din(64'd0),
    .addr(r_cnt_tv_sample[14:1]),
    .dout(w_dat_ulfe_input_tvrom)
);


`endif


`ifdef ULFE_inputctrl_ILADBG
 (* dont_touch="true" *)reg    [1:0]                    rila_inte_leav_frame_sync;
 (* dont_touch="true" *)reg    [2-1:0]                  rila_inte_leav_iq_en   [1:0];
 (* dont_touch="true" *)reg    [2*1*TOP_DIO_BW-1:0]     rila_inte_leav_iq      [1:0];

always @(posedge i_clk    )
begin
    rila_inte_leav_frame_sync   [0]     <=  w_inte_leav_frame_sync[0];
    rila_inte_leav_iq_en        [0]     <=  w_inte_leav_iq_en[1:0];
    rila_inte_leav_iq           [0]     <=  w_inte_leav_iq[31:0];
    rila_inte_leav_frame_sync   [1]     <=  rila_inte_leav_frame_sync   [0];
    rila_inte_leav_iq_en        [1]     <=  rila_inte_leav_iq_en        [0];
    rila_inte_leav_iq           [1]     <=  rila_inte_leav_iq           [0];
end

ila_ulfe_inputctrl u_ila_ulfe_inputctrl (
  .clk      (i_clk),
  .probe0   (rila_inte_leav_frame_sync   [1]),
  .probe1   (rila_inte_leav_iq_en        [1]),
  .probe2   (rila_inte_leav_iq           [1])
);
`endif

endmodule
