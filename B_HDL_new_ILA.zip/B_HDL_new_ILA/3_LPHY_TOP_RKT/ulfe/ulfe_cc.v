// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20/FSU10 + DCM RT4419 + VzW RT8808
//  Module       : ulfe_cc
//  Author       : dg0110.jo@samsung.com
//  Description  : ulfe cc top for comment Projects
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.19 | donggeun.jo   | Ver2.0 : add num_chain architecture
//              |               | Supporting RT8808 (VERSAL FPGA)
//  ------------+---------------+-----------------------------------------------
//   2020.06.02 | jyzoo.lee     | IO Port Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "ulfe_cc.vh"


module ulfe_cc
#(
     parameter  NUM_ANT             =   8
    ,parameter  NUM_CHAIN           =   1     
    ,parameter  TOP_DIO_BW          =   16
    ,parameter  DLY_REG_RD          =   7
    ,parameter  ADDR_OFFSET         =   16'h5000
    ,parameter  VENDOR              =   "Xilinx"
//    ,parameter  CALB_EN             =   "disable"
    ,parameter  CPUIF_BB_ADDR_BW    =   20
)
(
    //--- reset & clk
        input   wire                                        i_rst
    ,   input   wire                                        i_clk

    //--- from cpu interface
    ,   input   wire    [CPUIF_BB_ADDR_BW-1:0]              i_cpu_addr
    ,   input   wire    [0:0]                               i_cpu_wren
    ,   input   wire    [31:0]                              i_cpu_wdata
    ,   input   wire    [0:0]                               i_cpu_rden
    ,   output  wire    [31:0]                              o_cpu_rdata
    ,   output  wire    [0:0]                               o_cpu_rd_valid

    //--- from bb_if
    ,   input   wire    [0:0]                               i_uin_frame_sync
    ,   input   wire    [NUM_ANT-1:0]                       i_uin_en
    ,   input   wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          i_uin_iq

    //--- from bb_if
    ,   output   wire   [3:0]                               o_uout_ul_bw_idx
    
    //--- from oran_top
    ,   input   wire    [7:0]                               i_uin_frame_idx
`ifdef ULFE_Cp
    ,   input   wire    [3:0]                               i_uin_cp_symbol_idx
`endif
`ifdef ULFE_DSS
    ,   input   wire                                        i_uin_en_technology
    ,   input   wire                                        i_uin_technology_dss
`endif
`ifdef ULFE_SRS
    ,   input   wire                                        i_uin_dl_start_tick
    ,   input   wire                                        i_uin_srs_sym_flag
    
    ,   output  wire                                        o_srsout_frame_sync
    ,   output  wire    [7:0]                               o_srsout_frame_idx
    ,   output  wire    [3:0]                               o_srsout_subfrm_idx
    ,   output  wire    [5:0]                               o_srsout_slot_idx
    ,   output  wire                                        o_srsout_symbol_sync
    ,   output  wire    [3:0]                               o_srsout_symbol_idx
    ,   output  wire    [NUM_ANT-1:0]                       o_srsout_en
    ,   output  wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          o_srsout_iq
    ,   output  wire    [NUM_ANT*16-1:0]                    o_srsout_start_re_idx
    ,   output  wire    [NUM_ANT*1-1:0]                     o_srsout_start_re
    ,   output  wire    [NUM_ANT*1-1:0]                     o_srsout_last_re
    ,   output  wire                                        o_srsout_start_tick

    
`endif

        
`ifdef ULFE_CAL    
    ,   input   wire                                        i_dl_cal_en_ultop   
    ,   input   wire                                        i_ul_cal_en_ultop          
    ,   input   wire    [NUM_ANT*1-1:0]                     i_dl_cal_tx_en_ultop          
    ,   input   wire    [NUM_ANT*1-1:0]                     i_ul_cal_tx_en_ultop          
`endif
    
    //--- to bb_top
    ,   output  wire                                        o_uout_frame_sync
    ,   output  wire    [7:0]                               o_uout_frame_idx
    ,   output  wire    [3:0]                               o_uout_subfrm_idx
    ,   output  wire    [5:0]                               o_uout_slot_idx
    ,   output  wire                                        o_uout_symbol_sync
    ,   output  wire    [3:0]                               o_uout_symbol_idx
    ,   output  wire    [NUM_ANT-1:0]                       o_uout_en
    ,   output  wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          o_uout_iq
    ,   output  wire    [NUM_ANT*16-1:0]                    o_uout_start_re_idx
    ,   output  wire    [NUM_ANT*1-1:0]                     o_uout_start_re
    ,   output  wire    [NUM_ANT*1-1:0]                     o_uout_last_re
    
`ifdef ULFE_AIE_8RX_4CHAIN    
    ,   input   wire                                        i_aie_rst 
    ,   input   wire                                        i_aie_clk 
    ,   input   wire    [1   -1:0]                          i_p2a0_ready    
    ,   output  wire    [1   -1:0]                          o_p2a0_valid    
    ,   output  wire    [64  -1:0]                          o_p2a0_data     
    ,   output  wire    [1   -1:0]                          o_p2a0_last     
    ,   output  wire    [8   -1:0]                          o_p2a0_keep     
    ,   output  wire    [1   -1:0]                          o_a2p0_ready 
    ,   input   wire    [1   -1:0]                          i_a2p0_valid 
    ,   input   wire    [64  -1:0]                          i_a2p0_data  
    ,   input   wire    [1   -1:0]                          i_a2p0_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a1_ready    
    ,   output  wire    [1   -1:0]                          o_p2a1_valid    
    ,   output  wire    [64  -1:0]                          o_p2a1_data     
    ,   output  wire    [1   -1:0]                          o_p2a1_last     
    ,   output  wire    [8   -1:0]                          o_p2a1_keep     
    ,   output  wire    [1   -1:0]                          o_a2p1_ready 
    ,   input   wire    [1   -1:0]                          i_a2p1_valid 
    ,   input   wire    [64  -1:0]                          i_a2p1_data  
    ,   input   wire    [1   -1:0]                          i_a2p1_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a2_ready    
    ,   output  wire    [1   -1:0]                          o_p2a2_valid    
    ,   output  wire    [64  -1:0]                          o_p2a2_data     
    ,   output  wire    [1   -1:0]                          o_p2a2_last     
    ,   output  wire    [8   -1:0]                          o_p2a2_keep     
    ,   output  wire    [1   -1:0]                          o_a2p2_ready 
    ,   input   wire    [1   -1:0]                          i_a2p2_valid 
    ,   input   wire    [64  -1:0]                          i_a2p2_data  
    ,   input   wire    [1   -1:0]                          i_a2p2_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a3_ready    
    ,   output  wire    [1   -1:0]                          o_p2a3_valid    
    ,   output  wire    [64  -1:0]                          o_p2a3_data     
    ,   output  wire    [1   -1:0]                          o_p2a3_last     
    ,   output  wire    [8   -1:0]                          o_p2a3_keep     
    ,   output  wire    [1   -1:0]                          o_a2p3_ready 
    ,   input   wire    [1   -1:0]                          i_a2p3_valid 
    ,   input   wire    [64  -1:0]                          i_a2p3_data  
    ,   input   wire    [1   -1:0]                          i_a2p3_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a4_ready    
    ,   output  wire    [1   -1:0]                          o_p2a4_valid    
    ,   output  wire    [64  -1:0]                          o_p2a4_data     
    ,   output  wire    [1   -1:0]                          o_p2a4_last     
    ,   output  wire    [8   -1:0]                          o_p2a4_keep     
    ,   output  wire    [1   -1:0]                          o_a2p4_ready 
    ,   input   wire    [1   -1:0]                          i_a2p4_valid 
    ,   input   wire    [64  -1:0]                          i_a2p4_data  
    ,   input   wire    [1   -1:0]                          i_a2p4_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a5_ready    
    ,   output  wire    [1   -1:0]                          o_p2a5_valid    
    ,   output  wire    [64  -1:0]                          o_p2a5_data     
    ,   output  wire    [1   -1:0]                          o_p2a5_last     
    ,   output  wire    [8   -1:0]                          o_p2a5_keep     
    ,   output  wire    [1   -1:0]                          o_a2p5_ready 
    ,   input   wire    [1   -1:0]                          i_a2p5_valid 
    ,   input   wire    [64  -1:0]                          i_a2p5_data  
    ,   input   wire    [1   -1:0]                          i_a2p5_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a6_ready    
    ,   output  wire    [1   -1:0]                          o_p2a6_valid    
    ,   output  wire    [64  -1:0]                          o_p2a6_data     
    ,   output  wire    [1   -1:0]                          o_p2a6_last     
    ,   output  wire    [8   -1:0]                          o_p2a6_keep     
    ,   output  wire    [1   -1:0]                          o_a2p6_ready 
    ,   input   wire    [1   -1:0]                          i_a2p6_valid 
    ,   input   wire    [64  -1:0]                          i_a2p6_data  
    ,   input   wire    [1   -1:0]                          i_a2p6_last  
                                                            
    ,   input   wire    [1   -1:0]                          i_p2a7_ready    
    ,   output  wire    [1   -1:0]                          o_p2a7_valid    
    ,   output  wire    [64  -1:0]                          o_p2a7_data     
    ,   output  wire    [1   -1:0]                          o_p2a7_last     
    ,   output  wire    [8   -1:0]                          o_p2a7_keep     
    ,   output  wire    [1   -1:0]                          o_a2p7_ready 
    ,   input   wire    [1   -1:0]                          i_a2p7_valid 
    ,   input   wire    [64  -1:0]                          i_a2p7_data  
    ,   input   wire    [1   -1:0]                          i_a2p7_last  
`endif
    
);

localparam  FHTYPE      =   "ORAN"; //ORAN - CPRI
localparam  NUM_RX_CORE =   NUM_ANT/NUM_CHAIN;  // < operating clock / sampling rate
localparam  MAX_NUM_RX = 8;
localparam  NUM_AIE_AXI = 8;                                                                                                  

genvar  gcore ;


    wire    [                  31:0]    w_input_ctrl_mode           ;
    wire    [                  31:0]    w_input_tp_mode             ;
    wire    [                  31:0]    w_output_ctrl_mode          ;
    wire    [                  31:0]    w_par_freqshifton           ;
    wire    [                  31:0]    w_par_cptype                ;
    wire    [                  31:0]    w_par_cprmoffset            ;
    wire    [                  31:0]    w_par_tagcon                ;
    wire    [                  31:0]    w_par_tagcbackoff           ;
    wire    [                  31:0]    w_par_k0                    ;
    wire    [                  31:0]    w_par_rbsize                ;
    wire    [                  31:0]    w_par_gaincompon            ;
    wire    [                  31:0]    w_par_ctson                 ;
    wire    [                  31:0]    w_par_ctsshift              ;
    wire    [                  31:0]    w_par_phasecompon           ;
    wire    [                  31:0]    w_par_mpfrmstruct           ; //include : w_par_mpfrmstruct_fftsize & w_par_mpfrmstruct_scstype
    wire    [                   1:0]    w_par_fftsize   ;
    wire    [                   1:0]    w_par_scstype   ;
    wire    [                  31:0]    w_par_tdrssiTrigSlot        ;
    wire    [                  31:0]    w_par_tdrssiTrigSym         ;
    wire    [                  31:0]    w_par_tdrssiStartSlot       ;
    wire    [                  31:0]    w_par_tdrssiStartSym        ;
    wire    [                  31:0]    w_par_tdrssiSymSize         ;
    wire    [                  31:0]    w_par_tdrssiTrigger         ;
    wire    [                  31:0]    w_par_sel_symidx_tdrssirpt  ;
//    wire    [                  31:0]    w_par_phase0                ;
//    wire    [                  31:0]    w_par_phase1                ;
//    wire    [                  31:0]    w_par_phase2                ;
//    wire    [                  31:0]    w_par_phase3                ;
//    wire    [                  31:0]    w_par_phase4                ;
//    wire    [                  31:0]    w_par_phase5                ;
//    wire    [                  31:0]    w_par_phase6                ;
//    wire    [                  31:0]    w_par_phase7                ;
//    wire    [                  31:0]    w_par_phase8                ;
//    wire    [                  31:0]    w_par_phase9                ;
//    wire    [                  31:0]    w_par_phase10               ;
//    wire    [                  31:0]    w_par_phase11               ;
//    wire    [                  31:0]    w_par_phase12               ;
//    wire    [                  31:0]    w_par_phase13               ;
    wire    [16*14*(2**`MAX_SCS_u_ULFE)-1:0]    w_par_phaseI        ;
    wire    [16*14*(2**`MAX_SCS_u_ULFE)-1:0]    w_par_phaseQ        ;    

    wire    [                  31:0]    w_par_calon                 ;
    wire    [                  31:0]    w_par_calwscale             ;
    wire    [                  31:0]    w_sel_calb_rx               ;
    wire    [        NUM_ANT* 1-1:0]    w_calwght_evenodd           ;
    reg     [                 1-1:0]    r_sel_calwght_evenodd       ;
    

    wire    [                 4-1:0]    w_fs_type                   ;
    wire    [                 6-1:0]    w_osr                       ;
    wire    [                 3-1:0]    w_osr_quotient              ;

    wire    [                 4-1:0]    w_bw_type                   ;

//    wire    [                 2-1:0]    w_fft_type                  ;

    wire    [0:0]                       w_uin_frame_sync            ;
    wire    [NUM_ANT-1:0]               w_uin_en                    ;
    wire    [2*NUM_CHAIN*TOP_DIO_BW-1:0]  w_uin_iq                  ;

    wire    [           NUM_ANT-1:0]    w_pre_process_out_vld       ; // output valid
    wire    [NUM_CHAIN*TOP_DIO_BW-1:0]    w_pre_process_out_i         ; // output I    
    wire    [NUM_CHAIN*TOP_DIO_BW-1:0]    w_pre_process_out_q         ; // output Q    
    wire    [         NUM_CHAIN-1:0]    w_pre_process_frm_tick      ; // output frm tick 

    wire                                wo_pre_process_frm_tick     ;
    wire    [NUM_ANT*2-1:0]             temp_en                     ;
    wire    [TOP_DIO_BW-2:0]            temp_i                      ;
    wire    [TOP_DIO_BW-2:0]            temp_q                      ;
                                                                    
//    wire    [NUM_ANT-1:0]               w_uin_xssi_en               ;
//    wire    [32*NUM_ANT-1:0]            w_uin_xssi                  ;
    wire    [32*NUM_ANT-1:0]            w_uin_xssi                  ;
//    wire    [NUM_ANT-1:0]               w_uout_xssi_en              ;
//    wire    [32*NUM_ANT-1:0]            w_uout_xssi                 ;
    wire    [32*NUM_ANT-1:0]            w_uout_xssi                 ;
    wire    [32*NUM_ANT-1:0]            w_srsout_xssi               ;
    wire    [16*14*1-1:0]               w_phaseW_i                  ;
    wire    [16*14*1-1:0]               w_phaseW_q                  ;
    wire    [31:0]                      w_frm_chk_gap               ;
    wire    [31:0]                      w_inout_frm_syncfail_count  ;
    wire    [31:0]                      w_prev_current_frmidx       ;
    wire    [31:0]                      w_inputsync_time_stamp      ;
    
    wire    [  NUM_CHAIN-1:0]           w_tdagc_frm_tick            ;
    wire    [    NUM_ANT-1:0]           w_tdagc_tdrssi_vld          ;     
    wire    [ NUM_ANT*32-1:0]           w_tdagc_tdrssi              ;     
    wire    [            0:0]           w_tdrssi_rpt_done           ;
    wire    [ NUM_ANT*32-1:0]           w_tdrssi_rpt                ;

    wire    [NUM_CHAIN*6-1:0]           w_pre_process_sltIdx        ;
    wire    [NUM_CHAIN*4-1:0]           w_pre_process_symIdx        ;
    reg     [NUM_ANT-1:0]               r_uout_en                   ;
    reg     [2*NUM_ANT*TOP_DIO_BW-1:0]  r_uout_iq                   ;

    wire    [MAX_NUM_RX-1:0]            w_uin_en_exist              ;
    wire    [NUM_CHAIN*5-1:0]           w_dbg_dssCp_alarm           ;
    wire                                w_dly_dl_start_tick         ;
    wire                                w_dly_srs_sym_flag          ;

    wire    [NUM_CHAIN-1:0]             w_calb_cpu_rvalid           ;
    wire    [NUM_CHAIN*32-1:0]          w_calb_cpu_rdata            ;
    wire    [NUM_CHAIN-1:0]             wo_calb_cpu_rvalid          ;
    wire    [NUM_CHAIN*32-1:0]          wo_calb_cpu_rdata           ;
    wire    [0:0]                       wi_calb_cpu_rvalid          ;
    wire    [32-1:0]                    wi_calb_cpu_rdata           ;


    
//`ifdef ULFE_AIE_8RX_4CHAIN    
wire    [NUM_CHAIN*32-1:0]              w_cnt_st01_a2p_last         ;                           
wire    [NUM_CHAIN*32-1:0]              w_cnt_st01_a2p_0dat         ;
wire    [NUM_CHAIN*32-1:0]              w_cnt_fd_0dat               ;
wire    [NUM_AIE_AXI*1   -1:0]          wi_p2a_ready                ;
wire    [NUM_AIE_AXI*1   -1:0]          wo_p2a_valid                ;
wire    [NUM_AIE_AXI*64  -1:0]          wo_p2a_data                 ;
wire    [NUM_AIE_AXI*1   -1:0]          wo_p2a_last                 ;
wire    [NUM_AIE_AXI*8   -1:0]          wo_p2a_keep                 ;
wire    [NUM_AIE_AXI*1   -1:0]          wo_a2p_ready                ;
wire    [NUM_AIE_AXI*1   -1:0]          wi_a2p_valid                ;
wire    [NUM_AIE_AXI*64  -1:0]          wi_a2p_data                 ;
wire    [NUM_AIE_AXI*1   -1:0]          wi_a2p_last                 ;
//`endif

reg    [NUM_AIE_AXI*1   -1:0]          ri_p2a_ready                [1:0];
reg    [NUM_AIE_AXI*1   -1:0]          ri_a2p_valid                [1:0];

always @(posedge i_clk)
begin
    ri_p2a_ready[0] <= wi_p2a_ready;
    ri_a2p_valid[0] <= wi_a2p_valid;
    ri_p2a_ready[1] <= ri_p2a_ready[0];
    ri_a2p_valid[1] <= ri_a2p_valid[0];    
end

                                                            
`ifdef ULFE_AIE_8RX_4CHAIN    
assign wi_p2a_ready   = {i_p2a7_ready ,i_p2a6_ready ,i_p2a5_ready ,i_p2a4_ready,i_p2a3_ready ,i_p2a2_ready ,i_p2a1_ready ,i_p2a0_ready };
assign {o_p2a7_valid ,o_p2a6_valid ,o_p2a5_valid ,o_p2a4_valid,o_p2a3_valid ,o_p2a2_valid ,o_p2a1_valid ,o_p2a0_valid } = wo_p2a_valid  ;
assign {o_p2a7_data  ,o_p2a6_data  ,o_p2a5_data  ,o_p2a4_data ,o_p2a3_data  ,o_p2a2_data  ,o_p2a1_data  ,o_p2a0_data  } = wo_p2a_data   ;
assign {o_p2a7_last  ,o_p2a6_last  ,o_p2a5_last  ,o_p2a4_last ,o_p2a3_last  ,o_p2a2_last  ,o_p2a1_last  ,o_p2a0_last  } = wo_p2a_last   ;
assign {o_p2a7_keep  ,o_p2a6_keep  ,o_p2a5_keep  ,o_p2a4_keep ,o_p2a3_keep  ,o_p2a2_keep  ,o_p2a1_keep  ,o_p2a0_keep  } = wo_p2a_keep   ;
assign {o_a2p7_ready ,o_a2p6_ready ,o_a2p5_ready ,o_a2p4_ready,o_a2p3_ready ,o_a2p2_ready ,o_a2p1_ready ,o_a2p0_ready } = wo_a2p_ready  ;
assign wi_a2p_valid   = {i_a2p7_valid ,i_a2p6_valid ,i_a2p5_valid ,i_a2p4_valid,i_a2p3_valid ,i_a2p2_valid ,i_a2p1_valid ,i_a2p0_valid };
assign wi_a2p_data    = {i_a2p7_data  ,i_a2p6_data  ,i_a2p5_data  ,i_a2p4_data ,i_a2p3_data  ,i_a2p2_data  ,i_a2p1_data  ,i_a2p0_data  };
assign wi_a2p_last    = {i_a2p7_last  ,i_a2p6_last  ,i_a2p5_last  ,i_a2p4_last ,i_a2p3_last  ,i_a2p2_last  ,i_a2p1_last  ,i_a2p0_last  };
`endif


    // ctrl module
    ulfe_cpu_param_if #(
    .ADDR_OFFSET    (   ADDR_OFFSET        ) // CPU IF Address Offset    
    ,.DLY_REG_RD    (   DLY_REG_RD         ) // READ Latency
    ,.AW            (   CPUIF_BB_ADDR_BW   )       // CPU IF Address Bit Width
    ,.DW            (   32                 )     // CPU IF Data Bit Width 
    ,.UL_NUM_ANT    (   NUM_ANT            )
    ,.NUM_CHAIN     (   NUM_CHAIN          )
    //    ,.MAX_SCS_u_ULFE(   `MAX_SCS_u_ULFE    )
    )
    u_ulfe_cpu_param_if(
    //--- reset & clk
    .i_clk                          ( i_clk                 )
    ,.i_rst                         ( i_rst                 )
    //--- cpu interface
    ,.i_cpu_addr                    ( i_cpu_addr            )
    ,.i_cpu_wren                    ( i_cpu_wren            )
    ,.i_cpu_wdata                   ( i_cpu_wdata           )
    ,.i_cpu_rden                    ( i_cpu_rden            )
    ,.o_cpu_rdata                   ( o_cpu_rdata           )
    ,.o_cpu_rd_valid                ( o_cpu_rd_valid        )
    
`ifdef ULFE_CALB_EN
    ,.i_calb_cpu_rvalid             ( w_calb_cpu_rvalid     )
    ,.i_calb_cpu_rdata              ( w_calb_cpu_rdata      )     
    ,.i_calwght_evenodd_sel         ({r_sel_calwght_evenodd,w_calwght_evenodd})
       
`endif
    
    //--- Parsed parameter 
    ,.o_input_ctrl_mode             ( w_input_ctrl_mode    )
    ,.o_input_tp_mode               ( w_input_tp_mode      )
    ,.o_output_ctrl_mode            ( w_output_ctrl_mode   )
    
    ,.o_par_freqshifton             ( w_par_freqshifton    )
    ,.o_par_cpType                  ( w_par_cptype         )
    ,.o_par_cpRmOffset              ( w_par_cprmoffset     )
    ,.o_par_tagcOn                  ( w_par_tagcon         )
    ,.o_par_tagcBackoff             ( w_par_tagcbackoff    )
    ,.o_par_k0                      ( w_par_k0             )
    ,.o_par_rbSize                  ( w_par_rbsize         )
    ,.o_par_gainCompOn              ( w_par_gaincompon     )
    ,.o_par_ctsOn                   ( w_par_ctson          )
    ,.o_par_ctsShift                ( w_par_ctsshift       )
    ,.o_par_phaseCompOn             ( w_par_phasecompon    )
    ,.o_par_mpfrmstruct             ( w_par_mpfrmstruct    )
    ,.o_par_mpfrmstruct_fftsize     ( w_par_fftsize        )
    ,.o_par_mpfrmstruct_scstype     ( w_par_scstype        )
    ,.o_par_tdrssiTrigSlot          ( w_par_tdrssiTrigSlot )      
    ,.o_par_tdrssiTrigSym           ( w_par_tdrssiTrigSym  )      
    ,.o_par_tdrssiStartSlot         ( w_par_tdrssiStartSlot)      
    ,.o_par_tdrssiStartSym          ( w_par_tdrssiStartSym )      
    ,.o_par_tdrssiSymSize           ( w_par_tdrssiSymSize  )      
    ,.o_par_tdrssiTrigger           ( w_par_tdrssiTrigger  )
    ,.o_par_sel_symidx_tdrssirpt    ( w_par_sel_symidx_tdrssirpt )
    ,.i_tdrssi_rpt_done             ( w_tdrssi_rpt_done    )
    ,.i_tdrssi_rpt                  ( {{(64-NUM_ANT){32'h00000000}},w_tdrssi_rpt} )
    ,.o_par_numMdmPath              ()                                                                                         
    ,.o_par_numAnt                  ()
    ,.o_par_Phase_I                 ( w_par_phaseI         )
    ,.o_par_Phase_Q                 ( w_par_phaseQ         )
    ,.o_par_calon                   ( w_par_calon        )
    ,.o_par_calwscale               ( w_par_calwscale        )
    ,.o_sel_calb_rx                 ( w_sel_calb_rx        )
    //--- Report Register
//    ,.i_rpt_p2000                   (                       )
//    ,.i_rpt_p2001                   (                       )
//    ,.i_rpt_p2002                   (                       )
//    ,.i_rpt_p2003                   (                       )
//    ,.i_rpt_p2004                   (                       )
    ,.i_rpt_uin_xssi                ( w_uin_xssi            )
    ,.i_rpt_uout_xssi               ( w_uout_xssi           )

    //--- Monitoring Register
    ,.i_uin_en                      ( w_uin_en_exist            )
    ,.o_frm_chk_gap                 ( w_frm_chk_gap             )
    ,.i_inout_frm_syncfail_count    ( w_inout_frm_syncfail_count)
    ,.i_prev_current_frmidx         ( w_prev_current_frmidx     )    
    ,.i_inputsync_time_stamp        ( w_inputsync_time_stamp    )
    ,.i_p2a_ready_fft               ( {{(32-NUM_AIE_AXI){1'b0}},{ri_p2a_ready[1]}}  )
    ,.i_a2p_valid_fft               ( {{(32-NUM_AIE_AXI){1'b0}},{ri_a2p_valid[1]}}  )
    ,.i_cnt_st01_a2p_last           ({{((4-NUM_CHAIN)*32){1'b0}},w_cnt_st01_a2p_last[NUM_CHAIN*32-1:0]})                           
    ,.i_cnt_st01_a2p_0dat           ({{((4-NUM_CHAIN)*32){1'b0}},w_cnt_st01_a2p_0dat[NUM_CHAIN*32-1:0]})
    ,.i_cnt_fd_0dat                 ({{((4-NUM_CHAIN)*32){1'b0}},w_cnt_fd_0dat[NUM_CHAIN*32-1:0]})

    //--- Cp Monitoring 
    ,.i_dbg_dssCp_alarm             (w_dbg_dssCp_alarm[4:0])
    );

assign w_uin_en_exist = {{(MAX_NUM_RX-NUM_ANT){1'b0}},{i_uin_en}};
//assign wi_calb_cpu_rvalid   = (w_sel_calb_rx[2:0] / NUM_RX_CORE == 0) ? wo_calb_cpu_rvalid[0] : (w_sel_calb_rx[2:0] / NUM_RX_CORE == 1) ? wo_calb_cpu_rvalid[1] : (w_sel_calb_rx[2:0] / NUM_RX_CORE == 2) ? wo_calb_cpu_rvalid[2] : wo_calb_cpu_rvalid[3]; 
//assign wi_calb_cpu_rdata    = (w_sel_calb_rx[2:0] / NUM_RX_CORE == 0) ? wo_calb_cpu_rdata[0] : (w_sel_calb_rx[2:0] / NUM_RX_CORE == 1) ? wo_calb_cpu_rdata[1] : (w_sel_calb_rx[2:0] / NUM_RX_CORE == 2) ? wo_calb_cpu_rdata[2] : wo_calb_cpu_rdata[3]; 


ulfe_cpu_param_post_proc u_ulfe_cpu_param_post_proc (
    .i_clk          (i_clk)
    ,.i_rst         (i_rst)
    
    ,.i_par_rbsize  (w_par_rbsize)
    ,.i_par_scstype (w_par_scstype)
    ,.o_bw_type     (w_bw_type)
    ,.o_fs_type     (w_fs_type)
    ,.o_osr         (w_osr)    
    ,.o_osr_quotient(w_osr_quotient)    
//    ,.i_par_mpfrmstruct_fftsize(w_par_mpfrmstruct_fftsize) 
//    ,.o_fft_type(w_fft_type)                 
);

assign o_uout_ul_bw_idx = w_bw_type;



ulfe_input_ctrl #(
    .NUM_ANT(NUM_ANT)
    ,.NUM_CHAIN(NUM_CHAIN)
    ,.TOP_DIO_BW(TOP_DIO_BW)
) ulfe_input_ctrl_instance (
    .i_clk              (i_clk)
    ,.i_rst             (i_rst)

    ,.i_uin_frame_sync  (i_uin_frame_sync)
    ,.i_uin_en          (i_uin_en)
    ,.i_uin_iq          (i_uin_iq)
    ,.o_uin_frame_sync  (w_uin_frame_sync)
    ,.o_uin_en          (w_uin_en)
    ,.o_uin_iq          (w_uin_iq)
    
`ifdef ULFE_SRS
    ,.i_cp_symbol_idx   (i_uin_cp_symbol_idx   )
    ,.i_srs_sym_flag    (i_uin_srs_sym_flag )
    ,.o_srs_sym_flag    (w_dly_srs_sym_flag)
    ,.i_dl_start_tick   (i_uin_dl_start_tick)
    ,.o_dl_start_tick   (w_dly_dl_start_tick)
`endif    
    ,.tp_on             ((|(w_input_tp_mode[1:0])))
    ,.tp_mode           ({w_input_tp_mode[8],w_input_tp_mode[4],w_input_tp_mode[1:0]})
    ,.sig_ctrl_mode     (w_input_ctrl_mode[1:0])
    ,.i_scstype         (w_par_scstype)
    ,.i_fs_type         (w_fs_type)
    ,.i_osr             ({2'b00,w_osr})
    ,.o_xssi            (w_uin_xssi[32*NUM_ANT-1:0])
    ,.i_frm_chk_gap                 (w_frm_chk_gap             )
    ,.o_inout_frm_syncfail_count    (w_inout_frm_syncfail_count[15:0])
    ,.o_inputsync_time_stamp        (w_inputsync_time_stamp)
);

//integer kk;
//reg [8-NUM_ANT-1:0] r_dummy_en [NUM_ANT-1:0];
//
//always @ (posedge i_clk)
//begin
//    r_dummy_en[0] <=  w_uin_en[8-NUM_ANT-1:0];
//    
//    for (kk = 0; kk < 8-NUM_ANT-1; kk = kk+1)
//    begin
//        r_dummy_en[kk+1] <= r_dummy_en[kk];     //aligned addr 7
//    end
//end 




//assign w_phaseW_i = {w_par_phase13[32-1:16], w_par_phase12[32-1:16], w_par_phase11[32-1:16], w_par_phase10[32-1:16], w_par_phase9[32-1:16], w_par_phase8[32-1:16], w_par_phase7[32-1:16], w_par_phase6[32-1:16], w_par_phase5[32-1:16], w_par_phase4[32-1:16], w_par_phase3[32-1:16], w_par_phase2[32-1:16], w_par_phase1[32-1:16], w_par_phase0[32-1:16]};
//assign w_phaseW_q = {w_par_phase13[16-1:0] , w_par_phase12[16-1:0] , w_par_phase11[16-1:0] , w_par_phase10[16-1:0] , w_par_phase9[16-1:0] , w_par_phase8[16-1:0] , w_par_phase7[16-1:0] , w_par_phase6[16-1:0] , w_par_phase5[16-1:0] , w_par_phase4[16-1:0] , w_par_phase3[16-1:0] , w_par_phase2[16-1:0] , w_par_phase1[16-1:0] , w_par_phase0[16-1:0] };

wire                                        w_dl_cal_en_ultop    ;
wire                                        w_ul_cal_en_ultop    ;       
wire    [NUM_ANT*1-1:0]                     w_dl_cal_tx_en_ultop ;          
wire    [NUM_ANT*1-1:0]                     w_ul_cal_tx_en_ultop ;          

`ifdef ULFE_CAL    
assign w_dl_cal_en_ultop    = i_dl_cal_en_ultop    ;
assign w_ul_cal_en_ultop    = i_ul_cal_en_ultop    ;
assign w_dl_cal_tx_en_ultop = i_dl_cal_tx_en_ultop ;
assign w_ul_cal_tx_en_ultop = i_ul_cal_tx_en_ultop ;
`else
assign w_dl_cal_en_ultop    = 0 ;
assign w_ul_cal_en_ultop    = 0 ;
assign w_dl_cal_tx_en_ultop = 0 ;
assign w_ul_cal_tx_en_ultop = 0 ;
`endif

wire        w_calBypassFlag;
assign      w_calBypassFlag = (w_dl_cal_en_ultop & (|w_dl_cal_tx_en_ultop)) | (w_ul_cal_en_ultop & (|w_ul_cal_tx_en_ultop));



localparam x_ant = 1;
generate for(gcore=0 ; gcore<NUM_CHAIN ; gcore=gcore+1 ) begin : g_ulfe_pre_processing_core
    ulfe_pre_processing #(
         .FS_CLK        (245760000      ) 
        ,.OC            ($clog2(NUM_RX_CORE) )//Over clocking ratio      
        ,.NUM_RX        (NUM_RX_CORE    )
        ,.IB            (15             )//input Bitwidth                
        ,.OB            (15             )//ouput Bitwidth            
        ,.MAX_SCIDX     (`MAX_SCS_u_ULFE )//Sub carrier spacing IDX   
        ,.CPTYPE        (0              )//0:normal, 1:long          
        ,.TR            (32             )//TD-rssi report            
        ,.CALWB         (12             )//CALB weight bit width     
        ,.PWB           (16             )//Weight bitwidth           
        ,.MAX_NFFT      (`MAX_FFT_ULFE   )
        ,.VENDOR        (VENDOR         )
//        ,.CALB_EN   ("disable"      )//enble,disble
        ,.FHTYPE        ("ORAN"         )//ORAN ,CPRI
        ,.CHAIN_INDEX   (gcore)
        ,.CPUIF_BB_ADDR_BW (CPUIF_BB_ADDR_BW)
        
    ) u_ulfe_pre_processing      
    (
         .i_clk                        ( i_clk                                                                  )
        ,.i_rst                        ( i_rst                                                                  )
        ,.i_osr_quotient               (w_osr_quotient)

        ,.i_frm_tick_pre1              ( w_uin_frame_sync                                                       )
        ,.i_pre_process_in_vld         ( w_uin_en[NUM_RX_CORE*(gcore+1)-1:NUM_RX_CORE*gcore]                    )
        ,.i_pre_process_in_I           ( w_uin_iq[(gcore*2+2)*TOP_DIO_BW-2 : (gcore*2+1)*TOP_DIO_BW]            )
        ,.i_pre_process_in_Q           ( w_uin_iq[(gcore*2+1)*TOP_DIO_BW-2 : (gcore*2)*TOP_DIO_BW]              )

        ,.o_pre_process_out_vld        (w_pre_process_out_vld[NUM_RX_CORE*(gcore+1)-1:NUM_RX_CORE*gcore]        )
        ,.o_pre_process_out_I          (w_pre_process_out_i[(gcore*1+1)*TOP_DIO_BW-1 : (gcore*1)*TOP_DIO_BW]    )
        ,.o_pre_process_out_Q          (w_pre_process_out_q[(gcore*1+1)*TOP_DIO_BW-1 : (gcore*1)*TOP_DIO_BW]    )    
        ,.o_pre_process_frm_tick       (w_pre_process_frm_tick[gcore]                                           )    
        ,.o_sltIdx                     (w_pre_process_sltIdx[(gcore*1+1)*6-1 : (gcore*1)*6]                     )
        ,.o_symIdx                     (w_pre_process_symIdx[(gcore*1+1)*4-1 : (gcore*1)*4]                     )

`ifdef ULFE_Cp
        ,.i_uin_symbol_idx             (i_uin_cp_symbol_idx        )
`endif
`ifdef ULFE_DSS
        ,.i_uin_en_technology          (i_uin_en_technology     )
        ,.i_uin_technology_dss         (i_uin_technology_dss    )
        ,.o_dbg_dssCp_alarm            (w_dbg_dssCp_alarm[(gcore+1)*5-1 -: 5]       )
`endif
`ifdef ULFE_TAGC_TDRSSI
//        ,.i_tdrssi_trigger              (w_par_tdrssiTrigger  [0]    )      
//        ,.i_tdrssi_start_slt_idx        (w_par_tdrssiStartSlot[7-1:0])
//        ,.i_tdrssi_start_sym_idx        (w_par_tdrssiStartSym [4-1:0])
//        ,.i_tdrssi_syms_size            (w_par_tdrssiSymSize  [6-1:0])

        ,.o_tdagc_frm_tick             (w_tdagc_frm_tick[gcore])
        ,.o_tdagc_tdrssi_vld           (w_tdagc_tdrssi_vld[(gcore+1)*2-1 -: 2])    
        ,.o_tdagc_tdrssi               (w_tdagc_tdrssi[(gcore+1)*64-1 -: 64])
`endif
`ifdef ULFE_CALB_EN
        ,.i_cpu_addr                    (i_cpu_addr)
        ,.i_cpu_wren                    (i_cpu_wren)
        ,.i_cpu_wdata                   (i_cpu_wdata)
        ,.i_cpu_rden                    (i_cpu_rden)
        ,.o_calb_cpu_rvalid             (w_calb_cpu_rvalid[gcore])
        ,.o_calb_cpu_rdata              (w_calb_cpu_rdata[(gcore+1)*32-1 -: 32])
        ,.i_sel_calb_rx                 ({w_sel_calb_rx[8],w_sel_calb_rx[5:0]})
        ,.o_calwght_evenodd             (w_calwght_evenodd[(gcore+1)*2-1 -: 2])
        ,.i_sel_calwght_evenodd         (r_sel_calwght_evenodd)
`endif

        ,.i_bcf_en                     ( 1'd0                                           )
        ,.i_tdd_mode                   ( 1'd0                                           )
        ,.i_freqShiftOn                ( {NUM_RX_CORE{w_par_freqshifton[0]}}            )   //fsu20:005200
        ,.i_calBypassFlag              ( {NUM_RX_CORE{w_calBypassFlag}}                            )   //fsu20:skip
        ,.i_scsType                    ( {1'b0,w_par_scstype}                           )   
        ,.i_tagcbackoff                ( {NUM_RX_CORE{w_par_tagcbackoff[4:0]}}          )
        ,.i_tagcon                     ( {NUM_RX_CORE{w_par_tagcon[0]}}                 )
        ,.i_gainCompOn                 ( {NUM_RX_CORE{w_par_gaincompon[0]}}             )
        ,.i_calOn                      ( {NUM_RX_CORE{w_par_calon[0]}}                  )
        ,.i_calWScale                  ( {NUM_RX_CORE{w_par_calwscale[3:0]}}            )
        ,.i_cpType                     ( w_par_cptype[0]                                )
        ,.i_fftType                    ( w_par_fftsize                                  )
        ,.i_k0                         ( w_par_k0[11:0]                                 )
        ,.i_rb_size                    ( w_par_rbsize[8:0]                              )
        ,.i_cpRmOffset                 ( w_par_cprmoffset[10:0]                         )
        ,.i_phaseCompOn                ( {NUM_RX_CORE{w_par_phasecompon[0]}}            )
        ,.i_cts_on                     ( {NUM_RX_CORE{w_par_ctson[0]}}                  )
        ,.i_cts_shft_vld               ( {NUM_RX_CORE{1'b1}}                            )
        ,.i_cts_shft                   ( {NUM_RX_CORE{w_par_ctsshift[11:0]}}            )
        //    ,.i_phaseW_vld                 ( 'd0                          )
        ,.i_phaseW_i                   ( w_par_phaseI                                   )
        ,.i_phaseW_q                   ( w_par_phaseQ                                   )
        ,.i_cal_wght_addr              (11'd0                                           )
        ,.i_cal_wght_buf_bus           (1'd0                                            )
        ,.i_cal_wght_buf_core          (1'd0                                            )
        ,.i_cal_wght_wren              (1'd0                                            )
        ,.i_cal_wght_rden              (1'd0                                            )
        ,.i_cal_wght_wr_i              ({NUM_RX_CORE*12{1'b0}}                          )  
        ,.i_cal_wght_wr_q              ({NUM_RX_CORE*12{1'b0}}                          )
        ,.o_cal_wght_rd_i              (                                                )
        ,.o_cal_wght_rd_q              (                                                )      
`ifdef ULFE_AIE_8RX_4CHAIN             
        ,.o_cnt_st01_a2p_last          (w_cnt_st01_a2p_last[((gcore*32+0)+32)*(1)-1   :(gcore*32+0)*1    ])                              
        ,.o_cnt_st01_a2p_0dat          (w_cnt_st01_a2p_0dat[((gcore*32+0)+32)*(1)-1   :(gcore*32+0)*1    ])
        ,.o_cnt_fd_0dat                (w_cnt_fd_0dat      [((gcore*32+0)+32)*(1)-1   :(gcore*32+0)*1    ])
        ,.i_aie_rst                    (i_aie_rst )
        ,.i_aie_clk                    (i_aie_clk )
        ,.i_p2a0_ready                 ( wi_p2a_ready[((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.o_p2a0_valid                 ( wo_p2a_valid[((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.o_p2a0_data                  ( wo_p2a_data [((gcore*NUM_RX_CORE+0)+1)*(64)-1  :(gcore*NUM_RX_CORE+0)*64   ]   )
        ,.o_p2a0_last                  ( wo_p2a_last [((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.o_p2a0_keep                  ( wo_p2a_keep [((gcore*NUM_RX_CORE+0)+1)*(8)-1   :(gcore*NUM_RX_CORE+0)*8    ]   )
        ,.o_a2p0_ready                 ( wo_a2p_ready[((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.i_a2p0_valid                 ( wi_a2p_valid[((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.i_a2p0_data                  ( wi_a2p_data [((gcore*NUM_RX_CORE+0)+1)*(64)-1  :(gcore*NUM_RX_CORE+0)*64   ]   )
        ,.i_a2p0_last                  ( wi_a2p_last [((gcore*NUM_RX_CORE+0)+1)*(1)-1   :(gcore*NUM_RX_CORE+0)*1    ]   )
        ,.i_p2a1_ready                 ( wi_p2a_ready[((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
        ,.o_p2a1_valid                 ( wo_p2a_valid[((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
        ,.o_p2a1_data                  ( wo_p2a_data [((gcore*NUM_RX_CORE+1)+1)*(64)-1  :(gcore*NUM_RX_CORE+1)*64   ]   )
        ,.o_p2a1_last                  ( wo_p2a_last [((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
        ,.o_p2a1_keep                  ( wo_p2a_keep [((gcore*NUM_RX_CORE+1)+1)*(8)-1   :(gcore*NUM_RX_CORE+1)*8    ]   )
        ,.o_a2p1_ready                 ( wo_a2p_ready[((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
        ,.i_a2p1_valid                 ( wi_a2p_valid[((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
        ,.i_a2p1_data                  ( wi_a2p_data [((gcore*NUM_RX_CORE+1)+1)*(64)-1  :(gcore*NUM_RX_CORE+1)*64   ]   )
        ,.i_a2p1_last                  ( wi_a2p_last [((gcore*NUM_RX_CORE+1)+1)*(1)-1   :(gcore*NUM_RX_CORE+1)*1    ]   )
`endif
     );
end
endgenerate

ulfe_output_ctrl #(
    .NUM_ANT(NUM_ANT)
    ,.NUM_CHAIN(NUM_CHAIN)
    ,.TOP_DIO_BW(TOP_DIO_BW)
) ulfe_output_ctrl_instance (
    .i_clk                      (i_clk)
    ,.i_rst                     (i_rst)
    ,.i_sig_ctrl_mode           (w_output_ctrl_mode[1:0])
    ,.i_scstype                 ({1'b0,w_par_scstype})
    ,.i_uin_frame_idx           (i_uin_frame_idx)
    ,.i_pre_proc_sltidx         (w_pre_process_sltIdx[6-1:0])
    ,.i_pre_proc_symidx         (w_pre_process_symIdx[4-1:0])
    
    ,.i_pre_process_out_frm_tick(w_pre_process_frm_tick[0])
    ,.i_pre_process_out_vld     (w_pre_process_out_vld)
    ,.i_pre_process_out_i       (w_pre_process_out_i)
    ,.i_pre_process_out_q       (w_pre_process_out_q)
    ,.o_uout_frame_sync         (o_uout_frame_sync)
    ,.o_uout_frame_idx          (o_uout_frame_idx)
    ,.o_uout_subfrm_idx         (o_uout_subfrm_idx)
    ,.o_uout_slot_idx           (o_uout_slot_idx)
    ,.o_uout_symbol_sync        (o_uout_symbol_sync)
    ,.o_uout_symbol_idx         (o_uout_symbol_idx)
    ,.o_uout_en                 (o_uout_en)
    ,.o_uout_iq                 (o_uout_iq)
    ,.o_uout_start_re_idx       (o_uout_start_re_idx)
    ,.o_uout_start_re           (o_uout_start_re)
    ,.o_uout_last_re            (o_uout_last_re)
    //,.o_uout_xssi_en            (w_uout_xssi_en)
    ,.o_xssi                    (w_uout_xssi[32*NUM_ANT-1:0])
    ,.i_frm_chk_gap             (w_frm_chk_gap             )
    ,.o_inout_frm_syncfail_count(w_inout_frm_syncfail_count[31:16])
    ,.o_prev_current_frmidx     (w_prev_current_frmidx)    

);

`ifdef ULFE_SRS
ulfe_srs_output_ctrl #(
    .NUM_ANT(NUM_ANT)
    ,.NUM_CHAIN(NUM_CHAIN)
    ,.TOP_DIO_BW(TOP_DIO_BW)
) ulfesrs_output_ctrl_instance (
    .i_clk                      (i_clk)
    ,.i_rst                     (i_rst)
    ,.i_sig_ctrl_mode           (w_output_ctrl_mode[1:0])
    ,.i_scstype                 ({1'b0,w_par_scstype})
    ,.i_uin_frame_idx           (i_uin_frame_idx)
    ,.i_pre_proc_sltidx         (w_pre_process_sltIdx[6-1:0])
    ,.i_pre_proc_symidx         (w_pre_process_symIdx[4-1:0])
    
    ,.i_dl_start_tick           (w_dly_dl_start_tick)
    ,.i_srs_sym_flag            (w_dly_srs_sym_flag)
    
    ,.i_pre_process_out_frm_tick(w_pre_process_frm_tick[0])
    ,.i_pre_process_out_vld     (w_pre_process_out_vld)
    ,.i_pre_process_out_i       (w_pre_process_out_i)
    ,.i_pre_process_out_q       (w_pre_process_out_q)
    ,.o_srsout_frame_sync       (o_srsout_frame_sync)
    ,.o_srsout_frame_idx        (o_srsout_frame_idx)
    ,.o_srsout_subfrm_idx       (o_srsout_subfrm_idx)
    ,.o_srsout_slot_idx         (o_srsout_slot_idx)
    ,.o_srsout_symbol_sync      (o_srsout_symbol_sync)
    ,.o_srsout_symbol_idx       (o_srsout_symbol_idx)
    ,.o_srsout_en               (o_srsout_en)
    ,.o_srsout_iq               (o_srsout_iq)
    ,.o_srsout_start_re_idx     (o_srsout_start_re_idx)
    ,.o_srsout_start_re         (o_srsout_start_re)
    ,.o_srsout_last_re          (o_srsout_last_re)
    ,.o_srsout_start_tick       (o_srsout_start_tick)
    
    ,.o_xssi                    (w_srsout_xssi[32*NUM_ANT-1:0])
    ,.i_frm_chk_gap             (w_frm_chk_gap             )
    ,.o_inout_frm_syncfail_count()//(w_inout_frm_syncfail_count[31:16])
    ,.o_prev_current_frmidx     ()//(w_prev_current_frmidx)    

);
`endif



`ifdef ULFE_TAGC_TDRSSI

ulfe_tdrssi_rpt #(
    .NUM_ANT(NUM_ANT)
) u_ulfe_tdrssi_rpt (
    .i_clk                  (i_clk),
    .i_rst                  (i_rst),
    .i_tdagc_frm_tick       (w_tdagc_frm_tick[0]),
    .i_tdagc_tdrssi_vld     (w_tdagc_tdrssi_vld),
    .i_tdagc_tdrssi         (w_tdagc_tdrssi),
    
    .i_tdrssi_trigger       (w_par_tdrssiTrigger  [0]  ),                
    .i_tdrssi_start_slt_idx (w_par_tdrssiStartSlot[7-1:0]),        
    .i_tdrssi_start_sym_idx (w_par_tdrssiStartSym [4-1:0]),        
    .i_tdrssi_syms_size     (w_par_tdrssiSymSize  [6-1:0]),       
         
    .i_sel_symidx_tdrssi    (w_par_sel_symidx_tdrssirpt[5:0]),
    .o_tdrssi_rpt_done      (w_tdrssi_rpt_done),
    .o_tdrssi_rpt           (w_tdrssi_rpt)
);

`endif

`ifdef ULFE_CALB_EN
always @(posedge i_clk)
begin
    if(i_rst)
    begin
        r_sel_calwght_evenodd  <=  1'b0;
    end
    else
    begin
        if( (~(^w_calwght_evenodd)) )
        begin
            r_sel_calwght_evenodd  <=  &w_calwght_evenodd;
        end
        else
        begin
            r_sel_calwght_evenodd  <=  r_sel_calwght_evenodd;
        end
    end
end
`endif



`ifndef ULFE_DSS
assign w_dbg_dssCp_alarm = {NUM_CHAIN{5'd0}};
`endif



`ifdef ULFE_outputctrl_ILADBG
ila_ulfe_outctrl u_ila_ulfe_outctrl(
.clk    (i_clk),
.probe0 (o_uout_frame_sync),
.probe1 (o_uout_frame_idx),
.probe2 (o_uout_subfrm_idx),
.probe3 (o_uout_slot_idx),
.probe4 (o_uout_symbol_sync),
.probe5 (o_uout_symbol_idx),
.probe6 (o_uout_en),
.probe7 (o_uout_iq),
.probe8 (o_uout_start_re),
.probe9 (o_uout_last_re)
);

`endif



endmodule
