// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************


/*
-slot length  
-1ms        (SCS=15K)   
-0.5ms      (SCS=30K)
-0.25ms     (SCS=60K)
-0.125ms    (SCS=120K)
-
-sym length  {normal long, normal short, extended}
-(SCS= 15K) : 71.875us, 71.354us, 83.333us
-(SCS= 30K) : 36.198us, 35.677us, 41.667us
-(SCS= 60K) : 18.359us, 17.839us, 20.833us
-(SCS=120K) :  9.440us,  8.919us, 10.417us


-Fs_dat (Fs_adc=245.76Msps)     
SCS\FFT :   0(512)  1(1024) 2(2048) 3(4096)
0( 15K)     7.68    15.36   30.72   61.44
1( 30K)     15.36   30.72   61.44   122.88
2( 60K)     30.72   61.44   122.88  245.76(X)
3(120K)     61.44   122.88  245.76(x)
4(240K)     122.88  245.76(x)

-OVS (Fs_adc=245.76Msps)        
SCS\FFT :   0(512)  1(1024) 2(2048) 3(4096)
0( 15K)     32      16      8       4
1( 30K)     16      8       4       2
2( 60K)     8       4       2       1(x)
3(120K)     4       2       1(x)
4(240K)     2       1(x)

-OVS (Fs_adc=245.76Msps)        
SCS\FFT :   0(512)  1(1024) 2(2048) 3(4096)
0( 15K)     32      16      8       4
1( 30K)     16      8       4       2
2( 60K)     8       4       2       1(x)
3(120K)     4       2       1(x)
4(240K)     2       1(x)


input : i_frm_tick_pre1
output : o_frm_tick_pre1    (input tick + 1 )

#TICK with CP
output : o_slt_tick         (input tick + 2 )
output : o_sym_tick         (input tick + 2 )
output : o_slt_idx          (input tick + 2 )
output : o_sym_idx          (input tick + 2 )

#TICK after CP
output : o_slt_tick         (syncToOFDM_body )
output : o_sym_tick         (syncT0OFDM_body )
output : o_slt_idx          (input tick + 2 )
output : o_sym_idx          (input tick + 2 )

*/

module ulfe_timer #(
     parameter N_CYCLE_CLK      =245760000
    ,parameter SCS_IDX          =1              //{0~4} --> {15k, 30k, 60k, 120k, 240k}
    ,parameter CP_TYPE          =0              //0:normal, 1:extended
    ,parameter CP_TICK          =1
)
(
     input  wire                        i_clk
    ,input  wire                        i_frm_tick_pre1
    ,output wire                        o_frm_tick_pre1 //i_tick+1
    ,output reg                         o_slt_tick      //i_tick+2
    ,output reg                         o_sym_tick      //i_tick+2
    ,output wire        [       6-1:0]  o_slt_idx       //i_tick+2
    ,output wire        [       4-1:0]  o_sym_idx       //i_tick+2
);

function integer clog2;
    input   [31:0]  value;

    begin
        value = value-1;
        
        for(clog2=0; value>0; clog2=clog2+1) begin
            value=value>>1;
        end
    end
endfunction

localparam N_SLT            =10*(2**SCS_IDX);
localparam N_SYM            =(CP_TYPE==0)? 14:12;
localparam MAX_OVS          = 32 / (2**SCS_IDX);        //fftidx=0;
localparam N_MS_CYCLE       = N_CYCLE_CLK / 1000;
localparam N_SLT_CYCLE      = N_MS_CYCLE / (2**SCS_IDX);
localparam W_SLT_CYCLE      = clog2(N_SLT_CYCLE);
localparam N_NOR_SCP_CYCLE  = MAX_OVS * 144/(2**2);
localparam N_NOR_LCP_CYCLE  = N_NOR_SCP_CYCLE + MAX_OVS * 16*(2**SCS_IDX)/(2**2);
localparam N_EXT_CP_CYCLE   = MAX_OVS * 512/(2**2);
localparam N_NOR_LSYM_CYCLE = MAX_OVS * 512 + N_NOR_LCP_CYCLE;
localparam N_NOR_SSYM_CYCLE = MAX_OVS * 512 + N_NOR_SCP_CYCLE;
localparam N_EXT_SYM_CYCLE  = MAX_OVS * 512 + N_EXT_CP_CYCLE;
localparam MAX_N_SYM_CYCLE  = (N_NOR_LSYM_CYCLE > N_EXT_SYM_CYCLE)? N_NOR_LSYM_CYCLE : N_EXT_SYM_CYCLE;
localparam W_SYM_CYCLE      = clog2(MAX_N_SYM_CYCLE);
localparam N_SYM1_CYCLE     = N_NOR_LSYM_CYCLE;
localparam N_SYM2_CYCLE     = (CP_TYPE==0)? N_NOR_SSYM_CYCLE : N_EXT_SYM_CYCLE;
localparam LEN_LSYM         = N_SYM1_CYCLE;
localparam LEN_SSYM         = N_SYM2_CYCLE;
localparam LEN_LASTSYM      = (CP_TICK==0)? LEN_SSYM : LEN_LSYM;
localparam N_CP1_CYCLE      = N_NOR_LCP_CYCLE;
localparam N_CP2_CYCLE      = (CP_TYPE==0)? N_NOR_SCP_CYCLE : N_EXT_CP_CYCLE;
localparam N_SYM_HALF_MS    = (N_SYM/2)*(2**SCS_IDX);

localparam SYM_LAST_FLG     = 2**(N_SYM-1);
localparam SYM_BITMAP1      = (CP_TYPE==0)? (2**N_SYM_HALF_MS)-2 : (2**N_SYM_HALF_MS)-1;    //bit0 : SYM1(L), bit1 : SYM2(S, extCP)
localparam SYM_BITMAP2      = (CP_TYPE==0)? (2**(N_SYM_HALF_MS-1))-1 : (2**N_SYM_HALF_MS)-1;    //bit0 : SYM1(L), bit1 : SYM2(S, extCP)
localparam SYM_BITMAP       = (CP_TICK==0)? SYM_BITMAP1 : SYM_BITMAP2;

reg                             tick_gen_on          ;
reg     [              6-1:0]   slt_idx_cnt          ;
reg     [              4-1:0]   sym_idx_cnt          ;
reg     [    W_SYM_CYCLE-1:0]   sym_cycle_cnt        ;
reg                             m_sym_tick_pre1_free ;
wire                            m_sym_tick_pre1      ;
reg                             m_frm_tick           ;
reg                             m_slt_tick           ;
reg                             m_sym_tick           ;
reg     [  N_SYM_HALF_MS-1:0]   sym_bit_map          ;          
reg     [          N_SYM-1:0]   sym_last_flg         ;
reg                             m_slt_tick_pre1_free ;

assign  m_sym_tick_pre1     = i_frm_tick_pre1 || (m_sym_tick_pre1_free & tick_gen_on);
assign  o_frm_tick_pre1     = m_frm_tick;
assign  o_slt_idx           = slt_idx_cnt;
assign  o_sym_idx           = sym_idx_cnt;

always @(posedge i_clk) m_frm_tick  <= i_frm_tick_pre1;
always @(posedge i_clk) m_slt_tick  <= i_frm_tick_pre1 || (m_slt_tick_pre1_free & tick_gen_on);
always @(posedge i_clk) m_sym_tick  <= m_sym_tick_pre1;

always @(posedge i_clk) o_slt_tick  <= m_slt_tick;
always @(posedge i_clk) o_sym_tick  <= m_sym_tick;

always @(posedge i_clk) 
begin
    if(i_frm_tick_pre1) tick_gen_on <= 0;
    else                tick_gen_on <= 1;
end

// slot, symbol index counter //
always @(posedge i_clk) begin

    if(m_frm_tick)                  slt_idx_cnt <= 0;
    else if(m_slt_tick)             slt_idx_cnt <= slt_idx_cnt+1;

    if(m_frm_tick || m_slt_tick )   sym_idx_cnt <= 0;
    else if(m_sym_tick)             sym_idx_cnt <= sym_idx_cnt+1;
end

//slot, symbol cycle //
always @(posedge i_clk) begin
    if(i_frm_tick_pre1)         sym_cycle_cnt   <= 1;
    else if(m_sym_tick_pre1)    sym_cycle_cnt   <= 0;
    else if(tick_gen_on)        sym_cycle_cnt   <= sym_cycle_cnt+1;
end



//symbol pattern//
always @(posedge i_clk) begin
    if(i_frm_tick_pre1)         sym_bit_map <= SYM_BITMAP;
    else if(m_sym_tick_pre1)    sym_bit_map <= {sym_bit_map[0], sym_bit_map[N_SYM_HALF_MS-1:1]};  //right shift
end

//slot boundary//
always @(posedge i_clk) begin
    if(i_frm_tick_pre1)         sym_last_flg    <= SYM_LAST_FLG;
    else if(m_sym_tick_pre1)    sym_last_flg    <= {sym_last_flg[0], sym_last_flg[N_SYM-1:1]};  //right shift
    
    if(sym_bit_map[0] && (sym_cycle_cnt == (LEN_SSYM-2)) )          m_sym_tick_pre1_free    <= 1;
    else if((!sym_bit_map[0]) && (sym_cycle_cnt == (LEN_LSYM-2)) )  m_sym_tick_pre1_free    <= 1;
    else                                                            m_sym_tick_pre1_free    <= 0;
end

//slot tick//
always @(posedge i_clk) begin
    if(sym_last_flg[0] && (sym_cycle_cnt == (LEN_LASTSYM-2)) )  m_slt_tick_pre1_free    <= 1;
    else                                                        m_slt_tick_pre1_free    <= 0;
end

endmodule

