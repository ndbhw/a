// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ORAN RU/MISC
//  Module       : ulfe_output_ctrl
//  Author       : dg0110.jo@samsung.com
//  Description  : ulfe output control for ORAN RU/MISC
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.   | Donggeun Jo   | Update achitecture : add num_chain
//  ------------+---------------+-----------------------------------------------
//   2020.07.   | Donggeun Jo   | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "ulfe_cc.vh"


module ulfe_output_ctrl
#(
     parameter  NUM_ANT              =   4
    ,parameter  NUM_CHAIN           =   2 //NUM_ANT/OVS     
    ,parameter  TOP_DIO_BW          =   16
//    ,parameter  OVS                 =   6'd4
)(
        input wire                                      i_clk   
    ,   input wire                                      i_rst
    ,   input wire [1:0]                                i_sig_ctrl_mode
    ,   input wire [2:0]                                i_scstype

    ,   input wire [7:0]                                i_uin_frame_idx
    ,   input wire [6-1:0]                              i_pre_proc_sltidx
    ,   input wire [4-1:0]                              i_pre_proc_symidx
    ,   input wire [0:0]                                i_pre_process_out_frm_tick
    ,   input wire [NUM_ANT-1:0]                        i_pre_process_out_vld
    ,   input wire [NUM_CHAIN*TOP_DIO_BW-1:0]           i_pre_process_out_i
    ,   input wire [NUM_CHAIN*TOP_DIO_BW-1:0]           i_pre_process_out_q
    
,output wire                                        o_uout_frame_sync
,output wire    [7:0]                               o_uout_frame_idx
,output wire    [3:0]                               o_uout_subfrm_idx
,output wire    [5:0]                               o_uout_slot_idx
,output wire                                        o_uout_symbol_sync
,output wire    [3:0]                               o_uout_symbol_idx
,output wire    [NUM_ANT-1:0]                       o_uout_en
,output wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          o_uout_iq
,output wire    [NUM_ANT*16-1:0]                    o_uout_start_re_idx
,output wire    [NUM_ANT*1-1:0]                     o_uout_start_re
,output wire    [NUM_ANT*1-1:0]                     o_uout_last_re

,output wire    [32*NUM_ANT-1:0]                    o_xssi  

    ,input      [31:0]                                  i_frm_chk_gap                 
,output     [15:0]                                  o_inout_frm_syncfail_count    
,output     [31:0]                                  o_prev_current_frmidx                 


);

localparam OSR = (NUM_ANT / NUM_CHAIN);
localparam sync_dly = 3'd4;
                
genvar gcore;
integer k;                
                                                        
wire                        w_frame_sync                ;           
wire                        w_subfrm_sync               ;          
wire                        w_slot_sync                 ;       
wire                        w_symbol_sync               ;       
wire    [3:0]               w_subfrm_idx                ;         
wire    [7:0]               w_slot_idx                  ;        
wire    [3:0]               w_symbol_idx                ;
reg     [NUM_ANT-1:0]       r_pre_process_out_vld       ;
reg     [TOP_DIO_BW-1:0]    r_pre_process_out_i [NUM_CHAIN-1:0]     ; 
reg     [TOP_DIO_BW-1:0]    r_pre_process_out_q [NUM_CHAIN-1:0]     ;
reg     [NUM_ANT-1:0]       r_ulfe_out_vld              ;
reg     [TOP_DIO_BW-1:0]    r_ulfe_out_i [NUM_CHAIN-1:0]            ; 
reg     [TOP_DIO_BW-1:0]    r_ulfe_out_q [NUM_CHAIN-1:0]            ;
wire    [NUM_ANT-1:0]       w_xssi_en                   ;
wire    [32-1:0]            w_xssi  [NUM_ANT-1:0]       ;
reg     [32-1:0]            r_xssi  [NUM_ANT-1:0]       ;

reg    [NUM_ANT-1:0]       r_puxch_sos  ;
reg    [NUM_ANT-1:0]       r_puxch_eos  ;
wire   [NUM_ANT-1:0]       w_puxch_eos  ;



reg [16 -1:0]   r_smp_cnt;

always @(posedge i_clk) begin
    if((|w_puxch_eos)|i_pre_process_out_frm_tick) begin
        r_smp_cnt   <= 16'd0;
    end
    else if(|i_pre_process_out_vld) begin
        r_smp_cnt   <= r_smp_cnt + 16'b1;
    end
    else begin
        r_smp_cnt   <= r_smp_cnt;
    end
end


always @(posedge i_clk)
begin
    if(i_sig_ctrl_mode==2'd1)
    begin
        r_pre_process_out_vld   <=  i_pre_process_out_vld;
        for(k=0 ; k<NUM_CHAIN ; k=k+1)
        begin
            r_pre_process_out_i[k]     <=  16'd0;
            r_pre_process_out_q[k]     <=  16'd0;
        end
    end
    else if(i_sig_ctrl_mode==2'd2)
    begin
        r_pre_process_out_vld   <=  i_pre_process_out_vld;//{NUM_ANT{1'b1}};//
        for(k=0 ; k<NUM_CHAIN ; k=k+1)
        begin
            r_pre_process_out_i[k]     <=  {{2'b00},i_pre_proc_sltidx,4'b0000,i_pre_proc_symidx};
            r_pre_process_out_q[k]     <=  {r_smp_cnt};
        end
    end
    else
    begin
        r_pre_process_out_vld   <=  i_pre_process_out_vld;
        for(k=0 ; k<NUM_CHAIN ; k=k+1)
        begin
            r_pre_process_out_i[k]     <=  i_pre_process_out_i[k*TOP_DIO_BW +: TOP_DIO_BW];
            r_pre_process_out_q[k]     <=  i_pre_process_out_q[k*TOP_DIO_BW +: TOP_DIO_BW];
         end
    end
end 


always @(posedge i_clk)
begin
    r_ulfe_out_vld   <=  r_pre_process_out_vld;   
    for(k=0 ; k<NUM_CHAIN ; k=k+1)
    begin
        r_ulfe_out_i[k]  <=  r_pre_process_out_i[k]  ;
        r_ulfe_out_q[k]  <=  r_pre_process_out_q[k]  ;
    end
end

always @(posedge i_clk)
begin
    r_puxch_sos     <=  (r_pre_process_out_vld & (~r_ulfe_out_vld));
//    r_puxch_eos     <=  (~i_pre_process_out_vld & r_pre_process_out_vld  );
end
assign w_puxch_eos  =   (~r_pre_process_out_vld & r_ulfe_out_vld  );

reg     [NUM_ANT-1:0]                   r_uout_en               ;
reg     [2*NUM_ANT*TOP_DIO_BW-1:0]      r_uout_iq               ;
reg     [NUM_ANT-1:0]                   r_uout_puxch_sos        ;
reg     [NUM_ANT-1:0]                   r_uout_puxch_eos        ;
wire    [NUM_ANT-1:0]                   w_uout_en               ;
wire    [2*NUM_ANT*TOP_DIO_BW-1:0]      w_uout_iq               ;
wire    [NUM_ANT-1:0]                   w_uout_puxch_sos        ;
wire    [NUM_ANT-1:0]                   w_uout_puxch_eos        ;

always @(posedge i_clk)
begin
    if(i_rst)
    begin
        r_uout_en   <= 0;
        r_uout_iq   <= 0;       
    end                                 
    else
    begin
        for(k=0 ; k<NUM_ANT ; k=k+1)
        begin
            r_uout_iq[2*TOP_DIO_BW*k +: 2*TOP_DIO_BW] <= {r_ulfe_out_i[(k/OSR)],r_ulfe_out_q[(k/OSR)]};
        end
        r_uout_en           <=  r_ulfe_out_vld[NUM_ANT-1:0];
        r_uout_puxch_sos    <=  r_puxch_sos;
        r_uout_puxch_eos    <=  w_puxch_eos;  //r_puxch_eos;
        
    end
end

ylib_reg #(
    .WIDTH(NUM_ANT+2*NUM_ANT*TOP_DIO_BW+NUM_ANT+NUM_ANT),
    .DEPTH(sync_dly-3'd3)
) ylib_reg_dly_uout (
    .i_clk(i_clk),
    .i_in({r_uout_en,r_uout_iq,r_uout_puxch_sos,r_uout_puxch_eos}),
    .o_out({w_uout_en,w_uout_iq,w_uout_puxch_sos,w_uout_puxch_eos})
);


ref_vsync_gen ref_vsync_gen_instance (
    .i_clk          (i_clk),
    .i_mu           ({1'b0,i_scstype}),     // 0:15, 1:30, 2:60 ... TBD
    .i_retard       ({{19{1'b0}},sync_dly}),    // dly 3clk
    .i_frame_sync   (i_pre_process_out_frm_tick),
    .i_en           (1'b1),
    .o_frame_sync   (w_frame_sync),
    .o_subfrm_sync  (w_subfrm_sync),
    .o_slot_sync    (w_slot_sync),
    .o_symbol_sync  (w_symbol_sync),
    .o_subfrm       (w_subfrm_idx),
    .o_slot         (w_slot_idx),
    .o_symbol       (w_symbol_idx)
);

wire        w_pre_process_out_frm_tick;
reg [7:0]   r_frm_idx;
reg [7:0]   rprev_frm_idx;

ylib_pshift #(.BW_SHIFT($clog2(sync_dly+1))) ylib_pshift_instance 
(
.i_clk(i_clk),    .i_shift(sync_dly),    .i_in(i_pre_process_out_frm_tick),    .o_out(w_pre_process_out_frm_tick)
);

always @(posedge i_clk)
begin
    if(w_pre_process_out_frm_tick)
    begin
        r_frm_idx       <= i_uin_frame_idx;
        rprev_frm_idx   <=  r_frm_idx;
    end
end



assign o_uout_frame_sync        =    w_frame_sync       ;         
assign o_uout_frame_idx         =    r_frm_idx          ; 
assign o_uout_subfrm_idx        =    w_subfrm_idx       ; 
assign o_uout_slot_idx          =    (i_scstype==3'd0)?{6'd0} : (i_scstype==3'd1)?{5'd0,w_slot_idx[0:0]} : (i_scstype==3'd2)?{4'd0,w_slot_idx[1:0]} : w_slot_idx[5:0]    ; 
assign o_uout_symbol_sync       =    w_symbol_sync      ;
assign o_uout_symbol_idx        =    w_symbol_idx       ; 
assign o_uout_en                =    w_uout_en          ; 
assign o_uout_iq                =    w_uout_iq          ; 
assign o_uout_start_re_idx      =    0; 
assign o_uout_start_re          =    w_uout_puxch_sos   ;   
assign o_uout_last_re           =    w_uout_puxch_eos   ; 


genvar i;

`ifndef FD_RSSI_disable
generate for(i=0; i<NUM_ANT; i=i+1) 
begin : output_rssi    

    ylib_xssi #(
        .NUM_FRAME(7'd1),
        .RPT_FRAME(7'd0),
        .BW_SIG(TOP_DIO_BW-1),
        .ID_XSSI(0)
    ) ylib_xssi_instance (
        .i_rst(i_rst),
        .i_clk(i_clk),
        .i_frame_sync(w_pre_process_out_frm_tick),
        .i_sig_en(r_ulfe_out_vld[i]),
        .i_sig_i(r_ulfe_out_i[((i/OSR))][TOP_DIO_BW-2 : 0]),
        .i_sig_q(r_ulfe_out_q[((i/OSR))][TOP_DIO_BW-2 : 0]),
        .o_xssi_id(),
        .o_xssi_en      (w_xssi_en[i]),
        .o_xssi         (w_xssi[i])
    );
end
endgenerate
`endif

always @(posedge i_clk) begin
    for(k=0 ; k<NUM_ANT ; k=k+1)
    if(w_xssi_en[k])
        r_xssi[k] <= w_xssi[k];
end


generate for (i=0 ; i<NUM_ANT ; i=i+1)
begin
    assign o_xssi[(i+1)*2*TOP_DIO_BW-1:(i)*2*TOP_DIO_BW] = r_xssi[i];
end
endgenerate



////DBG

wire dbg_pre_process_out_frm_tick;
localparam dbg_sync_dly = 3'd5;
ylib_pshift #(.BW_SHIFT($clog2(dbg_sync_dly+3'd1))) ylib_pshift_instance_dbgsync
(
.i_clk(i_clk),    .i_shift(dbg_sync_dly),    .i_in(w_pre_process_out_frm_tick),    .o_out(dbg_pre_process_out_frm_tick)
);



reg [31:0] r_frm_chk_gap;
always @(posedge i_clk)
begin
    r_frm_chk_gap   <= i_frm_chk_gap;
end

reg [21:0] cnt_245mh76_10ms;
reg [15:0] syncfail_10ms_count;
reg [15:0] syncfail_prev_frmidx;
reg [15:0] syncfail_current_frmidx;
reg [15:0] r_syncfail_10ms_count;
reg [15:0] r_syncfail_prev_frmidx;
reg [15:0] r_syncfail_current_frmidx;

always @(posedge i_clk)
begin
    if(dbg_pre_process_out_frm_tick)
        cnt_245mh76_10ms <= 22'd0;
    else
        cnt_245mh76_10ms <= cnt_245mh76_10ms + 22'd1;    
end

always @(posedge i_clk)
begin
    if(i_rst)
    begin
        syncfail_10ms_count     <= 16'd0;
        syncfail_prev_frmidx    <= 16'd0;
        syncfail_current_frmidx <= 16'd0;
    end
    else if(dbg_pre_process_out_frm_tick)
    begin
        if(cnt_245mh76_10ms >= 22'd2457600-22'd1-r_frm_chk_gap[21:0] && cnt_245mh76_10ms <= 22'd2457600-22'd1+r_frm_chk_gap[21:0] ) 
        begin       
            syncfail_10ms_count     <= syncfail_10ms_count;
            syncfail_prev_frmidx    <= syncfail_prev_frmidx;
            syncfail_current_frmidx <= syncfail_current_frmidx;

        end
        else
        begin
            syncfail_10ms_count     <= syncfail_10ms_count + 16'd1;
            syncfail_prev_frmidx    <= {8'd0,rprev_frm_idx};
            syncfail_current_frmidx <= {8'd0,r_frm_idx};
        end
    end
    else         
    begin
        syncfail_10ms_count     <= syncfail_10ms_count;
        syncfail_prev_frmidx    <= syncfail_prev_frmidx;
        syncfail_current_frmidx <= syncfail_current_frmidx;
    end
end

always @(posedge i_clk)
begin
    r_syncfail_10ms_count       <=  syncfail_10ms_count    ;         
    r_syncfail_prev_frmidx      <=  syncfail_prev_frmidx   ;
    r_syncfail_current_frmidx   <=  syncfail_current_frmidx;
end



assign o_inout_frm_syncfail_count   = r_syncfail_10ms_count;
assign o_prev_current_frmidx        = {r_syncfail_prev_frmidx,r_syncfail_current_frmidx};
////DBG



endmodule
