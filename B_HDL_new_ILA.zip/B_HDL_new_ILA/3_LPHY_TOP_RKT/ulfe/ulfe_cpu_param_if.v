// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : template_cpu_param_if 
//  Author       : jyzoo.lee@samsung.com
//  Description  : Template Code for cpu parameter interface
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

`include "ulfe_cc.vh"

module ulfe_cpu_param_if
#(
    parameter   ADDR_OFFSET         =       0           
   ,parameter   DLY_REG_RD          =       7           
   ,parameter   AW                  =      16       // CPU IF Address Bit Width
   ,parameter   DW                  =      32       // CPU IF Data Bit Width 
   ,parameter   UL_NUM_ANT          =       4
   ,parameter   NUM_CHAIN           =       4
//   ,parameter MAX_SCS_u_ULFE        =       0
)(
    //--- reset & clk
        input   wire                                i_clk                      
    ,   input   wire                                i_rst

    //--- cpu interface
    ,   input   wire    [AW-1:0]                    i_cpu_addr
    ,   input   wire    [0:0]                       i_cpu_wren
    ,   input   wire    [DW-1:0]                    i_cpu_wdata
    ,   input   wire    [0:0]                       i_cpu_rden
    ,   output  wire    [DW-1:0]                    o_cpu_rdata
    ,   output  wire    [0:0]                       o_cpu_rd_valid
`ifdef ULFE_CALB_EN
    ,   input   wire    [NUM_CHAIN-1:0]             i_calb_cpu_rvalid
    ,   input   wire    [(NUM_CHAIN*32)-1:0]        i_calb_cpu_rdata
    ,   input   wire    [9-1:0]                     i_calwght_evenodd_sel
`endif    
    //--- Parsed parameter 
    ,   output  reg     [31:0]                      o_input_ctrl_mode
    ,   output  reg     [31:0]                      o_input_tp_mode
    ,   output  reg     [31:0]                      o_output_ctrl_mode
    
    ,   output  reg     [31:0]                      o_par_freqshifton
    ,   output  reg     [31:0]                      o_par_cpType     
    ,   output  reg     [31:0]                      o_par_cpRmOffset 
    ,   output  reg     [31:0]                      o_par_tagcOn     
    ,   output  reg     [31:0]                      o_par_tagcBackoff
    ,   output  reg     [31:0]                      o_par_k0         
    ,   output  reg     [31:0]                      o_par_rbSize     
    ,   output  reg     [31:0]                      o_par_gainCompOn 
    ,   output  reg     [31:0]                      o_par_ctsOn      
    ,   output  reg     [31:0]                      o_par_ctsShift       
    ,   output  reg     [31:0]                      o_par_phaseCompOn
    ,   output  reg     [31:0]                      o_par_mpfrmstruct
    ,   output  reg      [1:0]                      o_par_mpfrmstruct_fftsize
    ,   output  reg      [1:0]                      o_par_mpfrmstruct_scstype
    ,   output  reg     [31:0]                      o_par_tdrssiTrigSlot  
    ,   output  reg     [31:0]                      o_par_tdrssiTrigSym   
    ,   output  reg     [31:0]                      o_par_tdrssiStartSlot 
    ,   output  reg     [31:0]                      o_par_tdrssiStartSym  
    ,   output  reg     [31:0]                      o_par_tdrssiSymSize   
    ,   output  reg     [31:0]                      o_par_tdrssiTrigger   
    ,   output  reg     [31:0]                      o_par_sel_symidx_tdrssirpt                                                                                                                 
    ,   input            [0:0]                      i_tdrssi_rpt_done
    ,   input      [64*32-1:0]                      i_tdrssi_rpt
    ,   output  reg     [31:0]                      o_par_numMdmPath                                                                                                        
    ,   output  reg     [31:0]                      o_par_numAnt         

    ,   output  reg     [16*14*(2**`MAX_SCS_u_ULFE)-1:0]             o_par_Phase_I    
    ,   output  reg     [16*14*(2**`MAX_SCS_u_ULFE)-1:0]             o_par_Phase_Q    

    
    ,   output  reg     [31:0]                      o_par_calon
    ,   output  reg     [31:0]                      o_par_calwscale
    ,   output  reg     [31:0]                      o_sel_calb_rx
    
    //--- Report Register
//    ,   input   wire    [31:0]                      i_rpt_p2000
//    ,   input   wire    [31:0]                      i_rpt_p2001
//    ,   input   wire    [31:0]                      i_rpt_p2002
//    ,   input   wire    [31:0]                      i_rpt_p2003
//    ,   input   wire    [31:0]                      i_rpt_p2004
    ,   input   wire    [32*UL_NUM_ANT-1:0]        i_rpt_uin_xssi
    ,   input   wire    [32*UL_NUM_ANT-1:0]        i_rpt_uout_xssi

    
    //--- Monitoring Register
    ,   input  wire   [8-1:0]                       i_uin_en
    ,   output  reg     [31:0]                      o_frm_chk_gap
    ,   input   wire    [31:0]                      i_inout_frm_syncfail_count
    ,   input   wire    [31:0]                      i_prev_current_frmidx
    ,   input   wire    [31:0]                      i_inputsync_time_stamp
    ,   input   wire    [31:0]                      i_p2a_ready_fft
    ,   input   wire    [31:0]                      i_a2p_valid_fft
    ,   input   wire    [32*4-1:0]                  i_cnt_st01_a2p_last                                        
    ,   input   wire    [32*4-1:0]                  i_cnt_st01_a2p_0dat  
    ,   input   wire    [32*4-1:0]                  i_cnt_fd_0dat     
    
    //--- Cp monitoring
    ,   input   wire    [4:0]                       i_dbg_dssCp_alarm
);


reg [ 8-1:0]    r_uin_en_exist;
reg [32-1:0]    r_p2a_ready_fft;
reg [32-1:0]    r_a2p_valid_fft;
reg [   0:0]    r_tdrssi_rpt_done;
reg [   0:0]    r_dss_cp_alarm;

//Logic Variable
genvar gidx ;

reg [AW-1:0]  r_cpu_addr                        ;    
reg [   0:0]  r_cpu_wren                        ;
reg [DW-1:0]  r_cpu_wdata                       ;
reg [   0:0]  r_cpu_rden                        ;
always@(posedge i_clk) begin
    if(i_cpu_wren) begin
        r_cpu_wren      <=    i_cpu_wren    ;
        r_cpu_wdata     <=    i_cpu_wdata   ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else if(i_cpu_rden) begin
        r_cpu_rden      <=    i_cpu_rden    ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else begin
        r_cpu_wren      <=    1'd0    ;
        r_cpu_rden      <=    1'd0    ;
    end
end

//reg [   1       -1:0]  rr_cpu_rden [2   -1:0] ;
//reg [  AW       -1:0]  rr_cpu_addr [2   -1:0] ; 
//
//always@(posedge i_clk) begin
//    if(r_cpu_rden) begin
//        rr_cpu_rden[0] <=     r_cpu_rden    ;
//        rr_cpu_addr[0] <=     r_cpu_addr    ; 
//        rr_cpu_rden[1] <=     r_cpu_rden    ;
//        rr_cpu_addr[1] <=     r_cpu_addr    ; 
//    end
//    else begin
//        rr_cpu_rden[0] <=     1'b0    ;
//        rr_cpu_rden[1] <=     1'b0    ;
//    end
//end

//demux & parsing
always@(posedge i_clk) begin
    if(i_rst) begin
        o_par_cpType                <= 32'h00000000;
        o_par_tagcOn                <= 32'h00000001;
        o_par_k0                    <= 32'h00000000;
        o_par_gainCompOn            <= 32'h00000001;
        o_par_ctsOn                 <= 32'h00000001;
        o_par_phaseCompOn           <= 32'h00000001;
        o_par_calwscale             <= 32'h00000008;
        
        o_input_ctrl_mode           <= 32'h00000000;
        o_input_tp_mode             <= 32'h00000000;
        o_output_ctrl_mode          <= 32'h00000000;
        o_frm_chk_gap               <= 32'h00000000;
        
       
`ifdef ULFE_LTE   
       {o_par_Phase_I[15:0]   ,o_par_Phase_Q[15:0]   } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[31:16]  ,o_par_Phase_Q[31:16]  } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[47:32]  ,o_par_Phase_Q[47:32]  } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[63:48]  ,o_par_Phase_Q[63:48]  } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[79:64]  ,o_par_Phase_Q[79:64]  } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[95:80]  ,o_par_Phase_Q[95:80]  } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[111:96] ,o_par_Phase_Q[111:96] } <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[127:112],o_par_Phase_Q[127:112]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[143:128],o_par_Phase_Q[143:128]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[159:144],o_par_Phase_Q[159:144]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[175:160],o_par_Phase_Q[175:160]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[191:176],o_par_Phase_Q[191:176]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[207:192],o_par_Phase_Q[207:192]} <= {16'h4000,16'h0000}; 
       {o_par_Phase_I[223:208],o_par_Phase_Q[223:208]} <= {16'h4000,16'h0000}; 
`endif       
        
    end
    else if(r_cpu_wren) begin
        case(r_cpu_addr)
            ADDR_OFFSET+{16'h0040}    :   o_input_ctrl_mode       <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0044}    :   o_input_tp_mode         <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0048}    :   o_output_ctrl_mode      <=  r_cpu_wdata ;  
            
            ADDR_OFFSET+{16'h0200}    :   o_par_freqshifton       <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0204}    :   o_par_cpType            <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0208}    :   o_par_cpRmOffset        <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h020C}    :   o_par_tagcOn            <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0210}    :   o_par_tagcBackoff       <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0214}    :   o_par_k0                <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0218}    :   o_par_rbSize            <=  r_cpu_wdata ;          
            ADDR_OFFSET+{16'h021C}    :   o_par_gainCompOn        <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0220}    :   o_par_ctsOn             <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0224}    :   o_par_ctsShift          <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h0228}    :   o_par_phaseCompOn       <=  r_cpu_wdata ;  
            ADDR_OFFSET+{16'h022C}    :   begin   
                                            o_par_mpfrmstruct       <=  r_cpu_wdata ;  
                                            o_par_mpfrmstruct_fftsize <= r_cpu_wdata[5:4] ;
                                            o_par_mpfrmstruct_scstype <= r_cpu_wdata[1:0] ;
                                        end            
            ADDR_OFFSET+{16'h0230}    :   o_par_tdrssiTrigSlot    <=  r_cpu_wdata ;    
            ADDR_OFFSET+{16'h0234}    :   o_par_tdrssiTrigSym     <=  r_cpu_wdata ;     
            ADDR_OFFSET+{16'h0238}    :   o_par_tdrssiStartSlot   <=  r_cpu_wdata ;   
            ADDR_OFFSET+{16'h023C}    :   o_par_tdrssiStartSym    <=  r_cpu_wdata ;    
            ADDR_OFFSET+{16'h0240}    :   o_par_tdrssiSymSize     <=  r_cpu_wdata ;    
            ADDR_OFFSET+{16'h0244}    :   o_par_tdrssiTrigger     <=  r_cpu_wdata ;    
            ADDR_OFFSET+{16'h0248}    :   o_par_sel_symidx_tdrssirpt <=  r_cpu_wdata ;    



            
            ADDR_OFFSET+{16'h0800}    :   o_par_numMdmPath        <=  r_cpu_wdata ;    
            ADDR_OFFSET+{16'h0804}    :   o_par_numAnt            <=  r_cpu_wdata ;    
             
            ADDR_OFFSET+{16'h0600}    :   {o_par_Phase_I[15:0]   ,o_par_Phase_Q[15:0]   } <=  r_cpu_wdata ;     //0_0    //o_par_Phase0                
            ADDR_OFFSET+{16'h0604}    :   {o_par_Phase_I[31:16]  ,o_par_Phase_Q[31:16]  } <=  r_cpu_wdata ;     //0_1    //o_par_Phase1            
            ADDR_OFFSET+{16'h0608}    :   {o_par_Phase_I[47:32]  ,o_par_Phase_Q[47:32]  } <=  r_cpu_wdata ;     //0_2    //o_par_Phase2            
            ADDR_OFFSET+{16'h060C}    :   {o_par_Phase_I[63:48]  ,o_par_Phase_Q[63:48]  } <=  r_cpu_wdata ;     //0_3    //o_par_Phase3            
            ADDR_OFFSET+{16'h0610}    :   {o_par_Phase_I[79:64]  ,o_par_Phase_Q[79:64]  } <=  r_cpu_wdata ;     //0_4    //o_par_Phase4            
            ADDR_OFFSET+{16'h0614}    :   {o_par_Phase_I[95:80]  ,o_par_Phase_Q[95:80]  } <=  r_cpu_wdata ;     //0_5    //o_par_Phase5            
            ADDR_OFFSET+{16'h0618}    :   {o_par_Phase_I[111:96] ,o_par_Phase_Q[111:96] } <=  r_cpu_wdata ;     //0_6    //o_par_Phase6                
            ADDR_OFFSET+{16'h061C}    :   {o_par_Phase_I[127:112],o_par_Phase_Q[127:112]} <=  r_cpu_wdata ;     //0_7    //o_par_Phase7            
            ADDR_OFFSET+{16'h0620}    :   {o_par_Phase_I[143:128],o_par_Phase_Q[143:128]} <=  r_cpu_wdata ;     //0_8    //o_par_Phase8            
            ADDR_OFFSET+{16'h0624}    :   {o_par_Phase_I[159:144],o_par_Phase_Q[159:144]} <=  r_cpu_wdata ;     //0_9    //o_par_Phase9            
            ADDR_OFFSET+{16'h0628}    :   {o_par_Phase_I[175:160],o_par_Phase_Q[175:160]} <=  r_cpu_wdata ;     //0_10   //o_par_Phase10           
            ADDR_OFFSET+{16'h062C}    :   {o_par_Phase_I[191:176],o_par_Phase_Q[191:176]} <=  r_cpu_wdata ;     //0_11   //o_par_Phase11           
            ADDR_OFFSET+{16'h0630}    :   {o_par_Phase_I[207:192],o_par_Phase_Q[207:192]} <=  r_cpu_wdata ;     //0_12   //o_par_Phase12               
            ADDR_OFFSET+{16'h0634}    :   {o_par_Phase_I[223:208],o_par_Phase_Q[223:208]} <=  r_cpu_wdata ;     //0_13   //o_par_Phase13           
`ifndef SCS1_u_ULFE_disable
            ADDR_OFFSET+{16'h0638}    :   {o_par_Phase_I[239:224],o_par_Phase_Q[239:224]} <=  r_cpu_wdata ;     //1_0    //o_par_Phase0                
            ADDR_OFFSET+{16'h063C}    :   {o_par_Phase_I[255:240],o_par_Phase_Q[255:240]} <=  r_cpu_wdata ;     //1_1    //o_par_Phase1            
            ADDR_OFFSET+{16'h0640}    :   {o_par_Phase_I[271:256],o_par_Phase_Q[271:256]} <=  r_cpu_wdata ;     //1_2    //o_par_Phase2            
            ADDR_OFFSET+{16'h0644}    :   {o_par_Phase_I[287:272],o_par_Phase_Q[287:272]} <=  r_cpu_wdata ;     //1_3    //o_par_Phase3            
            ADDR_OFFSET+{16'h0648}    :   {o_par_Phase_I[303:288],o_par_Phase_Q[303:288]} <=  r_cpu_wdata ;     //1_4    //o_par_Phase4            
            ADDR_OFFSET+{16'h064C}    :   {o_par_Phase_I[319:304],o_par_Phase_Q[319:304]} <=  r_cpu_wdata ;     //1_5    //o_par_Phase5            
            ADDR_OFFSET+{16'h0650}    :   {o_par_Phase_I[335:320],o_par_Phase_Q[335:320]} <=  r_cpu_wdata ;     //1_6    //o_par_Phase6                
            ADDR_OFFSET+{16'h0654}    :   {o_par_Phase_I[351:336],o_par_Phase_Q[351:336]} <=  r_cpu_wdata ;     //1_7    //o_par_Phase7            
            ADDR_OFFSET+{16'h0658}    :   {o_par_Phase_I[367:352],o_par_Phase_Q[367:352]} <=  r_cpu_wdata ;     //1_8    //o_par_Phase8            
            ADDR_OFFSET+{16'h065C}    :   {o_par_Phase_I[383:368],o_par_Phase_Q[383:368]} <=  r_cpu_wdata ;     //1_9    //o_par_Phase9            
            ADDR_OFFSET+{16'h0660}    :   {o_par_Phase_I[399:384],o_par_Phase_Q[399:384]} <=  r_cpu_wdata ;     //1_10   //o_par_Phase10           
            ADDR_OFFSET+{16'h0664}    :   {o_par_Phase_I[415:400],o_par_Phase_Q[415:400]} <=  r_cpu_wdata ;     //1_11   //o_par_Phase11           
            ADDR_OFFSET+{16'h0668}    :   {o_par_Phase_I[431:416],o_par_Phase_Q[431:416]} <=  r_cpu_wdata ;     //1_12   //o_par_Phase12               
            ADDR_OFFSET+{16'h066C}    :   {o_par_Phase_I[447:432],o_par_Phase_Q[447:432]} <=  r_cpu_wdata ;     //1_13   //o_par_Phase13           
`endif
`ifndef SCS2_u_ULFE_disable
            ADDR_OFFSET+{16'h0670}    :   {o_par_Phase_I[463:448],o_par_Phase_Q[463:448]} <=  r_cpu_wdata ;     //2_0    //o_par_Phase0                
            ADDR_OFFSET+{16'h0674}    :   {o_par_Phase_I[479:464],o_par_Phase_Q[479:464]} <=  r_cpu_wdata ;     //2_1    //o_par_Phase1            
            ADDR_OFFSET+{16'h0678}    :   {o_par_Phase_I[495:480],o_par_Phase_Q[495:480]} <=  r_cpu_wdata ;     //2_2    //o_par_Phase2            
            ADDR_OFFSET+{16'h067C}    :   {o_par_Phase_I[511:496],o_par_Phase_Q[511:496]} <=  r_cpu_wdata ;     //2_3    //o_par_Phase3            
            ADDR_OFFSET+{16'h0680}    :   {o_par_Phase_I[527:512],o_par_Phase_Q[527:512]} <=  r_cpu_wdata ;     //2_4    //o_par_Phase4            
            ADDR_OFFSET+{16'h0684}    :   {o_par_Phase_I[543:528],o_par_Phase_Q[543:528]} <=  r_cpu_wdata ;     //2_5    //o_par_Phase5            
            ADDR_OFFSET+{16'h0688}    :   {o_par_Phase_I[559:544],o_par_Phase_Q[559:544]} <=  r_cpu_wdata ;     //2_6    //o_par_Phase6                
            ADDR_OFFSET+{16'h068C}    :   {o_par_Phase_I[575:560],o_par_Phase_Q[575:560]} <=  r_cpu_wdata ;     //2_7    //o_par_Phase7            
            ADDR_OFFSET+{16'h0690}    :   {o_par_Phase_I[591:576],o_par_Phase_Q[591:576]} <=  r_cpu_wdata ;     //2_8    //o_par_Phase8            
            ADDR_OFFSET+{16'h0694}    :   {o_par_Phase_I[607:592],o_par_Phase_Q[607:592]} <=  r_cpu_wdata ;     //2_9    //o_par_Phase9            
            ADDR_OFFSET+{16'h0698}    :   {o_par_Phase_I[623:608],o_par_Phase_Q[623:608]} <=  r_cpu_wdata ;     //2_10   //o_par_Phase10           
            ADDR_OFFSET+{16'h069C}    :   {o_par_Phase_I[639:624],o_par_Phase_Q[639:624]} <=  r_cpu_wdata ;     //2_11   //o_par_Phase11           
            ADDR_OFFSET+{16'h06A0}    :   {o_par_Phase_I[655:640],o_par_Phase_Q[655:640]} <=  r_cpu_wdata ;     //2_12   //o_par_Phase12       
            ADDR_OFFSET+{16'h06A4}    :   {o_par_Phase_I[671:656],o_par_Phase_Q[671:656]} <=  r_cpu_wdata ;     //2_13   //o_par_Phase13       
            ADDR_OFFSET+{16'h06A8}    :   {o_par_Phase_I[687:672],o_par_Phase_Q[687:672]} <=  r_cpu_wdata ;     //3_0    //_par_Phase0         
            ADDR_OFFSET+{16'h06AC}    :   {o_par_Phase_I[703:688],o_par_Phase_Q[703:688]} <=  r_cpu_wdata ;     //3_1    //_par_Phase1         
            ADDR_OFFSET+{16'h06B0}    :   {o_par_Phase_I[719:704],o_par_Phase_Q[719:704]} <=  r_cpu_wdata ;     //3_2    //_par_Phase2         
            ADDR_OFFSET+{16'h06B4}    :   {o_par_Phase_I[735:720],o_par_Phase_Q[735:720]} <=  r_cpu_wdata ;     //3_3    //_par_Phase3         
            ADDR_OFFSET+{16'h06B8}    :   {o_par_Phase_I[751:736],o_par_Phase_Q[751:736]} <=  r_cpu_wdata ;     //3_4    //_par_Phase4         
            ADDR_OFFSET+{16'h06BC}    :   {o_par_Phase_I[767:752],o_par_Phase_Q[767:752]} <=  r_cpu_wdata ;     //3_5    //_par_Phase5         
            ADDR_OFFSET+{16'h06C0}    :   {o_par_Phase_I[783:768],o_par_Phase_Q[783:768]} <=  r_cpu_wdata ;     //3_6    //o_par_Phase6        
            ADDR_OFFSET+{16'h06C4}    :   {o_par_Phase_I[799:784],o_par_Phase_Q[799:784]} <=  r_cpu_wdata ;     //3_7    //o_par_Phase7        
            ADDR_OFFSET+{16'h06C8}    :   {o_par_Phase_I[815:800],o_par_Phase_Q[815:800]} <=  r_cpu_wdata ;     //3_8    //o_par_Phase8        
            ADDR_OFFSET+{16'h06CC}    :   {o_par_Phase_I[831:816],o_par_Phase_Q[831:816]} <=  r_cpu_wdata ;     //3_9    //o_par_Phase9        
            ADDR_OFFSET+{16'h06D0}    :   {o_par_Phase_I[847:832],o_par_Phase_Q[847:832]} <=  r_cpu_wdata ;     //3_10   //o_par_Phase10           
            ADDR_OFFSET+{16'h06D4}    :   {o_par_Phase_I[863:848],o_par_Phase_Q[863:848]} <=  r_cpu_wdata ;     //3_11   //o_par_Phase11           
            ADDR_OFFSET+{16'h06D8}    :   {o_par_Phase_I[879:864],o_par_Phase_Q[879:864]} <=  r_cpu_wdata ;     //3_12   //o_par_Phase12               
            ADDR_OFFSET+{16'h06DC}    :   {o_par_Phase_I[895:880],o_par_Phase_Q[895:880]} <=  r_cpu_wdata ;     //3_13   //o_par_Phase13                   
`endif

            ADDR_OFFSET+{16'h0C00}    :   o_par_calon               <=  r_cpu_wdata ;          
            ADDR_OFFSET+{16'h0C04}    :   o_par_calwscale           <=  r_cpu_wdata ;          
            ADDR_OFFSET+{16'h0C08}    :   o_sel_calb_rx             <=  r_cpu_wdata ;          
            ADDR_OFFSET+{16'h2004}    :   o_frm_chk_gap             <=  r_cpu_wdata ;          

        endcase                                                                                                 
    end                                                               
end                                                                   

reg [0:0]   r_mux_rd_en    [DLY_REG_RD-2:0]  ;
reg [31:0]  r_mux_rd_data  [DLY_REG_RD-2:0]  ;
reg [0:0]   r_mux_rdmem_en    ;//[DLY_REG_RD-4:0]  ;
reg [31:0]  r_mux_rdmem_data  ;//[DLY_REG_RD-4:0]  ;
        /*
        always@(posedge i_clk) begin
            if(r_cpu_rden) begin
                case(r_cpu_addr)
                    ADDR_OFFSET+16'h0040    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_input_ctrl_mode     ; end    
                    ADDR_OFFSET+16'h0044    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_input_tp_mode       ; end    
                    ADDR_OFFSET+16'h0048    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_output_ctrl_mode    ; end    
                    
                    ADDR_OFFSET+16'h0200    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_freqshifton     ; end    
                    ADDR_OFFSET+16'h0204    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_cpType          ; end    
                    ADDR_OFFSET+16'h0208    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_cpRmOffset      ; end    
                    ADDR_OFFSET+16'h020C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tagcOn          ; end  
                    ADDR_OFFSET+16'h0210    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tagcBackoff     ; end    
                    ADDR_OFFSET+16'h0214    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_k0              ; end    
                    ADDR_OFFSET+16'h0218    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_rbSize          ; end    
                    ADDR_OFFSET+16'h021C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_gainCompOn      ; end  
                    ADDR_OFFSET+16'h0220    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_ctsOn           ; end    
                    ADDR_OFFSET+16'h0224    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_ctsShift        ; end    
                    ADDR_OFFSET+16'h0228    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_phaseCompOn     ; end    
                    ADDR_OFFSET+16'h022C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_mpfrmstruct     ; end  
                    ADDR_OFFSET+16'h0230    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiTrigSlot  ; end    
                    ADDR_OFFSET+16'h0234    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiTrigSym   ; end  
                    ADDR_OFFSET+16'h0238    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiStartSlot ; end    
                    ADDR_OFFSET+16'h023C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiStartSym  ; end    
                    ADDR_OFFSET+16'h0240    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiSymSize   ; end    
                    ADDR_OFFSET+16'h0244    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_par_tdrssiTrigger   ; end    
                    
                   
                    ADDR_OFFSET+16'h0600    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[15:0]   ,o_par_Phase_Q[15:0]   }         ; end    //0_0    //o_par_Phase0  
                    ADDR_OFFSET+16'h0604    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[31:16]  ,o_par_Phase_Q[31:16]  }         ; end    //0_1    //o_par_Phase1  
                    ADDR_OFFSET+16'h0608    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[47:32]  ,o_par_Phase_Q[47:32]  }         ; end    //0_2    //o_par_Phase2  
                    ADDR_OFFSET+16'h060C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[63:48]  ,o_par_Phase_Q[63:48]  }         ; end    //0_3    //o_par_Phase3  
                    ADDR_OFFSET+16'h0610    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[79:64]  ,o_par_Phase_Q[79:64]  }         ; end    //0_4    //o_par_Phase4  
                    ADDR_OFFSET+16'h0614    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[95:80]  ,o_par_Phase_Q[95:80]  }         ; end    //0_5    //o_par_Phase5  
                    ADDR_OFFSET+16'h0618    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[111:96] ,o_par_Phase_Q[111:96] }         ; end    //0_6    //o_par_Phase6  
                    ADDR_OFFSET+16'h061C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[127:112],o_par_Phase_Q[127:112]}         ; end    //0_7    //o_par_Phase7  
                    ADDR_OFFSET+16'h0620    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[143:128],o_par_Phase_Q[143:128]}         ; end    //0_8    //o_par_Phase8  
                    ADDR_OFFSET+16'h0624    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[159:144],o_par_Phase_Q[159:144]}         ; end    //0_9    //o_par_Phase9  
                    ADDR_OFFSET+16'h0628    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[175:160],o_par_Phase_Q[175:160]}         ; end    //0_10   //o_par_Phase10 
                    ADDR_OFFSET+16'h062C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[191:176],o_par_Phase_Q[191:176]}         ; end    //0_11   //o_par_Phase11 
                    ADDR_OFFSET+16'h0630    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[207:192],o_par_Phase_Q[207:192]}         ; end    //0_12   //o_par_Phase12 
                    ADDR_OFFSET+16'h0634    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[223:208],o_par_Phase_Q[223:208]}         ; end    //0_13   //o_par_Phase13 
        `ifndef SCS1_u_ULFE_disable
                    ADDR_OFFSET+16'h0638    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[239:224],o_par_Phase_Q[239:224]}         ; end    //1_0    //o_par_Phase0  
                    ADDR_OFFSET+16'h063C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[255:240],o_par_Phase_Q[255:240]}         ; end    //1_1    //o_par_Phase1  
                    ADDR_OFFSET+16'h0640    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[271:256],o_par_Phase_Q[271:256]}         ; end    //1_2    //o_par_Phase2  
                    ADDR_OFFSET+16'h0644    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[287:272],o_par_Phase_Q[287:272]}         ; end    //1_3    //o_par_Phase3  
                    ADDR_OFFSET+16'h0648    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[303:288],o_par_Phase_Q[303:288]}         ; end    //1_4    //o_par_Phase4  
                    ADDR_OFFSET+16'h064C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[319:304],o_par_Phase_Q[319:304]}         ; end    //1_5    //o_par_Phase5  
                    ADDR_OFFSET+16'h0650    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[335:320],o_par_Phase_Q[335:320]}         ; end    //1_6    //o_par_Phase6  
                    ADDR_OFFSET+16'h0654    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[351:336],o_par_Phase_Q[351:336]}         ; end    //1_7    //o_par_Phase7  
                    ADDR_OFFSET+16'h0658    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[367:352],o_par_Phase_Q[367:352]}         ; end    //1_8    //o_par_Phase8  
                    ADDR_OFFSET+16'h065C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[383:368],o_par_Phase_Q[383:368]}         ; end    //1_9    //o_par_Phase9  
                    ADDR_OFFSET+16'h0660    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[399:384],o_par_Phase_Q[399:384]}         ; end    //1_10   //o_par_Phase10 
                    ADDR_OFFSET+16'h0664    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[415:400],o_par_Phase_Q[415:400]}         ; end    //1_11   //o_par_Phase11 
                    ADDR_OFFSET+16'h0668    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[431:416],o_par_Phase_Q[431:416]}         ; end    //1_12   //o_par_Phase12 
                    ADDR_OFFSET+16'h066C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[447:432],o_par_Phase_Q[447:432]}         ; end    //1_13   //o_par_Phase13 
        `endif
        `ifndef SCS2_u_ULFE_disable
                    ADDR_OFFSET+16'h0670    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[463:448],o_par_Phase_Q[463:448]}         ; end    //2_0    //o_par_Phase0  
                    ADDR_OFFSET+16'h0674    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[479:464],o_par_Phase_Q[479:464]}         ; end    //2_1    //o_par_Phase1  
                    ADDR_OFFSET+16'h0678    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[495:480],o_par_Phase_Q[495:480]}         ; end    //2_2    //o_par_Phase2  
                    ADDR_OFFSET+16'h067C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[511:496],o_par_Phase_Q[511:496]}         ; end    //2_3    //o_par_Phase3  
                    ADDR_OFFSET+16'h0680    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[527:512],o_par_Phase_Q[527:512]}         ; end    //2_4    //o_par_Phase4  
                    ADDR_OFFSET+16'h0684    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[543:528],o_par_Phase_Q[543:528]}         ; end    //2_5    //o_par_Phase5  
                    ADDR_OFFSET+16'h0688    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[559:544],o_par_Phase_Q[559:544]}         ; end    //2_6    //o_par_Phase6  
                    ADDR_OFFSET+16'h068C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[575:560],o_par_Phase_Q[575:560]}         ; end    //2_7    //o_par_Phase7  
                    ADDR_OFFSET+16'h0690    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[591:576],o_par_Phase_Q[591:576]}         ; end    //2_8    //o_par_Phase8  
                    ADDR_OFFSET+16'h0694    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[607:592],o_par_Phase_Q[607:592]}         ; end    //2_9    //o_par_Phase9  
                    ADDR_OFFSET+16'h0698    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[623:608],o_par_Phase_Q[623:608]}         ; end    //2_10   //o_par_Phase10 
                    ADDR_OFFSET+16'h069C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[639:624],o_par_Phase_Q[639:624]}         ; end    //2_11   //o_par_Phase11 
                    ADDR_OFFSET+16'h06A0    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[655:640],o_par_Phase_Q[655:640]}         ; end    //2_12   //o_par_Phase12 
                    ADDR_OFFSET+16'h06A4    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[671:656],o_par_Phase_Q[671:656]}         ; end    //2_13   //o_par_Phase13 
                    ADDR_OFFSET+16'h06A8    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[687:672],o_par_Phase_Q[687:672]}         ; end    //3_0    //_par_Phase0   
                    ADDR_OFFSET+16'h06AC    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[703:688],o_par_Phase_Q[703:688]}         ; end    //3_1    //_par_Phase1   
                    ADDR_OFFSET+16'h06B0    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[719:704],o_par_Phase_Q[719:704]}         ; end    //3_2    //_par_Phase2   
                    ADDR_OFFSET+16'h06B4    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[735:720],o_par_Phase_Q[735:720]}         ; end    //3_3    //_par_Phase3   
                    ADDR_OFFSET+16'h06B8    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[751:736],o_par_Phase_Q[751:736]}         ; end    //3_4    //_par_Phase4   
                    ADDR_OFFSET+16'h06BC    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[767:752],o_par_Phase_Q[767:752]}         ; end    //3_5    //_par_Phase5   
                    ADDR_OFFSET+16'h06C0    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[783:768],o_par_Phase_Q[783:768]}         ; end    //3_6    //o_par_Phase6  
                    ADDR_OFFSET+16'h06C4    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[799:784],o_par_Phase_Q[799:784]}         ; end    //3_7    //o_par_Phase7  
                    ADDR_OFFSET+16'h06C8    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[815:800],o_par_Phase_Q[815:800]}         ; end    //3_8    //o_par_Phase8  
                    ADDR_OFFSET+16'h06CC    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[831:816],o_par_Phase_Q[831:816]}         ; end    //3_9    //o_par_Phase9  
                    ADDR_OFFSET+16'h06D0    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[847:832],o_par_Phase_Q[847:832]}         ; end    //3_10   //o_par_Phase10 
                    ADDR_OFFSET+16'h06D4    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[863:848],o_par_Phase_Q[863:848]}         ; end    //3_11   //o_par_Phase11 
                    ADDR_OFFSET+16'h06D8    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[879:864],o_par_Phase_Q[879:864]}         ; end    //3_12   //o_par_Phase12 
                    ADDR_OFFSET+16'h06DC    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {o_par_Phase_I[895:880],o_par_Phase_Q[895:880]}         ; end    //3_13   //o_par_Phase13 
        `endif
          
                    
                    
                    
                    
                    
                    ADDR_OFFSET+16'h2000    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= {{(32-8){1'b0}},r_uin_en_exist}   ; end    
                    ADDR_OFFSET+16'h2004    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= o_frm_chk_gap                     ; end    
                    ADDR_OFFSET+16'h2008    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_inout_frm_syncfail_count        ; end    
                    ADDR_OFFSET+16'h200C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_prev_current_frmidx             ; end    
        
                    ADDR_OFFSET+16'h2100    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*1-1:32*0]       ; end    
                    ADDR_OFFSET+16'h2104    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*2-1:32*1]       ; end    
                    ADDR_OFFSET+16'h2108    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*3-1:32*2]       ; end    
                    ADDR_OFFSET+16'h210C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*4-1:32*3]       ; end                
                    ADDR_OFFSET+16'h2110    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*1-1:32*0]      ; end    
                    ADDR_OFFSET+16'h2114    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*2-1:32*1]      ; end    
                    ADDR_OFFSET+16'h2118    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*3-1:32*2]      ; end    
                    ADDR_OFFSET+16'h211C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*4-1:32*3]      ; end                
                    ADDR_OFFSET+16'h2120    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*5-1:32*4]       ; end    
                    ADDR_OFFSET+16'h2124    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*6-1:32*5]       ; end    
                    ADDR_OFFSET+16'h2128    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*7-1:32*6]       ; end    
                    ADDR_OFFSET+16'h212C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uin_xssi[32*8-1:32*7]       ; end                
                    ADDR_OFFSET+16'h2130    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*5-1:32*4]      ; end    
                    ADDR_OFFSET+16'h2134    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*6-1:32*5]      ; end    
                    ADDR_OFFSET+16'h2138    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*7-1:32*6]      ; end    
                    ADDR_OFFSET+16'h213C    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_uout_xssi[32*8-1:32*7]      ; end                
                    
                    
                    
                    
                      
        //            ADDR_OFFSET+16'h2000    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_p2000   ; end    
        //            ADDR_OFFSET+16'h2001    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_p2001   ; end    
        //            ADDR_OFFSET+16'h2002    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_p2002   ; end    
        //            ADDR_OFFSET+16'h2003    :   begin r_mux_rd_en[0] <= 1'd1; r_mux_rd_data[0] <= i_rpt_p2003   ; end    
                    default                 :   begin r_mux_rd_en[0] <= 1'd0; r_mux_rd_data[0] <= 32'h21FE21FE  ; end    
                endcase                                                      
            end  
            else begin
                r_mux_rd_en [0]  <=  1'd0    ;    
            end
        end                               
        */


reg [0:0]     r_mux_rd0_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd0_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(r_cpu_rden) begin
        case(r_cpu_addr)
            ADDR_OFFSET+{16'h0040}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_input_ctrl_mode     ; end    
            ADDR_OFFSET+{16'h0044}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_input_tp_mode       ; end    
            ADDR_OFFSET+{16'h0048}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_output_ctrl_mode    ; end    
            
            ADDR_OFFSET+{16'h0200}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_freqshifton     ; end    
            ADDR_OFFSET+{16'h0204}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_cpType          ; end    
            ADDR_OFFSET+{16'h0208}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_cpRmOffset      ; end    
            ADDR_OFFSET+{16'h020C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tagcOn          ; end  
            ADDR_OFFSET+{16'h0210}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tagcBackoff     ; end    
            ADDR_OFFSET+{16'h0214}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_k0              ; end    
            ADDR_OFFSET+{16'h0218}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_rbSize          ; end    
            ADDR_OFFSET+{16'h021C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_gainCompOn      ; end  
            ADDR_OFFSET+{16'h0220}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_ctsOn           ; end    
            ADDR_OFFSET+{16'h0224}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_ctsShift        ; end    
            ADDR_OFFSET+{16'h0228}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_phaseCompOn     ; end    
            ADDR_OFFSET+{16'h022C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_mpfrmstruct     ; end  
            ADDR_OFFSET+{16'h0230}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiTrigSlot  ; end    
            ADDR_OFFSET+{16'h0234}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiTrigSym   ; end  
            ADDR_OFFSET+{16'h0238}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiStartSlot ; end    
            ADDR_OFFSET+{16'h023C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiStartSym  ; end    
            ADDR_OFFSET+{16'h0240}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiSymSize   ; end    
            ADDR_OFFSET+{16'h0244}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_tdrssiTrigger   ; end    
            ADDR_OFFSET+{16'h0248}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_sel_symidx_tdrssirpt   ; end    
            ADDR_OFFSET+{16'h024C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {31'h0000_0000,r_tdrssi_rpt_done} ; end    

            ADDR_OFFSET+{16'h0250}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 1*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h0254}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 2*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h0258}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 3*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h025C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 4*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h0260}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 5*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h0264}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 6*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h0268}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 7*32-1 -: 32] ; end    
            ADDR_OFFSET+{16'h026C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 8*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0270}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[ 9*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0274}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[10*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0278}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[11*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h027C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[12*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0280}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[13*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0284}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[14*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0288}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[15*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h028C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[16*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0290}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[17*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0294}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[18*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0298}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[19*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h029C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[20*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02A0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[21*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02A4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[22*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02A8}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[23*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02AC}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[24*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02B0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[25*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02B4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[26*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02B8}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[27*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02BC}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[28*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02C0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[29*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02C4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[30*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02D0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[31*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02D4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[32*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02D8}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[33*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02DC}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[34*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02E0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[35*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02E4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[36*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02E8}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[37*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02EC}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[38*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02F0}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[39*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02F4}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[40*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02F8}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[41*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h02FC}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[42*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0300}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[43*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0304}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[44*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0308}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[45*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h030C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[46*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0310}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[47*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0314}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[48*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0318}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[49*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h031C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[50*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0320}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[51*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0324}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[52*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0328}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[53*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h032C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[54*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0330}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[55*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0334}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[56*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0338}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[57*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h033C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[58*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0340}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[59*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0344}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[60*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0348}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[61*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h034C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[62*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0350}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[63*32-1 -: 32] ; end    
//            ADDR_OFFSET+{16'h0354}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_tdrssi_rpt[64*32-1 -: 32] ; end    


            ADDR_OFFSET+{16'h0800}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_numMdmPath      ; end    
            ADDR_OFFSET+{16'h0804}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_numAnt          ; end    
           
            ADDR_OFFSET+{16'h0C00}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_calon           ; end    
            ADDR_OFFSET+{16'h0C04}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_par_calwscale       ; end           
            ADDR_OFFSET+{16'h0C08}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_sel_calb_rx         ; end    
                  
        
            ADDR_OFFSET+{16'h1C00}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {r_dss_cp_alarm,{(32-1-4){1'b0}},i_dbg_dssCp_alarm[3:0]}   ; end    
            
           
            ADDR_OFFSET+{16'h2000}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(32-8){1'b0}},r_uin_en_exist}   ; end    
            ADDR_OFFSET+{16'h2004}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= o_frm_chk_gap                     ; end    
            ADDR_OFFSET+{16'h2008}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_inout_frm_syncfail_count        ; end    
            ADDR_OFFSET+{16'h200C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_prev_current_frmidx             ; end    
            ADDR_OFFSET+{16'h2010}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_inputsync_time_stamp            ; end    
            ADDR_OFFSET+{16'h2014}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(32-8){1'b0}},r_p2a_ready_fft}  ; end    
            ADDR_OFFSET+{16'h2018}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(32-8){1'b0}},r_a2p_valid_fft}  ; end    
`ifdef ULFE_CALB_EN
            ADDR_OFFSET+{16'h201C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(3){1'b0}},i_calwght_evenodd_sel[8],{(32-12){1'b0}},i_calwght_evenodd_sel[7:0]}  ; end  
`endif                          

            ADDR_OFFSET+{16'h2020}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_last[32*1-1:32*0]  ; end    
            ADDR_OFFSET+{16'h2024}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_last[32*2-1:32*1]  ; end    
            ADDR_OFFSET+{16'h2028}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_last[32*3-1:32*2]  ; end    
            ADDR_OFFSET+{16'h202c}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_last[32*4-1:32*3]  ; end    
            ADDR_OFFSET+{16'h2030}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_0dat[32*1-1:32*0]  ; end    
            ADDR_OFFSET+{16'h2034}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_0dat[32*2-1:32*1]  ; end    
            ADDR_OFFSET+{16'h2038}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_0dat[32*3-1:32*2]  ; end    
            ADDR_OFFSET+{16'h203c}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_st01_a2p_0dat[32*4-1:32*3]  ; end    
            ADDR_OFFSET+{16'h2040}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_fd_0dat[32*1-1:32*0]  ; end    
            ADDR_OFFSET+{16'h2044}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_fd_0dat[32*2-1:32*1]  ; end    
            ADDR_OFFSET+{16'h2048}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_fd_0dat[32*3-1:32*2]  ; end    
            ADDR_OFFSET+{16'h204c}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_cnt_fd_0dat[32*4-1:32*3]  ; end    

            ADDR_OFFSET+{16'h2100}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*1-1:32*0]       ; end    
            ADDR_OFFSET+{16'h2104}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*2-1:32*1]       ; end    
`ifndef UL_NUM_ANT_2
            ADDR_OFFSET+{16'h2108}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*3-1:32*2]       ; end    
            ADDR_OFFSET+{16'h210C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*4-1:32*3]       ; end                
`endif
            ADDR_OFFSET+{16'h2110}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*1-1:32*0]      ; end    
            ADDR_OFFSET+{16'h2114}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*2-1:32*1]      ; end    
`ifndef UL_NUM_ANT_2
            ADDR_OFFSET+{16'h2118}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*3-1:32*2]      ; end    
            ADDR_OFFSET+{16'h211C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*4-1:32*3]      ; end                
`endif
`ifdef UL_NUM_ANT_8

            ADDR_OFFSET+{16'h2120}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*5-1:32*4]       ; end    
            ADDR_OFFSET+{16'h2124}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*6-1:32*5]       ; end    
            ADDR_OFFSET+{16'h2128}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*7-1:32*6]       ; end    
            ADDR_OFFSET+{16'h212C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uin_xssi[32*8-1:32*7]       ; end                
            ADDR_OFFSET+{16'h2130}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*5-1:32*4]      ; end    
            ADDR_OFFSET+{16'h2134}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*6-1:32*5]      ; end    
            ADDR_OFFSET+{16'h2138}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*7-1:32*6]      ; end    
            ADDR_OFFSET+{16'h213C}    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_uout_xssi[32*8-1:32*7]      ; end                
        `endif
            default                 :   begin r_mux_rd0_en[0] <= 1'd0; r_mux_rd0_data[0] <= 32'h01234567     ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd0_en [0]  <=  1'd0    ;    
    end
end                               



reg [0:0]     r_mux_rd1_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd1_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(r_cpu_rden) begin
        case(r_cpu_addr)

            ADDR_OFFSET+{16'h0600}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[15:0]   ,o_par_Phase_Q[15:0]   }         ; end    //0_0    //o_par_Phase0  
            ADDR_OFFSET+{16'h0604}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[31:16]  ,o_par_Phase_Q[31:16]  }         ; end    //0_1    //o_par_Phase1  
            ADDR_OFFSET+{16'h0608}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[47:32]  ,o_par_Phase_Q[47:32]  }         ; end    //0_2    //o_par_Phase2  
            ADDR_OFFSET+{16'h060C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[63:48]  ,o_par_Phase_Q[63:48]  }         ; end    //0_3    //o_par_Phase3  
            ADDR_OFFSET+{16'h0610}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[79:64]  ,o_par_Phase_Q[79:64]  }         ; end    //0_4    //o_par_Phase4  
            ADDR_OFFSET+{16'h0614}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[95:80]  ,o_par_Phase_Q[95:80]  }         ; end    //0_5    //o_par_Phase5  
            ADDR_OFFSET+{16'h0618}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[111:96] ,o_par_Phase_Q[111:96] }         ; end    //0_6    //o_par_Phase6  
            ADDR_OFFSET+{16'h061C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[127:112],o_par_Phase_Q[127:112]}         ; end    //0_7    //o_par_Phase7  
            ADDR_OFFSET+{16'h0620}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[143:128],o_par_Phase_Q[143:128]}         ; end    //0_8    //o_par_Phase8  
            ADDR_OFFSET+{16'h0624}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[159:144],o_par_Phase_Q[159:144]}         ; end    //0_9    //o_par_Phase9  
            ADDR_OFFSET+{16'h0628}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[175:160],o_par_Phase_Q[175:160]}         ; end    //0_10   //o_par_Phase10 
            ADDR_OFFSET+{16'h062C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[191:176],o_par_Phase_Q[191:176]}         ; end    //0_11   //o_par_Phase11 
            ADDR_OFFSET+{16'h0630}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[207:192],o_par_Phase_Q[207:192]}         ; end    //0_12   //o_par_Phase12 
            ADDR_OFFSET+{16'h0634}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[223:208],o_par_Phase_Q[223:208]}         ; end    //0_13   //o_par_Phase13 
`ifndef SCS1_u_ULFE_disable
            ADDR_OFFSET+{16'h0638}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[239:224],o_par_Phase_Q[239:224]}         ; end    //1_0    //o_par_Phase0  
            ADDR_OFFSET+{16'h063C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[255:240],o_par_Phase_Q[255:240]}         ; end    //1_1    //o_par_Phase1  
            ADDR_OFFSET+{16'h0640}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[271:256],o_par_Phase_Q[271:256]}         ; end    //1_2    //o_par_Phase2  
            ADDR_OFFSET+{16'h0644}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[287:272],o_par_Phase_Q[287:272]}         ; end    //1_3    //o_par_Phase3  
            ADDR_OFFSET+{16'h0648}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[303:288],o_par_Phase_Q[303:288]}         ; end    //1_4    //o_par_Phase4  
            ADDR_OFFSET+{16'h064C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[319:304],o_par_Phase_Q[319:304]}         ; end    //1_5    //o_par_Phase5  
            ADDR_OFFSET+{16'h0650}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[335:320],o_par_Phase_Q[335:320]}         ; end    //1_6    //o_par_Phase6  
            ADDR_OFFSET+{16'h0654}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[351:336],o_par_Phase_Q[351:336]}         ; end    //1_7    //o_par_Phase7  
            ADDR_OFFSET+{16'h0658}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[367:352],o_par_Phase_Q[367:352]}         ; end    //1_8    //o_par_Phase8  
            ADDR_OFFSET+{16'h065C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[383:368],o_par_Phase_Q[383:368]}         ; end    //1_9    //o_par_Phase9  
            ADDR_OFFSET+{16'h0660}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[399:384],o_par_Phase_Q[399:384]}         ; end    //1_10   //o_par_Phase10 
            ADDR_OFFSET+{16'h0664}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[415:400],o_par_Phase_Q[415:400]}         ; end    //1_11   //o_par_Phase11 
            ADDR_OFFSET+{16'h0668}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[431:416],o_par_Phase_Q[431:416]}         ; end    //1_12   //o_par_Phase12 
            ADDR_OFFSET+{16'h066C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[447:432],o_par_Phase_Q[447:432]}         ; end    //1_13   //o_par_Phase13 
`endif
`ifndef SCS2_u_ULFE_disable
            ADDR_OFFSET+{16'h0670}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[463:448],o_par_Phase_Q[463:448]}         ; end    //2_0    //o_par_Phase0  
            ADDR_OFFSET+{16'h0674}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[479:464],o_par_Phase_Q[479:464]}         ; end    //2_1    //o_par_Phase1  
            ADDR_OFFSET+{16'h0678}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[495:480],o_par_Phase_Q[495:480]}         ; end    //2_2    //o_par_Phase2  
            ADDR_OFFSET+{16'h067C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[511:496],o_par_Phase_Q[511:496]}         ; end    //2_3    //o_par_Phase3  
            ADDR_OFFSET+{16'h0680}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[527:512],o_par_Phase_Q[527:512]}         ; end    //2_4    //o_par_Phase4  
            ADDR_OFFSET+{16'h0684}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[543:528],o_par_Phase_Q[543:528]}         ; end    //2_5    //o_par_Phase5  
            ADDR_OFFSET+{16'h0688}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[559:544],o_par_Phase_Q[559:544]}         ; end    //2_6    //o_par_Phase6  
            ADDR_OFFSET+{16'h068C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[575:560],o_par_Phase_Q[575:560]}         ; end    //2_7    //o_par_Phase7  
            ADDR_OFFSET+{16'h0690}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[591:576],o_par_Phase_Q[591:576]}         ; end    //2_8    //o_par_Phase8  
            ADDR_OFFSET+{16'h0694}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[607:592],o_par_Phase_Q[607:592]}         ; end    //2_9    //o_par_Phase9  
            ADDR_OFFSET+{16'h0698}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[623:608],o_par_Phase_Q[623:608]}         ; end    //2_10   //o_par_Phase10 
            ADDR_OFFSET+{16'h069C}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[639:624],o_par_Phase_Q[639:624]}         ; end    //2_11   //o_par_Phase11 
            ADDR_OFFSET+{16'h06A0}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[655:640],o_par_Phase_Q[655:640]}         ; end    //2_12   //o_par_Phase12 
            ADDR_OFFSET+{16'h06A4}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[671:656],o_par_Phase_Q[671:656]}         ; end    //2_13   //o_par_Phase13 
            ADDR_OFFSET+{16'h06A8}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[687:672],o_par_Phase_Q[687:672]}         ; end    //3_0    //_par_Phase0   
            ADDR_OFFSET+{16'h06AC}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[703:688],o_par_Phase_Q[703:688]}         ; end    //3_1    //_par_Phase1   
            ADDR_OFFSET+{16'h06B0}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[719:704],o_par_Phase_Q[719:704]}         ; end    //3_2    //_par_Phase2   
            ADDR_OFFSET+{16'h06B4}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[735:720],o_par_Phase_Q[735:720]}         ; end    //3_3    //_par_Phase3   
            ADDR_OFFSET+{16'h06B8}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[751:736],o_par_Phase_Q[751:736]}         ; end    //3_4    //_par_Phase4   
            ADDR_OFFSET+{16'h06BC}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[767:752],o_par_Phase_Q[767:752]}         ; end    //3_5    //_par_Phase5   
            ADDR_OFFSET+{16'h06C0}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[783:768],o_par_Phase_Q[783:768]}         ; end    //3_6    //o_par_Phase6  
            ADDR_OFFSET+{16'h06C4}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[799:784],o_par_Phase_Q[799:784]}         ; end    //3_7    //o_par_Phase7  
            ADDR_OFFSET+{16'h06C8}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[815:800],o_par_Phase_Q[815:800]}         ; end    //3_8    //o_par_Phase8  
            ADDR_OFFSET+{16'h06CC}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[831:816],o_par_Phase_Q[831:816]}         ; end    //3_9    //o_par_Phase9  
            ADDR_OFFSET+{16'h06D0}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[847:832],o_par_Phase_Q[847:832]}         ; end    //3_10   //o_par_Phase10 
            ADDR_OFFSET+{16'h06D4}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[863:848],o_par_Phase_Q[863:848]}         ; end    //3_11   //o_par_Phase11 
            ADDR_OFFSET+{16'h06D8}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[879:864],o_par_Phase_Q[879:864]}         ; end    //3_12   //o_par_Phase12 
            ADDR_OFFSET+{16'h06DC}    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= {o_par_Phase_I[895:880],o_par_Phase_Q[895:880]}         ; end    //3_13   //o_par_Phase13 
`endif

            default                 :   begin r_mux_rd1_en[0] <= 1'd0; r_mux_rd1_data[0] <= 32'h0123_4567     ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd1_en [0]  <=  1'd0    ;    
    end
end                               

//reg [0:0]     r_mux_rd_en    [DLY_REG_RD_OUT+1:0]  ;
//reg [DW-1:0]  r_mux_rd_data  [DLY_REG_RD_OUT+1:0]  ;

always @(posedge i_clk) begin
    if     (r_mux_rd0_en[0]) 
    begin 
        r_mux_rd_en[0]      <= r_mux_rd0_en[0]; 
        r_mux_rd_data[0]    <= r_mux_rd0_data[0]; 
    end
    else if(r_mux_rd1_en[0]) 
    begin 
        r_mux_rd_en[0]      <= r_mux_rd1_en[0]; 
        r_mux_rd_data[0]    <= r_mux_rd1_data[0]; 
    end
    else                     
    begin 
        r_mux_rd_en[0]      <= 1'b0;  
    end
end

`ifdef ULFE_CALB_EN
always @(posedge i_clk) begin
    case(i_calb_cpu_rvalid)
        4'b0001 : begin
            r_mux_rdmem_en      <=  i_calb_cpu_rvalid[0];
            r_mux_rdmem_data    <=  i_calb_cpu_rdata[32*(0+1)-1 -: 32];
            end
        4'b0010 : begin
            r_mux_rdmem_en      <=  i_calb_cpu_rvalid[1];
            r_mux_rdmem_data    <=  i_calb_cpu_rdata[32*(1+1)-1 -: 32];
            end
        4'b0100 : begin
            r_mux_rdmem_en      <=  i_calb_cpu_rvalid[2];
            r_mux_rdmem_data    <=  i_calb_cpu_rdata[32*(2+1)-1 -: 32];
            end
        4'b1000 : begin
            r_mux_rdmem_en      <=  i_calb_cpu_rvalid[3];
            r_mux_rdmem_data    <=  i_calb_cpu_rdata[32*(3+1)-1 -: 32];
            end
        default : begin
            r_mux_rdmem_en      <=  1'b0;
            r_mux_rdmem_data    <=  32'd0;
        end
    endcase
end
`endif        



generate for(gidx=1;gidx<DLY_REG_RD-3;gidx=gidx+1) begin : g00_reg_rd_dly 
always@(posedge i_clk) begin
    if(r_mux_rd_en    [gidx-1]) begin
        r_mux_rd_en    [gidx]  <=  r_mux_rd_en    [gidx-1]    ;    
        r_mux_rd_data  [gidx]  <=  r_mux_rd_data  [gidx-1]    ;    
    end  
    else begin
        r_mux_rd_en    [gidx]  <=  1'd0    ;    
    end
end                               
end
endgenerate

always@(posedge i_clk) begin
begin
    if(r_mux_rd_en    [DLY_REG_RD-4]) begin
        r_mux_rd_en    [DLY_REG_RD-3]  <=  r_mux_rd_en    [DLY_REG_RD-4]    ;    
        r_mux_rd_data  [DLY_REG_RD-3]  <=  r_mux_rd_data  [DLY_REG_RD-4]    ;    
    end  
`ifdef ULFE_CALB_EN
    else if(r_mux_rdmem_en) begin
        r_mux_rd_en    [DLY_REG_RD-3]  <=  r_mux_rdmem_en   ;    
        r_mux_rd_data  [DLY_REG_RD-3]  <=  r_mux_rdmem_data ;    
    end
`endif        
    else begin
        r_mux_rd_en    [DLY_REG_RD-3]  <=  1'd0    ;    
    end
end                               
end


assign  o_cpu_rd_valid  =   r_mux_rd_en    [DLY_REG_RD-3]   ;   
assign  o_cpu_rdata     =   r_mux_rd_data  [DLY_REG_RD-3]   ;   




always@(posedge i_clk) 
begin
    if(i_tdrssi_rpt_done) begin
        r_tdrssi_rpt_done <=  1'd1 ;
    end
    else if(r_cpu_rden&&r_cpu_addr==ADDR_OFFSET+16'h024C) begin
        r_tdrssi_rpt_done <=  1'd0 ;
    end
end

always@(posedge i_clk) 
begin
    if(i_dbg_dssCp_alarm[4]) begin
        r_dss_cp_alarm <=  1'd1 ;
    end
    else if(r_cpu_rden&&r_cpu_addr==ADDR_OFFSET+16'h1C00) begin
        r_dss_cp_alarm <=  1'd0 ;
    end
end


integer k;
always@(posedge i_clk) 
begin
    for(k=0 ; k<8 ; k=k+1)
    begin
        if(i_uin_en[k]) begin
            r_uin_en_exist[k] <=  1'd1 ;
        end
        else if(r_cpu_rden&&r_cpu_addr==ADDR_OFFSET+16'h2000) begin
            r_uin_en_exist[k] <=  1'd0 ;
        end
    end
end

always@(posedge i_clk) 
begin
    for(k=0 ; k<8 ; k=k+1)
    begin
        if(i_p2a_ready_fft[k]) begin
            r_p2a_ready_fft[k] <=  1'd1 ;
        end
        else if(r_cpu_rden&&r_cpu_addr==ADDR_OFFSET+16'h2014) begin
            r_p2a_ready_fft[k] <=  1'd0 ;
        end
    end
end

always@(posedge i_clk) 
begin
    for(k=0 ; k<8 ; k=k+1)
    begin
        if(i_a2p_valid_fft[k]) begin
            r_a2p_valid_fft[k] <=  1'd1 ;
        end
        else if(r_cpu_rden&&r_cpu_addr==ADDR_OFFSET+16'h2018) begin
            r_a2p_valid_fft[k] <=  1'd0 ;
        end
    end
end



endmodule                                                             
