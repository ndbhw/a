// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : tagc
//  Author       : Han Xiangdong
//  Description  : TD AGC
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tagc_aie  #
  (
   parameter TYPE         = 0                             // 0: ULFE   1: RAFE
  ,parameter OC           = 1                             // 1: hovs2  2: hovs4  3:hovs8                   
  ,parameter OVS          = 2**OC                         // 0: 2      1:4       2:8
  ,parameter IB           = 15                            // IQ input data width
  ,parameter OB           = 15                            // IQ output data width
  ,parameter TR           = 32                            // output RSSI data width   
  ,parameter N_CYCLE_CLK  =245760000                      
  ,parameter SCS_IDX      =1                              //{0~4} --> {15k, 30k, 60k, 120k, 240k}
  ,parameter CP_TYPE      =0                              //0:normal, 1:extended
  ,parameter VENDOR       ="Xilinx"
  )
  (

   input                  i_clk                           // 
  ,input                  i_rst                           // 

  ,input                  i_frm_tick_pre1                 // 10ms tick
  ,input  [OVS-1:0]       i_tdagc_vld                     // 
  ,input  [IB-1:0]        i_tdagc_i                       // 
  ,input  [IB-1:0]        i_tdagc_q                       // 

  ,input                  i_bcf_enb                       // 
  ,input                  i_tdd_mode                      // 

  ,input  [OVS*5-1:0]     i_tagcbackoff                   // agc back off                                 //cell setup
  ,input  [3:0]           i_ffttype                       // 0:512   1:1024    2:2048    3:4096           //cell setup
  ,input  [OVS-1:0]       i_tagcon                        // 1:on        0:off                            //cell setup
  ,input  [OVS-1:0]       i_calbypassflag                 // 0:no bypass 1:bypass for calibation pattern  //symbol tick
  ,input  [3:0]           i_tagcdb_conv_mod               //                                              //                                           

  ,input                  i_rafe_frm_tick                 // rafe input 
  ,input                  i_rafe_slt_tick                 // rafe input 
  ,input  [5:0]           i_rafe_slt_idx                  // rafe input 
  ,input                  i_rafe_ro_tick                  // rafe input 
  ,input  [3:0]           i_rafe_ro_idx                   // rafe input 
  ,input                  i_rafe_sym_tick                 // rafe input 
  ,input  [3:0]           i_rafe_sym_idx                  // rafe input 

  ,output                 o_frm_tick                      // 
  ,output                 o_slt_tick                      // 
  ,output                 o_sym_tick                      // 
  ,output [3:0]           o_rafe_ro_idx                   // 
  ,output [3:0]           o_rafe_sym_idx                  // 

  ,output [OVS-1:0]       o_tdagc_vld                     // 
  ,output [OB-1:0]        o_tdagc_i_0M                       // 
  ,output [OB-1:0]        o_tdagc_q_0M                       // 
  ,output [OB-1:0]        o_tdagc_i_0L                       // 
  ,output [OB-1:0]        o_tdagc_q_0L                       // 
  ,output [OB-1:0]        o_tdagc_i_1M                       // 
  ,output [OB-1:0]        o_tdagc_q_1M                       // 
  ,output [OB-1:0]        o_tdagc_i_1L                       // 
  ,output [OB-1:0]        o_tdagc_q_1L                       // 

  ,output [4-1 :0]        o_tdgain1                       // 
  ,output [5-1 :0]        o_tdgain2                       //
  ,output [5-1 :0]        o_tdagc_gain                    // 
  ,output                 o_bcf_enb                       // 
  ,output                 o_tdd_mode                      // 

//  ,output [31:0]          o_tdagc_latency                 // 

  ,output [OVS*TR-1:0]    o_tdagc_tdrssi                  // 
  ,output [OVS-1:0]       o_tdagc_tdrssi_vld              // 
);


  genvar i,j;

  localparam PWR_MUL_OB   = (TYPE==0)? 29:31           ;   // power calculation output width
  localparam PWR_ACC_OB   = (TYPE==0)? 41:40           ;   // power accumulation output width
  localparam ACC_RSH_OB   = (TYPE==0)? 29:31           ;   // power accumulation average output width
  localparam TDRSSI_O_DELAY = 65                       ;

  wire                    w_i_frm_tick_pre1            ;
  wire [OVS-1:0]          w_i_tdagc_vld                ;
  wire [IB-1:0]           w_i_tdagc_i                  ;
  wire [IB-1:0]           w_i_tdagc_q                  ;

  wire                    w_i_bcf_enb                  ;     
  wire                    w_i_tdd_mode                 ;       

  wire [OVS*5-1:0]        w_i_tagcbackoff              ;
  wire [3:0]              w_i_ffttype                  ;
  wire [OVS-1:0]          w_i_tagcon                   ;
  wire [OVS-1:0]          w_i_calbypassflag            ;
  wire [3:0]              w_i_tagcdb_conv_mod          ;

  wire [OVS*5-1:0]        w_tagcbackoff                ;
  wire [3:0]              w_ffttype                    ;
  wire [OVS-1:0]          w_tagcon                     ;
  wire [OVS-1:0]          w_calbypassflag              ;
  wire [3:0]              w_tagcdb_conv_mod            ;

  wire                    w_ulfe_frm_tick             ;
  wire                    w_ulfe_slt_tick             ;
  wire                    w_ulfe_sym_tick             ;
  wire [6-1:0]            w_ulfe_slt_idx              ; 
  wire [4-1:0]            w_ulfe_sym_idx              ; 

  wire                    w_rafe_frm_tick             ;
  wire                    w_rafe_slt_tick             ;
  wire [6-1:0]            w_rafe_slt_idx              ;
  wire                    w_rafe_ro_tick              ;
  wire [3:0]              w_rafe_ro_idx               ;
  wire                    w_rafe_sym_tick             ;
  wire [3:0]              w_rafe_sym_idx              ;

  reg                     r_d1_ulfe_frm_tick          ;
  reg  [6-1:0]            r_d1_ulfe_slt_idx           ; 
  reg  [4-1:0]            r_d1_ulfe_sym_idx           ; 
  reg                     r_in_frm_tick               ;
  reg                     r_in_slt_tick               ;
  reg                     r_in_sym_tick               ;
  reg  [6-1:0]            r_in_slt_idx                ; 
  reg  [4-1:0]            r_in_sym_idx                ; 
  reg                     r_in_ro_tick                ;
  reg  [4-1:0]            r_in_ro_idx                 ;

  wire [OVS-1:0]          w_in_tdagc_vld              ;
  wire [IB-1:0]           w_in_tdagc_i                ;
  wire [IB-1:0]           w_in_tdagc_q                ;

  wire [OVS-1:0]          w_gpt_tdagc_vld             ;
  wire [IB-1:0]           w_gpt_tdagc_i               ;
  wire [IB-1:0]           w_gpt_tdagc_q               ;
  wire                    w_gpt_frm_tick              ;
  wire                    w_gpt_slt_tick              ;
  wire [6-1:0]            w_gpt_slt_idx               ;
  wire                    w_gpt_sym_tick              ;
  wire [4-1:0]            w_gpt_sym_idx               ;
  wire                    w_gpt_ro_tick               ;
  wire [4-1:0]            w_gpt_ro_idx                ;

  wire [OVS-1:0]          w_gpt_pwr_start             ;
  wire [OVS-1:0]          w_gpt_pwr_end               ;
  wire [OVS-1:0]          w_gpt_pwr_en                ;

  wire [6-1:0]            w_gpt_slt_idx_lock          ;
  wire [3:0]              w_gpt_sym_idx_lock          ;
  wire [3:0]              w_gpt_ro_idx_lock           ;

  wire [         OVS-1:0] w_pwr_acc_vld               ;
  wire [  PWR_ACC_OB-1:0] w_pwr_acc          [OVS-1:0];

  wire                    w_dly_acc_frm_tick          ;
  wire                    w_dly_acc_slt_tick          ;
  wire [6-1:0]            w_dly_acc_slt_idx           ;
  wire                    w_dly_acc_sym_tick          ;
  wire [4-1:0]            w_dly_acc_sym_idx           ;
  wire                    w_dly_acc_ro_tick           ;
  wire [4-1:0]            w_dly_acc_ro_idx            ;

  wire [OVS-1:0]          w_dly_acc_sym_start         ;
  wire [OVS-1:0]          w_dly_acc_sym_end           ;
  wire [OVS-1:0]          w_dly_acc_sym_en            ;

  wire [PWR_ACC_OB-1:0]   w_pwr_acc_lock     [OVS-1:0];

  wire [OVS-1:0]          w_lock_dly_acc_sym_end      ;
  reg  [3:0]              r_pwr_acc_rshift_num        ;

  wire [OVS-1:0]          w_avg_pwr_vld               ;
  wire [ACC_RSH_OB-1:0]   w_avg_pwr          [OVS-1:0];    
  wire [OVS-1:0]          w_clz_dout_vld              ;
  wire [5-1:0]            w_clz_cnt_ld_z     [OVS-1:0];
  wire [4-1:0]            w_clz_sel_bel_bits [OVS-1:0];

  reg  signed [5:0]       r_sub_target_bo    [OVS-1:0];
  wire [OVS-1:0]          w_clz_dout_vld_bo_dly       ;

  wire signed [4:0]       w_clz_sub_bo_rnd   [OVS-1:0];  
  wire [OVS-1:0]          w_clz_sub_bo_rnd_vld        ; 

  wire signed [4:0]       w_clz_bo_rnd_lck   [OVS-1:0];  
  wire [OVS-1:0]          w_clz_bo_rnd_lck_vld        ; 

  reg  [4:0]              r_gain2            [OVS-1:0];
  reg  [3:0]              r_gain1            [OVS-1:0];  

  wire [8:0]              w_gain2_tout       [OVS-1:0];
  wire [OVS-1:0]          w_gain_tout_vld             ;

  wire [4:0]              w_gain2_o_lck      [OVS-1:0];
  wire [3:0]              w_gain1_o_lck      [OVS-1:0]; 
  wire [8:0]              w_gain2_o_tout_lck [OVS-1:0];
  wire [OVS-1:0]          w_gain_tout_vld_o           ; 

  wire                    w_tagc_buf_bcf_enb          ;
  wire                    w_tagc_buf_frm_tick         ;
  wire [3:0]              w_tagc_buf_ro_idx           ;
  wire [3:0]              w_tagc_buf_sym_idx          ;
  
  wire [OVS-1:0]          w_buf_dout_vld              ;
  wire [OB-1:0]           w_buf_dout_i                ;
  wire [OB-1:0]           w_buf_dout_q                ;
  wire [OB-1:0]           w_buf_dout_i_0M             ;
  wire [OB-1:0]           w_buf_dout_q_0M             ;
  wire [OB-1:0]           w_buf_dout_i_0L             ;
  wire [OB-1:0]           w_buf_dout_q_0L             ;
  wire [OB-1:0]           w_buf_dout_i_1M             ;
  wire [OB-1:0]           w_buf_dout_q_1M             ;
  wire [OB-1:0]           w_buf_dout_i_1L             ;
  wire [OB-1:0]           w_buf_dout_q_1L             ;



  wire                    w_rout_frm_tick             ;
  wire                    w_rout_slt_tick             ;
  wire                    w_rout_sym_tick             ;
  wire [6-1:0]            w_rout_slt_idx              ; 
  wire [4-1:0]            w_rout_sym_idx              ; 
  reg                     r_rout_frm_tick             ;
  reg  [6-1:0]            r_rout_slt_idx              ; 
  reg  [4-1:0]            r_rout_sym_idx              ; 

  wire                    w_rdout_frm_tick            ;
  wire                    w_rdout_slt_tick            ;
  wire                    w_rdout_sym_tick            ;
  wire [6-1:0]            w_rdout_slt_idx             ; 
  wire [4-1:0]            w_rdout_sym_idx             ; 

  wire [OVS*9-1:0]        w_smul_sat_i_gain2_tout     ;
  wire [OVS*4-1:0]        w_smul_sat_i_gain1          ;
  wire [OVS*5-1:0]        w_smul_sat_i_gain2          ;

  wire [OVS*5-1:0]        w_smul_sat_i_tdagc_gain     ; 

  wire [OVS-1:0]          w_o_tdagc_vld               ;
  wire [OB-1:0]           w_o_tdagc_i                 ;
  wire [OB-1:0]           w_o_tdagc_q                 ;
  wire [OB-1:0]           w_o_tdagc_i_0M              ;
  wire [OB-1:0]           w_o_tdagc_q_0M              ;
  wire [OB-1:0]           w_o_tdagc_i_0L              ;
  wire [OB-1:0]           w_o_tdagc_q_0L              ;
  wire [OB-1:0]           w_o_tdagc_i_1M              ;
  wire [OB-1:0]           w_o_tdagc_q_1M              ;
  wire [OB-1:0]           w_o_tdagc_i_1L              ;
  wire [OB-1:0]           w_o_tdagc_q_1L              ;
  wire [3   :0]           w_o_tdgain1                 ;
  wire [4   :0]           w_o_tdgain2                 ; 
  wire [4   :0]           w_o_tdagc_gain              ; 

  wire                    w_o_bcf_enb                 ;
  wire                    w_o_frm_tick                ;      
  wire                    w_o_slt_tick                ; 
  wire                    w_o_sym_tick                ; 
  wire [3:0]              w_o_ro_idx                  ;      
  wire [3:0]              w_o_sym_idx                 ;  

  reg                     r_o_sfm_syn_ok              ;

  reg  [OVS-1:0]          r_o_tdagc_vld               ;
  reg  [OB-1:0]           r_o_tdagc_i                 ;
  reg  [OB-1:0]           r_o_tdagc_q                 ;
  reg  [OB-1:0]           r_o_tdagc_i_0M              ;
  reg  [OB-1:0]           r_o_tdagc_q_0M              ;
  reg  [OB-1:0]           r_o_tdagc_i_0L              ;
  reg  [OB-1:0]           r_o_tdagc_q_0L              ;
  reg  [OB-1:0]           r_o_tdagc_i_1M              ;
  reg  [OB-1:0]           r_o_tdagc_q_1M              ;
  reg  [OB-1:0]           r_o_tdagc_i_1L              ;
  reg  [OB-1:0]           r_o_tdagc_q_1L              ;
  reg  [3   :0]           r_o_tdgain1                 ;
  reg  [4   :0]           r_o_tdgain2                 ; 
  reg  [4   :0]           r_o_tdagc_gain              ; 

  reg                     r_o_bcf_enb                 ;
  reg                     r_o_frm_tick                ;      
  reg                     r_o_slt_tick                ; 
  reg                     r_o_sym_tick                ; 
  reg  [3:0]              r_o_ro_idx                  ;      
  reg  [3:0]              r_o_sym_idx                 ;  

  reg  [31:0]             r_test_frm_tick_dly_cnt     ;

  reg  [31:0]             tdagc_latency_cntr          ;   
  reg  [31:0]             tdagc_latency_cntr_lck      ; 

  wire [OVS-1:0]          w_o_rssi_vld                ;
  wire [OVS*TR-1:0]       w_o_rssi                    ;

  wire [OVS*TR-1:0]       w_o_tdagc_tdrssi            ;
  wire [OVS-1:0]          w_o_tdagc_tdrssi_vld        ;

  wire [OVS*TR-1:0]       w_o_tdagc_tdrssi_d1         ;
  wire [OVS-1:0]          w_o_tdagc_tdrssi_vld_d1     ;



ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_frm_tick_pre1   ( .i_clk(i_clk),  .i_in(i_frm_tick_pre1  ), .o_out(w_i_frm_tick_pre1  ) );
ylib_reg #( .WIDTH(OVS  ), .DEPTH(1) ) reg_shr_if_tdagc_vld       ( .i_clk(i_clk),  .i_in(i_tdagc_vld      ), .o_out(w_i_tdagc_vld      ) );
ylib_reg #( .WIDTH(IB   ), .DEPTH(1) ) reg_shr_if_tdagc_i         ( .i_clk(i_clk),  .i_in(i_tdagc_i        ), .o_out(w_i_tdagc_i        ) );
ylib_reg #( .WIDTH(IB   ), .DEPTH(1) ) reg_shr_if_tdagc_q         ( .i_clk(i_clk),  .i_in(i_tdagc_q        ), .o_out(w_i_tdagc_q        ) );

ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_bcf_enb         ( .i_clk(i_clk),  .i_in(i_bcf_enb        ), .o_out(w_i_bcf_enb        ) );
ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_tdd_mod         ( .i_clk(i_clk),  .i_in(i_tdd_mode       ), .o_out(w_i_tdd_mode       ) );

ylib_reg #( .WIDTH(5*OVS), .DEPTH(1) ) reg_shr_if_tagcbackoff     ( .i_clk(i_clk),  .i_in(i_tagcbackoff    ), .o_out(w_i_tagcbackoff    ) );
ylib_reg #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_if_ffttype         ( .i_clk(i_clk),  .i_in(i_ffttype        ), .o_out(w_i_ffttype        ) );
ylib_reg #( .WIDTH(OVS  ), .DEPTH(1) ) reg_shr_if_tagcon          ( .i_clk(i_clk),  .i_in(i_tagcon         ), .o_out(w_i_tagcon         ) );
ylib_reg #( .WIDTH(OVS  ), .DEPTH(1) ) reg_shr_if_calbypassflag   ( .i_clk(i_clk),  .i_in(i_calbypassflag  ), .o_out(w_i_calbypassflag  ) );
ylib_reg #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_if_tagcdb_conv_mod ( .i_clk(i_clk),  .i_in(i_tagcdb_conv_mod), .o_out(w_i_tagcdb_conv_mod) );

ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_rafe_frm_tick   ( .i_clk(i_clk),  .i_in(i_rafe_frm_tick  ), .o_out(w_rafe_frm_tick  ) );
ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_rafe_slt_tick   ( .i_clk(i_clk),  .i_in(i_rafe_slt_tick  ), .o_out(w_rafe_slt_tick  ) );
ylib_reg #( .WIDTH(6    ), .DEPTH(1) ) reg_shr_if_rafe_slt_idx    ( .i_clk(i_clk),  .i_in(i_rafe_slt_idx   ), .o_out(w_rafe_slt_idx   ) );
ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_rafe_ro_tick    ( .i_clk(i_clk),  .i_in(i_rafe_ro_tick   ), .o_out(w_rafe_ro_tick   ) );
ylib_reg #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_if_rafe_ro_idx     ( .i_clk(i_clk),  .i_in(i_rafe_ro_idx    ), .o_out(w_rafe_ro_idx    ) );
ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_if_rafe_sym_tick   ( .i_clk(i_clk),  .i_in(i_rafe_sym_tick  ), .o_out(w_rafe_sym_tick  ) );
ylib_reg #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_if_rafe_sym_idx    ( .i_clk(i_clk),  .i_in(i_rafe_sym_idx   ), .o_out(w_rafe_sym_idx   ) );



generate

if (TYPE==0)begin
ulfe_timer #(
    .N_CYCLE_CLK         (N_CYCLE_CLK              )
  , .SCS_IDX             (SCS_IDX                  )
  , .CP_TYPE             (CP_TYPE                  )
  , .CP_TICK             (1                        )
)
inst_input_timer
(
    .i_clk               (i_clk                    )
  , .i_frm_tick_pre1     (i_frm_tick_pre1          )
  , .o_frm_tick_pre1     (w_ulfe_frm_tick          )
  , .o_slt_tick          (w_ulfe_slt_tick          )
  , .o_sym_tick          (w_ulfe_sym_tick          )
  , .o_slt_idx           (w_ulfe_slt_idx           )
  , .o_sym_idx           (w_ulfe_sym_idx           )
);

always @ (posedge i_clk)begin
    r_d1_ulfe_frm_tick  <= w_ulfe_frm_tick   ;
    r_d1_ulfe_slt_idx   <= w_ulfe_slt_idx    ;
    r_d1_ulfe_sym_idx   <= w_ulfe_sym_idx    ;
    r_in_frm_tick       <= r_d1_ulfe_frm_tick;
    r_in_slt_tick       <= w_ulfe_slt_tick   ;
    r_in_sym_tick       <= w_ulfe_sym_tick   ;
    r_in_slt_idx        <= r_d1_ulfe_slt_idx ;
    r_in_sym_idx        <= r_d1_ulfe_sym_idx ;
    r_in_ro_tick        <= 1'b0              ;
    r_in_ro_idx         <= 4'd0              ;  
end


end else begin

always @ (posedge i_clk)begin
    r_in_frm_tick       <= w_rafe_frm_tick;  
    r_in_slt_tick       <= w_rafe_slt_tick;
    r_in_slt_idx        <= w_rafe_slt_idx ;
    r_in_sym_tick       <= w_rafe_sym_tick;
    r_in_sym_idx        <= w_rafe_sym_idx ;
    r_in_ro_tick        <= w_rafe_ro_tick ;
    r_in_ro_idx         <= w_rafe_ro_idx  ; 
end
  
end

endgenerate


ylib_reg #( .WIDTH(OVS  ), .DEPTH(2) ) reg_shr_in_delay_vld       ( .i_clk(i_clk), .i_in(w_i_tdagc_vld      ), .o_out(w_in_tdagc_vld   ) );
ylib_reg #( .WIDTH(IB   ), .DEPTH(2) ) reg_shr_in_delay_i         ( .i_clk(i_clk), .i_in(w_i_tdagc_i        ), .o_out(w_in_tdagc_i     ) );
ylib_reg #( .WIDTH(IB   ), .DEPTH(2) ) reg_shr_in_delay_q         ( .i_clk(i_clk), .i_in(w_i_tdagc_q        ), .o_out(w_in_tdagc_q     ) );  

ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_in_bcf_enb         ( .i_clk(i_clk), .i_in(w_i_bcf_enb        ), .o_out(w_bcf_enb        ) );
ylib_reg #( .WIDTH(1    ), .DEPTH(1) ) reg_shr_in_tdd_mod         ( .i_clk(i_clk), .i_in(w_i_tdd_mode       ), .o_out(w_tdd_mode       ) );

ylib_reg_clk_en #( .WIDTH(5*OVS), .DEPTH(1) ) reg_shr_in_tagcbackoff     ( .i_clk(i_clk), .i_en(r_in_slt_tick), .i_in(w_i_tagcbackoff    ), .o_out(w_tagcbackoff    ) );
ylib_reg_clk_en #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_in_ffttype         ( .i_clk(i_clk), .i_en(r_in_slt_tick), .i_in(w_i_ffttype        ), .o_out(w_ffttype        ) );
ylib_reg_clk_en #( .WIDTH(OVS  ), .DEPTH(1) ) reg_shr_in_tagcon          ( .i_clk(i_clk), .i_en(r_in_slt_tick), .i_in(w_i_tagcon         ), .o_out(w_tagcon         ) );
ylib_reg_clk_en #( .WIDTH(OVS  ), .DEPTH(1) ) reg_shr_in_calbypassflag   ( .i_clk(i_clk), .i_en(r_in_sym_tick), .i_in(w_i_calbypassflag  ), .o_out(w_calbypassflag  ) );
ylib_reg_clk_en #( .WIDTH(4    ), .DEPTH(1) ) reg_shr_in_tagcdb_conv_mod ( .i_clk(i_clk), .i_en(r_in_slt_tick), .i_in(w_i_tagcdb_conv_mod), .o_out(w_tagcdb_conv_mod) );


tagc_gen_pwr_timing  #
  (
    .TYPE                (TYPE                     )
  , .OC                  (OC                       )
  , .OVS                 (OVS                      )
  , .IB                  (IB                       )
  )
inst_tagc_gen_pwr_acc_timing
  (
    .i_rst               (i_rst                    )
  , .i_clk               (i_clk                    )

  , .i_ffttype           (w_ffttype                )
       
  , .i_tdagc_vld         (w_in_tdagc_vld           )
  , .i_tdagc_i           (w_in_tdagc_i             )
  , .i_tdagc_q           (w_in_tdagc_q             )
       
  , .i_frm_tick          (r_in_frm_tick            )
  , .i_slt_tick          (r_in_slt_tick            )
  , .i_slt_idx           (r_in_slt_idx             )
  , .i_sym_tick          (r_in_sym_tick            )
  , .i_sym_idx           (r_in_sym_idx             )
  , .i_ro_tick           (r_in_ro_tick             )
  , .i_ro_idx            (r_in_ro_idx              )
     
  , .o_tdagc_vld         (w_gpt_tdagc_vld          )
  , .o_tdagc_i           (w_gpt_tdagc_i            )
  , .o_tdagc_q           (w_gpt_tdagc_q            )
       
  , .o_frm_tick          (w_gpt_frm_tick           )
  , .o_slt_tick          (w_gpt_slt_tick           )
  , .o_slt_idx           (w_gpt_slt_idx            )
  , .o_ro_tick           (w_gpt_ro_tick            )
  , .o_ro_idx            (w_gpt_ro_idx             )
  , .o_sym_tick          (w_gpt_sym_tick           )
  , .o_sym_idx           (w_gpt_sym_idx            )
       
  , .o_pwr_start         (w_gpt_pwr_start          )
  , .o_pwr_end           (w_gpt_pwr_end            )
  , .o_pwr_en            (w_gpt_pwr_en             )
    
  , .o_slt_idx_lock      (w_gpt_slt_idx_lock       )
  , .o_sym_idx_lock      (w_gpt_sym_idx_lock       )
  , .o_ro_idx_lock       (w_gpt_ro_idx_lock        )
);


generate

  for (i = 0; i < OVS; i = i + 1)begin : INST_PWR_SUM

pwr_sum  #
  (
    .IB                  (IB                       )
  , .CMB                 (PWR_MUL_OB               )
  , .SUMB                (PWR_ACC_OB               )
  )
inst_pwr_acc
  (
    .i_clk               (i_clk                    )
  , .i_rst               (i_rst                    )

  , .i_symbol_tick       (r_in_sym_tick            )
  , .i_sum_clr           (w_gpt_pwr_start[i]       )
  , .i_en                (w_gpt_pwr_en[i]          )
  , .i_din_vld           (w_gpt_tdagc_vld[i]       )
  , .i_din_i             (w_gpt_tdagc_i            )
  , .i_din_q             (w_gpt_tdagc_q            )

  , .o_dout_vld          (w_pwr_acc_vld[i]         )
  , .o_dout              (w_pwr_acc[i]             )
  );

  end
endgenerate



ylib_reg #( .WIDTH(1        ), .DEPTH(15) ) reg_shr_acc_frm_tick     ( .i_clk(i_clk), .i_in(w_gpt_frm_tick), .o_out(w_dly_acc_frm_tick ) );
ylib_reg #( .WIDTH(1        ), .DEPTH(15) ) reg_shr_acc_slt_tick     ( .i_clk(i_clk), .i_in(w_gpt_slt_tick), .o_out(w_dly_acc_slt_tick ) );
ylib_reg #( .WIDTH(6        ), .DEPTH(15) ) reg_shr_acc_slt_idx      ( .i_clk(i_clk), .i_in(w_gpt_slt_idx ), .o_out(w_dly_acc_slt_idx  ) );
ylib_reg #( .WIDTH(1        ), .DEPTH(15) ) reg_shr_acc_ro_tick      ( .i_clk(i_clk), .i_in(w_gpt_sym_tick), .o_out(w_dly_acc_sym_tick ) );
ylib_reg #( .WIDTH(4        ), .DEPTH(15) ) reg_shr_acc_ro_idx       ( .i_clk(i_clk), .i_in(w_gpt_sym_idx ), .o_out(w_dly_acc_sym_idx  ) );
ylib_reg #( .WIDTH(1        ), .DEPTH(15) ) reg_shr_acc_sym_tick     ( .i_clk(i_clk), .i_in(w_gpt_ro_tick ), .o_out(w_dly_acc_ro_tick  ) );
ylib_reg #( .WIDTH(4        ), .DEPTH(15) ) reg_shr_acc_sym_idx      ( .i_clk(i_clk), .i_in(w_gpt_ro_idx  ), .o_out(w_dly_acc_ro_idx   ) );

ylib_reg #( .WIDTH(OVS      ), .DEPTH(15) ) reg_shr_acc_sym_start    ( .i_clk(i_clk), .i_in(w_gpt_pwr_start), .o_out(w_dly_acc_sym_start) );
ylib_reg #( .WIDTH(OVS      ), .DEPTH(15) ) reg_shr_acc_sym_end      ( .i_clk(i_clk), .i_in(w_gpt_pwr_end  ), .o_out(w_dly_acc_sym_end  ) );
ylib_reg #( .WIDTH(OVS      ), .DEPTH(15) ) reg_shr_acc_sym_en       ( .i_clk(i_clk), .i_in(w_gpt_pwr_en   ), .o_out(w_dly_acc_sym_en   ) );




generate

for (i = 0 ; i < OVS; i = i + 1)begin : INST_LIB_REG_PWR_ACC_LOCK

ylib_reg_clk_en #( .WIDTH(PWR_ACC_OB ) ,.DEPTH(1)) reg_lth_pwr_acc_lock (.i_clk(i_clk),.i_en(w_dly_acc_sym_end[i]),.i_in(w_pwr_acc[i]),.o_out(w_pwr_acc_lock[i]));      

end
endgenerate


ylib_reg #( .WIDTH(OVS), .DEPTH(2) ) reg_shr_lock_dly_acc_sym_end ( .i_clk(i_clk), .i_in(w_dly_acc_sym_end   ), .o_out(w_lock_dly_acc_sym_end ) );



always @ (posedge i_clk)begin
  r_pwr_acc_rshift_num <= 4'd9 + w_ffttype;
end  

generate

for (i = 0 ; i < OVS; i = i + 1)begin : INST_CNT_LD_ZEROS_AND_GAIN2_LKP_TBL

ylib_sshftvd_sat # // delay3
(.IB(PWR_ACC_OB),.SB(4),.OB(ACC_RSH_OB),.ROUND_TYPE("TRUNC"),.SAT_TYPE("NONSYMMETRIC"))
inst_right_shift_n
(
    .i_clk               (i_clk                    )
  
  , .i_shft              (r_pwr_acc_rshift_num     )
  , .i_din_vld           (w_lock_dly_acc_sym_end[i])
  , .i_din               (w_pwr_acc_lock[i]        )

  , .o_dout_vld          (w_avg_pwr_vld[i]         )
  , .o_dout              (w_avg_pwr[i]             )
);


cnt_ld_zeros_32  #(.IB(ACC_RSH_OB),.NU(4),.CLZOB(5),.SBBOB(4))
  inst_cnt_ld_zeros
  (
    .i_clk               (i_clk                    )
  , .i_rst               (i_rst                    )

  , .i_symbol_tick       (r_in_sym_tick            )
  , .i_din_vld           (w_avg_pwr_vld[i]         )
  , .i_din               (w_avg_pwr[i]             )

  , .o_dout_vld          (w_clz_dout_vld[i]        )
  , .o_cnt_ld_z          (w_clz_cnt_ld_z[i]        )
  , .o_sel_bel_bits      (w_clz_sel_bel_bits[i]    )
);


always@(posedge i_clk)begin
  r_sub_target_bo[i] <= $signed({1'b0,w_clz_cnt_ld_z[i]}) - $signed({1'b0,w_tagcbackoff[i*5+4:i*5]}); 
end

ylib_reg #( .WIDTH(1      ), .DEPTH(12) ) reg_shr_dly_cnt_ld_zeros_vld ( .i_clk(i_clk), .i_in(w_clz_dout_vld[i] ), .o_out(w_clz_dout_vld_bo_dly[i]) );


ylib_sshftd_sat #(.IB(6),.SF(0),.OB(5),.ROUND_TYPE("SYMMETRIC_ROUND"),.SAT_TYPE("SYMMETRIC"))
  inst_clz_bo_sat
(
    .i_clk               (i_clk                    )
    
  , .i_din_vld           (w_clz_dout_vld_bo_dly[i] )
  , .i_din               (r_sub_target_bo[i]       )

  , .o_dout_vld          (w_clz_sub_bo_rnd_vld[i]  )
  , .o_dout              (w_clz_sub_bo_rnd[i]      )
);

ylib_reg_clk_en #( .WIDTH(5  ), .DEPTH(1))  reg_lth_clz_bo_rnd_lck     ( .i_clk(i_clk), .i_en(w_clz_sub_bo_rnd_vld[i]),	.i_in(w_clz_sub_bo_rnd[i])			,.o_out(w_clz_bo_rnd_lck[i]		));      
ylib_reg_clk_en #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_clz_bo_rnd_lck_vld ( .i_clk(i_clk), .i_en(1'b1), 					.i_in(w_clz_sub_bo_rnd_vld[i]   )	,.o_out(w_clz_bo_rnd_lck_vld[i] ));


always@(posedge i_clk)begin
  if (w_tagcon[i] == 1'b1 && w_calbypassflag[i] == 1'b0)begin
    r_gain1[i] <=  w_clz_bo_rnd_lck[i][4:1];
    r_gain2[i] <= {w_clz_bo_rnd_lck[i][0],w_clz_sel_bel_bits[i]};
  end else begin
    r_gain1[i] <= 4'd0;
    r_gain2[i] <= 5'd0;
  end
end

agc_tbl_rom inst_agc_tbl_rom 
(
    .i_clk               (i_clk                   )
  , .i_rst               (i_rst                   )
   
  , .i_idx               (r_gain2[i]              )
  , .o_d                 (w_gain2_tout[i]         )
);   


ylib_reg #( .WIDTH(1   ), .DEPTH(2 ) ) reg_shr_gain_vld ( .i_clk(i_clk), .i_in(w_clz_bo_rnd_lck_vld[i]   ), .o_out(w_gain_tout_vld[i]) );

ylib_reg_clk_en #( .WIDTH(4 ),.DEPTH(1)) reg_lth_gain1_lock (.i_clk(i_clk),.i_en(w_gain_tout_vld[i]),.i_in(r_gain1[i]     ),.o_out(w_gain1_o_lck[i])      ); 
ylib_reg_clk_en #( .WIDTH(5 ),.DEPTH(1)) reg_lth_gain2_lock (.i_clk(i_clk),.i_en(w_gain_tout_vld[i]),.i_in(r_gain2[i]     ),.o_out(w_gain2_o_lck[i])      ); 
ylib_reg_clk_en #( .WIDTH(9 ),.DEPTH(1)) reg_lth_tout_lock  (.i_clk(i_clk),.i_en(w_gain_tout_vld[i]),.i_in(w_gain2_tout[i]),.o_out(w_gain2_o_tout_lck[i]) ); 

ylib_reg #( .WIDTH(1   ), .DEPTH(2 ) ) reg_shr_gain_vld_o  ( .i_clk(i_clk), .i_in(w_gain_tout_vld[i]   ), .o_out(w_gain_tout_vld_o[i]) );      

    end  
endgenerate


//tagc_buf_top  #
//  (
//    .TYPE                (TYPE                    )
//  , .SCS                 (SCS_IDX                 )
//  , .OC                  (OC                      )
//  , .OVS                 (OVS                     )
//  , .OVS_offset          (0)//4  )
//  , .IB                  (IB                      )
//  , .OB                  (IB                      )
//  , .VENDOR              (VENDOR                  )
//  )
//  inst_tagc_buf_top
//  (
//    .i_rst               (i_rst                   )
//  , .i_clk               (i_clk                   )
//
//  , .i_wr_resync_frm_tick(r_in_frm_tick           )
//  , .i_rd_resync_frm_tick(w_rout_frm_tick         )
//  , .i_ffttype           (w_ffttype               )
//
//  , .i_bcf_enb           (w_bcf_enb               )
//  , .i_frm_tick          (w_gpt_frm_tick          )
//  , .i_ro_idx            (w_gpt_ro_idx            )
//  , .i_sym_idx           (w_gpt_sym_idx           )
//
//
//  , .i_sym_end           (w_gpt_pwr_end           )
//  , .i_sym_start         (w_gpt_pwr_start         )
//
//  , .i_din_vld           (w_gpt_tdagc_vld         )
//  , .i_din_i             (w_gpt_tdagc_i           )
//  , .i_din_q             (w_gpt_tdagc_q           )
//
//
//  , .i_dout_rqt          (w_rdout_sym_tick        )
//  , .i_gain_vld          (w_gain_tout_vld_o[0]    )
//
//  , .o_bcf_enb           (w_tagc_buf_bcf_enb      )
//  , .o_frm_tick          (w_tagc_buf_frm_tick     )
//  , .o_ro_idx            (w_tagc_buf_ro_idx       )
//  , .o_sym_idx           (w_tagc_buf_sym_idx      )
//      
//  , .o_dout_vld          (w_buf_dout_vld          )
//  , .o_dout_i            (w_buf_dout_i            )
//  , .o_dout_q            (w_buf_dout_q            )
//
//);

tagc_buf_top_aie #
  (
    .TYPE                (TYPE                    )
  , .SCS                 (SCS_IDX                 )
  , .OC                  (OC                      )
  , .OVS                 (OVS                     )
  , .OVS_offset          (0)//4  )
  , .IB                  (IB                      )
  , .OB                  (IB                      )
  , .VENDOR              (VENDOR                  )
  )
  inst_tagc_buf_top_aie
  (
    .i_rst               (i_rst                   )
  , .i_clk               (i_clk                   )

  , .i_wr_resync_frm_tick(r_in_frm_tick           )
//  , .i_rd_resync_frm_tick(w_rout_frm_tick         )
//  , .i_ffttype           (w_ffttype               )
//
//  , .i_bcf_enb           (w_bcf_enb               )
  , .i_frm_tick          (w_gpt_frm_tick          )
//  , .i_ro_idx            (w_gpt_ro_idx            )
  , .i_sym_idx           (w_gpt_sym_idx           )

  , .i_sym_end           (w_gpt_pwr_end           )
  , .i_sym_start         (w_gpt_pwr_start         )

  , .i_din_vld           (w_gpt_tdagc_vld         )
  , .i_din_i             (w_gpt_tdagc_i           )
  , .i_din_q             (w_gpt_tdagc_q           )


  , .i_dout_rqt          (w_rdout_sym_tick        )
  , .i_gain_vld          (w_gain_tout_vld_o[0]    )

//  , .o_bcf_enb           ( )
  , .o_frm_tick          (w_tagc_buf_frm_tick)
//  , .o_ro_idx            (        )
//  , .o_sym_idx           (       )
      
  , .o_dout_vld          (w_buf_dout_vld        )
  , .o_dout_i_0M         (w_buf_dout_i_0M       )
  , .o_dout_q_0M         (w_buf_dout_q_0M       )
  , .o_dout_i_0L         (w_buf_dout_i_0L       )
  , .o_dout_q_0L         (w_buf_dout_q_0L       )
  , .o_dout_i_1M         (w_buf_dout_i_1M       )
  , .o_dout_q_1M         (w_buf_dout_q_1M       )
  , .o_dout_i_1L         (w_buf_dout_i_1L       )
  , .o_dout_q_1L         (w_buf_dout_q_1L       )

);



ulfe_timer #(
    .N_CYCLE_CLK         (N_CYCLE_CLK             )
  , .SCS_IDX             (SCS_IDX                 )
  , .CP_TYPE             (CP_TYPE                 )
  , .CP_TICK             (1                       )
)
inst_rdout_timer
(
    .i_clk               (i_clk                   )
  , .i_frm_tick_pre1     (w_tagc_buf_frm_tick     )
  , .o_frm_tick_pre1     (w_rout_frm_tick         )
  , .o_slt_tick          (w_rout_slt_tick         )
  , .o_sym_tick          (w_rout_sym_tick         )
  , .o_slt_idx           (w_rout_slt_idx          )
  , .o_sym_idx           (w_rout_sym_idx          )
);


always @ (posedge i_clk)begin
  r_rout_frm_tick <= w_rout_frm_tick;
  r_rout_slt_idx  <= w_rout_slt_idx ;
  r_rout_sym_idx  <= w_rout_sym_idx ;
end

assign w_rdout_frm_tick        = r_rout_frm_tick  ;
assign w_rdout_slt_tick        = w_rout_slt_tick  ;
assign w_rdout_sym_tick        = w_rout_sym_tick  ;
assign w_rdout_slt_idx         = r_rout_slt_idx   ;
assign w_rdout_sym_idx         = r_rout_sym_idx   ;


for (i = 0; i < OVS; i = i + 1)begin : MAKE_GAIN_TO_SMUL_SAT
assign w_smul_sat_i_gain2_tout[i*9+8:i*9] = w_gain2_o_tout_lck[i] ;
assign w_smul_sat_i_gain1     [i*4+3:i*4] = w_gain1_o_lck[i];
assign w_smul_sat_i_gain2     [i*5+4:i*5] = w_gain2_o_lck[i];
assign w_smul_sat_i_tdagc_gain[i*5+4:i*5] = w_clz_bo_rnd_lck[i];
end

tagc_smul_sat  #(.TYPE(TYPE),.OC(OC),.OVS(OVS),.IB(IB),.OB(OB))
  inst_tagc_smul_sat_0M
  (
    .i_rst               (i_rst                   )
  , .i_clk               (i_clk                   )

  , .i_gain2_tout        (w_smul_sat_i_gain2_tout )
  , .i_gain1             (w_smul_sat_i_gain1      )
  , .i_gain2             (w_smul_sat_i_gain2      )
  , .i_tdagc_gain        (w_smul_sat_i_tdagc_gain )

  , .i_tdagc_vld         (w_buf_dout_vld          )
  , .i_tdagc_i           (w_buf_dout_i_0M         )
  , .i_tdagc_q           (w_buf_dout_q_0M         )

  , .o_tdagc_vld         (w_o_tdagc_vld           )
  , .o_tdagc_i           (w_o_tdagc_i_0M          )
  , .o_tdagc_q           (w_o_tdagc_q_0M          )
  , .o_tdgain1           (w_o_tdgain1             )  
  , .o_tdgain2           (w_o_tdgain2             )
  , .o_tdagc_gain        (w_o_tdagc_gain          )   
);
tagc_smul_sat  #(.TYPE(TYPE),.OC(OC),.OVS(OVS),.IB(IB),.OB(OB))
  inst_tagc_smul_sat_0L
  (
    .i_rst               (i_rst                   )
  , .i_clk               (i_clk                   )

  , .i_gain2_tout        (w_smul_sat_i_gain2_tout )
  , .i_gain1             (w_smul_sat_i_gain1      )
  , .i_gain2             (w_smul_sat_i_gain2      )
  , .i_tdagc_gain        (w_smul_sat_i_tdagc_gain )

  , .i_tdagc_vld         (w_buf_dout_vld          )
  , .i_tdagc_i           (w_buf_dout_i_0L         )
  , .i_tdagc_q           (w_buf_dout_q_0L         )

  , .o_tdagc_vld         (          )
  , .o_tdagc_i           (w_o_tdagc_i_0L          )
  , .o_tdagc_q           (w_o_tdagc_q_0L          )
  , .o_tdgain1           (          )  
  , .o_tdgain2           (          )
  , .o_tdagc_gain        (          )   
);
tagc_smul_sat  #(.TYPE(TYPE),.OC(OC),.OVS(OVS),.IB(IB),.OB(OB))
  inst_tagc_smul_sat_1M
  (
    .i_rst               (i_rst                   )
  , .i_clk               (i_clk                   )

  , .i_gain2_tout        (w_smul_sat_i_gain2_tout )
  , .i_gain1             (w_smul_sat_i_gain1      )
  , .i_gain2             (w_smul_sat_i_gain2      )
  , .i_tdagc_gain        (w_smul_sat_i_tdagc_gain )

  , .i_tdagc_vld         (w_buf_dout_vld          )
  , .i_tdagc_i           (w_buf_dout_i_1M         )
  , .i_tdagc_q           (w_buf_dout_q_1M         )

  , .o_tdagc_vld         (          )
  , .o_tdagc_i           (w_o_tdagc_i_1M          )
  , .o_tdagc_q           (w_o_tdagc_q_1M          )
  , .o_tdgain1           (         )  
  , .o_tdgain2           (         )
  , .o_tdagc_gain        (         )   
);
tagc_smul_sat  #(.TYPE(TYPE),.OC(OC),.OVS(OVS),.IB(IB),.OB(OB))
  inst_tagc_smul_sat_1L
  (
    .i_rst               (i_rst                   )
  , .i_clk               (i_clk                   )

  , .i_gain2_tout        (w_smul_sat_i_gain2_tout )
  , .i_gain1             (w_smul_sat_i_gain1      )
  , .i_gain2             (w_smul_sat_i_gain2      )
  , .i_tdagc_gain        (w_smul_sat_i_tdagc_gain )

  , .i_tdagc_vld         (w_buf_dout_vld          )
  , .i_tdagc_i           (w_buf_dout_i_1L         )
  , .i_tdagc_q           (w_buf_dout_q_1L         )

  , .o_tdagc_vld         (          )
  , .o_tdagc_i           (w_o_tdagc_i_1L          )
  , .o_tdagc_q           (w_o_tdagc_q_1L          )
  , .o_tdgain1           (         )  
  , .o_tdgain2           (         )
  , .o_tdagc_gain        (         )   
);


ylib_reg #( .WIDTH(1   ), .DEPTH(15 ) ) reg_shr_buf_bcf_enb_o   ( .i_clk(i_clk), .i_in( w_tagc_buf_bcf_enb), .o_out( w_o_bcf_enb  ) );
ylib_reg #( .WIDTH(1   ), .DEPTH(15 ) ) reg_shr_frm_tick_sfr_o  ( .i_clk(i_clk), .i_in( w_rdout_frm_tick  ), .o_out( w_o_frm_tick ) );
ylib_reg #( .WIDTH(1   ), .DEPTH(15 ) ) reg_shr_slt_tick_sfr_o  ( .i_clk(i_clk), .i_in( w_rdout_slt_tick  ), .o_out( w_o_slt_tick ) );
ylib_reg #( .WIDTH(1   ), .DEPTH(15 ) ) reg_shr_sym_tick_sfr_o  ( .i_clk(i_clk), .i_in( w_rdout_sym_tick  ), .o_out( w_o_sym_tick ) );
ylib_reg #( .WIDTH(4   ), .DEPTH(14 ) ) reg_shr_rafe_ro_idx_o   ( .i_clk(i_clk), .i_in( w_tagc_buf_ro_idx ), .o_out( w_o_ro_idx   ) );
ylib_reg #( .WIDTH(4   ), .DEPTH(14 ) ) reg_shr_rafe_sym_idx_o  ( .i_clk(i_clk), .i_in( w_tagc_buf_sym_idx), .o_out( w_o_sym_idx  ) );

always @ (posedge i_clk)begin
  if (i_rst)begin
    r_o_sfm_syn_ok <= 1'b0;
  end else if (w_rdout_frm_tick)begin
    r_o_sfm_syn_ok <= 1'b1;
  end
end

always @ (posedge i_clk)begin
  if (r_o_sfm_syn_ok)begin
    r_o_tdagc_vld <= w_o_tdagc_vld ;
    r_o_tdagc_i_0M   <= w_o_tdagc_i_0M   ;
    r_o_tdagc_q_0M   <= w_o_tdagc_q_0M   ;
    r_o_tdagc_i_0L   <= w_o_tdagc_i_0L   ;
    r_o_tdagc_q_0L   <= w_o_tdagc_q_0L   ;
    r_o_tdagc_i_1M   <= w_o_tdagc_i_1M   ;
    r_o_tdagc_q_1M   <= w_o_tdagc_q_1M   ;
    r_o_tdagc_i_1L   <= w_o_tdagc_i_1L   ;
    r_o_tdagc_q_1L   <= w_o_tdagc_q_1L   ;
    r_o_tdgain1   <= w_o_tdgain1   ;
    r_o_tdgain2   <= w_o_tdgain2   ;
    r_o_tdagc_gain<= w_o_tdagc_gain;
    r_o_bcf_enb   <= w_o_bcf_enb   ;
    r_o_frm_tick  <= w_o_frm_tick  ;
    r_o_slt_tick  <= w_o_slt_tick  ;
    r_o_sym_tick  <= w_o_sym_tick  ;
    r_o_ro_idx    <= w_o_ro_idx    ;
    r_o_sym_idx   <= w_o_sym_idx   ;
  end else begin
    r_o_tdagc_vld <= 'd0           ;
    r_o_tdagc_i   <= 'd0           ;
    r_o_tdagc_q   <= 'd0           ;
    r_o_tdgain1   <= 'd0           ;
    r_o_tdgain2   <= 'd0           ;
    r_o_tdagc_gain<= 'd0           ;
    r_o_bcf_enb   <= 'd0           ;
    r_o_frm_tick  <= 'd0           ;
    r_o_slt_tick  <= 'd0           ;
    r_o_sym_tick  <= 'd0           ;
    r_o_ro_idx    <= 'd0           ;
    r_o_sym_idx   <= 'd0           ;    
  end
end


always @ (posedge i_clk)begin
  if (w_o_frm_tick)begin
    r_test_frm_tick_dly_cnt <= 'd0;
  end else begin
    r_test_frm_tick_dly_cnt <= r_test_frm_tick_dly_cnt + 1'b1;
  end
end



assign o_frm_tick       = r_o_frm_tick  ;  
assign o_slt_tick       = r_o_slt_tick  ; 
assign o_sym_tick       = r_o_sym_tick  ;
assign o_rafe_ro_idx    = r_o_ro_idx    ;   
assign o_rafe_sym_idx   = r_o_sym_idx   ;   

assign o_tdagc_vld      = r_o_tdagc_vld ;  
assign o_tdagc_i_0M        = r_o_tdagc_i_0M   ;  
assign o_tdagc_q_0M        = r_o_tdagc_q_0M   ; 
assign o_tdagc_i_0L        = r_o_tdagc_i_0L   ;  
assign o_tdagc_q_0L        = r_o_tdagc_q_0L   ; 
assign o_tdagc_i_1M        = r_o_tdagc_i_1M   ;  
assign o_tdagc_q_1M        = r_o_tdagc_q_1M   ; 
assign o_tdagc_i_1L        = r_o_tdagc_i_1L   ;  
assign o_tdagc_q_1L        = r_o_tdagc_q_1L   ; 
assign o_tdgain1        = r_o_tdgain1   ;
assign o_tdgain2        = r_o_tdgain2   ;
assign o_tdagc_gain     = r_o_tdagc_gain;

assign o_bcf_enb        = w_o_bcf_enb  ;
assign o_tdd_mode       = 1'b0         ;


//// calculate process delay

always @ (posedge i_clk)begin
  if (w_i_frm_tick_pre1)begin
    tdagc_latency_cntr <= 4;    
  end else begin
    if (tdagc_latency_cntr[31] == 1'b0)begin
      tdagc_latency_cntr <= tdagc_latency_cntr + 1'b1;
    end
  end
end

always @ (posedge i_clk)begin
  if (w_o_frm_tick)begin
    tdagc_latency_cntr_lck <= tdagc_latency_cntr;
  end
end

//assign o_tdagc_latency  = tdagc_latency_cntr_lck;


//// output TDRSSI

for (i = 0; i < OVS; i = i + 1)begin : MAKE_RSSI_OUTPUT
assign w_o_rssi_vld[i] =  w_avg_pwr_vld[i];
assign w_o_rssi[TR*(i+1)-1:TR*i]     =  {{(TR-ACC_RSH_OB){1'b0}},w_avg_pwr[i]};
end


ylib_reg #( .WIDTH(OVS    ), .DEPTH(TDRSSI_O_DELAY ) ) reg_dly_tdrssi_vld   ( .i_clk(i_clk), .i_in( w_o_rssi_vld  ), .o_out( w_o_tdagc_tdrssi_vld  ) );
ylib_reg #( .WIDTH(OVS*TR ), .DEPTH(TDRSSI_O_DELAY ) ) reg_dly_tdrssi_data  ( .i_clk(i_clk), .i_in( w_o_rssi      ), .o_out( w_o_tdagc_tdrssi      ) );


ylib_reg #( .WIDTH(OVS    ), .DEPTH(1 ) ) reg_dly1_tdrssi_vld   ( .i_clk(i_clk), .i_in( w_o_tdagc_tdrssi_vld  ), .o_out( w_o_tdagc_tdrssi_vld_d1  ) );
generate
for(i = 0 ; i < OVS ; i = i + 1)begin
ylib_reg_clk_en #( .WIDTH(32) ,.DEPTH(1)) reg_lth_rssi_lock  (.i_clk(i_clk),.i_en(w_o_tdagc_tdrssi_vld[i]),.i_in(w_o_tdagc_tdrssi[TR*(i+1)-1:TR*i]),.o_out(w_o_tdagc_tdrssi_d1[TR*(i+1)-1:TR*i]) );   
end  
endgenerate
            
assign o_tdagc_tdrssi     = w_o_tdagc_tdrssi_d1;
assign o_tdagc_tdrssi_vld = w_o_tdagc_tdrssi_vld_d1;


endmodule
