// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

 ////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : agc_tbl_rom
//  Author       : Han Xiangdong
//  Description  : agc Table
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.12 |Han xiangdong  | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module agc_tbl_rom (
      input  wire                  i_clk       // Clock 
    , input  wire                  i_rst       // Reset

    , input  wire        [ 5-1:0]  i_idx       // agc Table index
    , output reg         [ 9-1:0]  o_d         // OUtput agc       
);                       


always @ (posedge i_clk) begin
    case(i_idx)
        5'd00 : o_d <= 9'd256;
        5'd01 : o_d <= 9'd248;
        5'd02 : o_d <= 9'd241;
        5'd03 : o_d <= 9'd235;
        5'd04 : o_d <= 9'd229;
        5'd05 : o_d <= 9'd223;
        5'd06 : o_d <= 9'd218;
        5'd07 : o_d <= 9'd214;
        5'd08 : o_d <= 9'd209;
        5'd09 : o_d <= 9'd205;
        5'd10 : o_d <= 9'd201;
        5'd11 : o_d <= 9'd197;
        5'd12 : o_d <= 9'd194;
        5'd13 : o_d <= 9'd190;
        5'd14 : o_d <= 9'd187;
        5'd15 : o_d <= 9'd184;
        5'd16 : o_d <= 9'd362;
        5'd17 : o_d <= 9'd351;
        5'd18 : o_d <= 9'd341;
        5'd19 : o_d <= 9'd332;
        5'd20 : o_d <= 9'd324;
        5'd21 : o_d <= 9'd316;
        5'd22 : o_d <= 9'd309;
        5'd23 : o_d <= 9'd302;
        5'd24 : o_d <= 9'd296;
        5'd25 : o_d <= 9'd290;
        5'd26 : o_d <= 9'd284;
        5'd27 : o_d <= 9'd279;
        5'd28 : o_d <= 9'd274;
        5'd29 : o_d <= 9'd269;
        5'd30 : o_d <= 9'd264;
        5'd31 : o_d <= 9'd260; 
        default:o_d <= 9'd256;
    endcase
end
       
                                
endmodule


