// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : 
//  Module       : ulfe_tagc
//  Author       : Han Xiangdong
//  Description  : Power Calculation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module ulfe_tagc_aie  #
  (
   parameter OC           = 1                             // 1: hovs2  2: hovs4  3:hovs8                   
  ,parameter OVS          = 2**OC                         // 0: 2      1:4       2:8
  ,parameter IB           = 15                            // IQ input data width
  ,parameter OB           = 15                            // IQ output data width
  ,parameter TR           = 32                            // output RSSI data width   
  ,parameter N_CYCLE_CLK  =245760000                      
  ,parameter SCS_IDX      =1                              //{0~4} --> {15k, 30k, 60k, 120k, 240k}
  ,parameter CP_TYPE      =0                              //0:normal, 1:extended
  ,parameter VENDOR       ="Xilinx"
  ,parameter FHTYPE       ="ORAN"
  )
  (
   input                  i_rst                           //          
  ,input                  i_clk                           //          

  ,input                  i_frm_tick_pre1                 // 10ms tick
  ,input  [OVS-1:0]       i_tdagc_vld                     // 
  ,input  [IB-1:0]        i_tdagc_i                       // 
  ,input  [IB-1:0]        i_tdagc_q                       // 

  ,input                  i_bcf_enb                       // 
  ,input                  i_tdd_mode                      // 

  ,input  [OVS*5-1:0]     i_tagcbackoff                   // agc back off
  ,input  [3:0]           i_ffttype                       // 0:512   1:1024    2:2048    3:4096
  ,input  [OVS-1:0]       i_tagcon                        // 1:on        0:off
  ,input  [OVS-1:0]       i_calbypassflag                 // 0:no bypass 1:bypass for calibation pattern
  ,input  [3:0]           i_tagcdb_conv_mod               //

  ,output                 o_frm_tick                      // 
  ,output                 o_slt_tick                      // 
  ,output                 o_sym_tick                      // 

  ,output [OVS-1:0]       o_tdagc_vld                     // 
  ,output [OB-1:0]        o_tdagc_i_0M                       // 
  ,output [OB-1:0]        o_tdagc_q_0M                       // 
  ,output [OB-1:0]        o_tdagc_i_0L                       // 
  ,output [OB-1:0]        o_tdagc_q_0L                       // 
  ,output [OB-1:0]        o_tdagc_i_1M                       // 
  ,output [OB-1:0]        o_tdagc_q_1M                       // 
  ,output [OB-1:0]        o_tdagc_i_1L                       // 
  ,output [OB-1:0]        o_tdagc_q_1L                       // 

  ,output [OVS*TR-1:0]    o_tdagc_tdrssi                  // 
  ,output [OVS-1:0]       o_tdagc_tdrssi_vld              // 

  ,output [4-1 :0]        o_tdgain1                       // 
  ,output [5-1 :0]        o_tdgain2                       // 
  ,output [5-1 :0]        o_tdagc_gain                    // 
  ,output                 o_bcf_enb                       // 
  ,output                 o_tdd_mode                      // 

//  ,output [31:0]          o_tdagc_latency                 // 

  ,input  [0:0]           i_tdrssi_trigger                //
  ,input  [8-1:0]         i_tdrssi_start_slt_idx          //
  ,input  [4-1:0]         i_tdrssi_start_sym_idx          //
  ,input  [5-1:0]         i_tdrssi_syms_size              //
  ,output                 o_tdrssi_cap_done               //
  ,input  [4-1:0]         i_tdrssi_rd_symidx              //
  ,input                  i_tdrssi_rd_rqst                //
  ,output                 o_tdrssi_vld                    //
  ,output [OVS*TR-1:0]    o_tdrssi                        
);

  wire [OVS*TR-1:0]       w_tdagc_tdrssi                  ;
  wire [OVS-1:0]          w_tdagc_tdrssi_vld              ;

  wire                    w_frm_tick                      ;
  wire                    w_slt_tick                      ;
  wire                    w_sym_tick                      ;

  wire                    w_cap_tagc_tdrssi_wr_pre        ;
  wire [OVS-1:0]          w_cap_tdagc_tdrssi_vld          ;
  wire [OVS*TR-1:0]       w_cap_tdagc_tdrssi              ;

  wire [3:0]              w_rafe_ro_idx                   ;
  wire [3:0]              w_rafe_sym_idx                  ;

  wire                    w_tdagc_tdrssi_rpt_done         ;
  wire                    w_tdrssi_cap_done               ;

  reg                     r_o_tdrssi_cap_done            ;

tagc_aie  #
  (
    .TYPE                    (0                              )
  , .OC                      (OC                             )
  , .OVS                     (OVS                            )
  , .IB                      (IB                             )
  , .OB                      (OB                             )
  , .TR                      (TR                             )
  , .N_CYCLE_CLK             (N_CYCLE_CLK                    )
  , .SCS_IDX                 (SCS_IDX                        )
  , .CP_TYPE                 (CP_TYPE                        )
  , .VENDOR                  (VENDOR                         )
  )
  U_TAGC
  (

    .i_clk                   (i_clk                          )
  , .i_rst                   (i_rst                          )

  , .i_frm_tick_pre1         (i_frm_tick_pre1                )
  , .i_tdagc_vld             (i_tdagc_vld                    )
  , .i_tdagc_i               (i_tdagc_i                      )
  , .i_tdagc_q               (i_tdagc_q                      )

  , .i_bcf_enb               (i_bcf_enb                      )
  , .i_tdd_mode              (i_tdd_mode                     )

  , .i_tagcbackoff           (i_tagcbackoff                  )
  , .i_ffttype               (i_ffttype                      )
  , .i_tagcon                (i_tagcon                       )
  , .i_calbypassflag         (i_calbypassflag                )
  , .i_tagcdb_conv_mod       (i_tagcdb_conv_mod              )

  , .i_rafe_frm_tick         (1'b0                           )
  , .i_rafe_slt_tick         (1'b0                           )
  , .i_rafe_slt_idx          (6'd0                           )
  , .i_rafe_ro_tick          (1'b0                           )
  , .i_rafe_ro_idx           (4'd0                           )
  , .i_rafe_sym_tick         (1'b0                           )
  , .i_rafe_sym_idx          (4'd0                           )

  , .o_frm_tick              (w_frm_tick                     )
  , .o_slt_tick              (w_slt_tick                     )
  , .o_sym_tick              (w_sym_tick                     )
  , .o_rafe_ro_idx           (w_rafe_ro_idx                  )
  , .o_rafe_sym_idx          (w_rafe_sym_idx                 )

  , .o_tdagc_vld             (o_tdagc_vld                    )
  , .o_tdagc_i_0M            (o_tdagc_i_0M                      )
  , .o_tdagc_q_0M            (o_tdagc_q_0M                      )
  , .o_tdagc_i_0L            (o_tdagc_i_0L                      )
  , .o_tdagc_q_0L            (o_tdagc_q_0L                      )
  , .o_tdagc_i_1M            (o_tdagc_i_1M                      )
  , .o_tdagc_q_1M            (o_tdagc_q_1M                      )
  , .o_tdagc_i_1L            (o_tdagc_i_1L                      )
  , .o_tdagc_q_1L            (o_tdagc_q_1L                      )

  , .o_tdgain1               (o_tdgain1                      )
  , .o_tdgain2               (o_tdgain2                      )
  , .o_tdagc_gain            (o_tdagc_gain                   )
  , .o_bcf_enb               (o_bcf_enb                      )
  , .o_tdd_mode              (o_tdd_mode                     )

//  , .o_tdagc_latency         (o_tdagc_latency                )

  , .o_tdagc_tdrssi          (w_tdagc_tdrssi                 )
  , .o_tdagc_tdrssi_vld      (w_tdagc_tdrssi_vld             )
);


assign o_frm_tick            = w_frm_tick                   ;
assign o_slt_tick            = w_slt_tick                   ;
assign o_sym_tick            = w_sym_tick                   ;

assign o_tdagc_tdrssi        = w_tdagc_tdrssi               ;
assign o_tdagc_tdrssi_vld    = w_tdagc_tdrssi_vld           ;

generate if(FHTYPE != "ORAN") 
    begin
        tdrssi_rpt  #
          (
            .TYPE                   (0                               )
          , .OC                     (OC                              )
          , .OVS                    (OVS                             )
          , .IB                     (IB                              )
          , .OB                     (OB                              )
          , .TR                     (TR                              )
          , .N_CYCLE_CLK            (N_CYCLE_CLK                     )
          , .SCS_IDX                (SCS_IDX                         )
          , .CP_TYPE                (CP_TYPE                         )
          )
          U_TDRSSI_RPT
          (
            .i_rst                  (i_rst                           )
          , .i_clk                  (i_clk                           )
        
          , .i_tdrssi_trigger       (i_tdrssi_trigger                )
          , .i_tdrssi_start_slt_idx (i_tdrssi_start_slt_idx          )
          , .i_tdrssi_start_sym_idx (i_tdrssi_start_sym_idx          )
          , .i_tdrssi_syms_size     (i_tdrssi_syms_size              )
        
          , .i_frm_tick             (w_frm_tick                      )
          , .i_slt_tick             (w_slt_tick                      )
          , .i_sym_tick             (w_sym_tick                      )
        
        
          , .i_tdagc_tdrssi_vld     (w_tdagc_tdrssi_vld              )
          , .i_tdagc_tdrssi         (w_tdagc_tdrssi                  )
        
          , .o_tagc_tdrssi_wr_pre   (w_cap_tagc_tdrssi_wr_pre        )
          , .o_tdagc_tdrssi_vld     (w_cap_tdagc_tdrssi_vld          )
          , .o_tdagc_tdrssi         (w_cap_tdagc_tdrssi              )
          , .o_tdagc_tdrssi_rpt_done(w_tdagc_tdrssi_rpt_done         )
        );
        
        tdrssi_cap #
          (
            .AO                     (OC                              )
          , .TR                     (TR                              )
        )
        
         U_TDRSSI_CAP
        (
            .i_rst                  (i_rst                           )
          , .i_clk                  (i_clk                           )
        
          , .i_tdrssi_uls           (w_cap_tagc_tdrssi_wr_pre        )
          , .i_tdrssi_vld           (w_cap_tdagc_tdrssi_vld          )
          , .i_tdrssi               (w_cap_tdagc_tdrssi              )
        
          , .i_tdrssi_wr_rqst       (i_tdrssi_trigger                )
          , .o_tdrssi_wr_done       (w_tdrssi_cap_done               )
        
          , .i_tdrssi_rd_symidx     (i_tdrssi_rd_symidx              )
          , .i_tdrssi_rd_rqst       (i_tdrssi_rd_rqst                )
          , .o_tdrssi_vld           (o_tdrssi_vld                    )
          , .o_tdrssi               (o_tdrssi                        )
        
        );      
    end
endgenerate

always @ (posedge i_clk)begin
  if (w_tdrssi_cap_done | w_tdagc_tdrssi_rpt_done)begin
    r_o_tdrssi_cap_done <= 1'b1;
  end else begin
    r_o_tdrssi_cap_done <= 1'b0;
  end
end    
assign o_tdrssi_cap_done = r_o_tdrssi_cap_done;

endmodule
