// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : tagc_smul_sat
//  Author       : Han Xiangdong
//  Description  : Power Calculation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tagc_smul_sat  #
  (
   parameter TYPE         = 0         // 0: ULFE 1: RAFE
  ,parameter OC           = 1                            
  ,parameter OVS          = 2**OC     // 0:2 , 1:4 , 2:8
  ,parameter IB           = 15        // IQ input data width
  ,parameter OB           = 15        // IQ output data width
  )
  (
   input                  i_rst
  ,input                  i_clk

  ,input  [OVS*9-1:0]     i_gain2_tout
  ,input  [OVS*4-1:0]     i_gain1     
  ,input  [OVS*5-1:0]     i_gain2
  ,input  [OVS*5-1:0]     i_tdagc_gain

  ,input  [OVS-1:0]       i_tdagc_vld
  ,input  [IB-1:0]        i_tdagc_i  
  ,input  [IB-1:0]        i_tdagc_q  

  ,output [OVS-1:0]       o_tdagc_vld
  ,output [OB-1:0]        o_tdagc_i
  ,output [OB-1:0]        o_tdagc_q
  ,output [3   :0]        o_tdgain1  
  ,output [4   :0]        o_tdgain2   
  ,output [4   :0]        o_tdagc_gain
);

genvar i;
genvar j;

localparam AGC_CMUL_OB        = (TYPE==0)? 24:25                    ; // TOUT multiplier output data width
localparam AGC_CAL_DLY_N      = 16                                  ; // delay line number
localparam AGC_SAT_PRE_OFFSET = 2                                   ; // shift bit operation pre_processing clock numbers

  reg  [OVS*9-1:0]         r_gain2_tout                             ;
  reg  [OVS*4-1:0]         r_gain1                                  ;
  reg  [OVS*5-1:0]         r_gain2                                  ;
  reg  [OVS*5-1:0]         r_tdagc_gain                             ;
  reg  [OVS-1:0]           r_tdagc_vld                              ;
  reg  [IB-1:0]            r_tdagc_i                                ;
  reg  [IB-1:0]            r_tdagc_q                                ; 
  reg  [AGC_CAL_DLY_N-1:0] r_agc_vld_m_shr                          ;
  reg  [OVS-1:0]           r_agc_vld_shr   [AGC_CAL_DLY_N-1:0]      ;
  reg  [8:0]               r_agc_tout_mux  [OVS-1:0]                ;
  wire [OVS-1:0]           w_agc_tout_mux  [8:0]                    ; 
  reg  [9-1:0]             r_agc_tout_mul                           ;
  wire [IB-1:0]            w_ex_agc_tout_mul                        ;
  wire                     w_i_vld                                  ;
  wire [IB+IB-1:0]         w_i_z                                    ;
  wire                     w_q_vld                                  ;
  wire [IB+IB-1:0]         w_q_z                                    ;  
  reg  [IB-1:0]            r_dout_i_shr    [AGC_CAL_DLY_N-1:0]      ;
  reg  [IB-1:0]            r_dout_q_shr    [AGC_CAL_DLY_N-1:0]      ;
  wire                     w_agc_tout_mul_i_vld                     ;
  wire [AGC_CMUL_OB-1:0]   w_agc_tout_mul_i_data                    ;
  wire                     w_agc_tout_mul_q_vld                     ;
  wire [AGC_CMUL_OB-1:0]   w_agc_tout_mul_q_data                    ;  
  reg  [3:0]               r_agc_gain1_mux [OVS-1:0]                ;
  reg  [4:0]               r_agc_gain2_mux [OVS-1:0]                ;
  reg  [4:0]               r_tdagc_gain_mux [OVS-1:0]               ;
  wire [OVS-1:0]           w_agc_gain1_mux [3:0]                    ; 
  wire [OVS-1:0]           w_agc_gain2_mux [4:0]                    ;
  wire [OVS-1:0]           w_tdagc_gain_mux [4:0]                   ;  
  reg  [3:0]               r_agc_gain1_mul                          ;
  reg  [4:0]               r_agc_gain2_mul                          ; 
  reg  [4:0]               r_tdagc_gain_mul                         ; 
  reg  [3:0]               r_agc_gain1_mul_shr [AGC_CAL_DLY_N-1:0]  ;
  reg  [4:0]               r_agc_gain2_mul_shr [AGC_CAL_DLY_N-1:0]  ; 
  reg  [4:0]               r_tdagc_gain_mul_shr[AGC_CAL_DLY_N-1:0]  ;  
  reg  [3:0]               r_agc_gain1_mux1                         ;

  wire                     w_sat_dout_vld                           ;
  wire signed [OB-1:0]     w_sat_dout_i                             ;
  wire signed [OB-1:0]     w_sat_dout_q                             ;

  wire                     w_o_sat_dout_vld                         ;
  wire signed [OB-1:0]     w_o_sat_dout_i                           ;
  wire signed [OB-1:0]     w_o_sat_dout_q                           ;


// initial

//generate
//integer ram_idx;
//initial
//begin
//for (ram_idx = 0; ram_idx < AGC_CAL_DLY_N; ram_idx = ram_idx + 1)begin
//  r_agc_vld_shr[ram_idx] = {OVS{1'b0}};
//  r_agc_gain1_mul_shr[ram_idx] = 'd0;
//  r_agc_gain2_mul_shr[ram_idx] = 'd0;
//  r_tdagc_gain_mul_shr[ram_idx] = 'd0;
//  r_dout_i_shr[ram_idx] = 'd0;
//  r_dout_q_shr[ram_idx] = 'd0;
//
//end
//end  
//endgenerate



always @(posedge i_clk)begin
  r_gain2_tout<= i_gain2_tout;
  r_gain1     <= i_gain1     ;
  r_gain2     <= i_gain2     ;
  r_tdagc_gain<= i_tdagc_gain;
  r_tdagc_vld <= i_tdagc_vld ;
  r_tdagc_i   <= i_tdagc_i   ;
  r_tdagc_q   <= i_tdagc_q   ;
end


always @ (posedge i_clk)begin
  r_agc_vld_m_shr <= {r_agc_vld_m_shr[AGC_CAL_DLY_N-2:0],|(r_tdagc_vld)};
end

always @(posedge i_clk)begin
  r_agc_vld_shr[0] <= r_tdagc_vld;
end

generate
for(i = 1; i < AGC_CAL_DLY_N; i = i + 1)begin
  always @ (posedge i_clk)begin
    r_agc_vld_shr[i] <= r_agc_vld_shr[i-1];
  end
end
endgenerate

generate
for (i = 0; i < OVS; i = i + 1)begin
always @ (posedge i_clk)begin
  if (r_tdagc_vld[i] == 1'b1) begin
    r_agc_tout_mux[i] <= r_gain2_tout[i*9+8:i*9];
  end else begin
    r_agc_tout_mux[i] <= 'd0; 
  end
end   
end
endgenerate

for (i = 0; i < 9  ; i = i + 1)begin
for (j = 0; j < OVS; j = j + 1)begin
assign w_agc_tout_mux[i][j] = r_agc_tout_mux[j][i]; 
end
end

generate
for(i = 0; i < 9; i = i +1)begin
  always @ (posedge i_clk)begin
    r_agc_tout_mul[i] <= |(w_agc_tout_mux[i]);
  end
end
endgenerate

always @(*)begin
  r_dout_i_shr[0] <= r_tdagc_i;
  r_dout_q_shr[0] <= r_tdagc_q;
end

generate
for (i = 1; i < AGC_CAL_DLY_N; i = i +1)begin
  always @(posedge i_clk)begin
    r_dout_i_shr[i] <= r_dout_i_shr[i-1];
    r_dout_q_shr[i] <= r_dout_q_shr[i-1];
  end
end
endgenerate           

assign w_ex_agc_tout_mul = {{(IB-10){1'b0}},r_agc_tout_mul};


ylib_fxp_smult #( 
    .XB         (IB                         )
  , .YB         (IB                         )
  , .NP         (4                          )
)
inst_agc_tout_mul_i
(
    .i_clk      (i_clk                      )
  , .i_rst      (i_rst                      )
  
  , .i_vld      (r_agc_vld_m_shr[1]         )
  , .i_x        (r_dout_i_shr[2]            )
  , .i_y        (w_ex_agc_tout_mul          )

  , .o_vld      (w_i_vld                    )
  , .o_z        (w_i_z                      )
);


ylib_fxp_smult #( 
    .XB         (IB                         )
  , .YB         (IB                         )
  , .NP         (4                          )
)
inst_agc_tout_mul_q
(
    .i_clk      (i_clk                      )
  , .i_rst      (i_rst                      )
  
  , .i_vld      (r_agc_vld_m_shr[1]         )
  , .i_x        (r_dout_q_shr[2]            )
  , .i_y        (w_ex_agc_tout_mul          )

  , .o_vld      (w_q_vld                    )
  , .o_z        (w_q_z                      )
);

assign w_agc_tout_mul_i_vld = w_i_vld;
assign w_agc_tout_mul_q_vld = w_q_vld;
assign w_agc_tout_mul_i_data = w_i_z[AGC_CMUL_OB-1:0];
assign w_agc_tout_mul_q_data = w_q_z[AGC_CMUL_OB-1:0];

generate
for (i = 0; i < OVS; i = i + 1)begin
always @ (posedge i_clk)begin
  if (r_agc_vld_shr[AGC_SAT_PRE_OFFSET][i] == 1'b1 ) begin
    r_agc_gain1_mux[i] <= r_gain1[i*4+3:i*4];
    r_agc_gain2_mux[i] <= r_gain2[i*5+4:i*5];
    r_tdagc_gain_mux[i]<= r_tdagc_gain[i*5+4:i*5];
  end else begin
    r_agc_gain1_mux[i] <= 'd0; 
    r_agc_gain2_mux[i] <= 'd0;
    r_tdagc_gain_mux[i]<= 'd0;
  end     
  end     
end
endgenerate

for (i = 0; i < 4  ; i = i + 1)begin
for (j = 0; j < OVS; j = j + 1)begin
assign w_agc_gain1_mux[i][j] = r_agc_gain1_mux[j][i];
end
end

for (i = 0; i < 5  ; i = i + 1)begin
for (j = 0; j < OVS; j = j + 1)begin
assign w_agc_gain2_mux[i][j] = r_agc_gain2_mux[j][i];
assign w_tdagc_gain_mux[i][j] = r_tdagc_gain_mux[j][i]; 
end
end

generate
  for(i = 0; i < 4; i = i +1)begin
  always @ (posedge i_clk)begin
    r_agc_gain1_mul[i] <= |(w_agc_gain1_mux[i]);
  end
  end
endgenerate

generate
  for(i = 0; i < 5; i = i +1)begin
  always @ (posedge i_clk)begin
    r_agc_gain2_mul[i] <= |(w_agc_gain2_mux[i]);
    r_tdagc_gain_mul[i] <= |(w_tdagc_gain_mux[i]);
  end
  end
endgenerate

always @(posedge i_clk)begin
  r_agc_gain1_mul_shr[0] <= r_agc_gain1_mul;
  r_agc_gain2_mul_shr[0] <= r_agc_gain2_mul;
  r_tdagc_gain_mul_shr[0]<= r_tdagc_gain_mul;
end
 
generate
for (i = 1; i < AGC_CAL_DLY_N; i = i +1)begin
  always @(posedge i_clk)begin
    r_agc_gain1_mul_shr[i] <= r_agc_gain1_mul_shr[i-1];
    r_agc_gain2_mul_shr[i] <= r_agc_gain2_mul_shr[i-1];
    r_tdagc_gain_mul_shr[i]<= r_tdagc_gain_mul_shr[i-1];
  end
end
endgenerate 

always @(posedge i_clk)begin
  r_agc_gain1_mux1 <= 4'b1000 - r_agc_gain1_mul;
end


ylib_cshftvd_sat #
(.IB(AGC_CMUL_OB),.SB(4),.OB(OB),.ROUND_TYPE("SYMMETRIC_ROUND"),.SAT_TYPE("SYMMETRIC"))
inst_cshftvd_sat_fpga // 4 delay
(
    .i_clk            (i_clk                 )
  
  , .i_shft           (r_agc_gain1_mux1      )
  , .i_din_vld        (r_agc_vld_m_shr[5]    )
  , .i_din_i          (w_agc_tout_mul_i_data )
  , .i_din_q          (w_agc_tout_mul_q_data )

  , .o_dout_vld       (w_sat_dout_vld        )
  , .o_dout_i         (w_sat_dout_i          )
  , .o_dout_q         (w_sat_dout_q          )
);

ylib_reg #( .WIDTH(1   ), .DEPTH(1 ) ) reg_sfr_dout_vld_dly  ( .i_clk(i_clk), .i_in(w_sat_dout_vld), .o_out(w_o_sat_dout_vld) ); 
ylib_reg #( .WIDTH(OB  ), .DEPTH(1 ) ) reg_sfr_dout_i_dly    ( .i_clk(i_clk), .i_in(w_sat_dout_i  ), .o_out(w_o_sat_dout_i  ) );
ylib_reg #( .WIDTH(OB  ), .DEPTH(1 ) ) reg_sfr_dout_q_dly    ( .i_clk(i_clk), .i_in(w_sat_dout_q  ), .o_out(w_o_sat_dout_q  ) );


for(i = 0 ; i < OVS; i = i + 1)begin
assign  o_tdagc_vld[i] = r_agc_vld_shr[10][i];  
end

assign  o_tdagc_i   = w_o_sat_dout_i;
assign  o_tdagc_q   = w_o_sat_dout_q;

assign  o_tdgain1   = r_agc_gain1_mul_shr[5];
assign  o_tdgain2   = r_agc_gain2_mul_shr[5];
assign  o_tdagc_gain= r_tdagc_gain_mul_shr[5];

endmodule
