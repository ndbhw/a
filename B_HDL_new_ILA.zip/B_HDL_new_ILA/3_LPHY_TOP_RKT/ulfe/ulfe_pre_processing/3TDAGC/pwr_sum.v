// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : pwr_sum
//  Author       : 
//  Description  : Power Calculation and accumulation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------

module pwr_sum  #
  (
    parameter IB     = 16                               ,
    parameter CMB    = 32                               ,
    parameter SUMB   = 40                            
  )
  (
  input                  i_clk                          ,
  input                  i_rst                          ,

  input                  i_symbol_tick                  ,
  input                  i_sum_clr                      ,
  input                  i_en                           ,
  input                  i_din_vld                      ,
  input  [IB-1:0]        i_din_i                        ,
  input  [IB-1:0]        i_din_q                        ,

  output                 o_dout_vld                     ,
  output [SUMB-1:0]      o_dout
  );


  reg                     r_symbol_tick                   ;
  reg                     r_i_sum_clr                     ;
  reg                     r_i_en                          ;
  reg                     r_i_din_vld                     ;
  reg  [IB-1:0]           r_i_din_i                       ;
  reg  [IB-1:0]           r_i_din_q                       ;

  reg                     w_din_vld                       ;
  reg  signed [IB-1:0]    w_din_i                         ;
  reg  signed [IB-1:0]    w_din_q                         ;

  reg                     r_sum_clr                       ;
  reg                     r_en                            ;
  reg                     r_din_vld                       ;
  reg  signed [IB-1:0]    r_din_i                         ;
  reg  signed [IB-1:0]    r_din_q                         ;


  reg  [15:0]             r_sum_clr_shr                   ;
  reg  [15:0]             r_en_sfr                        ;

  wire                    w_i_vld                         ;
  wire  [IB+IB-1:0]       w_i_z                           ;

  wire                    w_q_vld                         ;
  wire  [IB+IB-1:0]       w_q_z                           ;

  wire                    w_abs_i_vld                     ;
  wire [CMB-1:0]          w_abs_i                         ;
  wire                    w_abs_q_vld                     ;
  wire [CMB-1:0]          w_abs_q                         ;
  reg  [CMB-1:0]          r_abs_i_d00                     ;  
  reg  [CMB-1:0]          r_abs_q_d00                     ; 
  reg                     r_abs_vld_d00                   ;
  reg                     r_abs_vld_d01                   ; 
(* use_dsp = "yes" *)reg [SUMB-1:0] r_abs_sum             ; 

  reg  [SUMB-1:0]         r_abs_sum_d02                   ; 
  reg                     r_abs_vld_d02                   ; 

  reg  [SUMB-1:0]         r_abs_sum_d03                   ; 
  reg                     r_abs_vld_d03                   ;
  reg  [SUMB-1:0]         r_abs_sum_d04                   ; 
  reg                     r_abs_vld_d04                   ;

(* use_dsp = "yes" *)  reg [SUMB-1:0] r_abs_acc           ;
  reg  [SUMB-1:0]         r_abs_acc_o                     ;
  reg                     r_vld_o                         ;


always @ (posedge i_clk)begin
  r_symbol_tick<= i_symbol_tick;
  r_i_sum_clr  <= i_sum_clr;
  r_i_en       <= i_en     ;
  r_i_din_vld  <= i_din_vld;  
  r_i_din_i    <= i_din_i  ;  
  r_i_din_q    <= i_din_q  ;  
end

always @ (*)begin
  if (r_i_en)begin
    w_din_vld  <= r_i_din_vld;
    w_din_i    <= r_i_din_i  ;
    w_din_q    <= r_i_din_q  ;    
  end else begin
    w_din_vld  <= 1'b0;
    w_din_i    <= {(IB){1'b0}};
    w_din_q    <= {(IB){1'b0}};    
  end
end

always @ (posedge i_clk)begin
    r_sum_clr  <= r_i_sum_clr;
    r_en       <= r_i_en;
    r_din_vld  <= w_din_vld;
    r_din_i    <= w_din_i;
    r_din_q    <= w_din_q;    
end

always @ (posedge i_clk)begin
  r_sum_clr_shr <= {r_sum_clr_shr[14:0],r_sum_clr};
  r_en_sfr <= {r_en_sfr[14:0],r_en};
end



ylib_fxp_smult #( 
      .XB         (IB          )
    , .YB         (IB          )
    , .NP         (4           )
)
inst_pwr_abs_i
(
      .i_clk      (i_clk       )
    , .i_rst      (i_rst       )
    
    , .i_vld      (r_din_vld   )
    , .i_x        (r_din_i     )
    , .i_y        (r_din_i     )

    , .o_vld      (w_i_vld     )
    , .o_z        (w_i_z       )
);

ylib_fxp_smult #( 
      .XB         (IB          )
    , .YB         (IB          )
    , .NP         (4           )
)
inst_pwr_abs_q
(
      .i_clk      (i_clk       )
    , .i_rst      (i_rst       )
    
    , .i_vld      (r_din_vld   )
    , .i_x        (r_din_q     )
    , .i_y        (r_din_q     )

    , .o_vld      (w_q_vld     )
    , .o_z        (w_q_z       )
);


assign w_abs_i_vld = w_i_vld;
assign w_abs_q_vld = w_q_vld;
assign w_abs_i = w_i_z[CMB-1:0];
assign w_abs_q = w_q_z[CMB-1:0];
 
always @ (posedge i_clk)begin
  r_abs_i_d00     <= w_abs_i;
  r_abs_q_d00     <= w_abs_q;
  r_abs_vld_d00   <= w_abs_q_vld;
end


always @ (posedge i_clk)begin
  r_abs_vld_d01 <= r_abs_vld_d00;
end

 
always @ (posedge i_clk)begin
  r_abs_sum <= r_abs_i_d00 + r_abs_q_d00;
end
  

always @ (posedge i_clk)begin
  r_abs_sum_d02     <= r_abs_sum;
  r_abs_vld_d02     <= r_abs_vld_d01;
end


always @ (posedge i_clk)begin
  r_abs_sum_d03 <= r_abs_sum_d02;
  r_abs_sum_d04 <= r_abs_sum_d03;
  r_abs_vld_d03 <= r_abs_vld_d02;
  r_abs_vld_d04 <= r_abs_vld_d03;
end


always @ (posedge i_clk)begin
  if (r_symbol_tick)begin
    r_abs_acc <= {(SUMB){1'b0}};
  end else if (r_sum_clr_shr[8])begin
    r_abs_acc <= {(SUMB){1'b0}};
  end else if (r_abs_vld_d04)begin
    r_abs_acc <= r_abs_acc + r_abs_sum_d04;
  end
end


always @ (posedge i_clk)begin
  r_abs_acc_o <= r_abs_acc;
end


always @ (posedge i_clk)begin
  if (r_symbol_tick)begin
    r_vld_o <= 1'b0;
  end else if (r_sum_clr_shr[9])begin
    r_vld_o <= 1'b0;
  end else if (r_en_sfr[9:8] == 2'b10 )begin
    r_vld_o <= 1'b1;
  end  
end

assign o_dout_vld = r_vld_o;
assign o_dout = r_abs_acc_o;

endmodule
