// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : cnt_ld_zeros_32
//  Author       : Song, Moon-Gun
//  Description  : Count Leading Zeros Calculation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.21 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong | select SBBOB bits below nth 1bit
//  ------------+---------------+-----------------------------------------------

module cnt_ld_zeros_32  #
  (
    parameter IB     = 32                               ,//input data width
    parameter NU     = 4                                ,//= ceil(IB/8)
    parameter CLZOB  = 5                                ,//Count leading 0 output width
    parameter SBBOB  = 4                                 //Select SBBOB bits output width below nth bit = 1
  )
  (
  input                  i_clk                          ,
  input                  i_rst                          ,

  input                  i_symbol_tick                  ,
  input                  i_din_vld                      ,
  input  [IB-1:0]        i_din                          ,

  output                 o_dout_vld                     ,
  output [CLZOB-1:0]     o_cnt_ld_z                     ,
  output [SBBOB-1:0]     o_sel_bel_bits                 
);




genvar i;
localparam UB = 8;
localparam W_DIN = NU * UB + SBBOB;
localparam LEN_VLD_SHR = NU*2+1;

reg  [NU-1:0]          r_symbol_tick                 ;
wire [UB*NU-1:0]       w_din                         ;
wire [W_DIN-1:0]       w_din_ex                      ;
reg  [LEN_VLD_SHR-1:0] r_din_vld_shr                 ;
reg  [W_DIN-1:0]       r_din_shr             [NU*2+1:0];//-1:0];
reg  [NU-1:0]          r_cnt_ld_zeros_str            ;
reg  [CLZOB-1 :0]      r_cnt_ld_zeros        [NU-1:0];
reg  [SBBOB-1 :0]      r_sel_bits_blw_1bit   [NU-1:0];

reg [NU-1:0]           r_cnt_ld_zeros_str_o          ; 
reg [CLZOB-1 :0]       r_cnt_ld_zeros_o      [NU-1:0];
reg [SBBOB-1 :0]       r_sel_bits_blw_1bit_o [NU-1:0];
reg [CLZOB-1 :0]       r_cnt_ld_zeros_o_lck          ;
reg [SBBOB-1 :0]       r_sel_bits_blw_1bit_o_lck     ;

generate
for(i = 0 ; i < NU; i = i + 1)begin

always @ (posedge i_clk)begin
  r_symbol_tick[i] <= i_symbol_tick;
end

end
endgenerate

generate
if (UB*NU==IB) begin assign w_din = i_din;                       end
else           begin assign w_din = {i_din, {(UB*NU-IB){1'b1}}}; end
endgenerate


assign w_din_ex = {w_din,{(SBBOB){1'b1}}};


always@(posedge i_clk)begin
  r_din_vld_shr <= {r_din_vld_shr[LEN_VLD_SHR-2:0],i_din_vld};
end


always@(posedge i_clk)begin
  if (i_din_vld)begin
    r_din_shr[0] <= w_din_ex; 
  end 
end

generate
  for (i = 1; i < LEN_VLD_SHR; i = i + 1)begin
    always@(posedge i_clk)begin
      r_din_shr[i] <= r_din_shr[i-1];
    end 
  end
endgenerate

generate
  for (i = 0; i < NU; i = i + 1)
    always@(posedge i_clk)begin
      //if (r_symbol_tick[i])begin
      //      r_cnt_ld_zeros_str[i]   <= 'd0; 
      //      r_cnt_ld_zeros[i]       <= 'd0; 
      //      r_sel_bits_blw_1bit[i]  <= 'd0;        
      //end else begin
        casex (r_din_shr[i][i*8+7+SBBOB:i*8+SBBOB])
          8'b1xxxxxxx :begin 
            r_cnt_ld_zeros_str[i]   <= 1'b1; 
            r_cnt_ld_zeros[i]       <= (NU-1-i)*8   ; 
            r_sel_bits_blw_1bit[i]  <= r_din_shr[i][i*8+7+SBBOB-1:i*8+SBBOB+4-1];
            end
          8'b01xxxxxx :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+1 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-2:i*8+SBBOB+4-2];end
          8'b001xxxxx :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+2 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-3:i*8+SBBOB+4-3];end
          8'b0001xxxx :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+3 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-4:i*8+SBBOB+4-4];end
          8'b00001xxx :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+4 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-5:i*8+SBBOB+4-5];end
          8'b000001xx :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+5 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-6:i*8+SBBOB+4-6];end 
          8'b0000001x :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+6 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-7:i*8+SBBOB+4-7];end 
          8'b00000001 :begin 
            r_cnt_ld_zeros_str[i] <= 1'b1; 
            r_cnt_ld_zeros[i] <= (NU-1-i)*8+7 ; 
            r_sel_bits_blw_1bit[i] <= r_din_shr[i][i*8+7+SBBOB-8:i*8+SBBOB+4-8];end
          8'b00000000 :begin 
            if (i==0)begin
              r_cnt_ld_zeros_str[i] <= 1'b1;
              r_cnt_ld_zeros[i] <= (NU-1-i)*8+8;
              r_sel_bits_blw_1bit[i] <= {SBBOB{1'b0}};
            end else begin
              r_cnt_ld_zeros_str[i] <= 1'b0; 
              r_cnt_ld_zeros[i] <= {CLZOB{1'b0}}    ; 
              r_sel_bits_blw_1bit[i] <= {SBBOB{1'b0}};           
            end  
              end
          default     :begin 
            r_cnt_ld_zeros_str[i] <= 1'b0; 
            r_cnt_ld_zeros[i] <= {CLZOB{1'b0}}    ; 
            r_sel_bits_blw_1bit[i] <= {SBBOB{1'b0}};end
        endcase 
      //end 
    end     
endgenerate

always@(posedge i_clk)begin
  //if (r_symbol_tick[0])begin
  //  r_cnt_ld_zeros_str_o[0]  <= 'd0;
  //  r_cnt_ld_zeros_o[0]      <= 'd0;
  //  r_sel_bits_blw_1bit_o[0] <= 'd0;
  //end else begin
    r_cnt_ld_zeros_str_o[0]  <= r_cnt_ld_zeros_str[0];
    r_cnt_ld_zeros_o[0]      <= r_cnt_ld_zeros[0];
    r_sel_bits_blw_1bit_o[0] <= r_sel_bits_blw_1bit[0];  
  //end      
end

generate
  for (i = 1; i < NU; i = i + 1)begin
    always@(posedge i_clk)begin
      //if (r_symbol_tick[i])begin
      //  r_cnt_ld_zeros_str_o[i]  <= 1'b0;
      //  r_cnt_ld_zeros_o[i]      <= {CLZOB{1'b0}};
      //  r_sel_bits_blw_1bit_o[i] <= {SBBOB{1'b0}}; 
      //end  else 
      if (r_cnt_ld_zeros_str[i])begin
        r_cnt_ld_zeros_str_o[i]  <= r_cnt_ld_zeros_str[i];
        r_cnt_ld_zeros_o[i]      <= r_cnt_ld_zeros[i];
        r_sel_bits_blw_1bit_o[i] <= r_sel_bits_blw_1bit[i];
      end else if (r_cnt_ld_zeros_str_o[i-1])begin
        r_cnt_ld_zeros_str_o[i]  <= r_cnt_ld_zeros_str_o[i-1];
        r_cnt_ld_zeros_o[i]      <= r_cnt_ld_zeros_o[i-1];
        r_sel_bits_blw_1bit_o[i] <= r_sel_bits_blw_1bit_o[i-1];        
      end else begin
        r_cnt_ld_zeros_str_o[i]  <= 1'b0;
        r_cnt_ld_zeros_o[i]      <= {CLZOB{1'b0}};
        r_sel_bits_blw_1bit_o[i] <= {SBBOB{1'b0}};              
      end
    end
  end 
endgenerate


//output
always @ (posedge i_clk)begin
  if (r_din_vld_shr[LEN_VLD_SHR-2])begin
    r_cnt_ld_zeros_o_lck       <= r_cnt_ld_zeros_o[NU-1]     ;
    r_sel_bits_blw_1bit_o_lck  <= r_sel_bits_blw_1bit_o[NU-1];  
  end
end


assign o_dout_vld     = r_din_vld_shr[LEN_VLD_SHR-1];
assign o_cnt_ld_z     = r_cnt_ld_zeros_o_lck       ;
assign o_sel_bel_bits = r_sel_bits_blw_1bit_o_lck  ;
  


endmodule
