// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : mult_signed
//  Author       : Han Xiangdong
//  Description  : signed mult
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


(* use_dsp = "yes" *)module mult_signed  #(
    parameter IB       = 16             ,
    parameter OB       = 32             
  )(
    input 			    clk				,
    input               i_vld           ,
    input	[IB-1:0]	i_a          	,
    input	[IB-1:0]	i_b  	       	,
    output              o_vld           ,
    output	[OB-1:0]	o_c         		 
    );

reg signed [IB-1:0]  r_d01_a   = {(IB){1'B0}};
reg signed [IB-1:0]  r_d02_a   = {(IB){1'B0}};
reg signed [IB-1:0]  r_d01_b   = {(IB){1'B0}};
reg signed [IB-1:0]  r_d02_b   = {(IB){1'B0}};
reg signed [OB-1:0]  r_d01_o   = {(OB){1'B0}};
reg signed [OB-1:0]  r_d02_o   = {(OB){1'B0}};
reg        [3:0]    r_vld_shr  = 4'd0        ;

always @ (posedge clk)begin
    r_d01_a <= i_a;
    r_d02_a <= r_d01_a;
    r_d01_b <= i_b;
    r_d02_b <= r_d01_b;
end

always @ (posedge clk)begin
    r_d01_o <= r_d02_a * r_d02_b;
    r_d02_o <= r_d01_o;
end


always @ (posedge clk)begin
    r_vld_shr <= {r_vld_shr[2:0],i_vld};
end

assign o_vld = r_vld_shr[3];

assign o_c = r_d02_o;

endmodule
