// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : tagc
//  Author       : Han Xiangdong
//  Description  : tdagc
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tagc_buf_top_aie  #
  (
   parameter TYPE         = 0         // 0: ULFE 1: RAFE
  ,parameter SCS          = 1         //
  ,parameter OC           = 1                            
  ,parameter OVS          = 2**OC     // 0:2 , 1:4 , 2:8
  ,parameter OVS_offset   = 0
  ,parameter IB           = 15        // IQ input data width
  ,parameter OB           = 15 
  ,parameter VENDOR       = "Xilinx"
  )
  (
   input                  i_rst
  ,input                  i_clk

  ,input                  i_wr_resync_frm_tick
//  ,input                  i_rd_resync_frm_tick
//  ,input  [3:0]           i_ffttype      

//  ,input                  i_bcf_enb      
  ,input                  i_frm_tick
//  ,input  [3:0]           i_ro_idx  
  ,input  [3:0]           i_sym_idx     //


  ,input  [OVS-1:0]       i_sym_end     // [0] sync with i_frm_tick
  ,input  [OVS-1:0]       i_sym_start   // effective sym 

  ,input  [OVS-1:0]       i_din_vld     //
  ,input  [IB-1:0]        i_din_i       //
  ,input  [IB-1:0]        i_din_q       //

                                        //
  ,input                  i_dout_rqt    //read sym tick periodic
  ,input                  i_gain_vld 

//  ,output                 o_bcf_enb   
  ,output                 o_frm_tick 
//  ,output [3:0]           o_ro_idx  
//  ,output [3:0]           o_sym_idx     // 
      
  ,output [OVS-1:0]       o_dout_vld
  ,output [OB-1:0]        o_dout_i_0M
  ,output [OB-1:0]        o_dout_q_0M
  ,output [OB-1:0]        o_dout_i_0L
  ,output [OB-1:0]        o_dout_q_0L
  ,output [OB-1:0]        o_dout_i_1M
  ,output [OB-1:0]        o_dout_q_1M
  ,output [OB-1:0]        o_dout_i_1L
  ,output [OB-1:0]        o_dout_q_1L

);
 
localparam      r_scs_type = 1; 
 
reg [12-1:0]    r_wfftin_cnt;
reg [4-1:0]     r_wdecoded_locbuf;
reg [4-1:0]     r_wea;
reg [10-1:0]    r_wdecoded_addr;
reg [12-1:0]    r_addra;
reg             r_wsym_odd;
reg             r_wlastrx_vld;
reg             r_eff_vld;
wire [15-1:0]      w_din_i;
wire [15-1:0]      w_din_q;
wire [16-1:0]      w_dout_i_0M;
wire [16-1:0]      w_dout_q_0M;
wire [16-1:0]      w_dout_i_0L;
wire [16-1:0]      w_dout_q_0L;
wire [16-1:0]      w_dout_i_1M;
wire [16-1:0]      w_dout_q_1M;
wire [16-1:0]      w_dout_i_1L;
wire [16-1:0]      w_dout_q_1L;

reg [16 -1:0]   r_shr_val ;
wire            w_dly_frm_tick;
wire            w_dly_sym_tick;
reg [10-1:0]    r_rgap_cnt;

reg [10-1:0]    r_rfft_cnt;
reg [2-1:0]     r_rx_num;
reg [2-1:0]     rr_rx_num;
reg             r_rsym_odd;
reg             r_en_sym_lat;
reg             f_en_sym;
reg             r_enb;
reg             rr_enb;
reg [12-1:0]    r_addrb;
reg [OVS-1:0]   r_dout_vld;

always @(posedge i_clk)
begin
    if(i_sym_start[0])
        r_wfftin_cnt <= 12'd0;
    else if(i_din_vld[OVS-1])
        r_wfftin_cnt <= r_wfftin_cnt + 12'd1;            
end
 
always @(posedge i_clk)
begin
    case(r_wfftin_cnt[2:1])
        2'b00 : r_wdecoded_locbuf <= 4'b0001;
        2'b01 : r_wdecoded_locbuf <= 4'b0100;
        2'b10 : r_wdecoded_locbuf <= 4'b0010;
        2'b11 : r_wdecoded_locbuf <= 4'b1000;
    endcase
    
    if(r_eff_vld)
        r_wea <= r_wdecoded_locbuf;
    else
        r_wea  <= 4'd0;
end 

always @(posedge i_clk)
begin
    if(!r_wfftin_cnt[0])
        r_wdecoded_addr <= 10'd512 + {1'b0,r_wfftin_cnt[11:3]};
    else
        r_wdecoded_addr <= 10'd0 + {1'b0,r_wfftin_cnt[11:3]};
end 

always @(posedge i_clk)
begin
//    if(i_frm_tick)
//        r_sym_odd   <= 1'b0;
//    else if(i_sym_start[0])
//        r_sym_odd   <= ~r_sym_odd;
    r_wsym_odd   <= i_sym_idx[0];
end

always @(posedge i_clk)
begin
    r_wlastrx_vld   <=  i_din_vld[OVS-1];   
    r_eff_vld       <=  |i_din_vld;
end

always @(posedge i_clk)
begin
    r_addra <= {r_wsym_odd,r_wlastrx_vld,r_wdecoded_addr};
end

ylib_reg #( .WIDTH(30), .DEPTH(2) ) reg_din_retiming ( .i_clk(i_clk), .i_in( {i_din_i,i_din_q}  ), .o_out( {w_din_i,w_din_q}  ) );


                   
                   
 
ylib_rams_sdp #(
.WIDTH(32),
.DEPTH(4096),
.VENDOR(VENDOR),
.RAM_STYLE("block")
) ylib_rams_sdp_stream0M (
.clk(i_clk),
.ena(1'b1),
.enb(rr_enb),
.wea(r_wea[0]),
.addra(r_addra),
.addrb(r_addrb),
.dia({w_din_i[15-1],w_din_i,w_din_q[15-1],w_din_q}),
.dob({w_dout_i_0M,w_dout_q_0M})
);
ylib_rams_sdp #(
.WIDTH(32),
.DEPTH(4096),
.VENDOR(VENDOR),
.RAM_STYLE("block")
) ylib_rams_sdp_stream0L (
.clk(i_clk),
.ena(1'b1),
.enb(rr_enb),
.wea(r_wea[1]),
.addra(r_addra),
.addrb(r_addrb),
.dia({w_din_i[15-1],w_din_i,w_din_q[15-1],w_din_q}),
.dob({w_dout_i_0L,w_dout_q_0L})
);
ylib_rams_sdp #(
.WIDTH(32),
.DEPTH(4096),
.VENDOR(VENDOR),
.RAM_STYLE("block")
) ylib_rams_sdp_stream1M (
.clk(i_clk),
.ena(1'b1),
.enb(rr_enb),
.wea(r_wea[2]),
.addra(r_addra),
.addrb(r_addrb),
.dia({w_din_i[15-1],w_din_i,w_din_q[15-1],w_din_q}),
.dob({w_dout_i_1M,w_dout_q_1M})
);
ylib_rams_sdp #(
.WIDTH(32),
.DEPTH(4096),
.VENDOR(VENDOR),
.RAM_STYLE("block")
) ylib_rams_sdp_stream1L (
.clk(i_clk),
.ena(1'b1),
.enb(rr_enb),
.wea(r_wea[3]),
.addra(r_addra),
.addrb(r_addrb),
.dia({w_din_i[15-1],w_din_i,w_din_q[15-1],w_din_q}),
.dob({w_dout_i_1L,w_dout_q_1L})
);
 
 
 

 
 
 
 
 
// sync shift



always@(posedge i_clk) begin
        case(r_scs_type)
            0   :   begin
                        r_shr_val   <= (16'd17664-16'd700);//(18'd17664-18'd1250);//18'd17536 ;// - 18'd1100;
                        r_rgap_cnt  <= 10'd300;
                    end
            1   :   begin
                        r_shr_val   <= (16'd17664-16'd700)/2;//(18'd17664-18'd1200)/2;//18'd8768  ;
                        r_rgap_cnt  <= 10'd512;
                    end
            default :   begin
                            r_shr_val   <= 16'd17536;
                            r_rgap_cnt  <= 10'd250;
                        end
        endcase
end
 
ylib_pshift #(
    .BW_SHIFT(16)
) ylib_pshift_instance (
    .i_clk(i_clk),
    .i_shift(r_shr_val),
    .i_in(i_frm_tick),
    .o_out(w_dly_frm_tick)
);
//ylib_pshift #(
//    .BW_SHIFT(16)
//) ylib_pshift_instance (
//    .i_clk(i_clk),
//    .i_shift(r_shr_val),
//    .i_in(i_sym_start[0]),
//    .o_out(w_dly_sym_tick)
//); 
 



always @(posedge i_clk)
begin
    if(i_sym_start[0])
        r_en_sym_lat <= 1'b1;
    else if(i_dout_rqt)
        r_en_sym_lat <= 1'b0;
    else
        r_en_sym_lat <= r_en_sym_lat;    
end

always @(posedge i_clk)
begin
    if(i_dout_rqt)
    begin
        if(r_en_sym_lat)
            f_en_sym <= 1'b1;
        else 
            f_en_sym <= 1'b0;
    end
    else// if(i_din_vld[1])
        f_en_sym <= f_en_sym ;            
end

always @(posedge i_clk)
begin
    if(i_dout_rqt&r_en_sym_lat)
    begin
        r_rfft_cnt      <= 10'd0;
        r_rx_num          <= 2'b01;    
        r_enb           <= 1'b1;
    end
    else if(r_rx_num[0]==1'b1 && r_enb==1'b1 && r_rfft_cnt==10'd1023 )
    begin
        r_rfft_cnt      <= 10'd0;
        r_rx_num          <= 2'b01;    
        r_enb           <= 1'b0;
    end
    else if(r_rx_num[0]==1'b1 && r_enb==1'b0 && r_rfft_cnt==r_rgap_cnt )
    begin
        r_rfft_cnt      <= 10'd0;
        r_rx_num          <= 2'b10;    
        r_enb           <= 1'b1;
    end
    else if(r_rx_num[1]==1'b1 && r_enb==1'b1 && r_rfft_cnt==10'd1023 )
    begin
        r_rfft_cnt      <= 10'd0;
        r_rx_num          <= 2'b10;    
        r_enb           <= 1'b0;
    end
    else 
    begin
        r_rfft_cnt      <= r_rfft_cnt + 10'd1;
        r_rx_num          <= r_rx_num;    
        r_enb           <= r_enb;
    end

end



always @(posedge i_clk)
begin
    if(w_dly_frm_tick)
        r_rsym_odd   <= 1'b1;
    else if(i_dout_rqt)
        r_rsym_odd   <= ~r_rsym_odd;
end



always @(posedge i_clk)
begin
    rr_enb      <= r_enb;
    r_addrb <= {r_rsym_odd,r_rx_num[1],r_rfft_cnt};
end


always @(posedge i_clk)
begin   
    if(rr_enb)
        r_dout_vld <= r_rx_num;
    else 
        r_dout_vld <= 2'b00;
end
 
 
assign o_dout_vld   = r_dout_vld   ;
assign o_dout_i_0M  = w_dout_i_0M[15-1:0]  ;
assign o_dout_q_0M  = w_dout_q_0M[15-1:0]  ;
assign o_dout_i_0L  = w_dout_i_0L[15-1:0]  ;
assign o_dout_q_0L  = w_dout_q_0L[15-1:0]  ;
assign o_dout_i_1M  = w_dout_i_1M[15-1:0]  ;
assign o_dout_q_1M  = w_dout_q_1M[15-1:0]  ;
assign o_dout_i_1L  = w_dout_i_1L[15-1:0]  ;
assign o_dout_q_1L  = w_dout_q_1L[15-1:0]  ;
assign o_frm_tick   = w_dly_frm_tick;
 
 
 
 
 
 
 
 
 
 
 
 
 
 

endmodule
