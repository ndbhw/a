// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : 
//  Module       : tdrssi_rpt
//  Author       : Han Xiangdong
//  Description  : tagc rssi report
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tdrssi_rpt  #
  (
   parameter TYPE         = 0                             // 0: ULFE   1: RAFE
  ,parameter OC           = 1                             // 1: hovs2  2: hovs4  3:hovs8                   
  ,parameter OVS          = 2**OC                         // 0: 2      1:4       2:8
  ,parameter IB           = 15                            // IQ input data width
  ,parameter OB           = 15                            // IQ output data width
  ,parameter TR           = 32                            // output RSSI data width   
  ,parameter N_CYCLE_CLK  =245760000                      
  ,parameter SCS_IDX      =1                              //{0~4} --> {15k, 30k, 60k, 120k, 240k}
  ,parameter CP_TYPE      =0                              //0:normal, 1:extended
  )
  (
   input                  i_rst                           //          
  ,input                  i_clk                           //          

  ,input  [0:0]           i_tdrssi_trigger                //
  ,input  [8-1:0]         i_tdrssi_start_slt_idx          //
  ,input  [4-1:0]         i_tdrssi_start_sym_idx          //
  ,input  [5-1:0]         i_tdrssi_syms_size              //

  ,input                  i_frm_tick                      // 
  ,input                  i_slt_tick                      // 
  ,input                  i_sym_tick                      // 

  ,input  [OVS-1:0]       i_tdagc_tdrssi_vld              // 
  ,input  [OVS*TR-1:0]    i_tdagc_tdrssi                  // 

  ,output                 o_tagc_tdrssi_wr_pre            // 
  ,output [OVS-1:0]       o_tdagc_tdrssi_vld              //   
  ,output [OVS*TR-1:0]    o_tdagc_tdrssi                  //
  ,output                 o_tdagc_tdrssi_rpt_done          
);

genvar i;
localparam RPT_CNTB       = 5                                   ;
localparam SHR_LEN        = 8                                   ;

  reg  [0:0]              r_tdrssi_trigger                      ;
  reg  [8-1:0]            r_tdrssi_start_slt_idx                ;
  reg  [4-1:0]            r_tdrssi_start_sym_idx                ;
  reg  [5-1:0]            r_tdrssi_syms_size                    ;
                                                              
  reg                     r_frm_tick                            ;
  reg                     r_slt_tick                            ;
  reg                     r_sym_tick                            ;
  reg  [OVS-1:0]          r_tdagc_tdrssi_vld                    ;
  reg  [OVS*TR-1:0]       r_tdagc_tdrssi                        ;
  reg  [OVS-1:0]          r_shr_tdagc_tdrssi_vld  [SHR_LEN-1:0] ;
  reg  [OVS*TR-1:0]       r_shr_tdagc_tdrssi      [SHR_LEN-1:0] ;
  reg  [SHR_LEN-1:0]      r_shr_sym_tick                        ;
  wire                    w_sym_tick                            ;
                                                                
  reg  [8-1:0]            r_slt_cnt                             ;
  reg  [4-1:0]            r_sym_cnt                             ;
                                                                
  reg  [SHR_LEN-1:0]      r_shr_trigger                         ;
                                                                
  reg                     r_trigger_start                       ;
  reg                     r_rpt_on                              ;
  reg                     r_rpt_rdy                             ;
  reg  [RPT_CNTB-1:0]     r_rpt_cnt                             ;
  reg                     r_rpt_done                            ;
                                                                
  reg  [31:0]             r_rpt_on_shr                          ;
                                                                
  reg  [OVS-1:0]          r_o_tdagc_tdrssi_vld                  ;
  reg  [OVS*TR-1:0]       r_o_tdagc_tdrssi                      ;
                                                                
  reg                     r_tagc_tdrssi_wr_pre                  ;


always @ (posedge i_clk)begin
  r_tdrssi_trigger        <= i_tdrssi_trigger      ;
  r_tdrssi_start_slt_idx  <= i_tdrssi_start_slt_idx;        
  r_tdrssi_start_sym_idx  <= i_tdrssi_start_sym_idx;        
  r_tdrssi_syms_size      <= i_tdrssi_syms_size    ;        
end

always @ (posedge i_clk)begin
  r_frm_tick              <= i_frm_tick            ;
  r_slt_tick              <= i_slt_tick            ;
  r_sym_tick              <= i_sym_tick            ;
  r_tdagc_tdrssi_vld      <= i_tdagc_tdrssi_vld    ;
  r_tdagc_tdrssi          <= i_tdagc_tdrssi        ;
end

always @ (posedge i_clk)begin
  r_shr_sym_tick <= {r_shr_sym_tick[SHR_LEN-2:0],r_sym_tick};
end

assign w_sym_tick = r_shr_sym_tick[4];

//generate
//integer ram_idx;
//initial
//begin
//for (ram_idx = 0; ram_idx < SHR_LEN; ram_idx = ram_idx + 1)begin
//  r_shr_tdagc_tdrssi_vld[ram_idx] = {OVS{1'b0}};
//  r_shr_tdagc_tdrssi[ram_idx] = 'd0;
//end
//end  
//endgenerate

always @(*)begin
  r_shr_tdagc_tdrssi_vld[0] <= r_tdagc_tdrssi_vld;
  r_shr_tdagc_tdrssi[0] <= r_tdagc_tdrssi;
end

generate
for(i = 1; i < SHR_LEN; i = i + 1)begin
always @ (posedge i_clk)begin
  r_shr_tdagc_tdrssi_vld[i] <=  r_shr_tdagc_tdrssi_vld[i-1]; 
  r_shr_tdagc_tdrssi[i]     <=  r_shr_tdagc_tdrssi[i-1]; 
end
end  
endgenerate

always @ (posedge i_clk)begin
  if (r_frm_tick)begin
    r_slt_cnt <= 'd0;
  end else if (r_slt_tick)begin
    r_slt_cnt <= r_slt_cnt + 1;
  end
end

always @ (posedge i_clk)begin
  if (r_slt_tick)begin
    r_sym_cnt <= 'd0;
  end else if (w_sym_tick)begin
    r_sym_cnt <= r_sym_cnt + 1;
  end
end

always @ (posedge i_clk)begin
  r_shr_trigger  <= {r_shr_trigger[SHR_LEN-2:0],r_tdrssi_trigger};
end

always @(posedge i_clk)begin
  if (r_shr_trigger[2:1] == 2'b01)begin
    r_trigger_start <= 1'b1;
  end else if (r_sym_tick)begin
    r_trigger_start <= 1'b0;
  end
end

always @ (posedge i_clk)begin
  if (i_rst)begin
    r_rpt_rdy <= 1'b0;
    r_rpt_done <= 1'b0;
  end else if (r_trigger_start== 1'b1 && r_sym_tick == 1'b1)begin
    r_rpt_rdy <= 1'b1;
    r_rpt_done <= 1'b0;
  end else if (r_rpt_cnt == r_tdrssi_syms_size )begin
    r_rpt_rdy <= 1'b0;
    r_rpt_done <= 1'b1;
  end
end

always @ (posedge i_clk)begin
  if (i_rst)begin
    r_rpt_on <= 1'b0;
  end else if (r_rpt_rdy == 1'b1 && r_slt_cnt == r_tdrssi_start_slt_idx && r_sym_cnt == r_tdrssi_start_sym_idx)begin
    r_rpt_on <= 1'b1;
  end else if (r_rpt_cnt == r_tdrssi_syms_size )begin
    r_rpt_on <= 1'b0;
  end
end

always @ (posedge i_clk)begin
  if (r_rpt_on)begin
    if (w_sym_tick)begin
      r_rpt_cnt <= r_rpt_cnt + 1'b1;
    end
  end else begin
    r_rpt_cnt <= 'd0;
  end
end

always @ (posedge i_clk)begin
  r_rpt_on_shr <= {r_rpt_on_shr[30:0],r_rpt_on};
end

always @ (posedge i_clk)begin
  if (r_rpt_on_shr[0])begin
    r_o_tdagc_tdrssi_vld <= r_shr_tdagc_tdrssi_vld[2];
    r_o_tdagc_tdrssi     <= r_shr_tdagc_tdrssi[2];
  end else begin
    r_o_tdagc_tdrssi_vld <= 'd0;
    r_o_tdagc_tdrssi     <= 'd0;
  end
end
         
assign o_tdagc_tdrssi_vld   = r_o_tdagc_tdrssi_vld;
assign o_tdagc_tdrssi       = r_o_tdagc_tdrssi    ;

assign o_tdagc_tdrssi_rpt_done = r_rpt_done;

always @ (posedge i_clk)begin
  if (r_trigger_start== 1'b1 && r_sym_tick == 1'b1)begin
    r_tagc_tdrssi_wr_pre <= 1'b1;
  end else begin
    r_tagc_tdrssi_wr_pre <= 1'b0;
  end
end



assign o_tagc_tdrssi_wr_pre = r_tagc_tdrssi_wr_pre;


endmodule
