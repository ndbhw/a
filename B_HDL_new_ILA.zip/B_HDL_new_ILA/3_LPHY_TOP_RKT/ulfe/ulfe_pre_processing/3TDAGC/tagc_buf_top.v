// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : tagc
//  Author       : Han Xiangdong
//  Description  : tdagc
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tagc_buf_top  #
  (
   parameter TYPE         = 0         // 0: ULFE 1: RAFE
  ,parameter SCS          = 1         //
  ,parameter OC           = 1                            
  ,parameter OVS          = 2**OC     // 0:2 , 1:4 , 2:8
  ,parameter OVS_offset   = 0
  ,parameter IB           = 15        // IQ input data width
  ,parameter OB           = 15 
  ,parameter VENDOR       = "Xilinx"
  )
  (
   input                  i_rst
  ,input                  i_clk

  ,input                  i_wr_resync_frm_tick
  ,input                  i_rd_resync_frm_tick
  ,input  [3:0]           i_ffttype      

  ,input                  i_bcf_enb      
  ,input                  i_frm_tick
  ,input  [3:0]           i_ro_idx  
  ,input  [3:0]           i_sym_idx     //


  ,input  [OVS-1:0]       i_sym_end     // 
  ,input  [OVS-1:0]       i_sym_start   //  

  ,input  [OVS-1:0]       i_din_vld     //
  ,input  [IB-1:0]        i_din_i       //
  ,input  [IB-1:0]        i_din_q       //

                                        //
  ,input                  i_dout_rqt
  ,input                  i_gain_vld 

  ,output                 o_bcf_enb   
  ,output                 o_frm_tick 
  ,output [3:0]           o_ro_idx  
  ,output [3:0]           o_sym_idx     // 
      
  ,output [OVS-1:0]       o_dout_vld
  ,output [OB-1:0]        o_dout_i
  ,output [OB-1:0]        o_dout_q

);
 
  localparam EB = (TYPE==0) ? 2 : 2                            ;
  localparam AW = (TYPE==0) ? (SCS==0)? 13:12 :13              ;
  localparam DW = 72                                           ;
  localparam NP = 5                                            ;//mem num pipe  
  
  localparam RAM_TYPE = "ultra"                                ;
  localparam NUM_COL = 9                                       ;
  localparam LCP0_SYM_N = 6                                    ;
  localparam LCP1_SYM_N = 13                                   ;
  localparam LCP0_NR_SYM_N = 6                                 ;
  localparam LCP1_NR_SYM_N = 13                                ;
  localparam OVS_DIV_EB = clogb2(OVS/EB)                       ;

  localparam W_MEM_H1 = AW                                     ;
  localparam W_MEM_H2 = AW-(clogb2(OVS/EB))+1                  ;
  localparam W_MEM_L1 = AW-(clogb2(OVS/EB))                    ;
  localparam W_MEM_L2 = 0                                      ;

  
  genvar i;
  genvar j;
  integer k;
  
  reg                             r_frm_tick                   ;
  reg  [3:0]                      r_ro_idx                     ;
  reg  [3:0]                      r_sym_idx                    ;
  reg  [OVS-1:0]                  r_sym_end                    ;
  reg  [OVS-1:0]                  r_sym_start                  ;
  reg  [OVS-1:0]                  r_din_vld                    ;
  reg  [IB-1:0]                   r_din_i                      ;
  reg  [IB-1:0]                   r_din_q                      ;
  reg  [IB-1:0]                   r_din_i_dly0                 ;
  reg  [IB-1:0]                   r_din_q_dly0                 ;
  reg  [IB-1:0]                   r_din_i_dly1                 ;
  reg  [IB-1:0]                   r_din_q_dly1                 ;
  reg                             r_bcf_enb                    ; 
  reg  [7:0]                      r_rd_resync_frm_tick         ;  
  reg  [7:0]                      r_wr_resync_frm_tick         ;   
  reg  [3:0]                      r_ffttype                    ;
  reg  [15:0]                     r_dout_rqt                   ;
  reg  [5:0]                      r_ant_cnt                    ;
  reg  [11:0]                     r_ts_cnt                     ;
  reg                             r_pingpang                   ;

  reg  [EB-1:0]                   r_mem_rsta                   ; 
  wire [OVS/EB-1:0]               w_mem_wren [EB/2-1:0]        ;  
  wire [EB/2-1:0]                 w_ram_wren                   ;
  reg  [NUM_COL-1:0]              r_mem_wea  [EB-1:0]          ; 
  reg  [EB-1:0]                   r_mem_regcea                 ;
  reg  [EB-1:0]                   r_mem_ena                    ;
  wire [DW-1:0]                   w_mem_dina                   ;
  reg  [DW-1:0]                   r_mem_dina   [EB-1:0]        ;
  wire [AW:0]                     w_mem_wraddr [EB-1:0]        ; 
  reg  [AW-1:0]                   r_mem_addra  [EB-1:0]        ;
  wire [DW-1:0]                   w_mem_douta  [EB-1:0]        ;
  reg  [EB-1:0]                   r_mem_rstb                   ; 
  reg  [NUM_COL-1:0]              r_mem_web    [EB-1:0]        ;
  reg  [EB-1:0]                   r_mem_regceb                 ;
  reg  [EB-1:0]                   r_mem_enb                    ;
  reg  [DW-1:0]                   r_mem_dinb   [EB-1:0]        ;
  wire [AW-1:0]                   w_mem_addrb  [EB-1:0]        ;
  wire [DW-1:0]                   w_mem_doutb  [EB-1:0]        ;
  wire [DW-1:0]                   w_mem_doutb_temp_xil  [EB-1:0]        ;
  reg  [DW-1:0]                   r_mem_doutb_pipe  [EB-1:0][NP:0];


  reg                             r_pingpang_lock              ;
  reg  [3:0]                      r_ro_idx_lock                ;  
  reg  [3:0]                      r_sym_idx_lock               ;

  localparam  [8:0]                      r_rd_nr_gap0         = 9'd352;
  localparam  [8:0]                      r_rd_nr_gap1         = 9'd288;
  localparam  [8:0]                      r_rd_fft_gap0        = 9'd320;
  localparam  [8:0]                      r_rd_fft_gap1        = 9'd288;
  reg  [8:0]                      r_nr_rd_fft_gap              ;
  reg  [8:0]                      r_lte_rd_fft_gap             ;
  reg  [8:0]                      r_rd_fft_gap                 ;
  reg  [8:0]                      r_rd_fft_gap_m0_d1           ;
  reg  [8:0]                      r_rd_fft_gap_m0_d2           ;
  reg  [8:0]                      r_rd_fft_gap_m0              ;
(* use_dsp = "yes" *)reg  [8:0]   r_rd_fft_gap_m0_o_d1         ;
  reg  [8:0]                      r_rd_fft_gap_m0_o_d2         ;
  
  reg  [8:0]                      r_rd_fft_gap_m1              ;
  reg  [8:0]                      r_rd_fft_gap_m1_d1           ;
  reg  [8:0]                      r_rd_fft_gap_m1_d2           ;
(* use_dsp = "yes" *)  reg  [8:0] r_rd_fft_gap_m1_o_d1         ;
  reg  [8:0]                      r_rd_fft_gap_m1_o_d2         ;

  reg  [15:0]                     r_rd_fft_size                ;

  reg  [15:0]                     r_rd_fft_size_m0_d1          ;
  reg  [15:0]                     r_rd_fft_size_m0_d2          ;
  reg  [15:0]                     r_rd_fft_size_m0             ;
(* use_dsp = "yes" *)  reg [15:0] r_rd_fft_size_m0_o_d1        ;
  reg  [15:0]                     r_rd_fft_size_m0_o_d2        ;


  reg  [15:0]                     r_rd_fft_size_m1_d1          ;
  reg  [15:0]                     r_rd_fft_size_m1_d2          ;
  reg  [15:0]                     r_rd_fft_size_m1             ;
(* use_dsp = "yes" *)  reg [15:0] r_rd_fft_size_m1_o_d1        ;
  reg  [15:0]                     r_rd_fft_size_m1_o_d2        ;

  reg                             r_dout_busy                  ;
  reg  [1:0]                      r_sym_d_vld_cnt              ;
  reg                             r_pingpang_lck               ;
  reg  [3:0]                      r_ro_idx_lck                 ;
  reg  [3:0]                      r_sym_idx_lck                ;
  reg                             r_prev_pingpang_lck               ;
  reg  [3:0]                      r_prev_ro_idx_lck                 ;
  reg  [3:0]                      r_prev_sym_idx_lck                ;

  reg  [8:0]                      r_rd_gap_cnt                 ;
  reg  [15:0]                     r_rd_fft_cnt                 ;
  reg  [4:0]                      r_rd_ant_cnt                 ;  
                                                               
  reg                             r_rd_en                      ;
  wire [AW:0]                     w_rd_mem_addrb [EB-1:0]      ;
  reg  [AW-1:0]                   r_rd_mem_addrb [EB-1:0]      ; 
  reg  [OVS-1:0]                  ant_vld                      ; 

  wire [OVS-1:0]                  w_ant_vld_rd_dly             ;
  wire [4:0]                      w_ant_cnt_rd_dly             ;
  wire                            w_ant_en_rd_dly              ;
  reg [1-1 :0]                    r_mem_rd_mux1_bcf[EB-1:0]    ;
  reg [OB-1:0]                    r_mem_rd_mux1_i [EB-1:0]     ;
  reg [OB-1:0]                    r_mem_rd_mux1_q [EB-1:0]     ;
  reg [1-1 :0]                    r_mem_rd_mux2_bcf            ;
  reg [OB-1:0]                    r_mem_rd_mux2_i              ;
  reg [OB-1:0]                    r_mem_rd_mux2_q              ;

  wire [OVS-1:0]                  w_ant_vld_mux_dly            ;
  wire [4:0]                      w_ant_cnt_mux_dly            ;
  wire                            w_ant_en_mux_dly             ;
  reg                             r_frm_tick_lck               ;
  reg                             r_frm_tick_puls              ;
  wire                            w_frm_tick_o                 ;
  reg [31:0]                      r_cnt_in_dout_rqt            ;


always @(posedge i_clk) begin
  r_frm_tick    <= i_frm_tick;
  r_ro_idx      <= i_ro_idx  ;
  r_sym_idx     <= i_sym_idx ;
end

always @(posedge i_clk) begin
  r_sym_end         <= i_sym_end        ;
  r_sym_start       <= i_sym_start      ;
  r_din_vld         <= i_din_vld        ;
  r_din_i           <= i_din_i          ;
  r_din_q           <= i_din_q          ;
  r_bcf_enb         <= i_bcf_enb        ;
  r_ffttype         <= i_ffttype        ;
end  

generate
for(i = 0 ; i < 16; i = i + 1)begin
always @ (posedge i_clk)begin
  r_dout_rqt[i] <= i_dout_rqt;
end
end  
endgenerate


generate
for(i = 0 ; i < 8; i = i + 1)begin
always @ (posedge i_clk)begin
  r_rd_resync_frm_tick[i] <= i_rd_resync_frm_tick;
  r_wr_resync_frm_tick[i] <= i_wr_resync_frm_tick;
end
end  
endgenerate

always @(posedge i_clk)begin
  r_din_i_dly0 <= r_din_i;
  r_din_q_dly0 <= r_din_q;
  r_din_i_dly1 <= r_din_i_dly0;
  r_din_q_dly1 <= r_din_q_dly0;
end


always @(posedge i_clk)begin // for test
  if (r_dout_rqt[0])begin
    r_cnt_in_dout_rqt <= 'd0;  
  end else begin
    r_cnt_in_dout_rqt <= r_cnt_in_dout_rqt + 1'b1;
  end  
end

  
always @(posedge i_clk)begin
  if (r_wr_resync_frm_tick[0])
  begin
    r_ant_cnt <= 3'd0;
  end 
  else if (r_din_vld[OVS-1-OVS_offset] | r_sym_start[0])
  begin
    r_ant_cnt <= 3'd0;
  end 
  else if (!(|r_din_vld))
  begin
    r_ant_cnt <= r_ant_cnt;
  end
  else 
  begin
    r_ant_cnt <= r_ant_cnt + 1'b1;
  end
end

always @(posedge i_clk)begin
  if (r_wr_resync_frm_tick[0])begin
    r_ts_cnt <= 12'd0;
  end else if (r_sym_start[0])begin
    r_ts_cnt <= 12'd0;
  end else if (r_din_vld[OVS-1-OVS_offset])begin
    r_ts_cnt <= r_ts_cnt + 1'b1;
  end
end

always @(posedge i_clk)begin
  if (r_frm_tick)begin
    r_pingpang <= 1'b0;
  end else if (r_sym_end[OVS-1-OVS_offset])begin
    r_pingpang <= r_pingpang + 1'b1;
  end
end    


for (i = 0; i < EB/2; i = i + 1)begin
for (j = 0; j < OVS/EB; j = j + 1)begin
assign w_mem_wren[i][j] = r_din_vld[j*(2) + i*4+1];//+1 
end
assign w_ram_wren[i] = | (w_mem_wren[i]);
end

generate

for(i = 0; i < EB/2; i = i + 1)begin
  always @(posedge i_clk)begin
  if (r_wr_resync_frm_tick[1])begin
      r_mem_wea[i*2+0] <= {(9){1'b0}};
      r_mem_wea[i*2+1] <= {(9){1'b0}};            
  end else if (r_pingpang == 1'b0)begin
      r_mem_wea[i*2+0] <= {(9){w_ram_wren[i]}};
      r_mem_wea[i*2+1] <= {(9){1'b0}};
  end else begin
      r_mem_wea[i*2+0] <= {(9){1'b0}};
      r_mem_wea[i*2+1] <= {(9){w_ram_wren[i]}};
  end
  end
end    
endgenerate

generate
for(i = 0; i < EB/2; i = i + 1)begin
  always @(posedge i_clk)begin
  if (r_wr_resync_frm_tick[1])begin
      r_mem_ena[i*2+0] <= 1'b0;
      r_mem_ena[i*2+1] <= 1'b0;      
  end else if (r_pingpang == 1'b0)begin
      r_mem_ena[i*2+0] <= w_ram_wren[i];
      r_mem_ena[i*2+1] <= 1'b0;
  end else begin
      r_mem_ena[i*2+0] <= 1'b0;
      r_mem_ena[i*2+1] <= w_ram_wren[i];
  end
  end
end    
endgenerate


assign w_mem_dina = {7'd0,r_bcf_enb,{{(16-IB){r_din_i[IB-1]}},r_din_i},{{(16-IB){r_din_q[IB-1]}},r_din_q},{{(16-IB){r_din_i_dly0[IB-1]}},r_din_i_dly0},{{(16-IB){r_din_q_dly0[IB-1]}},r_din_q_dly0}};

generate
for(i = 0; i < EB/2; i = i + 1)begin
  always @(posedge i_clk)begin
  if (r_wr_resync_frm_tick[2])begin
      r_mem_dina[i*2+0] <= {(DW){1'b0}};
      r_mem_dina[i*2+1] <= {(DW){1'b0}};
  end else if (r_pingpang == 1'b0)begin
      r_mem_dina[i*2+0] <= w_mem_dina;
      r_mem_dina[i*2+1] <= {(DW){1'b0}};
  end else begin
      r_mem_dina[i*2+0] <= {(DW){1'b0}};
      r_mem_dina[i*2+1] <= w_mem_dina;
  end
  end
end    
endgenerate  

for (i = 0; i < EB; i = i + 1)begin 
////assign w_mem_wraddr[i] = {r_ant_cnt[$clog2(OVS/EB+1)+1:1],r_ts_cnt[AW-($clog2(OVS/EB)):0]}; 
//assign w_mem_wraddr[i] = {r_ant_cnt[clogb2(OVS/EB+1):1],r_ts_cnt[AW-(clogb2(OVS/EB+1)):0]}; 

//        assign w_mem_wraddr[i] = {r_ant_cnt[clogb2(OVS/EB):1],r_ts_cnt[AW-(clogb2(OVS/EB)):0]}; 

    if(OVS == 2 & SCS == 0)
            assign w_mem_wraddr[i] = {r_ant_cnt[clogb2(4/EB):1],r_ts_cnt[AW-(clogb2(4/EB)):0]}; 
    else
            assign w_mem_wraddr[i] = {r_ant_cnt[clogb2(OVS/EB):1],r_ts_cnt[AW-(clogb2(OVS/EB)):0]}; 
    
end

generate
for(i = 0; i < EB; i = i + 1)begin
  always @ (posedge i_clk)begin
    if (r_wr_resync_frm_tick[3])begin
      r_mem_addra[i]  <= 'd0;
    end else begin
      r_mem_addra[i]  <= w_mem_wraddr[i];
    end
  end
end
endgenerate  

generate
    for(i = 0; i < EB; i = i + 1)
    begin
//          tagc_buf #(
//            .AWIDTH   (AW          )
//          , .DWIDTH   (DW          )
//          , .NBPIPE   (NP          )
//         ) 
//         inst_tagc_buf
//         ( 
//           .clk       (i_clk       )
//            
//          , .rsta     (r_mem_rsta[i]  )
//          , .wea      (r_mem_wea[i]   )
//          , .regcea   (r_mem_regcea[i])
//          , .mem_ena  (r_mem_ena[i]   )
//          , .dina     (r_mem_dina[i]  )
//          , .addra    (r_mem_addra[i] )
//          , .douta    (w_mem_douta[i] )
//        
//          , .rstb     (r_mem_rstb[i]  )
//          , .web      (r_mem_web[i]   )
//          , .regceb   (r_mem_regceb[i])
//          , .mem_enb  (r_mem_enb[i]   )
//          , .dinb     (r_mem_dinb[i]  )
//          , .addrb    (w_mem_addrb[i] )
//          , .doutb    (w_mem_doutb_temp_xil[i] )
//           );
        ylib_rams_sdp #(
            .WIDTH(DW),
            .DEPTH(2**AW),
            .VENDOR(VENDOR),
            .RAM_STYLE("ultra")
        ) ylib_rams_sdp_instance (
            .clk(i_clk),
            .ena(r_mem_ena[i]),
            .enb(r_mem_enb[i]),
            .wea(r_mem_wea[i][0]),
            .addra(r_mem_addra[i]),
            .addrb(w_mem_addrb[i]),
            .dia(r_mem_dina[i]),
            .dob(w_mem_doutb[i])
        );
        
        always @ (posedge i_clk)
        begin
            r_mem_doutb_pipe[i][0] <=  w_mem_doutb[i];
            
            for (k = 0; k < NP; k = k+1)
            begin
                r_mem_doutb_pipe[i][k+1] <= r_mem_doutb_pipe[i][k];     //aligned addr 7
            end
        end 
    end
endgenerate



always @ (posedge i_clk)begin
    if(i_rst)
    begin
        r_pingpang_lock <= 1;
        r_ro_idx_lock   <= 1;
        r_sym_idx_lock  <= 1;
    end
    else if (r_sym_end[OVS-1-OVS_offset])
    begin
        r_pingpang_lock <= r_pingpang;
        r_ro_idx_lock   <= r_ro_idx;
        r_sym_idx_lock  <= r_sym_idx;
    end
end


always @ (posedge i_clk)begin
  case (r_ffttype)
    4'd0 : begin
      if (r_sym_idx_lock == LCP0_SYM_N || r_sym_idx_lock == LCP1_SYM_N)begin
        r_lte_rd_fft_gap <= {{(3){1'b0}},r_rd_fft_gap0[8:3]};
      end else begin
        r_lte_rd_fft_gap <= {{(3){1'b0}},r_rd_fft_gap1[8:3]};
      end
    end
    4'd1 : begin
      if (r_sym_idx_lock == LCP0_SYM_N || r_sym_idx_lock == LCP1_SYM_N)begin
        r_lte_rd_fft_gap <= {{(2){1'b0}},r_rd_fft_gap0[8:2]};
      end else begin
        r_lte_rd_fft_gap <= {{(2){1'b0}},r_rd_fft_gap1[8:2]};
      end      
    end
    4'd2 : begin
      if (r_sym_idx_lock == LCP0_SYM_N || r_sym_idx_lock == LCP1_SYM_N)begin
        r_lte_rd_fft_gap <= {{(1){1'b0}},r_rd_fft_gap0[8:1]};
      end else begin
        r_lte_rd_fft_gap <= {{(1){1'b0}},r_rd_fft_gap1[8:1]};
      end      
    end    
    4'd3 : begin
      if (r_sym_idx_lock == LCP0_SYM_N || r_sym_idx_lock == LCP1_SYM_N)begin
        r_lte_rd_fft_gap <= {{(0){1'b0}},r_rd_fft_gap0[8:0]};
      end else begin
        r_lte_rd_fft_gap <= {{(0){1'b0}},r_rd_fft_gap1[8:0]};
      end      
    end 
    default: begin
      if (r_sym_idx_lock == LCP0_SYM_N || r_sym_idx_lock == LCP1_SYM_N)begin
        r_lte_rd_fft_gap <= {{(2){1'b0}},r_rd_fft_gap0[8:2]};
      end else begin
        r_lte_rd_fft_gap <= {{(2){1'b0}},r_rd_fft_gap1[8:2]};
      end  
    end

  endcase
end

always @ (posedge i_clk)begin
  case (r_ffttype)
    4'd0 : begin
      if (r_sym_idx_lock == LCP1_NR_SYM_N)begin
        r_nr_rd_fft_gap <= {{(3){1'b0}},r_rd_nr_gap0[8:3]};
      end else begin
        r_nr_rd_fft_gap <= {{(3){1'b0}},r_rd_nr_gap1[8:3]};
      end
    end
    4'd1 : begin
      if (r_sym_idx_lock == LCP1_NR_SYM_N)begin
        r_nr_rd_fft_gap <= {{(2){1'b0}},r_rd_nr_gap0[8:2]};
      end else begin
        r_nr_rd_fft_gap <= {{(2){1'b0}},r_rd_nr_gap1[8:2]};
      end      
    end
    4'd2 : begin
      if (r_sym_idx_lock == LCP1_NR_SYM_N)begin
        r_nr_rd_fft_gap <= {{(1){1'b0}},r_rd_nr_gap0[8:1]};
      end else begin
        r_nr_rd_fft_gap <= {{(1){1'b0}},r_rd_nr_gap1[8:1]};
      end      
    end    
    4'd3 : begin
      if (r_sym_idx_lock == LCP1_NR_SYM_N)begin
        r_nr_rd_fft_gap <= {{(0){1'b0}},r_rd_nr_gap0[8:0]};
      end else begin
        r_nr_rd_fft_gap <= {{(0){1'b0}},r_rd_nr_gap1[8:0]};
      end      
    end 
    default: begin
      if (r_sym_idx_lock == LCP1_NR_SYM_N)begin
        r_nr_rd_fft_gap <= {{(2){1'b0}},r_rd_nr_gap0[8:2]};
      end else begin
        r_nr_rd_fft_gap <= {{(2){1'b0}},r_rd_nr_gap1[8:2]};
      end  
    end

  endcase    
end

always @ (posedge i_clk)begin
  if (SCS == 0)begin
    r_rd_fft_gap <= r_lte_rd_fft_gap;
  end else begin
    r_rd_fft_gap <= r_nr_rd_fft_gap;
  end
end

always @ (posedge i_clk)begin
  r_rd_fft_gap_m0_d1 <= r_rd_fft_gap;
  r_rd_fft_gap_m0_d2 <= r_rd_fft_gap_m0_d1;
end

always @ (posedge i_clk)begin
  r_rd_fft_gap_m1_d1 <= r_rd_fft_gap;
  r_rd_fft_gap_m1_d2 <= r_rd_fft_gap_m1_d1;
end

always @ (posedge i_clk)begin
  r_rd_fft_gap_m0_o_d1 <= r_rd_fft_gap_m0_d2 - 0;
  r_rd_fft_gap_m1_o_d1 <= r_rd_fft_gap_m1_d2 - 1;
end

always @ (posedge i_clk)begin
  r_rd_fft_gap_m0_o_d2 <= r_rd_fft_gap_m0_o_d1;
  r_rd_fft_gap_m0      <= r_rd_fft_gap_m0_o_d2;
end

always @ (posedge i_clk)begin
  r_rd_fft_gap_m1_o_d2 <= r_rd_fft_gap_m1_o_d1;
  r_rd_fft_gap_m1      <= r_rd_fft_gap_m1_o_d2;
end


always @ (posedge i_clk)begin
  case (r_ffttype)
    4'd0 :begin
      r_rd_fft_size <= 16'd512;
    end
    4'd1 :begin
      r_rd_fft_size <= 16'd1024;
    end
    4'd2 :begin
      r_rd_fft_size <= 16'd2048;
    end
    4'd3 :begin
      r_rd_fft_size <= 16'd4096;
    end
    default:begin
      r_rd_fft_size <= 16'd2048;
    end
  endcase
end

always @ (posedge i_clk)begin
  r_rd_fft_size_m0_d1  <= r_rd_fft_size;
  r_rd_fft_size_m0_d2  <= r_rd_fft_size_m0_d1;
end

always @ (posedge i_clk)begin
  r_rd_fft_size_m1_d1  <= r_rd_fft_size;
  r_rd_fft_size_m1_d2  <= r_rd_fft_size_m1_d1;
end


always @ (posedge i_clk)begin
  r_rd_fft_size_m0_o_d1 <= r_rd_fft_size_m0_d2 - 0;
  r_rd_fft_size_m1_o_d1 <= r_rd_fft_size_m1_d2 - 1;
end

always @ (posedge i_clk)begin
  r_rd_fft_size_m0_o_d2 <= r_rd_fft_size_m0_o_d1;
  r_rd_fft_size_m0      <= r_rd_fft_size_m0_o_d2;
end

always @ (posedge i_clk)begin
  r_rd_fft_size_m1_o_d2 <= r_rd_fft_size_m1_o_d1;
  r_rd_fft_size_m1      <= r_rd_fft_size_m1_o_d2;
end


always @ (posedge i_clk)begin
    if(i_rst)
    begin
        r_prev_pingpang_lck <= 1'b0     ;
        r_prev_ro_idx_lck   <= 4'd0     ;
        r_prev_sym_idx_lck  <= 4'd0    ;
      
        r_pingpang_lck      <= 1'b1   ;
        r_ro_idx_lck        <= 4'd1   ;
        r_sym_idx_lck       <= 4'd1   ;    
    end    
    else if (r_dout_rqt[1] == 1'b1 )begin     
        r_pingpang_lck      <= r_pingpang_lock  ;
        r_ro_idx_lck        <= r_ro_idx_lock    ;
        r_sym_idx_lck       <= r_sym_idx_lock   ;
        
        r_prev_pingpang_lck <= r_pingpang_lck   ;
        r_prev_ro_idx_lck   <= r_ro_idx_lck     ;
        r_prev_sym_idx_lck  <= r_sym_idx_lck    ;
    end
    else
    begin
        
    end
end

always @ (posedge i_clk)begin
  if (r_dout_rqt[2] == 1'b1 )begin
    r_rd_fft_cnt <= 'd0;
  end else if ( (r_rd_gap_cnt == r_rd_fft_gap_m1) && (r_rd_ant_cnt != (OVS -1)) ) begin
    r_rd_fft_cnt <= 'd0;
  end else begin  
   if (r_rd_fft_cnt == r_rd_fft_size_m0)begin
      r_rd_fft_cnt <= r_rd_fft_size_m0;
    end else begin
      r_rd_fft_cnt <= r_rd_fft_cnt + 1'b1;
    end
  end
end

always @ (posedge i_clk)begin
  if (r_dout_rqt[3] == 1'b1 )begin
    r_rd_gap_cnt <= r_rd_fft_gap_m0;
  end else if ( r_rd_fft_cnt == (r_rd_fft_size_m1))  begin
    r_rd_gap_cnt <= 'd0;
  end else begin
    if (r_rd_gap_cnt == r_rd_fft_gap_m0)begin
      r_rd_gap_cnt <= r_rd_fft_gap_m0;
    end else begin
      r_rd_gap_cnt <= r_rd_gap_cnt + 1'b1;
    end
  end
end

always @ (posedge i_clk)begin
  if (r_dout_rqt[4] == 1'b1 )begin
    r_rd_ant_cnt <= 'd0;
  end else if (r_rd_gap_cnt == r_rd_fft_gap_m1)begin
    if (r_rd_ant_cnt == OVS-1-OVS_offset)begin
      r_rd_ant_cnt <= OVS -1;
    end else begin
      r_rd_ant_cnt <= r_rd_ant_cnt + 1'b1;
    end
  end
end

always @ (posedge i_clk)begin
  if (r_dout_rqt[5] == 1'b1 )begin
    r_rd_en <= 1'b1;
  end else if ( (r_rd_gap_cnt == r_rd_fft_gap_m1) && (r_rd_ant_cnt < (OVS - OVS_offset -1 )) )begin
    r_rd_en <= 1'b1;
  end else if (r_rd_fft_cnt == r_rd_fft_size_m1)begin
    r_rd_en <= 1'b0;
  end
end


for (i = 0; i < EB; i = i + 1)begin 
assign w_rd_mem_addrb[i]   = {r_rd_ant_cnt[clogb2(OVS/EB):1],r_rd_fft_cnt[AW-(clogb2(OVS/EB)):0]}; 
end


generate
for(i = 0; i < EB; i = i + 1)begin
  always @ (posedge i_clk)begin
    if (r_dout_rqt[6])begin
      r_rd_mem_addrb[i] <= 'd0;
    end else begin
      r_rd_mem_addrb[i] <= w_rd_mem_addrb[i][AW-1:0]; 
    end
  end
end
endgenerate

for (i = 0; i < EB; i = i + 1)begin 
assign w_mem_addrb[i]  = r_rd_mem_addrb[i];
end


generate
for(i = 0; i < OVS; i = i + 1)begin
  always @ (posedge i_clk)begin
    if (r_dout_rqt[7])begin
      ant_vld[i] <= 1'b0;
    end else if (r_rd_ant_cnt == i)begin
      ant_vld[i] <= r_rd_en;
    end else begin
      ant_vld[i] <= 1'b0;
    end
  end      
end
endgenerate


generate
for(i = 0; i < EB; i = i + 1)begin
  always @ (posedge i_clk)begin
    r_mem_web[i]    <= {(NUM_COL){1'b0}};
    r_mem_regceb[i] <= 1'b1; 
    r_mem_dinb[i]   <= 1'b0;
  end
end
endgenerate  

generate
for(i = 0; i < EB; i = i + 1)begin
  always @ (posedge i_clk)begin
    if (r_dout_rqt[8])begin
      r_mem_enb[i] <= 'd0;
    end 
    else begin
      r_mem_enb[i] <= r_rd_en;
    end
  end
end
endgenerate  
//////


ylib_reg #( .WIDTH(OVS      ), .DEPTH(NP   ) ) reg_shr_ant_vld_rd_dly   ( .i_clk(i_clk), .i_in(ant_vld     ), .o_out(w_ant_vld_rd_dly ) );
ylib_reg #( .WIDTH(5        ), .DEPTH(NP   ) ) reg_shr_ant_cnt_rd_dly   ( .i_clk(i_clk), .i_in(r_rd_ant_cnt), .o_out(w_ant_cnt_rd_dly ) );
ylib_reg #( .WIDTH(1        ), .DEPTH(NP   ) ) reg_shr_ant_en_rd_dly    ( .i_clk(i_clk), .i_in(r_rd_en     ), .o_out(w_ant_en_rd_dly  ) );


//generate
//  for (i = 0; i < EB; i = i + 1)begin
//  always @ (posedge i_clk)begin
//    if (w_ant_cnt_rd_dly[0] == 1'b0)begin
//      r_mem_rd_mux1_i[i]  <= w_mem_doutb[i][OB+16:16];
//      r_mem_rd_mux1_q[i]  <= w_mem_doutb[i][OB+0 :0 ];
//    end else begin
//      r_mem_rd_mux1_i[i]  <= w_mem_doutb[i][OB+48:48];
//      r_mem_rd_mux1_q[i]  <= w_mem_doutb[i][OB+32:32];      
//    end
//      r_mem_rd_mux1_bcf[i]<= w_mem_doutb[i][64]      ;    
//  end
//  end
//endgenerate
generate
  for (i = 0; i < EB; i = i + 1)begin
  always @ (posedge i_clk)begin
    if (w_ant_cnt_rd_dly[0] == 1'b0)begin
      r_mem_rd_mux1_i[i]  <= r_mem_doutb_pipe[i][NP][OB+16:16];
      r_mem_rd_mux1_q[i]  <= r_mem_doutb_pipe[i][NP][OB+0 :0 ];
    end else begin
      r_mem_rd_mux1_i[i]  <= r_mem_doutb_pipe[i][NP][OB+48:48];
      r_mem_rd_mux1_q[i]  <= r_mem_doutb_pipe[i][NP][OB+32:32];      
    end
      r_mem_rd_mux1_bcf[i]<= r_mem_doutb_pipe[i][NP][64]      ;    
  end
  end
endgenerate

always @ (posedge i_clk)begin      
    if (r_pingpang_lck == 1'b0) begin
      r_mem_rd_mux2_bcf <= r_mem_rd_mux1_bcf[0];
      r_mem_rd_mux2_i   <= r_mem_rd_mux1_i[0];
      r_mem_rd_mux2_q   <= r_mem_rd_mux1_q[0];
    end else begin
      r_mem_rd_mux2_bcf <= r_mem_rd_mux1_bcf[1];
      r_mem_rd_mux2_i   <= r_mem_rd_mux1_i[1];
      r_mem_rd_mux2_q   <= r_mem_rd_mux1_q[1];        
    end
end


ylib_reg #( .WIDTH(OVS      ), .DEPTH(NP-1 ) ) reg_shr_ant_vld_mux_dly   ( .i_clk(i_clk), .i_in(w_ant_vld_rd_dly), .o_out(w_ant_vld_mux_dly ) );
ylib_reg #( .WIDTH(5        ), .DEPTH(NP   ) ) reg_shr_ant_cnt_mux_dly   ( .i_clk(i_clk), .i_in(w_ant_cnt_rd_dly), .o_out(w_ant_cnt_mux_dly ) );
ylib_reg #( .WIDTH(1        ), .DEPTH(NP   ) ) reg_shr_ant_en_mux_dly    ( .i_clk(i_clk), .i_in(w_ant_en_rd_dly ), .o_out(w_ant_en_mux_dly  ) );


reg f_norm_out;

always @(posedge i_clk)
begin
    if(w_ant_vld_rd_dly[0])
    begin
        if( (r_prev_pingpang_lck!=r_pingpang_lock) || (r_prev_ro_idx_lck!=r_ro_idx_lock)   || (r_prev_sym_idx_lck!=r_sym_idx_lock) )
            f_norm_out  <=  1'b1;
        else
            f_norm_out  <=  1'b0;
    end
    else
            f_norm_out  <=  f_norm_out  ;    
end

assign o_dout_vld = f_norm_out ? w_ant_vld_mux_dly  : 0   ;
assign o_dout_i   = f_norm_out ? r_mem_rd_mux2_i    : 0   ;
assign o_dout_q   = f_norm_out ? r_mem_rd_mux2_q    : 0   ;
assign o_bcf_enb  = f_norm_out ? r_mem_rd_mux2_bcf  : 0   ;
//assign o_dout_vld = w_ant_vld_mux_dly  ;
//assign o_dout_i   = r_mem_rd_mux2_i    ;
//assign o_dout_q   = r_mem_rd_mux2_q    ;
//assign o_bcf_enb  = r_mem_rd_mux2_bcf  ;



always @ (posedge i_clk)begin
  if (r_frm_tick)begin
    r_frm_tick_lck <= 1'b1;
  end else if (i_gain_vld)begin
    r_frm_tick_lck <= 1'b0;
  end
end


always @ (posedge i_clk)begin
  if (i_gain_vld == 1'b1 && r_frm_tick_lck == 1'b1)begin
    r_frm_tick_puls <= 1'b1;
  end else begin
    r_frm_tick_puls <= 1'b0;
  end
end

ylib_reg #( .WIDTH(1  ), .DEPTH(8 ) ) reg_shr_frm_tick_dly    ( .i_clk(i_clk), .i_in(r_frm_tick_puls ), .o_out(w_frm_tick_o  ) );
//assign o_frm_tick = w_frm_tick_o ;
assign o_ro_idx   = r_ro_idx_lck ;
assign o_sym_idx  = r_sym_idx_lck; 
  
// sync shift
reg     [18 -1:0] r_shr_val ;
reg [1:0] srstype = 2'd0;

always@(posedge i_clk) begin
        case(SCS)
            0   : r_shr_val <= (18'd17664-18'd700);//(18'd17664-18'd1250);//18'd17536 ;// - 18'd1100;
            1   : r_shr_val <= (18'd17664-18'd700)/2;//(18'd17664-18'd1200)/2;//18'd8768  ;
//            2'b10   : r_shr_val <= 18'd4384  ;
//            2'b11   : r_shr_val <= 18'd4384/2  ;
            default : r_shr_val <= 18'd17536 ;
        endcase
   
end

reg     [1  -1:0] r_shr_en  ;
reg     [18 -1:0] r_shr     ;
wire              w_frm_temp;

always@(posedge i_clk) begin
    if(i_frm_tick) begin
        r_shr_en <=  1'd1   ;
    end 
    else if(r_shr==r_shr_val-1) begin
        r_shr_en <=  1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(i_frm_tick) begin
        r_shr <=  18'b0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  (r_shr==r_shr_val-1) ? 18'b0 : r_shr+1'd1    ;
    end 
end

//assign w_frm_temp  =  r_shr_en&&(r_shr==r_shr_val-1) ;
assign o_frm_tick = r_shr_en&&(r_shr==r_shr_val-1) ;
  

//////////////////

  function integer clogb2;
    input integer depth;
      for (clogb2=0; depth>0; clogb2=clogb2+1)
        depth = depth >> 1;
  endfunction


endmodule
