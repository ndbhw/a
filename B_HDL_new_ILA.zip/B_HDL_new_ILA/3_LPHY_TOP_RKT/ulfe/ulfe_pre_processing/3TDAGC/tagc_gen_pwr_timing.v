// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : tagc
//  Author       : Han Xiangdong
//  Description  : Power Calculation
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------


module tagc_gen_pwr_timing  #
  (
   parameter TYPE         = 0         // 0: ULFE 1: RAFE
  ,parameter OC           = 1                            
  ,parameter OVS          = 2**OC     // 0:2 , 1:4 , 2:8
  ,parameter IB           = 15        // IQ input data width
  )
  (
   input                  i_rst
  ,input                  i_clk

  ,input  [3:0]           i_ffttype   

  ,input  [OVS-1:0]       i_tdagc_vld
  ,input  [IB-1:0]        i_tdagc_i
  ,input  [IB-1:0]        i_tdagc_q

  ,input                  i_frm_tick
  ,input                  i_slt_tick
  ,input  [6-1:0]         i_slt_idx
  ,input                  i_sym_tick
  ,input  [3:0]           i_sym_idx
  ,input                  i_ro_tick
  ,input  [3:0]           i_ro_idx

  ,output [OVS-1:0]       o_tdagc_vld
  ,output [IB-1:0]        o_tdagc_i
  ,output [IB-1:0]        o_tdagc_q

  ,output                 o_frm_tick
  ,output                 o_slt_tick
  ,output [6-1:0]         o_slt_idx
  ,output                 o_ro_tick
  ,output [3:0]           o_ro_idx
  ,output                 o_sym_tick
  ,output [3:0]           o_sym_idx

  ,output [OVS-1:0]       o_pwr_start
  ,output [OVS-1:0]       o_pwr_end
  ,output [OVS-1:0]       o_pwr_en

  ,output [6-1:0]         o_slt_idx_lock
  ,output [3:0]           o_sym_idx_lock
  ,output [3:0]           o_ro_idx_lock
);
 genvar i;
 genvar j;

  wire  [OVS-1:0] w_d00_tdagc_vld;
  wire  [IB-1:0]  w_d00_tdagc_i  ;
  wire  [IB-1:0]  w_d00_tdagc_q  ;

  wire  [3:0]     w_ffttype      ;    

  wire            w_d00_frm_tick ;
  wire            w_d00_slt_tick ;
  wire  [6-1:0]   w_d00_slt_idx  ;
  wire            w_d00_sym_tick ;
  wire  [4-1:0]   w_d00_sym_idx  ;
  wire            w_d00_ro_tick  ;
  wire  [4-1:0]   w_d00_ro_idx   ;

  wire  [OVS-1:0] w_d01_tdagc_vld;
  wire  [IB-1:0]  w_d01_tdagc_i  ;
  wire  [IB-1:0]  w_d01_tdagc_q  ;
  wire            w_d01_frm_tick ;
  wire            w_d01_slt_tick ;
  wire  [6-1:0]   w_d01_slt_idx  ;
  wire            w_d01_sym_tick ;
  wire  [4-1:0]   w_d01_sym_idx  ;
  wire            w_d01_ro_tick  ;
  wire  [4-1:0]   w_d01_ro_idx   ;

  wire  [OVS-1:0] w_d02_tdagc_vld;
  wire  [IB-1:0]  w_d02_tdagc_i  ;
  wire  [IB-1:0]  w_d02_tdagc_q  ;
  wire            w_d02_frm_tick ;
  wire            w_d02_slt_tick ;
  wire  [6-1:0]   w_d02_slt_idx  ;
  wire            w_d02_sym_tick ;
  wire  [4-1:0]   w_d02_sym_idx  ;
  wire            w_d02_ro_tick  ;
  wire  [4-1:0]   w_d02_ro_idx   ;

  wire  [OVS-1:0] w_d03_tdagc_vld;
  wire  [IB-1:0]  w_d03_tdagc_i  ;
  wire  [IB-1:0]  w_d03_tdagc_q  ;
  wire            w_d03_frm_tick ;
  wire            w_d03_slt_tick ;
  wire  [6-1:0]   w_d03_slt_idx  ;
  wire            w_d03_sym_tick ;
  wire  [4-1:0]   w_d03_sym_idx  ;
  wire            w_d03_ro_tick  ;
  wire  [4-1:0]   w_d03_ro_idx   ;

  reg [15:0]      r_ts_cnt_in_sym_d01 [OVS-1:0];
  reg             r_pwr_cal_start_d02 [OVS-1:0];
  reg             r_pwr_cal_end_d02   [OVS-1:0];
  reg             r_pwr_cal_end_d02_0 [OVS-1:0];
  reg             r_pwr_cal_en_d02    [OVS-1:0];
  reg [6:0]       r_slt_idx_lock               ;
  reg [3:0]       r_sym_idx_lock               ;
  reg [3:0]       r_ro_idx_lock                ;
  reg             r_pwr_cal_start_d03 [OVS-1:0];
  reg             r_pwr_cal_end_d03 [OVS-1:0]  ;

ylib_reg #( .WIDTH(OVS), .DEPTH(1) ) reg_shr_vld_d00      ( .i_clk(i_clk), .i_in(i_tdagc_vld    ),  .o_out(w_d00_tdagc_vld) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_i_d00        ( .i_clk(i_clk), .i_in(i_tdagc_i      ),  .o_out(w_d00_tdagc_i  ) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_q_d00        ( .i_clk(i_clk), .i_in(i_tdagc_q      ),  .o_out(w_d00_tdagc_q  ) ); 
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_ffttype_d00  ( .i_clk(i_clk), .i_in(i_ffttype      ),  .o_out(w_ffttype      ) );

ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_frm_tick_d00 ( .i_clk(i_clk), .i_in(i_frm_tick     ),  .o_out(w_d00_frm_tick ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_slt_tick_d00 ( .i_clk(i_clk), .i_in(i_slt_tick     ),  .o_out(w_d00_slt_tick ) );
ylib_reg #( .WIDTH(6  ), .DEPTH(1) ) reg_shr_slt_idx_d00  ( .i_clk(i_clk), .i_in(i_slt_idx      ),  .o_out(w_d00_slt_idx  ) );  
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_sym_tick_d00 ( .i_clk(i_clk), .i_in(i_sym_tick     ),  .o_out(w_d00_sym_tick ) );
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_sym_idx_d00  ( .i_clk(i_clk), .i_in(i_sym_idx      ),  .o_out(w_d00_sym_idx  ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_ro_tick_d00  ( .i_clk(i_clk), .i_in(i_ro_tick      ),  .o_out(w_d00_ro_tick  ) );  
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_ro_idx_d00   ( .i_clk(i_clk), .i_in(i_ro_idx       ),  .o_out(w_d00_ro_idx   ) );  

ylib_reg #( .WIDTH(OVS), .DEPTH(1) ) reg_shr_vld_d01      ( .i_clk(i_clk), .i_in(w_d00_tdagc_vld),  .o_out(w_d01_tdagc_vld) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_i_d01        ( .i_clk(i_clk), .i_in(w_d00_tdagc_i  ),  .o_out(w_d01_tdagc_i  ) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_q_d01        ( .i_clk(i_clk), .i_in(w_d00_tdagc_q  ),  .o_out(w_d01_tdagc_q  ) );  

ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_frm_tick_d01 ( .i_clk(i_clk), .i_in(w_d00_frm_tick ),  .o_out(w_d01_frm_tick ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_slt_tick_d01 ( .i_clk(i_clk), .i_in(w_d00_slt_tick ),  .o_out(w_d01_slt_tick ) );
ylib_reg #( .WIDTH(6  ), .DEPTH(1) ) reg_shr_slt_idx_d01  ( .i_clk(i_clk), .i_in(w_d00_slt_idx  ),  .o_out(w_d01_slt_idx  ) );  
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_sym_tick_d01 ( .i_clk(i_clk), .i_in(w_d00_sym_tick ),  .o_out(w_d01_sym_tick ) );
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_sym_idx_d01  ( .i_clk(i_clk), .i_in(w_d00_sym_idx  ),  .o_out(w_d01_sym_idx  ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_ro_tick_d01  ( .i_clk(i_clk), .i_in(w_d00_ro_tick  ),  .o_out(w_d01_ro_tick  ) );  
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_ro_idx_d01   ( .i_clk(i_clk), .i_in(w_d00_ro_idx   ),  .o_out(w_d01_ro_idx   ) );  

ylib_reg #( .WIDTH(OVS), .DEPTH(1) ) reg_shr_vld_d02      ( .i_clk(i_clk), .i_in(w_d01_tdagc_vld),  .o_out(w_d02_tdagc_vld) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_i_d02        ( .i_clk(i_clk), .i_in(w_d01_tdagc_i  ),  .o_out(w_d02_tdagc_i  ) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_q_d02        ( .i_clk(i_clk), .i_in(w_d01_tdagc_q  ),  .o_out(w_d02_tdagc_q  ) );  

ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_frm_tick_d02 ( .i_clk(i_clk), .i_in(w_d01_frm_tick ),  .o_out(w_d02_frm_tick ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_slt_tick_d02 ( .i_clk(i_clk), .i_in(w_d01_slt_tick ),  .o_out(w_d02_slt_tick ) );
ylib_reg #( .WIDTH(6  ), .DEPTH(1) ) reg_shr_slt_idx_d02  ( .i_clk(i_clk), .i_in(w_d01_slt_idx  ),  .o_out(w_d02_slt_idx  ) );  
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_sym_tick_d02 ( .i_clk(i_clk), .i_in(w_d01_sym_tick ),  .o_out(w_d02_sym_tick ) );
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_sym_idx_d02  ( .i_clk(i_clk), .i_in(w_d01_sym_idx  ),  .o_out(w_d02_sym_idx  ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_ro_tick_d02  ( .i_clk(i_clk), .i_in(w_d01_ro_tick  ),  .o_out(w_d02_ro_tick  ) );  
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_ro_idx_d02   ( .i_clk(i_clk), .i_in(w_d01_ro_idx   ),  .o_out(w_d02_ro_idx   ) ); 

ylib_reg #( .WIDTH(OVS), .DEPTH(1) ) reg_shr_vld_d03      ( .i_clk(i_clk), .i_in(w_d02_tdagc_vld),  .o_out(w_d03_tdagc_vld) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_i_d03        ( .i_clk(i_clk), .i_in(w_d02_tdagc_i  ),  .o_out(w_d03_tdagc_i  ) );
ylib_reg #( .WIDTH(IB ), .DEPTH(1) ) reg_shr_q_d03        ( .i_clk(i_clk), .i_in(w_d02_tdagc_q  ),  .o_out(w_d03_tdagc_q  ) );  

ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_frm_tick_d03 ( .i_clk(i_clk), .i_in(w_d02_frm_tick ),  .o_out(w_d03_frm_tick ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_slt_tick_d03 ( .i_clk(i_clk), .i_in(w_d02_slt_tick ),  .o_out(w_d03_slt_tick ) );
ylib_reg #( .WIDTH(6  ), .DEPTH(1) ) reg_shr_slt_idx_d03  ( .i_clk(i_clk), .i_in(w_d02_slt_idx  ),  .o_out(w_d03_slt_idx  ) );  
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_sym_tick_d03 ( .i_clk(i_clk), .i_in(w_d02_sym_tick ),  .o_out(w_d03_sym_tick ) );
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_sym_idx_d03  ( .i_clk(i_clk), .i_in(w_d02_sym_idx  ),  .o_out(w_d03_sym_idx  ) );
ylib_reg #( .WIDTH(1  ), .DEPTH(1) ) reg_shr_ro_tick_d03  ( .i_clk(i_clk), .i_in(w_d02_ro_tick  ),  .o_out(w_d03_ro_tick  ) );  
ylib_reg #( .WIDTH(4  ), .DEPTH(1) ) reg_shr_ro_idx_d03   ( .i_clk(i_clk), .i_in(w_d02_ro_idx   ),  .o_out(w_d03_ro_idx   ) ); 


generate
  for(i = 0; i < OVS; i = i + 1)begin
    
  always @ (posedge i_clk)begin // TS counter in a symbol
    if (w_d00_sym_tick)begin
      r_ts_cnt_in_sym_d01[i] <= 16'd0;
    end else if (w_d00_tdagc_vld[i])begin
      r_ts_cnt_in_sym_d01[i] <= r_ts_cnt_in_sym_d01[i] + 1'b1;
    end
end

always @ (posedge i_clk)begin
  if (TYPE == 0)begin
    if (w_d00_sym_tick)begin
      r_pwr_cal_start_d02[i] <= 1'b0;
    end else if (w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i] == 0 )begin
      r_pwr_cal_start_d02[i] <= 1'b1;
    end else begin
      r_pwr_cal_start_d02[i] <= 1'b0;
    end
  end else begin
    if (w_ffttype == 0)begin
      if (w_d00_sym_tick)begin
        r_pwr_cal_start_d02[i] <= 1'b0;
      end else if (w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i] == 0 )begin
        r_pwr_cal_start_d02[i] <= 1'b1;
      end else begin
        r_pwr_cal_start_d02[i] <= 1'b0;
      end 
    end else if (w_ffttype == 2)begin
      if (w_d00_sym_tick)begin
        r_pwr_cal_start_d02[i] <= 1'b0;
      end else if (w_d01_sym_idx == 0 && r_ts_cnt_in_sym_d01[i][11:9] == 3'b011 && r_ts_cnt_in_sym_d01[i][8:0] == 9'd0 && w_d00_tdagc_vld[i] == 1'b1 )begin
        r_pwr_cal_start_d02[i] <= 1'b1;
      end else begin
        r_pwr_cal_start_d02[i] <= 1'b0;
      end 
    end   
  end
end

always @ (posedge i_clk)begin // 
  if (w_ffttype == 0)begin
    if (w_d00_sym_tick)begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end else if (r_ts_cnt_in_sym_d01[i][11:9] == 3'b000 && w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i][8:0] == 9'd511)begin
      r_pwr_cal_end_d02[i] <= 1'b1;
    end else begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end
  end else if (w_ffttype == 1)begin
    if (w_d00_sym_tick)begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end else if (r_ts_cnt_in_sym_d01[i][11:9] == 3'b001 && w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i][8:0] == 9'd511)begin
      r_pwr_cal_end_d02[i] <= 1'b1;
    end else begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end  
  end else if (w_ffttype == 2)begin
    if (w_d00_sym_tick)begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end else if (r_ts_cnt_in_sym_d01[i][11:9] == 3'b011 && w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i][8:0] == 9'd511)begin
      r_pwr_cal_end_d02[i] <= 1'b1;
    end else begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end 
  end else if (w_ffttype == 3)begin
    if (w_d00_sym_tick)begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end else if (r_ts_cnt_in_sym_d01[i][11:9] == 3'b111 && w_d00_tdagc_vld[i] == 1'b1 && r_ts_cnt_in_sym_d01[i][8:0] == 9'd511)begin
      r_pwr_cal_end_d02[i] <= 1'b1;
    end else begin
      r_pwr_cal_end_d02[i] <= 1'b0;
    end 
  end else begin
      r_pwr_cal_end_d02[i] <= 1'b0;
  end
end  

always @ (posedge i_clk)begin
  r_pwr_cal_end_d02_0[i] <= r_pwr_cal_end_d02[i];
end

always @ (posedge i_clk)begin
  if (w_d01_sym_tick)begin
    r_pwr_cal_en_d02[i] <= 1'b0;
  end else if (r_pwr_cal_start_d02[i])begin
    r_pwr_cal_en_d02[i] <= 1'b1;
  end else if(r_pwr_cal_end_d02_0[i])begin
    r_pwr_cal_en_d02[i] <= 1'b0;
  end

end

always @ (posedge i_clk)begin
  r_pwr_cal_start_d03[i] <= r_pwr_cal_start_d02[i];
  r_pwr_cal_end_d03[i]   <= r_pwr_cal_end_d02[i];
end

  end
endgenerate


always @ (posedge i_clk)begin // lock index
  if (r_pwr_cal_end_d02_0[0])begin
    r_slt_idx_lock <= w_d02_slt_idx;
    r_sym_idx_lock <= w_d02_sym_idx;
    r_ro_idx_lock  <= w_d02_ro_idx;
  end
end 

//output
assign o_tdagc_vld    = w_d02_tdagc_vld;
assign o_tdagc_i      = w_d02_tdagc_i  ;
assign o_tdagc_q      = w_d02_tdagc_q  ;

assign o_frm_tick     = w_d02_frm_tick ;
assign o_slt_tick     = w_d02_slt_tick ;
assign o_slt_idx      = w_d02_slt_idx  ;
assign o_ro_tick      = w_d02_ro_tick  ;
assign o_ro_idx       = w_d02_ro_idx   ;
assign o_sym_tick     = w_d02_sym_tick ;
assign o_sym_idx      = w_d02_sym_idx  ;


for(i = 0; i < OVS; i = i + 1)begin
assign o_pwr_start[i]    = r_pwr_cal_start_d02[i];
assign o_pwr_end[i]      = r_pwr_cal_end_d02_0[i]  ;
assign o_pwr_en[i]       = r_pwr_cal_en_d02[i]   ;  
end  



assign o_slt_idx_lock = r_slt_idx_lock     ;
assign o_sym_idx_lock = r_sym_idx_lock     ;
assign o_ro_idx_lock  = r_ro_idx_lock      ;

endmodule
