// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU
//  Module       : urshf
//  Author       : 
//  Description  : lib for right shift, no saturation , no round
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.09 | Han Xiangdong |   Initial Release
//  ------------+---------------+-----------------------------------------------

module urshf  #
  (
   parameter IB          = 40                               
  ,parameter OB          = 31 
  ,parameter TB          = 4                              
  )
  (
   input                 clk       
  ,input                 reset     

  ,input                 i_din_vld  
  ,input  [TB-1:0 ]      i_rshf_n 
  ,input  [IB-1:0]       i_din     

  ,output                o_dout_vld
  ,output [OB-1:0]       o_dout    
  );

  reg                           r_din_vld              ;
  reg         [TB-1:0 ]         r_rshf_n               ; 
  reg  signed [IB-1:0]          r_din_i                ;
  wire signed [OB+2**TB-1:0]    w_ex_din               ;  
  reg         [OB-1:0]          r_trunc                ;
  reg                           r_din_vld_d00          ;

always @ (posedge clk)begin
    r_din_vld  <= i_din_vld;
    r_rshf_n   <= i_rshf_n;
    r_din_i    <= i_din;
end

always@(posedge clk)begin
  r_trunc <= r_din_i >>> r_rshf_n;
end 


always@(posedge clk)begin
  r_din_vld_d00 <= r_din_vld;
end   

assign o_dout_vld = r_din_vld_d00;
assign o_dout     = r_trunc;


endmodule
