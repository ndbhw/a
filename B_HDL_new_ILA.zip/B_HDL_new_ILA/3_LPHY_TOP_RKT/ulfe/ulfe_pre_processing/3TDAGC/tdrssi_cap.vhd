-- *****************************************************************************
--
-- CONFIDENTIAL AND SAMSUNG PROPRIETARY
--
-- NATIONAL CORE TECHNOLOGY INCLUDED
-- 
-- *****************************************************************************

--
--
--Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
--
-- Project      : NR MMU FPGA
-- Module       : puxch_sbif
-- Author       : Kim, Woo-yeon
-- Description  : TD RSSI Buffer
--
-- Revision History
-- ------------+---------------+-----------------------------------------------
--    Date     |   Author      |   Description
-- ------------+---------------+-----------------------------------------------
--  2020.02.28 | Kim, Woo-Yeon | Initial Release
-- ------------+---------------+-----------------------------------------------
--  2020.03.27 | Han Xiangdong | Modify tdrssi_vld and add o_tdrssi_vld output
-- ------------+---------------+-----------------------------------------------
--
--//////////////////////////////////////////////////////////////////////////////


library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use ieee.numeric_std.all;

-- library work;
-- use work.ARRAY_TYPE.all;
-- use work.RU_FPGA_FNC.all;
-- use work.BF_FPGA_CONFIG.all;



entity tdrssi_cap is
generic(
    AO                              : integer :=    5;
    TR                              : integer :=   32 
);
port(
    i_rst                           : in  std_logic                              ;
    i_clk                           : in  std_logic                              ;

    i_tdrssi_uls                    : in  std_logic                              ;
    i_tdrssi_vld                    : in  std_logic_vector((2**AO)* 1-1 downto 0);
    i_tdrssi                        : in  std_logic_vector((2**AO)*TR-1 downto 0);

    i_tdrssi_wr_rqst                : in  std_logic                              ;
    o_tdrssi_wr_done                : out std_logic                              ;

    i_tdrssi_rd_symidx              : in  std_logic_vector(         4-1 downto 0);
    i_tdrssi_rd_rqst                : in  std_logic                              ;
    o_tdrssi_vld                    : out std_logic                              ;
    o_tdrssi                        : out std_logic_vector((2**AO)*TR-1 downto 0)

);
end tdrssi_cap;

architecture arc_RTL of tdrssi_cap is

    component lib_sdpram is
    generic(
        AW                          : integer := 12       ;
        DW                          : integer := 72       ;
        NP                          : integer := 2        ;
        RAM_TYPE                    : string  := "distributed"
    );
    port(
        i_clk                       : in  std_logic;                       
        i_ena                       : in  std_logic;                       
        i_enb                       : in  std_logic;                       
        i_wea                       : in  std_logic;                       
        i_addra                     : in  std_logic_vector(AW-1 downto 0);
        i_addrb                     : in  std_logic_vector(AW-1 downto 0);
        i_dina                      : in  std_logic_vector(DW-1 downto 0);
        o_doutb                     : out std_logic_vector(DW-1 downto 0) 
    );
    end component;


    --component lib_sdpram_adv is
    --generic(
    --    AAW                         : integer := 12     ;
    --    ADW                         : integer := 12     ;
    --    BAW                         : integer := 12     ;
    --    BDW                         : integer := 12     ;
    --    NP                          : integer :=  3     ;
    --    RAM_TYPE                    : string  := "block" 
    --);
    --port(
    --    i_clk                       : in  std_logic;                       
    --    i_ena                       : in  std_logic;                       
    --    i_enb                       : in  std_logic;                       
    --    i_wea                       : in  std_logic;                       
    --    i_addra                     : in  std_logic_vector(AAW-1 downto 0);
    --    i_addrb                     : in  std_logic_vector(BAW-1 downto 0);
    --    i_dina                      : in  std_logic_vector(ADW-1 downto 0);
    --    o_doutb                     : out std_logic_vector(BDW-1 downto 0) 
    --);
    --end component;


    signal tdrssi_wr_rqst_sh        : std_logic_vector(         3-1 downto 0)     ;
    signal tdrssi_uls               : std_logic                                   ;
    signal tdrssi_vld               : std_logic                                   ;
    signal tdrssi                   : std_logic_vector((2**AO)*TR-1 downto 0)     ;
    signal tdrssi_vld_d             : std_logic                                   ;
    signal tdrssi_d                 : std_logic_vector((2**AO)*TR-1 downto 0)     ;
                                                                                  
    signal tdrssi_wr_rqst_lat       : std_logic                                   ;
    signal tdrssi_wr_vld            : std_logic                                   ;
    signal tdrssi_wr_done           : std_logic                                   ;
    signal tdrssi_wr_symcnt         : std_logic_vector(         4-1 downto 0)     ;
                                                                                  
    signal tdrssi_vld_sh            : std_logic_vector(        32-1 downto 0)     ;
    signal tdrssi_lat               : std_logic_vector((2**AO)*TR-1 downto 0)     ;
                                                                                  
    signal tdrssi_rd_rqst_sh        : std_logic_vector(         3-1 downto 0)     ;
    signal tdrssi_rd_rqst_r         : std_logic                                   ;
    signal tdrssi_rd_symidx         : std_logic_vector(         4-1 downto 0)     ; 
    signal tdrssi_rd                : std_logic_vector((2**AO)*TR-1 downto 0)     ; 
                                                                                  
    signal buf_a_wren               : std_logic                                   ; 
    signal buf_a_addr               : std_logic_vector(         4-1 downto 0)     ; 
    signal buf_a_data               : std_logic_vector((2**AO)*TR-1 downto 0)     ; 
                                                                                  
    signal buf_b_wren               : std_logic                                   ; 
    signal buf_b_addr               : std_logic_vector(         4-1 downto 0)     ; 
    signal buf_b_data               : std_logic_vector((2**AO)*TR-1 downto 0)     ; 
    signal buf_b_wren_shr           : std_logic_vector(7 downto 0)                ;

begin
    

    -- Ref Signal Gen
    process(i_rst,i_clk)
    begin
        if i_rst = '1' then
            tdrssi_wr_rqst_lat      <= '0';
            tdrssi_wr_vld           <= '0';
            tdrssi_wr_done          <= '0';
        
        elsif rising_edge(i_clk) then
            tdrssi_wr_rqst_sh       <= tdrssi_wr_rqst_sh(1 downto 0) & i_tdrssi_wr_rqst;
            tdrssi_uls              <= i_tdrssi_uls;
            if i_tdrssi_vld((2**AO)* 1-1) = '1' then
                tdrssi_vld <= '1';
            else
                tdrssi_vld <= '0'; 
            end if;
           --tdrssi_vld              <= i_tdrssi_vld( 0) or i_tdrssi_vld( 0+1) or i_tdrssi_vld( 0+2) or i_tdrssi_vld( 0+3) or   
           --                           i_tdrssi_vld( 4) or i_tdrssi_vld( 4+1) or i_tdrssi_vld( 4+2) or i_tdrssi_vld( 4+3) or   
           --                           i_tdrssi_vld( 8) or i_tdrssi_vld( 8+1) or i_tdrssi_vld( 8+2) or i_tdrssi_vld( 8+3) or   
           --                           i_tdrssi_vld(12) or i_tdrssi_vld(12+1) or i_tdrssi_vld(12+2) or i_tdrssi_vld(12+3) or   
           --                           i_tdrssi_vld(16) or i_tdrssi_vld(16+1) or i_tdrssi_vld(16+2) or i_tdrssi_vld(16+3) or   
           --                           i_tdrssi_vld(20) or i_tdrssi_vld(20+1) or i_tdrssi_vld(20+2) or i_tdrssi_vld(20+3) or   
           --                           i_tdrssi_vld(24) or i_tdrssi_vld(24+1) or i_tdrssi_vld(24+2) or i_tdrssi_vld(24+3) or   
           --                           i_tdrssi_vld(28) or i_tdrssi_vld(28+1) or i_tdrssi_vld(28+2) or i_tdrssi_vld(28+3);
            tdrssi                  <= i_tdrssi;
            
            tdrssi_vld_d            <= tdrssi_vld;
            tdrssi_d                <= tdrssi;
            
            -- TD RSSI Write Requst Latch
            if tdrssi_wr_rqst_sh(2 downto 1) = "01" then
                tdrssi_wr_rqst_lat  <= '1';
            elsif tdrssi_wr_done = '1' then
                tdrssi_wr_rqst_lat  <= '0';
            end if;
            
            
            -- TD RSSI Write Valid 
            if tdrssi_wr_rqst_lat = '1' then
                if tdrssi_uls = '1' then
                    tdrssi_wr_vld   <= '1';
                elsif tdrssi_wr_done = '1' then
                    tdrssi_wr_vld   <= '0';
                end if;
            end if;

            -- TD RSSI Measured Symbol 
            if tdrssi_uls = '1' then
                tdrssi_wr_symcnt        <= (others => '1');
            else
                if tdrssi_wr_vld = '1' then
                    if tdrssi_vld = '0' then
                        tdrssi_wr_symcnt<= tdrssi_wr_symcnt;
                    else
                        tdrssi_wr_symcnt<= tdrssi_wr_symcnt + '1';
                    end if;
                end if;
            end if;
        
            -- TD RSSI Write Done 
            if tdrssi_wr_rqst_sh(2 downto 1) = "01" then
                tdrssi_wr_done          <= '0';
            else
                if tdrssi_wr_symcnt = "1110" then
                    if tdrssi_vld = '0' then
                        tdrssi_wr_done  <= '0';
                    else
                        tdrssi_wr_done  <= '1';
                    end if;
                end if;
            end if;
        end if;
    end process;
    
    o_tdrssi_wr_done                <= tdrssi_wr_done;


    -- BUF Write Domain
    process(i_clk)
    begin
        if rising_edge(i_clk) then
            tdrssi_vld_sh           <= tdrssi_vld_sh(30 downto 0) & (tdrssi_vld_d and tdrssi_wr_vld);
            
            if (tdrssi_vld_d = '1') and (tdrssi_wr_vld = '1') then
                tdrssi_lat          <= tdrssi_d;
            else
                tdrssi_lat          <= tdrssi_lat;
            end if;

            buf_a_wren              <= tdrssi_vld_sh(31);
            buf_a_addr              <= tdrssi_wr_symcnt;
            buf_a_data              <= tdrssi_lat;
        end if;
    end process;

    -- BUF Read Domain
    process(i_clk)
    begin
        if rising_edge(i_clk) then
            tdrssi_rd_rqst_sh       <= tdrssi_rd_rqst_sh(1 downto 0) & i_tdrssi_rd_rqst;
            if tdrssi_rd_rqst_sh(2 downto 1) = "01" then
                tdrssi_rd_rqst_r    <= '1';
            else
                tdrssi_rd_rqst_r    <= '0';
            end if;
            tdrssi_rd_symidx        <= i_tdrssi_rd_symidx;


            buf_b_wren              <= tdrssi_rd_rqst_r;
            buf_b_addr              <= tdrssi_rd_symidx;
            tdrssi_rd               <= buf_b_data;
        end if;
    end process;
    
            
            
    U_TDRSSI_BUF : lib_sdpram
    generic map(
        AW                          =>          4                           , --: integer := 12       ;
        DW                          => (2**AO)*TR                           , --: integer := 72       ;
        NP                          =>          2                           , --: integer := 2        ;
        RAM_TYPE                    => "distributed"                          --: string  := "distributed"
    )
    port map(
        i_clk                       => i_clk                                , --: in  std_logic;                       
        i_ena                       => buf_a_wren                           , --: in  std_logic;                       
        i_enb                       => buf_b_wren                           , --: in  std_logic;                       
        i_wea                       => buf_a_wren                           , --: in  std_logic;                       
        i_addra                     => buf_a_addr                           , --: in  std_logic_vector(AW-1 downto 0);
        i_addrb                     => buf_b_addr                           , --: in  std_logic_vector(AW-1 downto 0);
        i_dina                      => buf_a_data                           , --: in  std_logic_vector(DW-1 downto 0);
        o_doutb                     => buf_b_data                             --: out std_logic_vector(DW-1 downto 0) 
    );
    
    process(i_clk)
    begin
        if rising_edge(i_clk) then
            buf_b_wren_shr       <= buf_b_wren_shr(6 downto 0) & buf_b_wren;
        end if;
    end process;

    o_tdrssi                        <= tdrssi_rd;
    o_tdrssi_vld                    <= buf_b_wren_shr(3);


end arc_RTL;
