// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR MMU FPGA
//  Module       : fft_4096
//  Author       : Song, Moon-Gun
//  Description  : fft 4096
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.29 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////
`include "ulfe_cc.vh"

module fft_blk
#( 
      parameter   IB                = 15
    , parameter   OB                = 15
    , parameter   OC                =  3                        // Overclocking Factor
    , parameter   VENDOR            = "Xilinx"
    , parameter   MAX_NFFT          = 2048
)
(
      input  wire                   i_clk                       // i_clk 
    , input  wire                   i_rst                       // Sync. Reset Active High

    , input  wire [   (2**OC)-1:0]  i_td_vld                    // Input Signal Enable
    , input  wire [   (2**OC)-1:0]  i_td_vld_pre1               // Input Signal Enable pre1
    , input  wire [        IB-1:0]  i_td_i                      // Inphase Input Signal
    , input  wire [        IB-1:0]  i_td_q                      // Quadrature Input Signal
    , input  wire [         1-1:0]  i_td_sym_tick               // ISS output Symbol tick pre5
    , input  wire [   (2**OC)-1:0]  i_fd_rqst                   // FFT Output Request
    , input  wire [   (2**OC)-1:0]  i_sc_vld                    // FFT Output vld Related to RB Size
    , input  wire [         9-1:0]  i_rb_size   
    , input  wire [        12-1:0]  i_k0   
    , input  wire [         2-1:0]  i_fft_sz_idx                // fft size
    , input  wire [         1-1:0]  i_fft_buf_in_vld_frm        // 
    , input  wire [         1-1:0]  i_fft_buf_in_vld_slt        // 
    , input  wire [         1-1:0]  i_fft_buf_out_vld_frm       // 
    , input  wire [         1-1:0]  i_fft_buf_out_vld_slt       // 

    , output wire [   (2**OC)-1:0]  o_fd_vld                    // Output Signal Enable
    , output wire [        OB-1:0]  o_fd_i                      // Inphase Output Signal
    , output wire [        OB-1:0]  o_fd_q                      // Quadrature Output Signal 
//    , output wire [         6-1:0]  o_fft_err_flag              // FFT IP Error Flag
//    , output wire [          31:0]  o_fft_latency 
);
localparam CSHFTD_SAT_LATENCY = 3'd2 ;
localparam FB                 = 16;
localparam FOB                = 32;
localparam AW                 = 12;
//localparam FRM_TICK_DELAY     = 2122/2/2;
wire [15:0] FRM_TICK_DELAY;

localparam BW_FFT_OUT         = 28;   
localparam FFT_DLY_RST        = 3;

//localparam AW                 = 13-OC;


reg                r_rst_1d     ;
reg                r_rst_2d     ;
reg                r_rst_3d     ;
reg                r_rst_4d     ;
reg                r_rst_5d     ;
reg                r_rst_6d     ;
reg                r_rst_7d     ;
reg                r_rst_8d     ;
reg                r_rst_9d     ;
reg                r_rst_10d    ;
reg                r_rst        ;
reg                r_xfft_rstn  ;
wire               w_rst        ;
reg                r_td_vld            ;
reg                r_td_vld_pre1       ;
reg                r_td_last           ;
reg  [     FB-1:0] r_td_i              ;
reg  [     FB-1:0] r_td_q              ;
reg  [      5-1:0] r_fft_idx           ;
reg  [     13-1:0] r_fftpts            ;
reg  [     10-1:0] r_scale_idx         ;



wire [    16-1: 0]  w_s_axis_config_tdata        = {7'b0, 1'b1, 3'b0, r_fft_idx}; 
wire                w_s_axis_config_tvalid       = r_td_vld;   

//wire [    8-1: 0] w_s_axis_config_tdata        = 0;      
//wire              w_s_axis_config_tvalid       = 0;   
wire                w_s_axis_config_tready               ; 

wire [   2*FB-1: 0] w_s_axis_data_tdata          = {r_td_q,r_td_i};    
wire                w_s_axis_data_tvalid         = r_td_vld;   
wire                w_s_axis_data_tready                  ;    
wire                w_s_axis_data_tlast          = r_td_last; 
  
wire [  2*FOB-1: 0] w_m_axis_data_tdata          ;    
wire [BW_FFT_OUT-1:0]  w_fft_out_i   ;
wire [BW_FFT_OUT-1:0]  w_fft_out_q   ;  

wire                w_m_axis_data_tvalid         ;         
wire                w_m_axis_data_tready         = 1'b1;  
wire [     16-1: 0] w_m_axis_data_tuser          ;        
wire                w_m_axis_data_tlast          ;
            
wire                w_event_frame_started        ;      
wire                w_event_tlast_unexpected     ;        
wire                w_event_tlast_missing        ;   
wire                w_event_status_channel_halt  ;    
wire                w_event_data_in_channel_halt ;     
wire                w_event_data_out_channel_halt; 
wire [1:0]          w_ifft_out_err ;
reg  [0:0]          r_ifft_rstn [FFT_DLY_RST-1:0]   ;

wire                w_fft_smult_vld              ; 
wire [FOB-5+10-1:0] w_fft_smult_i                ; 
wire [FOB-5+10-1:0] w_fft_smult_q                ; 

wire                w_xfft_sat_last              ;
wire                w_xfft_sat_vld               ;
wire [     OB-1:0]  w_xfft_sat_i                 ;
wire [     OB-1:0]  w_xfft_sat_q                 ;

wire [   2**OC-1:0] w_xfft_out_vld               ;
wire [      OB-1:0] w_xfft_out_i                 ;
wire [      OB-1:0] w_xfft_out_q                 ;

wire [   2**OC-1:0] w_buf_out_vld                ;
wire [        OB:0] w_buf_out_i                  ;
wire [        OB:0] w_buf_out_q                  ; 

wire [   2**OC-1:0] w_fd_vld                     ;
wire [   2**OC-1:0] w6_fd_vld                    ;
wire [      OB-1:0] w_fd_i                       ;
wire [      OB-1:0] w_fd_q                       ; 

wire [ (2**OC)-1:0] w_fd_rqst                    ;


reg  [       1-1:0] r_fft_frame_err              ;
reg  [       8-1:0] r_unstable_sym_cnt           ;
reg  [       1-1:0] r_fft_flusing                ;
reg  [       1-1:0] r_fft_flusing2               ;
reg f_norm_sym_chk1  ;
reg f_norm_sym_chk2  ;
reg f_norm_out  ;


//assign o_fft_latency = 19719;

wire [1:0] r_fft_sz_idx;
//ylib_reg #(.WIDTH(2), .DEPTH(1)) sync_fftType (.i_clk(i_clk),.i_in(i_fft_sz_idx),.i_en(i_fft_buf_in_vld_frm),.o_out(r_fft_sz_idx));
ylib_reg #(.WIDTH(2), .DEPTH(1)) sync_fftType (.i_clk(i_clk),.i_in(i_fft_sz_idx),.o_out(r_fft_sz_idx));

always @ (posedge i_clk) begin
    r_rst_1d                        <= i_rst;
    r_rst_2d                        <= r_rst_1d;
    r_rst_3d                        <= r_rst_2d;
    r_rst_4d                        <= r_rst_3d;
    r_rst_5d                        <= r_rst_4d;
    r_rst_6d                        <= r_rst_5d;
    r_rst_7d                        <= r_rst_6d;
    r_rst_8d                        <= r_rst_7d;
    r_rst_9d                        <= r_rst_8d;
    r_rst_10d                       <= r_rst_9d;
    r_rst                           <= r_rst_10d | r_rst_9d | r_rst_8d | r_rst_7d | r_rst_6d | r_rst_5d | r_rst_4d | r_rst_3d;
    r_xfft_rstn                     <= ~(r_rst_10d | r_rst_9d | r_rst_8d | r_rst_7d | r_rst_6d | r_rst_5d | r_rst_4d | r_rst_3d);
end
assign w_rst = r_rst;

always @ (posedge i_clk ) begin
    if(i_rst) begin
        r_td_vld                    <= 1'b0;
        r_td_vld_pre1               <= 1'b0;
        r_td_last                   <= 1'b0;
    end
    else begin
        if (r_fft_flusing == 1'b0) begin
            r_td_vld                <= |(i_td_vld);
            r_td_vld_pre1           <= |(i_td_vld_pre1);
            r_td_last               <= (r_td_vld_pre1) & (~(|(i_td_vld_pre1)));
        end
        else begin
            r_td_vld                <= 1'b0; 
            r_td_last               <= 1'b0; 
        end
    end
end

reg           r_td_vld_d1     ;
reg           r_td_vld_d2     ;
reg           r_td_vld_rs     ;
reg  [13-1:0] r_fft_stable_cnt;
always @ (posedge i_clk ) begin
    if(i_rst) begin
        r_td_vld_d1                 <= 1'b0;
        r_td_vld_d2                 <= 1'b0;
        r_td_vld_rs                 <= 1'b0;
        
        r_fft_stable_cnt            <= 13'd0;
    end
    else begin
        r_td_vld_d1                 <= |(i_td_vld);
        r_td_vld_d2                 <= r_td_vld_d1;
        if (r_td_vld_d1 == 1'b1 && r_td_vld_d2 == 1'b0 ) begin
            r_td_vld_rs             <= 1'b1;
        end
        else begin
            r_td_vld_rs             <= 1'b0;
        end

        if (r_td_vld_rs) begin
            r_fft_stable_cnt        <= 0;
        end
        else begin
            r_fft_stable_cnt        <= r_fft_stable_cnt + 1;
        end
    end
end


always @ (posedge i_clk ) begin
    if(i_rst) begin
        r_td_i                      <= 0;
        r_td_q                      <= 0;
    end
    else begin
        if (r_fft_flusing == 1'b0) begin
            r_td_i                  <= {{(FB-IB){i_td_i[IB-1]}},i_td_i};
            r_td_q                  <= {{(FB-IB){i_td_q[IB-1]}},i_td_q};
        end
        else begin
            r_td_i                  <= 0;
            r_td_q                  <= 0;
        end
    end
end

always @ (posedge i_clk) begin
    case(r_fft_sz_idx)
        2'b00   :   
        begin
            r_fft_idx       <= 5'b01001; // 5'd 9 
            r_fftpts        <= 13'd512;
        end 
        2'b01   :   
        begin
            r_fft_idx       <= 5'b01010; // 5'd10
            r_fftpts        <= 13'd1024;
        end
        2'b10   :   
        begin
            r_fft_idx       <= 5'b01011; // 5'd11
            r_fftpts        <= 13'd2048;
        end
        2'b11   :   
        begin
            r_fft_idx       <= 5'b01100; // 5'd12
            r_fftpts        <= 13'd4096;
        end
        default :   
        begin
            r_fft_idx       <= 5'b01100; // 5'd12
            r_fftpts        <= 13'd4096;            
        end
    endcase
end
assign FRM_TICK_DELAY     = (16'd4096+16'd128)>>(2'b11-r_fft_sz_idx);

always @ (posedge i_clk) begin
    case(r_fft_sz_idx)
        2'b00   :   r_scale_idx     <= 10'd362;
        2'b01   :   r_scale_idx     <= 10'd256;
        2'b10   :   r_scale_idx     <= 10'd181;
        2'b11   :   r_scale_idx     <= 10'd128;
        default :   r_scale_idx     <= 10'd128;
    endcase
end

reg r_ifft_recfg;
always@(posedge i_clk) begin
        r_ifft_recfg <= i_fft_sz_idx != r_fft_sz_idx ;
    end

integer i;
always@(posedge i_clk) begin
    r_ifft_rstn[0] <=  ~(r_rst|(|w_ifft_out_err))  ;
    for(i=1;i<FFT_DLY_RST;i=i+1) begin
        r_ifft_rstn[i] <=  r_ifft_rstn[i-1] ;
    end
end

wire w_ifft_rstn;
assign w_ifft_rstn = r_ifft_rstn[FFT_DLY_RST-2]&r_ifft_rstn[FFT_DLY_RST-1]  ;

reg [1-1:0] r_shift_a_sat_en    ;
always@(posedge i_clk) begin
    r_shift_a_sat_en    <=  w_s_axis_config_tvalid    ;
end

ylib_vfft_wrapper #(
    .MAX_NFFT(MAX_NFFT)
`ifdef Custom_FFT
    ,.VENDOR("Custom")  //Intel , Xilinx
`else
    ,.VENDOR(VENDOR)  //Intel , Xilinx
`endif
) ylib_vfft_wrapper_instance (
    .clk(i_clk),
    .reset_n(w_ifft_rstn),//(r_xfft_rstn )),//& (~r_fft_flusing2))),// & w_ifft_rstn ),
    
    .sink_valid(w_s_axis_data_tvalid),
    .sink_ready(sink_ready),
    .sink_error(),
    .sink_sop(w_s_axis_config_tvalid & ~r_shift_a_sat_en),
    .sink_eop(w_s_axis_data_tlast),
    .sink_real(w_s_axis_data_tdata[FB-1:0]),
    .sink_imag(w_s_axis_data_tdata[2*FB-1:FB]),
    .fftpts_in(r_fftpts[$clog2(MAX_NFFT):0]),

    .inverse(1'b0),

    .source_valid(w_m_axis_data_tvalid),
    .source_ready(w_m_axis_data_tready),
    .source_error(w_ifft_out_err),
    .source_sop(w_event_frame_started),
    .source_eop(w_m_axis_data_tlast),
    .source_real(w_fft_out_i),
    .source_imag(w_fft_out_q),
.fftpts_out()
);

wire                                w_xfft_out_en   ;   
wire [$clog2(MAX_NFFT)-1:0]         w_xfft_out_idx  ; 


ylib_xfft_order_gen #(
    .MAX_NFFT(MAX_NFFT)
) ylib_xfft_order_gen_instance (
    .i_clk(i_clk),
    .i_xfft_size(r_fft_idx[3:0]),
    .i_xfft_out_en(w_m_axis_data_tvalid),
    .o_xfft_out_en(w_xfft_out_en),
    .o_xfft_out_idx(w_xfft_out_idx)
);
    
//xfft_cnfg u00_xfft_cnfg
//(
//     .aclk                           ( i_clk                                )  
//    ,.aresetn                        ( (r_xfft_rstn & (~r_fft_flusing2))    )  
//    
//    ,.s_axis_config_tdata            ( w_s_axis_config_tdata                )  
//    ,.s_axis_config_tvalid           ( w_s_axis_config_tvalid               )  
//    ,.s_axis_config_tready           ( w_s_axis_config_tready               )  
//    
//    ,.s_axis_data_tdata              ( w_s_axis_data_tdata                  )  
//    ,.s_axis_data_tvalid             ( w_s_axis_data_tvalid                 )  
//    ,.s_axis_data_tready             ( w_s_axis_data_tready                 )  
//    ,.s_axis_data_tlast              ( w_s_axis_data_tlast                  )  
//    
//    ,.m_axis_data_tdata              ( w_m_axis_data_tdata                  )  
//    ,.m_axis_data_tvalid             ( w_m_axis_data_tvalid                 )  
//    ,.m_axis_data_tready             ( w_m_axis_data_tready                 )  
//    ,.m_axis_data_tuser              ( w_m_axis_data_tuser                  )
//    ,.m_axis_data_tlast              ( w_m_axis_data_tlast                  ) 
//    
//    ,.event_frame_started            ( w_event_frame_started                )  // after 6clocks 
//    ,.event_tlast_unexpected         ( w_event_tlast_unexpected             )  
//    ,.event_tlast_missing            ( w_event_tlast_missing                )  
//    ,.event_status_channel_halt      ( w_event_status_channel_halt          )  
//    ,.event_data_in_channel_halt     ( w_event_data_in_channel_halt         )  
//    ,.event_data_out_channel_halt    ( w_event_data_out_channel_halt        )  
//);



ylib_pshift #(
    .BW_SHIFT($clog2(CSHFTD_SAT_LATENCY+3'd2+3'd1))
) u01_lib_shr (
    .i_clk(i_clk),
    .i_shift((CSHFTD_SAT_LATENCY+3'd2)),
    .i_in(w_m_axis_data_tlast),
    .o_out(w_xfft_sat_last)
);


ylib_fxp_smult#(.XB(FOB-5), .YB(10)) u03_lib_fxp_smult
(
     .i_clk                         ( i_clk                                 ) // CLK 
    ,.i_rst                         ( i_rst                                 ) // Async. Reset Active High
    
    ,.i_vld                         ( w_m_axis_data_tvalid                  ) // Input Valid
    ,.i_x                           ( {w_fft_out_i[26:0]}          )//w_m_axis_data_tdata[  (FOB-5)-1:  0]  ) // Input X
    ,.i_y                           ( r_scale_idx                           ) // Input Y

    ,.o_vld                         ( w_fft_smult_vld                       ) // Output Valid
    ,.o_z                           ( w_fft_smult_i                         ) // Ouput
);


ylib_fxp_smult#(.XB(FOB-5), .YB(10)) u04_lib_fxp_smult
(
     .i_clk                         ( i_clk                                 ) // CLK 
    ,.i_rst                         ( i_rst                                 ) // Async. Reset Active High
    
    ,.i_vld                         ( w_m_axis_data_tvalid                  ) // Input Valid
    ,.i_x                           ( {w_fft_out_q[26:0]}          )//w_m_axis_data_tdata[(2*FOB-5)-1:FOB]  ) // Input X
    ,.i_y                           ( r_scale_idx                           ) // Input Y

    ,.o_vld                         (                                       ) // Output Valid
    ,.o_z                           ( w_fft_smult_q                         ) // Ouput
);

ylib_cshftd_sat #(.IB(FOB-5+10), .SF(13), .OB(OB)) u01_lib_cshftd_sat
(
     .i_clk                         ( i_clk                                )  // Clock 
    ,.i_rst                         ( w_rst                                )  // Reset
    
    ,.i_din_vld                     ( w_fft_smult_vld                      ) 
    ,.i_din_i                       ( w_fft_smult_i                        ) 
    ,.i_din_q                       ( w_fft_smult_q                        ) 

    ,.o_dout_vld                    ( w_xfft_sat_vld                       ) 
    ,.o_dout_i                      ( w_xfft_sat_i                         ) 
    ,.o_dout_q                      ( w_xfft_sat_q                         ) 
);

reg  [2**OC-1:0] r_out_sel      ;
reg  [2**OC-1:0] rr_out_sel     ;
reg  [2**OC-1:0] r_td_vld_outsel;
reg  [2**OC-1:0] r_td_vld_sync  ;
wire             w_shift_td_vld_rs    ;

ylib_pshift #(
    .BW_SHIFT(7)
) ylib_pshift_instance (
    .i_clk(i_clk),
    .i_shift(7'd100),
    .i_in(r_td_vld_rs),
    .o_out(w_shift_td_vld_rs)
);


always @ (posedge i_clk) begin
  if(w_shift_td_vld_rs) begin
    r_td_vld_sync <= i_td_vld;
  end
end

reg r_td_sym_flag;
reg r_outsel_init_flag;
reg r_m_axis_data_tvalid;

always @(posedge i_clk)
begin
    r_m_axis_data_tvalid    <=  w_m_axis_data_tvalid;      
end

always @(posedge i_clk)
begin
    if(i_td_sym_tick)
    begin
        r_td_sym_flag       <= 1'b1;
        r_outsel_init_flag  <= 1'b0;
    end
    else if(r_td_sym_flag & (w_m_axis_data_tvalid==1'b1 && r_m_axis_data_tvalid==1'b0))
    begin
        r_td_sym_flag       <= 1'b0;
        r_outsel_init_flag  <= 1'b1;
    end
    else
    begin
        r_td_sym_flag       <= r_td_sym_flag;
        r_outsel_init_flag  <= 1'b0;
    end
end

always @ (posedge i_clk) 
begin
    if(r_outsel_init_flag)//i_td_sym_tick ) 
    begin//| i_td_sym_tick) begin
        r_out_sel <= {{(2**OC-1){1'b0}},1'b1} ;
//        if(r_out_sel == {1'b1,{(2**OC-1){1'b0}}})
//            r_out_sel <= r_out_sel ;
//        else
//            r_out_sel <= i_td_vld_pre1;
    end
    else 
    begin
        if(w_xfft_sat_last & (r_td_vld_sync==r_out_sel)) 
        begin
            //r_out_sel <= {r_out_sel[2**OC-2:0], r_out_sel[2**OC-1]};
            r_out_sel <= {{(2**OC-1){1'b0}},1'b1} ;
        end
        else if (w_xfft_sat_last) 
        begin
            r_out_sel <= r_td_vld_sync;
        end
        else
        begin
            r_out_sel <= r_out_sel;
        end    
    end
            rr_out_sel   <= r_out_sel;
end

ylib_reg #(.WIDTH(2**OC) ,.DEPTH(1) ) u02_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( rr_out_sel & {(2**OC){w_xfft_sat_vld}}                   )
    ,.o_out                         ( w_xfft_out_vld                                          )  
);

ylib_reg #(.WIDTH(OB),.DEPTH(1)) u03_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( w_xfft_sat_i                                            )
    ,.o_out                         ( w_xfft_out_i                                            )  
);

ylib_reg #(.WIDTH(OB),.DEPTH(1)) u04_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( w_xfft_sat_q                                            )
    ,.o_out                         ( w_xfft_out_q                                            )  
);

 (* keep_hierarchy="yes" *)ylib_reg #(.WIDTH((2**OC)),.DEPTH(1)) u05_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( i_fd_rqst                                               )
    ,.o_out                         ( w_fd_rqst                                               )  
);

reg   [       15 : 0]     r_frm_delay_cnt  ;
reg   [       15 : 0]     r_slot_delay_cnt ;
reg                       r1_frm_tick      ;
reg                       r1_slt_tick      ;

always @(posedge i_clk) begin
  if(i_fft_buf_in_vld_frm) begin //resync
  	r_frm_delay_cnt <= 0;
  end
  else if(r_frm_delay_cnt<(FRM_TICK_DELAY+1'b1)) begin //for LTE 2048fft
  	r_frm_delay_cnt <= r_frm_delay_cnt+1'b1;
  end
end

always @(posedge i_clk) begin
  if(i_fft_buf_in_vld_slt) begin //resync
  	r_slot_delay_cnt <= 0;
  end
  else if(r_slot_delay_cnt<(FRM_TICK_DELAY+1'b1)) begin //for LTE 2048fft
  	r_slot_delay_cnt <= r_slot_delay_cnt+1'b1;
  end
end

always @(posedge i_clk) begin
  if(r_frm_delay_cnt==FRM_TICK_DELAY) begin //resync
  	r1_frm_tick <= 1'b1;
  end
  else begin
  	r1_frm_tick <= 1'b0;
  end
end

always @(posedge i_clk) begin
  if(r_slot_delay_cnt==FRM_TICK_DELAY) begin //resync
  	r1_slt_tick <= 1'b1;
  end
  else begin
  	r1_slt_tick <= 1'b0;
  end
end

wire                        r2_frm_tick,r2_slt_tick;
wire [   2**OC-1:0]         r_xfft_out_vld ;
wire [$clog2(MAX_NFFT)-1:0] r_xfft_out_idx ; 

ylib_reg #(.WIDTH(1+1+$clog2(MAX_NFFT)),.DEPTH(1)) u_ulfe_br_s2p_ntrl_demap_in
(
     .i_clk                         ( i_clk                                                   )   
    ,.i_in                          ( {r1_frm_tick,r1_slt_tick,w_xfft_out_idx})
    ,.o_out                         ( {r2_frm_tick,r2_slt_tick,r_xfft_out_idx}                                                )  
);


ulfe_br_s2p_ntrl_demap #(.BW(32), .OC(OC), .NP(5), .EB(1), .AW(AW), .VENDOR(VENDOR)) ulfe_br_s2p_ntrl
(
     .i_clk                         ( i_clk                                                   )  // Clock 
    ,.i_rst                         ( w_rst                                                   )  // Reset
     
    ,.i_rb_size                     ( i_rb_size                                               )   
    ,.i_k0                          ( i_k0                                                    )
    ,.i_fft_sz_idx                  ( r_fft_sz_idx                                            )                             
    ,.i_din_vld_frm                 ( r2_frm_tick                                             )  //             
    ,.i_din_vld_slt                 ( r2_slt_tick                                             )  //             
    ,.i_din_vld                     ( w_xfft_out_vld                                          )  // Input Enable
    ,.i_din                         ( {1'b0,w_xfft_out_q,1'b0,w_xfft_out_i}                   )  // Write Enable
    ,.i_din_tuser                   ( {{{16-$clog2(MAX_NFFT)}{1'd0}}, r_xfft_out_idx}                 )//w_m_axis_data_tuser                                     )
    ,.i_dout_rqt                    ( w_fd_rqst                                               )  // Output Request
    ,.i_dout_rqt_frm                ( i_fft_buf_out_vld_frm                                   )  //             
    ,.i_dout_rqt_slt                ( i_fft_buf_out_vld_slt                                   )  //             
	,.i_abnormal_input    			(  i_td_sym_tick & f_norm_sym_chk1			)
	
	,.o_dout_vld                    ( w_buf_out_vld                                           )  // Output Signal Enalbe
    ,.o_dout                        ( {w_buf_out_q,w_buf_out_i}                               )  // Output Signal        
);

ylib_reg #(.WIDTH(2**OC) ,.DEPTH(1)) u07_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
`ifndef ulfe_fdd
    ,.i_in                          ( i_sc_vld & {2**OC{f_norm_out}}                          )
`else
    ,.i_in                          ( i_sc_vld )//& {2**OC{f_norm_out}}                          )
`endif
    ,.o_out                         ( w_fd_vld                                                )  
);


ylib_reg #(.WIDTH(2**OC),.DEPTH(6)) u080_lib_reg (.i_clk(i_clk),.i_in(w_fd_vld),.o_out(w6_fd_vld));
ylib_reg #(.WIDTH(2**OC),.DEPTH(7)) u08_lib_reg (.i_clk(i_clk),.i_in(w_fd_vld),.o_out(o_fd_vld));


ylib_reg #(.WIDTH(OB) ,.DEPTH(1)) u09_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( (|w6_fd_vld) ? w_buf_out_i[OB-1:0]  : {OB{1'b0}}        )
    ,.o_out                         ( o_fd_i                                                  )  
);

ylib_reg #(.WIDTH(OB),.DEPTH(1)) u10_lib_reg
(
     .i_clk                         ( i_clk                                                   )   
//    ,.i_rst                         ( w_rst                                                   )  
//    ,.i_en                          ( 1'b1                                                    )
    ,.i_in                          ( (|w6_fd_vld) ? w_buf_out_q[OB-1:0]  : {OB{1'b0}}        )
    ,.o_out                         ( o_fd_q                                                  )  
);

always @ (posedge i_clk ) begin
    if(i_rst) begin
            r_fft_frame_err         <= 1'b0;
            r_unstable_sym_cnt      <= 8'd0;
            r_fft_flusing           <= 1'b0;
    end
    else begin
        // frame error detection
        if (w_event_frame_started) begin
            if (r_fft_stable_cnt == 13'd4) begin
                r_fft_frame_err     <= 1'b0;
            end
            else begin
                r_fft_frame_err     <= 1'b1;
            end
        end
        else begin
            if (r_unstable_sym_cnt == 8'd10) begin
                r_fft_frame_err     <= 1'b0;
            end
        end

        // symbol counter since frame_err occur
        if (r_fft_frame_err) begin
            if (i_td_sym_tick) begin
                r_unstable_sym_cnt  <= r_unstable_sym_cnt + 1;
            end
        end
        else begin
            if (i_td_sym_tick) begin
                r_unstable_sym_cnt  <= 8'd0;
            end
        end

        // unstable flushing signal
        if (r_unstable_sym_cnt == 8'd0) begin
            r_fft_flusing           <= 1'b0;
        end
        else begin
            r_fft_flusing           <= 1'b0;//1'b1
        end
        
        if ((r_unstable_sym_cnt == 8'd0) || (r_unstable_sym_cnt == 8'd10)) begin
            r_fft_flusing2          <= 1'b0;
        end
        else begin
            r_fft_flusing2          <= 1'b0;//1'b1
        end
    end
end




//wire [6-1:0] w_fft_err_flag;
//assign w_fft_err_flag = {w_event_frame_started        ,
//                         w_event_tlast_unexpected     ,
//                         w_event_tlast_missing        ,
//                         w_event_status_channel_halt  ,
//                         w_event_data_in_channel_halt ,
//                         w_event_data_out_channel_halt};
//


always @(posedge i_clk)
begin
    if(i_td_sym_tick && ~(|i_td_vld))
    begin
        f_norm_sym_chk1 <= 1'b1;
    end
    else if(|(i_td_vld))
    begin
        f_norm_sym_chk1 <= 1'b0;
    end
    else
    begin
        f_norm_sym_chk1 <= f_norm_sym_chk1;
    end    
end
    
always @(posedge i_clk)
begin
    if(i_td_sym_tick && f_norm_sym_chk1)
    begin
        f_norm_sym_chk2 <= 1'b1;
    end
    else if((i_td_sym_tick && ~f_norm_sym_chk1))
    begin
        f_norm_sym_chk2 <= 1'b0;
    end
    else
    begin
        f_norm_sym_chk2 <= f_norm_sym_chk2;
    end    
end

always @(posedge i_clk)
begin    
    if(f_norm_sym_chk2 && (i_fd_rqst==0))
        f_norm_out <= 1'b0;
    else if(!f_norm_sym_chk2)
        f_norm_out <= 1'b1;
    else
        f_norm_out <= f_norm_out;
end    
    

endmodule

