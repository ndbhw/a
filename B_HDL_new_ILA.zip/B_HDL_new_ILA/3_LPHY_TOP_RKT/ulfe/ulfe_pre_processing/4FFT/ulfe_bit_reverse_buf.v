// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date:
// Design Name: 
// Module Name: tagc_buf
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
//

//  Xilinx UltraRAM True Dual Port Mode - Byte write.  This code implements 
//  a parameterizable UltraRAM block with write/read on both ports in 
//  No change behavior on both the ports . The behavior of this RAM is 
//  when data is written, the output of RAM is unchanged w.r.t each port. 
//  Only when write is inactive data corresponding to the address is 
//  presented on the output port.
//
module ulfe_bit_reverse_buf #(
  parameter AWIDTH  = 12,  // Address Width
  parameter NUM_COL = 9,   // Number of columns
  parameter DWIDTH  = 72,  // Data Width, (Byte * NUM_COL) 
  parameter NBPIPE  = 3 ,  // Number of pipeline Registers
  parameter RAM_TYPE = "ultra" // Memory Type: "block" or "distributed" or "ultra" 
 ) ( 
    input clk,                    // Clock
    // Port A
    input rsta,                   // Reset
    input [NUM_COL-1:0] wea,      // Write Enable
    input regcea,                 // Output Register Enable
    input mem_ena,                // Memory Enable
    input [DWIDTH-1:0] dina,      // Data Input  
    input [AWIDTH-1:0] addra,     // Address Input
    output reg [DWIDTH-1:0] douta,// Data Output

    // Port B
    input rstb,                   // Reset
    input [NUM_COL-1:0] web,      // Write Enable
    input regceb,                 // Output Register Enable
    input mem_enb,                // Memory Enable
    input [DWIDTH-1:0] dinb,      // Data Input  
    input [AWIDTH-1:0] addrb,     // Address Input
    output reg [DWIDTH-1:0] doutb // Data Output
   );

(* ram_style = RAM_TYPE *)
reg [DWIDTH-1:0] mem[(1<<AWIDTH)-1:0];        // Memory Declaration

reg [DWIDTH-1:0] memrega;              
reg [DWIDTH-1:0] mem_pipe_rega[NBPIPE-1:0];    // Pipelines for memory
reg mem_en_pipe_rega[NBPIPE:0];                // Pipelines for memory enable  

reg [DWIDTH-1:0] memregb;              
reg [DWIDTH-1:0] mem_pipe_regb[NBPIPE-1:0];    // Pipelines for memory
reg mem_en_pipe_regb[NBPIPE:0];                // Pipelines for memory enable  

integer          i;
localparam CWIDTH = DWIDTH/NUM_COL;

// RAM : Read has one latency, Write has one latency as well.
always @ (posedge clk)
begin
 if(mem_ena) 
  begin
  for(i = 0;i<NUM_COL;i=i+1) 
   if(wea[i])
    mem[addra][i*CWIDTH +: CWIDTH] <= dina[i*CWIDTH +: CWIDTH];
  end     
end

always @ (posedge clk)
begin
 if(mem_ena)
  if(~|wea)
    memrega <= mem[addra];
end

// The enable of the RAM goes through a pipeline to produce a
// series of pipelined enable signals required to control the data
// pipeline.
always @ (posedge clk)
begin
mem_en_pipe_rega[0] <= mem_ena;
 for (i=0; i<NBPIPE; i=i+1)
  mem_en_pipe_rega[i+1] <= mem_en_pipe_rega[i];
end

// RAM output data goes through a pipeline.
always @ (posedge clk)
begin
 if (mem_en_pipe_rega[0])
  mem_pipe_rega[0] <= memrega;
end

always @ (posedge clk)
begin
 for (i = 0; i < NBPIPE-1; i = i+1)
  if (mem_en_pipe_rega[i+1])
    mem_pipe_rega[i+1] <= mem_pipe_rega[i];
end

// Final output register gives user the option to add a reset and
// an additional enable signal just for the data ouptut
always @ (posedge clk)
begin
 if (rsta)
  douta <= 0;
 else if (mem_en_pipe_rega[NBPIPE] && regcea)
  douta <= mem_pipe_rega[NBPIPE-1];
end 

// RAM : Read has one latency, Write has one latency as well.
always @ (posedge clk)
begin
 if(mem_enb) 
  begin
  for(i=0;i<NUM_COL;i=i+1)
   if(web[i])
    mem[addrb][i*CWIDTH +: CWIDTH] <= dinb[i*CWIDTH +: CWIDTH];
  end     
end

always @ (posedge clk)
begin
 if(mem_enb)
  if(~|web)
    memregb <= mem[addrb];
end

// The enable of the RAM goes through a pipeline to produce a
// series of pipelined enable signals required to control the data
// pipeline.
always @ (posedge clk)
begin
mem_en_pipe_regb[0] <= mem_enb;
 for (i=0; i<NBPIPE; i=i+1)
  mem_en_pipe_regb[i+1] <= mem_en_pipe_regb[i];
end

// RAM output data goes through a pipeline.
always @ (posedge clk)
begin
 if (mem_en_pipe_regb[0])
  mem_pipe_regb[0] <= memregb;
end

always @ (posedge clk)
begin
 for (i = 0; i < NBPIPE-1; i = i+1)
  if (mem_en_pipe_regb[i+1])
    mem_pipe_regb[i+1] <= mem_pipe_regb[i];
end

// Final output register gives user the option to add a reset and
// an additional enable signal just for the data ouptut
always @ (posedge clk)
begin
 if (rsta)
  doutb <= 0;
 else if (mem_en_pipe_regb[NBPIPE] && regceb)
  doutb <= mem_pipe_regb[NBPIPE-1];
end 

endmodule
                                       
            
            