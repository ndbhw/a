// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

 ////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : lib_br_s2p_ntrl_4096
//  Author       : Song, Moon-Gun
//  Description  : Bit-Reverse Order Serial Input to Natural Parallel Output
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.01.29 |Kim, Woo-Yeon  | Update Buffer Control Resync
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

 
module ulfe_br_s2p_ntrl_demap
#(
      parameter BW                  = 32                // BW <= 36
    , parameter OC                  = 1                 // 
    , parameter NP                  = 5                 //
    , parameter EB                  = 1                 // 2^EB = number of buffer
    , parameter AW                  = 12
    , parameter VENDOR              = "Xilinx" 
    , parameter RAM_TYPE            = "ultra"           // Memory Type: "block" or "distributed" or "ultra" 
) (
      input  wire                       i_clk               // Clock 
    , input  wire                       i_rst               // Reset

    , input  wire [             9-1:0]  i_rb_size   
    , input  wire [            12-1:0]  i_k0   
    , input  wire [             2-1:0]  i_fft_sz_idx        
    , input  wire [             1-1:0]  i_din_vld_frm       // Input Enable
    , input  wire [             1-1:0]  i_din_vld_slt       // Input Enable
    , input  wire [       (2**OC)-1:0]  i_din_vld           // Input Enable
    , input  wire [            BW-1:0]  i_din               // Write Enable
    , input  wire [            16-1:0]  i_din_tuser
    , input  wire [       (2**OC)-1:0]  i_dout_rqt          // Output Request
    , input  wire [             1-1:0]  i_dout_rqt_frm      // Input Enable
    , input  wire [             1-1:0]  i_dout_rqt_slt      // Input Enable
	, input wire		i_abnormal_input

    , output reg  [       (2**OC)-1:0]  o_dout_vld          // Output Signal Enalbe
    , output reg  [            BW-1:0]  o_dout              // Output Signal        
);
integer i, j, r;
genvar  k, l, m;
integer kk;

reg  [      1-1:0] r_din_en_frm                  ; 
reg  [      1-1:0] r_din_en_slt                  ; 
reg  [      1-1:0] r_din_ref                     ;
reg  [      1-1:0] r_din_ref_d1                  ;
reg  [      1-1:0] r_din_ref_rs                  ;

reg  [      1-1:0] r_dout_rqt_frm                ;
reg  [      1-1:0] r_dout_rqt_slt                ;
reg  [      1-1:0] r_dout_ref                    ; 
reg  [      1-1:0] r_dout_ref_d1                 ; 
reg  [      1-1:0] r_dout_ref_rs                 ; 

reg  [   BW*2-1:0] r_in_data        [(2**OC)-1:0];
reg  [(2**OC)-1:0] r_in_en                       ;
reg  [     12-1:0] r_in_cnt         [(2**OC)-1:0];
reg  [     12-1:0] r2_in_cnt        [(2**OC)-1:0];
wire [     AW-1:0] w_in_cnt_trans   [(2**OC)-1:0]; //zy revise, write address  bit_reverse_oder -> natural order   
reg  [     AW-1:0] r_in_cnt_trans   [(2**OC)-1:0]; //zy revise, write address  bit_reverse_oder -> natural order   
reg  [ (AW-1)-1:0] r_in_addr        [(2**OC)-1:0];
reg  [     AW-1:0] r_out_addr       [(2**OC)-1:0];
wire [     AW-1:0] w_out_addr       [(2**OC)-1:0];
reg  [(2**OC)-1:0] r_dout_rqt_dly   [   NP-1-1:0];

always @(posedge i_clk  ) begin
    if (i_rst) begin
        r_din_en_frm        <= 1'b0;
        r_din_en_slt        <= 1'b0;
        r_din_ref           <= 1'b0; 
        r_din_ref_d1        <= 1'b0; 
        r_din_ref_rs        <= 1'b0; 
    end
    else begin

        r_din_en_frm        <= i_din_vld_frm;
        r_din_en_slt        <= i_din_vld_slt;

        if (r_din_en_frm) begin
            r_din_ref       <= 1'b1;
        end
        else begin
            if (r_din_en_slt) begin
                r_din_ref   <= ~r_din_ref;
            end
        end
        
        r_din_ref_d1        <= r_din_ref;
        r_din_ref_rs        <= r_din_ref & ~r_din_ref_d1;
    end
end


always @(posedge i_clk  ) begin
    if (i_rst) begin
        r_dout_rqt_frm      <= 1'b0;
        r_dout_rqt_slt      <= 1'b0;
        r_dout_ref          <= 1'b0; 
        r_dout_ref_d1       <= 1'b0; 
        r_dout_ref_rs       <= 1'b0; 
    end
    else begin

        r_dout_rqt_frm      <= i_dout_rqt_frm;
        r_dout_rqt_slt      <= i_dout_rqt_slt;

        if (r_dout_rqt_frm) begin
            r_dout_ref      <= 1'b1;
        end
        else begin
            if (r_dout_rqt_slt) begin
                r_dout_ref  <= ~r_dout_ref;
            end
        end
        
        r_dout_ref_d1       <= r_dout_ref;
        r_dout_ref_rs       <= r_dout_ref & ~r_dout_ref_d1;
    end
end


reg [12:0] nfft, nfft_mult2, nfft_mult4;
always @ (posedge i_clk ) begin
    case(i_fft_sz_idx)
        2'b00:   nfft <= 13'd255;
        2'b01:   nfft <= 13'd511;
        2'b10:   nfft <= 13'd1023;
        2'b11:   nfft <= 13'd2047;        
        default: nfft <= 13'd2047;
    endcase
end

always @ (posedge i_clk ) begin
    case(i_fft_sz_idx)
        2'b00:   nfft_mult2 <= 13'd511;
        2'b01:   nfft_mult2 <= 13'd1023;
        2'b10:   nfft_mult2 <= 13'd2047;
        2'b11:   nfft_mult2 <= 13'd4095;        
        default: nfft_mult2 <= 13'd4095;
    endcase
end

always @ (posedge i_clk ) begin
    case(i_fft_sz_idx)
        2'b00:   nfft_mult4 <= 13'd1023;
        2'b01:   nfft_mult4 <= 13'd2047;
        2'b10:   nfft_mult4 <= 13'd4095;
        2'b11:   nfft_mult4 <= 13'd8191;        
        default: nfft_mult4 <= 13'd8191;
    endcase
end
//**********************************************************************************
//zy revise, write address  bit_reverse_oder -> natural order   
wire [AW-1:0] w_in_cnt_trans_9b [(2**OC)-1:0];
wire [AW-1:0] w_in_cnt_trans_10b[(2**OC)-1:0];
wire [AW-1:0] w_in_cnt_trans_11b[(2**OC)-1:0];
wire [AW-1:0] w_in_cnt_trans_12b[(2**OC)-1:0];

reg  [15:0] r1_din_tuser  ;
reg  [15:0] r2_din_tuser  ;
reg  [15:0] r3_din_tuser  ;
reg  [15:0] r4_din_tuser  ;
reg  [15:0] r5_din_tuser  ;


always @ (posedge i_clk ) begin
  r1_din_tuser <= i_din_tuser ;
  r2_din_tuser <= r1_din_tuser; 
  r3_din_tuser <= r2_din_tuser;
  r4_din_tuser <= r3_din_tuser;
  r5_din_tuser <= r4_din_tuser;
end


genvar  dm, bn;

//generate if (VENDOR == "Xilinx") begin
//    for (dm = 0; dm < (2**OC); dm = dm + 1) begin : IN_ADDR_ORDER
////        assign w_in_cnt_trans[dm]= (i_din_vld[dm])? r5_din_tuser[AW-1:0] : 0;    
//        assign w_in_cnt_trans[dm]= (i_din_vld[dm])? r4_din_tuser[AW-1:0] : 0;    
//    end
//
//end
//else begin : Intel
//    for (dm = 0; dm < (2**OC); dm = dm + 1) begin : IN_ADDR_ORDER
//        assign w_in_cnt_trans[dm]= (i_din_vld[dm])? r4_din_tuser[AW-1:0] : 0;    
//    end
//end
//endgenerate
for (dm = 0; dm < (2**OC); dm = dm + 1) begin : IN_ADDR_ORDER
    assign w_in_cnt_trans[dm]= (i_din_vld[dm])? r4_din_tuser[AW-1:0] : 0;    
end

integer dmm, bnn;
always @(posedge i_clk ) begin
  for (dmm = 0; dmm < (2**OC); dmm = dmm + 1) begin : IN_ADDR_ORDER_REG
    for (bnn = 0; bnn < AW; bnn = bnn + 1) begin
      if(i_rst) begin
        r_in_cnt_trans[dmm][bnn] <= 0;
      end
      else begin
        r_in_cnt_trans[dmm][bnn] <= w_in_cnt_trans[dmm][bnn];    
      end
    end    
  end
end
//**********************************************************************************


always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC); i = i + 1) begin 
        if(i_rst) begin
            r_in_data[i] <= 0;
            r_in_cnt[i]  <= 0;
            r_in_addr[i] <= 0;
            r2_in_cnt[i] <= 0;
        end
        else begin
            if (r_din_ref_rs) begin
                r_in_cnt[i]     <= 0;
                r2_in_cnt[i]    <= 0;
            end
            else begin
            	r2_in_cnt[i]    <= r_in_cnt[i];
                if(i_din_vld[i]) begin
                    r_in_cnt[i] <= r_in_cnt[i] + 1;
                    //if(r_in_cnt[i][0] == 1'b0) begin
                      if(w_in_cnt_trans[i][0] == 1'b0) begin  //zy revise, write address  bit_reverse_oder -> natural order   
                        r_in_data[i][  BW-1:0 ] <= i_din;
                        //r_in_data[i][2*BW-1:BW] <= 0;
                        r_in_addr[i] <= w_in_cnt_trans[i][AW-1:1]; //zy revise, write address  bit_reverse_oder -> natural order   
                    end
                    else begin
                        r_in_data[i][2*BW-1:BW] <= i_din;
                        //r_in_addr[i] <= r_in_cnt[i][AW-1:1];
                        r_in_addr[i] <= w_in_cnt_trans[i][AW-1:1]; //zy revise, write address  bit_reverse_oder -> natural order   
                    end
                end
                else begin
                    r_in_cnt[i] <= 0 ;
                end
            end
        end
    end
end

always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC); i = i + 1) begin 
        if(i_rst) begin
            r_in_en[i] <= 1'b0;
        end
        else begin
            //r_in_en[i] <= (i_din_vld[i] == 1'b1) & (r_in_cnt[i][0] == 1'b1);
            r_in_en[i] <= (i_din_vld[i] == 1'b1) ; //zy revise, write address  bit_reverse_oder -> natural order
        end
    end
end

//**********************************************************************************
//zy revise, with demap                    
reg [ 8:0] r_rb_size ;
reg [15:0] r_tone_len;
reg [12:0] r_k0;

always @(posedge i_clk) begin
  if(i_rst) begin
  	r_tone_len <= 0;
  	r_rb_size  <= 0;
  	r_k0       <= 0;
  end
  else if(i_dout_rqt_slt) begin
  	r_tone_len <= {i_rb_size,3'b000} + {i_rb_size,2'b00};
  	r_rb_size  <= i_rb_size;
  	r_k0       <= i_k0;
  end
end

//**********************************************************************************


always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC); i = i + 1) begin 
        if(i_rst) begin
            r_out_addr[i] <= 0;
        end
        else begin
            if (r_dout_rqt_slt) begin
              //**********************************************************************************
              //zy revise, with demap   
              r_out_addr[i]   <= $signed({1'b0,nfft_mult2})-$signed({1'b0,r_tone_len[15:1]}) +$signed(2'b01)+ $signed(r_k0);
              //**********************************************************************************
            end
            else begin
                if(i_dout_rqt[i]) begin
                    // r_out_addr[i] <= r_out_addr[i] + 1;
                    //*****************************************
                    //zy revise, with demap
                    r_out_addr[i] <= (r_out_addr[i]==nfft_mult2[11:0])? 0 : r_out_addr[i] + 1;
                    //*****************************************
                end
            end
        end
    end
end

always @(posedge i_clk ) begin
    if(i_rst) begin
        for (j = 0; j < NP-1; j = j + 1) begin 
            r_dout_rqt_dly[j] <= 0;
        end
    end
    else begin
        r_dout_rqt_dly[0] <= i_dout_rqt;
        for (j = 1; j < NP-1; j = j + 1) begin 
            r_dout_rqt_dly[j] <= r_dout_rqt_dly[j-1];
        end
    end
end

reg  [               EB-1:0] r_in_buf_sel     [  (2**OC)-1:0];
reg  [          (2**EB)-1:0] r_wea            [(2**OC)/2-1:0];
reg  [          (2**EB)-1:0] r_wea_h          [(2**OC)/2-1:0]; //zy revise, byte write memory byte enable  
reg  [          (2**EB)-1:0] r_wea_l          [(2**OC)/2-1:0]; //zy revise, byte write memory byte enable   
reg  [               AW-1:0] r_addra          [(2**OC)/2-1:0];
reg  [             BW*2-1:0] r_din            [(2**OC)/2-1:0];

reg  [               EB-1:0] r_out_buf_sel    [  (2**OC)-1:0];
reg  [          (2**OC)-1:0] r_out_idx_sel                   ;
reg  [          (2**OC)-1:0] r_out_idx_sel_dly[     NP-1-1:0];
reg  [          (2**EB)-1:0] r_enb            [(2**OC)/2-1:0];
wire [(2**EB)*(2**OC)/2-1:0] w_enb                           ;
reg  [(2**EB)*(2**OC)/2-1:0] r_enb_dly        [     NP-1-1:0];         
reg  [               AW-1:0] r_addrb          [(2**OC)/2-1:0];
reg  [               AW-1:0] w_addrb          [(2**OC)/2-1:0];

integer ns;
initial begin
  for(ns=0; ns<2**OC; ns=ns+1) r_out_buf_sel[ns]	<= 0;
end

for (k = 0; k < (2**EB); k = k + 1) begin : LIB_P2B_4096_ENB_EB
for (l = 0; l < (2**OC)/2; l = l + 1) begin : LIB_P2B_4096_ENB_OC

assign w_enb[k*(2**OC)/2+l] = r_enb[l][k];

end
end

always @(posedge i_clk ) begin
    if(i_rst) begin
        for (j = 0; j < NP-1; j = j + 1) begin 
            r_enb_dly[j] <= 0;
            r_out_idx_sel_dly[j] <= 0;
        end
    end
    else begin
        r_enb_dly[0] <= w_enb;
        r_out_idx_sel_dly[0] <= r_out_idx_sel;
        for (j = 1; j < NP-1; j = j + 1) begin 
            r_enb_dly[j] <= r_enb_dly[j-1];
            r_out_idx_sel_dly[j] <= r_out_idx_sel_dly[j-1];
        end
    end
end


always @(posedge i_clk ) 
begin
    for (i = 0; i < (2**OC)/2; i = i + 1) 
    begin
        if(i_rst) 
        begin
//           for (j = 0; j < (2**EB); j = j + 1) 
//           begin 
//               r_wea   [i][j]  <= 1'b0;
//               r_wea_h [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
//               r_wea_l [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
//           end

                r_wea   [i]  <= 2'b0;
                r_wea_h [i]  <= 2'b0;  //zy revise, byte write memory byte enable
                r_wea_l [i]  <= 2'b0;  //zy revise, byte write memory byte enable

            r_addra     [i]     <= 0;
            r_din       [i]     <= 0;
            r_in_buf_sel[2*i]   <= 0;
            r_in_buf_sel[2*i+1] <= 0;
        end
    	else if(i_abnormal_input)
    	begin
             for (j = 0; j < (2**EB); j = j + 1) 
            begin                
                r_wea   [i][j]  <= 1'b0;
                r_wea_h [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
                r_wea_l [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable                
     //           r_in_buf_sel[2*i]   <= 0;
     //           r_in_buf_sel[2*i+1] <= 0;
            end
                r_addra     [i] <= 0;
                r_in_buf_sel[2*i]   <= r_in_buf_sel[2*i]   +1;
                r_in_buf_sel[2*i+1] <= r_in_buf_sel[2*i+1] +1;   		
		end
        else 
        begin
            if (r_din_ref_rs) 
            begin
            for (j = 0; j < (2**EB); j = j + 1) 
            begin                
                r_wea   [i][j]  <= 1'b0;
                r_wea_h [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
                r_wea_l [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable                
     //           r_in_buf_sel[2*i]   <= 0;
     //           r_in_buf_sel[2*i+1] <= 0;
            end
                r_addra     [i] <= 0;
                r_in_buf_sel[2*i]   <= 0;
                r_in_buf_sel[2*i+1] <= 0;
            end
            else 
            begin
                if(r_in_en[2*i]) 
                begin
                    for (j = 0; j < (2**EB); j = j + 1) begin 
                        r_wea   [i][j]  <= (r_in_buf_sel[2*i] == j) & 1'b1;
                        r_wea_h [i][j]  <= (r_in_buf_sel[2*i] == j) & r_in_cnt_trans[2*i][0];     //zy revise, byte write memory byte enable
                        r_wea_l [i][j]  <= (r_in_buf_sel[2*i] == j) & (~r_in_cnt_trans[2*i][0]);  //zy revise, byte write memory byte enable
                    end
                    
                    if(i_fft_sz_idx == 2'd1)        r_addra[i] <=   {1'b0, r_in_addr[2*i][AW-2:0]} ;
                    else if(i_fft_sz_idx == 2'd2)   r_addra[i] <=   {1'b0, r_in_addr[2*i][AW-2:0]} ; 
                    else                            r_addra[i] <=   {1'b0, r_in_addr[2*i][AW-2:0]} ;    
                        
                    r_din  [i] <= r_in_data[2*i];
                    if(r2_in_cnt[2*i] == nfft_mult2[11:0] )  r_in_buf_sel[2*i] <= r_in_buf_sel[2*i]+1;
                end
                else if(r_in_en[2*i+1]) 
                begin
                    for (j = 0; j < (2**EB); j = j + 1) begin 
                        r_wea   [i][j]  <= (r_in_buf_sel[2*i+1] == j) & 1'b1;
                        r_wea_h [i][j]  <= (r_in_buf_sel[2*i+1] == j) & r_in_cnt_trans[2*i+1][0];    //zy revise, byte write memory byte enable
                        r_wea_l [i][j]  <= (r_in_buf_sel[2*i+1] == j) & (~r_in_cnt_trans[2*i+1][0]); //zy revise, byte write memory byte enable
                    end
                    
                    if(i_fft_sz_idx == 2'd1)        r_addra[i] <=   {1'b1, r_in_addr[2*i+1][AW-2:0]} ;
                    else if(i_fft_sz_idx == 2'd2)   r_addra[i] <=   {1'b1, r_in_addr[2*i+1][AW-2:0]} ; 
                    else                            r_addra[i] <=   {1'b1, r_in_addr[2*i+1][AW-2:0]} ;    
                        
                    r_din  [i] <= r_in_data[2*i+1];
                    if(r2_in_cnt[2*i+1] == nfft_mult2[11:0])  r_in_buf_sel[2*i+1] <= r_in_buf_sel[2*i+1]+1;
                end
                else 
                begin
                    for (j = 0; j < (2**EB); j = j + 1) begin 
                        r_wea   [i][j]  <= 1'b0;
                        r_wea_h [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
                        r_wea_l [i][j]  <= 1'b0;  //zy revise, byte write memory byte enable
                    end
                end
            end
        end
    end
end

genvar  n;
for (k = 0; k < (2**OC); k = k + 1) begin : W_OUT_ADDR
    for (n = 0; n < AW; n = n + 1) begin
        //assign w_out_addr[k][AW-n-1] = r_out_addr[k][n];    
        assign w_out_addr[k][n] = r_out_addr[k][n];       //zy revise, with demap 
    end    
end

reg [15:0] r_rd_trans_cnt  [(2**OC)/2-1:0];
reg [15:0] r2_rd_trans_cnt [(2**OC)/2-1:0];

always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC)/2; i = i + 1) begin
        if(i_rst) begin
            r_addrb[i] <= 0;
            w_addrb[i] <= 0 ;
            
            r_rd_trans_cnt[i]  <= 0;
            r2_rd_trans_cnt[i] <= 0;
        end
        else if(r_dout_rqt_slt) begin
           r_rd_trans_cnt[i]  <= 0;
           r2_rd_trans_cnt[i] <= 0;
           r_addrb[i] <= 0;
           w_addrb[i] <= 0 ;
        end
        else if(i_dout_rqt[2*i]) begin 
            //if(i_fft_sz_idx == 2'd1) begin
            //    r_addrb[i] <= {3'b000, w_out_addr[2*i][AW-1:1+2]} ;
            //    w_addrb[i] <= {3'b000, w_out_addr[2*i][AW-1:1+2]} ;
            //end
            //else if(i_fft_sz_idx == 2'd2) begin
            //    r_addrb[i] <= {2'b00, w_out_addr[2*i][AW-1:1+1]} ;
            //    w_addrb[i] <= {2'b00, w_out_addr[2*i][AW-1:1+1]} ;
            //end
            //else  begin 
                r_addrb[i] <= {1'b0, w_out_addr[2*i][AW-1:1]} ;
                w_addrb[i] <= {1'b0, w_out_addr[2*i][AW-1:1]} ;
            //end
            if(r_rd_trans_cnt[i]==nfft_mult4+1) begin
               r_rd_trans_cnt[i] <= 1;
            end
            else begin
              r_rd_trans_cnt[i] <= r_rd_trans_cnt[i] + 1'b1;
            end
            r2_rd_trans_cnt[i] <= r_rd_trans_cnt[i];
        end
        else if(i_dout_rqt[2*i+1]) begin
            //if(i_fft_sz_idx == 2'd1) begin
            //     r_addrb[i] <= {3'b001, w_out_addr[2*i+1][AW-1:1+2]} ;
            //     w_addrb[i] <= {3'b000, w_out_addr[2*i+1][AW-1:1+2]} ;
            //    end
            //else if(i_fft_sz_idx == 2'd2) begin
            //    r_addrb[i] <= {2'b01, w_out_addr[2*i+1][AW-1:1+1]} ;
            //    w_addrb[i] <= {2'b00, w_out_addr[2*i+1][AW-1:1+1]} ;
            //end
            //else begin 
                r_addrb[i] <= {1'b1, w_out_addr[2*i+1][AW-1:1]} ;
                w_addrb[i] <= {1'b0, w_out_addr[2*i+1][AW-1:1]} ;
            //end
            if(r_rd_trans_cnt[i]==nfft_mult4+1) begin
               r_rd_trans_cnt[i] <= 0;
            end
            else begin
              r_rd_trans_cnt[i] <= r_rd_trans_cnt[i] + 1'b1;
            end
            r2_rd_trans_cnt[i] <= r_rd_trans_cnt[i];
        end
        else begin
          r2_rd_trans_cnt[i] <= 0;//r_rd_trans_cnt[i];
        end
    end
end

always @(posedge i_clk ) begin //or posedge i_rst) begin
    for (i = 0; i < (2**OC)/2; i = i + 1) begin
        if(i_rst) begin
            for (j = 0; j < (2**EB); j = j + 1) begin 
                r_enb[i][j] <= 1'b0;
            end
        end
        else if(i_dout_rqt[2*i]) begin
            for (j = 0; j < (2**EB); j = j + 1) begin 
                r_enb[i][j] <= (r_out_buf_sel[2*i] == j);
            end
        end
        else if(i_dout_rqt[2*i+1]) begin
            for (j = 0; j < (2**EB); j = j + 1) begin 
                r_enb[i][j] <= (r_out_buf_sel[2*i+1] == j);
            end
        end
        else begin
            for (j = 0; j < (2**EB); j = j + 1) begin 
                r_enb[i][j] <= 1'b0;
            end
        end
    end
end

reg [     AW-1:0] r1_out_addr       [(2**OC)-1:0];

always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC); i = i + 1) begin
        if(i_rst) begin
            r1_out_addr[i] <= 0;
        end
        else begin
            r1_out_addr[i] <= w_out_addr[i];
        end
    end
end

always @(posedge i_clk ) begin
    for (i = 0; i < (2**OC)/2; i = i + 1) begin
        if(i_rst) begin
            r_out_buf_sel[2*i]   <= 0;
            r_out_buf_sel[2*i+1] <= 0;
            r_out_idx_sel[2*i]   <= 1'b0;
            r_out_idx_sel[2*i+1] <= 1'b0;
        end
        else begin
            if (r_dout_ref_rs) begin
    	        r_out_buf_sel[2*i]      <= 0;
    	        r_out_buf_sel[2*i+1]    <= 0;
                r_out_idx_sel[2*i]      <= 1'b0;
                r_out_idx_sel[2*i+1]    <= 1'b0;
            end
            else begin
                //if(|(r_enb[2*i])) begin
                if(|(r_enb[i])) begin
                    //if(w_addrb[i] == nfft ) begin              
                    if(r2_rd_trans_cnt[i][15:0] == {3'b000,nfft_mult4} ) begin         
                        if(r_dout_rqt_dly[0][2*i]) begin
                            //r_out_idx_sel[2*i]   <= ~r_out_idx_sel[2*i];
                            //if(r_out_idx_sel[2*i] == 1'b1) begin
                                r_out_buf_sel[2*i]   <= r_out_buf_sel[2*i]+1;
                            //end
                        end
                        else if(r_dout_rqt_dly[0][2*i+1]) begin
                            //r_out_idx_sel[2*i+1]   <= ~r_out_idx_sel[2*i+1];
                            //if(r_out_idx_sel[2*i+1] == 1'b1) begin
                                r_out_buf_sel[2*i]   <= r_out_buf_sel[2*i]+1;
                                r_out_buf_sel[2*i+1]   <= r_out_buf_sel[2*i+1]+1;
                            //end
                        end
                        else
                        begin
                            r_out_buf_sel[2*i]   <= r_out_buf_sel[2*i];
                            r_out_buf_sel[2*i+1]   <= r_out_buf_sel[2*i+1];
                        end
                    end
                    if(r_dout_rqt_dly[0][2*i]) begin
//                        r_out_idx_sel[2*i]   <= r1_out_addr[2*i][0];
                        r_out_idx_sel[0]   <= r1_out_addr[2*i][0];
                    end
                    else if (r_dout_rqt_dly[0][2*i+1]) begin
  //                      r_out_idx_sel[2*i+1]   <= r1_out_addr[2*i+1][0];
                        r_out_idx_sel[0]   <= r1_out_addr[2*i+1][0];
                    end
                end
            end
        end
    end
end


reg  [             BW*2-1:0] w_dout       [(2**EB)*(2**OC)/2-1:0][NP:0];
wire [             BW*2-1:0] w_mem_dout       [(2**EB)*(2**OC)/2-1:0];

wire [             BW*2-1:0] w_dout_XILINXtemp       [(2**EB)*(2**OC)/2-1:0];

wire [(2**EB)*(2**OC)/2-1:0] w_dout_t     [             BW*2-1:0];
wire [             BW*2-1:0] w_dout_t2                           ;
wire [          72-BW*2-1:0] w_dout_dummy [(2**EB)*(2**OC)/2-1:0];


generate
for (k = 0; k < (2**EB); k = k + 1) begin : LIB_P2B_4096_BUFFER_ORDER
for (l = 0; l < (2**OC)/2; l = l + 1) begin : LIB_P2B_4096_BUFFER_OVERCLOCK

//lib_sdpram #(.AW(AW), .DW(2*BW), .NP(NP-3), .RAM_TYPE(RAM_TYPE)) u0_sdpram (
//      .i_clk      (      i_clk                                           ) // Clock 
//    , .i_ena      (      1'b1                                            ) // Input port Enable
//    , .i_enb      (      r_enb[l][k]                                     ) // Output Register Enable
//    , .i_wea      (      r_wea[l][k]                                     ) // Write Enable
//    , .i_addra    (      r_addra[l]                                      ) // Write Address
//    , .i_addrb    (      r_addrb[l]                                      ) // Read  Address
//    , .i_dina     (      r_din[l]                                        ) // Data input wire   
//    , .o_doutb    (      w_dout[k*(2**OC)/2+l]                           ) // Data Output
//ulfe_bit_reverse_buf #( .AWIDTH(AW), .NUM_COL(BW/4), .DWIDTH(2*BW), .NBPIPE(NP-3),  .RAM_TYPE(RAM_TYPE)) u_ulfe_bit_reverse_buf_temp( 
//  .clk     ( i_clk                                  )       // input                                   // Clock
// ,.rsta    ( i_rst                                  )       // input                                  // Reset
// ,.wea     ( {{4{r_wea_h[l][k]}},{4{r_wea_l[l][k]}}})       // input [NUM_COL-1:0]       // Write Enable
// ,.regcea  ( 1'b0                                   )       // input                                // Output Register Enable
// ,.mem_ena ( r_wea[l][k]                            )       // input                               // Memory Enable
// ,.dina    ( r_din[l]                               )       // input [DWIDTH-1:0]        // Data Input  
// ,.addra   ( r_addra[l]                             )       // input [AWIDTH-1:0]       // Address Input
// ,.douta   (                                        )       // output reg [DWIDTH-1:0]   // Data Output
// ,.rstb    ( i_rst                                  )       // input                                  // Reset
// ,.web     ( 8'b00000000                            )       // input [NUM_COL-1:0]       // Write Enable
// ,.regceb  ( 1'b1                                   )       // input                                // Output Register Enable
// ,.mem_enb ( r_enb[l][k]                            )       // input                               // Memory Enable
// ,.dinb    ( 64'd0                                  )       // input [DWIDTH-1:0]        // Data Input  
// ,.addrb   ( r_addrb[l]                             )       // input [AWIDTH-1:0]        // Address Input
// ,.doutb   ( w_dout_XILINXtemp[k*(2**OC)/2+l]                  )        // output reg [DWIDTH-1:0]   // Data Output
//);

//        ylib_rams_sdp_8byte #(
////            .WIDTH(2*BW),
//            .DEPTH(2**AW),
//            .VENDOR(VENDOR)
//        ) u_ulfe_bit_reverse_buf_Sdp (
//            .clk   (   i_clk            ),
//            .ena   (   r_wea[l][k]      ),
//            .enb   (   r_enb[l][k]      ),
//            .wea   (   r_wea[l][k]     ),
//            .be    (   {{4{r_wea_h[l][k]}},{4{r_wea_l[l][k]}}}     ),
//            .addra (   r_addra[l]   ),
//            .addrb (   r_addrb[l]   ),
//            .dia   (   r_din[l]    ),
//            .dob   (   w_mem_dout[k*(2**OC)/2+l]   )
//        );
//generate if (VENDOR == "Xilinx") begin
        ylib_rams_tdp_8byte #(
        .AWIDTH(AW)       // Address Width
        ,.NUM_COL(8)      // Number of columns
        ,.DWIDTH(64)      // Data Width, (Byte * NUM_COL) 
        ,.NBPIPE(NP-3)    // Number of pipeline Registers
        ,.VENDOR(VENDOR)
        ) u_ulfe_bit_reverse_buf (
             .clk(i_clk),
             .rsta(1'b0),
             .wea({{4{r_wea_h[l][k]}},{4{r_wea_l[l][k]}}}),
             .regcea(1'b0),
             .mem_ena(r_wea[l][k]),
             .dina(r_din[l]),
             .addra(r_addra[l]),
             .douta(),
             .rstb(1'b0),
             .web(8'b00000000),
             .regceb(1'b1),
             .mem_enb(r_enb[l][k]),
             .dinb(64'd0),
             .addrb(r_addrb[l]),
             .doutb(w_mem_dout[k*(2**OC)/2+l])
        );
//end
//else begin : Intel

//end
//endgenerate


//
//        always @ (posedge i_clk)
//        begin
//            w_dout[k*(2**OC)/2+l][0] <=  w_mem_dout[k*(2**OC)/2+l];
//            
//            for (kk = 0; kk < NP-3; kk = kk+1)
//            begin
//                w_dout[k*(2**OC)/2+l][kk+1] <= w_dout[k*(2**OC)/2+l][kk];     //aligned addr 7
//            end
//        end 

end
end
endgenerate

for (m = 0; m < BW*2; m = m + 1) begin : LIB_P2B_4096_DOUT_MUX_BW
for (k = 0; k < (2**EB); k = k + 1) begin : LIB_P2B_4096_DOUT_MUX_EB
for (l = 0; l < (2**OC)/2; l = l + 1) begin : LIB_P2B_4096_DOUT_MUX_OC

assign w_dout_t[m][k*(2**OC)/2+l] = w_mem_dout[k*(2**OC)/2+l][m];//w_dout[k*(2**OC)/2+l][NP-3][m];

end
end

assign w_dout_t2[m] = |(w_dout_t[m] & r_enb_dly[NP-2]);

end



always @(posedge i_clk ) begin
    if(i_rst) begin
        o_dout_vld <= 0;
    end
    else begin
        o_dout_vld <= (r_dout_rqt_dly[NP-2]);
    end
end


always @(posedge i_clk ) begin
    if(i_rst) begin
        o_dout <= 0;
    end
    else if(|(r_enb_dly[NP-2-1])) begin
        if(r_out_idx_sel_dly[NP-2-1][0] == 1'b0) begin
            o_dout <= w_dout_t2[  BW-1: 0];
        end
        else begin
            o_dout <= w_dout_t2[2*BW-1:BW];
        end
    end
end


endmodule
 


