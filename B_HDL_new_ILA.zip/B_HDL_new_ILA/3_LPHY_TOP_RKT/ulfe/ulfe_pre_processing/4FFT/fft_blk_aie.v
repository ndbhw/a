// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR VERSAL 8T8R FPGA
//  Module       : fft_4096
//  Author       : Song, Moon-Gun
//  Description  : aie fft 4096 
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.12 | Donggeun Jo   | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module fft_blk_aie
#(
    parameter   IB                = 15
    , parameter   OB                = 15
    , parameter   NUM_RX            = 2
    , parameter   VENDOR            = "Xilinx"
    , parameter   MAX_NFFT          = 4096
)
(
    input  wire                   i_clk // i_clk 
    , input  wire                   i_rst // Sync. Reset Active High
    , input  wire                   i_aie_clk // i_clk 
    , input  wire                   i_aie_rst // Sync. Reset Active High

    , input  wire [   (NUM_RX)-1:0]  i_td_vld // Input Signal Enable
    , input  wire [        IB-1:0]  i_td_i_0M // Inphase Input Signal
    , input  wire [        IB-1:0]  i_td_q_0M // Quadrature Input Signal
    , input  wire [        IB-1:0]  i_td_i_0L // Inphase Input Signal
    , input  wire [        IB-1:0]  i_td_q_0L // Quadrature Input Signal
    , input  wire [        IB-1:0]  i_td_i_1M // Inphase Input Signal
    , input  wire [        IB-1:0]  i_td_q_1M // Quadrature Input Signal
    , input  wire [        IB-1:0]  i_td_i_1L // Inphase Input Signal
    , input  wire [        IB-1:0]  i_td_q_1L // Quadrature Input Signal

    , input  wire [         1-1:0]  i_td_sym_tick // 
    , input  wire [   (NUM_RX)-1:0]  i_fd_rqst // FFT Output Request
    , input  wire [   (NUM_RX)-1:0]  i_sc_vld // FFT Output vld Related to RB Size
    , input  wire [         9-1:0]  i_rb_size
    , input  wire [        12-1:0]  i_k0
    , input  wire [         2-1:0]  i_fft_sz_idx // fft size
    , input  wire [         1-1:0]  i_fft_buf_in_vld_frm // 
    , input  wire [         1-1:0]  i_fft_buf_in_vld_slt // 
    , input  wire [         1-1:0]  i_fft_buf_out_vld_frm // 
    , input  wire [         1-1:0]  i_fft_buf_out_vld_slt // 

    , output wire [   (NUM_RX)-1:0]  o_fd_vld // Output Signal Enable
    , output wire [        OB-1:0]  o_fd_i // Inphase Output Signal
    , output wire [        OB-1:0]  o_fd_q // Quadrature Output Signal 

    , output wire [31:0]     o_cnt_st01_a2p_last                                        
    , output wire [31:0]     o_cnt_st01_a2p_0dat  
    , output wire [31:0]     o_cnt_fd_01dat 


    , input   wire    [1   -1:0]                          i_p2a0_ready
    , output  wire    [1   -1:0]                          o_p2a0_valid
    , output  wire    [64  -1:0]                          o_p2a0_data
    , output  wire    [1   -1:0]                          o_p2a0_last
    , output  wire    [8   -1:0]                          o_p2a0_keep
    , output  wire    [1   -1:0]                          o_a2p0_ready
    , input   wire    [1   -1:0]                          i_a2p0_valid
    , input   wire    [64  -1:0]                          i_a2p0_data
    , input   wire    [1   -1:0]                          i_a2p0_last

    , input   wire    [1   -1:0]                          i_p2a1_ready
    , output  wire    [1   -1:0]                          o_p2a1_valid
    , output  wire    [64  -1:0]                          o_p2a1_data
    , output  wire    [1   -1:0]                          o_p2a1_last
    , output  wire    [8   -1:0]                          o_p2a1_keep
    , output  wire    [1   -1:0]                          o_a2p1_ready
    , input   wire    [1   -1:0]                          i_a2p1_valid
    , input   wire    [64  -1:0]                          i_a2p1_data
    , input   wire    [1   -1:0]                          i_a2p1_last
);

    localparam PL2AIE_EN                   = 1;
    localparam AIE2PL_EN                   = 1;
    //localparam PL2AIE_SYNC_STATE_EN        = 0;          //for DUCA, removed    
    localparam PL2AIE_DATA_SIZE            = 64;
    localparam AIE2PL_DATA_SIZE            = 64;
    localparam TKEEP_SIZE                  = 8;
    localparam PL_HEADER_EN                = 0;
    localparam AIE_HEADER_EN               = 0;
    localparam PL_HEADER_SIZE              = 8;
    localparam AIE_HEADER_SIZE             = 4;
    localparam PL_DATA_PACKET_SIZE_STREAM0 = 1027;
    localparam PL_DATA_PACKET_SIZE_STREAM1 = 1029;
    localparam AIE_DATA_PACKET_SIZE        = 1024;
    localparam PL2AIE_ASYNC_FIFO_DEPTH     = 1024; //keep for ul_cal             
    localparam PL2AIE_SYNC_FIFO_DEPTH      = 32;
    localparam AIE2PL_ASYNC_FIFO_DEPTH     = 512;
    localparam AIE2PL_SYNC_FIFO_DEPTH      = 32;

    localparam buf_AW       =   12;
    localparam buf_num_pipe =   2;
    //reg [(NUM_RX)-1:0]  r_td_vld;
    reg  r_td_vld;


    wire [2-1:0]    w_fft_sz_idx;
    wire [9-1:0]    w_rb_size   ;
    wire [12-1:0]   w_k0        ;

    reg [11-1:0]    m_reshape_cnt = 11'd1100;
    wire [16-1:0]    w_td_i_0M;
    wire [16-1:0]    w_td_q_0M;
    wire [16-1:0]    w_td_i_0L;
    wire [16-1:0]    w_td_q_0L;
    wire [16-1:0]    w_td_i_1M;
    wire [16-1:0]    w_td_q_1M;
    wire [16-1:0]    w_td_i_1L;
    wire [16-1:0]    w_td_q_1L;
    reg [1:0]       r_tvld;
    reg [1:0]       r_tlast;
    reg [7:0]       r_tkeep0;
    reg [7:0]       r_tkeep1;
    reg [16*2-1:0]  r_tdat_0M;
    reg [16*2-1:0]  rr_tdat_0M;
    reg [16*2-1:0]  r_tdat_0L;
    reg [16*2-1:0]  rr_tdat_0L;
    reg [16*2-1:0]  r_tdat_1M;
    reg [16*2-1:0]  rr_tdat_1M;
    reg [16*2-1:0]  r_tdat_1L;
    reg [16*2-1:0]  rr_tdat_1L;
    reg [16-1:0]    r_gain_i;
    reg [16-1:0]    r_gain_q;
    wire [AIE2PL_DATA_SIZE-1:0]   w_st0_a2p_data;
    wire                          w_st0_a2p_dvld;
    wire                          w_st0_a2p_last;
    wire [AIE2PL_DATA_SIZE-1:0]   w_st1_a2p_data;
    wire                          w_st1_a2p_dvld;
    wire                          w_st1_a2p_last;
    reg [15:0]      r_cnt_st1_a2p_last;                                        
    reg [15:0]      r_cnt_st0_a2p_last;                                        
    wire [31:0]     w_cnt_st01_a2p_last;                                        
    reg [15:0]      r_cnt_st1_a2p_0dat;                                        
    reg [15:0]      r_cnt_st0_a2p_0dat;                                        
    wire [31:0]     w_cnt_st01_a2p_0dat;  
    reg [15:0]      r_cnt_fd_0dat;                                        
    reg [15:0]      r_cnt_fd_1dat;                                        
    wire [31:0]     w_cnt_fd_01dat; 
    
    ylib_reg #(.WIDTH(2+9+12),.DEPTH(1)) ylib_reg_cfg (.i_clk(i_clk),.i_in({i_fft_sz_idx,i_rb_size,i_k0}),.o_out({w_fft_sz_idx,w_rb_size,w_k0}));

    wire    signed [16-1:0]     sw_k0;
    wire    signed [16-1:0]     sw_rb_size;

    assign  sw_k0       = {{4{w_k0[12-1]}},w_k0};
    assign  sw_rb_size  = {{4{1'b0}},w_rb_size};

    reg signed [16-1:0]     r_firstre;

    always @(posedge i_clk)
    begin
        r_firstre    <=  sw_k0 - ((sw_rb_size<<2)+(sw_rb_size<<1));
    end

    always @(posedge i_clk)
    begin
        case(w_fft_sz_idx)
            2'd0 : begin
                r_gain_i <= 16'd23170;
                r_gain_q <= 16'd0;
            end
            2'd1 : begin
                r_gain_i <= 16'd16384;
                r_gain_q <= 16'd0;
            end
            2'd2 : begin
                r_gain_i <= 16'd11585;
                r_gain_q <= 16'd0;
            end
            default : begin
                r_gain_i <= 16'd8192;
                r_gain_q <= 16'd0;
            end
        endcase
    end




    always @(posedge i_clk)
    begin
        r_td_vld <= |i_td_vld;
    end


    always @(posedge i_clk)
    begin
        if((~r_td_vld) && (|i_td_vld) && (m_reshape_cnt == 11'd1100))
            m_reshape_cnt   <= 11'd0;
        else if(m_reshape_cnt == 11'd1100)
            m_reshape_cnt   <= m_reshape_cnt;
        else
            m_reshape_cnt   <= m_reshape_cnt + 11'd1;
    end


    ylib_reg #(.WIDTH(32),.DEPTH(2)) ylib_reg_stage0_0M (.i_clk(i_clk),.i_in({i_td_i_0M[15-1],i_td_i_0M,i_td_q_0M[15-1],i_td_q_0M}),.o_out({w_td_i_0M,w_td_q_0M}));
    ylib_reg #(.WIDTH(32),.DEPTH(3)) ylib_reg_stage0_0L (.i_clk(i_clk),.i_in({i_td_i_0L[15-1],i_td_i_0L,i_td_q_0L[15-1],i_td_q_0L}),.o_out({w_td_i_0L,w_td_q_0L}));
    ylib_reg #(.WIDTH(32),.DEPTH(1)) ylib_reg_stage0_1M (.i_clk(i_clk),.i_in({i_td_i_1M[15-1],i_td_i_1M,i_td_q_1M[15-1],i_td_q_1M}),.o_out({w_td_i_1M,w_td_q_1M}));
    ylib_reg #(.WIDTH(32),.DEPTH(2)) ylib_reg_stage0_1L (.i_clk(i_clk),.i_in({i_td_i_1L[15-1],i_td_i_1L,i_td_q_1L[15-1],i_td_q_1L}),.o_out({w_td_i_1L,w_td_q_1L}));


    always @(posedge i_clk)
    begin
        if(|m_reshape_cnt == 1'b0)
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b1;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  {r_firstre,{14'd0,{2'd3-w_fft_sz_idx}}};
                r_tdat_0L   <=  32'h8fff1002;//32'd2;
                r_tdat_1M   <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  32'h8fff1001;//32'd1;
            end
        else if(m_reshape_cnt == 11'd1)
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  32'h8fff1001;//32'd1;
                r_tdat_1M   <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt >= 11'd2 && m_reshape_cnt < 11'd512 )
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd512 )
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b1;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'h0f;
                r_tdat_0M   <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {w_td_q_1M,w_td_i_1M};
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd513 )
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b1;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'h0f;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  {w_td_q_0M,w_td_i_0M};
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  rr_tdat_1M;
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  32'h0fff1000;//32'd0;
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd514 )
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  32'h0fff1000;//32'd0;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  rr_tdat_1M;
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  rr_tdat_1L;
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt > 11'd514 && m_reshape_cnt < 11'd1025)
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  rr_tdat_1M;
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  rr_tdat_1L;
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd1025)
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b1;
                r_tkeep0    <=  8'hff;
                r_tkeep1    <=  8'h0f;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  rr_tdat_1M;
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  rr_tdat_1L;
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd1026)
            begin
                r_tvld[0]   <=  1'b1;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b1;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'h0f;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {r_gain_q,r_gain_i};
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  32'h8fff1002;//32'd2;
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end

        else if(m_reshape_cnt == 11'd1027 )
            begin
                r_tvld[0]   <=  1'b0;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'h00;
                r_tkeep1    <=  8'hff;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {r_gain_q,r_gain_i};
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {r_gain_q,r_gain_i};
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else if(m_reshape_cnt == 11'd1028 )
            begin
                r_tvld[0]   <=  1'b0;
                r_tvld[1]   <=  1'b1;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b1;
                r_tkeep0    <=  8'h00;
                r_tkeep1    <=  8'h0f;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {r_gain_q,r_gain_i};
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {r_gain_q,r_gain_i};
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
        else //if(m_reshape_cnt == 11'd1028 )
            begin
                r_tvld[0]   <=  1'b0;
                r_tvld[1]   <=  1'b0;
                r_tlast[0]  <=  1'b0;
                r_tlast[1]  <=  1'b0;
                r_tkeep0    <=  8'h00;
                r_tkeep1    <=  8'h00;
                r_tdat_0M   <=  rr_tdat_0M;
                rr_tdat_0M  <=  {w_td_q_0M,w_td_i_0M};
                r_tdat_0L   <=  rr_tdat_0L;
                rr_tdat_0L   <=  {w_td_q_0L,w_td_i_0L};
                r_tdat_1M   <=  {r_gain_q,r_gain_i};
                rr_tdat_1M  <=  {w_td_q_1M,w_td_i_1M};
                r_tdat_1L   <=  {r_gain_q,r_gain_i};
                rr_tdat_1L   <=  {w_td_q_1L,w_td_i_1L};
            end
    end

    ////assign i_p2a0_ready     =         
    //assign o_p2a0_valid     = r_tvld[0];
    //assign o_p2a0_data      = {r_tdat_0M,r_tdat_0L};
    //assign o_p2a0_last      = r_tlast[0];
    //assign o_p2a0_keep      = r_tkeep0;
    //assign o_a2p0_ready     = 
    ////assign i_a2p0_valid     = r_tvld[0];
    ////assign i_a2p0_data      =
    ////assign i_a2p0_last      = r_tlast[0];                                     
    ////assign i_p2a1_ready     =
    //assign o_p2a1_valid     = r_tvld[1];
    //assign o_p2a1_data      = {r_tdat_1M,r_tdat_1L};
    //assign o_p2a1_last      = r_tlast[1];
    //assign o_p2a1_keep      = r_tkeep1;
    //assign o_a2p1_ready     = 
    ////assign i_a2p1_valid     = r_tvld[1];
    ////assign i_a2p1_data      =
    ////assign i_a2p1_last      = r_tlast[1];
    //    
    //    
    ////
    //


    AAI_TOP #(
    .BYPASS_MODE(1),
    .PL2AIE_EN(PL2AIE_EN),
    .AIE2PL_EN(AIE2PL_EN),
    //    .PL2AIE_SYNC_STATE_EN(PL2AIE_SYNC_STATE_EN),
    .PL2AIE_DATA_SIZE(PL2AIE_DATA_SIZE),
    .AIE2PL_DATA_SIZE(AIE2PL_DATA_SIZE),
    .TKEEP_SIZE(TKEEP_SIZE),
    .PL_HEADER_EN(PL_HEADER_EN),
    .AIE_HEADER_EN(AIE_HEADER_EN),
    .PL_HEADER_SIZE(PL_HEADER_SIZE),
    .AIE_HEADER_SIZE(AIE_HEADER_SIZE),
    .PL_DATA_PACKET_SIZE(PL_DATA_PACKET_SIZE_STREAM0),
    .AIE_DATA_PACKET_SIZE(AIE_DATA_PACKET_SIZE),
    .PL2AIE_ASYNC_FIFO_DEPTH(PL2AIE_ASYNC_FIFO_DEPTH),
    .PL2AIE_SYNC_FIFO_DEPTH(PL2AIE_SYNC_FIFO_DEPTH),
    .AIE2PL_ASYNC_FIFO_DEPTH(AIE2PL_ASYNC_FIFO_DEPTH),
    .AIE2PL_SYNC_FIFO_DEPTH(AIE2PL_SYNC_FIFO_DEPTH)
    ) AAI_TOP_instance_stream0 (
        .pl2aie_pl_clk      (i_clk),
        .pl2aie_aie_clk     (i_aie_clk),
        .aie2pl_pl_clk      (i_clk),
        .aie2pl_aie_clk     (i_aie_clk),
        .pl_reset           (1'b0),
        .aie_reset          (1'b0),
        .cpu_wen            ( 1'b0),
        .cpu_waddr          (16'b0),
        .cpu_wdata          (32'b0),
        .i_pl_data          ({r_tdat_0M,r_tdat_0L}),
        .i_pl_dvld          (r_tvld[0]),
        .i_pl_last          (r_tlast[0]),
        .i_pl_keep          (r_tkeep0),
        .i_head_data        (64'd0),
        .i_head_valid       (1'b0),
        .i_p2a_ready        (i_p2a0_ready),
        .o_p2a_valid        (o_p2a0_valid),
        .o_p2a_data         (o_p2a0_data),
        .o_p2a_last         (o_p2a0_last),
        .o_p2a_keep         (o_p2a0_keep),
        .o_a2p_ready        (o_a2p0_ready),
        .i_a2p_valid        (i_a2p0_valid),
        .i_a2p_data         (i_a2p0_data),
        .i_a2p_last         (i_a2p0_last),
        .i_a2p_ready        (1'b0), //unused
        .o_a2p_data         (w_st0_a2p_data),
        .o_a2p_dvld         (w_st0_a2p_dvld), //w_st0_a2p_dvld),
        .o_a2p_last         (w_st0_a2p_last), //gen from AAI using AIE_DATA_PACKET_SIZE
        .o_a2p_head_data    (),
        .o_a2p_head_valid   ()
    );
    AAI_TOP #(
    .BYPASS_MODE(1),
    .PL2AIE_EN(1),
    .AIE2PL_EN(1),
    //    .PL2AIE_SYNC_STATE_EN(0),
    .PL2AIE_DATA_SIZE(PL2AIE_DATA_SIZE),
    .AIE2PL_DATA_SIZE(AIE2PL_DATA_SIZE),
    .TKEEP_SIZE(TKEEP_SIZE),
    .PL_HEADER_EN(PL_HEADER_EN),
    .AIE_HEADER_EN(AIE_HEADER_EN),
    .PL_HEADER_SIZE(PL_HEADER_SIZE),
    .AIE_HEADER_SIZE(AIE_HEADER_SIZE),
    .PL_DATA_PACKET_SIZE(PL_DATA_PACKET_SIZE_STREAM1),
    .AIE_DATA_PACKET_SIZE(AIE_DATA_PACKET_SIZE),
    .PL2AIE_ASYNC_FIFO_DEPTH(PL2AIE_ASYNC_FIFO_DEPTH),
    .PL2AIE_SYNC_FIFO_DEPTH(PL2AIE_SYNC_FIFO_DEPTH),
    .AIE2PL_ASYNC_FIFO_DEPTH(AIE2PL_ASYNC_FIFO_DEPTH),
    .AIE2PL_SYNC_FIFO_DEPTH(AIE2PL_SYNC_FIFO_DEPTH)
    ) AAI_TOP_instance_stream1 (
        .pl2aie_pl_clk      (i_clk),
        .pl2aie_aie_clk     (i_aie_clk),
        .aie2pl_pl_clk      (i_clk),
        .aie2pl_aie_clk     (i_aie_clk),
        .pl_reset           (1'b0),
        .aie_reset          (1'b0),
        .cpu_wen            ( 1'b0),
        .cpu_waddr          (16'b0),
        .cpu_wdata          (32'b0),
        .i_pl_data          ({r_tdat_1M,r_tdat_1L}),
        .i_pl_dvld          (r_tvld[1]),
        .i_pl_last          (r_tlast[1]),
        .i_pl_keep          (r_tkeep1),
        .i_head_data        (64'd0),
        .i_head_valid       (1'b0),
        .i_p2a_ready        (i_p2a1_ready),
        .o_p2a_valid        (o_p2a1_valid),
        .o_p2a_data         (o_p2a1_data),
        .o_p2a_last         (o_p2a1_last),
        .o_p2a_keep         (o_p2a1_keep),
        .o_a2p_ready        (o_a2p1_ready),
        .i_a2p_valid        (i_a2p1_valid),
        .i_a2p_data         (i_a2p1_data),
        .i_a2p_last         (i_a2p1_last),
        .i_a2p_ready        (1'b0), //unused
        .o_a2p_data         (w_st1_a2p_data),
        .o_a2p_dvld         (w_st1_a2p_dvld), //w_st1_a2p_dvld),
        .o_a2p_last         (w_st1_a2p_last), //gen from AAI using AIE_DATA_PACKET_SIZE
        .o_a2p_head_data    (),
        .o_a2p_head_valid   ()
    );

    reg r_sym_idx_evenodd;
    reg r_latched_sym_idx_evenodd;
    wire w_expected_aie_symtick;

    always @(posedge i_clk)
    begin
        if(i_fft_buf_in_vld_frm)
            r_sym_idx_evenodd <= 1'b0;
        else if(i_td_sym_tick)
            r_sym_idx_evenodd <= ~r_sym_idx_evenodd;
        else
            r_sym_idx_evenodd <= r_sym_idx_evenodd;
    end

    ylib_pshift #(
    .BW_SHIFT($clog2(1590-10+1))
    ) ylib_pshift_delay_symtick (
        .i_clk(i_clk),
        .i_shift(11'd2), //11'd1580
        .i_in(i_td_sym_tick),
        .o_out(w_expected_aie_symtick)
    );

    always @(posedge i_clk)
    begin
        if(w_expected_aie_symtick)
            r_latched_sym_idx_evenodd <= r_sym_idx_evenodd;
    end


    //reg             r_wea_even  ;
    //reg [63-1:0]    r_dina_even ;
    //reg             r_addra_even;
    //reg             r_web_even  ;
    //reg [63-1:0]    r_dinb_even ;
    //reg             r_addrb_even;
    //
    //reg             r_wea_odd   ;
    //reg [63-1:0]    r_dina_odd  ;
    //reg             r_addra_odd ;
    //reg             r_web_odd   ;
    //reg [63-1:0]    r_dinb_odd  ;
    //reg             r_addrb_odd ;

    reg [1:0]       r_wea       ;
    reg [1:0]       r_ena       ;
    reg [64-1:0]    r_dina[1:0] ;
    reg [12-1:0]    r_addra[1:0];
    reg [12-1:0]    rr_addra[1:0];
    reg [1:0]       r_web       ;
    reg [1:0]       r_enb       ;
    reg [64-1:0]    r_dinb[1:0] ;
    reg [12-1:0]    r_addrb[1:0];
    reg [12-1:0]    rr_addrb[1:0];
    reg [3-1:0]     r_addra_vld_cnt;
    reg [12-1:0]    r_addra_offset;
    reg [3-1:0]     r_addrb_vld_cnt;
    reg [12-1:0]    r_addrb_offset;
    wire [64-1:0]   w_doutb[1:0];
    wire [(NUM_RX)-1:0] w_fd_vld;
    reg [OB+1-1:0]    r_fd_i  ;
    reg [OB+1-1:0]    r_fd_q  ;
    wire [OB-1:0]   w_fd_i  ;
    wire [OB-1:0]   w_fd_q  ;
    reg [OB+1-1:0]    rr_fd_i  ;
    reg [OB+1-1:0]    rr_fd_q  ;
    reg [OB+1-1:0]    rrr_fd_i  ;
    reg [OB+1-1:0]    rrr_fd_q  ;
    reg             f_wnorm_sym;
    reg             f_d_wnorm_sym;
    reg             f_rnorm_sym;

    always @(posedge i_clk)
    begin
        if(!r_sym_idx_evenodd) //r_latched_sym_idx_evenodd)    
            begin
                if(w_st0_a2p_dvld)
                    begin
                        r_wea[0]    <=  1'b1;
                        //r_web[0]    <=  1'b1;
                        r_ena[0]    <=  1'b1;
                        //r_enb[0]    <=  1'b1;
                        r_dina[0]   <=  w_st0_a2p_data; //{Q,I}
                        //r_dinb[0]   <=  w_st1_a2p_data; //{Q,I}
                    end
                else
                    begin
                        r_wea[0]    <=  1'b0;
                        //r_web[0]    <=  1'b0;
                        r_ena[0]    <=  1'b0;
                        //r_enb[0]    <=  1'b0;
                        r_dina[0]   <=  w_st0_a2p_data; //{Q,I}
                        //r_dinb[0]   <=  w_st1_a2p_data; //{Q,I}
                    end
                    
                if(w_st1_a2p_dvld)
                    begin
                        //r_wea[0]    <=  1'b1;
                        r_web[0]    <=  1'b1;
                        //r_ena[0]    <=  1'b1;
                        r_enb[0]    <=  1'b1;
                        //r_dina[0]   <=  w_st0_a2p_data; //{Q,I}
                        r_dinb[0]   <=  w_st1_a2p_data; //{Q,I}
                    end
                else
                    begin
//                        r_wea[0]    <=  1'b0;
                        r_web[0]    <=  1'b0;
//                        r_ena[0]    <=  1'b0;
                        r_enb[0]    <=  1'b0;
//                        r_dina[0]   <=  w_st0_a2p_data; //{Q,I}
                        r_dinb[0]   <=  w_st1_a2p_data; //{Q,I}
                    end


                if(w_expected_aie_symtick ) //| w_st0_a2p_last)  
                    begin
                        r_addra[0]  <=  12'd0;
//                        r_addrb[0]  <=  12'd6;
                    end
                else if(w_st0_a2p_last ) //| w_st0_a2p_last)  
                    begin
                        r_addra[0]  <=  12'b1000_0000_0000;
//                        r_addrb[0]  <=  12'b1000_0000_0110;
                    end
                else if(w_st0_a2p_dvld)
                    begin
                        r_addra[0]  <=  r_addra[0] + 12'd1 + r_addra_offset;
//                        if(r_addrb[0]==12'b1111_1111_1111)
//                            r_addrb[0]  <=  r_addrb[0] ;
//                        else
//                            r_addrb[0]  <=  r_addrb[0] + 12'd1 + r_addrb_offset;
                    end
                else
                    begin
                        r_addra[0]  <=  r_addra[0];
//                        r_addrb[0]  <=  r_addrb[0];
                    end

                if(w_expected_aie_symtick ) //| w_st0_a2p_last)  
                    begin
//                        r_addra[0]  <=  12'd0;
                        r_addrb[0]  <=  12'd6;
                    end
                else if(w_st1_a2p_last ) //| w_st0_a2p_last)  
                    begin
//                        r_addra[0]  <=  12'b1000_0000_0000;
                        r_addrb[0]  <=  12'b1000_0000_0110;
                    end
                else if(w_st1_a2p_dvld)
                    begin
//                        r_addra[0]  <=  r_addra[0] + 12'd1 + r_addra_offset;
                        if(r_addrb[0]==12'b1111_1111_1111)
                            r_addrb[0]  <=  r_addrb[0] ;
                        else
                            r_addrb[0]  <=  r_addrb[0] + 12'd1 + r_addrb_offset;
                    end
                else
                    begin
//                        r_addra[0]  <=  r_addra[0];
                        r_addrb[0]  <=  r_addrb[0];
                    end


                rr_addra[0]  <=  r_addra[0];
                rr_addrb[0]  <=  r_addrb[0];
            end
        else
            begin
                if(|i_sc_vld)
                    begin
                        r_ena[0]    <=  1'b0;
                        r_enb[0]    <=  f_rnorm_sym & 1'b1;

                        r_addrb[0]  <= r_addrb[0] + 12'd1;
                        rr_addrb[0] <= {i_sc_vld[1],r_addrb[0][11:1]};
                    end
                else
                    begin
                        r_ena[0]    <=  1'b0;
                        r_enb[0]    <=  1'b0;

                        r_addrb[0]  <=  12'd0;
                        rr_addrb[0] <=  12'd0;
                    end
            end
    end

    always @(posedge i_clk)
    begin
        if(r_sym_idx_evenodd) //r_latched_sym_idx_evenodd)    
            begin
                if(w_st0_a2p_dvld)
                    begin
                        r_wea[1]    <=  1'b1;
//                        r_web[1]    <=  1'b1;
                        r_ena[1]    <=  1'b1;
//                        r_enb[1]    <=  1'b1;
                        r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
//                        r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
                    end
                else
                    begin
                        r_wea[1]    <=  1'b0;
//                        r_web[1]    <=  1'b0;
                        r_ena[1]    <=  1'b0;
//                        r_enb[1]    <=  1'b0;
                        r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
//                        r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
                    end
                if(w_st1_a2p_dvld)
                    begin
//                        r_wea[1]    <=  1'b1;
                        r_web[1]    <=  1'b1;
//                        r_ena[1]    <=  1'b1;
                        r_enb[1]    <=  1'b1;
//                        r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
                        r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
                    end
                else
                    begin
//                        r_wea[1]    <=  1'b0;
                        r_web[1]    <=  1'b0;
//                        r_ena[1]    <=  1'b0;
                        r_enb[1]    <=  1'b0;
//                        r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
                        r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
                    end

                if(w_expected_aie_symtick ) //| w_st0_a2p_last)  
                    begin
                        r_addra[1]  <=  12'd0;
//                        r_addrb[1]  <=  12'd6;
                    end
                else if(w_st0_a2p_last ) //| w_st0_a2p_last)  
                    begin
                        r_addra[1]  <=  12'b1000_0000_0000;
//                        r_addrb[1]  <=  12'b1000_0000_0110;
                    end
                else if(w_st0_a2p_dvld)
                    begin
                        r_addra[1]  <=  r_addra[1] + 12'd1 + r_addra_offset;
//                        if(r_addrb[1]==12'b1111_1111_1111)
//                            r_addrb[1]  <=  r_addrb[1] ;
//                        else
//                            r_addrb[1]  <=  r_addrb[1] + 12'd1 + r_addrb_offset;
                    end
                else
                    begin
                        r_addra[1]  <=  r_addra[1];
//                        r_addrb[1]  <=  r_addrb[1];
                    end
                    
                if(w_expected_aie_symtick ) //| w_st0_a2p_last)  
                    begin
//                        r_addra[1]  <=  12'd0;
                        r_addrb[1]  <=  12'd6;
                    end
                else if(w_st1_a2p_last ) //| w_st0_a2p_last)  
                    begin
//                        r_addra[1]  <=  12'b1000_0000_0000;
                        r_addrb[1]  <=  12'b1000_0000_0110;
                    end
                else if(w_st1_a2p_dvld)
                    begin
//                        r_addra[1]  <=  r_addra[1] + 12'd1 + r_addra_offset;
                        if(r_addrb[1]==12'b1111_1111_1111)
                            r_addrb[1]  <=  r_addrb[1] ;
                        else
                            r_addrb[1]  <=  r_addrb[1] + 12'd1 + r_addrb_offset;
                    end
                else
                    begin
//                        r_addra[1]  <=  r_addra[1];
                        r_addrb[1]  <=  r_addrb[1];
                    end

                rr_addra[1]  <=  r_addra[1];
                rr_addrb[1]  <=  r_addrb[1];
            end
            
        else
            begin
                if(|i_sc_vld)
                    begin
                        r_ena[1]    <=  1'b0;
                        r_enb[1]    <=  f_rnorm_sym & 1'b1;

                        r_addrb[1]  <= r_addrb[1] + 12'd1;
                        rr_addrb[1] <= {i_sc_vld[1],r_addrb[1][11:1]};
                    end
                else
                    begin
                        r_ena[1]    <=  1'b0;
                        r_enb[1]    <=  1'b0;

                        r_addrb[1]  <=  12'd0;
                        rr_addrb[1] <=  12'd0;
                    end
            end
    end

    //always @(posedge i_clk)
    //begin
    //    if(r_latched_sym_idx_evenodd)    
    //    begin
    //        if(w_st0_a2p_dvld)
    //        begin
    //            r_wea[1]    <=  1'b1;
    //            r_web[1]    <=  1'b1;
    //            r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
    //            r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
    //        end
    //        else
    //        begin
    //            r_wea[1]    <=  1'b0;
    //            r_web[1]    <=  1'b0;
    //            r_dina[1]   <=  w_st0_a2p_data; //{Q,I}
    //            r_dinb[1]   <=  w_st1_a2p_data; //{Q,I}
    //        end
    //    end        
    //end

    always @(posedge i_clk)
    begin
        if(w_expected_aie_symtick | w_st0_a2p_last)
            begin
                r_addra_vld_cnt <= 3'd0;
                r_addra_offset  <= 12'd0;
            end
        else if(w_st0_a2p_dvld)
            begin
                if(r_addra_vld_cnt == 3'd4)
                    begin
                        r_addra_vld_cnt <= r_addra_vld_cnt + 3'd1;
                        r_addra_offset  <= 12'd6;
                    end
                else if(r_addra_vld_cnt == 3'd5)
                    begin
                        r_addra_vld_cnt <= 3'd0;
                        r_addra_offset  <= 12'd0;
                    end
                else
                    begin
                        r_addra_vld_cnt <= r_addra_vld_cnt + 3'd1;
                        r_addra_offset  <= 12'd0;
                    end
            end
        else
            begin
                r_addra_vld_cnt <= r_addra_vld_cnt;
                r_addra_offset  <= 12'd0;
            end
    end

    always @(posedge i_clk)
    begin
        if(w_expected_aie_symtick | w_st1_a2p_last)
            begin
                r_addrb_vld_cnt <= 3'd0;
                r_addrb_offset  <= 12'd0;
            end
        else if(w_st1_a2p_dvld)
            begin
                if(r_addrb_vld_cnt == 3'd4)
                    begin
                        r_addrb_vld_cnt <= r_addrb_vld_cnt + 3'd1;
                        r_addrb_offset  <= 12'd6;
                    end
                else if(r_addrb_vld_cnt == 3'd5)
                    begin
                        r_addrb_vld_cnt <= 3'd0;
                        r_addrb_offset  <= 12'd0;
                    end
                else
                    begin
                        r_addrb_vld_cnt <= r_addrb_vld_cnt + 3'd1;
                        r_addrb_offset  <= 12'd0;
                    end
            end
        else
            begin
                r_addrb_vld_cnt <= r_addrb_vld_cnt;
                r_addrb_offset  <= 12'd0;
            end
    end







    ylib_rams_tdp_8byte #(
    .AWIDTH(buf_AW) // Address Width
    ,.NUM_COL(8) // Number of columns
    ,.DWIDTH(64) // Data Width, (Byte * NUM_COL) 
    ,.NBPIPE(buf_num_pipe) // Number of pipeline Registers
    ,.VENDOR(VENDOR)
    ) u_ulfe_fft_buf_evenSYM (
        .clk(i_clk),
        .rsta(1'b0),
        .wea           ({8{r_wea[0]}}),
        .regcea(1'b0),
        .mem_ena       (r_ena[0]),
        .dina          (r_dina[0]),
        .addra         (rr_addra[0]),
        .douta(),
        .rstb(1'b0),
        .web           ({8{r_web[0]}}),
        .regceb(1'b1),
        .mem_enb       (r_enb[0]),
        .dinb          (r_dinb[0]),
        .addrb         (rr_addrb[0]),
        .doutb         (w_doutb[0] )
    );

    ylib_rams_tdp_8byte #(
    .AWIDTH(buf_AW) // Address Width
    ,.NUM_COL(8) // Number of columns
    ,.DWIDTH(64) // Data Width, (Byte * NUM_COL) 
    ,.NBPIPE(buf_num_pipe) // Number of pipeline Registers
    ,.VENDOR(VENDOR)
    ) u_ulfe_fft_buf_oddSYM (
        .clk(i_clk),
        .rsta(1'b0),
        .wea           ({8{r_wea[1]}}),
        .regcea(1'b0),
        .mem_ena       (r_ena[1]),
        .dina          (r_dina[1]),
        .addra         (rr_addra[1]),
        .douta(),
        .rstb(1'b0),
        .web           ({8{r_web[1]}}),
        .regceb(1'b1),
        .mem_enb       (r_enb[1]),
        .dinb          (r_dinb[1]),
        .addrb         (rr_addrb[1]),
        .doutb         (w_doutb[1] )
    );



    ylib_reg #(
    .WIDTH(NUM_RX),
    .DEPTH(6+buf_num_pipe)
    ) u_ylib_reg_sc_vld (
        .i_clk(i_clk),
        .i_in(i_sc_vld),
        .o_out(w_fd_vld)
    );


    wire [3:0] w_bufout_symbol_idx;
    wire  w_bufout_symbol_sync;
    ref_vsync_gen ref_vsync_gen_instance (
        .i_clk          (i_clk),
        .i_mu           (3'd1), // 0:15, 1:30, 2:60 ... TBD
//        .i_retard       (22'd4), // min dly 2clk
        .i_frame_sync   (i_fft_buf_out_vld_frm),
        .i_en           (1'b1),
        .o_frame_sync   (),
        .o_subfrm_sync  (),
        .o_slot_sync    (),
        .o_symbol_sync  (w_bufout_symbol_sync),
        .o_subfrm       (),
        .o_slot         (),
        .o_symbol       (w_bufout_symbol_idx)
    );




    reg r_doutb_ML;
    wire w_doutb_ML;

    always @(posedge i_clk)
    begin
        if(!w_bufout_symbol_idx[0])
            r_doutb_ML <= r_addrb[0][0];
        else
            r_doutb_ML <= r_addrb[1][0];
    end

    ylib_reg #(
    .WIDTH(1),
    .DEPTH(4)
    ) u_ylib_reg_wdoutbML (
        .i_clk(i_clk),
        .i_in(r_doutb_ML),
        .o_out(w_doutb_ML)
    );

    always @(posedge i_clk)
    begin
        if(!w_bufout_symbol_idx[0])
            begin
                if(w_doutb_ML)
                    begin
                        r_fd_i  <= w_doutb[0][16*3-1-:16];
                        r_fd_q  <= w_doutb[0][16*4-1-:16];
                    end
                else
                    begin
                        r_fd_i  <= w_doutb[0][16*1-1-:16];
                        r_fd_q  <= w_doutb[0][16*2-1-:16];
                    end
            end
        else
            begin
                if(w_doutb_ML)
                    begin
                        r_fd_i  <= w_doutb[1][16*3-1-:16];
                        r_fd_q  <= w_doutb[1][16*4-1-:16];
                    end
                else
                    begin
                        r_fd_i  <= w_doutb[1][16*1-1-:16];
                        r_fd_q  <= w_doutb[1][16*2-1-:16];
                    end
            end

                rr_fd_i  <= r_fd_i;    
                rr_fd_q  <= r_fd_q;
            //    rrr_fd_i  <= rr_fd_i;    
            //    rrr_fd_q  <= rr_fd_q;

    end

    ylib_sat
    #(
    .NUM_STREAM   (2          )
    ,.DI_BW        (16         )
    ,.DO_BW        (15         )
    ,.SAT_TYPE     ("SYMMETRIC")
    )ylib_sat_fft_o
    (
        .i_clk      (i_clk)
        ,.i_in_en    (1'b1)
        ,.i_in       ({rr_fd_i,rr_fd_q})
        ,.o_out_en   ()
        ,.o_out      ({w_fd_i,w_fd_q})
    );



    assign o_fd_vld = f_rnorm_sym==1'b1 ? w_fd_vld : {NUM_RX{1'b0}};
    assign o_fd_i   = w_fd_i;
    assign o_fd_q   = w_fd_q;




    ////Effective Symbol Buffer Control


    always @(posedge i_clk)
    begin
        if(i_td_sym_tick && (|i_td_vld))
            begin
                f_wnorm_sym <= 1'b1;
                f_d_wnorm_sym <= f_wnorm_sym;
            end
        else if(i_td_sym_tick && ~(|i_td_vld))
            begin
                f_wnorm_sym <= 1'b0;
                f_d_wnorm_sym <= f_wnorm_sym;
            end
        else
            begin
                f_wnorm_sym <= f_wnorm_sym;
                f_d_wnorm_sym <= f_d_wnorm_sym;
            end
    end

    always @(posedge i_clk)
    begin
        //    if(w_bufout_symbol_sync)
        //    begin
        f_rnorm_sym <=  f_d_wnorm_sym;
        //    end
    end


always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_st1_a2p_last  <= 16'd0;
    else if(w_st1_a2p_last)
        r_cnt_st1_a2p_last  <= r_cnt_st1_a2p_last+16'd1;
    else
        r_cnt_st1_a2p_last  <= r_cnt_st1_a2p_last;
end
always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_st0_a2p_last  <= 16'd0;
    else if(w_st0_a2p_last)
        r_cnt_st0_a2p_last  <= r_cnt_st0_a2p_last+16'd1;
    else
        r_cnt_st0_a2p_last  <= r_cnt_st0_a2p_last;
end

assign w_cnt_st01_a2p_last = {r_cnt_st0_a2p_last,r_cnt_st1_a2p_last};


always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_st1_a2p_0dat  <= 16'd0;
    else if(w_st1_a2p_dvld)
        if(w_st1_a2p_data[63:32]==32'd0 & w_st1_a2p_data[31:0]==32'd0 )
            r_cnt_st1_a2p_0dat  <= r_cnt_st1_a2p_0dat+16'd2;
        else if(w_st1_a2p_data[63:32]==32'd0 ^ w_st1_a2p_data[31:0]==32'd0 )
            r_cnt_st1_a2p_0dat  <= r_cnt_st1_a2p_0dat+16'd1;
        else
            r_cnt_st1_a2p_0dat  <= r_cnt_st1_a2p_0dat;
    else
        r_cnt_st1_a2p_0dat  <= r_cnt_st1_a2p_0dat;
end
always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_st0_a2p_0dat  <= 16'd0;
    else if(w_st0_a2p_dvld)
        if(w_st0_a2p_data[63:32]==32'd0 & w_st0_a2p_data[31:0]==32'd0 )
            r_cnt_st0_a2p_0dat  <= r_cnt_st0_a2p_0dat+16'd2;
        else if(w_st0_a2p_data[63:32]==32'd0 ^ w_st0_a2p_data[31:0]==32'd0 )
            r_cnt_st0_a2p_0dat  <= r_cnt_st0_a2p_0dat+16'd1;
        else
            r_cnt_st0_a2p_0dat  <= r_cnt_st0_a2p_0dat;
    else
        r_cnt_st0_a2p_0dat  <= r_cnt_st0_a2p_0dat;
end

assign w_cnt_st01_a2p_0dat = {r_cnt_st0_a2p_0dat,r_cnt_st1_a2p_0dat};

always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_fd_1dat  <= 16'd0;
    else if(w_fd_vld[1])
        if({w_fd_i,w_fd_q}==32'd0 )
            r_cnt_fd_1dat  <= r_cnt_fd_1dat+16'd1;
    else
        r_cnt_fd_1dat  <= r_cnt_fd_1dat;
end
always @(posedge i_clk)
begin
    if(i_rst)
        r_cnt_fd_0dat  <= 16'd0;
    else if(w_fd_vld[0])
        if({w_fd_i,w_fd_q}==32'd0 )
            r_cnt_fd_0dat  <= r_cnt_fd_0dat+16'd1;
    else
        r_cnt_fd_0dat  <= r_cnt_fd_0dat;
end

assign w_cnt_fd_01dat = {r_cnt_fd_0dat,r_cnt_fd_1dat};

assign o_cnt_st01_a2p_last =  w_cnt_st01_a2p_last;
assign o_cnt_st01_a2p_0dat =  w_cnt_st01_a2p_0dat;
assign o_cnt_fd_01dat      =  w_cnt_fd_01dat     ;




endmodule

