// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : cts
//  Author       : Song, Moon-Gun
//  Description  : Cyclic Time Shift
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ulfe_cts 
#(
      parameter IB          =  15    // Input Bitwidth
    , parameter OB          =  15    // Output Bitwidth
    , parameter OC          =  1     // Overclocking Factor
    , parameter OVS         =  2**OC

)(
      input   wire                      i_clk                      // Clock                                         
    , input   wire                      i_frm_tick
    , input   wire                      i_slt_tick
    , input   wire                      i_sym_tick
    , input   wire  [          6-1:0]   i_sltIdx 
    , input   wire  [          4-1:0]   i_symIdx                    
    , input   wire                      i_bcf_en
    , input   wire                      i_tdd_mode                    
    , input   wire  [     OVS* 1-1:0]   i_cts_on                   // CTS On
    , input   wire  [        OVS-1:0]   i_calBypassFlag            // cal bypass flag
    , input   wire  [     OVS* 1-1:0]   i_cts_shft_vld             // CTS Input Phase Enable
    , input   wire  [     OVS*12-1:0]   i_cts_shft                 // CTS Input phase                    
    , input   wire  [     OVS* 1-1:0]   i_CTS_in_vld
    , input   wire  [         IB-1:0]   i_CTS_in_I                    // CTS I Input 
    , input   wire  [         IB-1:0]   i_CTS_in_Q                    // CTS Q Input                    
    , output  reg   [     OVS* 1-1:0]   o_CTS_out_vld   
    , output  reg   [         OB-1:0]   o_CTS_out_I                    // CTS I out 
    , output  reg   [         OB-1:0]   o_CTS_out_Q                    // CTS Q out     
    , output  wire                      o_bcf_en
    , output  wire                      o_tdd_mode                                      
    , output  wire                      o_frm_tick
    , output  wire                      o_slt_tick
    , output  wire                      o_sym_tick
    , output  wire  [          6-1:0]   o_sltIdx 
    , output  wire  [          4-1:0]   o_symIdx                                        
//    , output  wire  [         32-1:0]   o_CTS_latency
);

localparam TO_CMP_EXP         = 5'd2 ;
localparam CMPLEX_EXP_LATENCY = 5'd4 ;
localparam CMUL_LATENCY       = 5'd6 ;
localparam CSHFTD_SAT_LATENCY = 5'd3 ;
localparam CMPLEX_EXP_BW      = 5'd16;
localparam PW                 = 5'd12;     // bitwidth of phase
localparam DLY_ME             = (TO_CMP_EXP + CMPLEX_EXP_LATENCY+CMUL_LATENCY+CSHFTD_SAT_LATENCY+5'd1);

wire                                 cts_vld_d1              ;
wire        [                  7:0]  cts_last                ;
wire                                 cts_vld_d2              ;
wire                                 cts_vld_d3              ;
wire                                 cts_vld_d4              ;            
wire        [           OVS* 1-1:0]  w_cts_vld               ;
wire        [           OVS* 1-1:0]  w_cts_vld_d             ;
wire        [               IB-1:0]  w_cts_i                 ;
wire        [               IB-1:0]  w_cts_q                 ;            
wire                                 w_cos_vld               ;
wire signed [    CMPLEX_EXP_BW-1:0]  w_p_cos                 ;
wire signed [    CMPLEX_EXP_BW-1:0]  w_n_sin                 ;
wire signed [    CMPLEX_EXP_BW-1:0]  w_cmul_cos              ;
wire signed [    CMPLEX_EXP_BW-1:0]  w_cmul_sin              ;                                     
wire                                 w_cmult_vld             ;
wire        [IB+CMPLEX_EXP_BW+1-1:0] w_cmult_i               ;
wire        [IB+CMPLEX_EXP_BW+1-1:0] w_cmult_q               ;            
wire                                 w_conv_vld              ;
wire        [                OB-1:0] w_conv_i                ;
wire        [                OB-1:0] w_conv_q                ;
reg         [                12-1:0] r_shft       [OVS-1:0]  ;
reg         [                 1-1:0] r_cts_vld_d             ;
reg         [                IB-1:0] r_cts_i_d               ;   
reg         [                IB-1:0] r_cts_q_d               ;   
wire        [               OVS-1:0] get_cts_on              ;
wire        [               OVS-1:0] w_cts_shft_vld_d1       ;
wire        [            12*OVS-1:0] get_cts_shft            ;
reg                                  curr_cts_on             ;
wire                                 cts_init                ;
wire                                 cts_idle                ;
wire        [               OVS-1:0] w_CTS_in_vld            ;

//assign o_CTS_latency = DLY_ME;

genvar l;
for (l = 0; l < OVS; l = l + 1) begin : get_cts_on_wire

assign get_cts_on[l] = i_cts_on[l] & (~i_calBypassFlag[l]);

end

ylib_reg #(.WIDTH(OVS*12) ,.DEPTH(1) ) reg_cts_shft ( .i_clk(i_clk), .i_in(i_cts_shft  ), .o_out(get_cts_shft  ));

ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) in_vld_dly1 ( .i_clk(i_clk),.i_in( |i_CTS_in_vld             ), .o_out(cts_vld_d1 ) );
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) in_vld_dly2 ( .i_clk(i_clk),.i_in((|i_CTS_in_vld)||cts_vld_d1), .o_out(cts_vld_d2 ) );
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) in_vld_dly3 ( .i_clk(i_clk),.i_in((|i_CTS_in_vld)||cts_vld_d2), .o_out(cts_vld_d3 ) );
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) in_vld_dly4 ( .i_clk(i_clk),.i_in((|i_CTS_in_vld)||cts_vld_d3), .o_out(cts_vld_d4 ) );

ylib_reg #(.WIDTH(OVS) ,.DEPTH(1)) shft_vld_dly ( .i_clk(i_clk),.i_in(i_cts_shft_vld), .o_out(w_cts_shft_vld_d1));

ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly1( .i_clk(i_clk),.i_in( |i_CTS_in_vld ), .o_out(cts_last[0]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly2( .i_clk(i_clk),.i_in( cts_last[0]   ), .o_out(cts_last[1]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly3( .i_clk(i_clk),.i_in( cts_last[1]   ), .o_out(cts_last[2]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly4( .i_clk(i_clk),.i_in( cts_last[2]   ), .o_out(cts_last[3]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly5( .i_clk(i_clk),.i_in( cts_last[3]   ), .o_out(cts_last[4]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly6( .i_clk(i_clk),.i_in( cts_last[4]   ), .o_out(cts_last[5]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly7( .i_clk(i_clk),.i_in( cts_last[5]   ), .o_out(cts_last[6]));
ylib_reg #(.WIDTH(1  ) ,.DEPTH(1)) cts_last_dly8( .i_clk(i_clk),.i_in( cts_last[6]   ), .o_out(cts_last[7]));

ylib_reg #(.WIDTH(OVS) ,.DEPTH(1)) cts_vld_dly  ( .i_clk(i_clk),.i_in( i_CTS_in_vld  ), .o_out(w_CTS_in_vld));

//syncTo vld
assign cts_init = (|i_CTS_in_vld) && (!cts_vld_d4) ;

assign cts_idle = (cts_last[3:0] == 4'b1000);

reg [12-1:0] r_shft_8 [OVS-1:0] ;

integer n;
//initial begin
//  for(n=0; n<OVS; n=n+1) r_shft[n]    <= 0;
//  for(n=0; n<OVS; n=n+1) r_shft_8[n]  <= 0;
//end

genvar i;
generate
for (i = 0; i < OVS; i = i + 1) begin : CTS_INPUT_CTRL

// syncTo vld+1
always @ (posedge i_clk) begin
  if(cts_init) begin
      r_shft[i] <= 0;
    r_shft_8[i] <= 0;
  end
  else if(i_CTS_in_vld[i] & cts_last[0]) begin //OVS-1]) begin
    r_shft[i]   <= get_cts_shft[12*(i+1)-1:12*i] +   r_shft[i][12-1:0];
    r_shft_8[i] <= get_cts_shft[12*(i+1)-1:12*i] + r_shft_8[i][12-1:0];
  end
end

end
endgenerate

reg  [OC-1:0] r_shft_cnt     ;
reg           r_shft_vld_1d  ;
reg  [12-1:0] r_shft_1d      ;
wire [OC-1:0] w_shft_cnt;

// syncTo vld+2
always @ (posedge i_clk) begin
   if(i_sym_tick) begin
       r_shft_cnt <= 0;
   end
   else if(cts_idle) begin
       r_shft_cnt <= r_shft_cnt + 1;
   end
end

always @ (posedge i_clk) begin
  r_shft_vld_1d <= |w_CTS_in_vld;
end

reg [  8-1:0] func_in1  ;

generate
for(i=0; i<OVS; i=i+1) begin: PHASE_SEL
  always @ (posedge i_clk) begin
    func_in1[i] <= (i_CTS_in_vld[i]&&get_cts_on[i])? 1'b1 : 1'b0;
  end
end
endgenerate

always @ (posedge i_clk) begin
    if(OVS==8) 
    begin
        if(|w_CTS_in_vld) 
        begin
            if(func_in1[0]==1'b1)
                r_shft_1d <= r_shft_8[0];
            else if(func_in1[1]==1'b1)
                r_shft_1d <= r_shft_8[1];
            else if(func_in1[2]==1'b1)
                r_shft_1d <= r_shft_8[2];
            else if(func_in1[3]==1'b1)
                r_shft_1d <= r_shft_8[3];
            else if(func_in1[4]==1'b1)
              r_shft_1d <= r_shft_8[4];
            else if(func_in1[5]==1'b1)
              r_shft_1d <= r_shft_8[5];
            else if(func_in1[6]==1'b1)
              r_shft_1d <= r_shft_8[6];  
            else if(func_in1[7]==1'b1)
              r_shft_1d <= r_shft_8[7]; 
            else
                r_shft_1d <= 0;   
        end
        else
            r_shft_1d <= 0; 
    end
    else if(OVS==4) 
    begin        
        if(|w_CTS_in_vld) 
        begin
            if(func_in1[0]==1'b1)
                r_shft_1d <= r_shft_8[0];
            else if(func_in1[1]==1'b1)
                r_shft_1d <= r_shft_8[1];
            else if(func_in1[2]==1'b1)
                r_shft_1d <= r_shft_8[2];
            else if(func_in1[3]==1'b1)
                r_shft_1d <= r_shft_8[3];
            else
                r_shft_1d <= 0;   
      end
      else
        r_shft_1d <= 0; 
    end
    else if(OVS==2) 
    begin        
        if(|w_CTS_in_vld) 
        begin
            if(func_in1[0]==1'b1)
                r_shft_1d <= r_shft_8[0];
            else if(func_in1[1]==1'b1)
                r_shft_1d <= r_shft_8[1];
            else
                r_shft_1d <= 0;   
      end
      else
        r_shft_1d <= 0; 
    end        
end
//syncTo vld+(TO_CMP_EXP-1)+CMPLEX_EXP_LATENCY
ylib_reg #(.WIDTH(2**OC), .DEPTH(TO_CMP_EXP-1+CMPLEX_EXP_LATENCY) )     u00_lib_shr ( .i_clk(i_clk), .i_in(i_CTS_in_vld  ), .o_out(w_cts_vld  ) );


ylib_reg #(.WIDTH(IB), .DEPTH(TO_CMP_EXP-1+CMPLEX_EXP_LATENCY) )     u02_lib_shr ( .i_clk(i_clk), .i_in(i_CTS_in_I  ), .o_out(w_cts_i  ) );


ylib_reg #(.WIDTH(IB), .DEPTH(TO_CMP_EXP-1+CMPLEX_EXP_LATENCY) )     u03_lib_shr ( .i_clk(i_clk), .i_in(i_CTS_in_Q  ), .o_out(w_cts_q  ) );


ylib_reg #(.WIDTH(OC), .DEPTH(TO_CMP_EXP-1+CMPLEX_EXP_LATENCY) )     u04_lib_shr ( .i_clk(i_clk), .i_in(r_shft_cnt  ), .o_out(w_shft_cnt  ) );


//syncTo vld+TO_CMP_EXP+CMPLEX_EXP_LATENCY
always @ (posedge i_clk) begin
    r_cts_vld_d <= |w_cts_vld;
    r_cts_i_d   <= w_cts_i;
    r_cts_q_d   <= w_cts_q;
    curr_cts_on <= get_cts_on[w_shft_cnt];
end

//syncTo vld+2+CMPLEX_EXP_LATENCY
ylib_cmplx_exp #(.CJ(1), .SIN_TABLE_BW(CMPLEX_EXP_BW), .PW(PW) ) u07_lib_cmplx_exp
(
 .i_clk      ( i_clk         )
,.i_phase_vld( r_shft_vld_1d )
,.i_phase    ( r_shft_1d     )
,.o_vld      ( w_cos_vld     )
,.o_cos      ( w_p_cos       )
,.o_sin      ( w_n_sin       )
);

assign w_cmul_cos   = w_p_cos;
assign w_cmul_sin   = w_n_sin;

//syncTo vld+TO_CMP_EXP+CMPLEX_EXP_LATENCY+CMUL_LATENCY
ylib_cmult #(.AWIDTH(IB), .BWIDTH(CMPLEX_EXP_BW)) u08_lib_fxp_cmult
(
 .clk( i_clk       )
,.en( r_cts_vld_d )
,.ar( r_cts_i_d   )
,.ai( r_cts_q_d   )
,.br( w_cmul_cos  )
,.bi( w_cmul_sin  )
,.pen( w_cmult_vld )
,.pr( w_cmult_i   )
,.pi( w_cmult_q   )
);
    
//syncTo vld+TO_CMP_EXP+CMPLEX_EXP_LATENCY+CMUL_LATENCY+CSHFTD_SAT_LATENCY
ylib_cshftd_sat  #(.IB(IB+CMPLEX_EXP_BW+1), .SF(CMPLEX_EXP_BW-1), .OB(OB)) u09_lib_cshftd_sat
(
 .i_clk      ( i_clk       )
,.i_rst      ( 1'b0          )
,.i_din_vld  ( w_cmult_vld )
,.i_din_i    ( w_cmult_i   )
,.i_din_q    ( w_cmult_q   )
,.o_dout_vld ( w_conv_vld  )
,.o_dout_i   ( w_conv_i    )
,.o_dout_q   ( w_conv_q    )
);

//syncTo vld+TO_CMP_EXP+CMPLEX_EXP_LATENCY+CMUL_LATENCY+CSHFTD_SAT_LATENCY
ylib_reg #(.WIDTH(2**OC), .DEPTH(CMUL_LATENCY+CSHFTD_SAT_LATENCY+1-1+1) )     u10_lib_shr ( .i_clk(i_clk), .i_in(w_cts_vld  ), .o_out(w_cts_vld_d  ) );



//syncTo vld+DLY_ME
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)) )   sync_o_bcf_en  ( .i_clk(i_clk), .i_shift(DLY_ME), .i_in(i_bcf_en  ), .o_out(o_bcf_en  ) );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)) )   sync_o_tdd_mode( .i_clk(i_clk), .i_shift(DLY_ME), .i_in(i_tdd_mode), .o_out(o_tdd_mode) );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)) )   sync_o_frm_tick( .i_clk(i_clk), .i_shift(DLY_ME), .i_in(i_frm_tick), .o_out(o_frm_tick) );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)) )   sync_o_slt_tick( .i_clk(i_clk), .i_shift(DLY_ME), .i_in(i_slt_tick), .o_out(o_slt_tick) );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)) )   sync_o_sym_tick( .i_clk(i_clk), .i_shift(DLY_ME), .i_in(i_sym_tick), .o_out(o_sym_tick) );
ylib_reg #(.WIDTH(6 ), .DEPTH(DLY_ME-1) )     sync_o_slt_idx ( .i_clk(i_clk), .i_in(i_sltIdx  ), .o_out(o_sltIdx  ) );
ylib_reg #(.WIDTH(4 ), .DEPTH(DLY_ME-1) )     sync_o_sym_idx ( .i_clk(i_clk), .i_in(i_symIdx  ), .o_out(o_symIdx  ) );



always @ (posedge i_clk) begin
    o_CTS_out_vld <= w_cts_vld_d;
end

always @ (posedge i_clk) begin
    if(|w_cts_vld_d) begin
        o_CTS_out_I  <= w_conv_i;
        o_CTS_out_Q  <= w_conv_q;
    end
    else begin
        o_CTS_out_I  <= 0;
        o_CTS_out_Q  <= 0;
    end
end

endmodule
