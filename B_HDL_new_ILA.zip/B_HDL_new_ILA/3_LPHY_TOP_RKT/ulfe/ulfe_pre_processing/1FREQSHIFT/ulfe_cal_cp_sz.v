// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : cal
//  Author       : Kyeong, Soocheol
//  Description  : cp size calculator 
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.02.05 |Kyeong,Soocheol| initial version
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////



//dly1
module ulfe_cal_cp_sz #(
		parameter W_SCSIDX		= 2			//0~3 : 15K, 30K, 60K, 120K
	,	parameter W_FFTIDX		= 2
	,	parameter W_CP			= 11					// max size : 512*2 = 1024
)
(
	  input		wire							i_clk
	, input		wire	[ W_SCSIDX-1 : 0]		i_scsType		//
	, input		wire	[ W_FFTIDX-1 : 0]		i_fftType		//
	, output	wire	[	  W_CP-1 : 0]		o_nor_lcp_sz		//
	, output	wire	[	  W_CP-1 : 0]		o_nor_scp_sz		//
	, output	wire	[	  W_CP-1 : 0]		o_ext_cp_sz		//
);

function integer clog2;
	input	[31:0]	value;

	begin
		value = value-1;
		
		for(clog2=0; value>0; clog2=clog2+1) begin
			value=value>>1;
		end
	end
endfunction
		
reg		[W_CP-1 : 0]	nor_lcp_sz	;
reg		[W_CP-1 : 0]	nor_scp_sz	;			
reg		[W_CP-1 : 0]	ext_cp_sz	;

assign o_nor_lcp_sz	= nor_lcp_sz;
assign o_nor_scp_sz	= nor_scp_sz;
assign o_ext_cp_sz	= ext_cp_sz;

always @(posedge i_clk) begin

	case(i_fftType[1:0])
		2'd0	: nor_scp_sz <= 144/4;   // 144*(2^(fftType-2))
		2'd1	: nor_scp_sz <= 144/2;   
		2'd2	: nor_scp_sz <= 144;
		2'd3	: nor_scp_sz <= 144*2;
		default : nor_scp_sz <= 144*2;
	endcase

	case({i_scsType[1:0], i_fftType[1:0]})
		{2'd0,2'd0}	: nor_lcp_sz <= (144/4  )   + (16)/4;   //144*(2^(fftType-2))+16*(2^(fftType+scsType-2))
		{2'd0,2'd1}	: nor_lcp_sz <= (144/2  )   + (16)/2;
		{2'd0,2'd2}	: nor_lcp_sz <= (144    )   + (16);
        {2'd0,2'd3} : nor_lcp_sz <= (144*2  )   + (16)*2;	
		{2'd1,2'd0}	: nor_lcp_sz <= (144/4	)	+ (16/2);
		{2'd1,2'd1}	: nor_lcp_sz <= (144/2	)	+ (16*1);
		{2'd1,2'd2}	: nor_lcp_sz <= (144	)	+ (16*2);
		{2'd1,2'd3}	: nor_lcp_sz <= (144*2	)	+ (16*4);
		{2'd2,2'd0}	: nor_lcp_sz <= (144/4	)	+ (16*1);
		{2'd2,2'd1}	: nor_lcp_sz <= (144/2	)	+ (16*2);
		{2'd2,2'd2}	: nor_lcp_sz <= (144	)	+ (16*4);
		{2'd2,2'd3}	: nor_lcp_sz <= (144*2	)	+ (16*8);
		{2'd3,2'd0}	: nor_lcp_sz <= (144/4	)	+ (16*2);
		{2'd3,2'd1}	: nor_lcp_sz <= (144/2	)	+ (16*4);
		{2'd3,2'd2}	: nor_lcp_sz <= (144	)	+ (16*8);
		{2'd3,2'd3}	: nor_lcp_sz <= (144*2	)	+ (16*16);
		default		: nor_lcp_sz <= (144+16)*2;
	endcase

	//external cp size
	case(i_fftType[1:0])
		2'd0	: ext_cp_sz <= 512/4;    //512*(2^(fftType-2)
		2'd1	: ext_cp_sz <= 512/2;
		2'd2	: ext_cp_sz <= 512;
        2'd3    : ext_cp_sz <= 512*2;		
		default	: ext_cp_sz <= 512*2;
	endcase
end

endmodule


