// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

/*
 * AUTHOR : sch.kyeong (Soocheol Kyeong)
 * Module name :  LTE_UL_FREQSHIFT
 * 
 * update i_*, o_*, r_*, w_*
 */


module ulfe_freq_shift #(
//  parameter    OC        = 3
//  ,parameter    NUM_RX       = 2**OC
   parameter    NUM_RX    = 4
  ,parameter    SCO       = 0
  ,parameter    CP_TYPE	  = 0
  ,parameter 	IB        = 15 
  ,parameter 	OB        = 15 
)
(
    input   wire                    i_clk
  , input   wire                    i_frm_tick_pre1
  , input   wire                    i_bcf_en
  , input   wire                    i_tdd_mode	
  , input   wire    [    NUM_RX-1:0]   i_freqShiftOn
  , input   wire    [    NUM_RX-1:0]   i_calBypassFlag
  , input   wire    [      3-1:0]   i_scsType
  , input   wire                    i_cpType	  
  , input   wire    [      2-1:0]   i_fftType	  
  , input   wire    [    NUM_RX-1:0]   i_FREQSHIFT_in_vld	      //tick
  , input   wire    [     IB-1:0]   i_FREQSHIFT_in_I	
  , input   wire    [     IB-1:0]   i_FREQSHIFT_in_Q
  , output  reg     [    NUM_RX-1:0]   o_FREQSHIFT_out_vld	
  , output  reg     [     OB-1:0]   o_FREQSHIFT_out_I	  
  , output  reg     [     OB-1:0]   o_FREQSHIFT_out_Q	  
  , output  wire                    o_frm_tick_pre1
  , output  wire                    o_sym_tick
  , output  wire                    o_bcf_en  
  , output  wire                    o_tdd_mode  
//  , output  wire    [     32-1:0]   o_FREQSHIFT_latency
);

//LTE : 15kHz only
//localparam  SCO       = 2'd0; //15K
localparam  W_CP      = 11;
localparam  W_COS     = 16;
localparam  W_CMUL    = IB+W_COS+1;

//STEP0 : dat align to tick+1 (idx output timing)
//STEP1 : gen exp phase
//STEP2 : gen exp val
//STEP3 : complex multiplication
//STEP4 : round & sat
//STEP5 : +1 output reg
localparam  DLY0        = 5'd1;   
localparam  DLY1        = 5'd3;   
localparam  DLY2        = 5'd4;   
localparam  DLY3        = 5'd6;   
localparam  DLY4        = 5'd3;   
localparam  DLY5        = 5'd1;   
localparam  DLY_TO_CMUL	= (DLY0+DLY1+DLY2);
localparam  DLY_ME      = (DLY_TO_CMUL+DLY3+DLY4+DLY5);

//**************************************INTERNAL SIGNALS*************************//
wire          [    NUM_RX-1:0]	    w_get_BypassOn	;
wire          [      3-1:0]     w_get_scsType   ;
wire                            w_get_cpType    ;    
wire          [      2-1:0]     w_get_fftType   ;    
                
reg           [    W_CP-1:0]	r_curr_nor_cp_sz;
wire          [    W_CP-1:0]	w_nor_lcp_sz;
wire          [    W_CP-1:0]	w_nor_scp_sz;      
wire          [    W_CP-1:0]	w_ext_cp_sz ;
                
reg           [        13:0]	r_smp_sht_idx  ;
reg           [        18-1:0]	r_expj14_idx   ;
wire  signed  [        15:0]	w_expj14_cos      ;
wire                            w_expj14_vld      ;
wire  signed  [        15:0]	w_expj14_sin      ;
wire  signed  [        15:0]	w_cmul_cos        ;
wire  signed  [        15:0]	w_cmul_sin        ;
wire  signed  [  W_CMUL-1:0]	w_cmul_out_i      ;
wire  signed  [  W_CMUL-1:0]	w_cmul_out_q      ;
wire                            w_cmul_out_vld    ;
wire  signed  [        14:0]    w_sat_out_i       ;
wire  signed  [        14:0]    w_sat_out_q       ;
                                                  
wire          [      IB-1:0]	w_cmul_in_i       ;
wire          [      IB-1:0]	w_cmul_in_q       ;
wire          [     NUM_RX-1:0]	w_vld             ;
                    
wire          [     NUM_RX-1:0]	w_vld_sync2tick_d2;
wire          [     NUM_RX-1:0]	w_vld_sync2tick_d4;
wire                            w_frm_tick        ;
wire                            w_slt_tick        ;
wire                            w_sym_tick        ;
wire                            w_sym_tick_d2     ;
wire          [     NUM_RX-1:0]    w_get_BypassOn_d  ;
wire          [       6-1:0]    w_sltIdx          ;    //aligned to (tick+1)
wire          [       4-1:0]    w_symIdx          ;

//assign o_FREQSHIFT_latency = DLY_ME;

//genvar i;

// to (tick)
ylib_reg_clk_en #(.WIDTH(3	  ),.DEPTH(1))  reg_scsType       ( .i_clk(i_clk), .i_en(i_frm_tick_pre1), .i_in(i_scsType                          ), .o_out(w_get_scsType ));
ylib_reg_clk_en #(.WIDTH(1	  ),.DEPTH(1))  reg_cpType        ( .i_clk(i_clk), .i_en(i_frm_tick_pre1), .i_in(i_cpType                           ), .o_out(w_get_cpType  ));
ylib_reg_clk_en #(.WIDTH(2	  ),.DEPTH(1))  reg_fftType       ( .i_clk(i_clk), .i_en(i_frm_tick_pre1), .i_in(i_fftType                          ), .o_out(w_get_fftType ));
ylib_reg_clk_en #(.WIDTH(NUM_RX ) ,.DEPTH(1))  reg_freqShiftOn   ( .i_clk(i_clk), .i_en(w_sym_tick     ), .i_in(i_freqShiftOn & (~i_calBypassFlag) ), .o_out(w_get_BypassOn));

// to (tick+1)
ulfe_cal_cp_sz cal_cp_inst
(
   .i_clk         ( i_clk             )
  ,.i_scsType     ( w_get_scsType[1:0])
  ,.i_fftType     ( w_get_fftType     )
  ,.o_nor_lcp_sz  ( w_nor_lcp_sz      )
  ,.o_nor_scp_sz  ( w_nor_scp_sz      )
  ,.o_ext_cp_sz	  ( w_ext_cp_sz       )
);

// output tick timing : reference
ulfe_timer #(
   .N_CYCLE_CLK	    (245760000   )
  ,.SCS_IDX         (SCO      )              //{0~4} --> {15k, 30k, 60k, 120k, 240k}
  ,.CP_TYPE         (CP_TYPE  )             //0:normal, 1:extended
  ,.CP_TICK         (0        )
) timer_inst
(
   .i_clk             ( i_clk           )
  ,.i_frm_tick_pre1   ( i_frm_tick_pre1	)
  ,.o_frm_tick_pre1   ( w_frm_tick      )        //tick
  ,.o_slt_tick        ( w_slt_tick      )       //tick
  ,.o_sym_tick        ( w_sym_tick      )       //tick
  ,.o_slt_idx         ( w_sltIdx        )       //tick+1
  ,.o_sym_idx         ( w_symIdx        )       //tick+1
);

// to tick+2

ylib_reg #(  .WIDTH(NUM_RX), .DEPTH(2) ) vld_dly1       ( .i_clk(i_clk), .i_in(i_FREQSHIFT_in_vld ), .o_out(w_vld_sync2tick_d2) );
ylib_pshift #(  .BW_SHIFT(1  ) ) sym_tick_dly2  ( .i_clk(i_clk), .i_shift(1'd1), .i_in(w_sym_tick         ), .o_out(w_sym_tick_d2     ) );

///DBG - DG
ylib_reg #(  .WIDTH(NUM_RX  ), .DEPTH(DLY_TO_CMUL-2) ) u_bypass_on_d ( .i_clk(i_clk), .i_in(w_get_BypassOn             ), .o_out(w_get_BypassOn_d     ) );

//syncTo tick+4
ylib_reg #(  .WIDTH(NUM_RX), .DEPTH(2) ) vld_dly2       ( .i_clk(i_clk), .i_in(w_vld_sync2tick_d2), .o_out(w_vld_sync2tick_d4)  );
//delayed data : 
ylib_reg #(  .WIDTH(IB), .DEPTH(DLY_TO_CMUL) ) datI_dly1 ( .i_clk(i_clk), .i_in(i_FREQSHIFT_in_I), .o_out(w_cmul_in_i) );
ylib_reg #(  .WIDTH(IB), .DEPTH(DLY_TO_CMUL) ) datQ_dly1 ( .i_clk(i_clk), .i_in(i_FREQSHIFT_in_Q), .o_out(w_cmul_in_q) );
  

////////////////////////////////////
// STEP0 : dat algin to tick+1 (dly = 1)
////////////////////////////////////
////////////////////////////////////
// STEP1 : phase index gen (dly = 3)
////////////////////////////////////
// (tick+1) to (tick + 2)
always @(posedge i_clk) begin
  case(w_symIdx[3:0])
    4'd0   : r_curr_nor_cp_sz <= w_nor_lcp_sz;
    4'd7   : r_curr_nor_cp_sz <= w_nor_lcp_sz;
    default: r_curr_nor_cp_sz <= w_nor_scp_sz;
  endcase
end

// (tick+2) to (tick+3) 
always @(posedge i_clk) begin
  if(w_sym_tick_d2 && w_get_cpType)
  //if(w_sym_tick && w_get_cpType)  // 0327, with new timer_v1, w_sym_tick is tick+2
    r_smp_sht_idx	<= w_ext_cp_sz;
  else if(w_sym_tick_d2)        // 0327, with new timer_v1, w_sym_tick is tick+2
  //else if(w_sym_tick)
    r_smp_sht_idx	<= r_curr_nor_cp_sz;
  else if(w_vld_sync2tick_d2[0])
    r_smp_sht_idx	<= r_smp_sht_idx-1;
end

// (tick+3) to (tick+4) 
//2**(4-fftType)
always @(posedge i_clk) begin
  case(w_get_fftType[1:0])
    2'd0    : r_expj14_idx <= r_smp_sht_idx<<4;  //512 fft
    2'd1    : r_expj14_idx <= r_smp_sht_idx<<3;  //1024 fft
    default : r_expj14_idx <= r_smp_sht_idx<<2;  //2048 fft
  endcase
  //    r_expj14_idx <= r_smp_sht_idx_sync;
end
/////END OF STEP1 /////////


////////////////////////////////////
// STEP2 : expj14 gen (dly=4)
////////////////////////////////////
// (tick+4) to (tick+8) 
ylib_cmplx_exp
#(
    .SIN_TABLE_BW(W_COS	)
   ,.PW	         (14    )  // 12 or 14 
)
expj14_table_inst 
(
   .i_clk       ( i_clk             )// Clock 
 , .i_phase_vld (|w_vld_sync2tick_d4)// phase enable
 , .i_phase     ( r_expj14_idx[13:0] )// Input Phase
 , .o_vld       ( w_expj14_vld      )// Output Cosine
 , .o_cos       ( w_expj14_cos      )// Output Cosine
 , .o_sin       ( w_expj14_sin      )// Output Sine        
);
/////END OF STEP2 /////////

////////////////////////////////////
// STEP3 : complex multiplication (dly=6)
////////////////////////////////////
// (tick+8) to (tick+14) 
//assign w_cmul_cos	= (|w_get_BypassOn)? w_expj14_cos : (2**15)-1;
//assign w_cmul_sin	= (|w_get_BypassOn)? w_expj14_sin : 0;

assign w_cmul_cos   = (|w_get_BypassOn_d)? w_expj14_cos : (2**15)-1;
assign w_cmul_sin   = (|w_get_BypassOn_d)? w_expj14_sin : 0;




ylib_cmult #(
    .AWIDTH(IB),
    .BWIDTH(W_COS)
) ylib_cmult_instance (
    .clk    (i_clk          ),
    .en     (w_expj14_vld   ),
    .ar     (w_cmul_in_i    ),
    .ai     (w_cmul_in_q    ),
    .br     (w_cmul_cos     ),
    .bi     (w_cmul_sin     ),
    .pen    (w_cmul_out_vld ),
    .pr     (w_cmul_out_i   ),
    .pi     (w_cmul_out_q   )
);

/////END OF STEP3 /////////

////////////////////////////////////
// STEP4 : rounding & saturation
////////////////////////////////////
// (tick+14) to (tick+17) 
ylib_sshftd_sat
#(
      .IB            (W_CMUL            )                    // Input Bit Width
    , .SF            (15                )    // Bit Shift for Round
    , .OB            (15                )    // Saturation Bit Width (Output Bit Width
    , .ROUND_TYPE    ("SYMMETRIC_ROUND" )    // SYMMETRIC_ROUND or ROUND or TRUNC
    , .SAT_TYPE      ("SYMMETRIC"       )    // SYMMETRIC or NONSYMMETRIC
)
sat15R_i
(
      .i_clk         (i_clk             ) // i_clk     
    , .i_din_vld     (w_cmul_out_vld    ) // Input Siganl Enable
    , .i_din         (w_cmul_out_i      ) // Input Signal
    , .o_dout_vld    (                  )
    , .o_dout        (w_sat_out_i       ) // Output Signal
);

ylib_sshftd_sat
#(
      .IB            (W_CMUL            )                    // Input Bit Width
    , .SF            (15                )    // Bit Shift for Round
    , .OB            (15                )    // Saturation Bit Width (Output Bit Width
    , .ROUND_TYPE    ("SYMMETRIC_ROUND" )    // SYMMETRIC_ROUND or ROUND or TRUNC
    , .SAT_TYPE      ("SYMMETRIC"       )    // SYMMETRIC or NONSYMMETRIC
)
sat15R_q
(
      .i_clk         (i_clk           ) // i_clk     
    , .i_din_vld     (w_cmul_out_vld  ) // Input Siganl Enable
    , .i_din         (w_cmul_out_q    ) // Input Signal
    , .o_dout_vld    (                )
    , .o_dout        (w_sat_out_q     ) // Output Signal
);

/////END OF STEP4 /////////

////////////////////////////////////
// STEP5 : output reg
////////////////////////////////////

//sync to o_tick
ylib_shr_en #(.WIDTH(NUM_RX  ), .DEPTH(DLY2+DLY3+DLY4) ) sync_w_vld     ( .i_clk(i_clk),  .i_en(1'b1), .i_in(w_vld_sync2tick_d4), .o_out(w_vld           )  );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1))   ) sync_o_frm_tick( .i_clk(i_clk),  .i_shift(DLY_ME),    .i_in(i_frm_tick_pre1   ), .o_out(o_frm_tick_pre1 )  );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1))   ) sync_o_sym_tick( .i_clk(i_clk),  .i_shift(DLY_ME-5'd2),    .i_in(w_sym_tick        ), .o_out(o_sym_tick      )  );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1))   ) bcf_en_dly     ( .i_clk(i_clk),  .i_shift(DLY_ME),    .i_in(i_bcf_en          ), .o_out(o_bcf_en        )  );
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1))   ) tdd_mode_dly   ( .i_clk(i_clk),  .i_shift(DLY_ME),    .i_in(i_tdd_mode        ), .o_out(o_tdd_mode      )  );

always @(posedge i_clk) begin	
  if(|w_vld)  begin
    o_FREQSHIFT_out_I	<= w_sat_out_i;
    o_FREQSHIFT_out_Q	<= w_sat_out_q;
  end
  else begin
    o_FREQSHIFT_out_I	<= 0;
    o_FREQSHIFT_out_Q	<= 0;
  end
  o_FREQSHIFT_out_vld	<= w_vld;
end
  
endmodule


