// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : cal
//  Author       : Song, Moon-Gun
//  Description  : Calibration 
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2018.03.23 |Song, Moon-Gun | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.02.05 |Kyeong,Soocheol| change of weight granularity : from each 2RE to RB
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ulfe_calb_fpga 
#(
      parameter IB          =  16    // Input Bitwidth
    , parameter WB          =  12    // Weight Bitwidth
    , parameter OB          =  16    // Output Bitwidth
    , parameter OC          =  1     // Overclocking Factor
    , parameter OVS         =  2**OC //

)(
 input   wire                        i_clk                      // Clock 
,input   wire                        i_rst                      // Reset                                          
,input   wire                        i_frm_tick
,input   wire                        i_slt_tick
,input   wire                        i_sym_tick
,input   wire      [          6-1:0] i_sltIdx 
,input   wire      [          4-1:0] i_symIdx
,input   wire                        i_bcf_en
,input   wire                        i_tdd_mode  
,input   wire      [      OVS*1-1:0] i_calOn               // Cal. On
,input   wire      [        OVS-1:0] i_calBypassFlag       // Cal bypass Flag
,input   wire                        i_calW_vld            // Cal. Weight Valid
,input   wire      [     OVS*WB-1:0] i_calW_i              // Cal. Weight I
,input   wire      [     OVS*WB-1:0] i_calW_q              // Cal. Weight Q
,input   wire      [      OVS*4-1:0] i_calWScale           // Cal. Weight Exponent
,input   wire      [      OVS*1-1:0] i_CALB_in_vld         // Cal. vld 
,input   wire      [         IB-1:0] i_CALB_in_I           // Cal. I Input 
,input   wire      [         IB-1:0] i_CALB_in_Q           // Cal. Q Input 
,output  wire                        o_cal_buf_rd_vld      // init+1 timing
,output  wire                        o_cal_buf_rd_bank     // init timing
,output  wire                        o_cal_buf_rd_init     //
,output  reg       [     OVS* 1-1:0] o_CALB_out_vld=0      // Cal. Output Valid
,output  reg       [         OB-1:0] o_CALB_out_I  =0      // Cal. I Output 
,output  reg       [         OB-1:0] o_CALB_out_Q  =0      // Cal. Q Output        
,output  wire                        o_bcf_en
,output  wire                        o_tdd_mode                                
,output  wire                        o_frm_tick
,output  wire                        o_slt_tick
,output  wire                        o_sym_tick
,output  wire      [          6-1:0] o_sltIdx 
,output  wire      [          4-1:0] o_symIdx               
//,output  wire      [         32-1:0] o_CALB_latency
);

localparam RD_BUF_NP           = 2;
localparam DLY_RD_BUF          = 3+RD_BUF_NP+1;	// 3+BUF_NP(2)+1(rd_vld gen clock)	
localparam CMUL_LATENCY        = 6;
localparam CSHFTVD_SAT_LATENCY = 4;
localparam DLY_ME              = DLY_RD_BUF+1+CMUL_LATENCY+1+CSHFTVD_SAT_LATENCY+1;	//from i_vld to o_vld

wire        [   OVS*1-1:0] get_cal_on             ;       
wire        [   OVS*4-1:0] get_cal_wght_exp       ;
wire                       w_cal_buf_rd_vld       ;	                                  
wire                       w_frm_tick_dN          ;
wire                       w_slt_tick_dN          ;
wire                       w_sym_tick_dN          ;
wire        [       6-1:0] w_slotIdx_dN           ;
wire        [       4-1:0] w_symIdx_dN            ;
reg                        r_cal_rd_bank      = 0 ;
wire                       w_cal_vld_d1           ;
wire                       w_cal_vld_d2           ;
wire                       w_cal_vld_d3           ;
wire                       w_cal_vld_d4           ;
wire        [     OVS-1:0] w_cal_vld_dN           ;
wire        [      IB-1:0] w_cal_i_dN             ;
wire        [      IB-1:0] w_cal_q_dN             ;                                         
reg         [      OC-1:0] r_cal_wght_cnt     = 0 ;
reg  signed [      WB-1:0] r_cal_wght_i_1d    = 0 ;
reg  signed [      WB-1:0] r_cal_wght_q_1d    = 0 ;
reg  signed [      IB-1:0] r_cal_i_1d         = 0 ;
reg  signed [      IB-1:0] r_cal_q_1d         = 0 ;
reg         [       1-1:0] r_cal_vld_1d       = 0 ;
reg         [      OC-1:0] r_cal_wght_exp_cnt = 0 ;
reg         [       4-1:0] r_cal_wght_exp     = 0 ;
reg                    	   r_cmult_vld_1d     = 0 ;
reg         [ IB+WB+1-1:0] r_cmult_i_1d       = 0 ;
reg         [ IB+WB+1-1:0] r_cmult_q_1d       = 0 ;    
wire                       w_cmult_vld            ;
wire        [ IB+WB+1-1:0] w_cmult_i              ;
wire        [ IB+WB+1-1:0] w_cmult_q              ;                                  
wire                       w_conv_vld             ;                                                                                            
wire        [      OB-1:0] w_conv_i               ;
wire        [      OB-1:0] w_conv_q               ;                                  
wire        [     OVS-1:0] w_cal_vld              ;                                 
wire        [      WB-1:0] w_cal_wght_i  [OVS-1:0];
wire        [      WB-1:0] w_cal_wght_q  [OVS-1:0];
wire        [       4-1:0] w_cal_wght_exp[OVS-1:0];                                 
wire                       w_buf_rout_last        ;
wire                       w_buf_rout_vld         ;
genvar i;

//assign o_CALB_latency = DLY_ME;

////////////////////////////////////////////////////////////
// registered input para
////////////////////////////////////////////////////////////
ylib_reg_clk_en #(.WIDTH(OVS	),.DEPTH(1) ) reg_calW_on  ( .i_clk(i_clk),	.i_en(i_sym_tick), .i_in(i_calOn & (~i_calBypassFlag)), .o_out(get_cal_on		) );
ylib_reg_clk_en #(.WIDTH(OVS*4	),.DEPTH(1) ) reg_calW_exp ( .i_clk(i_clk),	.i_en(i_sym_tick), .i_in(i_calWScale				 ), .o_out(get_cal_wght_exp	) );

///////////////////////////////////////////////////////
// BUF READ CONTROL AND WAITING FOR READ OUT SYNC
///////////////////////////////////////////////////////

assign	w_cal_buf_rd_vld	= (!i_rst) && (|i_CALB_in_vld);	
assign	o_cal_buf_rd_init	= (!i_rst) && (!w_cal_vld_d4) && (|i_CALB_in_vld);
assign	o_cal_buf_rd_bank	= r_cal_rd_bank;

ylib_reg #(.WIDTH(1		),.DEPTH(1) ) vld_d1		 ( .i_clk(i_clk),	.i_in(|i_CALB_in_vld					), .o_out(w_cal_vld_d1		) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) vld_d2		 ( .i_clk(i_clk),	.i_in((|i_CALB_in_vld) || w_cal_vld_d1	), .o_out(w_cal_vld_d2		) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) vld_d3		 ( .i_clk(i_clk),	.i_in((|i_CALB_in_vld) || w_cal_vld_d2	), .o_out(w_cal_vld_d3		) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) vld_d4		 ( .i_clk(i_clk),	.i_in((|i_CALB_in_vld) || w_cal_vld_d3	), .o_out(w_cal_vld_d4		) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) rd_vld_gen	 ( .i_clk(i_clk),	.i_in(w_cal_buf_rd_vld					), .o_out(o_cal_buf_rd_vld	) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) rout_vld_dly   ( .i_clk(i_clk),	.i_in(i_calW_vld						), .o_out(w_buf_rout_vld	) );
ylib_reg #(.WIDTH(1		),.DEPTH(1) ) rout_last_gen  ( .i_clk(i_clk),	.i_in((!i_calW_vld) && w_buf_rout_vld	), .o_out(w_buf_rout_last	) );

//////////////////////////////////////////////////////
// SYNC INPUT TO READ OUT TIMING
//////////////////////////////////////////////////////
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_RD_BUF) ) frm_tick_dly( .i_clk(i_clk), .i_in(i_frm_tick    ), .o_out(w_frm_tick_dN) );
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_RD_BUF) ) slt_tick_dly( .i_clk(i_clk), .i_in(i_slt_tick    ), .o_out(w_slt_tick_dN) );
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_RD_BUF) ) sym_tick_dly( .i_clk(i_clk), .i_in(i_sym_tick    ), .o_out(w_sym_tick_dN) );
ylib_reg #(.WIDTH(OVS	), .DEPTH(DLY_RD_BUF) ) dat_vld_dly ( .i_clk(i_clk), .i_in(i_CALB_in_vld ), .o_out(w_cal_vld_dN	) );
ylib_reg #(.WIDTH(IB	), .DEPTH(DLY_RD_BUF) ) dat_i_dly   ( .i_clk(i_clk), .i_in(i_CALB_in_I   ), .o_out(w_cal_i_dN   ) );
ylib_reg #(.WIDTH(IB	), .DEPTH(DLY_RD_BUF) ) dat_q_dly   ( .i_clk(i_clk), .i_in(i_CALB_in_Q   ), .o_out(w_cal_q_dN   ) );

generate
for (i = 0; i < OVS; i = i + 1) begin : CAL_INPUT_CTRL

assign w_cal_wght_i  [i] = i_calW_i  [WB*(i+1)-1:WB*i];
assign w_cal_wght_q  [i] = i_calW_q  [WB*(i+1)-1:WB*i];
assign w_cal_wght_exp[i] = get_cal_wght_exp[ 4*(i+1)-1: 4*i];

end
endgenerate

//dly1
always @ (posedge i_clk) begin

	//syncTo buf_rd_rqst
    if(i_sym_tick)
		r_cal_rd_bank	<= 0;
    else if(o_cal_buf_rd_init && (|i_CALB_in_vld[OVS-1:1])) // ant sig boundary condition
		r_cal_rd_bank	<= ~r_cal_rd_bank;

	//dats is not interleaved among multi-ports
    if(w_sym_tick_dN)
		r_cal_wght_cnt	<= 0;
    else if(w_buf_rout_last) 
		r_cal_wght_cnt	<= r_cal_wght_cnt+1;

    if(|get_cal_on) begin
		//r_cal_wght_i_1d <= $signed(w_cal_wght_i[r_cal_wght_cnt]);    
		//r_cal_wght_q_1d <= $signed(w_cal_wght_q[r_cal_wght_cnt]); 
        if(w_cal_vld_dN[0]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[0]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[0]);
        end
        else if(w_cal_vld_dN[1]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[1]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[1]);
        end
        else if(w_cal_vld_dN[2]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[2]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[2]);
        end
        else if(w_cal_vld_dN[3]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[3]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[3]);
        end
        else if(w_cal_vld_dN[4]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[4]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[4]);
        end
        else if(w_cal_vld_dN[5]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[5]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[5]);
        end
        else if(w_cal_vld_dN[6]) begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[6]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[6]);
        end
        else begin
		  r_cal_wght_i_1d <= $signed(w_cal_wght_i[7]);    
		  r_cal_wght_q_1d <= $signed(w_cal_wght_q[7]);
        end
		
    end
    else begin
		r_cal_wght_i_1d <= 1;
		r_cal_wght_q_1d <= 0;
    end
    r_cal_i_1d      <= $signed(w_cal_i_dN);
    r_cal_q_1d      <= $signed(w_cal_q_dN);
    r_cal_vld_1d    <= w_buf_rout_vld & (|w_cal_vld_dN);
end


//dly:6
ylib_cmult #(.AWIDTH(IB), .BWIDTH(WB)) u01_lib_fxp_cmult
(
     .clk     (    i_clk                                )
    ,.en      (    r_cal_vld_1d                         )
    ,.ar      (    r_cal_i_1d                           )
    ,.ai      (    r_cal_q_1d                           )
    ,.br      (    r_cal_wght_i_1d                      )
    ,.bi      (    r_cal_wght_q_1d                      )
    ,.pen     (    w_cmult_vld                          )
    ,.pr      (    w_cmult_i                            )
    ,.pi      (    w_cmult_q                            )
);


//dly1
always @ (posedge i_clk) begin
    if(i_rst) begin
        r_cmult_vld_1d     <= 1'b0;
    end
    else begin
        r_cmult_vld_1d <= w_cmult_vld;
    end

	if(w_sym_tick_dN)
        r_cal_wght_exp_cnt <= 0;
	else if(w_buf_rout_last) 
        r_cal_wght_exp_cnt <= r_cal_wght_exp_cnt + 1;

	if(|get_cal_on)
		r_cal_wght_exp <= w_cal_wght_exp[r_cal_wght_exp_cnt]; 
	else
		r_cal_wght_exp <= 0;
    
	r_cmult_i_1d   <= w_cmult_i;
    r_cmult_q_1d   <= w_cmult_q;
end

//dly4
ylib_cshftvd_sat  #(.IB(IB+WB+1), .SB(4), .OB(OB)) u02_lib_cshftvd_sat
(
     .i_clk      (    i_clk                                )
    ,.i_shft     (    r_cal_wght_exp                       )
    ,.i_din_vld  (    r_cmult_vld_1d                       )
    ,.i_din_i    (    r_cmult_i_1d                         )
    ,.i_din_q    (    r_cmult_q_1d                         )
    ,.o_dout_vld (    w_conv_vld                           )
    ,.o_dout_i   (    w_conv_i                             )
    ,.o_dout_q   (    w_conv_q                             )
);

///////////////////////////////////////////////////////////
//  LOGIC FOR BYPASS
// bypass reg vs (weight=1 & cmul)  which one is efficient?
//////////////////////////////////////////////////////////

ylib_reg #(.WIDTH(OVS), .DEPTH(CMUL_LATENCY+CSHFTVD_SAT_LATENCY+2)) u06_lib_shr          
(
     .i_clk      (    i_clk                                )
    ,.i_in       (    {OVS{w_buf_rout_vld}} & w_cal_vld_dN )
    ,.o_out      (    w_cal_vld                            )
);

///////////////////////////////////////////////////////////////
//		SYNC TO	OUTPUT TIMING
///////////////////////////////////////////////////////////////
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_ME) ) sync_o_bcf_en  ( .i_clk(i_clk),	.i_in(i_bcf_en  ), .o_out(o_bcf_en  	)	);
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_ME) ) sync_o_tdd_mode( .i_clk(i_clk),	.i_in(i_tdd_mode), .o_out(o_tdd_mode	)	);
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_ME) ) sync_o_frm_tick( .i_clk(i_clk),	.i_in(i_frm_tick), .o_out(o_frm_tick	)	);
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_ME) ) sync_o_slt_tick( .i_clk(i_clk),	.i_in(i_slt_tick), .o_out(o_slt_tick	)	);
ylib_reg #(.WIDTH(1		), .DEPTH(DLY_ME) ) sync_o_sym_tick( .i_clk(i_clk),	.i_in(i_sym_tick), .o_out(o_sym_tick	)	);
ylib_reg #(.WIDTH(6  	), .DEPTH(DLY_ME) ) sync_o_slt_idx ( .i_clk(i_clk),	.i_in(i_sltIdx  ), .o_out(o_sltIdx		)	);
ylib_reg #(.WIDTH(4 	), .DEPTH(DLY_ME) ) sync_o_sym_idx ( .i_clk(i_clk),	.i_in(i_symIdx  ), .o_out(o_symIdx		)	);

always @ (posedge i_clk) begin
    if(i_rst) begin
        o_CALB_out_vld <= 0;
    end
    else begin
        o_CALB_out_vld <= w_cal_vld;
    end
end

always @ (posedge i_clk) begin
    if(|w_cal_vld) begin
        o_CALB_out_I <= w_conv_i;
        o_CALB_out_Q <= w_conv_q;
    end
	else begin
        o_CALB_out_I <= 0;
        o_CALB_out_Q <= 0;
	end
end

endmodule
