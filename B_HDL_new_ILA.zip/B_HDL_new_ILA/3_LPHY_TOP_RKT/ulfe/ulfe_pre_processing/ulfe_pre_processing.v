// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      :  SVR 21B
//  Module       :  ulfe_pre_processing
//  Author       :  
//  Description  :  
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.19 | donggeun.jo   | Ver2.0 : add num_chain architecture
//              |               | Supporting RT8808 (VERSAL FPGA)
//  ------------+---------------+-----------------------------------------------
//   2020.12.12 |               | 
//  ------------+---------------+-----------------------------------------------
//   2020.03.13 |               | Initial Release
//  ------------+---------------+-----------------------------------------------
////////////////////////////////////////////////////////////////////////////////

//OSR : Operating clock / Sampling rate
//NUM_CHAIN_ANT : ANT / CHAIN ~= OVS

`include "ulfe_cc.vh"

//`define MAX_SCIDX   0 //Sub carrier spacing IDX

module ulfe_pre_processing #(
    parameter FS_CLK    = 245760000
    ,parameter OC        = 3 //Over clocking ratio
//    ,parameter NUM_RX       = 2**OC //Over sampling rate
    ,parameter MAX_SCIDX = 0
    ,parameter NUM_RX    = 8
    ,parameter IB        = 15 //input Bitwidth
    ,parameter OB        = 15 //ouput Bitwidth
    ,parameter CPTYPE    = 0 //0:normal, 1:long
    ,parameter TR        = 32 //TD-rssi report
    ,parameter CALWB     = 12 //CALB weight bit width
    ,parameter PWB       = 16 //Weight bitwidth
    ,parameter MAX_NFFT  = 2048
    ,parameter VENDOR    = "Xilinx"
//    ,parameter CALB_EN   = "disable"
`ifdef ULFE_ORAN
    ,parameter FHTYPE    = "ORAN" //ORAN - CPRI
`endif
    ,parameter CHAIN_INDEX = 0
    ,parameter CPUIF_BB_ADDR_BW = 20
)
(
    input  wire                            i_clk // clock
    , input  wire                          i_rst // reset   
    , input  wire                  [3-1:0] i_osr_quotient
   
    , input  wire                          i_bcf_en // parameter
    , input  wire                          i_tdd_mode // parameter
    , input  wire [            NUM_RX-1:0] i_freqShiftOn // parameter
    , input  wire [            NUM_RX-1:0] i_calBypassFlag // parameter
    , input  wire [          NUM_RX*5-1:0] i_tagcbackoff // parameter
    , input  wire [            NUM_RX-1:0] i_tagcon // parameter
    , input  wire [            NUM_RX-1:0] i_calOn // parameter
    , input  wire [            NUM_RX-1:0] i_gainCompOn
    , input  wire [          NUM_RX*4-1:0] i_calWScale // parameter
    , input  wire                          i_cpType // parameter
    , input  wire [                 2-1:0] i_fftType // parameter
    , input  wire [                12-1:0] i_k0 // parameter
    , input  wire [                 9-1:0] i_rb_size // parameter
    , input  wire [                 3-1:0] i_scsType // parameter
    , input  wire [                11-1:0] i_cpRmOffset // parameter
    , input  wire [            NUM_RX-1:0] i_phaseCompOn // parameter
    , input  wire [          NUM_RX*1-1:0] i_cts_on // parameter
    , input  wire [          NUM_RX*1-1:0] i_cts_shft_vld // parameter
    , input  wire [         NUM_RX*12-1:0] i_cts_shft // parameter

    //, input  wire                          i_phaseW_vld           // phase comp weight signal write interface
    , input  wire [ 14*(2**MAX_SCIDX)*PWB-1:0] i_phaseW_i // phase comp weight signal write interface
    , input  wire [ 14*(2**MAX_SCIDX)*PWB-1:0] i_phaseW_q // phase comp weight signal write interface

    , input  wire [                11-1:0] i_cal_wght_addr // calb weight rd/wr interface
    , input  wire [                 1-1:0] i_cal_wght_buf_bus // calb weight rd/wr interface
    , input  wire [                 1-1:0] i_cal_wght_buf_core // calb weight rd/wr interface
    , input  wire [                 1-1:0] i_cal_wght_wren // calb weight rd/wr interface
    , input  wire [                 1-1:0] i_cal_wght_rden // calb weight rd/wr interface
    , input  wire [      NUM_RX*CALWB-1:0] i_cal_wght_wr_i // calb weight rd/wr interface
    , input  wire [      NUM_RX*CALWB-1:0] i_cal_wght_wr_q // calb weight rd/wr interface
    , output wire [      NUM_RX*CALWB-1:0] o_cal_wght_rd_i // calb weight rd/wr interface
    , output wire [      NUM_RX*CALWB-1:0] o_cal_wght_rd_q // calb weight rd/wr interface

`ifdef ULFE_Cp
    , input wire                     [3:0] i_uin_symbol_idx
`endif
`ifdef ULFE_DSS
    , input wire                           i_uin_en_technology
    , input wire                           i_uin_technology_dss
    , output wire                    [4:0] o_dbg_dssCp_alarm

`endif
`ifdef ULFE_TAGC_TDRSSI
//    , input  wire [                   0:0] i_tdrssi_trigger         
//    , input  wire [                 7-1:0] i_tdrssi_start_slt_idx   
//    , input  wire [                 4-1:0] i_tdrssi_start_sym_idx   
//    , input  wire [                 6-1:0] i_tdrssi_syms_size  
,output [             0:0]              o_tdagc_frm_tick    
,output [      NUM_RX-1:0]              o_tdagc_tdrssi_vld               
,output [   NUM_RX*TR-1:0]              o_tdagc_tdrssi                   

//    , output wire                          o_tdrssi_cap_done // td rssi report interface
//    , input  wire [                 4-1:0] i_tdrssi_rd_symidx // td rssi report interface
//    , input  wire                          i_tdrssi_rd_rqst // td rssi report interface
//    , output wire                          o_tdrssi_vld // td rssi report interface
//    , output wire [            NUM_RX*TR-1:0] o_tdrssi // td rssi report interface
`endif
`ifdef ULFE_CALB_EN
    ,   input   wire    [CPUIF_BB_ADDR_BW-1:0]              i_cpu_addr
    ,   input   wire    [0:0]                               i_cpu_wren
    ,   input   wire    [31:0]                              i_cpu_wdata
    ,   input   wire    [0:0]                               i_cpu_rden
,   output  wire    [0:0]                               o_calb_cpu_rvalid
,   output  wire    [31:0]                              o_calb_cpu_rdata
    ,   input   wire    [6:0]                               i_sel_calb_rx
,   output  wire    [NUM_RX-1:0]                        o_calwght_evenodd         
    ,   input   wire    [0:0]                               i_sel_calwght_evenodd               

    
`endif    
    
    
    
    , input  wire                          i_frm_tick_pre1 // input frm tick                                 
    , input  wire [            NUM_RX-1:0] i_pre_process_in_vld // input valid
    , input  wire [                IB-1:0] i_pre_process_in_I // input I
    , input  wire [                IB-1:0] i_pre_process_in_Q // input Q                                     
    , output wire [            NUM_RX-1:0] o_pre_process_out_vld // output valid
    , output wire [                16-1:0] o_pre_process_out_I // output I    
    , output wire [                16-1:0] o_pre_process_out_Q // output Q    
    , output wire                          o_pre_process_frm_tick // output frm tick 
    , output wire [                 6-1:0] o_sltIdx
    , output wire [                 4-1:0] o_symIdx

`ifdef ULFE_AIE_8RX_4CHAIN    
    , output wire [31:0]     o_cnt_st01_a2p_last                                        
    , output wire [31:0]     o_cnt_st01_a2p_0dat  
    , output wire [31:0]     o_cnt_fd_0dat 
    , input  wire                           i_aie_rst 
    , input  wire                           i_aie_clk 
    , input   wire    [1   -1:0]            i_p2a0_ready    
    , output  wire    [1   -1:0]            o_p2a0_valid    
    , output  wire    [64  -1:0]            o_p2a0_data     
    , output  wire    [1   -1:0]            o_p2a0_last     
    , output  wire    [8   -1:0]            o_p2a0_keep     
    , output  wire    [1   -1:0]            o_a2p0_ready 
    , input   wire    [1   -1:0]            i_a2p0_valid 
    , input   wire    [64  -1:0]            i_a2p0_data  
    , input   wire    [1   -1:0]            i_a2p0_last  
                                            
    , input   wire    [1   -1:0]            i_p2a1_ready    
    , output  wire    [1   -1:0]            o_p2a1_valid    
    , output  wire    [64  -1:0]            o_p2a1_data     
    , output  wire    [1   -1:0]            o_p2a1_last     
    , output  wire    [8   -1:0]            o_p2a1_keep     
    , output  wire    [1   -1:0]            o_a2p1_ready 
    , input   wire    [1   -1:0]            i_a2p1_valid 
    , input   wire    [64  -1:0]            i_a2p1_data  
    , input   wire    [1   -1:0]            i_a2p1_last  
`endif

);

    //*****************************************************************
    //signal define

    //FREQ_SHIFT output signal
    wire   [     NUM_RX-1:0]   w_FREQSHIFT_out_vld      ;
    wire   [         OB-1:0]   w_FREQSHIFT_out_I        ;
    wire   [         OB-1:0]   w_FREQSHIFT_out_Q        ;
    wire                       w_FREQSHIFT_frm_tick_pre1;
    wire                       w_FREQSHIFT_sym_tick     ;
    wire                       w_FREQSHIFT_bcf_en       ;
    wire                       w_FREQSHIFT_tdd_mode     ;

    //CPRM output              
    wire   [     NUM_RX-1:0]   w_CPRM_out_vld           ;
    wire   [         OB-1:0]   w_CPRM_out_I             ;
    wire   [         OB-1:0]   w_CPRM_out_Q             ;
    wire                       w_CPRM_frm_tick          ;
    wire                       w_CPRM_slt_tick          ;
    wire                       w_CPRM_sym_tick          ;
    wire   [          6-1:0]   w_CPRM_sltIdx            ;
    wire   [          4-1:0]   w_CPRM_symIdx            ;
    wire                       w_CPRM_bcf_en            ;
    wire                       w_CPRM_tdd_mode          ;

    //tdagc output                                      
    wire                       w_tdagc_frm_tick         ;
    wire                       w_tdagc_slt_tick         ;
    wire                       w_tdagc_sym_tick         ;
    wire   [            3:0]   w_tdagc_ro_idx           ;
    wire   [            3:0]   w_tdagc_sym_idx          ;
    wire   [     NUM_RX-1:0]   w_tdagc_tdagc_vld        ;
    wire   [         OB-1:0]   w_tdagc_tdagc_i          ;
    wire   [         OB-1:0]   w_tdagc_tdagc_q          ;
    wire   [         OB-1:0]   w_tdagc_tdagc_i_0M       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_q_0M       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_i_0L       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_q_0L       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_i_1M       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_q_1M       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_i_1L       ;
    wire   [         OB-1:0]   w_tdagc_tdagc_q_1L       ;
    wire   [         4-1 :0]   w_tdagc_tdgain1          ;
    wire   [         5-1 :0]   w_tdagc_tdgain2          ;
    wire                       w_tdagc_bcf_enb          ;
    wire                       w_tdagc_tdd_mode         ;
    wire   [  NUM_RX*TR-1:0]   w_tdagc_tdrssi           ;
    wire   [     NUM_RX-1:0]   w_tdagc_tdrssi_vld       ;
    wire   [          5-1:0]   w_tdagc_gain             ;
    
    wire [                   0:0]     w_tdrssi_trigger              ;
    wire [                 7-1:0]     w_tdrssi_start_slt_idx        ;
    wire [                 4-1:0]     w_tdrssi_start_sym_idx        ;
    wire [                 6-1:0]     w_tdrssi_syms_size            ;
    wire                              w_tdrssi_cap_done             ;
    wire [                 4-1:0]     w_tdrssi_rd_symidx            ;
    wire                              w_tdrssi_rd_rqst              ;
    wire                              w_tdrssi_vld                  ;
    wire     [            NUM_RX*TR-1:0] w_tdrssi                   ;
    
    

    //fft block output signal                           
    wire   [     NUM_RX-1:0]   w_fft_blk_fd_vld         ;
    wire   [         OB-1:0]   w_fft_blk_fd_i           ;
    wire   [         OB-1:0]   w_fft_blk_fd_q           ;
    //wire   [          6-1:0]   w_fft_blk_fft_err_flag   ;

    //gain comp block output signal
    wire    [   NUM_RX-1:0]   w_GAINCOMP_fft_ram_rd_req;
    wire    [   NUM_RX-1:0]   w_GAINCOMP_fft_tone_valid;
    wire                       w_GAINCOMP_frm_tick      ;
    wire                       w_GAINCOMP_slt_tick      ;
    wire                       w_GAINCOMP_sym_tick      ;
    wire                       w_gaincomp_CALB_frm_tick ;
    wire                       w_gaincomp_CALB_slt_tick ;
    wire                       w_gaincomp_CALB_sym_tick ;
    wire    [         6-1:0]   w_gaincomp_CALB_sltIdx   ;
    wire    [         4-1:0]   w_gaincomp_CALB_symIdx   ;
    wire    [    NUM_RX-1:0]   w_GAINCOMP_out_vld       ;
    wire    [        OB-1:0]   w_GAINCOMP_out_I         ;
    wire    [        OB-1:0]   w_GAINCOMP_out_Q         ;

    //CALB buf output signal
    wire                       w_cal_wght_vld           ;
    wire    [ NUM_RX*CALWB-1:0]   w_cal_wght_i             ;
    wire 	[ NUM_RX*CALWB-1:0]   w_cal_wght_q             ;

    //CALB block output signal
    wire                       w_CALB_cal_buf_rd_vld    ;
    wire                       w_CALB_cal_buf_rd_bank   ;
    wire                       w_CALB_cal_buf_rd_init   ;
    wire    [  NUM_RX* 1-1:0]  w_CALB_out_vld      ;
    wire    [         OB-1:0]  w_CALB_out_I        ;
    wire    [         OB-1:0]  w_CALB_out_Q        ;
    wire                       w_CALB_bcf_en            ;
    wire                       w_CALB_tdd_mode          ;
    wire                       w_CALB_frm_tick          ;
    wire                       w_CALB_slt_tick          ;
    wire                       w_CALB_sym_tick          ;
    wire    [          6-1:0]  w_CALB_sltIdx            ;
    wire    [          4-1:0]  w_CALB_symIdx            ;
    wire                       w_cal_wght_init          ;
    wire                       w_cal_wght_rqst          ;
    wire    [  NUM_RX* 1-1:0]  w_calwght_evenodd        ;

    //CTS output signal                                 
    wire    [  NUM_RX* 1-1:0]  w_CTS_out_vld            ;
    wire    [         OB-1:0]  w_CTS_out_I              ;
    wire    [         OB-1:0]  w_CTS_out_Q              ;
    wire                       w_CTS_bcf_en             ;
    wire                       w_CTS_tdd_mode           ;
    wire                       w_CTS_frm_tick           ;
    wire                       w_CTS_slt_tick           ;
    wire                       w_CTS_sym_tick           ;
    wire    [          6-1:0]  w_CTS_sltIdx             ;
    wire    [          4-1:0]  w_CTS_symIdx             ;

    //phase comp output signal                          
    wire                       w_slt_tick               ;
    wire                       w_sym_tick               ;
    wire    [          6-1:0]  w_sltIdx                 ;
    wire    [          4-1:0]  w_symIdx                 ;
    wire                       w_bcf_en                 ;
    wire                       w_tdd_mode               ;
    wire    [      NUM_RX-1:0] w_pre_process_out_vld    ; // output valid
    wire    [          OB-1:0] w_pre_process_out_I      ; // output I    
    wire    [          OB-1:0] w_pre_process_out_Q      ; // output Q    
    wire                       w_pre_process_frm_tick   ; // output frm tick 

    //Cp delayed
`ifdef ULFE_Cp
    wire [3:0]                    w_uin_symbol_idx      ;
`endif
`ifdef ULFE_DSS
    wire                          w_uin_en_technology   ;
    wire                          w_uin_technology_dss  ;
`endif

    //*****************************************************************
    // symbol parameter resync for alignment
    wire    [        NUM_RX-1:0]  w_calBypassFlag_d3        ;
    wire 	[	  NUM_RX* 4-1:0]  w_calWScale               ;
    wire    [        NUM_RX-1:0]  w_calOn                   ;
    wire    [        NUM_RX-1:0]  w_cts_on                  ;
    wire    [     NUM_RX*12-1:0]  w_cts_shft                ;
    wire    [        NUM_RX-1:0]  w_phaseCompOn             ;
    wire    [          9-1:0]  w_rb_size                    ;


ylib_reg_clk_en #(.WIDTH(NUM_RX   ), .DEPTH(3)) sync_o_sym_tick   ( .i_clk(i_clk),  .i_en(w_FREQSHIFT_sym_tick), .i_in(i_calBypassFlag), .o_out(w_calBypassFlag_d3));
ylib_shr_en #(.WIDTH(NUM_RX*4 ), .DEPTH(3)) sync_calw_scal    ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_calWScale    ), .o_out(w_calWScale       ));
ylib_shr_en #(.WIDTH(NUM_RX   ), .DEPTH(3)) sync_o_cal_on     ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_calOn        ), .o_out(w_calOn           ));
ylib_shr_en #(.WIDTH(NUM_RX   ), .DEPTH(1)) sync_cts_on       ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_cts_on       ), .o_out(w_cts_on          ));
ylib_shr_en #(.WIDTH(NUM_RX*12), .DEPTH(3)) sync_cts_shift    ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_cts_shft     ), .o_out(w_cts_shft        ));
ylib_shr_en #(.WIDTH(NUM_RX   ), .DEPTH(1)) sync_phasecomp_on ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_phaseCompOn  ), .o_out(w_phaseCompOn     ));
ylib_shr_en #(.WIDTH(9     ), .DEPTH(3)) sync_rb_size      ( .i_clk(i_clk),  .i_en(i_frm_tick_pre1), .i_in(i_rb_size      ), .o_out(w_rb_size         ));

    ulfe_freq_shift #( .NUM_RX(NUM_RX),.SCO(MAX_SCIDX),.IB(IB),.OB(OB) ) u_ulfe_freq_shift
    (
        .i_clk                ( i_clk                         ) // input    wire  					    
        ,.i_frm_tick_pre1      ( i_frm_tick_pre1               ) // input    wire  					            
        ,.i_bcf_en             ( i_bcf_en                      ) // input    wire  					            
        ,.i_tdd_mode           ( i_tdd_mode                    ) // input    wire  					            
        ,.i_freqShiftOn        ( i_freqShiftOn                 ) // input    wire  [	  OVS-1:0]	        
        ,.i_calBypassFlag      ( i_calBypassFlag               ) // input    wire  [	  OVS-1:0]	      	
        ,.i_scsType            ( i_scsType                     )
        ,.i_cpType             ( i_cpType                      ) // input    wire                      	
        ,.i_fftType            ( i_fftType                     ) // input    wire  [	    2-1:0]	        
        ,.i_FREQSHIFT_in_vld   ( i_pre_process_in_vld          ) // input    wire  [	  OVS-1:0]			 	//tick
        ,.i_FREQSHIFT_in_I     ( i_pre_process_in_I            ) // input    wire  [	   IB-1:0]	      	
        ,.i_FREQSHIFT_in_Q     ( i_pre_process_in_Q            ) // input    wire  [	   IB-1:0]	      	
        ,.o_FREQSHIFT_out_vld  ( w_FREQSHIFT_out_vld           ) // output   reg   [	  OVS-1:0]	w_FREQSHIFT_out_vld	        	
        ,.o_FREQSHIFT_out_I    ( w_FREQSHIFT_out_I             ) // output   reg   [	   OB-1:0]	w_FREQSHIFT_out_I		        	  
        ,.o_FREQSHIFT_out_Q    ( w_FREQSHIFT_out_Q             ) // output   reg   [	   OB-1:0]	w_FREQSHIFT_out_Q		        	  
        ,.o_frm_tick_pre1      ( w_FREQSHIFT_frm_tick_pre1     ) // output   wire                w_FREQSHIFT_frm_tick_pre1 
        ,.o_sym_tick           ( w_FREQSHIFT_sym_tick          )
        ,.o_bcf_en             ( w_FREQSHIFT_bcf_en            ) // output   wire                w_FREQSHIFT_bcf_en              
        ,.o_tdd_mode           ( w_FREQSHIFT_tdd_mode          ) // output   wire                w_FREQSHIFT_tdd_mode            
//      ,.o_FREQSHIFT_latency  ( o_FREQSHIFT_latency           ) // output   wire  [	   32-1:0]  w_FREQSHIFT_latency             
    );

    ulfe_cprm #(.NUM_RX(NUM_RX),.IB(IB),.OB(OB)) u_ulfe_cprm
        (
        .i_clk              (i_clk)
        ,.i_frm_tick_adv1   (w_FREQSHIFT_frm_tick_pre1) 
//        ,.i_bcf_en          (i_bcf_en)
        ,.i_calBypassFlag   (i_calBypassFlag)
        ,.i_scsType         (i_scsType)
        ,.i_cpType          (i_cpType)
        ,.i_fftType         (i_fftType)
        ,.i_osr_quotient    (i_osr_quotient)
        ,.i_cpRmOffset      (i_cpRmOffset)
        ,.i_CPRM_in_vld     (w_FREQSHIFT_out_vld)      
        ,.i_CPRM_in_I       (w_FREQSHIFT_out_I)      
        ,.i_CPRM_in_Q       (w_FREQSHIFT_out_Q)      
        ,.o_CPRM_out_vld    (w_CPRM_out_vld)
        ,.o_CPRM_out_I      (w_CPRM_out_I)
        ,.o_CPRM_out_Q      (w_CPRM_out_Q)
        ,.o_frm_tick        (w_CPRM_frm_tick)
//        ,.o_bcf_en          (w_CPRM_bcf_en)
);



`ifdef ULFE_AIE_8RX_4CHAIN    
wire                       w_d1_tdagc_frm_tick ;
wire                       w_d1_tdagc_slt_tick ;
wire                       w_d1_tdagc_sym_tick ;
ylib_reg #(.WIDTH(3)   ,.DEPTH(1))  u00_lib_reg(.i_clk(i_clk),.i_in({w_tdagc_frm_tick,w_tdagc_slt_tick,w_tdagc_sym_tick} ), .o_out({w_d1_tdagc_frm_tick,w_d1_tdagc_slt_tick,w_d1_tdagc_sym_tick} ));

    ulfe_tagc_aie # ( .OC(OC), .IB(IB), .OB(OB), .TR(TR), .N_CYCLE_CLK(FS_CLK), .SCS_IDX(MAX_SCIDX), .CP_TYPE(CPTYPE) ,.VENDOR(VENDOR),.FHTYPE(FHTYPE))  u_ulfe_tagc_aie
    (
        .i_rst                  ( i_rst                        ) // input                  
        ,.i_clk                  ( i_clk                        ) // input                  
        ,.i_frm_tick_pre1        ( w_CPRM_frm_tick              ) // input                  
        ,.i_tdagc_vld            ( w_CPRM_out_vld               ) // input  [OVS-1:0]       
        ,.i_tdagc_i              ( w_CPRM_out_I                 ) // input  [IB-1:0]        
        ,.i_tdagc_q              ( w_CPRM_out_Q                 ) // input  [IB-1:0]        
        ,.i_bcf_enb              ( i_bcf_en                     ) // input                  
        ,.i_tdd_mode             ( i_tdd_mode                   ) // input                  
        ,.i_tagcbackoff          ( i_tagcbackoff                ) // input  [4:0]  i_tagcbackoff           
        ,.i_ffttype              ( {2'b00,i_fftType}            ) // input  [3:0]                 
        ,.i_tagcon               ( i_tagcon                     ) // input         i_tagcon                      
        ,.i_calbypassflag        ( i_calBypassFlag              ) // input                  
        ,.i_tagcdb_conv_mod      ( 4'b0000                      ) // input  [3:0]                    
        ,.o_frm_tick             ( w_tdagc_frm_tick             ) // valid Aligned
        ,.o_slt_tick             ( w_tdagc_slt_tick             ) // valid Aligned
        ,.o_sym_tick             ( w_tdagc_sym_tick             ) // valid Aligned
        ,.o_tdagc_vld            ( w_tdagc_tdagc_vld            ) // output [OVS-1:0] o_tdagc_tdagc_vld               
        ,.o_tdagc_i_0M           ( w_tdagc_tdagc_i_0M           ) // output [OB-1:0]  o_tdagc_tdagc_i                 
        ,.o_tdagc_q_0M           ( w_tdagc_tdagc_q_0M           ) // output [OB-1:0]  o_tdagc_tdagc_q  
        ,.o_tdagc_i_0L           ( w_tdagc_tdagc_i_0L           ) // output [OB-1:0]  o_tdagc_tdagc_i                 
        ,.o_tdagc_q_0L           ( w_tdagc_tdagc_q_0L           ) // output [OB-1:0]  o_tdagc_tdagc_q  
        ,.o_tdagc_i_1M           ( w_tdagc_tdagc_i_1M           ) // output [OB-1:0]  o_tdagc_tdagc_i                 
        ,.o_tdagc_q_1M           ( w_tdagc_tdagc_q_1M           ) // output [OB-1:0]  o_tdagc_tdagc_q  
        ,.o_tdagc_i_1L           ( w_tdagc_tdagc_i_1L           ) // output [OB-1:0]  o_tdagc_tdagc_i                 
        ,.o_tdagc_q_1L           ( w_tdagc_tdagc_q_1L           ) // output [OB-1:0]  o_tdagc_tdagc_q  
        ,.o_tdagc_tdrssi         ( w_tdagc_tdrssi               ) // output [OVS*TR-1:0]     
        ,.o_tdagc_tdrssi_vld     ( w_tdagc_tdrssi_vld           ) // output [OVS-1:0]       
        ,.o_tdgain1              ( w_tdagc_tdgain1              ) // output [4-1 :0]  o_tdagc_tdgain1                 
        ,.o_tdgain2              ( w_tdagc_tdgain2              ) // output [5-1 :0]  o_tdagc_tdgain2 
        ,.o_tdagc_gain           ( w_tdagc_gain                 )
        ,.o_bcf_enb              ( w_tdagc_bcf_enb              ) // output           o_tdagc_bcf_enb                 
        ,.o_tdd_mode             ( w_tdagc_tdd_mode             ) // output           o_tdagc_tdd_mode                
//      ,.o_tdagc_latency        ( o_TDAGC_latency              ) // output [31:0]    o_tdagc_latency                 
        ,.i_tdrssi_trigger       ( w_tdrssi_trigger             ) //  input  [0:0]        i_tdrssi_trigger         
        ,.i_tdrssi_start_slt_idx ( w_tdrssi_start_slt_idx       ) //  input  [8-1:0]      i_tdrssi_start_slt_idx   
        ,.i_tdrssi_start_sym_idx ( w_tdrssi_start_sym_idx       ) //  input  [4-1:0]      i_tdrssi_start_sym_idx   
        ,.i_tdrssi_syms_size     ( w_tdrssi_syms_size           ) //  input  [5-1:0]      i_tdrssi_syms_size       
        ,.o_tdrssi_cap_done      ( w_tdrssi_cap_done            ) //  output              o_tdrssi_cap_done        
        ,.i_tdrssi_rd_symidx     ( w_tdrssi_rd_symidx           ) //  input  [4-1:0]      i_tdrssi_rd_symidx       
        ,.i_tdrssi_rd_rqst       ( w_tdrssi_rd_rqst             ) //  input               i_tdrssi_rd_rqst         
        ,.o_tdrssi_vld           ( w_tdrssi_vld                 ) //  output                         
        ,.o_tdrssi               ( w_tdrssi                     ) //  output [OVS*TR-1:0] o_tdrssi                 
    );

    fft_blk_aie #(.IB(IB), .OB(OB), .NUM_RX(NUM_RX) ,.  MAX_NFFT(MAX_NFFT)  ,.VENDOR(VENDOR)) u_fft_blk_aie
    (
        .i_clk                   ( i_clk                       ) //input  wire                     // i_clk 
        ,.i_rst                  ( i_rst                       ) //input  wire                     // Sync. Reset Active High
        ,.i_aie_clk              ( i_aie_clk                   ) //input  wire                     // i_clk 
        ,.i_aie_rst              ( i_aie_rst                   ) //input  wire                     // Sync. Reset Active High
        ,.i_td_vld               ( w_tdagc_tdagc_vld        ) //input  wire [   (2**OC)-1:0]    // Input Signal Enable
     //   ,.i_td_vld_pre1          ( w_tdagc_tdagc_vld           ) //input  wire [   (2**OC)-1:0]    // Input Signal Enable pre1
        ,.i_td_i_0M              ( w_tdagc_tdagc_i_0M          ) //input  wire [        IB-1:0]    // Inphase Input Signal
        ,.i_td_q_0M              ( w_tdagc_tdagc_q_0M          ) //input  wire [        IB-1:0]    // Quadrature Input Signal
        ,.i_td_i_0L              ( w_tdagc_tdagc_i_0L          ) //input  wire [        IB-1:0]    // Inphase Input Signal
        ,.i_td_q_0L              ( w_tdagc_tdagc_q_0L          ) //input  wire [        IB-1:0]    // Quadrature Input Signal
        ,.i_td_i_1M              ( w_tdagc_tdagc_i_1M          ) //input  wire [        IB-1:0]    // Inphase Input Signal
        ,.i_td_q_1M              ( w_tdagc_tdagc_q_1M          ) //input  wire [        IB-1:0]    // Quadrature Input Signal
        ,.i_td_i_1L              ( w_tdagc_tdagc_i_1L          ) //input  wire [        IB-1:0]    // Inphase Input Signal
        ,.i_td_q_1L              ( w_tdagc_tdagc_q_1L          ) //input  wire [        IB-1:0]    // Quadrature Input Signal
        ,.i_td_sym_tick          ( w_tdagc_sym_tick         ) //input  wire [          1-1:0]    // ISS output Symbol tick pre5
        ,.i_fd_rqst              ( w_GAINCOMP_fft_ram_rd_req   ) //input  wire [   (2**OC)-1:0] i_fd_rqst   // FFT Output Request
        ,.i_sc_vld               ( w_GAINCOMP_fft_tone_valid   ) //input  wire [   (2**OC)-1:0] i_sc_vld    // FFT Output vld Related to RB Size
        ,.i_rb_size              ( i_rb_size                   ) //input  wire [         9-1:0]  
        ,.i_k0                   ( i_k0                        ) //input  wire [        12-1:0]  
        ,.i_fft_sz_idx           ( i_fftType                   ) //input  wire [         2-1:0]    // fft size
        ,.i_fft_buf_in_vld_frm   ( w_tdagc_frm_tick         ) //input  wire [         1-1:0]    // 
        ,.i_fft_buf_in_vld_slt   ( w_tdagc_slt_tick         ) //input  wire [         1-1:0]    // 
        ,.i_fft_buf_out_vld_frm  ( w_GAINCOMP_frm_tick         ) //input  wire [         1-1:0]  i_fft_buf_out_vld_frm   // 
        ,.i_fft_buf_out_vld_slt  ( w_GAINCOMP_slt_tick         ) //input  wire [         1-1:0]  i_fft_buf_out_vld_slt   // 
        ,.o_fd_vld               ( w_fft_blk_fd_vld            ) //output wire [   (2**OC)-1:0]  w_fft_blk_fd_vld             // Output Signal Enable
        ,.o_fd_i                 ( w_fft_blk_fd_i                ) //output wire [        OB-1:0]  w_fft_blk_fd_i               // Inphase Output Signal
        ,.o_fd_q                 ( w_fft_blk_fd_q                ) //output wire [        OB-1:0]  w_fft_blk_fd_q               // Quadrature Output Signal 
        ,.o_cnt_st01_a2p_last    ( o_cnt_st01_a2p_last)                                    
        ,.o_cnt_st01_a2p_0dat    ( o_cnt_st01_a2p_0dat)
        ,.o_cnt_fd_01dat          ( o_cnt_fd_0dat)
    
    
        ,.i_p2a0_ready           ( i_p2a0_ready )
        ,.o_p2a0_valid           ( o_p2a0_valid )
        ,.o_p2a0_data            ( o_p2a0_data  )
        ,.o_p2a0_last            ( o_p2a0_last  )
        ,.o_p2a0_keep            ( o_p2a0_keep  )
        ,.o_a2p0_ready           ( o_a2p0_ready )
        ,.i_a2p0_valid           ( i_a2p0_valid )
        ,.i_a2p0_data            ( i_a2p0_data  )
        ,.i_a2p0_last            ( i_a2p0_last  )
        ,.i_p2a1_ready           ( i_p2a1_ready )
        ,.o_p2a1_valid           ( o_p2a1_valid )
        ,.o_p2a1_data            ( o_p2a1_data  )
        ,.o_p2a1_last            ( o_p2a1_last  )
        ,.o_p2a1_keep            ( o_p2a1_keep  )
        ,.o_a2p1_ready           ( o_a2p1_ready )
        ,.i_a2p1_valid           ( i_a2p1_valid )
        ,.i_a2p1_data            ( i_a2p1_data  )
        ,.i_a2p1_last            ( i_a2p1_last  )

    );
    
    `ifdef    ULFE_AIE_ILADBG
        (* dont_touch="true" *) reg    [1   -1:0]            ri_p2a0_ready       [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_p2a0_valid       [1:0];  
        (* dont_touch="true" *) reg    [64  -1:0]            ro_p2a0_data        [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_p2a0_last        [1:0];  
        (* dont_touch="true" *) reg    [8   -1:0]            ro_p2a0_keep        [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_a2p0_ready       [1:0];
        (* dont_touch="true" *) reg    [1   -1:0]            ri_a2p0_valid       [1:0];
        (* dont_touch="true" *) reg    [64  -1:0]            ri_a2p0_data        [1:0];
        (* dont_touch="true" *) reg    [1   -1:0]            ri_a2p0_last        [1:0];
                                                                                 
        (* dont_touch="true" *) reg    [1   -1:0]            ri_p2a1_ready       [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_p2a1_valid       [1:0];  
        (* dont_touch="true" *) reg    [64  -1:0]            ro_p2a1_data        [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_p2a1_last        [1:0];  
        (* dont_touch="true" *) reg    [8   -1:0]            ro_p2a1_keep        [1:0];  
        (* dont_touch="true" *) reg    [1   -1:0]            ro_a2p1_ready       [1:0];
        (* dont_touch="true" *) reg    [1   -1:0]            ri_a2p1_valid       [1:0];
        (* dont_touch="true" *) reg    [64  -1:0]            ri_a2p1_data        [1:0];
        (* dont_touch="true" *) reg    [1   -1:0]            ri_a2p1_last        [1:0];
        
        (* dont_touch="true" *) reg    [1   -1:0]            rw_d1_tdagc_frm_tick [1:0] ;
        
        always @(posedge i_aie_clk    )
        begin
            ri_p2a0_ready        [0]     <=  i_p2a0_ready        ;
            ro_p2a0_valid        [0]     <=  o_p2a0_valid        ;
            ro_p2a0_data         [0]     <=  o_p2a0_data         ;
            ro_p2a0_last         [0]     <=  o_p2a0_last         ;
            ro_p2a0_keep         [0]     <=  o_p2a0_keep         ;
            ro_a2p0_ready        [0]     <=  o_a2p0_ready        ;
            ri_a2p0_valid        [0]     <=  i_a2p0_valid        ;
            ri_a2p0_data         [0]     <=  i_a2p0_data         ;
            ri_a2p0_last         [0]     <=  i_a2p0_last         ;
            ri_p2a1_ready        [0]     <=  i_p2a1_ready        ;
            ro_p2a1_valid        [0]     <=  o_p2a1_valid        ;
            ro_p2a1_data         [0]     <=  o_p2a1_data         ;
            ro_p2a1_last         [0]     <=  o_p2a1_last         ;
            ro_p2a1_keep         [0]     <=  o_p2a1_keep         ;
            ro_a2p1_ready        [0]     <=  o_a2p1_ready        ;
            ri_a2p1_valid        [0]     <=  i_a2p1_valid        ;
            ri_a2p1_data         [0]     <=  i_a2p1_data         ;
            ri_a2p1_last         [0]     <=  i_a2p1_last         ;
            rw_d1_tdagc_frm_tick [0]     <=  w_d1_tdagc_frm_tick ; 
    
            ri_p2a0_ready        [1]     <=  ri_p2a0_ready        [0];
            ro_p2a0_valid        [1]     <=  ro_p2a0_valid        [0];
            ro_p2a0_data         [1]     <=  ro_p2a0_data         [0];
            ro_p2a0_last         [1]     <=  ro_p2a0_last         [0];
            ro_p2a0_keep         [1]     <=  ro_p2a0_keep         [0];
            ro_a2p0_ready        [1]     <=  ro_a2p0_ready        [0];
            ri_a2p0_valid        [1]     <=  ri_a2p0_valid        [0];
            ri_a2p0_data         [1]     <=  ri_a2p0_data         [0];
            ri_a2p0_last         [1]     <=  ri_a2p0_last         [0];
            ri_p2a1_ready        [1]     <=  ri_p2a1_ready        [0];
            ro_p2a1_valid        [1]     <=  ro_p2a1_valid        [0];
            ro_p2a1_data         [1]     <=  ro_p2a1_data         [0];
            ro_p2a1_last         [1]     <=  ro_p2a1_last         [0];
            ro_p2a1_keep         [1]     <=  ro_p2a1_keep         [0];
            ro_a2p1_ready        [1]     <=  ro_a2p1_ready        [0];
            ri_a2p1_valid        [1]     <=  ri_a2p1_valid        [0];
            ri_a2p1_data         [1]     <=  ri_a2p1_data         [0];
            ri_a2p1_last         [1]     <=  ri_a2p1_last         [0];
            rw_d1_tdagc_frm_tick [1]     <=  rw_d1_tdagc_frm_tick [0]; 
            
        end
    
        ila_ulfe_aie_inout u_ila_ulfe_aie_inout (
          .clk      (i_aie_clk),
          .probe0   (ri_p2a0_ready        [1]),
          .probe1   (ro_p2a0_valid        [1]),
          .probe2   (ro_p2a0_data         [1]),
          .probe3   (ro_p2a0_last         [1]),
          .probe4   (ro_p2a0_keep         [1]),
          .probe5   (ro_a2p0_ready        [1]),
          .probe6   (ri_a2p0_valid        [1]),
          .probe7   (ri_a2p0_data         [1]),
          .probe8   (ri_a2p0_last         [1]),
          .probe9   (ri_p2a1_ready        [1]),
          .probe10  (ro_p2a1_valid        [1]),
          .probe11  (ro_p2a1_data         [1]),
          .probe12  (ro_p2a1_last         [1]),
          .probe13  (ro_p2a1_keep         [1]),
          .probe14  (ro_a2p1_ready        [1]),
          .probe15  (ri_a2p1_valid        [1]),
          .probe16  (ri_a2p1_data         [1]),
          .probe17  (ri_a2p1_last         [1]),
          .probe18  (rw_d1_tdagc_frm_tick [1])
        );

    `endif
    
    
`else
    ulfe_tagc # ( .OC(OC), .IB(IB), .OB(OB), .TR(TR), .N_CYCLE_CLK(FS_CLK), .SCS_IDX(MAX_SCIDX), .CP_TYPE(CPTYPE) ,.VENDOR(VENDOR) )  u_ulfe_tagc
    (
        .i_rst                  ( i_rst                        ) 
        ,.i_clk                  ( i_clk                        )
        ,.i_frm_tick_pre1        ( w_CPRM_frm_tick              )
        ,.i_tdagc_vld            ( w_CPRM_out_vld               )
        ,.i_tdagc_i              ( w_CPRM_out_I                 )
        ,.i_tdagc_q              ( w_CPRM_out_Q                 )
        ,.i_bcf_enb              ( i_bcf_en                     )
        ,.i_tdd_mode             ( i_tdd_mode                   )
        ,.i_tagcbackoff          ( i_tagcbackoff                )
        ,.i_ffttype              ( {2'b00,i_fftType}            )
        ,.i_tagcon               ( i_tagcon                     )
        ,.i_calbypassflag        ( i_calBypassFlag              )
        ,.i_tagcdb_conv_mod      ( 4'b0000                      )
        ,.o_frm_tick             ( w_tdagc_frm_tick             )
        ,.o_slt_tick             ( w_tdagc_slt_tick             )
        ,.o_sym_tick             ( w_tdagc_sym_tick             )
        ,.o_tdagc_vld            ( w_tdagc_tdagc_vld            )
        ,.o_tdagc_i              ( w_tdagc_tdagc_i              )
        ,.o_tdagc_q              ( w_tdagc_tdagc_q              )
        ,.o_tdagc_tdrssi         ( w_tdagc_tdrssi               )
        ,.o_tdagc_tdrssi_vld     ( w_tdagc_tdrssi_vld           )
        ,.o_tdgain1              ( w_tdagc_tdgain1              )
        ,.o_tdgain2              ( w_tdagc_tdgain2              )
        ,.o_tdagc_gain           ( w_tdagc_gain                 )
        ,.o_bcf_enb              ( w_tdagc_bcf_enb              )
        ,.o_tdd_mode             ( w_tdagc_tdd_mode             )
//      ,.o_tdagc_latency        ( o_TDAGC_latency              )
//        ,.i_tdrssi_trigger       ( w_tdrssi_trigger             )
//        ,.i_tdrssi_start_slt_idx ( w_tdrssi_start_slt_idx       )
//        ,.i_tdrssi_start_sym_idx ( w_tdrssi_start_sym_idx       )
//        ,.i_tdrssi_syms_size     ( w_tdrssi_syms_size           )
//        ,.o_tdrssi_cap_done      ( w_tdrssi_cap_done            )
//        ,.i_tdrssi_rd_symidx     ( w_tdrssi_rd_symidx           )
//        ,.i_tdrssi_rd_rqst       ( w_tdrssi_rd_rqst             )
//        ,.o_tdrssi_vld           ( w_tdrssi_vld                 )
//        ,.o_tdrssi               ( w_tdrssi                     )
    );


    wire                       w_d1_tdagc_frm_tick ;
    wire                       w_d1_tdagc_slt_tick ;
    wire                       w_d1_tdagc_sym_tick ;
    wire   [     NUM_RX-1:0]      w_d1_tdagc_tdagc_vld;
    wire   [      OB-1:0]      w_d1_tdagc_tdagc_i  ;
    wire   [      OB-1:0]      w_d1_tdagc_tdagc_q  ;

    ylib_reg #(.WIDTH(3)   ,.DEPTH(1))  u00_lib_reg(.i_clk(i_clk),.i_in({w_tdagc_frm_tick,w_tdagc_slt_tick,w_tdagc_sym_tick} ), .o_out({w_d1_tdagc_frm_tick,w_d1_tdagc_slt_tick,w_d1_tdagc_sym_tick} ));
    //ylib_reg #(.WIDTH(1)   ,.DEPTH(1))  u01_lib_reg(.i_clk(i_clk),.i_in(w_tdagc_slt_tick ), .o_out(w_d1_tdagc_slt_tick ));
    ylib_reg #(.WIDTH(NUM_RX) ,.DEPTH(1))  u02_lib_reg(.i_clk(i_clk),.i_in(w_tdagc_tdagc_vld), .o_out(w_d1_tdagc_tdagc_vld));
    ylib_reg #(.WIDTH(IB)  ,.DEPTH(1))  u03_lib_reg(.i_clk(i_clk),.i_in(w_tdagc_tdagc_i  ), .o_out(w_d1_tdagc_tdagc_i  ));
    ylib_reg #(.WIDTH(IB)  ,.DEPTH(1))  u04_lib_reg(.i_clk(i_clk),.i_in(w_tdagc_tdagc_q  ), .o_out(w_d1_tdagc_tdagc_q  ));

    fft_blk #(.IB(IB), .OB(OB), .OC(OC) ,.  MAX_NFFT(MAX_NFFT)  ,.VENDOR(VENDOR)) u_fft_blk
    (
        .i_clk                  ( i_clk                       ) //input  wire                     // i_clk 
        ,.i_rst                  ( i_rst                       ) //input  wire                     // Sync. Reset Active High
        ,.i_td_vld               ( w_d1_tdagc_tdagc_vld        ) //input  wire [   (2**OC)-1:0]    // Input Signal Enable
        ,.i_td_vld_pre1          ( w_tdagc_tdagc_vld           ) //input  wire [   (2**OC)-1:0]    // Input Signal Enable pre1
        ,.i_td_i                 ( w_d1_tdagc_tdagc_i          ) //input  wire [        IB-1:0]    // Inphase Input Signal
        ,.i_td_q                 ( w_d1_tdagc_tdagc_q          ) //input  wire [        IB-1:0]    // Quadrature Input Signal
        ,.i_td_sym_tick          ( w_d1_tdagc_sym_tick         ) //input  wire [          1-1:0]    // ISS output Symbol tick pre5
        ,.i_fd_rqst              ( w_GAINCOMP_fft_ram_rd_req   ) //input  wire [   (2**OC)-1:0] i_fd_rqst   // FFT Output Request
        ,.i_sc_vld               ( w_GAINCOMP_fft_tone_valid   ) //input  wire [   (2**OC)-1:0] i_sc_vld    // FFT Output vld Related to RB Size
        ,.i_rb_size              ( i_rb_size                   ) //input  wire [         9-1:0]  
        ,.i_k0                   ( i_k0                        ) //input  wire [        12-1:0]  
        ,.i_fft_sz_idx           ( i_fftType                   ) //input  wire [         2-1:0]    // fft size
        ,.i_fft_buf_in_vld_frm   ( w_d1_tdagc_frm_tick         ) //input  wire [         1-1:0]    // 
        ,.i_fft_buf_in_vld_slt   ( w_d1_tdagc_slt_tick         ) //input  wire [         1-1:0]    // 
        ,.i_fft_buf_out_vld_frm  ( w_GAINCOMP_frm_tick         ) //input  wire [         1-1:0]  i_fft_buf_out_vld_frm   // 
        ,.i_fft_buf_out_vld_slt  ( w_GAINCOMP_slt_tick         ) //input  wire [         1-1:0]  i_fft_buf_out_vld_slt   // 
        ,.o_fd_vld               ( w_fft_blk_fd_vld            ) //output wire [   (2**OC)-1:0]  w_fft_blk_fd_vld             // Output Signal Enable
        ,.o_fd_i                 ( w_fft_blk_fd_i              ) //output wire [        OB-1:0]  w_fft_blk_fd_i               // Inphase Output Signal
        ,.o_fd_q                 ( w_fft_blk_fd_q              ) //output wire [        OB-1:0]  w_fft_blk_fd_q               // Quadrature Output Signal 
//        ,.o_fft_err_flag         ( o_fft_blk_fft_err_flag      ) //output wire [         6-1:0]  w_fft_blk_fft_err_flag       // FFT IP Error Flag
//      ,.o_fft_latency          ( o_FFT_BLK_latency           )
    );
`endif    


`ifdef ULFE_TAGC_TDRSSI
//assign w_tdrssi_trigger                 = i_tdrssi_trigger          ;
//assign w_tdrssi_start_slt_idx           = i_tdrssi_start_slt_idx    ;
//assign w_tdrssi_start_sym_idx           = i_tdrssi_start_sym_idx    ;
//assign w_tdrssi_syms_size               = i_tdrssi_syms_size        ;
assign o_tdagc_frm_tick                 = w_CPRM_frm_tick           ;
assign o_tdagc_tdrssi_vld               = w_tdagc_tdrssi_vld        ;   
assign o_tdagc_tdrssi                   = w_tdagc_tdrssi            ;

//assign o_tdrssi_cap_done            = w_tdrssi_cap_done          ;
//assign i_tdrssi_rd_symidx           = w_tdrssi_rd_symidx         ;
//assign i_tdrssi_rd_rqst             = w_tdrssi_rd_rqst           ;
//assign o_tdrssi_vld                 = w_tdrssi_vld               ;
//assign o_tdrssi                     = w_tdrssi                   ;
`endif




    

    ulfe_gain_comp #(.IB(IB), .OB(OB), .OC(OC), .FS_CLK(FS_CLK), .SCIDX(MAX_SCIDX), .CPTYPE(CPTYPE)) u_ulfe_gain_comp
    (
         .i_clk                  ( i_clk                       ) //input   wire                                    // Clock  
        ,.i_rst                  ( i_rst                       ) //input   wire                                    
        ,.i_frm_tick             ( w_d1_tdagc_frm_tick         ) //input   wire                                    // frm_tick from FFT_blk, this tick is ~1symbol delay of FFT
        ,.i_rb_size              ( w_rb_size                   ) //input   wire [         9-1:0]  
        ,.i_fftType              ( i_fftType                   ) 
        ,.i_cpRmOffset           (i_cpRmOffset)
        ,.i_gainCompOn           ( i_gainCompOn                ) //input   wire [       OVS-1:0]          // common parameter
        ,.i_calBypassFlag        ( w_calBypassFlag_d3          ) //input   wire [       OVS-1:0]          // parameter                     
        ,.i_tdagc_vld            ( w_tdagc_tdagc_vld           ) //input   wire [       OVS-1:0]                   //tagc gain valid
        ,.i_tdagc_sym_tick       (w_d1_tdagc_sym_tick) 
        ,.i_td_gain1             ( w_tdagc_tdgain1             ) //input   wire [         4-1:0]                   //tagc gain1
        ,.i_td_gain2             ( w_tdagc_tdgain2             ) //input   wire [         5-1:0]                   //tagc gain2
        ,.i_gaincomp_in_vld      ( w_fft_blk_fd_vld            ) //input   wire [       OVS-1:0]                   // enable of input
        ,.i_gaincomp_in_I        ( w_fft_blk_fd_i              ) //input   wire [   	    IB-1:0]                // in-phase input
        ,.i_gaincomp_in_Q        ( w_fft_blk_fd_q              ) //input   wire [   	    IB-1:0]                // quadrature input   
        ,.o_fft_ram_rd_req       ( w_GAINCOMP_fft_ram_rd_req   ) //output  reg  [         OVS-1:0]   w_GAINCOMP_fft_ram_rd_req              // enable of rd req, to FFT blk   
        ,.o_tone_valid           ( w_GAINCOMP_fft_tone_valid   )
        ,.o_frm_tick             ( w_GAINCOMP_frm_tick         )
        ,.o_slt_tick             ( w_GAINCOMP_slt_tick         ) //output  wire                      w_GAINCOMP_slt_tick                    // slot tick, to FFT blk
        ,.o_sym_tick             ( w_GAINCOMP_sym_tick         ) //output  wire                      w_GAINCOMP_sym_tick                    // symbol tick, to FFT blk      
        ,.o_gaincomp_frm_tick    ( w_gaincomp_CALB_frm_tick    ) //output  wire                     w_gaincomp_CALB_frm_tick               
        ,.o_gaincomp_slt_tick    ( w_gaincomp_CALB_slt_tick    ) //output  wire                     w_gaincomp_CALB_slt_tick               
        ,.o_gaincomp_sym_tick    ( w_gaincomp_CALB_sym_tick    ) //output  wire                     w_gaincomp_CALB_sym_tick               
        ,.o_gaincomp_sltIdx      ( w_gaincomp_CALB_sltIdx      ) //output  wire  [      6-1 : 0]    w_gaincomp_CALB_sltIdx	                   
        ,.o_gaincomp_symIdx      ( w_gaincomp_CALB_symIdx      ) //output  wire  [      4-1 : 0]    w_gaincomp_CALB_symIdx	                                                                                       
        ,.o_gaincomp_out_vld     ( w_GAINCOMP_out_vld          ) //output  reg  [         OVS-1:0]   w_GAINCOMP_out_vld                     // enable of output 
        ,.o_gaincomp_out_I       ( w_GAINCOMP_out_I            ) //output  reg  [   	    OB-1:0]   w_GAINCOMP_out_I                      // in-phase output
        ,.o_gaincomp_out_Q       ( w_GAINCOMP_out_Q            ) //output  reg  [   	    OB-1:0]   w_GAINCOMP_out_Q                      // quadrature output      
//      ,.o_gaincomp_latency     ( o_GAINCOMP_latency          )                                                 
    );
    
    ///////////////////////////////////////////////////////////////////////////
    //CDC for calc buf
    //
    reg   r1_cal_wght_wren ;
    reg   r2_cal_wght_wren ;
    reg   r3_cal_wght_wren ;
    reg   r4_cal_wght_wren ;
                           
    reg   r1_cal_wght_rden ;
    reg   r2_cal_wght_rden ;
    reg   r3_cal_wght_rden ;
    reg   r4_cal_wght_rden ;
    
    reg [                11-1:0] r_cal_wght_addr      ;   // calb weight rd/wr interface
    reg [                 1-1:0] r_cal_wght_buf_bus   ;   // calb weight rd/wr interface
    reg [                 1-1:0] r_cal_wght_buf_core  ;   // calb weight rd/wr interface
    reg [     (NUM_RX)*CALWB-1:0] r_cal_wght_wr_i      ;   // calb weight rd/wr interface
    reg [     (NUM_RX)*CALWB-1:0] r_cal_wght_wr_q      ;   // calb weight rd/wr interface
    reg                          r_cal_wght_wren      ;
    reg                          r_cal_wght_rden      ;
    
    always @ (posedge i_clk) begin
        r1_cal_wght_wren     <= i_cal_wght_wren ;
        r2_cal_wght_wren     <= r1_cal_wght_wren;
        r3_cal_wght_wren     <= r2_cal_wght_wren;
        r4_cal_wght_wren     <= r2_cal_wght_wren && (~r3_cal_wght_wren);
        r_cal_wght_wren      <= r4_cal_wght_wren;
        
        r1_cal_wght_rden     <= i_cal_wght_rden ;
        r2_cal_wght_rden     <= r1_cal_wght_rden;
        r3_cal_wght_rden     <= r2_cal_wght_rden;
        r4_cal_wght_rden     <= r2_cal_wght_rden && (~r3_cal_wght_rden);
        r_cal_wght_rden      <= r4_cal_wght_rden;
    end
    
    always @ (posedge i_clk) begin
        if (r4_cal_wght_wren) begin
            r_cal_wght_addr         <= i_cal_wght_addr     ;
            r_cal_wght_buf_bus      <= i_cal_wght_buf_bus  ;      
            r_cal_wght_buf_core     <= i_cal_wght_buf_core ;      
            r_cal_wght_wr_i         <= i_cal_wght_wr_i     ; 
            r_cal_wght_wr_q         <= i_cal_wght_wr_q     ; 
        end
    end
    ///////////////////////////////////////////////////////////////////////////
    
`ifndef ULFE_CALB_EN
    assign w_CALB_out_vld       = w_GAINCOMP_out_vld        ;     
    assign w_CALB_out_I         = w_GAINCOMP_out_I          ;       
    assign w_CALB_out_Q         = w_GAINCOMP_out_Q          ;  
    assign w_CALB_frm_tick      = w_gaincomp_CALB_frm_tick  ;
    assign w_CALB_slt_tick      = w_gaincomp_CALB_slt_tick  ;   
    assign w_CALB_sym_tick      = w_gaincomp_CALB_sym_tick  ;
    assign w_CALB_sltIdx        = w_gaincomp_CALB_sltIdx    ;
    assign w_CALB_symIdx        = w_gaincomp_CALB_symIdx    ;
    assign w_CALB_bcf_en        = i_bcf_en                  ;
    assign w_CALB_tdd_mode      = i_tdd_mode                ;
`else
//    ulfe_cal_buf #(.AO(OC), .OC(OC), .BW(CALWB) ,.CHAIN_INDEX(CHAIN_INDEX)) u_ulfe_cal_buf(
//         .i_clk                  ( i_clk                       )//input  wire                       // CLK 
//        ,.i_rst                  ( i_rst                       )//input  wire                       // Sync. Reset Active High    
//        ,.i_cal_wght_addr        ( r_cal_wght_addr             )//input  wire [        11-1:0]  
//        ,.i_cal_wght_buf_bus     ( r_cal_wght_buf_bus          )//input  wire [         1-1:0]       
//        ,.i_cal_wght_buf_core    ( r_cal_wght_buf_core         )//input  wire [         1-1:0]       
//        ,.i_cal_wght_wren        ( r_cal_wght_wren             )//input  wire [         1-1:0]  
//        ,.i_cal_wght_rden        ( r_cal_wght_rden             )//input  wire [         1-1:0]  
//        ,.i_cal_wght_wr_i        ( r_cal_wght_wr_i             )//input  wire [(2**AO)*BW-1:0]  
//        ,.i_cal_wght_wr_q        ( r_cal_wght_wr_q             )//input  wire [(2**AO)*BW-1:0]  
//        ,.o_cal_wght_rd_i        ( o_cal_wght_rd_i             )//output wire [(2**AO)*BW-1:0]  
//        ,.o_cal_wght_rd_q        ( o_cal_wght_rd_q             )//output wire [(2**AO)*BW-1:0]  
//        ,.i_cal_wght_init        ( w_cal_wght_init             )//input  wire                  w_cal_wght_init        
//        ,.i_cal_wght_rqst        ( w_cal_wght_rqst             )//input  wire                  w_cal_wght_rqst        
//        ,.o_cal_wght_vld         ( w_cal_wght_vld              )//output wire                  w_cal_wght_vld         
//        ,.o_cal_wght_i           ( w_cal_wght_i                )//output reg  [(2**AO)*BW-1:0] w_cal_wght_i           
//        ,.o_cal_wght_q           ( w_cal_wght_q                )//output reg  [(2**AO)*BW-1:0] w_cal_wght_q           
//    );
//    
//    ulfe_calb_fpga #(.IB(IB), .WB(CALWB), .OB(OB), .OC(OC)) u_ulfe_calb_fpga
//    (
//         .i_clk                  ( i_clk                       )  //     input   wire                                  // Clock 
//        ,.i_rst                  ( i_rst                       )  //     input   wire                             // Reset                                          
//        ,.i_frm_tick             ( w_gaincomp_CALB_frm_tick    )  //     input   wire                           
//        ,.i_slt_tick             ( w_gaincomp_CALB_slt_tick    )  //     input   wire                           
//        ,.i_sym_tick             ( w_gaincomp_CALB_sym_tick    )  //     input   wire                           
//        ,.i_sltIdx               ( w_gaincomp_CALB_sltIdx      )  //     input   wire  [           6-1:0]       
//        ,.i_symIdx               ( w_gaincomp_CALB_symIdx      )  //     input   wire  [           4-1:0]       
//        ,.i_bcf_en               ( i_bcf_en                    )  //     input   wire                    
//        ,.i_tdd_mode             ( i_tdd_mode                  )  //     input   wire                    
//        ,.i_calOn                ( w_calOn_d3                  )  //     input   wire  [      OVS* 1-1:0]   i_calOn      // Cal. On
//        ,.i_calBypassFlag        ( w_calBypassFlag_d3          )  //     input   wire  [         OVS-1:0]               // Cal bypass Flag
//        ,.i_calW_vld             ( w_cal_wght_vld              )  //     input   wire                     w_cal_wght_vld                 // Cal. Weight Valid
//        ,.i_calW_i               ( w_cal_wght_i                )  //     input   wire  [      OVS*WB-1:0]  w_cal_wght_i                                 // Cal. Weight I
//        ,.i_calW_q               ( w_cal_wght_q                )  //     input   wire   [     OVS*WB-1:0]  w_cal_wght_q                                 // Cal. Weight Q
//        ,.i_calWScale            ( w_calWScale_d3              )  //     input   wire   [     OVS* 4-1:0]  w_calWScale_d3  i_calWScale        // Cal. Weight Exponent
//        ,.i_CALB_in_vld          ( w_GAINCOMP_out_vld          )  //     input   wire   [     OVS* 1-1:0]                   // Cal. vld 
//        ,.i_CALB_in_I            ( w_GAINCOMP_out_I            )  //     input   wire   [         IB-1:0]                 // Cal. I Input 
//        ,.i_CALB_in_Q            ( w_GAINCOMP_out_Q            )  //     input   wire   [         IB-1:0]                 // Cal. Q Input 
//        ,.o_cal_buf_rd_vld       ( w_cal_wght_rqst             )  //     output  wire                       w_CALB_cal_buf_rd_vld      //init+1 timing
//        ,.o_cal_buf_rd_bank      (                             )  //     output  wire                       w_CALB_cal_buf_rd_bank      //init timing
//        ,.o_cal_buf_rd_init      ( w_cal_wght_init             )  //     output  wire                       w_CALB_cal_buf_rd_init      //
//        ,.o_CALB_out_vld         ( w_CALB_CALB_out_vld         )  //     output  reg   [      OVS* 1-1:0]   w_CALB_CALB_out_vld                     // Cal. Output Valid
//        ,.o_CALB_out_I           ( w_CALB_CALB_out_I           )  //     output  reg   [        OB-1:0]   w_CALB_CALB_out_I                     // Cal. I Output 
//        ,.o_CALB_out_Q           ( w_CALB_CALB_out_Q           )  //     output  reg   [        OB-1:0]   w_CALB_CALB_out_Q                     // Cal. Q Output        
//        ,.o_bcf_en               ( w_CALB_bcf_en               )  //     output  wire                     w_CALB_bcf_en            
//        ,.o_tdd_mode             ( w_CALB_tdd_mode             )  //     output  wire                     w_CALB_tdd_mode                                       
//        ,.o_frm_tick             ( w_CALB_frm_tick             )  //     output  wire                     w_CALB_frm_tick          
//        ,.o_slt_tick             ( w_CALB_slt_tick             )  //     output  wire                     w_CALB_slt_tick          
//        ,.o_sym_tick             ( w_CALB_sym_tick             )  //     output  wire                     w_CALB_sym_tick          
//        ,.o_sltIdx               ( w_CALB_sltIdx               )  //     output  wire  [             6-1:0]   w_CALB_sltIdx            
//        ,.o_symIdx               ( w_CALB_symIdx               )  //     output  wire  [             4-1:0]   w_CALB_symIdx                        
////      ,.o_CALB_latency         ( o_CALB_latency              )  //     output  wire  [          32-1:0]     w_CALB_latency           
//    );



ulfe_calb #(
    .NUM_RX(NUM_RX),
    .WB(CALWB),
    .IB(IB),
    .OB(OB),
    .CHAIN_INDEX(CHAIN_INDEX),
    .CPUIF_BB_ADDR_BW(CPUIF_BB_ADDR_BW)
) u_ulfe_calb(
     .i_cpu_wren                (i_cpu_wren)
    ,.i_cpu_addr                (i_cpu_addr)
    ,.i_cpu_wdata               (i_cpu_wdata)
    ,.i_cpu_rden                (i_cpu_rden)
    ,.o_calb_cpu_rvalid         (o_calb_cpu_rvalid)
    ,.o_calb_cpu_rdata          (o_calb_cpu_rdata)
    ,.i_rst                     (i_rst                      )
    ,.i_clk                     (i_clk                      )
    ,.i_sel_calb_rx             (i_sel_calb_rx              )
    ,.i_calon                   (w_calOn                    )            
    ,.i_calbypassflag           (w_calBypassFlag_d3         )
    ,.i_calwscale               (w_calWScale                )
    ,.i_rb_size                 (w_rb_size                  )
    ,.o_calwght_evenodd         (o_calwght_evenodd          )
    ,.i_sel_calwght_evenodd     (i_sel_calwght_evenodd)   
   
    ,.i_calb_frm_tick           (w_gaincomp_CALB_frm_tick)    
    ,.i_calb_slt_tick           (w_gaincomp_CALB_slt_tick)    
    ,.i_calb_sym_tick           (w_gaincomp_CALB_sym_tick)    
    ,.i_calb_sltIdx             (w_gaincomp_CALB_sltIdx  )    
    ,.i_calb_symIdx             (w_gaincomp_CALB_symIdx  )                                     
    ,.i_calb_in_vld             (w_GAINCOMP_out_vld)   
    ,.i_calb_in_I               (w_GAINCOMP_out_I)   
    ,.i_calb_in_Q               (w_GAINCOMP_out_Q)     
    ,.o_calb_frm_tick           (w_CALB_frm_tick)    
    ,.o_calb_slt_tick           (w_CALB_slt_tick)    
    ,.o_calb_sym_tick           (w_CALB_sym_tick)    
    ,.o_calb_sltIdx             (w_CALB_sltIdx)    
    ,.o_calb_symIdx             (w_CALB_symIdx)                                    
    ,.o_calb_out_vld            (w_CALB_out_vld)    
    ,.o_calb_out_I              (w_CALB_out_I)    
    ,.o_calb_out_Q              (w_CALB_out_Q)
);





`endif
  
    
    ulfe_cts #(.IB(IB), .OB(OB), .OC(OC)) u_ulfe_cts
    (
         .i_clk                  ( i_clk                       ) // input   wire  			  		            // Clock                                       
        ,.i_frm_tick             ( w_CALB_frm_tick             ) // input   wire  			  		        
        ,.i_slt_tick             ( w_CALB_slt_tick             ) // input   wire  			  		        
        ,.i_sym_tick             ( w_CALB_sym_tick             ) // input   wire  			  		        
        ,.i_sltIdx               ( w_CALB_sltIdx               ) // input   wire  [		     6-1:0]	  
        ,.i_symIdx               ( w_CALB_symIdx               ) // input   wire  [		     4-1:0]	      
        ,.i_bcf_en               ( w_CALB_bcf_en               ) // input   wire  					          
        ,.i_tdd_mode             ( w_CALB_tdd_mode             ) // input   wire  					                 
        ,.i_cts_on               ( w_cts_on                    ) // input   wire  [	  OVS* 1-1:0]    i_cts_on   // CTS On
        ,.i_calBypassFlag        ( w_calBypassFlag_d3          ) // input   wire  [	     OVS-1:0]       // cal bypass flag
        ,.i_cts_shft_vld         ( i_cts_shft_vld              ) // input   wire  [	  OVS* 1-1:0] i_cts_shft_vld      // CTS Input Phase Enable
        ,.i_cts_shft             ( w_cts_shft                  ) // input   wire  [	  OVS*12-1:0] i_cts_shft      // CTS Input phase                    
        ,.i_CTS_in_vld           ( w_CALB_out_vld              ) // input   wire  [	  OVS* 1-1:0]   
        ,.i_CTS_in_I             ( w_CALB_out_I                ) // input   wire  [		    IB-1:0]          // CTS I Input 
        ,.i_CTS_in_Q             ( w_CALB_out_Q                ) // input   wire  [	  	  IB-1:0]          // CTS Q Input 
        ,.o_CTS_out_vld          ( w_CTS_out_vld               ) // output  reg  	[	  OVS* 1-1:0]  w_CTS_out_vld            
        ,.o_CTS_out_I            ( w_CTS_out_I                 ) // output  reg  	[	      OB-1:0]  w_CTS_out_I                      // CTS I out 
        ,.o_CTS_out_Q            ( w_CTS_out_Q                 ) // output  reg  	[	      OB-1:0]  w_CTS_out_Q                      // CTS Q out 	
        ,.o_bcf_en               ( w_CTS_bcf_en                ) // output  wire          			       w_bcf_en                   
        ,.o_tdd_mode             ( w_CTS_tdd_mode              ) // output  wire          			       w_tdd_mode                                          
        ,.o_frm_tick             ( w_CTS_frm_tick              ) // output  wire          			       w_frm_tick                 
        ,.o_slt_tick             ( w_CTS_slt_tick              ) // output  wire          			       w_slt_tick                 
        ,.o_sym_tick             ( w_CTS_sym_tick              ) // output  wire          			       w_sym_tick                 
        ,.o_sltIdx               ( w_CTS_sltIdx                ) // output  wire  [		   6-1:0]	   w_sltIdx                 
        ,.o_symIdx               ( w_CTS_symIdx                ) // output  wire  [		   4-1:0]	   w_symIdx                                         
//      ,.o_CTS_latency          ( o_CTS_latency               ) // output  wire  [		  32-1:0]	   w_CTS_latency            
    );


`ifdef ULFE_Cp
assign w_uin_symbol_idx = i_uin_symbol_idx;

`endif
`ifdef ULFE_DSS
assign w_uin_en_technology  = i_uin_en_technology;
assign w_uin_technology_dss = i_uin_technology_dss;


integer     k                           ;
reg [3:0]   r_symidx_dss_tech           ;
reg [105:0] r_mem_dss_tech              ;
reg [105:0] r_dlymem_dss_tech   [1:0]   ;
reg [3:0]   r_dlymem_symdix     [1:0]   ;
reg [6:0]   r_getcnt                    ;    
reg         r_uin_en_technology         ;


always @(posedge i_clk)
begin
    r_uin_en_technology <= w_uin_en_technology;
//    r_phasecomp_in_vld  <= |w_PHASECOMP_in_vld; 
end

always @(posedge i_clk)
begin
    if(w_uin_en_technology)
    begin
        r_getcnt <= r_getcnt + 7'd1;
    end
    else
    begin
        r_getcnt <= 7'd0;        
    end
end     

always@(posedge i_clk) 
begin
    if(i_rst)
    begin
        for(k=0;k<106;k=k+1)
        begin
            r_mem_dss_tech[k] <= 1'b1;
        end
    end    
    else if(w_uin_en_technology)
    begin
        for(k=0;k<106;k=k+1)      // Designed by W.D.
        begin
        if(r_getcnt == k[6:0]) 
        begin
            r_mem_dss_tech[k] <= w_uin_technology_dss;
        end
        else
        begin
            r_mem_dss_tech[k] <= r_mem_dss_tech[k];
        end
        end
    end
    else
    begin
        r_mem_dss_tech  <= r_mem_dss_tech;
    end
end

always @(posedge i_clk)
begin
    if(~w_uin_en_technology & r_uin_en_technology)
        r_symidx_dss_tech <= w_uin_symbol_idx;    
end

always @(posedge i_clk)
begin
    if(w_FREQSHIFT_sym_tick)
    begin
        r_dlymem_dss_tech[1]    <= r_mem_dss_tech       ;   
        r_dlymem_dss_tech[0]    <= r_dlymem_dss_tech[1] ;   
        
        r_dlymem_symdix[1]      <= r_symidx_dss_tech    ;
        r_dlymem_symdix[0]      <= r_dlymem_symdix[1]   ;
//        r_dss_tech <= r_dlymem_dss_tech[0];   
    end
end

`endif    
    
    
    
    
    ulfe_phasecomp #(.IB(IB), .OB(OB), .OC(OC), .SCO(MAX_SCIDX), .WB(PWB) ,.VENDOR(VENDOR)) u_ulfe_phasecomp
    (
         .i_clk                  ( i_clk                       ) //input   wire 			 	 	                     // Clock                                               
        ,.i_rst                  ( i_rst                       )
        ,.i_frm_tick             ( w_CTS_frm_tick              ) //input   wire 			 	 	               
        ,.i_slt_tick             ( w_CTS_slt_tick              ) //input   wire 			 	 	               
        ,.i_sym_tick             ( w_CTS_sym_tick              ) //input   wire 			 	 	               
        ,.i_sltIdx               ( w_CTS_sltIdx                ) //input   wire [		     6-1:0]	         
        ,.i_symIdx               ( w_CTS_symIdx                ) //input   wire [		     4-1:0]	                                       
        ,.i_bcf_en               ( w_CTS_bcf_en                ) //input   wire 			 	 	               
        ,.i_tdd_mode             ( w_CTS_tdd_mode              ) //input   wire 			 	 	                                             
        ,.i_phaseCompOn          ( w_phaseCompOn               ) //input   wire [		   OVS-1:0]	i_phaseCompOn                // phasecomp on/off 
        ,.i_calBypassFlag        ( w_calBypassFlag_d3          ) //input   wire [		   OVS-1:0]	                // calibration pattern bypass  
        //,.i_phaseW_vld           ( 1'b1                        ) //input   wire 			 	         i_phaseW_vld                           // in-phase weight
        ,.i_phaseW_i             ( i_phaseW_i                  ) //input   wire [     NW*WB-1:0] i_phaseW_i                             // in-phase weight
        ,.i_phaseW_q             ( i_phaseW_q                  ) //input   wire [     NW*WB-1:0] i_phaseW_q                             // quadrature weight
        ,.i_PHASECOMP_in_vld     ( w_CTS_out_vld               ) //input   wire [		   OVS-1:0]                 // enable of input
        ,.i_PHASECOMP_in_I       ( w_CTS_out_I                 ) //input   wire [   	    IB-1:0]               // in-phase input
        ,.i_PHASECOMP_in_Q       ( w_CTS_out_Q                 ) //input   wire [   	    IB-1:0]               // quadrature input                                       
        ,.o_PHASECOMP_out_vld    ( w_pre_process_out_vld       ) //output  reg  [	  	 OVS-1:0]    o_PHASECOMP_out_vld              // enable of output 
        ,.o_PHASECOMP_out_I      ( w_pre_process_out_I         ) //output  reg  [   	    OB-1:0]  o_PHASECOMP_out_I                // in-phase output
        ,.o_PHASECOMP_out_Q      ( w_pre_process_out_Q         ) //output  reg  [   	    OB-1:0]  o_PHASECOMP_out_Q                // quadrature output   
        ,.o_frm_tick             ( w_pre_process_frm_tick      ) //output  wire       				     o_frm_tick                
        ,.o_slt_tick             ( w_slt_tick                  ) //output  wire       				     w_slt_tick                
        ,.o_sym_tick             ( w_sym_tick                  ) //output  wire       				     w_sym_tick                
        ,.o_sltIdx               ( w_sltIdx                    ) //output  wire [     	   6-1:0]	 w_sltIdx                  
        ,.o_symIdx               ( w_symIdx                    ) //output  wire [     	   4-1:0]	 w_symIdx  	                                              
        ,.o_bcf_en               ( w_bcf_en                    ) //output  wire 					         w_bcf_en                  
        ,.o_tdd_mode             ( w_tdd_mode                  ) //output  wire 					         w_tdd_mode                                                  
//      ,.o_PHASECOMP_latency    ( o_PHASECOMP_latency         ) //output  wire [	  	  32-1:0]    w_PHASECOMP_latency       

`ifdef ULFE_Cp
        ,.i_uin_symbol_idx       (r_dlymem_symdix[0])
`endif
`ifdef ULFE_DSS
        ,.i_dlymem_dss_tech      (r_dlymem_dss_tech[0])
        ,.o_dbg_dssCp_alarm      (o_dbg_dssCp_alarm)
//        ,.i_uin_en_technology    (i_uin_en_technology)
//        ,.i_uin_technology_dss   (i_uin_technology_dss)
`endif
    );
    
    
    
    
assign o_sltIdx = w_sltIdx;
assign o_symIdx = w_symIdx;    
    
assign o_pre_process_out_vld    = w_pre_process_out_vld   ;
assign o_pre_process_out_I      = {w_pre_process_out_I[14],w_pre_process_out_I};
assign o_pre_process_out_Q      = {w_pre_process_out_Q[14],w_pre_process_out_Q};
assign o_pre_process_frm_tick   = w_pre_process_frm_tick  ;


endmodule


