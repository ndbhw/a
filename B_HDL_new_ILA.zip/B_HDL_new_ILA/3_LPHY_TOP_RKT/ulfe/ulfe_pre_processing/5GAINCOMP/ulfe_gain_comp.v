// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : 20A 
//  Module       : ulfe_gain_comp
//  Author       :  
//  Description  : ulfe gain compensator
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.03.11 |  Zhao Yan     | Initial Release
//  ------------+---------------+-----------------------------------------------
//
//  scs=30K
//   BW  |  FFT size  |  RBSIZE  
//  100  |    4096    |    273
//   80  |    4096    |    217
//   50  |    2048    |    133
//   40  |    2048    |    106
//   20  |    1024    |     51
////////////////////////////////////////////////////////////////////////////////

`define non_interleav


module ulfe_gain_comp 
#(
      parameter IB            = 15                  // Input Bitwidth
    , parameter OB            = 15                  // Output Bitwidth
    , parameter OC            = 1                   // Overclocking Factor
    , parameter OVS           = 2**OC
    , parameter FS_CLK        = 245760000
    , parameter SCIDX         = 1                   //subcarrier index, {0~4} --> {15k, 30k, 60k, 120k, 240k}
    , parameter CPTYPE        = 0   

)(
      input   wire                         i_clk                      // Clock  
    , input   wire                         i_rst                      // reset
    , input   wire                         i_frm_tick                 // frm_tick from FFT_blk, this tick is ~1symbol delay of FFT
    , input   wire [         9-1:0]        i_rb_size                  // common parameter, total RB size
    , input   wire [           1:0]        i_fftType                  // common parameter
    , input   wire [        11-1:0]        i_cpRmOffset
    , input   wire [       OVS-1:0]        i_gainCompOn               // common parameter
    , input   wire [       OVS-1:0]        i_calBypassFlag            // parameter
    , input   wire [       OVS-1:0]        i_tdagc_vld                // tagc gain valid, from tagc module
    , input   wire                         i_tdagc_sym_tick
    , input   wire [         4-1:0]        i_td_gain1                 // tagc gain1
    , input   wire [         5-1:0]        i_td_gain2                 // tagc gain2
    , input   wire [       OVS-1:0]        i_gaincomp_in_vld          // enable of input, 5 clock delay from o_fft_ram_rd_req: 1+1+URAM_DELAY+1
    , input   wire [        IB-1:0]        i_gaincomp_in_I            // in-phase input
    , input   wire [        IB-1:0]        i_gaincomp_in_Q            // quadrature input 
    , output  reg  [       OVS-1:0]        o_fft_ram_rd_req           // enable of rd req, to FFT blk
    , output  reg  [       OVS-1:0]        o_tone_valid               // enable of rd req, to FFT blk
    , output  wire                         o_frm_tick                 // slot tick, to FFT blk
    , output  wire                         o_slt_tick                 // slot tick, to FFT blk
    , output  wire                         o_sym_tick                 // symbol tick, to FFT blk
    , output  wire                         o_gaincomp_frm_tick        // output signal frm_tick  
    , output  wire                         o_gaincomp_slt_tick        // output signal slt_tick  
    , output  wire                         o_gaincomp_sym_tick        // output signal sym_tick  
    , output  wire  [      6-1 : 0]        o_gaincomp_sltIdx          // output signal sltIdx   
    , output  wire  [      4-1 : 0]        o_gaincomp_symIdx          // output signal symIdx                                    
    , output  wire  [      OVS-1:0]        o_gaincomp_out_vld         // enable of output 
    , output  wire  [       OB-1:0]        o_gaincomp_out_I           // in-phase output
    , output  wire  [       OB-1:0]        o_gaincomp_out_Q           // quadrature output    
//    , output  reg   [         31:0]        o_gaincomp_latency                                                
);
//localparam   FRM_TICK_DELAY     =  13288;          // frm_tick delay,
//localparam   FRM_TICK_DELAY     =  19704;          // frm_tick delay,
//localparam   FRM_TICK_DELAY     =  (17664+1000)/(2**SCIDX);          // frm_tick delay,
localparam   FRM_TICK_DELAY     =  (17664)/(2**(SCIDX));          // frm_tick delay,
localparam   NP                 =  2    ;          // multiplier delay
// input signal registering ****************************************

wire                      w_frm_tick       ; //ulfe timer output
wire                      w_slt_tick       ; //ulfe timer output
wire                      w_sym_tick       ; //ulfe timer output
wire  [      6-1 : 0]     w_sltIdx         ; //ulfe timer output
wire  [      4-1 : 0]     w_symIdx         ; //ulfe timer output                                           
reg   [       15 : 0]     r_symbol_cnt     ; //symbol counter
reg   [       15 : 0]     r_tone_len       ; //total tone number
wire                      w2_frm_tick      ; //delay of w_frm_tick  
wire                      w2_slt_tick      ; //delay of w_slt_tick 
wire                      w2_sym_tick      ; //delay of w_sym_tick   
wire   [    OVS-1 : 0]    w_gaincomp_in_vld; //input register
wire   [     IB-1 : 0]    w_gaincomp_in_I  ; //input register
wire   [     IB-1 : 0]    w_gaincomp_in_Q  ; //input register
wire                      w_mut_out_valid  ; //multiplier output valid
wire  [  IB+10-1 : 0]     w_mut_out_I      ; //multiplier output I 
wire  [  IB+10-1 : 0]     w_mut_out_Q      ; //multiplier output Q 
wire  [     OB-1 : 0]     w_shr_sat_I      ; //shr_sat output I
wire  [     OB-1 : 0]     w_shr_sat_Q      ; //shr_sat output Q
wire  [    OVS-1 : 0]     w_calBypassFlag  ;
wire  [    OVS-1 : 0]     w_gainCompOn     ;
reg                       r1_frm_tick      ;
reg   [       15 : 0]     r_frm_delay_cnt  ;
reg                       r_frm_start      ;
reg   [       15 : 0]     r_fft_size       ;
wire                      w_sym_tick_gain  ;
wire  [        1 : 0]     r_fftType        ;
//***************************************************
assign o_frm_tick = w2_frm_tick; // output to FFT blk, read RAM
assign o_slt_tick = w2_slt_tick; // output to FFT blk, read RAM
assign o_sym_tick = w2_sym_tick; // output to FFT blk, read RAM

ylib_reg #(.WIDTH(2),.DEPTH(1)) sync_fftType (.i_clk(i_clk),   .i_in(i_fftType),    .o_out(r_fftType));
//always @(posedge i_clk) begin
//  o_gaincomp_latency = {32'd4,{OC{1'b0}}}; //4*OC
//end

//start flag, for simulation

always @(posedge i_clk) begin
  if(i_rst) begin
    r_frm_start <= 0;
  end
  else if(r1_frm_tick) begin
    r_frm_start <= 1'b1;
  end
end

//counter for 1 symbol
always @(posedge i_clk) begin
  if(i_rst) begin
    r_symbol_cnt <= 32800;  //max value
  end
  else if(w_sym_tick&r_frm_start) begin //resync with sym tick
    r_symbol_cnt <= 'd0;
  end
  else if(r_frm_start) begin
    r_symbol_cnt <= r_symbol_cnt+1'b1;
  end
end

//NFFT*OVS valid clock number in 1 symbol -> valid Tone
always @(posedge i_clk) begin
  if(i_rst) begin
    r_tone_len <= 3278;
  end
  else if(SCIDX==0) begin //15k, LTE, 
    r_tone_len <= {i_rb_size,6'b000000} + {i_rb_size,5'b00000};
  end
  else if(SCIDX==1) begin //30k, NR
    r_tone_len <= {i_rb_size,6'b000000} + {i_rb_size,5'b00000};
//    r_tone_len <= {i_rb_size,3'b000,{OC{1'b0}}} + {i_rb_size,2'b00,{OC{1'b0}}};
  end
end

always @(posedge i_clk) begin
  if(i_rst) begin
    r_fft_size <= 0;
  end
  else if (r_fftType==2'b00) begin
    r_fft_size <= 16'd4096;
  end
  else if (r_fftType==2'b01) begin
    r_fft_size <= 16'd8192;
  end
  else if (r_fftType==2'b10) begin
    r_fft_size <= 16'd16384;
  end
  else begin
    r_fft_size <= 16'd32768;
  end
end

//generate rd_req for FFT ram
reg  [       OVS-1:0]        r1_tone_valid;
reg  [       OVS-1:0]        r2_tone_valid;
reg  [       OVS-1:0]        r1_fft_ram_rd_req;
reg  [       OVS-1:0]        r2_fft_ram_rd_req;
genvar  i;

/* generate
  for (i = 0; i < OVS; i = i + 1) begin : rd_req_gen
//    always @(posedge i_clk) begin
//      if(i_rst) begin
//        r1_tone_valid[i] <= 'd0;
//      end
//      else if(r_symbol_cnt<r_tone_len) begin
//      `ifdef non_interleav
//        case (r_symbol_cnt%(r_tone_len>>3))
//            0 : r1_tone_valid <= 'h1;
//            1 : r1_tone_valid <= 'h2;
//            2 : r1_tone_valid <= 'h4;
//            3 : r1_tone_valid <= 'h8;
//            4 : r1_tone_valid <= 'h10;
//            5 : r1_tone_valid <= 'h20;
//            6 : r1_tone_valid <= 'h40;
//            7 : r1_tone_valid <= 'h80;
//            default : r1_tone_valid<= 'd0;
//      endcase
//      `else
//        r1_tone_valid[i] <= (r_symbol_cnt[OC-1:0] == i)&1'b1;
//      `endif
//      
//      
//      end
//      else begin
//        r1_tone_valid[i] <= 1'b0;
//      end
//    end
    


    always @(posedge i_clk) begin
      if(i_rst) begin
        r1_fft_ram_rd_req[i] <= 'd0;
        r1_tone_valid[i] <= (r_symbol_cnt[OC-1:0] == i)&1'b1;
      end
      else if(r_symbol_cnt<r_fft_size) begin
      `ifdef non_interleav
        case (r_symbol_cnt/(r_fft_size>>3))
            0 : begin
                    r1_fft_ram_rd_req <= 'h1;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h1;
                    else
                        r1_tone_valid <= 'h0;
                end
            1 : begin
                    r1_fft_ram_rd_req <= 'h2;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h2;
                    else
                        r1_tone_valid <= 'h0;
                    end
            2 : begin
                    r1_fft_ram_rd_req <= 'h4;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h4;
                    else
                        r1_tone_valid <= 'h0;
                end
            3 : begin
                    r1_fft_ram_rd_req <= 'h8;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h8;
                    else
                        r1_tone_valid <= 'h0;
                end
            4 : begin 
                    r1_fft_ram_rd_req <= 'h10;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h10;
                    else
                        r1_tone_valid <= 'h0;
                end
            5 : begin 
                    r1_fft_ram_rd_req <= 'h20;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h20;
                    else
                        r1_tone_valid <= 'h0;
                end
            6 : begin
                    r1_fft_ram_rd_req <= 'h40;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h40;
                    else
                        r1_tone_valid <= 'h0;
                end
            7 : begin
                    r1_fft_ram_rd_req <= 'h80;
                    if((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h80;
                    else
                        r1_tone_valid <= 'h0;
                end
            default : begin
                    r1_fft_ram_rd_req <= 'd0;
                end
      endcase
      `else
        r1_fft_ram_rd_req[i] <= (r_symbol_cnt[OC-1:0] == i)&1'b1;
      `endif      
      end
      else begin
        r1_fft_ram_rd_req[i] <= 1'b0;
        r1_tone_valid[i] <= 1'b0;
      end
    end
  end
endgenerate

*/

wire [3-1:0] case_ant_vld;
wire [16-1:0] w_sym_antcnt;

assign case_ant_vld = (r_fftType==2'b00) ? r_symbol_cnt[9+2:9] : (r_fftType==2'b01) ? r_symbol_cnt[10+2:10] : (r_fftType==2'b10) ? r_symbol_cnt[11+2:11] : r_symbol_cnt[12+2:12];
assign w_sym_antcnt = (r_fftType==2'b00) ? {{7'd0},{r_symbol_cnt[9-1:0]}} : (r_fftType==2'b01) ? {{6'd0},{r_symbol_cnt[10-1:0]}} : (r_fftType==2'b10) ? {{5'd0},{r_symbol_cnt[11-1:0]}} : {{4'd0},{r_symbol_cnt[12-1:0]}};


    always @(posedge i_clk) begin
      if(i_rst) begin
        r1_fft_ram_rd_req <= 'd0;
        r1_tone_valid <= 'd0;//(r_symbol_cnt[OC-1:0] == i)&1'b1;
      end
      else if(r_symbol_cnt<r_fft_size) begin
      `ifdef non_interleav
   //     case (r_symbol_cnt/(r_fft_size>>3))
        case (case_ant_vld)
            0 : begin
                    r1_fft_ram_rd_req <= 'h1;
                    if(w_sym_antcnt < (r_tone_len>>3))//         (r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h1;
                    else
                        r1_tone_valid <= 'h0;
                end
            1 : begin
                    r1_fft_ram_rd_req <= 'h2;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h2;
                    else
                        r1_tone_valid <= 'h0;
                    end
            2 : begin
                    r1_fft_ram_rd_req <= 'h4;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h4;
                    else
                        r1_tone_valid <= 'h0;
                end
            3 : begin
                    r1_fft_ram_rd_req <= 'h8;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h8;
                    else
                        r1_tone_valid <= 'h0;
                end
            4 : begin 
                    r1_fft_ram_rd_req <= 'h10;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h10;
                    else
                        r1_tone_valid <= 'h0;
                end
            5 : begin 
                    r1_fft_ram_rd_req <= 'h20;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h20;
                    else
                        r1_tone_valid <= 'h0;
                end
            6 : begin
                    r1_fft_ram_rd_req <= 'h40;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h40;
                    else
                        r1_tone_valid <= 'h0;
                end
            7 : begin
                    r1_fft_ram_rd_req <= 'h80;
                    if(w_sym_antcnt < (r_tone_len>>3))//((r_symbol_cnt%(r_fft_size>>3))  / (r_tone_len>>3)   == 0)
                        r1_tone_valid <= 'h80;
                    else
                        r1_tone_valid <= 'h0;
                end
            default : begin
                    r1_fft_ram_rd_req <= 'd0;
                end
      endcase
      `else
        r1_fft_ram_rd_req[i] <= (r_symbol_cnt[OC-1:0] == i)&1'b1;
      `endif      
      end
      else begin
        r1_fft_ram_rd_req <= 'd0;
        r1_tone_valid <= 'd0;
      end
    end


















genvar  j;
generate
  for (j = 0; j < OVS; j = j + 1) begin : rd_req_gen_dly
    always @(posedge i_clk) begin
      if(i_rst) begin
        r2_fft_ram_rd_req[j] <= 'd0;
        o_fft_ram_rd_req[j]  <= 'd0;
        r2_tone_valid[j]     <= 0;
        o_tone_valid[j]      <= 0;
      end
      else begin
        r2_fft_ram_rd_req[j] <= r1_fft_ram_rd_req[j];
        o_fft_ram_rd_req[j]  <= r2_fft_ram_rd_req[j];
        r2_tone_valid[j]     <= r1_tone_valid[j];
        o_tone_valid[j]      <= r2_tone_valid[j];
      end
    end
  end
endgenerate

//*************************************************************************
// frm_tick delay

reg             r_new_frm_flag  ;
reg [11-1:0]    r_cpRmOffset    ;

always @(posedge i_clk) begin
  if(i_frm_tick) begin
    r_new_frm_flag <= 1'b1;
    r_cpRmOffset   <= i_cpRmOffset;
  end
end

always @(posedge i_clk) begin
  if(i_rst) begin
    r_frm_delay_cnt <= 0;
  end
  else if(i_frm_tick) begin //resync
    r_frm_delay_cnt <= 0;
  end
  else if((r_frm_delay_cnt<(FRM_TICK_DELAY+{5'b00000,r_cpRmOffset}+16'd1))&r_new_frm_flag) begin 
    r_frm_delay_cnt <= r_frm_delay_cnt+1'b1;
  end
end

always @(posedge i_clk) begin
  if(i_rst) begin
    r1_frm_tick <= 1'b0;
  end
  else if(r_frm_delay_cnt==FRM_TICK_DELAY+{5'b00000,r_cpRmOffset}) 
  begin //resync
    r1_frm_tick <= 1'b1;
  end
  else begin
    r1_frm_tick <= 1'b0;
  end
end

//ulfe timer
ulfe_timer #(
     .N_CYCLE_CLK       (FS_CLK          )
    ,.SCS_IDX           (SCIDX           )       //{0~4} --> {15k, 30k, 60k, 120k, 240k}
    ,.CP_TYPE           (CPTYPE          )       //0:normal, 1:extended
    ,.CP_TICK           (0        )
    
) timer_inst
(
     .i_clk             ( i_clk          )
    ,.i_frm_tick_pre1   ( r1_frm_tick    )
    ,.o_frm_tick_pre1   ( w_frm_tick     )       //tick
    ,.o_slt_tick        ( w_slt_tick     )       //tick
    ,.o_sym_tick        ( w_sym_tick     )       //tick
    ,.o_slt_idx         ( w_sltIdx       )       //tick+1
    ,.o_sym_idx         ( w_symIdx       )       //tick+1
);

//ulfe timer to store tick
ulfe_timer #(
     .N_CYCLE_CLK       (FS_CLK          )
    ,.SCS_IDX           (SCIDX           )       //{0~4} --> {15k, 30k, 60k, 120k, 240k}
    ,.CP_TYPE           (CPTYPE          )       //0:normal, 1:extended
    ,.CP_TICK           (0        )
) timer_inst_gain
(
     .i_clk             ( i_clk          )
    ,.i_frm_tick_pre1   ( i_frm_tick     )
    ,.o_frm_tick_pre1   (                )       //tick
    ,.o_slt_tick        (                )       //tick
    ,.o_sym_tick        ( w_sym_tick_gain)       //tick
    ,.o_slt_idx         (                )       //tick+1
    ,.o_sym_idx         (                )       //tick+1
);

//delay 1clk to FFT blk, read RAM
ylib_reg #(.WIDTH(1 ), .DEPTH(3 ) ) dly_w_frm_tick ( .i_clk(i_clk), .i_in(w_frm_tick), .o_out(w2_frm_tick) );
ylib_reg #(.WIDTH(1 ), .DEPTH(2 ) ) dly_w_slt_tick ( .i_clk(i_clk), .i_in(w_slt_tick), .o_out(w2_slt_tick) );
ylib_reg #(.WIDTH(1 ), .DEPTH(2 ) ) dly_w_sym_tick ( .i_clk(i_clk), .i_in(w_sym_tick), .o_out(w2_sym_tick) ); 

//input register
ylib_reg #(.WIDTH(OVS ), .DEPTH(1 ) ) dly_gaincomp_in_vld ( .i_clk(i_clk),  .i_in(i_gaincomp_in_vld), .o_out(w_gaincomp_in_vld) );
ylib_reg #(.WIDTH(IB  ), .DEPTH(1 ) ) dly_gaincomp_in_I   ( .i_clk(i_clk),  .i_in(i_gaincomp_in_I  ), .o_out(w_gaincomp_in_I  ) );
ylib_reg #(.WIDTH(IB  ), .DEPTH(1 ) ) dly_gaincomp_in_Q   ( .i_clk(i_clk),  .i_in(i_gaincomp_in_Q  ), .o_out(w_gaincomp_in_Q  ) ); 
ylib_reg_clk_en #(.WIDTH(OVS ), .DEPTH(1 ) ) dly_gainCompOn      ( .i_clk(i_clk),  .i_en(w_slt_tick), .i_in(i_gainCompOn     ), .o_out(w_gainCompOn     ) );
ylib_reg_clk_en #(.WIDTH(OVS ), .DEPTH(1 ) ) dly_calBypassFlag   ( .i_clk(i_clk),  .i_en(w_sym_tick), .i_in(i_calBypassFlag  ), .o_out(w_calBypassFlag  ) );

//sync tagc gain

integer dmm;

reg  [         4-1:0]        r_td_gain1  [8-1:0];         //tagc gain1    
reg  [         5-1:0]        r_td_gain2  [8-1:0];         //tagc gain2 
reg  [         4-1:0]        r2_td_gain1 [8-1:0];         //tagc gain1    
reg  [         5-1:0]        r2_td_gain2 [8-1:0];         //tagc gain2 
reg  [         4-1:0]        r3_td_gain1 [8-1:0];         //tagc gain1    
reg  [         5-1:0]        r3_td_gain2 [8-1:0];         //tagc gain2 
wire [         4-1:0]        w_td_gain1  [8-1:0];         //tagc gain1 
wire [         5-1:0]        w_td_gain2  [8-1:0];         //tagc gain2 
wire [         4-1:0]        w_interconn_td_gain1  [8-1:0];         //tagc gain1 
wire [         5-1:0]        w_interconn_td_gain2  [8-1:0];         //tagc gain2 


always @(posedge i_clk ) begin
  for (dmm = 0; dmm < (2**OC); dmm = dmm + 1) begin : TAGC_GAIN_MAP
    if(i_rst) begin
      r_td_gain1[dmm] <= 0;   
      r_td_gain2[dmm] <= 0;
    end
    else if(i_tdagc_vld[dmm])
    begin
      r_td_gain1[dmm] <= i_td_gain1;    
      r_td_gain2[dmm] <= i_td_gain2;
    end
  end 
end

always @(posedge i_clk ) begin
  for (dmm = 0; dmm < (2**OC); dmm = dmm + 1) begin : TAGC_GAIN_MAP_DLY
    if(i_rst) begin
      r2_td_gain1[dmm] <= 0;   
      r2_td_gain2[dmm] <= 0;
      r3_td_gain1[dmm] <= 0;   
      r3_td_gain2[dmm] <= 0;
    end
    else if(i_tdagc_vld[dmm])
    begin
      r2_td_gain1[dmm] <= r_td_gain1[dmm];  
      r2_td_gain2[dmm] <= r_td_gain2[dmm];
      r3_td_gain1[dmm] <= r2_td_gain1[dmm]; 
      r3_td_gain2[dmm] <= r2_td_gain2[dmm];
    end
  end 
end

genvar   dm;

//sync with symbol tick
for (dm = 0; dm < (2**OC); dm = dm + 1) begin : TAGC_GAIN_MAP_WIRE     
  ylib_reg_clk_en #(.WIDTH(4), .DEPTH(1) ) dly_tagc_gain1 ( .i_clk(i_clk),  .i_en(i_tdagc_sym_tick), .i_in(r3_td_gain1[dm]  ), .o_out(w_interconn_td_gain1[dm])  );
  ylib_reg_clk_en #(.WIDTH(5), .DEPTH(1) ) dly_tagc_gain2 ( .i_clk(i_clk),  .i_en(i_tdagc_sym_tick), .i_in(r3_td_gain2[dm]  ), .o_out(w_interconn_td_gain2[dm])  ); 
  ylib_reg_clk_en #(.WIDTH(4), .DEPTH(1) ) dly_synced_tagc_gain1 ( .i_clk(i_clk),  .i_en(w_sym_tick), .i_in(w_interconn_td_gain1[dm]  ), .o_out(w_td_gain1[dm])    );
  ylib_reg_clk_en #(.WIDTH(5), .DEPTH(1) ) dly_synced_tagc_gain2 ( .i_clk(i_clk),  .i_en(w_sym_tick), .i_in(w_interconn_td_gain2[dm]  ), .o_out(w_td_gain2[dm])    ); 
end


//***************************************************
reg [         5-1:0]      r_td_gain2_sel;
reg [         4-1:0]      r_td_gain1_sel;
reg [       OVS-1:0]      r_agcgain_flag;

always @(posedge i_clk) begin
  for (dmm = 0; dmm < (2**OC); dmm = dmm + 1) begin : GAIN_FLAG
    if(i_rst) begin
      r_agcgain_flag[dmm] <= 0;
    end
    else begin
      r_agcgain_flag[dmm] <= w_gainCompOn[dmm]&(~w_calBypassFlag[dmm]);
    end
  end
end


reg [2:0] r_cond_td_gain_sel;
always @(posedge i_clk) 
begin
    case(i_fftType)
    2'd1 : r_cond_td_gain_sel <= r_symbol_cnt[12:10] ;
    2'd2 : r_cond_td_gain_sel <= r_symbol_cnt[13:11] ;
    2'd3 : r_cond_td_gain_sel <= r_symbol_cnt[14:12] ;
    default : r_cond_td_gain_sel <= r_symbol_cnt[11:9] ;     
endcase
end

//align with antenna
always @(posedge i_clk) begin
  if(i_rst) begin
    r_td_gain2_sel <= 0;
  end
    else if(OC==3) begin
    `ifdef non_interleav
//        case(w_gaincomp_in_vld)
//        8'h01   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
//        8'h02   : r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
//        8'h04   : r_td_gain2_sel <= w_td_gain2[2]&{5{r_agcgain_flag[2]}};
//        8'h08   : r_td_gain2_sel <= w_td_gain2[3]&{5{r_agcgain_flag[3]}};
//        8'h10   : r_td_gain2_sel <= w_td_gain2[4]&{5{r_agcgain_flag[4]}};
//        8'h20   : r_td_gain2_sel <= w_td_gain2[5]&{5{r_agcgain_flag[5]}};
//        8'h40   : r_td_gain2_sel <= w_td_gain2[6]&{5{r_agcgain_flag[6]}};
//        8'h80   : r_td_gain2_sel <= w_td_gain2[7]&{5{r_agcgain_flag[7]}};
//        default: r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};        
        
        case(r_cond_td_gain_sel)
        3'd0   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
        3'd1   : r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
        3'd2   : r_td_gain2_sel <= w_td_gain2[2]&{5{r_agcgain_flag[2]}};
        3'd3   : r_td_gain2_sel <= w_td_gain2[3]&{5{r_agcgain_flag[3]}};
        3'd4   : r_td_gain2_sel <= w_td_gain2[4]&{5{r_agcgain_flag[4]}};
        3'd5   : r_td_gain2_sel <= w_td_gain2[5]&{5{r_agcgain_flag[5]}};
        3'd6   : r_td_gain2_sel <= w_td_gain2[6]&{5{r_agcgain_flag[6]}};
        3'd7   : r_td_gain2_sel <= w_td_gain2[7]&{5{r_agcgain_flag[7]}};
        default: r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};             
        
        
        
        
    `else 
    case(r_symbol_cnt[2:0])
    3'd2   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
    3'd3   : r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
    3'd4   : r_td_gain2_sel <= w_td_gain2[2]&{5{r_agcgain_flag[2]}};
    3'd5   : r_td_gain2_sel <= w_td_gain2[3]&{5{r_agcgain_flag[3]}};
    3'd6   : r_td_gain2_sel <= w_td_gain2[4]&{5{r_agcgain_flag[4]}};
    3'd7   : r_td_gain2_sel <= w_td_gain2[5]&{5{r_agcgain_flag[5]}};
    3'd0   : r_td_gain2_sel <= w_td_gain2[6]&{5{r_agcgain_flag[6]}};
    default: r_td_gain2_sel <= w_td_gain2[7]&{5{r_agcgain_flag[7]}};        
    `endif

    endcase
  end
else if(OC==2) begin
    `ifdef non_interleav
        case(r_cond_td_gain_sel)//[13:11])
        3'd0   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
        3'd1   : r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
        3'd2   : r_td_gain2_sel <= w_td_gain2[2]&{5{r_agcgain_flag[2]}};
        3'd3   : r_td_gain2_sel <= w_td_gain2[3]&{5{r_agcgain_flag[3]}};
        default: r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};                
        endcase
    `else
    case(r_symbol_cnt[1:0])
    2'd2   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
    2'd3   : r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
    2'd0   : r_td_gain2_sel <= w_td_gain2[2]&{5{r_agcgain_flag[2]}};
    default: r_td_gain2_sel <= w_td_gain2[3]&{5{r_agcgain_flag[3]}};
    endcase  
    
    `endif

  end
  else begin
    case(r_cond_td_gain_sel)
    3'd0   : r_td_gain2_sel <= w_td_gain2[0]&{5{r_agcgain_flag[0]}};
    default: r_td_gain2_sel <= w_td_gain2[1]&{5{r_agcgain_flag[1]}};
    endcase
  end
end

always @(posedge i_clk) begin
  if(i_rst) begin
    r_td_gain1_sel <= 0;
  end
    else if(OC==3) begin
    `ifdef non_interleav                                                                                                                                                                                                                            
//    case(w_gaincomp_in_vld)
//        8'h01   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
//        8'h02   : r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
//        8'h04   : r_td_gain1_sel <= w_td_gain1[2]&{4{r_agcgain_flag[2]}};
//        8'h08   : r_td_gain1_sel <= w_td_gain1[3]&{4{r_agcgain_flag[3]}};
//        8'h10   : r_td_gain1_sel <= w_td_gain1[4]&{4{r_agcgain_flag[4]}};
//        8'h20   : r_td_gain1_sel <= w_td_gain1[5]&{4{r_agcgain_flag[5]}};
//        8'h40   : r_td_gain1_sel <= w_td_gain1[6]&{4{r_agcgain_flag[6]}};
//        8'h80   : r_td_gain1_sel <= w_td_gain1[7]&{4{r_agcgain_flag[7]}};
//        default : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
//        endcase

        case(r_cond_td_gain_sel)
        3'd0   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
        3'd1   : r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
        3'd2   : r_td_gain1_sel <= w_td_gain1[2]&{4{r_agcgain_flag[2]}};
        3'd3   : r_td_gain1_sel <= w_td_gain1[3]&{4{r_agcgain_flag[3]}};
        3'd4   : r_td_gain1_sel <= w_td_gain1[4]&{4{r_agcgain_flag[4]}};
        3'd5   : r_td_gain1_sel <= w_td_gain1[5]&{4{r_agcgain_flag[5]}};
        3'd6   : r_td_gain1_sel <= w_td_gain1[6]&{4{r_agcgain_flag[6]}};
        3'd7   : r_td_gain1_sel <= w_td_gain1[7]&{4{r_agcgain_flag[7]}};
        default : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
        endcase

    `else
        case(r_symbol_cnt[2:0])
        3'd5   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
        3'd6   : r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
        3'd7   : r_td_gain1_sel <= w_td_gain1[2]&{4{r_agcgain_flag[2]}};
        3'd0   : r_td_gain1_sel <= w_td_gain1[3]&{4{r_agcgain_flag[3]}};
        3'd1   : r_td_gain1_sel <= w_td_gain1[4]&{4{r_agcgain_flag[4]}};
        3'd2   : r_td_gain1_sel <= w_td_gain1[5]&{4{r_agcgain_flag[5]}};
        3'd3   : r_td_gain1_sel <= w_td_gain1[6]&{4{r_agcgain_flag[6]}};
        default: r_td_gain1_sel <= w_td_gain1[7]&{4{r_agcgain_flag[7]}};
    endcase

    `endif
  end
else if(OC==2) begin
    `ifdef non_interleav
        case(r_cond_td_gain_sel)
        3'd0   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
        3'd1   : r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
        3'd2   : r_td_gain1_sel <= w_td_gain1[2]&{4{r_agcgain_flag[2]}};
        3'd3   : r_td_gain1_sel <= w_td_gain1[3]&{4{r_agcgain_flag[3]}};
        default : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
        endcase
    `else
    case(r_symbol_cnt[1:0])
    2'd1   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
    2'd2   : r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
    2'd3   : r_td_gain1_sel <= w_td_gain1[2]&{4{r_agcgain_flag[2]}};
    default: r_td_gain1_sel <= w_td_gain1[3]&{4{r_agcgain_flag[3]}};
    endcase    
    `endif
  end
  else begin
    case(r_cond_td_gain_sel)
    3'd0   : r_td_gain1_sel <= w_td_gain1[0]&{4{r_agcgain_flag[0]}};
    default: r_td_gain1_sel <= w_td_gain1[1]&{4{r_agcgain_flag[1]}};
    endcase
  end
end


reg [9:0] r_gaincomp_coef;

always @(posedge i_clk) begin
  if(i_rst) begin
        r_gaincomp_coef <= 'd0;
  end
 //else if(r_gaincomp_on&(~r_cal_bypass_flag)) begin
 else begin
    case(r_td_gain2_sel) //6,7,0,1,2,3,4,5,6,7,...
      5'd0   : r_gaincomp_coef <= 10'd256;
      5'd1   : r_gaincomp_coef <= 10'd264;
      5'd2   : r_gaincomp_coef <= 10'd272;
      5'd3   : r_gaincomp_coef <= 10'd279;
      5'd4   : r_gaincomp_coef <= 10'd286;
      5'd5   : r_gaincomp_coef <= 10'd293;
      5'd6   : r_gaincomp_coef <= 10'd300;
      5'd7   : r_gaincomp_coef <= 10'd307;
      5'd8   : r_gaincomp_coef <= 10'd314;
      5'd9   : r_gaincomp_coef <= 10'd320;
      5'd10  : r_gaincomp_coef <= 10'd326;
      5'd11  : r_gaincomp_coef <= 10'd333;
      5'd12  : r_gaincomp_coef <= 10'd339;
      5'd13  : r_gaincomp_coef <= 10'd345;
      5'd14  : r_gaincomp_coef <= 10'd351;
      5'd15  : r_gaincomp_coef <= 10'd356;
      5'd16  : r_gaincomp_coef <= 10'd181;
      5'd17  : r_gaincomp_coef <= 10'd187;
      5'd18  : r_gaincomp_coef <= 10'd192;
      5'd19  : r_gaincomp_coef <= 10'd197;
      5'd20  : r_gaincomp_coef <= 10'd202;
      5'd21  : r_gaincomp_coef <= 10'd207;
      5'd22  : r_gaincomp_coef <= 10'd212;
      5'd23  : r_gaincomp_coef <= 10'd217;
      5'd24  : r_gaincomp_coef <= 10'd222;
      5'd25  : r_gaincomp_coef <= 10'd226;
      5'd26  : r_gaincomp_coef <= 10'd231;
      5'd27  : r_gaincomp_coef <= 10'd235;
      5'd28  : r_gaincomp_coef <= 10'd239;
      5'd29  : r_gaincomp_coef <= 10'd244;
      5'd30  : r_gaincomp_coef <= 10'd248;
      default: r_gaincomp_coef <= 10'd252;   
    endcase
  end
  //else begin 
  //    r_gaincomp_coef <= 'd0;
  //end
end


// NP clk delay
ylib_fxp_smult#(.XB(IB), .YB(10), .NP(NP)) ui_lib_fxp_smult
(
     .i_clk      ( i_clk              ) // CLK 
    ,.i_rst      ( i_rst              ) // Async. Reset Active High    
    ,.i_vld      ( |w_gaincomp_in_vld ) // Input Valid
    ,.i_x        ( w_gaincomp_in_I    ) // Input X  7,0,1,2,3,4,5,6,7,0...
    ,.i_y        ( r_gaincomp_coef    ) // Input Y
    ,.o_vld      ( w_mut_out_valid    ) // Output Valid
    ,.o_z        ( w_mut_out_I        ) // Ouput
);


ylib_fxp_smult#(.XB(IB), .YB(10), .NP(NP)) uq_lib_fxp_smult
(
     .i_clk      ( i_clk              ) // CLK 
    ,.i_rst      ( i_rst              ) // Async. Reset Active High    
    ,.i_vld      ( |w_gaincomp_in_vld ) // Input Valid
    ,.i_x        ( w_gaincomp_in_Q    ) // Input X
    ,.i_y        ( r_gaincomp_coef    ) // Input Y
    ,.o_vld      (                    ) // Output Valid
    ,.o_z        ( w_mut_out_Q        ) // Ouput
);
wire [4:0] w_shift_value;
assign w_shift_value = $signed(r_td_gain1_sel) + $signed(5'd8);
//4clk delay
ylib_cshftvd_sat  #(.IB(IB+10-1), .SB(4), .OB(OB)) u02_lib_cshftvd_sat
(
     .i_clk      (    i_clk                                  )
    ,.i_shft     (    w_shift_value[3:0]                     )
    ,.i_din_vld  (    w_mut_out_valid                        )
    ,.i_din_i    (    w_mut_out_I[IB+10-2:0]                 )
    ,.i_din_q    (    w_mut_out_Q[IB+10-2:0]                 )
    ,.o_dout_vld (    w_shr_sat_valid                        )
    ,.o_dout_i   (    w_shr_sat_I                            )
    ,.o_dout_q   (    w_shr_sat_Q                            )
);

//*******************************************
//output signal
ylib_reg #(.WIDTH(OVS  ), .DEPTH(8) ) u00_lib_shr_fpga    ( .i_clk(i_clk), .i_in(i_gaincomp_in_vld),.o_out(o_gaincomp_out_vld) );
ylib_reg #(.WIDTH(OB   ), .DEPTH(1) ) u01_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_shr_sat_I      ),.o_out(o_gaincomp_out_I)   ); 
ylib_reg #(.WIDTH(OB   ), .DEPTH(1) ) u02_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_shr_sat_Q      ),.o_out(o_gaincomp_out_Q)   );
ylib_reg #(.WIDTH(1), .DEPTH(20) )    u03_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_frm_tick       ),.o_out(o_gaincomp_frm_tick ) );
ylib_reg #(.WIDTH(2), .DEPTH(20-1) )    u04_lib_shr_fpga    ( .i_clk(i_clk), .i_in({w_slt_tick,w_sym_tick}),.o_out({o_gaincomp_slt_tick,o_gaincomp_sym_tick }) ); 
//ylib_reg #(.WIDTH(1), .DEPTH(20) )    u05_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_sym_tick       ),.o_out(o_gaincomp_sym_tick ) );
ylib_reg #(.WIDTH(6), .DEPTH(20) )    u06_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_sltIdx         ),.o_out(o_gaincomp_sltIdx   ) );
ylib_reg #(.WIDTH(4), .DEPTH(20) )    u07_lib_shr_fpga    ( .i_clk(i_clk), .i_in(w_symIdx         ),.o_out(o_gaincomp_symIdx   ) );

endmodule