// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2016 Samsung Electronics Inc. All rights reserved
//
//  Project      : NR
//  Module       : ulfe_phase_comp
//  Author       : Kyeong, Soocheol
//  Description  : ulfe phase compensator
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.02.07 |Kyeong,Soocheol| Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "ulfe_cc.vh"

module ulfe_phasecomp 
#(
   parameter IB          = 15				   // Input Bitwidth
 , parameter OB          = 15    			   // Output Bitwidth
 , parameter OC          = 3     			   // Overclocking Factor
 , parameter OVS         = 2**OC
 , parameter SCO         = 1			       // subcarrier spacing order
 , parameter NW          = 14*(2**SCO)	       // number of weight
 , parameter WB          = 16    		       // weight
 , parameter VENDOR      = "Xilinx"

)(
    input   wire                            i_clk                      // Clock                                      
   ,input   wire                            i_rst                      // Reset                                          
   ,input   wire                            i_frm_tick
   ,input   wire                            i_slt_tick
   ,input   wire                            i_sym_tick
   ,input   wire [             6-1:0]       i_sltIdx 
   ,input   wire [             4-1:0]       i_symIdx                                           
   ,input   wire                            i_bcf_en
   ,input   wire                            i_tdd_mode                                          
   ,input   wire [           OVS-1:0]       i_phaseCompOn             // phasecomp on/off 
   ,input   wire [           OVS-1:0]       i_calBypassFlag           // calibration pattern bypass  
   ,input   wire [         NW*WB-1:0]       i_phaseW_i                // in-phase weight
   ,input   wire [         NW*WB-1:0]       i_phaseW_q                // quadrature weight
   ,input   wire [           OVS-1:0]       i_PHASECOMP_in_vld        // enable of input
   ,input   wire [            IB-1:0]       i_PHASECOMP_in_I          // in-phase input
   ,input   wire [            IB-1:0]       i_PHASECOMP_in_Q          // quadrature input                                        
   ,output  reg  [           OVS-1:0]       o_PHASECOMP_out_vld       // enable of output 
   ,output  reg  [            OB-1:0]       o_PHASECOMP_out_I         // in-phase output
   ,output  reg  [            OB-1:0]       o_PHASECOMP_out_Q         // quadrature output   
   ,output  wire                            o_frm_tick
   ,output  wire                            o_slt_tick
   ,output  wire                            o_sym_tick
   ,output  wire [             6-1:0]       o_sltIdx 
   ,output  wire [             4-1:0]       o_symIdx  	                                         
   ,output  wire                            o_bcf_en  
   ,output  wire                            o_tdd_mode                                             
// , output  wire [            32-1:0]      o_PHASECOMP_latency

`ifdef ULFE_Cp
   ,input wire [3:0]                        i_uin_symbol_idx
`endif
`ifdef ULFE_DSS
//   ,input wire                              i_uin_en_technology  
//   ,input wire                              i_uin_technology_dss 
    ,input wire [105:0]                     i_dlymem_dss_tech
,output wire     [ 4:0]                     o_dbg_dssCp_alarm
`endif


);

localparam CM                  = IB+WB+1;
localparam SF                  = 14;
localparam CMUL_LATENCY        = 4'd6;
localparam CSHFTD_SAT_LATENCY  = 4'd3;
localparam DLY_ME              = (4'd1+CMUL_LATENCY+CSHFTD_SAT_LATENCY+4'd2);

// input signal registering ****************************************
wire    [    1-1:0]  w_in_en_mux       ;
wire    [  OVS-1:0]  w_in_en           ;
wire    [   IB-1:0]  w_in_i  , w_in_q  ; 
wire                 w_phaseCompOn     ;
wire    [   WB-1:0]  w_phaseW_i        ;
wire    [   WB-1:0]  w_phaseW_q        ;
wire    [   WB-1:0]  w_currphaseW_i    ;
wire    [   WB-1:0]  w_currphaseW_q    ;
wire                 w_cmul_vld        ;
wire    [   CM-1:0]  w_cmul_i, w_cmul_q;
wire                 w_conv_vld        ;
wire    [   OB-1:0]  w_conv_i, w_conv_q;

wire d1_sym_tick;
wire [4-1:0] wd1_symIdx;

reg   [ WB-1:0]      r_arrayW_i[0:2**SCO-1][0:14-1];
reg   [ WB-1:0]      r_arrayW_q[0:2**SCO-1][0:14-1];

reg   [4:0]          r_dbg_dssCp_alarm;

`ifndef attr_type_intel
(* keep = "true" *) reg r1_frm_tick;
(* keep = "true" *) reg r2_frm_tick;
`else
reg r1_frm_tick;
reg r2_frm_tick;
`endif

always @(posedge i_clk)
begin    
    r1_frm_tick <= i_frm_tick;
    r2_frm_tick <= i_frm_tick;
end



genvar i,j;
generate 

for(i=0; i<2**SCO; i=i+1) begin
  for(j=0; j<14; j=j+1) begin
    always @(posedge i_clk) begin
      if(r1_frm_tick) begin
        r_arrayW_i[i][j] <= i_phaseW_i[(14*i+j)*WB +:WB];
//        r_arrayW_q[i][j] <= i_phaseW_q[(14*i+j)*WB +:WB];
      end
    end
  end
end 

for(i=0; i<2**SCO; i=i+1) begin
  for(j=0; j<14; j=j+1) begin
    always @(posedge i_clk) begin
      if(r2_frm_tick) begin
//        r_arrayW_i[i][j] <= i_phaseW_i[(14*i+j)*WB +:WB];
        r_arrayW_q[i][j] <= i_phaseW_q[(14*i+j)*WB +:WB];
      end
    end
  end
end 


endgenerate

wire        w_phaseCompBypass   ;

`ifdef ULFE_DSS
integer     k;
reg [3:0]   r_symidx_dss_tech       ;
reg [105:0] r_mem_dss_tech          ;
reg [105:0] r_dlymem_dss_tech[1:0]  ;
reg [105:0] r_dss_tech              ;
reg [105:0] sr_dss_tech             ;
reg [6:0]   r_getcnt                ;    
reg         r_uin_en_technology     ;
reg         r_phasecomp_in_vld      ;
reg [3:0]   r_re_cnt                ;

always @(posedge i_clk)
begin
//    r_uin_en_technology <= i_uin_en_technology;
    r_phasecomp_in_vld  <= |i_PHASECOMP_in_vld; 
end

/* 
always @(posedge i_clk)
begin
    if(i_uin_en_technology)
    begin
        r_getcnt <= r_getcnt + 7'd1;
    end
    else
    begin
        r_getcnt <= 7'd0;        
    end
end     

//always@(posedge i_clk) 
//begin
//    if(i_uin_en_technology)
//    begin
//        for(k=0;k<106;k++)      // Designed by W.D.
//        begin
//        r_mem_dss_tech[k] <= (r_getcnt == k) ? i_uin_technology_dss : r_mem_dss_tech[k] ;
//        end
//    end
//end
always@(posedge i_clk) 
begin
    if(i_rst)
    begin
        for(k=0;k<106;k=k+1)
        begin
            r_mem_dss_tech[k] <= 1'b1;
        end
    end    
    else if(i_uin_en_technology)
    begin
        for(k=0;k<106;k=k+1)      // Designed by W.D.
        begin
        if(r_getcnt == k[6:0]) 
        begin
            r_mem_dss_tech[k] <= i_uin_technology_dss;
        end
        else
        begin
            r_mem_dss_tech[k] <= r_mem_dss_tech[k];
        end
        end
    end
    else
    begin
        r_mem_dss_tech  <= r_mem_dss_tech;
    end
end

always @(posedge i_clk)
begin
    if(~i_uin_en_technology & r_uin_en_technology)
        r_symidx_dss_tech <= i_uin_symbol_idx;    
end
*/

always @(posedge i_clk)
begin
    if(i_sym_tick)
    begin
//        r_dlymem_dss_tech[1] <= r_mem_dss_tech;   
//        r_dlymem_dss_tech[0] <= r_dlymem_dss_tech[1];   
        r_dss_tech          <= i_dlymem_dss_tech;//r_dlymem_dss_tech[0];   
        r_symidx_dss_tech   <= i_uin_symbol_idx;
    end
end

always @(posedge i_clk)
begin
    if(|i_PHASECOMP_in_vld & ~r_phasecomp_in_vld)
    begin
        sr_dss_tech <= r_dss_tech;
        r_re_cnt    <= 4'd0;
    end 
    else if(|i_PHASECOMP_in_vld & (r_re_cnt==4'd11))
    begin
        sr_dss_tech <= sr_dss_tech >> 1;
        r_re_cnt    <= 4'd0;
    end 
    else if(|i_PHASECOMP_in_vld )
    begin
        sr_dss_tech <= sr_dss_tech ;
        r_re_cnt    <= r_re_cnt + 4'd1;
    end 
    else
    begin
        sr_dss_tech <= r_dss_tech;
        r_re_cnt    <= 4'd0;        
    end
end

reg [OVS-1:0]       r_PHASECOMP_in_vld  ;
always @(posedge i_clk)
begin
    r_PHASECOMP_in_vld <= i_PHASECOMP_in_vld ;
end

assign w_phaseCompBypass = |r_PHASECOMP_in_vld ? sr_dss_tech[0] : 1'b1 ;


///dbg
always @(posedge i_clk)
begin
    if(o_slt_tick)       
    begin
        if(r_symidx_dss_tech != wd1_symIdx)
        begin
            r_dbg_dssCp_alarm[4]    <= 1'b1;
//          r_dbg_dssCp_alarm[15:4]  <= wd1_symIdx - r_symidx_dss_tech;
//          r_dbg_dssCp_alarm[7:0]   <= r_symidx_dss_tech - wd1_symIdx;          
            r_dbg_dssCp_alarm[3:0]  <= r_symidx_dss_tech;
        end
        else
        begin
            r_dbg_dssCp_alarm       <= 5'd0;
        end
    end
    else
    begin
        r_dbg_dssCp_alarm       <= r_dbg_dssCp_alarm;
    end         
end
`else
assign w_phaseCompBypass = 1'b1;

always @(posedge i_clk)
begin
    r_dbg_dssCp_alarm <= 5'd0;
end
`endif

assign o_dbg_dssCp_alarm = r_dbg_dssCp_alarm;








ylib_reg #(.WIDTH(1) ,.DEPTH(2)) u00_lib_reg(.i_clk(i_clk),.i_in(|i_PHASECOMP_in_vld),.o_out(w_in_en_mux));
ylib_reg #(.WIDTH(IB),.DEPTH(2)) u02_lib_reg(.i_clk(i_clk) ,.i_in( i_PHASECOMP_in_I  ),.o_out(w_in_i     ));
ylib_reg #(.WIDTH(IB),.DEPTH(2)) u03_lib_reg(.i_clk(i_clk) ,.i_in( i_PHASECOMP_in_Q  ),.o_out(w_in_q     ));


ylib_pshift #(.BW_SHIFT(2))    u_dly_i_sym_tick (.i_clk(i_clk), .i_shift(2'd2),    .i_in(i_sym_tick        ), .o_out(d1_sym_tick));
ylib_reg #(.WIDTH(4) ,.DEPTH(1)) u_dly_i_sym_idx(.i_clk(i_clk),.i_in(i_symIdx),.o_out(wd1_symIdx));


//syncTo vld+1
//ylib_reg_clk_en #(.WIDTH(1) ,.DEPTH(1))  u04_lib_reg
//(
//  .i_clk ( i_clk                                   )
// ,.i_en  ( d1_sym_tick                              )
// ,.i_in  ( (|i_phaseCompOn) &&(~(&i_calBypassFlag)))
// ,.o_out ( w_phaseCompOn                           )
//);
ylib_reg #(.WIDTH(1) ,.DEPTH(1))  u04_lib_reg
(
  .i_clk ( i_clk                                   )
 ,.i_in  ( (|i_phaseCompOn) &&(~(&i_calBypassFlag)) && w_phaseCompBypass)
 ,.o_out ( w_phaseCompOn                           )
);



generate 
if(SCO==0) begin //15K
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u05_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_i[0][wd1_symIdx]),.o_out (w_phaseW_i));
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u06_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_q[0][wd1_symIdx]),.o_out (w_phaseW_q));
end
else if(SCO==1) begin //30K
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u05_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_i[i_sltIdx[0]][wd1_symIdx]),.o_out (w_phaseW_i));
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u06_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_q[i_sltIdx[0]][wd1_symIdx]),.o_out (w_phaseW_q));
end
else if(SCO==2) begin //60K
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u05_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_i[i_sltIdx[1:0]][wd1_symIdx]),.o_out (w_phaseW_i));
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u06_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_q[i_sltIdx[1:0]][wd1_symIdx]),.o_out (w_phaseW_q));
end
else begin //3 (120K)
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u05_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_i[i_sltIdx[2:0]][wd1_symIdx]),.o_out (w_phaseW_i));
ylib_reg_clk_en #(.WIDTH(WB),.DEPTH(1))  u06_lib_reg (.i_clk(i_clk),.i_en(d1_sym_tick),.i_in(r_arrayW_q[i_sltIdx[2:0]][wd1_symIdx]),.o_out (w_phaseW_q));
end
endgenerate

// mult. weight ****************************************************
assign w_currphaseW_i	= w_phaseCompOn? w_phaseW_i : 2**SF;
assign w_currphaseW_q	= w_phaseCompOn? w_phaseW_q : 0;

//syncTo vld+1+CMUL_LATENCY
ylib_cmult #(.AWIDTH(IB), .BWIDTH(WB)) u07_lib_fxp_cmult 
(
 .clk ( i_clk          )
,.en ( w_in_en_mux    )
,.ar ( w_in_i         )
,.ai ( w_in_q         )
,.br ( w_currphaseW_i )
,.bi ( w_currphaseW_q )
,.pen ( w_cmul_vld     )
,.pr ( w_cmul_i       )
,.pi ( w_cmul_q       )
);
   
//syncTo vld+1+CMUL_LATENCY+CSHFTD_SAT_LATENCY
ylib_cshftd_sat  #(.IB(CM),.SF(SF),.OB(OB)) u08_lib_cshftvd_sat 
(
  .i_clk      ( i_clk      )
 ,.i_rst      ( 1'b0       )
 ,.i_din_vld  ( w_cmul_vld )
 ,.i_din_i    ( w_cmul_i   )
 ,.i_din_q    ( w_cmul_q   )
 ,.o_dout_vld ( w_conv_vld )
 ,.o_dout_i   ( w_conv_i   )
 ,.o_dout_q   ( w_conv_q   )
);

ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)))    bcf_en_dly      (.i_clk(i_clk), .i_shift(DLY_ME),    .i_in(i_bcf_en          ), .o_out(o_bcf_en  ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)))    tdd_mode_dly    (.i_clk(i_clk), .i_shift(DLY_ME),    .i_in(i_tdd_mode        ), .o_out(o_tdd_mode));
ylib_reg    #(.WIDTH(OVS),.DEPTH(DLY_ME-2+1)) u09_lib_shr     (.i_clk(i_clk), .i_in(i_PHASECOMP_in_vld), .o_out(w_in_en));
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)))    sync_o_frm_tick (.i_clk(i_clk), .i_shift(DLY_ME),    .i_in(i_frm_tick        ), .o_out(o_frm_tick));
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)))    sync_o_slt_tick (.i_clk(i_clk), .i_shift(DLY_ME),    .i_in(i_slt_tick        ), .o_out(o_slt_tick));
ylib_pshift #(.BW_SHIFT($clog2(DLY_ME+1)))    sync_o_sym_tick (.i_clk(i_clk), .i_shift(DLY_ME),    .i_in(i_sym_tick        ), .o_out(o_sym_tick));
ylib_reg    #(.WIDTH(6),.DEPTH(DLY_ME))         sync_o_slt_idx  (.i_clk(i_clk), .i_in(i_sltIdx),     .o_out(o_sltIdx  ));
ylib_reg    #(.WIDTH(4),.DEPTH(DLY_ME))     sync_o_sym_idx  (.i_clk(i_clk), .i_in(i_symIdx),     .o_out(o_symIdx  ));

always @(posedge i_clk) begin
  if(|w_in_en) begin
    o_PHASECOMP_out_I	<= w_conv_i;
    o_PHASECOMP_out_Q	<= w_conv_q;
  end
  else begin
    o_PHASECOMP_out_I <= 0;
    o_PHASECOMP_out_Q <= 0;
  end
	
    o_PHASECOMP_out_vld <= w_in_en;
end
endmodule
