// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ORAN RU/MISC
//  Module       : ulfe_cprm
//  Author       : dg0110.jo@samsung.com
//  Description  : 
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.28 | donggeun.jo   | initial release : oran ulfe_cprm (ref. ulfe_cprm.v 2020.03.06)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////


module ulfe_cprm #(
      parameter NUM_RX      = 2
	, parameter IB          = 15
	, parameter OB          = 15
)
(

     input                      i_clk

    ,input                      i_frm_tick_adv1    
	,input [NUM_RX-1:0]  i_calBypassFlag
	,input [3-1:0]              i_scsType
	,input                      i_cpType
	,input [2-1:0]              i_fftType
	,input [3-1:0]              i_osr_quotient
	,input [11-1:0]             i_cpRmOffset

	,input [NUM_RX-1:0]  i_CPRM_in_vld			
	,input [IB-1:0]             i_CPRM_in_I			    
	,input [IB-1:0]             i_CPRM_in_Q			    
,output [NUM_RX-1:0] o_CPRM_out_vld
,output [OB-1:0]            o_CPRM_out_I  
,output [OB-1:0]            o_CPRM_out_Q  

,output                     o_frm_tick
);

genvar i;

localparam  W_CP      = 11;
localparam  W_CP_FFT  = 13;
localparam  DLY_ME  = 3'd4 ;    //from i_vld to o_vld

wire [3-1 : 0]             w_scstype            ;
wire                       w_cptype             ;
wire [2-1 : 0]             w_ffttype            ;
wire [3-1 : 0]             w_osr_quotient       ;
wire [W_CP_FFT-1 : 0]      w_cprmoffset         ;
wire [W_CP-1 : 0]          w_nor_lcp_sz         ;
wire [W_CP-1 : 0]          w_nor_scp_sz         ;
wire [W_CP-1 : 0]          w_ext_cp_sz          ;

wire [NUM_RX-1:0]   w_CPRM_in_vld        ;   
wire [IB-1:0]              w_CPRM_in_I          ;   
wire [IB-1:0]              w_CPRM_in_Q          ;   

reg                        r_bcf_en             ;
reg [NUM_RX-1:0]    r_CPRM_out_vld       ;
reg [OB-1:0]               r_CPRM_out_I         ;
reg [OB-1:0]               r_CPRM_out_Q         ;



reg [W_CP-1 : 0]           r_cp_sz              ;
reg [W_CP_FFT-1 : 0]       r_fft_sz             ;
reg [W_CP_FFT : 0]         r_cp_cnt             ;
reg                        r_cprmout_en         ;


wire                       w_frame_sync         ;           
wire                       w_subfrm_sync        ;          
wire                       w_slot_sync          ;       
wire                       w_symbol_sync        ;       
wire [3:0]                 w_subfrm_idx         ;         
wire [7:0]                 w_slot_idx           ;        
wire [3:0]                 w_symbol_idx         ;

ylib_reg_clk_en #(.WIDTH(W_CP_FFT),.DEPTH(1))   u_set_cprmoffset
(
    .i_clk(i_clk)
    ,.i_en(w_symbol_sync)
    ,.i_in( (|i_calBypassFlag)? {W_CP_FFT{1'b0}}:{{W_CP_FFT-W_CP{1'b0}},{i_cpRmOffset}} )
    ,.o_out(    w_cprmoffset    )
);
ylib_reg #(.WIDTH(3+1+2+3),.DEPTH(1))   u_reg_parameters
(
    .i_clk(i_clk)
    ,.i_in({i_scsType,      i_cpType,       i_fftType,  i_osr_quotient})
    ,.o_out({w_scstype,     w_cptype,       w_ffttype,  w_osr_quotient})
);




ylib_reg #(.WIDTH(NUM_RX+2*IB),.DEPTH(4) ) u_reg_iq_en (
    .i_clk(i_clk), .i_in({i_CPRM_in_vld,i_CPRM_in_I,i_CPRM_in_Q}), .o_out({w_CPRM_in_vld,w_CPRM_in_I,w_CPRM_in_Q})
);


ref_vsync_gen ref_vsync_gen_instance_test0 (
    .i_clk          (i_clk),
    .i_mu           ({1'b0,w_scstype}),     // 0:15, 1:30, 2:60 ... TBD
    .i_retard       ({{19{1'b0}},3'd4}),    // dly 3clk
    .i_frame_sync   (i_frm_tick_adv1),
    .i_en           (1'b1),
    .o_frame_sync   (w_frame_sync),
    .o_subfrm_sync  (w_subfrm_sync),
    .o_slot_sync    (w_slot_sync),
    .o_symbol_sync  (w_symbol_sync),
    .o_subfrm       (w_subfrm_idx),
    .o_slot         (w_slot_idx),
    .o_symbol       (w_symbol_idx)
);


ulfe_cal_cp_sz cal_cp_inst
(
        .i_clk          (   i_clk             )
    ,   .i_scsType      (   w_scstype[1:0])
    ,   .i_fftType      (   w_ffttype     )
    ,   .o_nor_lcp_sz   (   w_nor_lcp_sz      )
    ,   .o_nor_scp_sz   (   w_nor_scp_sz      )
    ,   .o_ext_cp_sz    (   w_ext_cp_sz       )
);


always @(posedge i_clk) 
begin
    if(!w_cptype)
    case({w_scstype[1:0],w_symbol_idx[3:0]})
        {2'd0,4'd0}    : r_cp_sz  <= w_nor_lcp_sz;
        {2'd0,4'd7}    : r_cp_sz  <= w_nor_lcp_sz;
        {2'd1,4'd0}    : r_cp_sz  <= w_nor_lcp_sz;
        {2'd2,4'd0}    : r_cp_sz  <= w_nor_lcp_sz;
        default        : r_cp_sz  <= w_nor_scp_sz;
    endcase
    else
        r_cp_sz    <= w_ext_cp_sz;  
end

always @(posedge i_clk) 
begin
    if(w_symbol_sync) 
        r_cp_cnt    <= 0;
    else if(w_CPRM_in_vld[NUM_RX-1] )
        r_cp_cnt    <= r_cp_cnt+1;
    else
        r_cp_cnt    <= r_cp_cnt;
end

always @(posedge i_clk) 
begin
    case(w_ffttype) 
        2'd0 : r_fft_sz <= 13'd512;
        2'd1 : r_fft_sz <= 13'd1024;
        2'd2 : r_fft_sz <= 13'd2048;
        2'd3 : r_fft_sz <= 13'd4096;
        default : r_fft_sz <= 13'd2048;
    endcase        
end

always @(posedge i_clk) 
begin
    if(w_symbol_sync) 
    begin
        r_cprmout_en <= 1'd0;
    end
    else if(w_CPRM_in_vld[NUM_RX-1] )
    begin
        if(r_cp_cnt>=({{W_CP_FFT-W_CP{1'b0}},r_cp_sz}-w_cprmoffset-1) && r_cp_cnt<({{W_CP_FFT-W_CP{1'b0}},r_cp_sz}-w_cprmoffset+r_fft_sz-1)) 
        begin           
            r_cprmout_en    <= 1'd1    ;
        end
        else 
        begin
            r_cprmout_en    <=  1'd0    ;
        end
    end
    else
    begin
        r_cprmout_en    <= r_cprmout_en;

    end
end

always@(posedge i_clk) begin
    if(r_cprmout_en) begin
        r_CPRM_out_vld  <= w_CPRM_in_vld    ; 
        r_CPRM_out_I    <= w_CPRM_in_I      ; 
        r_CPRM_out_Q    <= w_CPRM_in_Q      ;        
    end
    else begin
        r_CPRM_out_vld  <= 0                ; 
        r_CPRM_out_I    <= 0                ; 
        r_CPRM_out_Q    <= 0                ;        
    end
end


wire wd_frm_tick;
wire wo_frm_tick;
reg [16-1:0] r_shift_cp_sz;

always @(posedge i_clk)
begin
    if(!w_cptype)//  && w_scstype == 0)
    begin
        r_shift_cp_sz <= (({2'b00,r_cp_sz}-w_cprmoffset)<<w_osr_quotient) ;
    end
    else if(w_cptype)//  && w_scstype == 0)
    begin
        r_shift_cp_sz <= (({2'b00,r_cp_sz}-w_cprmoffset)<<w_osr_quotient) ;
    end
    else
        r_shift_cp_sz <= 0;
end

wire w_frame_presync;
ylib_pshift     #(.BW_SHIFT(2)) u_preshift_frm_tick1 ( .i_clk(i_clk), .i_shift(2'd2), .i_in(w_frame_sync), .o_out(w_frame_presync) );
ylib_pshift     #(.BW_SHIFT(16)) u_shift_frm_tick1 ( .i_clk(i_clk), .i_shift(r_shift_cp_sz-16'd2), .i_in(w_frame_presync), .o_out(wo_frm_tick) );



assign o_CPRM_out_vld   = r_CPRM_out_vld    ;
assign o_CPRM_out_I     = r_CPRM_out_I      ;      
assign o_CPRM_out_Q     = r_CPRM_out_Q      ;
assign o_frm_tick       = wo_frm_tick ;//| w_o_frm_tick      ;


endmodule
