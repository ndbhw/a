// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : nbiot_oran_param_if 
//  Author       : ty321.kim@samsung.com
//  Description  : oran parameter interface for NBIOT
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | taeyeong      | Initial Release
//  ------------------------------------------------------------------------------------ 
//
////////////////////////////////////////////////////////////////////////////////////////

module nbiot_oran_param_if
#(
    parameter  NUM_ANT             =   4           
)(
    //--- clk
        input   wire                                i_clk        
    ,   input   wire                                i_nin_frame_sync

    //--- from cpu_if
    //,   input   wire    [ 8     -1:0]               i_m_frm_str             // [3:0]:PUSCH SCS,[7:4]:PUSCH FFT Size       
    ,   input   wire    [ 1     -1:0]               i_freq_shift_7p5k
    ,   input   wire    [16     -1:0]               i_rach_freq_shift
    ,   input   wire    [ 1     -1:0]               i_rach_freq_shift_sel
    
    ,   input   wire    [16     -1:0]               i_adv_offset

    ,   input   wire    [ 1     -1:0]               i_par_debug_mode     
    ,   input   wire    [ 4     -1:0]               i_par_filter_idx     
    ,   input   wire    [16     -1:0]               i_par_time_offset    
    ,   input   wire    [ 8     -1:0]               i_par_frame_struct      
    ,   input   wire    [16     -1:0]               i_par_cp_length      
    ,   input   wire    [ 4     -1:0]               i_par_num_psymbol     
    ,   input   wire    [24     -1:0]               i_par_freq_offset    
    ,   input   wire    [ 3     -1:0]               i_par_num_ro    
    ,   input   wire    [ 8     -1:0]               i_par_num_prbc     

    //--- from qm_top
    ,   input   wire    [ 1         -1:0]           i_nin_en                   // enable
    ,   input   wire    [ 4*NUM_ANT -1:0]           i_nin_filter_idx           // 1, 3                                    oRAN                                 
    ,   input   wire    [16*NUM_ANT -1:0]           i_nin_time_offset          // 0 ~ 30720 : 1ms                         oRAN                                 
    ,   input   wire    [ 8*NUM_ANT -1:0]           i_nin_frame_struct         // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,   input   wire    [16*NUM_ANT -1:0]           i_nin_cp_length            //                                         oRAN                                 
    ,   input   wire    [ 4*NUM_ANT -1:0]           i_nin_num_psymbol          //                                         oRAN                                  
    ,   input   wire    [24*NUM_ANT -1:0]           i_nin_freq_offset          //                                         oRAN                                 
    ,   input   wire    [ 8*NUM_ANT -1:0]           i_nin_num_prbc                                     
    ,   input   wire    [10*NUM_ANT -1:0]           i_nin_start_prbc         
    ,   input   wire    [ 3*NUM_ANT -1:0]           i_nin_trig                 // nin_num_ro lsb
    
    //--- to RAFE core
    ,   output  wire    [ 1     -1:0]               o_nbiot_en
    //,   output  wire    [ 6     -1:0]               o_path_ratio            // operation clock/sampling rate
    ,   output  wire    [ 1     -1:0]               o_rec_trig
    ,   output  wire    [ 4     -1:0]               o_subf_numb

    //,   output  wire    [ 4     -1:0]               o_pu_fft_idx
    ,   output  wire    [ 4     -1:0]               o_nb_scs_idx
    ,   output  wire    [14     -1:0]               o_time_offset
    ,   output  reg     [12     -1:0]               o_freq_shift
    ,   output  reg     [ 4     -1:0]               o_nb_fft_idx
    ,   output  reg     [12     -1:0]               o_num_re
    ,   output  wire    [ 4     -1:0]               o_num_psym

    //--- Read oRAN parameter
    ,   output  wire    [ 4     -1:0]               o_nin_filter_idx        
    ,   output  wire    [16     -1:0]               o_nin_time_offset       
    ,   output  wire    [ 8     -1:0]               o_nin_frame_struct      
    ,   output  wire    [16     -1:0]               o_nin_cp_length         
    ,   output  wire    [ 4     -1:0]               o_nin_num_psymbol       
    ,   output  wire    [24     -1:0]               o_nin_freq_offset       
    ,   output  wire    [ 8     -1:0]               o_nin_num_prbc   
    ,   output  wire    [10     -1:0]               o_nin_start_prbc
    ,   output  wire    [32     -1:0]               o_nin_rec_oran          // slot [15:8], symbol[3:0]    
);

// local param
 
// localparam  SUBP5 = 20'd122847 ; // 20'd122880 -1 -32 + 1symb     122847 / 127231
// localparam  SUB1  = 20'd245727 ; // 20'd245760 -1 -32 
// localparam  SUB1P5= 20'd368607 ;
// localparam  SUB1P7= 20'd417791 ;
// localparam  SUB2  = 20'd491487 ; // 20'd491520 -1 -32
// localparam  SUB3  = 20'd737247 ; // 20'd737280 -1 -32
// localparam  SUB4  = 20'd983007 ; // 20'd983040 -1 -32

localparam  SYM1  = 20'd17664  ; // 15k SCS 
localparam  SYM2  = 20'd35328  ; // 15k SCS 
// localparam  SYM4  = 20'd70272  ; // 15k SCS 
// localparam  SYM3  = 20'd367584 ; // 3.75k SCS 

// signal
reg     [ 4     -1:0]               r_nin_filter_idx        ;
reg     [16     -1:0]               r_nin_time_offset       ;
reg     [ 8     -1:0]               r_nin_frame_struct      ;
reg     [16     -1:0]               r_nin_cp_length         ;
reg     [ 4     -1:0]               r_nin_num_psymbol       ;
reg     [24     -1:0]               r_nin_freq_offset       ;
reg     [ 8     -1:0]               r_nin_num_prbc          ;
reg     [10     -1:0]               r_nin_start_prbc        ;

reg     [ 4     -1:0]               r_rec_nin_filter_idx    ;
reg     [16     -1:0]               r_rec_nin_time_offset   ;
reg     [ 8     -1:0]               r_rec_nin_frame_struct  ;
reg     [16     -1:0]               r_rec_nin_cp_length     ;
reg     [ 4     -1:0]               r_rec_nin_num_psymbol   ;
reg     [24     -1:0]               r_rec_nin_freq_offset   ;
reg     [ 8     -1:0]               r_rec_nin_num_prbc      ;
reg     [10     -1:0]               r_rec_nin_start_prbc    ;

reg     [ 4     -1:0]               rr_rec_nin_filter_idx   ;
reg     [16     -1:0]               rr_rec_nin_time_offset  ;
reg     [ 8     -1:0]               rr_rec_nin_frame_struct ;
reg     [16     -1:0]               rr_rec_nin_cp_length    ;
reg     [ 4     -1:0]               rr_rec_nin_num_psymbol  ;
reg     [24     -1:0]               rr_rec_nin_freq_offset  ;
reg     [ 8     -1:0]               rr_rec_nin_num_prbc     ;
reg     [10     -1:0]               rr_rec_nin_start_prbc   ;


wire                                w_sym_sync      ;
reg                                 r_nbiot_en      ;
reg     [22     -1:0]               r_en_cnt        ;
reg                                 r_hold          ;
reg     [22     -1:0]               r_en_len        ;
wire    [ 8     -1:0]               w_slot_num      ;
wire    [ 4     -1:0]               w_symb_num      ;

// ref sync gen & cp parsing

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'd0                  )  
    ,.i_retard              ( 22'd4                 )  
    ,.i_frame_sync          ( i_nin_frame_sync      )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         (                       )   
    ,.o_slot_sync           (                       )   
    ,.o_symbol_sync         (  w_sym_sync           )          
    ,.o_subfrm              (  o_subf_numb          )
    ,.o_slot                (  w_slot_num           )          
    ,.o_symbol              (  w_symb_num           )          
);

reg r_2nd_sec_param;

always @(posedge i_clk) begin
    if(i_nin_trig[0]) begin
        r_2nd_sec_param     <= 1'b0;
    end
    else if(i_nin_trig[6]) begin
        r_2nd_sec_param     <= 1'b1;
    end
end

always @(posedge i_clk) begin
    if (i_par_debug_mode) begin
        r_nin_filter_idx    <=  i_par_filter_idx    ;
        r_nin_time_offset   <=  i_par_time_offset   ;
        r_nin_frame_struct  <=  i_par_frame_struct  ;
        r_nin_cp_length     <=  i_par_cp_length     ;
        r_nin_num_psymbol   <=  i_par_num_psymbol   ;
        r_nin_freq_offset   <=  i_par_freq_offset   ;
        r_nin_num_prbc      <=  i_par_num_prbc      ;   
    end
    else if(w_sym_sync & (|i_nin_num_psymbol) & (r_2nd_sec_param) ) begin    
        r_nin_filter_idx    <=  i_nin_filter_idx    [  4*3 -1: 4*2];
        r_nin_time_offset   <=  i_nin_time_offset   [ 16*3 -1:16*2];
        r_nin_frame_struct  <=  i_nin_frame_struct  [  8*3 -1: 8*2];
        r_nin_cp_length     <=  i_nin_cp_length     [ 16*3 -1:16*2];
        r_nin_num_psymbol   <=  i_nin_num_psymbol   [  4*3 -1: 4*2];
        r_nin_freq_offset   <=  i_nin_freq_offset   [ 24*3 -1:24*2];
        r_nin_num_prbc      <=  i_nin_num_prbc      [  8*3 -1: 8*2];
        r_nin_start_prbc    <=  i_nin_start_prbc    [ 10*3 -1:10*2];
    end
    else if(w_sym_sync & (|i_nin_num_psymbol)) begin    
        r_nin_filter_idx    <=  i_nin_filter_idx    [  4 -1:0];
        r_nin_time_offset   <=  i_nin_time_offset   [ 16 -1:0];
        r_nin_frame_struct  <=  i_nin_frame_struct  [  8 -1:0];
        r_nin_cp_length     <=  i_nin_cp_length     [ 16 -1:0];
        r_nin_num_psymbol   <=  i_nin_num_psymbol   [  4 -1:0];
        r_nin_freq_offset   <=  i_nin_freq_offset   [ 24 -1:0];
        r_nin_num_prbc      <=  i_nin_num_prbc      [  8 -1:0];
        r_nin_start_prbc    <=  i_nin_start_prbc    [ 10 -1:0];
    end
end
                            
always @(posedge i_clk) begin
    r_rec_nin_filter_idx    <=  i_nin_filter_idx    ;
    r_rec_nin_time_offset   <=  i_nin_time_offset   ;
    r_rec_nin_frame_struct  <=  i_nin_frame_struct  ;
    r_rec_nin_cp_length     <=  i_nin_cp_length     ;
    r_rec_nin_num_psymbol   <=  i_nin_num_psymbol   ;
    r_rec_nin_freq_offset   <=  i_nin_freq_offset   ;
    r_rec_nin_num_prbc      <=  i_nin_num_prbc      ;
    r_rec_nin_start_prbc    <=  i_nin_start_prbc    ;
end

// oRAN param input timing
reg  [32    -1: 0]  r_nin_rec_oran  ;

always @(posedge i_clk) begin
    if(i_nin_trig[0]) begin
        r_nin_rec_oran          <= {1'b0,3'b0,8'b0,w_slot_num,4'b0,w_symb_num};
        rr_rec_nin_filter_idx   <=  i_nin_filter_idx   [  4 -1:0];
        rr_rec_nin_time_offset  <=  i_nin_time_offset  [ 16 -1:0];
        rr_rec_nin_frame_struct <=  i_nin_frame_struct [  8 -1:0];
        rr_rec_nin_cp_length    <=  i_nin_cp_length    [ 16 -1:0];
        rr_rec_nin_num_psymbol  <=  i_nin_num_psymbol  [  4 -1:0];
        rr_rec_nin_freq_offset  <=  i_nin_freq_offset  [ 24 -1:0];
        rr_rec_nin_num_prbc     <=  i_nin_num_prbc     [  8 -1:0];  
        rr_rec_nin_start_prbc   <=  i_nin_start_prbc   [ 10 -1:0];        
    end
    else if(i_nin_trig[6]) begin
        r_nin_rec_oran          <= {1'b0,3'b0,8'b0,w_slot_num,4'b0,w_symb_num};
        rr_rec_nin_filter_idx   <=  i_nin_filter_idx   [  4*3 -1: 4*2] ;
        rr_rec_nin_time_offset  <=  i_nin_time_offset  [ 16*3 -1:16*2] ;
        rr_rec_nin_frame_struct <=  i_nin_frame_struct [  8*3 -1: 8*2] ;
        rr_rec_nin_cp_length    <=  i_nin_cp_length    [ 16*3 -1:16*2] ;
        rr_rec_nin_num_psymbol  <=  i_nin_num_psymbol  [  4*3 -1: 4*2] ;
        rr_rec_nin_freq_offset  <=  i_nin_freq_offset  [ 24*3 -1:24*2] ;
        rr_rec_nin_num_prbc     <=  i_nin_num_prbc     [  8*3 -1: 8*2] ; 
        rr_rec_nin_start_prbc   <=  i_nin_start_prbc   [ 10*3 -1:10*2] ;       
    end
end

assign o_nin_rec_oran = r_nin_rec_oran;



ylib_pshift #(
    .BW_SHIFT   (8))
u02_ylib_pshift(
     .i_clk     (i_clk           )
//    ,.i_shift   (8'd32           )
    ,.i_shift   (8'd18           )  // CE
    ,.i_in      ({i_nin_trig[0]|i_nin_trig[6]}      )
    ,.o_out     (o_rec_trig      )
);


// enable control

reg r_inf_en_mode;

always @(posedge i_clk) begin
    if(r_nin_frame_struct[3:0] == 4'hd) begin
        r_inf_en_mode   <= 1'b1;
    end
    else if(r_nin_frame_struct[3:0] == 4'h0) begin
        r_inf_en_mode   <= 1'b0;
    end
end


always @(posedge i_clk) begin
    if(i_nin_frame_sync) begin
        r_en_len        <= 0;        
    end  
    else if(w_sym_sync & (i_nin_frame_struct[3:0] == 4'hd)) begin
        r_en_len        <= SYM2;        
    end
    else if(w_sym_sync & (i_nin_num_psymbol == 4'h1)) begin
        r_en_len        <= r_en_len + SYM1;        
    end
end


always @(posedge i_clk) begin
    // if(r_inf_en_mode) begin
    //     if(w_sym_sync) begin
    //         r_nbiot_en           <=  1'b1                ;
    //     end
    // end
    // else begin
    //     if(i_nin_frame_sync) begin
    //         r_nbiot_en           <=  1'b0                ;
    //     end
    //     else if(w_sym_sync & (|i_nin_num_psymbol) & (~r_hold)) begin
    //         r_nbiot_en           <=  i_nin_en            ;
    //     end
    //     else if(r_en_cnt== r_en_len) begin
    //         r_nbiot_en           <=  1'b0                ;
    //     end
    // end
    r_nbiot_en  <= 1'b1;
end

always @(posedge i_clk) begin
    if(i_nin_frame_sync) begin
        r_en_cnt        <=  22'b0;
        r_hold          <=   1'b0;
    end
    else if(r_en_cnt == r_en_len) begin
        r_en_cnt        <=  22'b0;
        r_hold          <=   1'b0;
    end
    else if(r_nbiot_en) begin
        r_en_cnt        <=  r_en_cnt + 22'b1;
        r_hold          <=              1'b1;
    end
end

assign o_nbiot_en = r_nbiot_en;


// time offset

reg [18 -1:0]   r_time_offset;

always @(posedge i_clk) begin
    if((r_nin_time_offset == 16'b0) & (r_nin_cp_length==16'b0)) begin
        r_time_offset <= 18'h77f0;
    end
    else begin
        r_time_offset <= r_nin_time_offset + r_nin_cp_length - i_adv_offset -1;
    end
end

assign o_time_offset = r_time_offset[17:4]; 


// always @(posedge i_clk) begin
//     if(r_nin_num_psymbol[1] | r_nin_num_psymbol[3]) begin
//         if((r_nin_time_offset == 16'b0) & (r_nin_cp_length==16'b0)) begin
//             r_time_offset <= 18'h7710;
//         end
//         else begin
//             r_time_offset <= r_nin_time_offset + r_nin_cp_length - 18'hF1;
//         end
//     end        
//     else begin
//         if((r_nin_time_offset == 16'b0) & (r_nin_cp_length==16'b0)) begin
//             r_time_offset <= 18'h77f0;
//         end
//         else begin
//             r_time_offset <= r_nin_time_offset + r_nin_cp_length -1;
//         end
//     end        
// end
// 
// assign o_time_offset = r_time_offset[17:4];

// freq_shift, num_re

always @(posedge i_clk) begin
    if((r_nin_frame_struct[7:4]==4'd9)||(r_nin_frame_struct[7:4]==4'd6)) begin   // 512 & 64
        o_freq_shift    <= 12'd32;
    end
    else if((r_nin_frame_struct[7:4]==4'd7)||(r_nin_frame_struct[7:4]==4'd4)) begin   // 128 & 16        
        o_freq_shift    <= 12'd128;
    end
end

always @(posedge i_clk) begin
    o_num_re    <= {1'b0,r_nin_num_prbc,3'b0} + {2'b0,r_nin_num_prbc,2'b0};
end

// nbiot scs, fft

assign o_nb_scs_idx = r_nin_frame_struct[3:0];

always @(posedge i_clk) begin
    case(r_nin_frame_struct [7:4])
        4'd 6   : o_nb_fft_idx    <= 4'd6;
        4'd 9   : o_nb_fft_idx    <= 4'd6;
        4'd 4   : o_nb_fft_idx    <= 4'd4;
        4'd 7   : o_nb_fft_idx    <= 4'd4;
        default : o_nb_fft_idx    <= 4'd4; 
    endcase
end

// numPsym

assign o_num_psym   = r_nin_num_psymbol;


// oRAN param read

assign o_nin_filter_idx       = rr_rec_nin_filter_idx    ; 
assign o_nin_time_offset      = rr_rec_nin_time_offset   ; 
assign o_nin_frame_struct     = rr_rec_nin_frame_struct  ; 
assign o_nin_cp_length        = rr_rec_nin_cp_length     ; 
assign o_nin_num_psymbol      = rr_rec_nin_num_psymbol   ; 
assign o_nin_freq_offset      = rr_rec_nin_freq_offset   ; 
assign o_nin_num_prbc         = rr_rec_nin_num_prbc      ;
assign o_nin_start_prbc       = rr_rec_nin_start_prbc    ;

endmodule                                                             
