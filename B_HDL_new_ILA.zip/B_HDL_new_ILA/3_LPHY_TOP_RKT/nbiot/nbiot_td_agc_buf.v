// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : nbiot_td_agc_buf
//  Author       : jyzoo.lee@samsung.com
//  Description  : Psym Buffering & Time Domain AGC 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.5.19  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.7.14  | taeyeong      | Modify for FSU20
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_td_agc_buf
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16   
   ,parameter  PW_BW               =   31
   ,parameter  VENDOR              =   "Xilinx"
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from cpu
    ,   input   wire    [ 5         -1:0]           i_tagc_back_off
    ,   input   wire    [ 1         -1:0]           i_tagc_on      

    //--- from oran 
    ,   input   wire    [ 4         -1:0]           i_nbiot_nfft
    ,   input   wire    [ 4         -1:0]           i_nbiot_scs  
    ,   input   wire    [ 8         -1:0]           i_nin_frame_idx  

    //--- from config_map
    ,   input   wire    [ 1         -1:0]           i_frame_sync           
    ,   input   wire    [ 1         -1:0]           i_ro_sync
    ,   input   wire    [NUM_ANT    -1:0]           i_nin_en           
    ,   input   wire    [2*DI_BW    -1:0]           i_nin_iq           

    //--- to rach_fft_demap
    ,   output  reg     [ 1         -1:0]           o_frame_sync           
    ,   output  wire    [ 1         -1:0]           o_nout_en
    ,   output  wire    [2*DO_BW    -1:0]           o_nout_iq      
    ,   output  reg     [NUM_ANT*4  -1:0]           o_tagc_gain
    ,   output  reg     [NUM_ANT*5  -1:0]           o_tagc_lut_index

    ,   output  reg     [NUM_ANT*PW_BW-1:0]         o_rssi
);

//Parameter nbiot_td_agc_buf
localparam      FFT_0016          =       12'd0016                    ;
localparam      FFT_0064          =       12'd0064                    ;
localparam      FFT_0512          =       12'd0512                    ;
localparam      PRACH_2048_SYNC   =       12'd1536                    ;
localparam      READ_DELAY        =       6'd7+6'd32                  ;
localparam      READ_OFFSET       =       4096                        ;  // 6
localparam      SMP_CNT           =       14                          ;
localparam      MEM_ADDR          =        9                          ;
localparam      COMP_BW           =       25                          ;
localparam      SYNC_DELAY        =       18'd16311                   ;  

//logic variable
genvar gidx ;


// cpu param reg
reg [1  -1:0]   r_tagc_on       ;
reg [6  -1:0]   r_tagc_back_off ;

always@(posedge i_clk) begin
    r_tagc_on       <=  i_tagc_on   ;
    r_tagc_back_off <=  {1'b0,i_tagc_back_off} ;
end

// oran param reg
reg   [SMP_CNT -1:0]   r_nfft;

always @(posedge i_clk) begin
    case(i_nbiot_nfft)
        4'b0100 : r_nfft    <= FFT_0016;
        4'b0111 : r_nfft    <= FFT_0016;
        4'b0110 : r_nfft    <= FFT_0064;        
        4'b1001 : r_nfft    <= FFT_0064;
        default : r_nfft    <= FFT_0064;
    endcase
end

// sample counter
reg [SMP_CNT -1:0]   r_psym_smp_cnt    ;
reg [1  -1:0]   r_psym_pow_msr_en ;
reg [1  -1:0]   r_psym_pow_done   ;
reg [1  -1:0]   r_psym_sync       ;

always@(posedge i_clk) begin
    if(i_ro_sync) begin
        r_psym_smp_cnt      <= {SMP_CNT{1'b0}}        ;
        r_psym_pow_msr_en   <=  1'b1        ;
        r_psym_pow_done     <=  1'b0        ;
        r_psym_sync         <=  1'b1        ;
    end
    else if(i_nin_en[NUM_ANT-1]) begin
        if(r_psym_smp_cnt==PRACH_2048_SYNC-1'd1) begin
            r_psym_smp_cnt      <=  r_psym_smp_cnt + 1'd1 ;
            r_psym_pow_msr_en   <=  1'b1  ;
        end
        else if(r_psym_smp_cnt==r_nfft-1'd1) begin
            r_psym_smp_cnt      <=  {SMP_CNT{1'b0}}   ;
            r_psym_pow_msr_en   <=  1'b0    ;
            r_psym_pow_done     <=  1'b1    ;
        end
        else begin
            r_psym_smp_cnt  <=  r_psym_smp_cnt + 1'd1 ;
            r_psym_sync         <=  1'b0  ;
        end
    end
    else begin
        r_psym_pow_done     <=  1'b0  ;
        r_psym_sync         <=  1'b0  ;
    end
end


// msr_en dly

wire    w_psym_pow_msr_en;
wire    w_psym_pow_done  ;

ylib_reg #(
    .WIDTH(1+1) ,.DEPTH(3)) 
u00_out_reg(
    .i_clk      ( i_clk             )
   ,.i_in       ( {r_psym_pow_msr_en,r_psym_pow_done} )
   ,.o_out      ( {w_psym_pow_msr_en,w_psym_pow_done} )
);



// input reg

reg [NUM_ANT-1:0]   r_nin_en                            ;  
reg [2*DI_BW-1:0]   r_nin_iq            [NUM_ANT-1:0]   ;             
reg [NUM_ANT-1:0]   rr_nin_en                           ;  
reg [2*DI_BW-1:0]   rr_nin_iq           [NUM_ANT-1:0]   ;           

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_in_sep
always@(posedge i_clk) begin
    r_nin_en[gidx]  <=  i_nin_en[gidx]  ;
    if(i_nin_en[gidx]) begin
        r_nin_iq[gidx]  <=  i_nin_iq;
    end
end
always@(posedge i_clk) begin
    rr_nin_en[gidx] <=  r_nin_en[gidx]  ;
    if(r_nin_en[gidx]) begin
        rr_nin_iq[gidx]  <= r_nin_iq[gidx] ;
    end
end
end
endgenerate

// tagc

reg [0:0]           r_pow2_en           [NUM_ANT-1:0]   ;
reg [2*DI_BW-1:0]   r_pow2_i            [NUM_ANT-1:0]   ;
reg [2*DI_BW-1:0]   r_pow2_q            [NUM_ANT-1:0]   ;
reg [0:0]           r_pow2_iq_en        [NUM_ANT-1:0]   ;
reg [2*DI_BW:0]     r_pow2_iq           [NUM_ANT-1:0]   ;
reg [0:0]           r_psym_pow_en       [NUM_ANT-1:0]   ;
reg [40 -1:0]       r_psym_pow          [NUM_ANT-1:0]   ;
reg [0:0]           r_psym_pow_avg_en   [NUM_ANT-1:0]   ;
reg [PW_BW  -1:0]   r_psym_pow_avg      [NUM_ANT-1:0]   ;

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_psym_pow_calc

// pow    
always@(posedge i_clk) begin
    if(r_nin_en[gidx]) begin
        r_pow2_en[gidx] <=  r_nin_en[gidx]  ;
        r_pow2_i[gidx]  <=  $signed({{{DI_BW}{r_nin_iq[gidx][DI_BW*2-1]}},r_nin_iq[gidx][(DI_BW*2-1)-:DI_BW]})*$signed({{{DI_BW}{r_nin_iq[gidx][DI_BW*2-1]}},r_nin_iq[gidx][(DI_BW*2-1)-:DI_BW]}) ;
        r_pow2_q[gidx]  <=  $signed({{{DI_BW}{r_nin_iq[gidx][DI_BW*1-1]}},r_nin_iq[gidx][(DI_BW*1-1)-:DI_BW]})*$signed({{{DI_BW}{r_nin_iq[gidx][DI_BW*1-1]}},r_nin_iq[gidx][(DI_BW*1-1)-:DI_BW]}) ;
    end
    else begin
        r_pow2_en[gidx] <=  1'd0    ;
    end
end

// I + Q
always@(posedge i_clk) begin 
    if(r_pow2_en[gidx]) begin
        r_pow2_iq_en[gidx]  <=  r_pow2_en[gidx]  ;  
        r_pow2_iq[gidx]     <=  {1'd0,r_pow2_i[gidx]}+{1'd0,r_pow2_q[gidx]}   ;
    end
    else begin
        r_pow2_iq_en[gidx]  <=  1'd0    ;  
    end
end

// sum 512
always@(posedge i_clk) begin 
    if(r_psym_sync) begin
        r_psym_pow[gidx]    <=   40'd0   ;
    end
    else if(w_psym_pow_msr_en && r_pow2_iq_en[gidx]) begin
        r_psym_pow_en[gidx] <=   r_pow2_iq_en[gidx]  ;  
        r_psym_pow[gidx]    <=   r_psym_pow[gidx] + r_pow2_iq[gidx]  ;
    end        
    else begin
        r_psym_pow_en[gidx] <=   1'd0    ;  
    end
end

// Avg
always@(posedge i_clk) begin 
//    if(r_psym_pow_en[gidx]&r_psym_pow_done&&r_psym_smp_cnt==10'd0) begin
    if(w_psym_pow_done) begin
        r_psym_pow_avg_en[gidx]   <=   1'd1 ;
        r_psym_pow_avg[gidx]      <=   (r_psym_pow[gidx]) >> i_nbiot_nfft;
    end
    else begin
        r_psym_pow_avg_en[gidx]   <=   1'd0 ;
    end
end

end
endgenerate

reg [0:0]           r_clz_en            [NUM_ANT-1:0]   ;
reg [4:0]           r_clz               [NUM_ANT-1:0]   ;
reg [3:0]           r_clz_flw_4bit      [NUM_ANT-1:0]   ;
reg [0:0]           r_target_pwr_en     [NUM_ANT-1:0]   ;
wire[5:0]           w_target_pwr        [NUM_ANT-1:0]   ;
reg [4:0]           r_target_pwr_sat    [NUM_ANT-1:0]   ;
reg [0:0]           r_td_gain2_en       [NUM_ANT-1:0]   ;
reg [4:0]           r_td_gain2          [NUM_ANT-1:0]   ;
reg [8:0]           r_tdagc_frac        [      8-1:0]   ;
reg [3:0]           r_td_gain1          [      8-1:0]   ;

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g02_calc_gain

// count zero
always@(posedge i_clk) begin 
    r_clz_en[gidx] <=  r_psym_pow_avg_en[gidx] ;
    if(r_psym_pow_avg_en[gidx]) begin
        casez(r_psym_pow_avg[gidx])
            31'b1??????????????????????????????   :   begin   r_clz[gidx] <= 5'd0 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][29-:4]         ;  end
            31'b01?????????????????????????????   :   begin   r_clz[gidx] <= 5'd1 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][28-:4]         ;  end
            31'b001????????????????????????????   :   begin   r_clz[gidx] <= 5'd2 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][27-:4]         ;  end
            31'b0001???????????????????????????   :   begin   r_clz[gidx] <= 5'd3 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][26-:4]         ;  end
            31'b00001??????????????????????????   :   begin   r_clz[gidx] <= 5'd4 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][25-:4]         ;  end
            31'b000001?????????????????????????   :   begin   r_clz[gidx] <= 5'd5 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][24-:4]         ;  end
            31'b0000001????????????????????????   :   begin   r_clz[gidx] <= 5'd6 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][23-:4]         ;  end
            31'b00000001???????????????????????   :   begin   r_clz[gidx] <= 5'd7 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][22-:4]         ;  end
            31'b000000001??????????????????????   :   begin   r_clz[gidx] <= 5'd8 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][21-:4]         ;  end
            31'b0000000001?????????????????????   :   begin   r_clz[gidx] <= 5'd9 ; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][20-:4]         ;  end
            31'b00000000001????????????????????   :   begin   r_clz[gidx] <= 5'd10; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][19-:4]         ;  end
            31'b000000000001???????????????????   :   begin   r_clz[gidx] <= 5'd11; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][18-:4]         ;  end
            31'b0000000000001??????????????????   :   begin   r_clz[gidx] <= 5'd12; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][17-:4]         ;  end
            31'b00000000000001?????????????????   :   begin   r_clz[gidx] <= 5'd13; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][16-:4]         ;  end
            31'b000000000000001????????????????   :   begin   r_clz[gidx] <= 5'd14; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][15-:4]         ;  end
            31'b0000000000000001???????????????   :   begin   r_clz[gidx] <= 5'd15; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][14-:4]         ;  end
            31'b00000000000000001??????????????   :   begin   r_clz[gidx] <= 5'd16; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][13-:4]         ;  end
            31'b000000000000000001?????????????   :   begin   r_clz[gidx] <= 5'd17; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][12-:4]         ;  end
            31'b0000000000000000001????????????   :   begin   r_clz[gidx] <= 5'd18; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][11-:4]         ;  end
            31'b00000000000000000001???????????   :   begin   r_clz[gidx] <= 5'd19; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][10-:4]         ;  end
            31'b000000000000000000001??????????   :   begin   r_clz[gidx] <= 5'd20; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][09-:4]         ;  end
            31'b0000000000000000000001?????????   :   begin   r_clz[gidx] <= 5'd21; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][08-:4]         ;  end
            31'b00000000000000000000001????????   :   begin   r_clz[gidx] <= 5'd22; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][07-:4]         ;  end
            31'b000000000000000000000001???????   :   begin   r_clz[gidx] <= 5'd23; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][06-:4]         ;  end
            31'b0000000000000000000000001??????   :   begin   r_clz[gidx] <= 5'd24; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][05-:4]         ;  end
            31'b00000000000000000000000001?????   :   begin   r_clz[gidx] <= 5'd25; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][04-:4]         ;  end
            31'b000000000000000000000000001????   :   begin   r_clz[gidx] <= 5'd26; r_clz_flw_4bit[gidx] <= r_psym_pow_avg[gidx][03-:4]         ;  end
            31'b0000000000000000000000000001???   :   begin   r_clz[gidx] <= 5'd27; r_clz_flw_4bit[gidx] <={r_psym_pow_avg[gidx][02-:3],1'd0}   ;  end
            31'b00000000000000000000000000001??   :   begin   r_clz[gidx] <= 5'd28; r_clz_flw_4bit[gidx] <={r_psym_pow_avg[gidx][01-:2],2'd0}   ;  end
            31'b000000000000000000000000000001?   :   begin   r_clz[gidx] <= 5'd29; r_clz_flw_4bit[gidx] <={r_psym_pow_avg[gidx][00-:1],3'd0}   ;  end
            31'b0000000000000000000000000000001   :   begin   r_clz[gidx] <= 5'd30; r_clz_flw_4bit[gidx] <= 4'd0                                ;  end
            default                               :   begin   r_clz[gidx] <= 5'd30; r_clz_flw_4bit[gidx] <= 4'd0                                ;  end
        endcase
    end
end

// apply target back off

assign    w_target_pwr[gidx]  =   $signed({1'd0,r_clz[gidx]})-$signed({r_tagc_back_off})  ;

always@(posedge i_clk) begin
    r_target_pwr_en[gidx]   <=  r_clz_en[gidx]  ;
    if(r_clz_en[gidx]) begin
        if($signed(w_target_pwr[gidx])>6'sd15) begin 
            r_target_pwr_sat[gidx] <=  5'sd15 ;
        end
        else if($signed(w_target_pwr[gidx])<(-6'sd15)) begin 
            r_target_pwr_sat[gidx] <= -5'sd15 ;
        end
        else begin
            r_target_pwr_sat[gidx] <= w_target_pwr[gidx][4:0]  ;
        end
    end
end

// gain = tagc_gain[s][r]
always@(posedge i_clk) begin
    if(r_target_pwr_en[gidx]) begin
        r_td_gain1[gidx] <= (r_tagc_on) ? r_target_pwr_sat[gidx][4:1] : 4'd0 ;
    end
end

// tagc_lut_index[s][r]
always@(posedge i_clk) begin
    r_td_gain2_en[gidx]   <=  r_target_pwr_en[gidx]   ;
    if(r_target_pwr_en[gidx]) begin
        r_td_gain2[gidx]  <= (r_tagc_on) ? ({4'd0,r_target_pwr_sat[gidx][0]}<<4)|{1'd0,r_clz_flw_4bit[gidx]} : 5'b0 ;
    end
end

// LUT:TAGC
always@(posedge i_clk) begin
    if(r_td_gain2_en[gidx]) begin
        case(r_td_gain2[gidx]) 
            5'd0    :   r_tdagc_frac[gidx] <= 9'd256    ;
            5'd1    :   r_tdagc_frac[gidx] <= 9'd248    ;
            5'd2    :   r_tdagc_frac[gidx] <= 9'd241    ;
            5'd3    :   r_tdagc_frac[gidx] <= 9'd235    ;
            5'd4    :   r_tdagc_frac[gidx] <= 9'd229    ;
            5'd5    :   r_tdagc_frac[gidx] <= 9'd223    ;
            5'd6    :   r_tdagc_frac[gidx] <= 9'd218    ;
            5'd7    :   r_tdagc_frac[gidx] <= 9'd214    ;
            5'd8    :   r_tdagc_frac[gidx] <= 9'd209    ;
            5'd9    :   r_tdagc_frac[gidx] <= 9'd205    ;
            5'd10   :   r_tdagc_frac[gidx] <= 9'd201    ;
            5'd11   :   r_tdagc_frac[gidx] <= 9'd197    ;
            5'd12   :   r_tdagc_frac[gidx] <= 9'd194    ;
            5'd13   :   r_tdagc_frac[gidx] <= 9'd190    ;
            5'd14   :   r_tdagc_frac[gidx] <= 9'd187    ;
            5'd15   :   r_tdagc_frac[gidx] <= 9'd184    ;
            5'd16   :   r_tdagc_frac[gidx] <= 9'd362    ;
            5'd17   :   r_tdagc_frac[gidx] <= 9'd351    ;
            5'd18   :   r_tdagc_frac[gidx] <= 9'd341    ;
            5'd19   :   r_tdagc_frac[gidx] <= 9'd332    ;
            5'd20   :   r_tdagc_frac[gidx] <= 9'd324    ;
            5'd21   :   r_tdagc_frac[gidx] <= 9'd316    ;
            5'd22   :   r_tdagc_frac[gidx] <= 9'd309    ;
            5'd23   :   r_tdagc_frac[gidx] <= 9'd302    ;
            5'd24   :   r_tdagc_frac[gidx] <= 9'd296    ;
            5'd25   :   r_tdagc_frac[gidx] <= 9'd290    ;
            5'd26   :   r_tdagc_frac[gidx] <= 9'd284    ;
            5'd27   :   r_tdagc_frac[gidx] <= 9'd279    ;
            5'd28   :   r_tdagc_frac[gidx] <= 9'd274    ;
            5'd29   :   r_tdagc_frac[gidx] <= 9'd269    ;
            5'd30   :   r_tdagc_frac[gidx] <= 9'd264    ;
            5'd31   :   r_tdagc_frac[gidx] <= 9'd260    ;
            default :   r_tdagc_frac[gidx] <= 9'd256    ;
        endcase
    end
end
end
endgenerate

// data buff control
reg  [MEM_ADDR   -1:0]   r_psym_waddr   ;
reg  [ 1         -1:0]   r_psym_tog     ;


always @(posedge i_clk) begin
    r_psym_waddr    <= r_psym_smp_cnt[10:0];
end

always@(posedge i_clk) begin
    if((i_frame_sync) & (i_nin_frame_idx == 0)) begin
    //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_psym_tog    <=  1'd0          ;
    end
    else if(r_psym_pow_done) begin
        r_psym_tog    <=  ~r_psym_tog   ;
    end
end

wire [ 1 -1:0]  w_read_tick;


ylib_pshift #(
    .BW_SHIFT   ($clog2(READ_DELAY)))
u01_ylib_pshift(
     .i_clk     (i_clk          )
    ,.i_shift   (READ_DELAY     )
    ,.i_in      (w_psym_pow_done)
    ,.o_out     (w_read_tick    )
);

reg [ 1     -1:0] r_rcnt_en      ;
reg [ 1     -1:0] r_ren          ;
reg [SMP_CNT-1:0] r_psym_raddr   ;
reg [ 8     -1:0] r_ant_vld      ;

always @(posedge i_clk) begin
    if(r_rcnt_en) begin
        if(r_ant_vld[NUM_ANT-1] & (r_psym_raddr == r_nfft-1)) begin
            r_rcnt_en       <= 1'b0;
            r_ren           <= 1'b0;
            r_ant_vld       <= 8'b0;
            r_psym_raddr    <= {SMP_CNT{1'b0}};
        end
        else if(r_psym_raddr == r_nfft-1) begin
            r_ren           <= 1'b0;
            r_psym_raddr    <= r_psym_raddr + 12'b1;
        end
        else if(r_psym_raddr == r_nfft + READ_OFFSET) begin
            r_ren           <=  1'b1;
            r_psym_raddr    <= {SMP_CNT{1'b0}};
            r_ant_vld       <= r_ant_vld << 1;
        end
        else begin
            r_psym_raddr    <= r_psym_raddr + 12'b1;
        end
    end      
    else if((i_frame_sync) & (i_nin_frame_idx == 0)) begin 
    //else if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin   
        r_rcnt_en       <=  1'b0;
        r_ren           <=  1'b0;
        r_psym_raddr    <= {SMP_CNT{1'b0}};
        r_ant_vld       <= 8'b0;
    end
    else if(w_read_tick) begin
        r_rcnt_en       <=  1'b1;
        r_ren           <=  1'b1;
        r_psym_raddr    <= {SMP_CNT{1'b0}};
        r_ant_vld       <=  8'b1;
    end
end


// mem io

reg     [0:0]          r_mem_even_en            [NUM_ANT-1:0]  ; 
reg     [0:0]          r_mem_even_wen           [NUM_ANT-1:0]  ; 
reg     [MEM_ADDR-1:0] r_mem_even_addr          [NUM_ANT-1:0]  ; 
wire    [2*DI_BW -1:0] w_mem_even_dout          [NUM_ANT-1:0]  ;


reg     [0:0]          r_mem_odd_en             [NUM_ANT-1:0]  ; 
reg     [0:0]          r_mem_odd_wen            [NUM_ANT-1:0]  ; 
reg     [MEM_ADDR-1:0] r_mem_odd_addr           [NUM_ANT-1:0]  ; 
wire    [2*DI_BW -1:0] w_mem_odd_dout           [NUM_ANT-1:0]  ;

reg     [8 -1:0]  r_mem_dout_en_pre0                      ; 
reg     [8 -1:0]  r_mem_dout_en_pre1                      ; 
reg     [8 -1:0]  r_mem_dout_en_pre2                      ; 
reg     [8 -1:0]  r_mem_dout_en                           ; 
reg     [2*DI_BW-1:0]  r_mem_dout               [8 -1:0]  ;

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin 

always@(posedge i_clk) begin
    if(r_psym_tog) begin
        r_mem_odd_en[gidx]      <= r_nin_en[gidx];
        r_mem_odd_wen[gidx]     <= r_nin_en[gidx];
        r_mem_even_en[gidx]     <= r_ren & r_ant_vld[gidx];
        r_mem_even_wen[gidx]    <= 1'b0;
        r_mem_even_addr[gidx]   <= {MEM_ADDR{r_ren}} & {MEM_ADDR{r_ant_vld[gidx]}} & r_psym_raddr[8:0];
        r_mem_odd_addr[gidx]    <= {MEM_ADDR{r_nin_en[gidx]}} & r_psym_waddr;
    end
    else begin
        r_mem_odd_wen[gidx]     <= 1'b0;
        r_mem_even_en[gidx]     <= r_nin_en[gidx];
        r_mem_even_wen[gidx]    <= r_nin_en[gidx];
        r_mem_odd_en[gidx]      <= r_ren & r_ant_vld[gidx];
        r_mem_odd_addr[gidx]    <= {MEM_ADDR{r_ren}} & {MEM_ADDR{r_ant_vld[gidx]}} & r_psym_raddr[8:0];
        r_mem_even_addr[gidx]   <= {MEM_ADDR{r_nin_en[gidx]}} & r_psym_waddr;
    end
end

ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   FFT_0512            )
    ,.VENDOR    (   VENDOR              )
)
u02_psym_buf_even
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_even_wen[gidx]   ) 
    ,.en        (r_mem_even_en[gidx]    ) 
    ,.addr      (r_mem_even_addr[gidx]  ) 
    ,.di        (rr_nin_iq[gidx]        ) 
    ,.dout      (w_mem_even_dout[gidx]  ) 
);

ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   FFT_0512            )
    ,.VENDOR    (   VENDOR              )
)
u03_psym_buf_odd
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_odd_wen[gidx]    ) 
    ,.en        (r_mem_odd_en[gidx]     ) 
    ,.addr      (r_mem_odd_addr[gidx]   ) 
    ,.di        (rr_nin_iq[gidx]        ) 
    ,.dout      (w_mem_odd_dout[gidx]   ) 
);

always @(posedge i_clk) begin
    if((i_frame_sync) & (i_nin_frame_idx == 0)) begin    
    //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_mem_dout[gidx]  <= {(2*DI_BW-1){1'b0}};
    end
    else begin
        r_mem_dout[gidx]  <= w_mem_even_dout[gidx] | w_mem_odd_dout[gidx];
    end
end

end
endgenerate

always @(posedge i_clk) begin
    if((i_frame_sync) & (i_nin_frame_idx == 0)) begin      
    //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin               
        r_mem_dout_en_pre0   <= 8'b0;
        r_mem_dout_en_pre1   <= 8'b0;
        r_mem_dout_en_pre2   <= 8'b0;
        r_mem_dout_en        <= 8'b0;
    end
    else begin
     r_mem_dout_en_pre0   <= {8{r_ren}} & r_ant_vld ;
     r_mem_dout_en_pre1   <= r_mem_dout_en_pre0     ;
     r_mem_dout_en_pre2   <= r_mem_dout_en_pre1     ;
     r_mem_dout_en        <= r_mem_dout_en_pre2     ;
    end
end


// data serialize & gain compensation
reg     [2*DI_BW-1:0]  rr_mem_dout; 

reg [9          -1:0]     r_tdagc_frac_s        ;
reg [8          -1:0]     r_mult_td_gain2_en    ;
reg [2*COMP_BW  -1:0]     r_mult_td_gain2       ;
reg [8          -1:0]     rr_mult_td_gain2_en   ;
reg [2*COMP_BW  -1:0]     rr_mult_td_gain2      ;
reg [5          -1:0]     r_td_gain1_shift      ;

wire                      w_shift_td_gain1_en   ;
wire [2*COMP_BW-1:0]      w_shift_td_gain1      ;

always @(posedge i_clk) begin
    case(r_mem_dout_en_pre2)
        8'b0000_0001 : begin rr_mem_dout <= r_mem_dout[0]       ; r_tdagc_frac_s  <= r_tdagc_frac[0]; end 
        8'b0000_0010 : begin rr_mem_dout <= r_mem_dout[1]       ; r_tdagc_frac_s  <= r_tdagc_frac[1]; end  
        8'b0000_0100 : begin rr_mem_dout <= r_mem_dout[2]       ; r_tdagc_frac_s  <= r_tdagc_frac[2]; end 
        8'b0000_1000 : begin rr_mem_dout <= r_mem_dout[3]       ; r_tdagc_frac_s  <= r_tdagc_frac[3]; end 
        8'b0001_0000 : begin rr_mem_dout <= r_mem_dout[4]       ; r_tdagc_frac_s  <= r_tdagc_frac[4]; end 
        8'b0010_0000 : begin rr_mem_dout <= r_mem_dout[5]       ; r_tdagc_frac_s  <= r_tdagc_frac[5]; end 
        8'b0100_0000 : begin rr_mem_dout <= r_mem_dout[6]       ; r_tdagc_frac_s  <= r_tdagc_frac[6]; end 
        8'b1000_0000 : begin rr_mem_dout <= r_mem_dout[7]       ; r_tdagc_frac_s  <= r_tdagc_frac[7]; end 
        default      : begin rr_mem_dout <= {(2*DI_BW){1'b0}}   ; r_tdagc_frac_s  <=       {9{1'b0}}; end 
    endcase
end

always@(posedge i_clk) begin 
    r_mult_td_gain2_en <= r_mem_dout_en ;
    if(|r_mem_dout_en) begin
        r_mult_td_gain2[(COMP_BW*2-1)-:COMP_BW] <= $signed({{{COMP_BW-DI_BW}{rr_mem_dout[DI_BW*2-1]}},rr_mem_dout[(DI_BW*2-1):DI_BW]}) * $signed({{{COMP_BW-9}{1'd0}},r_tdagc_frac_s}) ;
        r_mult_td_gain2[(COMP_BW*1-1)-:COMP_BW] <= $signed({{{COMP_BW-DI_BW}{rr_mem_dout[DI_BW*1-1]}},rr_mem_dout[(DI_BW*1-1):    0]}) * $signed({{{COMP_BW-9}{1'd0}},r_tdagc_frac_s}) ;
    end
end

always@(posedge i_clk) begin
    rr_mult_td_gain2_en <= r_mult_td_gain2_en;
    rr_mult_td_gain2    <= r_mult_td_gain2   ;
end

always @(posedge i_clk) begin
    case(r_mult_td_gain2_en)
        8'b0000_0001: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[0][3],r_td_gain1[0]}) ;
        8'b0000_0010: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[1][3],r_td_gain1[1]}) ;
        8'b0000_0100: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[2][3],r_td_gain1[2]}) ;
        8'b0000_1000: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[3][3],r_td_gain1[3]}) ;
        8'b0001_0000: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[4][3],r_td_gain1[4]}) ;
        8'b0010_0000: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[5][3],r_td_gain1[5]}) ;
        8'b0100_0000: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[6][3],r_td_gain1[6]}) ;
        8'b1000_0000: r_td_gain1_shift  <= 5'sd8 - $signed({r_td_gain1[7][3],r_td_gain1[7]}) ;
        default: r_td_gain1_shift  <=       {5{1'b0}};
    endcase
end

ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   5           )
 ,.IO_BW        (   COMP_BW     ))
u04_shiftd_rnd 
(
     .i_clk     (   i_clk                 )
    ,.i_in_en   (   |rr_mult_td_gain2_en  )
    ,.i_in      (   rr_mult_td_gain2      )
    ,.i_shiftd  (   r_td_gain1_shift      )
    ,.o_out_en  (   w_shift_td_gain1_en   )
    ,.o_out     (   w_shift_td_gain1      )
);


ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   COMP_BW     )
 ,.DO_BW        (   DO_BW       )
 ,.SAT_TYPE     ( "ASSYMETRIC"  ))
u05_sat
(
     .i_clk     (   i_clk                               )
    ,.i_in_en   (   w_shift_td_gain1_en                 )
    ,.i_in      (   w_shift_td_gain1                    )
    ,.o_out_en  (   o_nout_en                           )
    ,.o_out     (   o_nout_iq                           )
);


// gain

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : gain_and_report

always@(posedge i_clk) begin
    if(r_mult_td_gain2_en[gidx]) begin
        o_tagc_gain[((4*(gidx+1))-1)-:4]  <= r_td_gain1[gidx] ;
    end
end

always@(posedge i_clk) begin
    if(r_td_gain2_en[gidx]) begin
        o_tagc_lut_index[((5*(gidx+1))-1)-:5]  <= r_td_gain2[gidx] ;
    end
end

always@(posedge i_clk) begin
    if(r_psym_pow_avg_en[0]) begin
        o_rssi[((PW_BW*(gidx+1))-1)-:PW_BW]  <= r_psym_pow_avg[gidx] ;
    end
end

end
endgenerate

// sync shift

reg     [1  -1:0] r_shr_en  ;
reg     [18 -1:0] r_shr     ;

always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr_en <=  1'd1   ;
    end 
    else if(r_shr==SYNC_DELAY) begin
        r_shr_en <=  1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr <=  18'b0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  (r_shr==SYNC_DELAY) ? 18'b0 : r_shr+1'd1    ;
    end 
end

//assign 

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        o_frame_sync    <= 1'b0;
    end
    else begin
        o_frame_sync    <= r_shr_en&&(r_shr==SYNC_DELAY) ;
    end
end

endmodule
