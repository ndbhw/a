// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : nbiot_fft_demap
//  Author       : jyzoo.lee@samsung.com
//  Description  : prach fft deampper
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.5.20  | jyzoo.lee     | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.5.26  | jyzoo.lee     | applied double buffer 
//  ------------+---------------+-----------------------------------------------
//   2020.7.16  | taeyeong      | Modifiy for FSU20 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_fft_demap
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16           
   ,parameter  VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from oran
    ,   input   wire    [ 8         -1:0]           i_nin_frame_idx  
    ,   input   wire    [4          -1:0]           i_nbiot_nfft   
    ,   input   wire    [12         -1:0]           i_num_re

    //--- from rafe_td_agc_buf
    ,   input   wire    [1          -1:0]           i_frame_sync           
    ,   input   wire    [1          -1:0]           i_ro_sync    
    ,   input   wire    [1          -1:0]           i_nin_en           
    ,   input   wire    [2*DI_BW    -1:0]           i_nin_iq           

    //--- to rafe_gain_comp
    ,   output  wire    [1          -1:0]           o_frame_sync           
    ,   output  reg     [1          -1:0]           o_nout_en
    ,   output  reg     [2*DO_BW    -1:0]           o_nout_iq      
);

//Parameter nbiot fft demap local Logic

localparam      BW_FFT_OUT          =       28              ;   
localparam      FFT_0016            =       7'd16           ;
localparam      FFT_0064            =       7'd64           ;
localparam      DLY_NFFT_0016       =       22'd0016 + 22'd0016 + 22'd15 ;
localparam      DLY_NFFT_0064       =       22'd0064 + 22'd0064 + 22'd63 ;
// localparam      DLY_NFFT_0128       =       22'd0128 + 22'd0128 + 22'd127;
// localparam      DLY_NFFT_0256       =       22'd0256 + 22'd0256 + 22'd15 ;
// localparam      DLY_NFFT_0512       =       22'd0512 + 22'd0512 + 22'd15 ;
// localparam      DLY_NFFT_1024       =       22'd1024 + 22'd1024 + 22'd15 ;
// localparam      DLY_NFFT_2048       =       22'd2048 + 22'd2048 + 22'd15 ;
localparam      DLY_RST             =       3               ;
localparam      NUM_MAX_SC          =       12'd2048        ; 
localparam      EOP_DELAY           =       4'd10           ; 

//Logic Variable
integer i   ;

// Logic Variable
reg  [7         -1:0]   r_fft_pts       ;
reg  [4         -1:0]   r_fft_scale     ;
reg  [22        -1:0]   r_fft_dly       ;
reg  [1         -1:0]   r_rach_nfft     ;
reg  [1         -1:0]   r_mem_ren       ;
reg  [6         -1:0]   r_mem_raddr     ;
reg  [6         -1:0]   r_start_addr    ;
reg  [6         -1:0]   r_end_addr      ;


always @(posedge i_clk) begin
    if(i_frame_sync) begin      
        case(i_nbiot_nfft)
            4'b0100 : r_fft_dly    <= DLY_NFFT_0016;
            4'b0111 : r_fft_dly    <= DLY_NFFT_0016;
            4'b0110 : r_fft_dly    <= DLY_NFFT_0064;
            4'b1001 : r_fft_dly    <= DLY_NFFT_0064;
            default : r_fft_dly    <= DLY_NFFT_0064;
        endcase
    end
end

always @(posedge i_clk) begin
    if(i_ro_sync) begin        
        case(i_nbiot_nfft)
            4'b0100 : begin r_fft_pts    <= FFT_0016;  r_fft_scale <= 4'd2; r_rach_nfft <= 1'd1; r_start_addr <= 6'd2; end //FFT_0016 - i_num_re[11:1]; end
            4'b0111 : begin r_fft_pts    <= FFT_0016;  r_fft_scale <= 4'd2; r_rach_nfft <= 1'd1; r_start_addr <= 6'd2; end //FFT_0016 - i_num_re[11:1]; end
            4'b0110 : begin r_fft_pts    <= FFT_0064;  r_fft_scale <= 4'd3; r_rach_nfft <= 1'd0; r_start_addr <= 6'd8; end //FFT_0064 - i_num_re[11:1]; end            
            4'b1001 : begin r_fft_pts    <= FFT_0064;  r_fft_scale <= 4'd3; r_rach_nfft <= 1'd0; r_start_addr <= 6'd8; end //FFT_0064 - i_num_re[11:1]; end
            default : begin r_fft_pts    <= FFT_0064;  r_fft_scale <= 4'd3; r_rach_nfft <= 1'd0; r_start_addr <= 6'd8; end //FFT_0064 - i_num_re[11:1]; end 
        endcase
    end
end
    
// input reg
reg    [1      -1:0]               r_nin_en ;         
reg    [2*DI_BW-1:0]               r_nin_iq ;         

always@(posedge i_clk) begin
    r_nin_en <= i_nin_en            ;
    if(i_nin_en) begin
        r_nin_iq    <=  i_nin_iq    ;
    end
end

// FFT
wire [0:0]              w_fft_rstn    ;
wire [0:0]              w_fft_ready   ;
reg  [0:0]              r_fft_sop     ;
wire [0:0]              w_fft_eop     ;
wire [0:0]              w_fft_out_en  ;
wire [1:0]              w_fft_out_err ;
wire [0:0]              w_fft_out_sop ;
wire [0:0]              w_fft_out_eop ;
wire [BW_FFT_OUT-1:0]   w_fft_out_i   ;
wire [BW_FFT_OUT-1:0]   w_fft_out_q   ;
wire [ 7        -1:0]   w_fft_out_pts ;
reg  [0:0]  r_fft_rstn [DLY_RST-1:0]  ;

always @(posedge i_clk) begin
    r_fft_sop <= i_nin_en&~r_nin_en;
end

assign w_fft_eop = r_nin_en&~i_nin_en; 


always@(posedge i_clk) begin
//    r_fft_rstn[0] <=  ~(i_frame_sync|(|w_fft_out_err))  ;
    r_fft_rstn[0] <=  ~((i_frame_sync & ((i_nin_frame_idx==8'd0)))|(|w_fft_out_err))  ;
    for(i=1;i<DLY_RST;i=i+1) begin
        r_fft_rstn[i] <=  r_fft_rstn[i-1] ;
    end
end

assign w_fft_rstn = r_fft_rstn[DLY_RST-2]&r_fft_rstn[DLY_RST-1]  ;

// fft ip
ylib_vfft_wrapper #(
     .MAX_NFFT   (    64             )
    ,.VENDOR     (    VENDOR         )
    ,.ARC_MODE   (    "Burst"        ))
    //.VENDOR     (    VENDOR         ))
u01_fft
(
     .clk               (   i_clk                               ) // input  wire        
    ,.reset_n           (   w_fft_rstn                          ) // input  wire        
    ,.sink_valid        (   r_nin_en                            ) // input  wire        
    ,.sink_ready        (   w_ifft_ready                        ) // output wire        
    ,.sink_error        (   2'd0                                ) // input  wire [1:0]  
    ,.sink_sop          (   r_fft_sop                           ) // input  wire        
    ,.sink_eop          (   w_fft_eop                           ) // input  wire        
    ,.sink_real         (   r_nin_iq[31:16]                     ) // input  wire [15:0] 
    ,.sink_imag         (   r_nin_iq[15:0]                      ) // input  wire [15:0] 
    ,.fftpts_in         (   r_fft_pts                           ) // input  wire [11:0] 
    ,.inverse           (   1'd0                                ) // input  wire [0:0]  
    ,.source_valid      (   w_fft_out_en                        ) // output wire        
    ,.source_ready      (   1'd1                                ) // input  wire        
    ,.source_error      (   w_fft_out_err                       ) // output wire [1:0]  
    ,.source_sop        (   w_fft_out_sop                       ) // output wire        
    ,.source_eop        (   w_fft_out_eop                       ) // output wire        
    ,.source_real       (   w_fft_out_i                         ) // output wire [27:0] 
    ,.source_imag       (   w_fft_out_q                         ) // output wire [27:0] 
    ,.fftpts_out        (   w_fft_out_pts                       ) // output wire [11:0] 
);

// fft_out reg & scale R
reg  [ 1        -1:0]   r_fft_out_en    ;
reg  [28        -1:0]   r_fft_out_i     ; 
reg  [28        -1:0]   r_fft_out_q     ; 
reg  [ 1        -1:0]   r_fft_out_a_en  ;
reg  [36        -1:0]   r_fft_out_a_i   ; 
reg  [36        -1:0]   r_fft_out_a_q   ; 
reg  [ 1        -1:0]   rr_fft_out_a_en ;
reg  [36        -1:0]   rr_fft_out_a_i  ; 
reg  [36        -1:0]   rr_fft_out_a_q  ; 

wire [ 1        -1:0]   w_fft_out_a2_en ;
wire [36        -1:0]   w_fft_out_a2_i  ;
wire [36        -1:0]   w_fft_out_a2_q  ;
wire [ 1        -1:0]   w_fft_out_sat_en;
wire [2*DO_BW   -1:0]   w_fft_out_sat   ;
reg  [ 1        -1:0]   r_psym_tog      ;


always@(posedge i_clk) begin
    r_fft_out_en <= w_fft_out_en          ;
    if(w_fft_out_en) begin
        r_fft_out_i    <=  w_fft_out_i    ;
        r_fft_out_q    <=  w_fft_out_q    ;
    end
end

always@(posedge i_clk) begin
    r_fft_out_a_en      <= r_fft_out_en   ;
    if(r_fft_out_en) begin
        r_fft_out_a_i   <= ({{8{r_fft_out_i[27]}},r_fft_out_i}); //*RAFE_FFT_SCALE1 ; 
        r_fft_out_a_q   <= ({{8{r_fft_out_q[27]}},r_fft_out_q}); //*RAFE_FFT_SCALE1 ; 
    end
end

always@(posedge i_clk) begin
    rr_fft_out_a_en <= r_fft_out_a_en    ;
    if(r_fft_out_a_en) begin
        rr_fft_out_a_i  <= r_fft_out_a_i  ; 
        rr_fft_out_a_q  <= r_fft_out_a_q  ; 
    end
end


ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   4           )
 ,.IO_BW        (   36          ))
u01_shiftd_rnd 
(
     .i_clk     (   i_clk                           )
    ,.i_in_en   (   rr_fft_out_a_en                 )
    ,.i_in      (   {rr_fft_out_a_i,rr_fft_out_a_q} )
    ,.i_shiftd  (   r_fft_scale                     )
    ,.o_out_en  (   w_fft_out_a2_en                 )
    ,.o_out     (   {w_fft_out_a2_i,w_fft_out_a2_q} )
);

ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   36          )
 ,.DO_BW        (   DO_BW       ))
u02_sat
(
     .i_clk     (   i_clk                           )
    ,.i_in_en   (   w_fft_out_a2_en                 )
    ,.i_in      (   {w_fft_out_a2_i,w_fft_out_a2_q} )
    ,.o_out_en  (   w_fft_out_sat_en                )
    ,.o_out     (   w_fft_out_sat                   )
);

// fft_order_gen

wire w_fft_out_idx_en ;
wire [$clog2(NUM_MAX_SC-1)-1:0] w_fft_out_idx ;

ylib_xfft_order_gen #(.MAX_NFFT(NUM_MAX_SC))
u03_fft_order_gen
(
     .i_clk             (  i_clk                )
    ,.i_xfft_size       (  i_nbiot_nfft         )
    ,.i_xfft_out_en     (  rr_fft_out_a_en      )
    ,.o_xfft_out_en     (  w_fft_out_idx_en     )
    ,.o_xfft_out_idx    (  w_fft_out_idx        )
);

// toggle gen

wire    [1  -1:0]   w_fft_out_eop_dly;

ylib_pshift #(
    .BW_SHIFT   ($clog2(EOP_DELAY)))
u04_ylib_pshift(
     .i_clk     (i_clk              )
    ,.i_shift   (EOP_DELAY          )
    ,.i_in      (w_fft_out_eop      )
    ,.o_out     (w_fft_out_eop_dly  )
);

always@(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin      
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_psym_tog <=  1'd0    ;
    end
    else if(w_fft_out_eop_dly) begin
        r_psym_tog <=  ~r_psym_tog    ;
    end
end 

// white address

reg  [1     -1:0]   r_fft_out_idx_en ;
reg  [12    -1:0]   r_fft_out_idx   ;

always @(posedge i_clk) begin
    r_fft_out_idx_en    <= w_fft_out_idx_en;

    if(w_fft_out_idx_en) begin
        if(r_rach_nfft) begin
            r_fft_out_idx   <= {1'b0,w_fft_out_idx} + 12'd0008;        
        end
        else begin
            r_fft_out_idx   <= {1'b0,w_fft_out_idx} + 12'd0032;     
        end
    end
end


reg  [1     -1:0]   rr_fft_out_idx_en ;
reg  [6     -1:0]   rr_fft_out_idx    ;

always @(posedge i_clk) begin
    if(r_fft_out_idx_en) begin
        if(r_rach_nfft) begin
            rr_fft_out_idx_en   <= 1'b1                     ;   
            rr_fft_out_idx      <= {2'b0,r_fft_out_idx[3:0]};
        end
        else begin
            rr_fft_out_idx_en   <= 1'b1                     ;   
            rr_fft_out_idx      <=       r_fft_out_idx[5:0] ;
        end
    end
    else begin
            rr_fft_out_idx_en   <= 1'b0 ;   
            rr_fft_out_idx      <= 10'b0;
    end
end

// read address

always @(posedge i_clk) begin
    r_end_addr  <= r_start_addr + i_num_re -1 ;
end

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin        
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_mem_ren   <= 1'b0         ;
        r_mem_raddr <= 6'b0        ;
    end
    else if(w_fft_out_eop_dly) begin
        r_mem_ren   <= 1'b1         ;
        r_mem_raddr <= r_start_addr ;
    end
    else if(r_mem_ren) begin
        if(r_mem_raddr  == r_end_addr) begin
            r_mem_ren   <= 1'b0         ;
            r_mem_raddr <= 6'b0        ;
        end
        else begin
            r_mem_raddr <= r_mem_raddr + 6'd1;
        end
    end
end

// memory interface

reg     [1      -1:0]           r_mem_even_en            ; 
reg     [1      -1:0]           r_mem_even_wen           ; 
reg     [6      -1:0]           r_mem_even_addr          ; 
reg     [2*DI_BW-1:0]           r_mem_even_din           ;
wire    [2*DI_BW-1:0]           w_mem_even_dout          ;


reg     [1      -1:0]           r_mem_odd_en             ; 
reg     [1      -1:0]           r_mem_odd_wen            ; 
reg     [6      -1:0]           r_mem_odd_addr           ; 
reg     [2*DI_BW-1:0]           r_mem_odd_din            ;
wire    [2*DI_BW-1:0]           w_mem_odd_dout           ;

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin     
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_mem_even_en   <=  1'b0; 
        r_mem_even_wen  <=  1'b0; 
        r_mem_even_addr <=  6'b0; 
        r_mem_odd_en    <=  1'b0; 
        r_mem_odd_wen   <=  1'b0; 
        r_mem_odd_addr  <=  6'b0; 
    end
    else if(r_psym_tog) begin
        r_mem_even_en   <= r_mem_ren        ;
        r_mem_even_wen  <= 1'b0             ;
        r_mem_even_addr <= r_mem_raddr      ;

        r_mem_odd_en    <= rr_fft_out_idx_en;
        r_mem_odd_wen   <= rr_fft_out_idx_en; 
        r_mem_odd_addr  <= rr_fft_out_idx   ;
    end
    else begin
        r_mem_even_en   <= rr_fft_out_idx_en;
        r_mem_even_wen  <= rr_fft_out_idx_en;
        r_mem_even_addr <= rr_fft_out_idx   ;

        r_mem_odd_en    <= r_mem_ren        ; 
        r_mem_odd_wen   <= 1'b0             ; 
        r_mem_odd_addr  <= r_mem_raddr      ; 
    end
end

always @(posedge i_clk) begin
    if(w_fft_out_sat_en) begin
        r_mem_even_din  <= w_fft_out_sat    ;   
        r_mem_odd_din   <= w_fft_out_sat    ;   
    end
end
   
ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   64                  )
    ,.VENDOR    (   VENDOR              )
)
u05_psym_buf_even
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_even_wen         ) 
    ,.en        (r_mem_even_en          ) 
    ,.addr      (r_mem_even_addr        ) 
    ,.di        (r_mem_even_din         ) 
    ,.dout      (w_mem_even_dout        ) 
);

ylib_rams_sp_wf #(
     .WIDTH     (   2*DI_BW             )
    ,.DEPTH     (   64                  )
    ,.VENDOR    (   VENDOR              )
)
u06_psym_buf_odd
(
     .clk       (i_clk                  )     
    ,.we        (r_mem_odd_wen          ) 
    ,.en        (r_mem_odd_en           ) 
    ,.addr      (r_mem_odd_addr         ) 
    ,.di        (r_mem_odd_din          ) 
    ,.dout      (w_mem_odd_dout         ) 
);

// mem out

reg     [1      -1:0]           r_mem_dout_en_pre0  ; 
reg     [1      -1:0]           r_mem_dout_en_pre1  ; 
reg     [1      -1:0]           r_mem_dout_en       ; 
reg     [2*DI_BW-1:0]           r_mem_dout          ;

always @(posedge i_clk) begin
    r_mem_dout_en_pre0  <= r_mem_ren            ;
    r_mem_dout_en_pre1  <= r_mem_dout_en_pre0   ;
    o_nout_en           <= r_mem_dout_en_pre1   ;
end

always @(posedge i_clk) begin
    if(r_mem_dout_en_pre1) 
        o_nout_iq  <= w_mem_even_dout | w_mem_odd_dout;
    else 
        o_nout_iq  <= {(2*DI_BW){1'b0}};
end

// sync shift
reg     [18 -1:0] r_shr_val ;
reg     [1  -1:0] r_shr_en  ;
reg     [18 -1:0] r_shr     ;

always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr_en <=  1'd1   ;
    end 
    else if(r_shr==r_fft_dly-1) begin
        r_shr_en <=  1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(i_frame_sync) begin
        r_shr <=  18'b0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  (r_shr==r_fft_dly-1) ? 18'b0 : r_shr+1'd1    ;
    end 
end

assign o_frame_sync  =  r_shr_en&&(r_shr==r_fft_dly-1) ;

endmodule
