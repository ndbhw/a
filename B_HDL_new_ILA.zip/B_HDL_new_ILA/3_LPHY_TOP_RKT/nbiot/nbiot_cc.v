// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW RF4440  
//  Module       : nbiot_cc
//  Author       : ty321.kim@samsung.com
//  Description  : nbiot cc top for VzW FSU
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.09.15 | taeyeong      | IO Port Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_cc
#( 
    parameter  NUM_ANT              =   4  
   ,parameter  NUM_CHAIN            =   1
   ,parameter  MAX_OBW              =   100
   ,parameter  TOP_DIO_BW           =   16           
   ,parameter  DLY_REG_RD           =   7
   ,parameter  ADDR_OFFSET          =   16'h9000           
   ,parameter  VENDOR               =   "Xilinx"
   ,parameter  CPU_ADDR_BW          =   20
)
(
    //--- reset & clk
        input   wire                                        i_rst                
    ,   input   wire                                        i_clk                  

    //--- from cpu interface
    ,   input   wire    [CPU_ADDR_BW-1:0]                   i_cpu_addr
    ,   input   wire    [0:0]                               i_cpu_wren
    ,   input   wire    [31:0]                              i_cpu_wdata
    ,   input   wire    [0:0]                               i_cpu_rden
    ,   output  wire    [31:0]                              o_cpu_rdata
    ,   output  wire    [0:0]                               o_cpu_rd_valid

    //--- from qm_top
    ,   input   wire    [NUM_ANT* 4-1:0]                    i_nin_filter_idx     
    ,   input   wire    [NUM_ANT*16-1:0]                    i_nin_time_offset    
    ,   input   wire    [NUM_ANT* 8-1:0]                    i_nin_frame_struct      
    ,   input   wire    [NUM_ANT*16-1:0]                    i_nin_cp_length      
    ,   input   wire    [NUM_ANT* 4-1:0]                    i_nin_num_psymbol     
    ,   input   wire    [NUM_ANT*24-1:0]                    i_nin_freq_offset    
    ,   input   wire    [NUM_ANT* 8-1:0]                    i_nin_num_prbc
    ,   input   wire    [NUM_ANT* 3-1:0]                    i_nin_num_ro    
    ,   input   wire    [NUM_ANT*10-1:0]                    i_nin_start_prbc   
       
    //--- from nbiot_wrapper
    ,   input   wire    [27 -1:0]                           i_nin_freq_offset_ref
    ,   input   wire    [ 1 -1:0]                           i_nin_sel_input_path

    //--- from bb_if
    ,   input   wire    [0:0]                               i_nin_frame_sync
    ,   input   wire    [7:0]                               i_nin_frame_idx
    ,   input   wire    [NUM_ANT-1:0]                       i_nin_en           
    ,   input   wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          i_nin_iq           

    //--- to bb_top
    ,   output  wire    [0:0]                               o_nout_frame_sync   
    ,   output  wire    [7:0]                               o_nout_frame_idx
    ,   output  wire    [3:0]                               o_nout_subfrm_idx
    ,   output  wire    [5:0]                               o_nout_slot_idx
    ,   output  wire    [5:0]                               o_nout_symbol_idx
    ,   output  wire    [NUM_ANT-1:0]                       o_nout_en
    ,   output  wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          o_nout_iq      
    ,   output  wire    [NUM_ANT*16-1:0]                    o_nout_start_re_idx
    ,   output  wire    [NUM_ANT*1-1:0]                     o_nout_start_re  
    ,   output  wire    [NUM_ANT*1-1:0]                     o_nout_last_re     

    ,   output  reg     [4          -1:0]                   o_nout_nb_bw_idx    
);

localparam  PATH_RATIO      = 8'd128                  ;       // 245.76MHz/1.92MHz
localparam  CP_DLY          = 16'd17472               ;    // L 17664 , N 17536
localparam  CP_DLY_CE       = 16'd17472   -16'd1920   ;    // L 17664 , N 17536
localparam  SYNC_DLY        = 22'd2457600 -16'd1920 +1;

// signal

genvar  chidx;

reg     [ 1                         -1:0]       r_nin_sel_input_path        ;
reg     [27                         -1:0]       r_nin_freq_offset_ref       ;

wire    [ 1                         -1:0]       w_par_rafe_en               ;
wire    [ 1                         -1:0]       w_par_rafe_band_en          ;
wire    [ 1                         -1:0]       w_par_sw_reset              ;
wire    [17                         -1:0]       w_par_slot_offset           ;
wire    [ 1                         -1:0]       w_par_tagc_on               ;
wire    [ 5                         -1:0]       w_par_target_bo             ;
wire    [ 8                         -1:0]       w_par_mpframstruct          ;
wire    [ 1                         -1:0]       w_par_freq_7p5k             ;
wire    [16                         -1:0]       w_par_rach_freq_shift       ;  

wire    [ 1                         -1:0]       w_par_rach_freq_shift_sel   ;
wire    [ 1                         -1:0]       w_par_iq_swap               ;
wire    [ 1                         -1:0]       w_par_in_tp_gen             ; 
wire    [ 1                         -1:0]       w_par_out_tp_gen            ; 
wire    [ 1                         -1:0]       w_par_debug_mode            ; 
wire    [ 4                         -1:0]       w_par_debug_subfrm          ; 

wire    [ 4                         -1:0]       w_par_filter_idx            ;
wire    [16                         -1:0]       w_par_time_offset           ;
wire    [ 8                         -1:0]       w_par_frame_struct          ;
wire    [16                         -1:0]       w_par_cp_length             ;
wire    [ 4                         -1:0]       w_par_num_psymbol           ;
wire    [24                         -1:0]       w_par_freq_offset           ;
wire    [ 8                         -1:0]       w_par_num_prbc              ; 
wire    [ 3                         -1:0]       w_par_num_ro                ;
wire    [10                         -1:0]       w_par_start_prbc            ;

wire    [ 1                         -1:0]       w_par_freq_init_set         ; 
wire    [12                         -1:0]       w_par_freq_init_val         ; 

wire    [16                         -1:0]       w_par_adv_offset            ; 

wire    [ 4*4                       -1:0]       ww_nin_filter_idx           ;
wire    [16*4                       -1:0]       ww_nin_time_offset          ;
wire    [ 8*4                       -1:0]       ww_nin_frame_struct         ;
wire    [16*4                       -1:0]       ww_nin_cp_length            ;
wire    [ 4*4                       -1:0]       ww_nin_num_psymbol          ;
wire    [24*4                       -1:0]       ww_nin_freq_offset          ;
wire    [ 8*4                       -1:0]       ww_nin_num_prbc             ;
wire    [ 3*4                       -1:0]       ww_nin_num_ro               ;
wire    [10*4                       -1:0]       ww_nin_start_prbc           ;

wire    [ 4                         -1:0]       w_nin_filter_idx            ;
wire    [16                         -1:0]       w_nin_time_offset           ;
wire    [ 8                         -1:0]       w_nin_frame_struct          ;
wire    [16                         -1:0]       w_nin_cp_length             ;
wire    [ 4                         -1:0]       w_nin_num_psymbol           ;
wire    [24                         -1:0]       w_nin_freq_offset           ;
wire    [ 8                         -1:0]       w_nin_num_prbc              ;
wire    [ 3                         -1:0]       w_nin_num_ro                ;
wire    [32                         -1:0]       w_nin_rec_oran              ;
wire    [10                         -1:0]       w_nin_start_prbc            ;

wire    [ 4                         -1:0]       ww_nin_filter_idx_ce        ;
wire    [16                         -1:0]       ww_nin_time_offset_ce       ;
wire    [ 8                         -1:0]       ww_nin_frame_struct_ce      ;
wire    [16                         -1:0]       ww_nin_cp_length_ce         ;
wire    [ 4                         -1:0]       ww_nin_num_psymbol_ce       ;
wire    [24                         -1:0]       ww_nin_freq_offset_ce       ;
wire    [ 8                         -1:0]       ww_nin_num_prbc_ce          ;
wire    [ 3                         -1:0]       ww_nin_num_ro_ce            ;
wire    [32                         -1:0]       ww_nin_rec_oran_ce          ;
wire    [10                         -1:0]       ww_nin_start_prbc_ce        ;

wire    [ 4                         -1:0]       ww_nin_filter_idx_nce       ;
wire    [16                         -1:0]       ww_nin_time_offset_nce      ;
wire    [ 8                         -1:0]       ww_nin_frame_struct_nce     ;
wire    [16                         -1:0]       ww_nin_cp_length_nce        ;
wire    [ 4                         -1:0]       ww_nin_num_psymbol_nce      ;
wire    [24                         -1:0]       ww_nin_freq_offset_nce      ;
wire    [ 8                         -1:0]       ww_nin_num_prbc_nce         ;
wire    [ 3                         -1:0]       ww_nin_num_ro_nce           ;
wire    [32                         -1:0]       ww_nin_rec_oran_nce         ;
wire    [10                         -1:0]       ww_nin_start_prbc_nce       ;

reg     [NUM_ANT* 4                 -1:0]       r_dly_filter_idx            ;
reg     [NUM_ANT*16                 -1:0]       r_dly_time_offset           ;
reg     [NUM_ANT* 8                 -1:0]       r_dly_frame_struct          ;   
reg     [NUM_ANT*16                 -1:0]       r_dly_cp_length             ;
reg     [NUM_ANT* 4                 -1:0]       r_dly_num_psymbol           ; 
reg     [NUM_ANT*24                 -1:0]       r_dly_freq_offset           ;
reg     [NUM_ANT* 8                 -1:0]       r_dly_num_prbc              ;
reg     [NUM_ANT* 3                 -1:0]       r_dly_num_ro                ;
reg     [NUM_ANT*10                 -1:0]       r_dly_start_prbc            ;
reg     [1                          -1:0]       r_dly_ce                = 0 ;

reg     [NUM_ANT* 4                 -1:0]       rr_dly_filter_idx           ;
reg     [NUM_ANT*16                 -1:0]       rr_dly_time_offset          ;
reg     [NUM_ANT* 8                 -1:0]       rr_dly_frame_struct         ;   
reg     [NUM_ANT*16                 -1:0]       rr_dly_cp_length            ;
reg     [NUM_ANT* 4                 -1:0]       rr_dly_num_psymbol          ; 
reg     [NUM_ANT*24                 -1:0]       rr_dly_freq_offset          ;
reg     [NUM_ANT* 8                 -1:0]       rr_dly_num_prbc             ;
reg     [NUM_ANT* 3                 -1:0]       rr_dly_num_ro               ;
reg     [NUM_ANT*10                 -1:0]       rr_dly_start_prbc           ;
                                                                             
wire    [ 1                         -1:0]       w_dly_num_ro                ;
wire    [ 1                         -1:0]       w_dly_num_ro_nce            ;
wire    [ 1                         -1:0]       w_dly_num_ro_ce             ;
                                                                            
reg     [ 1                         -1:0]       r_cp_dly_en                 ; 
reg     [16                         -1:0]       r_cp_dly_cnt                ; 
                                                                            
wire    [ 1                         -1:0]       w_nbiot_den                 ;
wire    [ 4                         -1:0]       w_nb_scs_idx                ;
wire    [14                         -1:0]       w_time_offset               ;
wire    [12                         -1:0]       w_freq_shift                ;
wire    [ 4                         -1:0]       w_nb_fft_idx                ;
wire    [12                         -1:0]       w_num_re                    ;
wire    [ 4                         -1:0]       w_num_psym                  ;
wire    [ 1                         -1:0]       w_rec_trig                  ;
wire    [ 4                         -1:0]       w_subf_numb                 ;
                                                                            
wire    [ 1                         -1:0]       w_input_ctrl_sync_pre       ;
wire    [ 1                         -1:0]       w_input_ctrl_sync           ;
wire    [ 1                         -1:0]       w_input_ctrl_en_pre         ;        
wire    [NUM_ANT                    -1:0]       w_input_ctrl_en             ;        
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_input_ctrl_iq             ;   
                                                                            
wire    [ 1                         -1:0]       w_input_ctrl_sync_pre_ce    ;
wire    [ 1                         -1:0]       w_input_ctrl_sync_ce        ;
wire    [ 1                         -1:0]       w_input_ctrl_en_pre_ce      ;        
wire    [NUM_ANT                    -1:0]       w_input_ctrl_en_ce          ;        
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_input_ctrl_iq_ce          ;   
                                                                             
// ce signal                                                                 
wire    [ 1                         -1:0]       w_nbiot_den_ce              ;
wire    [ 4                         -1:0]       w_nb_scs_idx_ce             ;
wire    [14                         -1:0]       w_time_offset_ce            ;
wire    [12                         -1:0]       w_freq_shift_ce             ;
wire    [ 4                         -1:0]       w_nb_fft_idx_ce             ;
wire    [12                         -1:0]       w_num_re_ce                 ;
wire    [ 4                         -1:0]       w_num_psym_ce               ;
wire    [ 1                         -1:0]       w_rec_trig_ce               ;
wire    [ 4                         -1:0]       w_subf_numb_ce              ;
                                                                            
wire    [ 4                         -1:0]       w_nin_filter_idx_ce         ;
wire    [16                         -1:0]       w_nin_time_offset_ce        ;
wire    [ 8                         -1:0]       w_nin_frame_struct_ce       ;
wire    [16                         -1:0]       w_nin_cp_length_ce          ;
wire    [ 4                         -1:0]       w_nin_num_psymbol_ce        ;
wire    [24                         -1:0]       w_nin_freq_offset_ce        ;
wire    [ 3                         -1:0]       w_nin_num_ro_ce             ;
wire    [ 8                         -1:0]       w_nin_num_prbc_ce           ;
wire    [32                         -1:0]       w_nin_rec_oran_ce           ;



wire                                            w_cmplx_exp_vld             ;
wire    [16                         -1:0]       w_p_cos                     ;
wire    [16                         -1:0]       w_n_sin                     ;
                                                                            
wire    [ 1          *NUM_CHAIN     -1:0]       w_fshift_sync               ;
wire    [1           *NUM_CHAIN     -1:0]       w_fshift_ro_sync            ;
wire    [NUM_ANT                    -1:0]       w_fshift_vld                ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_fshift_iq                 ;
                                                                            
wire    [1           *NUM_CHAIN     -1:0]       w_cic_filt_sync             ;             
wire    [NUM_ANT                    -1:0]       w_cic_filt_en               ;           
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cic_filt_iq               ;           
                                                                            
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_frame_sync_nce       ;
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_ro_sync_nce          ;
wire    [NUM_ANT                    -1:0]       w_cprm_nout_en_nce          ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cprm_nout_iq_nce          ;
wire    [8           *NUM_CHAIN     -1:0]       w_start_frm_nce             ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sub_nce             ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sym_nce             ;
                                                                            
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_frame_sync_ce        ;
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_ro_sync_ce           ;
wire    [NUM_ANT                    -1:0]       w_cprm_nout_en_ce           ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cprm_nout_iq_ce           ;
wire    [8           *NUM_CHAIN     -1:0]       w_start_frm_ce              ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sub_ce              ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sym_ce              ;
                                                                            
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_frame_sync           ;
wire    [1           *NUM_CHAIN     -1:0]       w_cprm_ro_sync              ;
wire    [NUM_ANT                    -1:0]       w_cprm_nout_en              ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_cprm_nout_iq              ;
wire    [8           *NUM_CHAIN     -1:0]       w_start_frm                 ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sub                 ;
wire    [4           *NUM_CHAIN     -1:0]       w_start_sym                 ;
                                                                            
wire    [ 1          *NUM_CHAIN     -1:0]       w_psym_sync                 ;      
wire    [ 1          *NUM_CHAIN     -1:0]       w_nout_en                   ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_nout_iq                   ;
wire    [NUM_ANT*4                  -1:0]       w_tagc_gain                 ;
wire    [NUM_ANT*5                  -1:0]       w_tagc_lut_index            ;
wire    [8*31                       -1:0]       w_rssi                      ;
                                                                             
                                                                             
wire    [ 1          *NUM_CHAIN     -1:0]       w_fft_demap_sync            ;   
wire    [ 1          *NUM_CHAIN     -1:0]       w_fft_demap_nout_en         ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_fft_demap_nout_iq         ;
                                                                            
wire    [ 1          *NUM_CHAIN     -1:0]       w_gain_comp_sync            ;   
wire    [ 1          *NUM_CHAIN     -1:0]       w_gain_comp_nout_en         ;
wire    [2*TOP_DIO_BW*NUM_CHAIN     -1:0]       w_gain_comp_nout_iq         ;




// input reg
wire    [0:0]                               w_nin_frame_sync    ; 
wire    [0:0]                               w_nin_frame_sync_ce ; 
wire    [0:0]                               w_nin_frame_sync_nce; 
wire    [7:0]                               w_nin_frame_idx     ;
wire    [NUM_ANT-1:0]                       w_nin_en            ;
wire    [2*NUM_ANT*TOP_DIO_BW-1:0]          w_nin_iq            ;
reg     [7:0]                               r_nin_frame_idx     ;

ylib_reg #(.WIDTH(2*NUM_ANT*TOP_DIO_BW + NUM_ANT + 8 + 1) ,.DEPTH(1)) u99_input_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ({i_nin_frame_sync    , i_nin_frame_idx, i_nin_en, i_nin_iq})
   ,.o_out      ({w_nin_frame_sync_nce, w_nin_frame_idx, w_nin_en, w_nin_iq})
);

ylib_pshift #( 
    .BW_SHIFT           (22))
u99_fsync_shift
(
     .i_clk             (   i_clk               )
    ,.i_shift           (   SYNC_DLY            )
    ,.i_in              (   i_nin_frame_sync    )
    ,.o_out             (   w_nin_frame_sync_ce )
);

// assign w_nin_frame_sync = (r_dly_ce)? w_nin_frame_sync_ce : w_nin_frame_sync_nce;

always @(posedge i_clk) begin
// sim    
//    if(i_nin_frame_sync) begin  r_nin_frame_idx <= i_nin_frame_idx;    end
// real    
    if(w_nin_frame_sync_ce) begin  r_nin_frame_idx <= i_nin_frame_idx;    end
end

always @(posedge i_clk) r_nin_sel_input_path   <=  i_nin_sel_input_path  ;
always @(posedge i_clk) r_nin_freq_offset_ref  <=  i_nin_freq_offset_ref ;

assign  ww_nin_filter_idx   = (NUM_ANT == 4) ? rr_dly_filter_idx  : {{(4-NUM_ANT){ 4'b0}},rr_dly_filter_idx   };   
assign  ww_nin_time_offset  = (NUM_ANT == 4) ? rr_dly_time_offset : {{(4-NUM_ANT){16'b0}},rr_dly_time_offset  };   
assign  ww_nin_frame_struct = (NUM_ANT == 4) ? rr_dly_frame_struct: {{(4-NUM_ANT){ 8'b0}},rr_dly_frame_struct };   
assign  ww_nin_cp_length    = (NUM_ANT == 4) ? rr_dly_cp_length   : {{(4-NUM_ANT){16'b0}},rr_dly_cp_length    };   
assign  ww_nin_num_psymbol  = (NUM_ANT == 4) ? rr_dly_num_psymbol : {{(4-NUM_ANT){ 4'b0}},rr_dly_num_psymbol  };    
assign  ww_nin_freq_offset  = (NUM_ANT == 4) ? rr_dly_freq_offset : {{(4-NUM_ANT){24'b0}},rr_dly_freq_offset  };   
assign  ww_nin_num_prbc     = (NUM_ANT == 4) ? rr_dly_num_prbc    : {{(4-NUM_ANT){ 8'b0}},rr_dly_num_prbc     };   
assign  ww_nin_num_ro       = (NUM_ANT == 4) ? rr_dly_num_ro      : {{(4-NUM_ANT){ 3'b0}},rr_dly_num_ro       };   
assign  ww_nin_start_prbc   = (NUM_ANT == 4) ? rr_dly_start_prbc  : {{(4-NUM_ANT){10'b0}},rr_dly_start_prbc   };   


// c-plane delay

always @(posedge i_clk) begin
    if(|i_nin_num_ro) begin
        r_dly_filter_idx    <=       i_nin_filter_idx    ;
        r_dly_time_offset   <=       i_nin_time_offset   ;
        r_dly_frame_struct  <=       i_nin_frame_struct  ;   
        r_dly_cp_length     <=       i_nin_cp_length     ;
        r_dly_num_psymbol   <=       i_nin_num_psymbol   ; 
        r_dly_freq_offset   <=       i_nin_freq_offset   ;
        r_dly_num_prbc      <=       i_nin_num_prbc      ;  
        r_dly_num_ro        <=       i_nin_num_ro        ;   
        r_dly_start_prbc    <=       i_nin_start_prbc    ;     
        r_dly_ce            <=       (i_nin_num_psymbol[1]|i_nin_num_psymbol[3]|i_nin_num_psymbol[9]|i_nin_num_psymbol[11]);
    end
end

ylib_pshift #( 
    .BW_SHIFT           (16))
u99_fsync_shift_nce
(
     .i_clk             (   i_clk           )
    ,.i_shift           (   CP_DLY          )
    ,.i_in              (   |i_nin_num_ro   )
    ,.o_out             (   w_dly_num_ro_nce)
);

ylib_pshift #( 
    .BW_SHIFT           (16))
u99_fsync_shift_ce
(
     .i_clk             (   i_clk           )
    ,.i_shift           (   CP_DLY_CE       )
    ,.i_in              (   |i_nin_num_ro   )
    ,.o_out             (   w_dly_num_ro_ce )
);

assign w_dly_num_ro = (r_dly_ce)? w_dly_num_ro_ce : w_dly_num_ro_nce;

always @(posedge i_clk) begin
    if(w_dly_num_ro) begin
        r_cp_dly_en     <= 1'b1    ; 
        r_cp_dly_cnt    <=16'b0    ; 
    end
    else if(r_cp_dly_cnt == 16'd17662) begin
        r_cp_dly_en     <= 1'b0    ; 
        r_cp_dly_cnt    <=16'b0    ; 
    end
    else if(r_cp_dly_en) begin
        r_cp_dly_cnt    <= r_cp_dly_cnt + 16'd1    ; 
    end
end

always @(posedge i_clk) begin
    if(w_dly_num_ro) begin
        rr_dly_filter_idx    <=       r_dly_filter_idx    ;
        rr_dly_time_offset   <=       r_dly_time_offset   ;
        rr_dly_frame_struct  <=       r_dly_frame_struct  ;   
        rr_dly_cp_length     <=       r_dly_cp_length     ;
        rr_dly_num_psymbol   <=       r_dly_num_psymbol   ; 
        rr_dly_freq_offset   <=       r_dly_freq_offset   ;
        rr_dly_num_prbc      <=       r_dly_num_prbc      ;  
        rr_dly_start_prbc    <=       r_dly_start_prbc    ;  
    end
    else if(r_cp_dly_en == 0) begin
        rr_dly_filter_idx    <=       0                   ;
        rr_dly_time_offset   <=       0                   ;
        rr_dly_frame_struct  <=       0                   ;   
        rr_dly_cp_length     <=       0                   ;
        rr_dly_num_psymbol   <=       0                   ; 
        rr_dly_freq_offset   <=       0                   ;
        rr_dly_num_prbc      <=       0                   ; 
        rr_dly_start_prbc    <=       0                   ;  
    end
end

always @(posedge i_clk) begin
    rr_dly_num_ro   <= {NUM_ANT* 3{w_dly_num_ro}};
end


// ctrl module
nbiot_cpu_param_if #(
    .ADDR_OFFSET    (   ADDR_OFFSET     )       // CPU IF Address Offset    
   ,.DLY_REG_RD     (   DLY_REG_RD      )       // READ Latency
   ,.AW             (   CPU_ADDR_BW     )       // CPU IF Address Bit Width
   ,.DW             (   32              ))      // CPU IF Data Bit Width 
u00_nbiot_cpu_param_if(
    //--- reset & clk
     .i_clk                        ( i_clk                      )
    //,.i_rst                        ( i_rst                      )                                          
    //--- cpu interface
    ,.i_cpu_addr                   ( i_cpu_addr                 )
    ,.i_cpu_wren                   ( i_cpu_wren                 )
    ,.i_cpu_wdata                  ( i_cpu_wdata                )
    ,.i_cpu_rden                   ( i_cpu_rden                 )
    ,.o_cpu_rdata                  ( o_cpu_rdata                )
    ,.o_cpu_rd_valid               ( o_cpu_rd_valid             )

    ,.o_par_freq_shift_sel         ( w_par_rach_freq_shift_sel  ) 
    ,.o_par_iq_swap                ( w_par_iq_swap              ) 
    ,.o_par_in_tp_gen              ( w_par_in_tp_gen            ) 
    ,.o_par_out_tp_gen             ( w_par_out_tp_gen           ) 
    ,.o_par_debug_mode             ( w_par_debug_mode           ) 
    ,.o_par_debug_subfrm           ( w_par_debug_subfrm         )

    ,.o_par_filter_idx             ( w_par_filter_idx           ) 
    ,.o_par_time_offset            ( w_par_time_offset          ) 
    ,.o_par_frame_struct           ( w_par_frame_struct         )    
    ,.o_par_cp_length              ( w_par_cp_length            ) 
    ,.o_par_num_psymbol            ( w_par_num_psymbol          )  
    ,.o_par_freq_offset            ( w_par_freq_offset          ) 
    ,.o_par_num_ro                 ( w_par_num_ro               )  
    ,.o_par_num_prbc               ( w_par_num_prbc             )  

    ,.o_par_freq_init_set          ( w_par_freq_init_set        ) 
    ,.o_par_freq_init_val          ( w_par_freq_init_val        ) 

    ,.o_par_adv_offset             ( w_par_adv_offset           ) 
    
    //--- Read oRAN parameter         
    ,.i_rin_filter_idx             ( w_nin_filter_idx           ) 
    ,.i_rin_time_offset            ( w_nin_time_offset          ) 
    ,.i_rin_frame_struct           ( w_nin_frame_struct         )    
    ,.i_rin_cp_length              ( w_nin_cp_length            ) 
    ,.i_rin_num_psymbol            ( w_nin_num_psymbol          )  
    ,.i_rin_freq_offset            ( w_nin_freq_offset          ) 
    ,.i_rin_num_ro                 ( w_nin_num_ro               )
    ,.i_rin_num_prbc               ( w_nin_num_prbc             )
    ,.i_rin_start_prbc             ( w_nin_start_prbc           )  
    ,.i_rin_rec_oran               ( w_nin_rec_oran             ) 
    
    //--- nbiot_wrapper
    ,.i_rin_freq_offset_ref        ( r_nin_freq_offset_ref      )  
    ,.i_rin_sel_input_path         ( r_nin_sel_input_path       )
                                                                
    //--- Parsed parameter 
    ,.i_nin_nb_scs_idx             ( w_nb_scs_idx               )
    ,.i_nin_time_offset            ( w_time_offset              )
    ,.i_nin_freq_shift             ( w_freq_shift               )
    ,.i_nin_nb_fft_idx             ( w_nb_fft_idx               )
    ,.i_nin_num_re                 ( w_num_re                   )
    ,.i_nin_num_psym               ( w_num_psym                 )
                                    
    //--- Report Register
    ,.i_rpt_rssi_ro0               ({1'b0,w_rssi[31*1 -1: 31*0]})
    ,.i_rpt_rssi_ro1               ({1'b0,w_rssi[31*2 -1: 31*1]})
    ,.i_rpt_rssi_ro2               ({1'b0,w_rssi[31*3 -1: 31*2]})
    ,.i_rpt_rssi_ro3               ({1'b0,w_rssi[31*4 -1: 31*3]})
    ,.i_rpt_rssi_ro4               ({1'b0,w_rssi[31*5 -1: 31*4]})
    ,.i_rpt_rssi_ro5               ({1'b0,w_rssi[31*6 -1: 31*5]})
    ,.i_rpt_rssi_ro6               ({1'b0,w_rssi[31*7 -1: 31*6]})
    ,.i_rpt_rssi_ro7               ({1'b0,w_rssi[31*8 -1: 31*7]})
    
    ,.i_nout_frame_idx             (o_nout_frame_idx            )
    ,.i_nout_subframe_idx          (o_nout_subfrm_idx           )
    ,.i_nout_slot_idx              (o_nout_slot_idx             )
    ,.i_nout_symbol_idx            (o_nout_symbol_idx           )
    ,.i_nout_en                    (o_nout_en                   )
    ,.i_nout_last_re               (o_nout_last_re              )
);
  



assign  w_nin_filter_idx   = (r_dly_ce) ? ww_nin_filter_idx_ce   : ww_nin_filter_idx_nce   ;  
assign  w_nin_time_offset  = (r_dly_ce) ? ww_nin_time_offset_ce  : ww_nin_time_offset_nce  ;  
assign  w_nin_frame_struct = (r_dly_ce) ? ww_nin_frame_struct_ce : ww_nin_frame_struct_nce ;  
assign  w_nin_cp_length    = (r_dly_ce) ? ww_nin_cp_length_ce    : ww_nin_cp_length_nce    ;  
assign  w_nin_num_psymbol  = (r_dly_ce) ? ww_nin_num_psymbol_ce  : ww_nin_num_psymbol_nce  ;  
assign  w_nin_freq_offset  = (r_dly_ce) ? ww_nin_freq_offset_ce  : ww_nin_freq_offset_nce  ;  
assign  w_nin_num_prbc     = (r_dly_ce) ? ww_nin_num_prbc_ce     : ww_nin_num_prbc_nce     ;  
assign  w_nin_num_ro       = (r_dly_ce) ? ww_nin_num_ro_ce       : ww_nin_num_ro_nce       ;  
assign  w_nin_start_prbc   = (r_dly_ce) ? ww_nin_start_prbc_ce   : ww_nin_start_prbc_nce   ;  
assign  w_nin_rec_oran     = (r_dly_ce) ? ww_nin_rec_oran_ce     : ww_nin_rec_oran_nce     ;  


// oran if

nbiot_oran_param_if #(
         .NUM_ANT   ( 4   ))
u01_nbiot_oran_param_if_nce(
    //--- reset & clk
     .i_clk                         ( i_clk                       )        
    //,.i_nin_frame_sync              ( w_nin_frame_sync            )  
    ,.i_nin_frame_sync              ( w_nin_frame_sync_nce        )  

    //--- from cpu_if
    ,.i_freq_shift_7p5k             ( w_par_freq_7p5k             )   
    ,.i_rach_freq_shift             ( w_par_rach_freq_shift       )   
    ,.i_rach_freq_shift_sel         ( w_par_rach_freq_shift_sel   )   
     
    ,.i_adv_offset                  ( w_par_adv_offset            )  

    ,.i_par_debug_mode              ( w_par_debug_mode            )    // enable
    ,.i_par_filter_idx              ( w_par_filter_idx            )    // 1, 3                                    oRAN                                 
    ,.i_par_time_offset             ( w_par_time_offset           )    // 0 ~ 30720 : 1ms                         oRAN                                 
    ,.i_par_frame_struct            ( w_par_frame_struct          )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,.i_par_cp_length               ( w_par_cp_length             )    //                                         oRAN                                 
    ,.i_par_num_psymbol             ( w_par_num_psymbol           )    //                                         oRAN                                  
    ,.i_par_freq_offset             ( w_par_freq_offset           )    //                                         oRAN                                 
    ,.i_par_num_ro                  ( w_par_num_ro                )    // nuber of c-plane type3
    ,.i_par_num_prbc                ( w_par_num_prbc              )

    //--- from qm_top

    // real
    ,.i_nin_en                      ( w_nin_en [0]                )    // enable
    ,.i_nin_filter_idx              ( ww_nin_filter_idx           )    // 1, 3                                    oRAN                                 
    ,.i_nin_time_offset             ( ww_nin_time_offset          )    // 0 ~ 30720 : 1ms                         oRAN                                 
    ,.i_nin_frame_struct            ( ww_nin_frame_struct         )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,.i_nin_cp_length               ( ww_nin_cp_length            )    //                                         oRAN                                 
    ,.i_nin_num_psymbol             ( ww_nin_num_psymbol          )    //                                         oRAN                                  
    ,.i_nin_freq_offset             ( ww_nin_freq_offset          )    //                                         oRAN                                 
    ,.i_nin_num_prbc                ( ww_nin_num_prbc             )                                                           
    ,.i_nin_start_prbc              ( ww_nin_start_prbc           )
    ,.i_nin_trig                    ( ww_nin_num_ro               )    // i_nin_num_ro LSB 1 bit                

    // sim
    //,.i_nin_en                      ( w_nin_en         [ 1 -1:0] )    // enable
    //,.i_nin_filter_idx              ( i_nin_filter_idx           )    // 1, 3                                    oRAN                                 
    //,.i_nin_time_offset             ( i_nin_time_offset          )    // 0 ~ 30720 : 1ms                         oRAN                                 
    //,.i_nin_frame_struct            ( i_nin_frame_struct         )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    //,.i_nin_cp_length               ( i_nin_cp_length            )    //                                         oRAN                                 
    //,.i_nin_num_psymbol             ( i_nin_num_psymbol          )    //                                         oRAN                                  
    //,.i_nin_freq_offset             ( i_nin_freq_offset          )    //                                         oRAN                                 
    //,.i_nin_num_prbc                ( i_nin_num_prbc             )
    //,.i_nin_trig                    ( i_nin_num_ro               )    // i_nin_num_ro LSB 1 bit     

    //--- to NB-IoT core
    ,.o_nbiot_en                    ( w_nbiot_den                 )
    ,.o_nb_scs_idx                  ( w_nb_scs_idx                ) 
    ,.o_time_offset                 ( w_time_offset               ) 
    ,.o_freq_shift                  ( w_freq_shift                ) 
    ,.o_nb_fft_idx                  ( w_nb_fft_idx                ) 
    ,.o_num_re                      ( w_num_re                    ) 
    ,.o_num_psym                    ( w_num_psym                  ) 
    ,.o_rec_trig                    ( w_rec_trig                  )
    ,.o_subf_numb                   ( w_subf_numb                 )

    //--- Read oRAN parameter
    ,.o_nin_filter_idx              ( ww_nin_filter_idx_nce       ) 
    ,.o_nin_time_offset             ( ww_nin_time_offset_nce      ) 
    ,.o_nin_frame_struct            ( ww_nin_frame_struct_nce     )    
    ,.o_nin_cp_length               ( ww_nin_cp_length_nce        ) 
    ,.o_nin_num_psymbol             ( ww_nin_num_psymbol_nce      )  
    ,.o_nin_freq_offset             ( ww_nin_freq_offset_nce      ) 
    ,.o_nin_num_prbc                ( ww_nin_num_prbc_nce         )
    ,.o_nin_start_prbc              ( ww_nin_start_prbc_nce       )
    ,.o_nin_rec_oran                ( ww_nin_rec_oran_nce         )
);


nbiot_oran_param_if #(
         .NUM_ANT   ( 4   ))
u01_nbiot_oran_param_if_ce(
    //--- reset & clk
     .i_clk                         ( i_clk                       )        
    //,.i_nin_frame_sync              ( w_nin_frame_sync            )  
    ,.i_nin_frame_sync              ( w_nin_frame_sync_ce         )  

    //--- from cpu_if
    ,.i_freq_shift_7p5k             ( w_par_freq_7p5k             )   
    ,.i_rach_freq_shift             ( w_par_rach_freq_shift       )   
    ,.i_rach_freq_shift_sel         ( w_par_rach_freq_shift_sel   )  
     
    ,.i_adv_offset                  ( w_par_adv_offset            )   

    ,.i_par_debug_mode              ( w_par_debug_mode            )    // enable
    ,.i_par_filter_idx              ( w_par_filter_idx            )    // 1, 3                                    oRAN                                 
    ,.i_par_time_offset             ( w_par_time_offset           )    // 0 ~ 30720 : 1ms                         oRAN                                 
    ,.i_par_frame_struct            ( w_par_frame_struct          )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,.i_par_cp_length               ( w_par_cp_length             )    //                                         oRAN                                 
    ,.i_par_num_psymbol             ( w_par_num_psymbol           )    //                                         oRAN                                  
    ,.i_par_freq_offset             ( w_par_freq_offset           )    //                                         oRAN                                 
    ,.i_par_num_ro                  ( w_par_num_ro                )    // nuber of c-plane type3
    ,.i_par_num_prbc                ( w_par_num_prbc              )

    //--- from qm_top

    // real
    ,.i_nin_en                      ( w_nin_en [0]                )    // enable
    ,.i_nin_filter_idx              ( ww_nin_filter_idx           )    // 1, 3                                    oRAN                                 
    ,.i_nin_time_offset             ( ww_nin_time_offset          )    // 0 ~ 30720 : 1ms                         oRAN                                 
    ,.i_nin_frame_struct            ( ww_nin_frame_struct         )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    ,.i_nin_cp_length               ( ww_nin_cp_length            )    //                                         oRAN                                 
    ,.i_nin_num_psymbol             ( ww_nin_num_psymbol          )    //                                         oRAN                                  
    ,.i_nin_freq_offset             ( ww_nin_freq_offset          )    //                                         oRAN                                 
    ,.i_nin_num_prbc                ( ww_nin_num_prbc             )                                                         
    ,.i_nin_start_prbc              ( ww_nin_start_prbc           )
    ,.i_nin_trig                    ( ww_nin_num_ro               )    // i_nin_num_ro LSB 1 bit                

    // sim
    // ,.i_nin_en                      ( w_nin_en         [ 1  -1:0] )    // enable
    // ,.i_nin_filter_idx              ( i_nin_filter_idx            )    // 1, 3                                    oRAN                                 
    // ,.i_nin_time_offset             ( i_nin_time_offset           )    // 0 ~ 30720 : 1ms                         oRAN                                 
    // ,.i_nin_frame_struct            ( i_nin_frame_struct          )    // [3:0]:PRACH SCS,[7:4]:PRACH FFT Size    oRAN                                    
    // ,.i_nin_cp_length               ( i_nin_cp_length             )    //                                         oRAN                                 
    // ,.i_nin_num_psymbol             ( i_nin_num_psymbol           )    //                                         oRAN                                  
    // ,.i_nin_freq_offset             ( i_nin_freq_offset           )    //                                         oRAN                                 
    // ,.i_nin_num_prbc                ( i_nin_num_prbc              )
    // ,.i_nin_trig                    ( i_nin_num_ro                )    // i_nin_num_ro LSB 1 bit     

    //--- to NB-IoT core
    ,.o_nbiot_en                    ( w_nbiot_den_ce              )
    ,.o_nb_scs_idx                  ( w_nb_scs_idx_ce             ) 
    ,.o_time_offset                 ( w_time_offset_ce            ) 
    ,.o_freq_shift                  ( w_freq_shift_ce             ) 
    ,.o_nb_fft_idx                  ( w_nb_fft_idx_ce             ) 
    ,.o_num_re                      ( w_num_re_ce                 ) 
    ,.o_num_psym                    ( w_num_psym_ce               ) 
    ,.o_rec_trig                    ( w_rec_trig_ce               )
    ,.o_subf_numb                   ( w_subf_numb_ce              )

    //--- Read oRAN parameter
    ,.o_nin_filter_idx              ( ww_nin_filter_idx_ce         ) 
    ,.o_nin_time_offset             ( ww_nin_time_offset_ce        ) 
    ,.o_nin_frame_struct            ( ww_nin_frame_struct_ce       )    
    ,.o_nin_cp_length               ( ww_nin_cp_length_ce          ) 
    ,.o_nin_num_psymbol             ( ww_nin_num_psymbol_ce        )  
    ,.o_nin_freq_offset             ( ww_nin_freq_offset_ce        ) 
    ,.o_nin_num_prbc                ( ww_nin_num_prbc_ce           )
    ,.o_nin_start_prbc              ( ww_nin_start_prbc_ce         )
    ,.o_nin_rec_oran                ( ww_nin_rec_oran_ce           )
);

// input ctrl
rafe_input_ctrl #(
     .NUM_ANT   ( NUM_ANT   )
    ,.NUM_CHAIN ( NUM_CHAIN )
    ,.DI_BW     ( TOP_DIO_BW)
    ,.DO_BW     ( TOP_DIO_BW))
u02_nbiot_input_ctrl_nce(
     .i_clk                     (i_clk                  )   //   input   wire                                

    ,.i_par_iq_swap             ( 1'd0                  )   //w_par_iq_swap          )   //   input   wire    [ 1             -1:0]       
    ,.i_par_in_tp_gen           ( w_par_in_tp_gen       )   //   input   wire    [ 1             -1:0]  
    ,.i_par_debug_mode          ( 1'd0                  )   //w_par_debug_mode       )
    ,.i_par_debug_subfrm        ( 4'd0                  )   //w_par_debug_subfrm     )
    ,.i_path_ratio              ( PATH_RATIO            )   //   245.760 clock / 1.92 fs = 128

    ,.i_rin_frame_sync          (w_nin_frame_sync_nce   )   //   input   wire    [ 1             -1:0]       
    ,.i_rin_en                  (w_nin_en               )   //   input   wire    [NUM_ANT        -1:0]       
    ,.i_rin_iq                  (w_nin_iq               )   //   input   wire    [2*NUM_ANT*DI_BW-1:0]      
    
    ,.i_rafe_den                (w_nbiot_den             )

    ,.o_rout_frame_sync_pre     (w_input_ctrl_sync_pre  )   //   input   wire    [ 1             -1:0]       
    ,.o_rout_frame_sync         (w_input_ctrl_sync      )   //   input   wire    [ 1             -1:0]       
    ,.o_rout_en_pre             (w_input_ctrl_en_pre    )   //   input   wire    [NUM_ANT        -1:0]       
    ,.o_rout_en                 (w_input_ctrl_en        )   //   input   wire    [NUM_ANT        -1:0]       
    ,.o_rout_iq                 (w_input_ctrl_iq        )   //   input   wire    [2*DO_BW        -1:0]       
);


rafe_input_ctrl #(
     .NUM_ANT   ( NUM_ANT   )
    ,.NUM_CHAIN ( NUM_CHAIN )
    ,.DI_BW     ( TOP_DIO_BW)
    ,.DO_BW     ( TOP_DIO_BW))
u02_nbiot_input_ctrl_ce(
     .i_clk                     (i_clk                  )   //   input   wire                                

    ,.i_par_iq_swap             ( 1'd0                  )   //w_par_iq_swap          )   //   input   wire    [ 1             -1:0]       
    ,.i_par_in_tp_gen           ( w_par_in_tp_gen       )   //   input   wire    [ 1             -1:0]  
    ,.i_par_debug_mode          ( 1'd0                  )   //w_par_debug_mode       )
    ,.i_par_debug_subfrm        ( 4'd0                  )   //w_par_debug_subfrm     )
    ,.i_path_ratio              ( PATH_RATIO            )   //   245.760 clock / 1.92 fs = 128

    ,.i_rin_frame_sync          (w_nin_frame_sync_ce    )   //   input   wire    [ 1             -1:0]       
    ,.i_rin_en                  (w_nin_en               )   //   input   wire    [NUM_ANT        -1:0]       
    ,.i_rin_iq                  (w_nin_iq               )   //   input   wire    [2*NUM_ANT*DI_BW-1:0]      
    
    ,.i_rafe_den                (w_nbiot_den_ce         )

    ,.o_rout_frame_sync_pre     (w_input_ctrl_sync_pre_ce  )   //   input   wire    [ 1             -1:0]       
    ,.o_rout_frame_sync         (w_input_ctrl_sync_ce      )   //   input   wire    [ 1             -1:0]       
    ,.o_rout_en_pre             (w_input_ctrl_en_pre_ce    )   //   input   wire    [NUM_ANT        -1:0]       
    ,.o_rout_en                 (w_input_ctrl_en_ce        )   //   input   wire    [NUM_ANT        -1:0]       
    ,.o_rout_iq                 (w_input_ctrl_iq_ce        )   //   input   wire    [2*DO_BW        -1:0]       
);


// cmplx exp

wire    w_ce;

assign  w_ce = w_nin_num_psymbol[1]|w_nin_num_psymbol[3];


nbiot_exp_12bit  #(
    .DO_BW(TOP_DIO_BW))
u03_nbiot_exp_12bit(
     .i_clk           (i_clk                )  //              input   wire                                

    ,.i_freq_shift    (w_freq_shift         )
    ,.i_ce            (w_ce                 )
    ,.i_init_set      (w_par_freq_init_set  )  
    ,.i_init_val      (w_par_freq_init_val  )  

    ,.i_ro_sync       (w_cprm_ro_sync   [0] )
    ,.i_rin_en        (w_cprm_nout_en   [1] )  //              input   wire    [1              -1:0]       

    ,.o_cmplx_exp_vld ( w_cmplx_exp_vld     )  //              input   wire                                
    ,.o_p_cos         ( w_p_cos             )  //              input   wire    [DO_BW          -1:0]       
    ,.o_n_sin         ( w_n_sin             )  //              input   wire    [DO_BW          -1:0]       
);

generate
    for (chidx=0;chidx<NUM_CHAIN;chidx=chidx+1) begin : path_chain


    // CP remove
    
    nbiot_cp_remove #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW   (TOP_DIO_BW       )
        ,.DO_BW   (TOP_DIO_BW       )) 
    u04_nbiot_cp_remove_nce(
         .i_clk           ( i_clk                   )  

        ,.i_nin_frame_idx ( r_nin_frame_idx         ) 
        ,.i_subf_numb     ( w_subf_numb             )
        ,.i_nfft          ( w_nb_fft_idx            ) //         input   wire    [ 1     -1:0]               
        ,.i_time_offset   ( w_time_offset           ) //         input   wire    [14     -1:0]               
        ,.i_num_psym      ( w_num_psym              ) //         input   wire    [ 4     -1:0]               
        ,.i_nb_scs_idx    ( w_nb_scs_idx            )
        ,.i_rec_trig      ( w_rec_trig              )

        ,.i_frame_sync    ( w_input_ctrl_sync                                                              ) //         input   wire                                
        ,.i_nin_en        ( w_input_ctrl_en  [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]                ) //         input   wire    [NUM_ANT-1:0]               
        ,.i_nin_iq        ( w_input_ctrl_iq  [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]                ) //         input   wire    [2*DI_BW-1:0]               
    
        ,.o_frame_sync    ( w_cprm_frame_sync_nce[1                 *chidx+:                 1]                ) //         output  reg                                 
        ,.o_ro_sync       ( w_cprm_ro_sync_nce   [1                 *chidx+:                 1]                ) //         output  reg                                 
        ,.o_nout_en       ( w_cprm_nout_en_nce   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]                ) //         output  reg     [NUM_ANT-1:0]               
        ,.o_nout_iq       ( w_cprm_nout_iq_nce   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]                ) //         output  reg     [2*DO_BW-1:0]               
        ,.o_start_frm     ( w_start_frm_nce      [8                 *chidx+:                 8]                )             
        ,.o_start_sub     ( w_start_sub_nce      [4                 *chidx+:                 4]                )             
        ,.o_start_sym     ( w_start_sym_nce      [4                 *chidx+:                 4]                )             
    );

    // CP remove CE
    
    nbiot_cp_remove #(
         .NUM_ANT (NUM_ANT/NUM_CHAIN)
        ,.DI_BW   (TOP_DIO_BW       )
        ,.DO_BW   (TOP_DIO_BW       )) 
    u04_nbiot_cp_remove_ce(
         .i_clk           ( i_clk                   )  

        ,.i_nin_frame_idx ( r_nin_frame_idx         ) 
        ,.i_subf_numb     ( w_subf_numb             )
        ,.i_nfft          ( w_nb_fft_idx            ) //         input   wire    [ 1     -1:0]               
        ,.i_time_offset   ( w_time_offset           ) //         input   wire    [14     -1:0]               
        ,.i_num_psym      ( w_num_psym              ) //         input   wire    [ 4     -1:0]               
        ,.i_nb_scs_idx    ( w_nb_scs_idx            )
        ,.i_rec_trig      ( w_rec_trig              )

        ,.i_frame_sync    ( w_input_ctrl_sync_ce                                                              ) //         input   wire                                
        ,.i_nin_en        ( w_input_ctrl_en_ce  [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]                ) //         input   wire    [NUM_ANT-1:0]               
        ,.i_nin_iq        ( w_input_ctrl_iq_ce  [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]                ) //         input   wire    [2*DI_BW-1:0]               
    
        ,.o_frame_sync    ( w_cprm_frame_sync_ce[1                 *chidx+:                 1]                ) //         output  reg                                 
        ,.o_ro_sync       ( w_cprm_ro_sync_ce   [1                 *chidx+:                 1]                ) //         output  reg                                 
        ,.o_nout_en       ( w_cprm_nout_en_ce   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]                ) //         output  reg     [NUM_ANT-1:0]               
        ,.o_nout_iq       ( w_cprm_nout_iq_ce   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]                ) //         output  reg     [2*DO_BW-1:0]               
        ,.o_start_frm     ( w_start_frm_ce      [8                 *chidx+:                 8]                )             
        ,.o_start_sub     ( w_start_sub_ce      [4                 *chidx+:                 4]                )             
        ,.o_start_sym     ( w_start_sym_ce      [4                 *chidx+:                 4]                )             
    );

    assign  w_cprm_frame_sync[1                 *chidx+:                 1] =  (r_dly_ce)? w_cprm_frame_sync_ce[1                 *chidx+:                 1] : w_cprm_frame_sync_nce[1                 *chidx+:                 1] ; 
    assign  w_cprm_ro_sync   [1                 *chidx+:                 1] =  (r_dly_ce)? w_cprm_ro_sync_ce   [1                 *chidx+:                 1] : w_cprm_ro_sync_nce   [1                 *chidx+:                 1] ; 
    assign  w_cprm_nout_en   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN] =  (r_dly_ce)? w_cprm_nout_en_ce   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN] : w_cprm_nout_en_nce   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN] ; 
    assign  w_cprm_nout_iq   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW] =  (r_dly_ce)? w_cprm_nout_iq_ce   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW] : w_cprm_nout_iq_nce   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW] ; 
    assign  w_start_frm      [8                 *chidx+:                 8] =  (r_dly_ce)? w_start_frm_ce      [8                 *chidx+:                 8] : w_start_frm_nce      [8                 *chidx+:                 8] ; 
    assign  w_start_sub      [4                 *chidx+:                 4] =  (r_dly_ce)? w_start_sub_ce      [4                 *chidx+:                 4] : w_start_sub_nce      [4                 *chidx+:                 4] ; 
    assign  w_start_sym      [4                 *chidx+:                 4] =  (r_dly_ce)? w_start_sym_ce      [4                 *chidx+:                 4] : w_start_sym_nce      [4                 *chidx+:                 4] ; 


     // freq shift
 
     nbiot_freq_shift #(
          .NUM_ANT (NUM_ANT/NUM_CHAIN)
         ,.DI_BW(TOP_DIO_BW)
         ,.DO_BW(TOP_DIO_BW))
     u05_nbiot_freq_shift(
        .i_clk        ( i_clk                    ) 
     
       ,.i_frame_sync ( w_cprm_frame_sync[1                 *chidx+:                 1]        ) 
       ,.i_ro_sync    ( w_cprm_ro_sync   [1                 *chidx+:                 1]        ) 
       ,.i_nin_en     ( w_cprm_nout_en   [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]        ) 
       ,.i_nin_iq     ( w_cprm_nout_iq   [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]        ) 
       ,.i_p_cos      ( w_p_cos                  ) 
       ,.i_n_sin      ( w_n_sin                  ) 
     
       ,.o_frame_sync ( w_fshift_sync    [1                 *chidx+:                 1]        ) 
       ,.o_ro_sync    ( w_fshift_ro_sync [1                 *chidx+:                 1]        )
       ,.o_nout_en    ( w_fshift_vld     [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]        ) 
       ,.o_nout_iq    ( w_fshift_iq      [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]        ) 
     );


      // TD AGC
      
      nbiot_td_agc_buf #(
           .NUM_ANT (NUM_ANT/NUM_CHAIN)
          ,.DI_BW(TOP_DIO_BW)
          ,.DO_BW(TOP_DIO_BW)
          ,.VENDOR(VENDOR)) 
      u06_nbiot_td_agc_buf(
           .i_clk             ( i_clk                 )         //input   wire                                              

          ,.i_nin_frame_idx   ( r_nin_frame_idx       )            
          ,.i_tagc_back_off   ( 5'd12                 )       //input   wire    [04:0]                      ff
          ,.i_tagc_on         ( 1'd1                  )       //input   wire    [00:0]                        
          ,.i_nbiot_nfft      ( w_nb_fft_idx          )       //input   wire    [ 1     -1:0]                                 
          ,.i_nbiot_scs       ( w_nb_scs_idx          )       //input   wire    [1:0]                       
                         
          ,.i_frame_sync      ( w_fshift_sync    [1                 *chidx+:                 1]     )       //input   wire    [0:0]                                 
          ,.i_ro_sync         ( w_fshift_ro_sync [1                 *chidx+:                 1]     )       //input   wire    [0:0]                       
          ,.i_nin_en          ( w_fshift_vld     [NUM_ANT/NUM_CHAIN *chidx+: NUM_ANT/NUM_CHAIN]     )       //input   wire    [NUM_ANT-1:0]                     
          ,.i_nin_iq          ( w_fshift_iq      [2*TOP_DIO_BW      *chidx+:      2*TOP_DIO_BW]     )       //input   wire    [2*NUM_ANT*DI_BW-1:0]             
                         
          ,.o_frame_sync      ( w_psym_sync      [ 1                   *chidx+:                    1]     )       //output  reg     [0:0]                                
          ,.o_nout_en         ( w_nout_en        [ 1                   *chidx+:                    1]     )       //output  wire    [NUM_ANT-1:0]               
          ,.o_nout_iq         ( w_nout_iq        [ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]     )       //output  wire    [2*NUM_ANT*DO_BW-1:0]         
          ,.o_tagc_gain       ( w_tagc_gain      [ 4*NUM_ANT/NUM_CHAIN *chidx+:  4*NUM_ANT/NUM_CHAIN]     )       //output  reg     [NUM_ANT*4-1:0]             
          ,.o_tagc_lut_index  ( w_tagc_lut_index [ 5*NUM_ANT/NUM_CHAIN *chidx+:  5*NUM_ANT/NUM_CHAIN]     )       //output  reg     [NUM_ANT*5-1:0]             
          ,.o_rssi            ( w_rssi           [31*NUM_ANT/NUM_CHAIN *chidx+: 31*NUM_ANT/NUM_CHAIN]     )       // 31*NUM_ANT
      );

      // FFT demap
      
      nbiot_fft_demap #(
           .NUM_ANT (NUM_ANT/NUM_CHAIN)
          ,.DI_BW(TOP_DIO_BW)
          ,.DO_BW(TOP_DIO_BW)
          ,.VENDOR(VENDOR)) 
      u07_nbiot_fft_demap(    
           .i_clk             ( i_clk               )       //                  input   wire                               
            
          ,.i_nin_frame_idx   ( r_nin_frame_idx     )                       
          ,.i_nbiot_nfft      ( w_nb_fft_idx        )
          ,.i_num_re          ( w_num_re            )
      
          ,.i_frame_sync      (w_psym_sync        [ 1                   *chidx+:                    1]   )       //              ,   input   wire    [0:0]                      
          ,.i_ro_sync         (w_fshift_ro_sync   [ 1                   *chidx+:                    1]   )       //              ,   input   wire    [0:0]                       
          ,.i_nin_en          (w_nout_en          [ 1                   *chidx+:                    1]   )       //              ,   input   wire    [NUM_ANT-1:0]              
          ,.i_nin_iq          (w_nout_iq          [ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]   )       //              ,   input   wire    [2*NUM_ANT*DI_BW-1:0]      
      
          ,.o_frame_sync      (w_fft_demap_sync   [ 1                   *chidx+:                    1]   )       //              ,   output  reg     [0:0]                      
          ,.o_nout_en         (w_fft_demap_nout_en[ 1                   *chidx+:                    1]   )       //              ,   output  reg     [NUM_ANT-1:0]              
          ,.o_nout_iq         (w_fft_demap_nout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]   )       //              ,   output  reg     [2*NUM_ANT*DO_BW-1:0]      
      );


      // Gain comp
      
      nbiot_gain_comp #(
           .NUM_ANT   ( NUM_ANT   /NUM_CHAIN)
          ,.DI_BW     ( TOP_DIO_BW)
          ,.DO_BW     ( TOP_DIO_BW)
          ,.DLY_SYNC  ( 3'd5       ))
      u08_nbiot_gain_comp(
           .i_clk                 (i_clk                  )
      
          ,.i_nin_frame_idx       (r_nin_frame_idx         )            
          ,.i_tagc_gain           (w_tagc_gain        [ 4*NUM_ANT/NUM_CHAIN *chidx+:  4*NUM_ANT/NUM_CHAIN]    )
          ,.i_tagc_lut_index      (w_tagc_lut_index   [ 5*NUM_ANT/NUM_CHAIN *chidx+:  5*NUM_ANT/NUM_CHAIN]    )
          ,.i_out_scale           (5'b1                   )
      
          ,.i_frame_sync          (w_fft_demap_sync   [ 1                   *chidx+:                    1]    )
          ,.i_nin_en              (w_fft_demap_nout_en[ 1                   *chidx+:                    1]    )
          ,.i_nin_iq              (w_fft_demap_nout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]    )
                                                                                                          
          ,.o_frame_sync          (w_gain_comp_sync   [ 1                   *chidx+:                    1]    )
          ,.o_nout_en             (w_gain_comp_nout_en[ 1                   *chidx+:                    1]    )
          ,.o_nout_iq             (w_gain_comp_nout_iq[ 2*TOP_DIO_BW        *chidx+:         2*TOP_DIO_BW]    )
      );

    end
endgenerate

// Output ctrl

nbiot_output_ctrl #(
     .NUM_ANT   ( NUM_ANT   )
    ,.NUM_CHAIN ( NUM_CHAIN ) 
    ,.DI_BW     ( TOP_DIO_BW)
    ,.DO_BW     ( TOP_DIO_BW))
u09_nbiot_output_ctrl(
     .i_clk                 ( i_clk                         )   //         input   wire                                

    ,.i_par_out_tp_gen      ( w_par_out_tp_gen              )   //         input   wire    [ 6     -1:0]               

    ,.i_scs                 ( w_nb_scs_idx                  )   
    ,.i_start_frm           ( w_start_frm                   )
    ,.i_start_sub           ( w_start_sub                   )   
    ,.i_start_sym           ( w_start_sym                   )   
    ,.i_num_psym            ( w_num_psym                    )

    ,.i_nin_frame_idx       ( r_nin_frame_idx               )   //         input   wire    [ 8     -1:0]               

    ,.i_frame_sync          ( w_gain_comp_sync[0]           )   //         input   wire    [1      -1:0]               
    ,.i_ro_sync             ( w_cprm_ro_sync[0]             )
    ,.i_nin_en              ( w_gain_comp_nout_en           )   //         input   wire    [NUM_ANT-1:0]               
    ,.i_nin_iq              ( w_gain_comp_nout_iq           )   //         input   wire    [2*DO_BW-1:0]               

    ,.o_frm_sync            ( o_nout_frame_sync             )
    ,.o_frm_idx             ( o_nout_frame_idx              )   //         output  wire    [8      -1:0]               
    ,.o_subfrm_idx          ( o_nout_subfrm_idx             )   //         output  wire    [4      -1:0]               
    ,.o_slot_idx            ( o_nout_slot_idx               )   //         output  wire    [6      -1:0]               
    ,.o_symb_idx            ( o_nout_symbol_idx             )   //         output  wire    [4      -1:0]               
    ,.o_nout_en             ( o_nout_en                     )   //         output  wire    [NUM_ANT-1:0]               
    ,.o_nout_iq             ( o_nout_iq                     )   //         output  wire    [2*DO_BW-1:0]               
    ,.o_nout_start_re_idx   ( o_nout_start_re_idx           )   //         output  wire    [NUM_ANT*16-1:0]            
    ,.o_nout_start_re       ( o_nout_start_re               )   //         output  wire    [NUM_ANT*1-1:0]             
    ,.o_nout_last_re        ( o_nout_last_re                )   //         output  wire    [NUM_ANT*1-1:0]             
);

// sbif rate
always @(posedge i_clk) begin
    o_nout_nb_bw_idx    <=  4'hd;
end

endmodule
