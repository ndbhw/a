// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU  
//  Module       : nbiot_output_ctrl
//  Author       : ty321.kim@samsung.com
//  Description  : nbiot output control for VzW
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.20 | taeyeong      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_output_ctrl
#(
     parameter NUM_ANT      =   8
    ,parameter NUM_CHAIN    =   4 
    ,parameter DI_BW        =   16
    ,parameter DO_BW        =   16
    )(
    //--- reset & clk
        input   wire                                    i_clk                      

    //--- from CPU IF
    ,   input   wire    [ 1                 -1:0]       i_par_out_tp_gen
    
    ,   input   wire    [ 4                 -1:0]       i_scs
    ,   input   wire    [ 8                 -1:0]       i_start_frm    
    ,   input   wire    [ 4                 -1:0]       i_start_sub    
    ,   input   wire    [ 4                 -1:0]       i_start_sym
    ,   input   wire    [ 4                 -1:0]       i_num_psym       
    //--- from BB IF
    ,   input   wire    [ 8                 -1:0]       i_nin_frame_idx

    //--- from gain comp
    ,   input   wire    [1                  -1:0]       i_frame_sync   
    ,   input   wire    [1                  -1:0]       i_ro_sync    
    ,   input   wire    [1      *NUM_CHAIN  -1:0]       i_nin_en
    ,   input   wire    [2*DO_BW*NUM_CHAIN  -1:0]       i_nin_iq     

    //--- to rach_config_map
    ,   output  reg     [1                  -1:0]       o_frm_sync  
    ,   output  reg     [8                  -1:0]       o_frm_idx
    ,   output  reg     [4                  -1:0]       o_subfrm_idx
    ,   output  reg     [6                  -1:0]       o_slot_idx
    ,   output  reg     [6                  -1:0]       o_symb_idx
    ,   output  reg     [NUM_ANT            -1:0]       o_nout_en
    ,   output  reg     [2*DO_BW*NUM_ANT    -1:0]       o_nout_iq      

    ,   output  reg     [NUM_ANT*16         -1:0]       o_nout_start_re_idx
    ,   output  reg     [NUM_ANT*1          -1:0]       o_nout_start_re    
    ,   output  reg     [NUM_ANT*1          -1:0]       o_nout_last_re     
);

localparam DLY_SYNC = 22'd4;
localparam RO_DLY   = 16'd65040;

// signal
genvar chidx ;


// input reg
reg    [1      *NUM_CHAIN -1:0]               r_nin_en;
reg    [2*DO_BW*NUM_CHAIN -1:0]               r_nin_iq;     

always @(posedge i_clk) begin
    r_nin_en    <= i_nin_en         ;
end

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin  
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin        
        r_nin_iq    <= {2*DO_BW{1'b0}}  ;
    end
    else if(i_nin_en) begin
        r_nin_iq    <= i_nin_iq;
    end
end

// ro sync & numpsym shift 


wire    [1              -1:0]               w_ro_sync   ;
reg     [4              -1:0]               r_num_psym  ;   

ylib_pshift #(
    .BW_SHIFT   (16))
u01_ylib_pshift(
     .i_clk     (i_clk      )
    ,.i_shift   (RO_DLY     )
    ,.i_in      (i_ro_sync  )
    ,.o_out     (w_ro_sync  )
);

always @(posedge i_clk) begin
    if(w_ro_sync) begin
        r_num_psym  <=   i_num_psym;
    end
end


// k bar
reg    [ 1     -1:0]               r_par_out_tp_gen;
reg    [ 8     -1:0]               r_nin_frame_idx ;

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_par_out_tp_gen    <=               i_par_out_tp_gen  ;
        r_nin_frame_idx     <=               i_nin_frame_idx   ;
    end
end

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        o_nout_start_re_idx <= 16'b0;       
    end
end

// gen sop

wire    [1      -1:0]    w_sop;
wire    [1      -1:0]    w_eop;
reg     [1      -1:0]    r_sop;
reg     [1      -1:0]    r_eop;

assign w_sop = i_nin_en[0] & (~r_nin_en[0]);
assign w_eop = ~i_nin_en[0] & r_nin_en[0]  ;


always@(posedge i_clk) begin
    r_sop   <= w_sop;
    r_eop   <= w_eop;
end


// ant align
reg    [4-1:0]             r_ant_cnt       ; 
reg    [4-1:0]             r_repet_cnt     ;

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin  
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_ant_cnt          <= {4{1'b0}}; 
        r_repet_cnt        <= {4{1'b0}}; 
    end
    else if(w_sop & (r_ant_cnt == NUM_ANT/NUM_CHAIN) & (r_repet_cnt == (r_num_psym -1)) ) begin
        r_ant_cnt          <= 4'b1;
        r_repet_cnt        <= {4{1'b0}}; 
    end
    else if(w_sop & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) begin
        r_ant_cnt          <= 4'b1;
        r_repet_cnt        <= r_repet_cnt + 4'b1;
    end
    else if(w_sop) begin
        r_ant_cnt          <= r_ant_cnt +4'b1;
    end
end

 
// slot sync gen
wire [1     -1:0]  w_frm_sync       ;
wire [4     -1:0]  w_subfrm_idx     ;


wire [8     -1:0]  w_slot_idx_15k   ;
wire [4     -1:0]  w_symb_idx_15k   ;

wire [8     -1:0]  w_slot_idx_375   ;
wire [4     -1:0]  w_symb_idx_375   ;


ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'b0                  )  // 0:15, 1:30, 2:60 ... TBD
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          ( w_frm_sync            )  // wire          
    ,.o_subfrm_sync         (                       )  // wire          
    ,.o_slot_sync           (                       )  //w_slot_sync           )  // wire          
    ,.o_symbol_sync         (                       )  //w_symb_sync           )  // wire  
    ,.o_subfrm              ( w_subfrm_idx          )  // wire   [3:0]     
    ,.o_slot                ( w_slot_idx_15k        )  // wire   [7:0]         
    ,.o_symbol              ( w_symb_idx_15k        )  // wire   [3:0]         
);

// ref_vsync_gen u01_ref_sync
// (
//      .i_clk                 ( i_clk                 )          
//     ,.i_mu                  ( 4'hd                  )  // 0:15, 1:30, 2:60 ... TBD
//     ,.i_retard              ( DLY_SYNC              )  
//     ,.i_frame_sync          ( i_frame_sync          )          
//     ,.i_en                  ( 1'd1                  )          
//     ,.o_frame_sync          (                       )  // wire          
//     ,.o_subfrm_sync         (                       )  // wire          
//     ,.o_slot_sync           (                       )  //w_slot_sync           )  // wire          
//     ,.o_symbol_sync         (                       )  //w_symb_sync           )  // wire  
//     ,.o_subfrm              (                       )  // wire   [3:0]     
//     ,.o_slot                ( w_slot_idx_375        )  // wire   [7:0]         
//     ,.o_symbol              ( w_symb_idx_375        )  // wire   [3:0]         
// );

// oRAN output pattern gen

reg [10 -1:0]   r_smp_cnt;

always @(posedge i_clk) begin
    if(i_frame_sync) begin
        r_smp_cnt   <= 10'b0;
    end
    else if(w_sop) begin
        r_smp_cnt   <= 10'b0;
    end
    else if(i_nin_en) begin
        r_smp_cnt   <= r_smp_cnt + 10'b1;
    end
    else begin
        r_smp_cnt   <= 10'b0;
    end
end

// long preamble symbol idx
reg [ 6 -1:0]   r_long_sidx;
reg [ 4 -1:0]   r_short_sidx;
reg [ 1 -1:0]   r_short_shold;

// always @(posedge i_clk) begin
//     if(i_frame_sync) begin
//         r_long_sidx <= 4'b0;
//     end
//     else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN & r_long_sidx == (i_nin_num_psymbol-1)) begin
//         r_long_sidx <= 4'b0 ;
//     end
//     else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN) begin
//         r_long_sidx <= r_long_sidx + 1 ;
//     end
// end

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin       
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_long_sidx     <= 6'b0;
        r_short_sidx    <= 4'b0;
        r_short_shold   <= 1'b0;
    end
    else if(w_sop & (~r_short_shold)) begin
        r_short_shold   <= 1'b1;
        r_long_sidx     <= {2'b0,i_start_sym}  ; //oRAN ver 5.0 CR
        r_short_sidx    <=  w_symb_idx_15k      ; 
    end
    else if((r_eop & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) & r_repet_cnt == (r_num_psym -1)) begin
        r_short_sidx <= r_short_sidx + 1 ;
        r_short_shold   <= 1'b0;
    end
    else if(r_eop & r_ant_cnt == NUM_ANT/NUM_CHAIN) begin
        r_long_sidx <= r_long_sidx + 1 ;
        r_short_sidx <= r_short_sidx + 1 ;
    end
end


// long preamble subframe idx
reg [8  -1:0]   r_long_fridx;
reg [4  -1:0]   r_long_sfidx;
reg [1  -1:0]   r_long_sfhold;

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin  
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin   
        r_long_fridx    <= 8'b0         ;
        r_long_sfidx    <= 4'b0         ;
        r_long_sfhold   <= 1'b0         ;
    end
    else if(r_eop & (r_repet_cnt==r_num_psym-1) & (r_ant_cnt == NUM_ANT/NUM_CHAIN)) begin
        r_long_fridx    <= 8'b0         ;
        r_long_sfidx    <= 4'b0         ;
        r_long_sfhold   <= 1'b0         ;
    end
    else if(w_sop & (~r_long_sfhold)) begin
//        r_long_sfidx    <= w_subfrm_idx ;
        r_long_fridx    <= i_start_frm  ;
        r_long_sfidx    <= i_start_sub  ;
        r_long_sfhold   <= 1'b1         ;
    end
end


// output ctrl

generate for(chidx=0;chidx<NUM_CHAIN;chidx=chidx+1) begin : g00_out_en_iq

    always@(posedge i_clk) begin
//        if(i_frame_sync) begin
        if(i_frame_sync & (~(|i_nin_frame_idx))) begin 
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin   
            o_nout_en      [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
            o_nout_start_re[NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
            o_nout_last_re [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){1'b0}};  
        end
        else begin
            o_nout_en      [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},r_nin_en[chidx]}<< (r_ant_cnt - 1);  
            o_nout_start_re[NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},r_sop          }<< (r_ant_cnt - 1);  
            o_nout_last_re [NUM_ANT/NUM_CHAIN*chidx+:NUM_ANT/NUM_CHAIN] <= {{(NUM_ANT/NUM_CHAIN-1){1'b0}},w_eop          }<< (r_ant_cnt - 1);  
        end
    end


    always@(posedge i_clk) begin
//        if(i_frame_sync) begin
        if(i_frame_sync & (~(|i_nin_frame_idx))) begin   
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin               
            o_nout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(2*DO_BW*NUM_ANT/NUM_CHAIN){1'b0}};
        end
        else if(r_par_out_tp_gen) begin
            o_nout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){{r_nin_frame_idx,w_subfrm_idx,w_slot_idx_15k[5:0],w_symb_idx_15k,r_smp_cnt}}};
        end
        else begin
            o_nout_iq[2*DO_BW*NUM_ANT/NUM_CHAIN*chidx+:2*DO_BW*NUM_ANT/NUM_CHAIN] <= {(NUM_ANT/NUM_CHAIN){r_nin_iq[2*DO_BW*chidx+:2*DO_BW]}};
        end
    end

end
endgenerate


always @(posedge i_clk) begin
    o_frm_sync      <=  w_frm_sync              ;   
    o_slot_idx      <=  6'b0                    ;    
end

always @(posedge i_clk) begin
    if(i_scs == 4'hd) begin
        o_frm_idx   <=  r_long_fridx            ;
        o_subfrm_idx<=  r_long_sfidx            ;    
        o_symb_idx  <=  r_long_sidx             ;
    end
    else begin
        o_frm_idx   <=  r_nin_frame_idx         ;            
        o_subfrm_idx<=  {2'b0,w_subfrm_idx  }   ; 
        o_symb_idx  <=  {2'b0,w_symb_idx_15k}   ;     
    end
end

endmodule
