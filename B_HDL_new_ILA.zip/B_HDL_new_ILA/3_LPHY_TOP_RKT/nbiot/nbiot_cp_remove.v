// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : RF4440
//  Module       : cp_remove
//  Author       : ty321.kim@samsung.com
//  Description  : configuration mapping for valid rach data 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.10.12 | taeyeong      | Modify for FSU20
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_cp_remove
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16  
   ,parameter  CNT_BW              =   17  
)(
    //--- reset & clk
        input   wire                                i_clk                      
        
    //--- from oran 
    ,   input   wire    [ 8     -1:0]               i_nin_frame_idx
    ,   input   wire    [ 4     -1:0]               i_subf_numb
    ,   input   wire    [ 4     -1:0]               i_nfft
    ,   input   wire    [14     -1:0]               i_time_offset
    ,   input   wire    [ 4     -1:0]               i_num_psym
    ,   input   wire    [ 4     -1:0]               i_nb_scs_idx
    ,   input   wire    [ 1     -1:0]               i_rec_trig

    //--- from deci_filt
    ,   input   wire                                i_frame_sync           
    ,   input   wire    [NUM_ANT-1:0]               i_nin_en           
    ,   input   wire    [2*DI_BW-1:0]               i_nin_iq           

    //--- to rach_td_agc
    ,   output  wire                                o_frame_sync           
    ,   output  wire                                o_ro_sync           
    ,   output  wire    [NUM_ANT-1:0]               o_nout_en
    ,   output  wire    [2*DO_BW-1:0]               o_nout_iq      

    //--- to output_ctrl            
    ,   output  reg     [ 8     -1:0]               o_start_frm
    ,   output  reg     [ 4     -1:0]               o_start_sub
    ,   output  reg     [ 4     -1:0]               o_start_sym
);

//Parameter config_map
localparam  DLY_SYNC                =       22'd4           ;
localparam  MAX_PATH                =       8               ;

//logic variable
genvar gidx ;

// slot sync gen
wire [0:0]  w_slot_sync_15k ;
wire [3:0]  w_subf_numb     ;
wire [3:0]  w_symb_numb     ;

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 4'd0                  ) 
    ,.i_retard              ( DLY_SYNC              )  
    ,.i_frame_sync          ( i_frame_sync          )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         (                       )   
    ,.o_slot_sync           ( w_slot_sync_15k       )   
    ,.o_subfrm              ( w_subf_numb           )
    ,.o_symbol_sync         (                       )          
    ,.o_slot                (                       )          
    ,.o_symbol              ( w_symb_numb           )          
);

// cnt

reg              r_psym_done     ;
reg              r_psym_done_d1  ;
reg  [20 -1:0]   r_cnt_m0_p1     = 20'h322CE; // 20'h77f0;
wire [14 -1:0]   w_nb_cnt        ;

always @(posedge i_clk) begin
//    if(w_slot_sync_15k & r_psym_done) begin
    if(w_slot_sync_15k) begin
        r_cnt_m0_p1    <= 20'b0            ; 
    end
    else begin
        r_cnt_m0_p1    <= r_cnt_m0_p1 +20'b1  ;
    end
end

assign w_nb_cnt = r_cnt_m0_p1[19:7];

// input reg
reg [NUM_ANT-1:0]   r_nin_en         ;  
reg [NUM_ANT-1:0]   rr_nin_en        ;  
reg [NUM_ANT-1:0]   rrr_nin_en       ;  
reg [2*DI_BW-1:0]   r_nin_iq    [NUM_ANT-1:0]   ;             

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_in_sep
    always@(posedge i_clk) begin
        r_nin_en[gidx]   <= i_nin_en[gidx]     ;
        rr_nin_en[gidx]  <= r_nin_en[gidx]     ;  
        rrr_nin_en[gidx] <= rr_nin_en[gidx]    ;  

        if(i_nin_en[gidx]) begin
            r_nin_iq[gidx]  <=  i_nin_iq[(2*DI_BW-1)-:2*DI_BW] ;
        end

    end
end
endgenerate

// sample

reg [CNT_BW-1:0] r_tot_psym_len  ;
reg [CNT_BW-1:0] rr_tot_psym_len = 0;
reg  [ 1    -1:0]   r_ro_start      ;

always@(posedge i_clk) begin
    if(|r_nin_en) begin
        r_tot_psym_len  <= {13'd0,i_num_psym}<<i_nfft<<3  ;
    end
end

always@(posedge i_clk) begin
    if(r_ro_start) begin
        rr_tot_psym_len  <= r_tot_psym_len;
    end
end

 
//reg  [ 1    -1:0]   r_ro_start      ;
reg  [ 1    -1:0]   r_end_trig      ;
reg  [ 1    -1:0]   r_end_trig_d1   ;
wire [ 1    -1:0]   w_end_tick      ;
reg  [10    -1:0]   r_cp_cnt        = 10'b0;
reg  [ 1    -1:0]   r_proc_done     =  1'b1;
reg  [CNT_BW-1:0]   r_psym_smp_cnt  ;

always@(posedge i_clk) begin
    if(r_nin_en[0] && (w_nb_cnt==i_time_offset) && r_psym_done && (~r_proc_done)) begin
        r_ro_start  <= 1'd1 ;
        o_start_frm <= i_nin_frame_idx;       
//        o_start_sub <= w_subf_numb;       
        o_start_sub <= i_subf_numb;               
//        o_start_sym <= w_symb_numb;             
        if(i_num_psym[2]|i_num_psym[3]) begin
            o_start_sym <= 1'b0         ;     
        end
        else begin
            o_start_sym <= w_symb_numb  ;     
        end
    end
    else begin
        r_ro_start <= 1'd0 ;
        o_start_frm <= o_start_frm;
        o_start_sub <= o_start_sub;
        o_start_sym <= o_start_sym;         
    end
end


always@(posedge i_clk) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin
    //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_psym_smp_cnt  <=  18'd0  ;
        r_psym_done     <=   1'b1  ;    
    end
    else if(r_ro_start) begin
        r_psym_smp_cnt  <=  18'd0  ;
        r_psym_done     <=   1'b0  ;    
    end
    else if((~r_psym_done)&&(rr_nin_en[0])&&(r_psym_smp_cnt<rr_tot_psym_len)) begin
        r_psym_smp_cnt  <=  r_psym_smp_cnt + 1'd1   ;
    end
//    else if(r_psym_smp_cnt == r_tot_psym_len) begin
    else if(r_psym_smp_cnt == rr_tot_psym_len - 4 ) begin     // CE edit
        r_psym_done     <=   1'b1  ;    
    end
end


always @(posedge i_clk) begin
    r_psym_done_d1 <=  r_psym_done;
end    



// capture fft size sample

reg [MAX_PATH -1:0]   r_nout_en                     ;  

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin      
    //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_nout_en   <= {MAX_PATH{1'b0}};
    end
    else if((~r_psym_done)&&(|rrr_nin_en) && (r_psym_smp_cnt < rr_tot_psym_len) && (r_psym_smp_cnt[2:0] == 3'b0) ) begin
        r_nout_en   <= {{(8-NUM_ANT){1'b0}},rrr_nin_en};
    end
    else begin
        r_nout_en   <= {MAX_PATH{1'b0}};
    end
end


// process on/off control

always @(posedge i_clk) begin
    if((|r_cp_cnt) & (r_psym_done & (~r_psym_done_d1))) begin
        r_end_trig  <= 1'b1;
    end
    else begin
        r_end_trig  <= 1'b0;
    end
end

always @(posedge i_clk) begin
    r_end_trig_d1   <= r_end_trig;
end

assign w_end_tick   = (i_rec_trig & r_end_trig) ? r_end_trig_d1 : r_end_trig;

always  @(posedge i_clk) begin
    // if(i_nb_scs_idx == 4'd0) begin
    //     r_proc_done <=  1'b0                    ;
    // end
    // else begin
        if(i_frame_sync & (~(|i_nin_frame_idx)) & (r_cp_cnt==10'b1))  begin
        //if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))&(r_cp_cnt==10'b1)) begin            
            r_cp_cnt    <=  r_cp_cnt                   ;
            r_proc_done <=  r_proc_done                ;
        end 
        else if(i_frame_sync & (~(|i_nin_frame_idx) & (r_cp_cnt==10'b0) )) begin
        //else if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin               
            r_cp_cnt    <=  10'b0                   ;
            r_proc_done <=  1'b1                    ;
        end
        else if((r_cp_cnt==10'b1) & (w_end_tick)) begin
            r_cp_cnt    <=  10'b0                   ;
            r_proc_done <=  1'b1                    ; 
        end    
        else if(i_rec_trig) begin
            r_cp_cnt    <=  r_cp_cnt    + 10'b1     ;
            r_proc_done <=  1'b0                    ;
        end
        else if((|r_cp_cnt) & (w_end_tick)) begin
            r_cp_cnt    <=  r_cp_cnt    - 10'b1;
        end
    // end
end

// output delay

ylib_reg #(.WIDTH(1) ,.DEPTH(2)) u98_input_reg(
    .i_clk      (i_clk      )
   ,.i_in       (r_ro_start )
   ,.o_out      (o_ro_sync  )
);

assign  o_nout_en = r_nout_en[NUM_ANT-1:0];

ylib_reg #(.WIDTH(2*DO_BW+1) ,.DEPTH(4)) u99_input_reg(
    .i_clk      (i_clk      )
   ,.i_in       ({i_frame_sync,i_nin_iq }  )
   ,.o_out      ({o_frame_sync,o_nout_iq}  )
);


endmodule
