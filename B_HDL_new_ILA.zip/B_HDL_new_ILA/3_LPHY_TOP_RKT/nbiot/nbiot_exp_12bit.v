// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU  
//  Module       : rafe_exp_49152
//  Author       : ty321.kim@samsung.com
//  Description  : rafe exp 49152 for VzW FSU
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.20 | taeyeong      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_exp_12bit
#(  
        parameter PA_BW        =   12
    ,   parameter DO_BW        =   16
    )(
    //--- reset & clk
        input   wire                                i_clk                      

    //--- from CPU IF
    ,   input   wire    [PA_BW          -1:0]       i_freq_shift
    ,   input   wire    [ 1             -1:0]       i_ce
    ,   input   wire                                i_init_set
    ,   input   wire    [12             -1:0]       i_init_val

    //--- from input ctrl
    ,   input   wire    [ 1             -1:0]       i_ro_sync
    ,   input   wire    [ 1             -1:0]       i_rin_en

    //--- to freq shift
    ,   output  wire                                o_cmplx_exp_vld             
    ,   output  wire    [DO_BW          -1:0]       o_p_cos                     
    ,   output  wire    [DO_BW          -1:0]       o_n_sin                     
);

localparam SHIFT_BW = 13        ;

// signal
reg     [SHIFT_BW   -1:0]               r_shift                     ;

always @(posedge i_clk) begin
    if(i_ro_sync) begin
        if(i_ce) begin
            if(i_init_set) begin
                r_shift         <= {1'b0,i_init_val}           ;
            end
            else begin
                r_shift         <= 13'd2048                    ;
            end
        end
        else begin
            r_shift         <= {SHIFT_BW{1'b0}}            ;
        end            
    end
    else if(i_rin_en) begin
        r_shift         <= r_shift + {1'b0,i_freq_shift};
    end
end

lib_cmplx_exp_fpga #(.CJ( 1 ) ,.SIN_TABLE_BW(DO_BW) ,.PW(PA_BW)) u00_lib_cmplx_exp
(
     .i_clk         ( i_clk           )
    ,.i_phase_vld   ( i_rin_en        )
    ,.i_phase       ( r_shift[11:0]   )
    ,.o_vld         ( o_cmplx_exp_vld )
    ,.o_cos         ( o_p_cos         )
    ,.o_sin         ( o_n_sin         )
);

endmodule
