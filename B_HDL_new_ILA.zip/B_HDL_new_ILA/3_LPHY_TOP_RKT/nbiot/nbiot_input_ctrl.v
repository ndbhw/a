// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20  
//  Module       : rafe_input_ctrl
//  Author       : ty321.kim@samsung.com
//  Description  : rafe input control for VzW FSU
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.20 | taeyeong      | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module nbiot_input_ctrl
#(
     parameter NUM_ANT      =   4
    ,parameter NUM_CHAIN    =   4
    ,parameter DI_BW        =   16
    ,parameter DO_BW        =   16
    )(
    //--- reset & clk
        input   wire                                    i_clk                      

    //--- from CPU IF
    ,   input   wire    [ 1                 -1:0]       i_par_iq_swap
    ,   input   wire    [ 1                 -1:0]       i_par_in_tp_gen
    ,   input   wire    [ 1                 -1:0]       i_par_debug_mode
    ,   input   wire    [ 4                 -1:0]       i_par_debug_subfrm
    ,   input   wire    [ 8                 -1:0]       i_path_ratio

    //--- from 
    ,   input   wire    [ 1                 -1:0]       i_rin_frame_sync
    ,   input   wire    [NUM_ANT            -1:0]       i_rin_en           
    ,   input   wire    [2*NUM_ANT*DI_BW    -1:0]       i_rin_iq   

    ,   input   wire    [ 1                 -1:0]       i_rafe_den

    //--- to freq shift
    ,   output  wire    [ 1                 -1:0]       o_rout_frame_sync_pre 
    ,   output  wire    [ 1                 -1:0]       o_rout_frame_sync 
    ,   output  wire    [ 1                 -1:0]       o_rout_en_pre       
    ,   output  wire    [NUM_ANT            -1:0]       o_rout_en       
    ,   output  wire    [2*DO_BW*NUM_CHAIN  -1:0]       o_rout_iq      
);

// signal
genvar i;

reg     [NUM_ANT            -1:0]   r_rin_en                   ;          
reg     [2*NUM_ANT*DO_BW    -1:0]   r_rin_iq                   ;          

reg     [NUM_ANT            -1:0]   r_iq_swap_en               ;          
reg     [2*NUM_ANT*DO_BW    -1:0]   r_iq_swap_iq               ;          
wire    [2*NUM_ANT*DO_BW    -1:0]   w_iq_swap_iq               ;        


reg     [NUM_ANT            -1:0]   r_reg_iq_swap_en           ;          
reg     [2*NUM_ANT*DO_BW    -1:0]   r_reg_iq_swap_iq           ;          

reg     [NUM_ANT            -1:0]   r_input_tp_en              ;          
reg     [2*NUM_ANT*DO_BW    -1:0]   r_input_tp_iq              ;          

reg     [8                  -1:0]   r_ratio_cnt                ;
reg     [2*11               -1:0]   r_input_tp_gen_iq          ;          

reg     [NUM_ANT            -1:0]   r_reg_input_tp_en          ;          
reg     [2*NUM_ANT*DO_BW    -1:0]   r_reg_input_tp_iq          ;          

wire    [1      *NUM_CHAIN  -1:0]   w_inte_leav_sync           ;
wire    [NUM_ANT            -1:0]   w_inte_leav_iq_en          ;          
wire    [2*DO_BW*NUM_CHAIN  -1:0]   w_inte_leav_iq             ;          

wire                            w_inte_leav_sync_dly4      ;
wire    [NUM_ANT        -1:0]   w_inte_leav_iq_en_dly4     ;
wire    [2*DO_BW*NUM_CHAIN  -1:0]   w_inte_leav_iq_dly4        ;

wire                            w_rin_frame_sync_d3        ;
wire                            w_rin_frame_sync_d5        ;

wire    [4              -1:0]   w_subfrm_idx               ;
wire    [1              -1:0]   w_subfrm_sync              ;
reg     [NUM_ANT        -1:0]   r_debug_en                 ;

// param reg
reg     [1      -1:0]       r_par_iq_swap   ;
reg     [1      -1:0]       r_par_in_tp_gen ;

always @(posedge i_clk) begin
    if(i_rin_frame_sync) begin
        r_par_iq_swap       <= i_par_iq_swap   ;
        r_par_in_tp_gen     <= i_par_in_tp_gen ;
    end
end

// data path

// input register : total 1 dly
always @(posedge i_clk) begin
//    r_rin_en    <=  i_rin_en; 
    r_rin_iq    <=  i_rin_iq; 
end

// debug mode : enable gen

ref_vsync_gen u00_ref_sync
(
     .i_clk                 ( i_clk                 )          
    ,.i_mu                  ( 3'd0                  )  
    ,.i_retard              ( 22'd1                 )  
    ,.i_frame_sync          ( i_rin_frame_sync      )          
    ,.i_en                  ( 1'd1                  )          
    ,.o_frame_sync          (                       )   
    ,.o_subfrm_sync         ( w_subfrm_sync         )   
    ,.o_slot_sync           (                       )   
    ,.o_subfrm              ( w_subfrm_idx          )
    ,.o_symbol_sync         (                       )          
    ,.o_slot                (                       )          
    ,.o_symbol              (                       )          
);

always @(posedge i_clk) begin
    if(i_rin_frame_sync) begin
        r_debug_en  <= {NUM_ANT{1'b0}};
    end
    else if(w_subfrm_sync) begin
        if(w_subfrm_idx == i_par_debug_subfrm) begin
            r_debug_en  <= {NUM_ANT{1'b1}};
        end
        else begin
            r_debug_en  <= {NUM_ANT{1'b0}};
        end
    end
end
    
// input iq swap : total 3 dly

generate
    for (i=0;i<NUM_ANT;i=i+1) begin : iq_swap
        assign w_iq_swap_iq[DO_BW*2*(i+1)-1:DO_BW*2*i] = 
             {r_rin_iq[DO_BW*(2*i+1)-1:DO_BW*2*i],
              r_rin_iq[DO_BW*2*(i+1)-1:DO_BW*(2*i+1)]} ;          
    end
endgenerate

always @(posedge i_clk) begin
    if(r_par_iq_swap) begin
//        r_iq_swap_en    <= r_rin_en     ;
        r_iq_swap_iq    <= w_iq_swap_iq ;
    end
    else begin
//        r_iq_swap_en    <= r_rin_en     ;
        r_iq_swap_iq    <= r_rin_iq     ;
    end
end

// debug mode enable

always @(posedge i_clk) begin
    r_reg_iq_swap_iq    <=  r_iq_swap_iq; 

        if(i_par_debug_mode) 
            r_reg_iq_swap_en    <=  r_debug_en; 
        else
            r_reg_iq_swap_en    <=  {NUM_ANT{i_rafe_den}}; 
end

// input test pattern  // TBD  //total 5 dly

// test pattern gen
always @(posedge i_clk) begin
    if(w_rin_frame_sync_d3) begin
        r_input_tp_gen_iq[21:11]        <= 11'b0; 
        r_input_tp_gen_iq[10: 0]        <= 11'b100_0000_0000; 
        r_ratio_cnt                     <=  8'b0;
    end
    else if(r_par_in_tp_gen) begin
        if(r_ratio_cnt==i_path_ratio-1) begin
            r_input_tp_gen_iq[21:11]        <= r_input_tp_gen_iq[21:11] + 11'b1 ;   // 0 ~ 1023, -1024 ~ -1
            r_input_tp_gen_iq[10: 0]        <= r_input_tp_gen_iq[10: 0] + 11'b1 ;   // -1024 ~ 1023
            r_ratio_cnt                     <= 8'b0 ;
        end
        else begin
            r_ratio_cnt                     <= r_ratio_cnt              +  8'b1 ;
        end
    end
end

always @(posedge i_clk) begin
    if(r_par_in_tp_gen) begin
        r_input_tp_en   <= r_reg_iq_swap_en;
        r_input_tp_iq   <= {NUM_ANT{{5{r_input_tp_gen_iq[21]}},r_input_tp_gen_iq[21:11], {5{r_input_tp_gen_iq[10]}},r_input_tp_gen_iq[10: 0]}};
    end
    else begin
        r_input_tp_en   <= r_reg_iq_swap_en;
        r_input_tp_iq   <= r_reg_iq_swap_iq;
    end
end

always @(posedge i_clk) begin
    r_reg_input_tp_en   <= r_input_tp_en; 
    r_reg_input_tp_iq   <= r_input_tp_iq; 
end

// frame sync dly
ylib_reg #(.WIDTH(1) ,.DEPTH(3)) u01_out_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ( i_rin_frame_sync    )
   ,.o_out      ( w_rin_frame_sync_d3 )
);

ylib_reg #(.WIDTH(1) ,.DEPTH(2)) u02_out_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ( w_rin_frame_sync_d3 )
   ,.o_out      ( w_rin_frame_sync_d5 )
);

// input interleaving
generate
    for (i=0;i<NUM_CHAIN;i=i+1) begin : input_interleaving

        ylib_inter_leav #(
             .WIDTH     (    DO_BW              ) 
            ,.NUM_ANT   (    NUM_ANT/NUM_CHAIN  )
            ,.DLY       (    1                  ))
        u03_ylib_inter_leav(
             .i_clk     ( i_clk                 )
            ,.i_sync    ( w_rin_frame_sync_d5   )
            ,.i_ratio   ( i_path_ratio          )   
            ,.i_en      ( r_reg_input_tp_en[        NUM_ANT/NUM_CHAIN *i+:         NUM_ANT/NUM_CHAIN]     )
            ,.i_in      ( r_reg_input_tp_iq[2*DO_BW*NUM_ANT/NUM_CHAIN *i+: 2*DO_BW*NUM_ANT/NUM_CHAIN]     )
            ,.o_sync    ( w_inte_leav_sync [        1                 *i+:                         1]     )
            ,.o_vld     ( w_inte_leav_iq_en[        NUM_ANT/NUM_CHAIN *i+:         NUM_ANT/NUM_CHAIN]     )
            ,.o_out     ( w_inte_leav_iq   [        2*DO_BW           *i+:                   2*DO_BW]     )
        );

    end
endgenerate


// input data dly 4 + 2
ylib_reg #(.WIDTH(2*DO_BW*NUM_CHAIN +NUM_ANT+1) ,.DEPTH(3+2+1)) u04_out_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ( {w_inte_leav_sync[0]  ,w_inte_leav_iq_en     ,w_inte_leav_iq}            )
   ,.o_out      ( {w_inte_leav_sync_dly4,w_inte_leav_iq_en_dly4,w_inte_leav_iq_dly4}  )
);





// output


//ylib_reg #(.WIDTH(2) ,.DEPTH(2+1)) u05_out_reg(
//    .i_clk      ( i_clk    )
//   ,.i_in       ( {w_rin_frame_sync_d5,r_reg_input_tp_en[0] })
//   ,.o_out      ( {o_rout_frame_sync_pre,o_rout_en_pre })
//);

wire [1     -1:0]    w_sync_pre ;
reg  [1     -1:0]    r_en_pre   ;
//reg  [1     -1:0]    r_frm_ready;
//
//always @(posedge i_clk) begin
//    if(w_rin_frame_sync_d3) begin
//        r_frm_ready <= 1'b1;
//    end
//    else if(o_rout_frame_sync_pre) begin
//        r_frm_ready <= 1'b0;
//    end
//end

always @(posedge i_clk) begin
//    if(i_rin_frame_sync) 
//        r_en_pre    <= 1'b0                 ;
//    else
        r_en_pre    <= r_reg_input_tp_en[0] ;
end

//assign  w_sync_pre = r_frm_ready & r_reg_input_tp_en[0] & (~r_en_pre);
assign  w_sync_pre = r_reg_input_tp_en[0] & (~r_en_pre);

ylib_reg #(.WIDTH(2) ,.DEPTH(2)) u05_out_reg(
    .i_clk      ( i_clk    )
   ,.i_in       ( {w_sync_pre,r_en_pre })
   ,.o_out      ( {o_rout_frame_sync_pre,o_rout_en_pre })
);


// assign o_rout_frame_sync_pre= w_rin_frame_sync_d5   ;
// assign o_rout_en_pre        = |r_reg_input_tp_en    ;

assign o_rout_frame_sync    = w_inte_leav_sync_dly4 ;
assign o_rout_en            = w_inte_leav_iq_en_dly4;
assign o_rout_iq            = w_inte_leav_iq_dly4   ;


endmodule
