// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

/////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : ATnT HRU micro
//  Module       : gain_comp
//  Author       : ty321.kim@samsung.com
//  Description  : NB-IoT gain comp
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.5.12  | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2020.5.12  | ty321.kim     | Modify for FSU20        
//  ------------+---------------+-------------------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////////////

module nbiot_gain_comp
#(
    parameter  NUM_ANT             =   4           
   ,parameter  DI_BW               =   16           
   ,parameter  DO_BW               =   16           
   ,parameter  DLY_SYNC            =   3'd6           
)(
    //--- clk
        input   wire                            i_clk                 

    //--- from td_agc_buf
    ,   input   wire    [8          -1:0]       i_nin_frame_idx 
    ,   input   wire    [NUM_ANT*4  -1:0]       i_tagc_gain
    ,   input   wire    [NUM_ANT*5  -1:0]       i_tagc_lut_index
    ,   input   wire    [5          -1:0]       i_out_scale

    //--- from ofdm_demod
    ,   input   wire    [1          -1:0]       i_frame_sync 
    ,   input   wire    [1          -1:0]       i_nin_en
    ,   input   wire    [2*DI_BW    -1:0]       i_nin_iq      

    //--- to phase_comp
    ,   output  wire    [1          -1:0]       o_frame_sync 
    ,   output  wire    [1          -1:0]       o_nout_en
    ,   output  wire    [2*DO_BW    -1:0]       o_nout_iq      
);

// logic variable
genvar gidx ;

// input reg
reg    [1      -1:0]               r_nin_en;
reg    [2*DI_BW-1:0]               r_nin_iq; 

always @(posedge i_clk) begin
    r_nin_en    <=  i_nin_en;
    r_nin_iq    <=  i_nin_iq;  
end

// sop gen
wire     [1      -1:0]               w_sop;

assign w_sop   = i_nin_en & (~r_nin_en)   ;

// table
reg [9*NUM_ANT  -1:0]           r_gain2_comp        ;

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_td_lut_comp
    always@(posedge i_clk) begin
        case(i_tagc_lut_index[(5*(gidx+1)-1)-:5]) 
            5'd0    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd256    ;
            5'd1    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd264    ;
            5'd2    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd272    ;
            5'd3    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd279    ;
            5'd4    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd286    ;
            5'd5    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd293    ;
            5'd6    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd300    ;
            5'd7    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd307    ;
            5'd8    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd314    ;
            5'd9    :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd320    ;
            5'd10   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd326    ;
            5'd11   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd333    ;
            5'd12   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd339    ;
            5'd13   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd345    ;
            5'd14   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd351    ;
            5'd15   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd356    ;
            5'd16   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd181    ;
            5'd17   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd187    ;
            5'd18   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd192    ;
            5'd19   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd197    ;
            5'd20   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd202    ;
            5'd21   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd207    ;
            5'd22   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd212    ;
            5'd23   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd217    ;
            5'd24   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd222    ;
            5'd25   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd226    ;
            5'd26   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd231    ;
            5'd27   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd235    ;
            5'd28   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd239    ;
            5'd29   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd244    ;
            5'd30   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd248    ;
            5'd31   :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd252    ;
            default :   r_gain2_comp[(9*(gidx+1)-1)-:9] <= 9'd252    ;   
        endcase
    end
end
endgenerate

// gain align
reg    [3   -1:0]             r_gain_cnt            ; 
reg    [4*8 -1:0]             r_pre_tagc_gain       ;
reg    [9*8 -1:0]             r_pre_tagc_lut_index  ;
reg    [4   -1:0]             r_tagc_gain           ;
reg    [9   -1:0]             r_tagc_lut_index      ;

always @(posedge i_clk) begin
    //if(i_frame_sync) begin
    //    r_pre_tagc_gain       <= 32'b0;
    //    r_pre_tagc_lut_index  <= 72'b0;
    //end
    //else begin
    r_pre_tagc_gain       <= {{((8-NUM_ANT)*4){1'b0}},i_tagc_gain};
    r_pre_tagc_lut_index  <= {{((8-NUM_ANT)*9){1'b0}},r_gain2_comp};
    //end
end

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin  
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_gain_cnt          <= {3{1'b0}}; 
    end
    else if(w_sop & (r_gain_cnt == NUM_ANT-1)) begin
        r_gain_cnt          <= {3{1'b0}};
    end
    else if(w_sop) begin
        r_gain_cnt          <= r_gain_cnt +1;
    end
end

always @(posedge i_clk) begin
//    if(i_frame_sync) begin
    if(i_frame_sync & (~(|i_nin_frame_idx))) begin      
//    if(i_frame_sync & ((i_nin_frame_idx==8'd0)|(i_nin_frame_idx==8'd2))) begin           
        r_tagc_gain         <= 4'b0;
        r_tagc_lut_index    <= 9'b0;
    end
    else if(w_sop) begin
        case(r_gain_cnt)
            3'd0    : begin r_tagc_gain <= r_pre_tagc_gain[4*1  -1:4*0]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*1  -1:9*0]; end
            3'd1    : begin r_tagc_gain <= r_pre_tagc_gain[4*2  -1:4*1]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*2  -1:9*1]; end
            3'd2    : begin r_tagc_gain <= r_pre_tagc_gain[4*3  -1:4*2]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*3  -1:9*2]; end
            3'd3    : begin r_tagc_gain <= r_pre_tagc_gain[4*4  -1:4*3]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*4  -1:9*3]; end
            3'd4    : begin r_tagc_gain <= r_pre_tagc_gain[4*5  -1:4*4]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*5  -1:9*4]; end
            3'd5    : begin r_tagc_gain <= r_pre_tagc_gain[4*6  -1:4*5]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*6  -1:9*5]; end
            3'd6    : begin r_tagc_gain <= r_pre_tagc_gain[4*7  -1:4*6]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*7  -1:9*6]; end
            3'd7    : begin r_tagc_gain <= r_pre_tagc_gain[4*8  -1:4*7]; r_tagc_lut_index <= r_pre_tagc_lut_index[9*8  -1:9*7]; end
            default : begin r_tagc_gain <=                     4'd0; r_tagc_lut_index <=                      9'd0; end
        endcase
    end
end


// lut comp
reg [1   -1:0]  r_td_gain2_comp_en  ;  
reg [2*24-1:0]  r_td_gain2_comp_iq  ;   
reg [1   -1:0]  rr_td_gain2_comp_en ;  
reg [2*24-1:0]  rr_td_gain2_comp_iq ;   

always@(posedge i_clk) begin
    r_td_gain2_comp_en  <=  r_nin_en  ;
    if(r_nin_en) begin
        r_td_gain2_comp_iq[(24*2-1)-:24]  <=  $signed({{{24-DI_BW}{r_nin_iq[DI_BW*2-1]}},r_nin_iq[(DI_BW*2-1)-:DI_BW]})*$signed({{{24-9}{1'd0}},r_tagc_lut_index}) ;
        r_td_gain2_comp_iq[(24*1-1)-:24]  <=  $signed({{{24-DI_BW}{r_nin_iq[DI_BW*1-1]}},r_nin_iq[(DI_BW*1-1)-:DI_BW]})*$signed({{{24-9}{1'd0}},r_tagc_lut_index}) ;
    end
end

always@(posedge i_clk) begin
    rr_td_gain2_comp_en  <=  r_td_gain2_comp_en  ;
    if(r_td_gain2_comp_en) begin
        rr_td_gain2_comp_iq <= r_td_gain2_comp_iq;
    end
end

// tagc comp
wire    [1      -1:0]      w_td_gain1_comp_en    ;  
wire    [2*24   -1:0]      w_td_gain1_comp_iq    ;             
reg     [5      -1:0]      r_gain1_comp          ;

always@(posedge i_clk) begin
    if(r_nin_en) 
        r_gain1_comp  <=  5'sd8 + $signed({r_tagc_gain[3],r_tagc_gain})  ;         
end

ylib_shiftd_rnd #(
  .NUM_STREAM   (   2           )
 ,.SHIFTD_BW    (   5           )
 ,.IO_BW        (   24          ))
u00_shiftd_rnd 
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   rr_td_gain2_comp_en         )
    ,.i_in      (   rr_td_gain2_comp_iq         )
    ,.i_shiftd  (   r_gain1_comp                )
    ,.o_out_en  (   w_td_gain1_comp_en          )
    ,.o_out     (   w_td_gain1_comp_iq          )
);

ylib_sat #(
  .NUM_STREAM   (   2           )
 ,.DI_BW        (   24          )
 ,.DO_BW        (   DO_BW       )
 ,.SAT_TYPE     ( "ASSYMETRIC"  ))
u01_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   w_td_gain1_comp_en          )
    ,.i_in      (   w_td_gain1_comp_iq          )
    ,.o_out_en  (   o_nout_en                   )
    ,.o_out     (   o_nout_iq                   )
);

// sync shift
ylib_pshift #(
    .BW_SHIFT   ($clog2(DLY_SYNC)))
u02_fsync_shift
(
     .i_clk     (   i_clk           )
    ,.i_shift   (   DLY_SYNC        )
    ,.i_in      (   i_frame_sync    )
    ,.o_out     (   o_frame_sync    )
);

endmodule
