// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : rafe_cpu_param_if 
//  Author       : jyzoo.lee@samsung.com
//  Description  : cpu parameter interface for RAFE
//  Revision History
//  ------------+---------------+-------------------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | jyzoo.lee     | Initial Release
//  ------------+---------------+-------------------------------------------------------
//   2020.6.09  | taeyeong      | Modify to RAFE
//  ------------------------------------------------------------------------------------ 
//
////////////////////////////////////////////////////////////////////////////////////////

module nbiot_cpu_param_if
#(
    parameter   ADDR_OFFSET         =16'h9000       // CPU IF Address Offset    
   ,parameter   DLY_REG_RD          =       5       // READ Latency
   ,parameter   AW                  =      16       // CPU IF Address Bit Width
   ,parameter   DW                  =      32       // CPU IF Data Bit Width 
   ,parameter   RU_MODE             =       0
   ,parameter   NUM_ANT             =       4
)(
    //--- reset & clk
        input   wire                           i_clk 
    //,   input   wire                           i_rst
                                     
    //--- cpu interface              
    ,   input   wire    [AW           -1:0]    i_cpu_addr
    ,   input   wire    [ 1           -1:0]    i_cpu_wren
    ,   input   wire    [DW           -1:0]    i_cpu_wdata
    ,   input   wire    [ 1           -1:0]    i_cpu_rden
    ,   output  wire    [DW           -1:0]    o_cpu_rdata
    ,   output  wire    [ 1           -1:0]    o_cpu_rd_valid
                                     
    //--- Parsed parameter           
    ,   output  reg     [ 1           -1:0]    o_par_freq_shift_sel 
    ,   output  reg     [ 1           -1:0]    o_par_iq_swap        
    ,   output  reg     [ 1           -1:0]    o_par_in_tp_gen      
    ,   output  reg     [ 1           -1:0]    o_par_out_tp_gen     
    ,   output  reg     [ 1           -1:0]    o_par_debug_mode 
    ,   output  reg     [ 4           -1:0]    o_par_debug_subfrm 
                                     
    ,   output  reg     [4            -1:0]    o_par_filter_idx     
    ,   output  reg     [16           -1:0]    o_par_time_offset    
    ,   output  reg     [8            -1:0]    o_par_frame_struct      
    ,   output  reg     [16           -1:0]    o_par_cp_length      
    ,   output  reg     [4            -1:0]    o_par_num_psymbol     
    ,   output  reg     [24           -1:0]    o_par_freq_offset    
    ,   output  reg     [8            -1:0]    o_par_num_prbc
    ,   output  reg     [3            -1:0]    o_par_num_ro  
                                     
    ,   output  reg     [1            -1:0]    o_par_freq_init_set
    ,   output  reg     [12           -1:0]    o_par_freq_init_val
    
    ,   output  reg     [16           -1:0]    o_par_adv_offset
                                     
    //--- oRAN param read            
    ,   input   wire    [4            -1:0]    i_rin_filter_idx     
    ,   input   wire    [16           -1:0]    i_rin_time_offset    
    ,   input   wire    [8            -1:0]    i_rin_frame_struct      
    ,   input   wire    [16           -1:0]    i_rin_cp_length      
    ,   input   wire    [4            -1:0]    i_rin_num_psymbol     
    ,   input   wire    [24           -1:0]    i_rin_freq_offset    
    ,   input   wire    [8            -1:0]    i_rin_num_prbc    
    ,   input   wire    [3            -1:0]    i_rin_num_ro    
    ,   input   wire    [10           -1:0]    i_rin_start_prbc
    ,   input   wire    [32           -1:0]    i_rin_rec_oran    
                                     
    //--- nbiot_wrapper              
    ,   input   wire    [27           -1:0]    i_rin_freq_offset_ref
    ,   input   wire    [1            -1:0]    i_rin_sel_input_path
                                     
    //--- nbiot_core                 
    ,   input   wire    [ 4           -1:0]    i_nin_nb_scs_idx    
    ,   input   wire    [14           -1:0]    i_nin_time_offset   
    ,   input   wire    [12           -1:0]    i_nin_freq_shift    
    ,   input   wire    [ 4           -1:0]    i_nin_nb_fft_idx    
    ,   input   wire    [12           -1:0]    i_nin_num_re        
    ,   input   wire    [ 4           -1:0]    i_nin_num_psym      
                                     
    //--- Report Register            
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro0
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro1
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro2
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro3
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro4
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro5
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro6
    ,   input   wire    [DW           -1:0]    i_rpt_rssi_ro7
    
    ,   input   wire    [ 8           -1:0]    i_nout_frame_idx   
    ,   input   wire    [ 4           -1:0]    i_nout_subframe_idx
    ,   input   wire    [ 6           -1:0]    i_nout_slot_idx  
    ,   input   wire    [ 6           -1:0]    i_nout_symbol_idx  
    ,   input   wire    [ 1 * NUM_ANT -1:0]    i_nout_en
    ,   input   wire    [ 1 * NUM_ANT -1:0]    i_nout_last_re
);

//Parameter
localparam DLY_REG_RD_OUT = (DLY_REG_RD == 2)? 0 : DLY_REG_RD -3;
localparam ADD_OFFSET     = (RU_MODE == 1)? 16'h0000 : 16'h4000;

//Logic Variable
genvar gidx  ;
genvar gidx1 ;


//////////////////////////////////////////////////////////////////////////

reg  [ 8     -1:0] r_nout_frame_idx       [80 -1:0] ;
reg  [ 4     -1:0] r_nout_subframe_idx    [80 -1:0] ;
reg  [ 6     -1:0] r_nout_slot_idx        [80 -1:0] ;
reg  [ 6     -1:0] r_nout_symbol_idx      [80 -1:0] ;
reg  [ 1     -1:0] r_nout_last_re                   ;
reg  [ 7     -1:0] r_nout_cnt                   = 0 ;

wire [32     -1:0] w_out_timing_info [80 -1:0] ;

always @(posedge i_clk) begin
    r_nout_last_re  <=  i_nout_en & (|i_nout_last_re) ;
end

always @(posedge i_clk) begin
    if (r_nout_last_re) begin
        if (r_nout_cnt == 80  -1)
            r_nout_cnt  <=  0;
        else
            r_nout_cnt  <=  r_nout_cnt + 1;
    end
end

always @(posedge i_clk) begin
    if (r_nout_last_re) begin
        r_nout_frame_idx    [r_nout_cnt]  <=  i_nout_frame_idx    ;
        r_nout_subframe_idx [r_nout_cnt]  <=  i_nout_subframe_idx ;
        r_nout_slot_idx     [r_nout_cnt]  <=  i_nout_slot_idx     ;
        r_nout_symbol_idx   [r_nout_cnt]  <=  i_nout_symbol_idx   ;
    end                             
end                                 


generate
    for (gidx1 = 0; gidx1 < 80; gidx1 = gidx1 + 1) begin : timing_info
        assign w_out_timing_info [gidx1]  =  {r_nout_frame_idx [gidx1], 4'b0, r_nout_subframe_idx [gidx1], 2'b0, r_nout_slot_idx [gidx1], 2'b0, r_nout_symbol_idx [gidx1]} ;
    end
endgenerate

//////////////////////////////////////////////////////////////////////////






reg [  AW       -1:0]  r_cpu_addr                        ;    
reg [   1       -1:0]  r_cpu_wren                        ;
reg [  DW       -1:0]  r_cpu_wdata                       ;
reg [   1       -1:0]  r_cpu_rden                        ;

always@(posedge i_clk) begin
    if(i_cpu_wren) begin
        r_cpu_wren      <=    i_cpu_wren    ;
        r_cpu_wdata     <=    i_cpu_wdata   ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else if(i_cpu_rden) begin
        r_cpu_rden      <=    i_cpu_rden    ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else begin
        r_cpu_wren      <=    1'd0    ;
        r_cpu_rden      <=    1'd0    ;
    end
end

reg [   1       -1:0]  rr_cpu_rden [2   -1:0] ;
reg [  AW       -1:0]  rr_cpu_addr [2   -1:0] ; 

always@(posedge i_clk) begin
    if(i_cpu_rden) begin
        rr_cpu_rden[0] <=     i_cpu_rden    ;
        rr_cpu_addr[0] <=     i_cpu_addr    ; 
        rr_cpu_rden[1] <=     i_cpu_rden    ;
        rr_cpu_addr[1] <=     i_cpu_addr    ; 
    end
    else begin
        rr_cpu_rden[0] <=     1'b0    ;
        rr_cpu_rden[1] <=     1'b0    ;
    end
end


//demux & parsing
always@(posedge i_clk) begin
    if(r_cpu_wren) begin
        case(r_cpu_addr)
            ADDR_OFFSET+ADD_OFFSET+16'h0080    :   o_par_iq_swap           <=  r_cpu_wdata[ 1     -1:0];  
            ADDR_OFFSET+ADD_OFFSET+16'h0084    :   o_par_in_tp_gen         <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h0088    :   o_par_out_tp_gen        <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h008C    :   o_par_freq_shift_sel    <=  r_cpu_wdata[ 1     -1:0]; 

            ADDR_OFFSET+ADD_OFFSET+16'h0098    :   o_par_debug_mode        <=  r_cpu_wdata[ 1     -1:0];
            ADDR_OFFSET+ADD_OFFSET+16'h009C    :   o_par_debug_subfrm      <=  r_cpu_wdata[ 4     -1:0];
            
            ADDR_OFFSET+ADD_OFFSET+16'h00A0    :   o_par_filter_idx        <=  r_cpu_wdata[ 4     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00A4    :   o_par_time_offset       <=  r_cpu_wdata[16     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00A8    :   o_par_frame_struct      <=  r_cpu_wdata[ 8     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00AC    :   o_par_cp_length         <=  r_cpu_wdata[16     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B0    :   o_par_num_psymbol       <=  r_cpu_wdata[ 4     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B4    :   o_par_freq_offset       <=  r_cpu_wdata[24     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00B8    :   o_par_num_ro            <=  r_cpu_wdata[ 3     -1:0];     
            ADDR_OFFSET+ADD_OFFSET+16'h00BC    :   o_par_num_prbc          <=  r_cpu_wdata[ 8     -1:0];             

            ADDR_OFFSET+ADD_OFFSET+16'h00F0    :   o_par_freq_init_set     <=  r_cpu_wdata[ 1     -1:0];              
            ADDR_OFFSET+ADD_OFFSET+16'h00F4    :   o_par_freq_init_val     <=  r_cpu_wdata[12     -1:0];  
            
            ADDR_OFFSET+ADD_OFFSET+16'h0138    :   o_par_adv_offset        <=  r_cpu_wdata[16     -1:0];    
        endcase                                                      
    end                                                               
end                                                                   

reg [0:0]     r_mux_rd0_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd0_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(rr_cpu_rden[0]) begin
        case(rr_cpu_addr[0])
            
            ADDR_OFFSET+ADD_OFFSET+16'h0080    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_iq_swap                   }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h0084    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_in_tp_gen                 }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h0088    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_out_tp_gen                }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h008C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_freq_shift_sel            }; end 
                                                                                                                                                         
            ADDR_OFFSET+ADD_OFFSET+16'h0098    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_debug_mode                }; end 
            ADDR_OFFSET+ADD_OFFSET+16'h009C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_debug_subfrm              }; end 
                                                                                                                                                         
            ADDR_OFFSET+ADD_OFFSET+16'h00A0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_filter_idx                }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00A4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, o_par_time_offset               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00A8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 8){1'b0}}, o_par_frame_struct              }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00AC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, o_par_cp_length                 }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, o_par_num_psymbol               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-24){1'b0}}, o_par_freq_offset               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00B8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}}, o_par_num_ro                    }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00BC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}}, o_par_num_prbc                  }; end
                                                                                                                                                         
            ADDR_OFFSET+ADD_OFFSET+16'h00F0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, o_par_freq_init_set             }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00F4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-12){1'b0}}, o_par_freq_init_val             }; end
            
            ADDR_OFFSET+ADD_OFFSET+16'h0138    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, o_par_adv_offset                }; end
                                                                                                                                                         
            ADDR_OFFSET+ADD_OFFSET+16'h00C0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, i_rin_filter_idx                }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00C4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, i_rin_time_offset               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00C8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 8){1'b0}}, i_rin_frame_struct              }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00CC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-16){1'b0}}, i_rin_cp_length                 }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, i_rin_num_psymbol               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-24){1'b0}}, i_rin_freq_offset               }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00D8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 3){1'b0}}, i_rin_num_ro                    }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00DC    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-18){1'b0}}, i_rin_start_prbc, i_rin_num_prbc}; end
            ADDR_OFFSET+ADD_OFFSET+16'h00E0    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <=                   i_rin_rec_oran                   ; end
                                                                                                                                                        
            ADDR_OFFSET+ADD_OFFSET+16'h00E4    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW-27){1'b0}}, i_rin_freq_offset_ref           }; end
            ADDR_OFFSET+ADD_OFFSET+16'h00E8    :   begin r_mux_rd0_en[0] <= 1'b1; r_mux_rd0_data[0] <= {{(DW- 1){1'b0}}, i_rin_sel_input_path            }; end
                                                                                                                                                        
            ADDR_OFFSET+ADD_OFFSET+16'h0100    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, i_nin_nb_scs_idx                }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0104    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-14){1'b0}}, i_nin_time_offset               }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0108    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-12){1'b0}}, i_nin_freq_shift                }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h010C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, i_nin_nb_fft_idx                }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0110    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW-12){1'b0}}, i_nin_num_re                    }; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0114    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= {{(DW- 4){1'b0}}, i_nin_num_psym                  }; end    

            ADDR_OFFSET+ADD_OFFSET+16'h0390    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro0    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0394    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro1    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0398    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro2    ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h039C    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro3    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A0    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro4    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A4    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro5    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03A8    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro6    ; end 
            ADDR_OFFSET+ADD_OFFSET+16'h03AC    :   begin r_mux_rd0_en[0] <= 1'd1; r_mux_rd0_data[0] <= i_rpt_rssi_ro7    ; end 
            
                                    default    :   begin r_mux_rd0_en[0] <= 1'd0; r_mux_rd0_data[0] <= 32'hEFEF_EFEF     ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd0_en [0]  <=  1'd0    ;    
    end
end                               



reg [0:0]     r_mux_rd1_en    [DLY_REG_RD-1:0]  ;
reg [DW-1:0]  r_mux_rd1_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(rr_cpu_rden[1]) begin
        case(rr_cpu_addr[1])
            ADDR_OFFSET+ADD_OFFSET+16'h0400    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 0] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0404    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 1] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0408    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 2] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h040C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 3] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0410    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 4] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0414    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 5] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0418    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 6] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h041C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 7] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0420    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 8] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0424    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [ 9] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0428    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [10] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h042C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [11] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0430    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [12] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0434    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [13] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0438    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [14] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h043C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [15] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0440    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [16] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0444    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [17] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0448    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [18] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h044C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [19] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0450    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [20] ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h0454    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [21] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0458    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [22] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h045C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [23] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0460    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [24] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0464    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [25] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0468    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [26] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h046C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [27] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0470    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [28] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0474    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [29] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0478    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [30] ; end    
            ADDR_OFFSET+ADD_OFFSET+16'h047C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [31] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0480    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [32] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0484    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [33] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0488    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [34] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h048C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [35] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0490    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [36] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0494    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [37] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h0498    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [38] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h049C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [39] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04A0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [40] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04A4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [41] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04A8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [42] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04AC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [43] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04B0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [44] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04B4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [45] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04B8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [46] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04BC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [47] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04C0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [48] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04C4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [49] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04C8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [50] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04CC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [51] ; end     
            ADDR_OFFSET+ADD_OFFSET+16'h04D0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [52] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04D4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [53] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04D8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [54] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04DC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [55] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04E0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [56] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04E4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [57] ; end   
            ADDR_OFFSET+ADD_OFFSET+16'h04E8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [58] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h04EC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [59] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h04F0    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [60] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h04F4    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [61] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h04F8    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [62] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h04FC    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [63] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0500    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [64] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0504    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [65] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0508    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [66] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h050C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [67] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0510    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [68] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0514    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [69] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0518    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [70] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h051C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [71] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0520    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [72] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0524    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [73] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0528    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [74] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h052C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [75] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0530    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [76] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0534    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [77] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h0538    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [78] ; end  
            ADDR_OFFSET+ADD_OFFSET+16'h053C    :   begin r_mux_rd1_en[0] <= 1'd1; r_mux_rd1_data[0] <= w_out_timing_info [79] ; end  
                                          
                                    default    :   begin r_mux_rd1_en[0] <= 1'd0; r_mux_rd1_data[0] <= 32'hEFEF_EFEF          ; end    
        endcase                                                      
    end  
    else begin
        r_mux_rd1_en [0]  <=  1'd0    ;    
    end
end                               

reg [0:0]     r_mux_rd_en    [DLY_REG_RD_OUT+1:0]  ;
reg [DW-1:0]  r_mux_rd_data  [DLY_REG_RD_OUT+1:0]  ;

always @(posedge i_clk) begin
    if     (r_mux_rd0_en[0]) begin r_mux_rd_en[0] <= r_mux_rd0_en[0]; r_mux_rd_data[0] <= r_mux_rd0_data[0]; end
    else if(r_mux_rd1_en[0]) begin r_mux_rd_en[0] <= r_mux_rd1_en[0]; r_mux_rd_data[0] <= r_mux_rd1_data[0]; end
    else                     begin r_mux_rd_en[0] <= 1'b0;  end
end

generate for(gidx=1;gidx<DLY_REG_RD_OUT+2;gidx=gidx+1) begin : g00_reg_rd_dly 
always@(posedge i_clk) begin
    if(r_mux_rd_en    [gidx-1]) begin
        r_mux_rd_en    [gidx]  <=  r_mux_rd_en    [gidx-1]    ;    
        r_mux_rd_data  [gidx]  <=  r_mux_rd_data  [gidx-1]    ;    
    end  
    else begin
        r_mux_rd_en    [gidx]  <=  1'd0    ;    
    end
end                               
end
endgenerate

assign  o_cpu_rd_valid  =   r_mux_rd_en    [DLY_REG_RD_OUT]   ;   
assign  o_cpu_rdata     =   r_mux_rd_data  [DLY_REG_RD_OUT]   ;   

endmodule                                                             
