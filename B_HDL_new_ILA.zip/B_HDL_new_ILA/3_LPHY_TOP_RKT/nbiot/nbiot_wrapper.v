// *****************************************************************************
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED
// 
// *****************************************************************************

////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW RF4440  
//  Module       : nbiot_wrapper
//  Author       : hk.myeong@samsung.com
//  Description  : nbiot wrapper for VzW FSU
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2023.08.15 | hk.myeong     | Initial Release
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////



module nbiot_wrapper
#( 
     parameter  NB_NUM_CC            =   3
   , parameter  NUM_ANT              =   4  
   , parameter  NUM_CHAIN            =   1
   , parameter  MAX_OBW              =   10
   , parameter  TOP_DIO_BW           =   16           
   , parameter  DLY_REG_RD           =   2
   , parameter  ADDR_OFFSET          =   16'hB000           
   , parameter  VENDOR               =   "Xilinx"
   , parameter  CPU_ADDR_BW          =   20
)
(
    // common
      input  wire                                                i_rst                
    , input  wire                                                i_clk                  
                                                              
    // from cpu interface                                  
    , input  wire  [ 1 * NB_NUM_CC * CPU_ADDR_BW          -1:0]  i_cpu_addr
    , input  wire  [ 1 * NB_NUM_CC                        -1:0]  i_cpu_wren
    , input  wire  [32 * NB_NUM_CC                        -1:0]  i_cpu_wdata
    , input  wire  [ 1 * NB_NUM_CC                        -1:0]  i_cpu_rden
    , output wire  [32 * NB_NUM_CC                        -1:0]  o_cpu_rdata
    , output wire  [ 1 * NB_NUM_CC                        -1:0]  o_cpu_rd_valid
                                                                   
    // from qm_top                                              
    , input  wire  [ 4 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_filter_idx     
    , input  wire  [16 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_time_offset    
    , input  wire  [ 8 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_frame_struct      
    , input  wire  [16 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_cp_length      
    , input  wire  [ 4 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_num_psymbol     
    , input  wire  [24 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_freq_offset    
    , input  wire  [ 8 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_num_prbc
    , input  wire  [ 3 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_num_ro      
    , input  wire  [10 * NB_NUM_CC * NUM_ANT              -1:0]  i_nin_start_prbc       
                                                              
    // from bb_if                                          
    , input  wire  [ 1 *  2                               -1:0]  i_nin_frame_sync
    , input  wire  [ 8 *  2                               -1:0]  i_nin_frame_idx
    , input  wire  [ 1 *  2 * NUM_ANT                     -1:0]  i_nin_en           
    , input  wire  [ 2 *  2 * NUM_ANT * TOP_DIO_BW        -1:0]  i_nin_iq           
                    
    // to dsp_top
    , output wire  [ 1 *  2                               -1:0]  o_nout_nco_valid   
    , output wire  [ 8 *  2                               -1:0]  o_nout_frame_struct
    , output wire  [24 *  2                               -1:0]  o_nout_freq_offset
                                                          
    // to bb_top                                          
    , output wire  [ 1 * NB_NUM_CC                        -1:0]  o_nout_frame_sync   
    , output wire  [ 8 * NB_NUM_CC                        -1:0]  o_nout_frame_idx
    , output wire  [ 4 * NB_NUM_CC                        -1:0]  o_nout_subfrm_idx
    , output wire  [ 6 * NB_NUM_CC                        -1:0]  o_nout_slot_idx
    , output wire  [ 6 * NB_NUM_CC                        -1:0]  o_nout_symbol_idx
    , output wire  [ 1 * NB_NUM_CC * NUM_ANT              -1:0]  o_nout_en
    , output wire  [ 2 * NB_NUM_CC * NUM_ANT * TOP_DIO_BW -1:0]  o_nout_iq      
    , output wire  [16 * NB_NUM_CC * NUM_ANT              -1:0]  o_nout_start_re_idx
    , output wire  [ 1 * NB_NUM_CC * NUM_ANT              -1:0]  o_nout_start_re  
    , output wire  [ 1 * NB_NUM_CC * NUM_ANT              -1:0]  o_nout_last_re     
    , output wire  [ 4 * NB_NUM_CC                        -1:0]  o_nout_nb_bw_idx   
);
    
    integer ccidx0;
    integer ccidx1;
    genvar  ccidx2;
    
    
    
    reg   [ 8                        -1:0]  r_frame_struct      [NB_NUM_CC  -1:0] ;
    reg   [ 8                        -1:0]  r_frame_struct_d    [NB_NUM_CC  -1:0] ;
    reg   [27                        -1:0]  r_freq_offset       [NB_NUM_CC  -1:0] ;
    reg   [27                        -1:0]  r_start_prbc        [NB_NUM_CC  -1:0] ;  // The unit of startPrbc is 1 rb, so needed to be changed to 1 re.
                                                                
    reg   [27                        -1:0]  r_start_prbc_value  [NB_NUM_CC  -1:0] ;  // And scs/2 is needed to considered, so that it comes to "start_prbc_value = startPrbc * 12 * 2"
    reg   [27                        -1:0]  r_freq_offset_m1    [NB_NUM_CC  -1:0] ;  // freq_offset - 1
    reg   [27                        -1:0]  r_freq_prbc_m1      [NB_NUM_CC  -1:0] ;  // freq_offset + startPrbc - 1                    
    reg   [27                        -1:0]  r_freq_offset_ref   [NB_NUM_CC  -1:0] ;  // (freq_offset + startPrbc - 1) * (4 or 1 depending on scs)
    
    reg   [ 4                        -1:0]  r_nco_valid         [NB_NUM_CC  -1:0] ;
                                                                
    reg   [ 1                        -1:0]  r_out_nco_valid     [ 2         -1:0] ;
    reg   [ 8                        -1:0]  r_out_frame_struct  [ 2         -1:0] ;
    reg   [24                        -1:0]  r_out_freq_offset   [ 2         -1:0] ;
                                                                
    reg   [ 1                        -1:0]  r_sel_input_path                  = 0 ;
                                                                
    reg   [ 1                        -1:0]  r_frame_sync        [NB_NUM_CC  -1:0] ;
    reg   [ 8                        -1:0]  r_frame_idx         [NB_NUM_CC  -1:0] ;
    reg   [ 1 * NUM_ANT              -1:0]  r_nb_in_en          [NB_NUM_CC  -1:0] ;
    reg   [ 2 * NUM_ANT * TOP_DIO_BW -1:0]  r_nb_in_iq          [NB_NUM_CC  -1:0] ;
                                                                
    wire  [ 1                        -1:0]  w_nb_frame_sync     [NB_NUM_CC  -1:0] ;
    wire  [ 8                        -1:0]  w_nb_frame_idx      [NB_NUM_CC  -1:0] ;
    wire  [ 4                        -1:0]  w_nb_subfrm_idx     [NB_NUM_CC  -1:0] ;
    wire  [ 6                        -1:0]  w_nb_slot_idx       [NB_NUM_CC  -1:0] ;
    wire  [ 6                        -1:0]  w_nb_symbol_idx     [NB_NUM_CC  -1:0] ;
    wire  [ 1 * NUM_ANT              -1:0]  w_nb_out_en         [NB_NUM_CC  -1:0] ;
    wire  [ 2 * NUM_ANT * TOP_DIO_BW -1:0]  w_nb_out_iq         [NB_NUM_CC  -1:0] ;
    wire  [16 * NUM_ANT              -1:0]  w_nb_start_re_idx   [NB_NUM_CC  -1:0] ;
    wire  [ 1 * NUM_ANT              -1:0]  w_nb_start_re       [NB_NUM_CC  -1:0] ;
    wire  [ 1 * NUM_ANT              -1:0]  w_nb_last_re        [NB_NUM_CC  -1:0] ;
    wire  [ 4                        -1:0]  w_nb_nb_bw_idx      [NB_NUM_CC  -1:0] ;
                 


    // for simulation
    initial
    begin
        for (ccidx0 = 0; ccidx0 < NB_NUM_CC; ccidx0 = ccidx0 + 1) begin
            r_frame_struct    [ccidx0]  <=  0 ;
            r_frame_struct_d  [ccidx0]  <=  0 ;
            r_freq_offset     [ccidx0]  <=  0 ;
            r_nco_valid       [ccidx0]  <=  0 ;
            r_frame_sync      [ccidx0]  <=  0 ;
            r_frame_idx       [ccidx0]  <=  0 ;
            r_nb_in_en        [ccidx0]  <=  0 ;
            r_nb_in_iq        [ccidx0]  <=  0 ;
            r_freq_offset_m1  [ccidx0]  <=  0 ;
            r_freq_offset_ref [ccidx0]  <=  0 ;
        end
        
        for (ccidx1 = 0; ccidx1 < 2; ccidx1 = ccidx1 + 1) begin
            r_out_nco_valid    [ccidx1]  <=  0 ;
            r_out_frame_struct [ccidx1]  <=  0 ;
            r_out_freq_offset  [ccidx1]  <=  0 ;
        end
    end




    always @(posedge i_clk) begin
        for (ccidx0 = 0; ccidx0 < NB_NUM_CC; ccidx0 = ccidx0 + 1) begin : valid_cc_chain
            r_nco_valid [ccidx0][0]    <=  (|i_nin_num_ro [ 3 * NUM_ANT * ccidx0 +:  3 * NUM_ANT]) ;
            r_nco_valid [ccidx0][3:1]  <=  r_nco_valid [ccidx0][2:0] ;
        end
    end
            
    always @(posedge i_clk) begin
        for (ccidx0 = 0; ccidx0 < NB_NUM_CC; ccidx0 = ccidx0 + 1) begin : cp_cc_chain
            if (|i_nin_num_ro [ 3 * NUM_ANT * ccidx0 +:  3 * NUM_ANT]) begin
                r_frame_struct [ccidx0]  <=  i_nin_frame_struct [ 8 * NUM_ANT * ccidx0 +:  8]  ;
                r_freq_offset  [ccidx0]  <=  {{(27 - 24){i_nin_freq_offset  [24 * (NUM_ANT * ccidx0 + 1) -1]}}, i_nin_freq_offset  [24 * NUM_ANT * ccidx0 +: 24]} ;
                r_start_prbc   [ccidx0]  <=  {{(27 - 10){i_nin_start_prbc   [10 * (NUM_ANT * ccidx0 + 1) -1]}}, i_nin_start_prbc   [10 * NUM_ANT * ccidx0 +: 10]} ;
            end
        end
    end
        

    // freq_offset 
    always @(posedge i_clk) begin
        for (ccidx0 = 0; ccidx0 < NB_NUM_CC; ccidx0 = ccidx0 + 1) begin
            r_start_prbc_value [ccidx0]  <=  (r_start_prbc [ccidx0] << 4) + (r_start_prbc [ccidx0] << 3) ;                // startPrbc * 24
                                                                                                                           
            r_freq_offset_m1   [ccidx0]  <=  r_freq_offset [ccidx0] - 1 ;                                                 // freq_offset - 1 
            r_freq_prbc_m1     [ccidx0]  <=  r_freq_offset_m1 [ccidx0] + r_start_prbc_value [ccidx0] ;                    // freq_offset + startPrbc' - 1 
                                                                                                                           
            if (r_frame_struct [ccidx0][3:0] == 0)                                                                       
                r_freq_offset_ref [ccidx0]  <=  r_freq_prbc_m1 [ccidx0] << 2 ;                                            // If scs == 15kHz
            else
                r_freq_offset_ref [ccidx0]  <=  r_freq_prbc_m1 [ccidx0] ;                                                 // If scs == 3.75kHz
        end
    end
    
    
    always @(posedge i_clk) begin
        if (r_nco_valid [0][3] | r_nco_valid [1][3] | r_nco_valid [2][3]) begin
            if ((r_freq_offset_ref [2] == r_freq_offset_ref [0]) | (r_freq_offset_ref [2] == r_freq_offset_ref [1])) begin
                r_out_nco_valid    [0]  <=  r_nco_valid    [0][3]  ;
                r_out_frame_struct [0]  <=  r_frame_struct [0]     ;
                r_out_freq_offset  [0]  <=  r_freq_prbc_m1 [0] + 1 ;   // freq_offset + startPrbc'
    
                r_out_nco_valid    [1]  <=  r_nco_valid    [1][3]  ;
                r_out_frame_struct [1]  <=  r_frame_struct [1]     ;
                r_out_freq_offset  [1]  <=  r_freq_prbc_m1 [1] + 1 ;
            end
            else begin
                r_out_nco_valid    [0]  <=  r_nco_valid    [0][3]  ;
                r_out_frame_struct [0]  <=  r_frame_struct [0]     ;
                r_out_freq_offset  [0]  <=  r_freq_prbc_m1 [0] + 1 ;
    
                r_out_nco_valid    [1]  <=  r_nco_valid    [2][3]  ;
                r_out_frame_struct [1]  <=  r_frame_struct [2]     ;
                r_out_freq_offset  [1]  <=  r_freq_prbc_m1 [2] + 1 ;
            end
        end
        else begin
            r_out_nco_valid [0]  <=  0 ;
            r_out_nco_valid [1]  <=  0 ;
        end
    end
    
    
    
    // IQ data
    always @(posedge i_clk) begin
        for (ccidx1 = 0; ccidx1 < 2; ccidx1 = ccidx1 + 1) begin
            r_frame_sync [ccidx1]  <=  i_nin_frame_sync [ 1                        * ccidx1 +:  1                        ] ;
            r_frame_idx  [ccidx1]  <=  i_nin_frame_idx  [ 8                        * ccidx1 +:  8                        ] ;
            r_nb_in_en   [ccidx1]  <=  i_nin_en         [ 1 * NUM_ANT              * ccidx1 +:  1 * NUM_ANT              ] ;
            r_nb_in_iq   [ccidx1]  <=  i_nin_iq         [ 2 * NUM_ANT * TOP_DIO_BW * ccidx1 +:  2 * NUM_ANT * TOP_DIO_BW ] ;
        end
        
        if (r_freq_offset_ref [2] == r_freq_offset_ref [0]) begin  // IQ data from cell #0
            r_frame_sync [2]  <=  i_nin_frame_sync   [ 1                        * 0 +:  1                        ] ; 
            r_frame_idx  [2]  <=  i_nin_frame_idx    [ 8                        * 0 +:  8                        ] ; 
            r_nb_in_en   [2]  <=  i_nin_en           [ 1 * NUM_ANT              * 0 +:  1 * NUM_ANT              ] ; 
            r_nb_in_iq   [2]  <=  i_nin_iq           [ 2 * NUM_ANT * TOP_DIO_BW * 0 +:  2 * NUM_ANT * TOP_DIO_BW ] ; 
            r_sel_input_path  <=  0 ;
        end
        else begin                                               // IQ data from cell #1
            r_frame_sync [2]  <=  i_nin_frame_sync   [ 1                        * 1 +:  1                        ] ; 
            r_frame_idx  [2]  <=  i_nin_frame_idx    [ 8                        * 1 +:  8                        ] ; 
            r_nb_in_en   [2]  <=  i_nin_en           [ 1 * NUM_ANT              * 1 +:  1 * NUM_ANT              ] ; 
            r_nb_in_iq   [2]  <=  i_nin_iq           [ 2 * NUM_ANT * TOP_DIO_BW * 1 +:  2 * NUM_ANT * TOP_DIO_BW ] ; 
            r_sel_input_path  <=  1 ;
        end
    end
    
    
    // nbiot_core_cc
    generate
        for (ccidx2 = 0; ccidx2 < NB_NUM_CC; ccidx2 = ccidx2 + 1) begin : nbiot_cc_chain
            nbiot_cc #(
                .NUM_ANT               (NUM_ANT                                                           ),
                .NUM_CHAIN             (NUM_CHAIN                                                         ),
                .MAX_OBW               (MAX_OBW                                                           ),
                .TOP_DIO_BW            (TOP_DIO_BW                                                        ),
                .DLY_REG_RD            (DLY_REG_RD                                                        ),
                .ADDR_OFFSET           (ADDR_OFFSET                                                       ),
                .VENDOR                (VENDOR                                                            ),
                .CPU_ADDR_BW           (CPU_ADDR_BW                                                       )
            ) nbiot_cc (                                                                                  
                .i_rst                 (i_rst                                                             ),
                .i_clk                 (i_clk                                                             ),
                                                                                                         
                .i_cpu_addr            (i_cpu_addr         [ 1 * CPU_ADDR_BW * ccidx2 +:  1 * CPU_ADDR_BW]),
                .i_cpu_wren            (i_cpu_wren         [ 1               * ccidx2 +:  1              ]),
                .i_cpu_wdata           (i_cpu_wdata        [32               * ccidx2 +: 32              ]),
                .i_cpu_rden            (i_cpu_rden         [ 1               * ccidx2 +:  1              ]),
                                                                                                         
                .o_cpu_rdata           (o_cpu_rdata        [32               * ccidx2 +: 32              ]),
                .o_cpu_rd_valid        (o_cpu_rd_valid     [ 1               * ccidx2 +:  1              ]),
                                                                                                        
                .i_nin_filter_idx      (i_nin_filter_idx   [ 4 * NUM_ANT     * ccidx2 +:  4 * NUM_ANT    ]),
                .i_nin_time_offset     (i_nin_time_offset  [16 * NUM_ANT     * ccidx2 +: 16 * NUM_ANT    ]),
                .i_nin_frame_struct    (i_nin_frame_struct [ 8 * NUM_ANT     * ccidx2 +:  8 * NUM_ANT    ]),
                .i_nin_cp_length       (i_nin_cp_length    [16 * NUM_ANT     * ccidx2 +: 16 * NUM_ANT    ]),
                .i_nin_num_psymbol     (i_nin_num_psymbol  [ 4 * NUM_ANT     * ccidx2 +:  4 * NUM_ANT    ]),
                .i_nin_freq_offset     (i_nin_freq_offset  [24 * NUM_ANT     * ccidx2 +: 24 * NUM_ANT    ]),
                .i_nin_num_prbc        (i_nin_num_prbc     [ 8 * NUM_ANT     * ccidx2 +:  8 * NUM_ANT    ]),
                .i_nin_num_ro          (i_nin_num_ro       [ 3 * NUM_ANT     * ccidx2 +:  3 * NUM_ANT    ]),
                .i_nin_start_prbc      (i_nin_start_prbc   [10 * NUM_ANT     * ccidx2 +: 10 * NUM_ANT    ]),
                                       
                .i_nin_freq_offset_ref (r_freq_offset_ref  [ccidx2]                                       ),
                .i_nin_sel_input_path  (r_sel_input_path                                                  ),
                                       
                .i_nin_frame_sync      (r_frame_sync       [ccidx2]                                       ),
                .i_nin_frame_idx       (r_frame_idx        [ccidx2]                                       ),
                .i_nin_en              (r_nb_in_en         [ccidx2]                                       ),
                .i_nin_iq              (r_nb_in_iq         [ccidx2]                                       ),
                                                                                                           
                .o_nout_frame_sync     (w_nb_frame_sync    [ccidx2]                                       ),
                .o_nout_frame_idx      (w_nb_frame_idx     [ccidx2]                                       ),
                .o_nout_subfrm_idx     (w_nb_subfrm_idx    [ccidx2]                                       ),
                .o_nout_slot_idx       (w_nb_slot_idx      [ccidx2]                                       ),
                .o_nout_symbol_idx     (w_nb_symbol_idx    [ccidx2]                                       ),
                .o_nout_en             (w_nb_out_en        [ccidx2]                                       ),
                .o_nout_iq             (w_nb_out_iq        [ccidx2]                                       ),
                .o_nout_start_re_idx   (w_nb_start_re_idx  [ccidx2]                                       ),
                .o_nout_start_re       (w_nb_start_re      [ccidx2]                                       ),
                .o_nout_last_re        (w_nb_last_re       [ccidx2]                                       ),
                .o_nout_nb_bw_idx      (w_nb_nb_bw_idx     [ccidx2]                                       )
            );
        end
    endgenerate
    

    // outputs
    generate
        for (ccidx2 = 0; ccidx2 < 2; ccidx2 = ccidx2 + 1) begin : nbiot_to_ddc
            assign o_nout_nco_valid     [ 1                        * ccidx2 +:  1                       ]  =  r_out_nco_valid    [ccidx2] ;
            assign o_nout_frame_struct  [ 8                        * ccidx2 +:  8                       ]  =  r_out_frame_struct [ccidx2] ;
            assign o_nout_freq_offset   [24                        * ccidx2 +: 24                       ]  =  r_out_freq_offset  [ccidx2] ;
        end
    endgenerate

    generate
        for (ccidx2 = 0; ccidx2 < NB_NUM_CC; ccidx2 = ccidx2 + 1) begin : nbiot_output_cc_chain
            assign o_nout_frame_sync    [ 1                        * ccidx2 +:  1                       ]  =  w_nb_frame_sync    [ccidx2] ;
            assign o_nout_frame_idx     [ 8                        * ccidx2 +:  8                       ]  =  w_nb_frame_idx     [ccidx2] ;
            assign o_nout_subfrm_idx    [ 4                        * ccidx2 +:  4                       ]  =  w_nb_subfrm_idx    [ccidx2] ;
            assign o_nout_slot_idx      [ 6                        * ccidx2 +:  6                       ]  =  w_nb_slot_idx      [ccidx2] ;
            assign o_nout_symbol_idx    [ 6                        * ccidx2 +:  6                       ]  =  w_nb_symbol_idx    [ccidx2] ;
            assign o_nout_en            [ 1 * NUM_ANT              * ccidx2 +:  1 * NUM_ANT             ]  =  w_nb_out_en        [ccidx2] ;
            assign o_nout_iq            [ 2 * NUM_ANT * TOP_DIO_BW * ccidx2 +:  2 * NUM_ANT * TOP_DIO_BW]  =  w_nb_out_iq        [ccidx2] ;
            assign o_nout_start_re_idx  [16 * NUM_ANT              * ccidx2 +: 16 * NUM_ANT             ]  =  w_nb_start_re_idx  [ccidx2] ;
            assign o_nout_start_re      [ 1 * NUM_ANT              * ccidx2 +:  1 * NUM_ANT             ]  =  w_nb_start_re      [ccidx2] ;
            assign o_nout_last_re       [ 1 * NUM_ANT              * ccidx2 +:  1 * NUM_ANT             ]  =  w_nb_last_re       [ccidx2] ;
            assign o_nout_nb_bw_idx     [ 4                        * ccidx2 +:  4                       ]  =  w_nb_nb_bw_idx     [ccidx2] ;
        end
    endgenerate



endmodule







