----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date: 08/03/2021 13:13:13
-- Design Name:
-- Module Name: ECPRIPHY_TOP - Behavioral
-- Project Name:
-- Target Devices:
-- Tool Versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
use WORK.ARRAY_TYPE.ALL;

entity ECPRIPHY_TOP is
    port (
--------------------------------------------------------------------------------
-- Pin
--------------------------------------------------------------------------------

        OTRX_DEL_IN                 : in  std_logic_vector(1 downto 0);
        OTRX_LOS_IN                 : in  std_logic_vector(1 downto 0);
        OTRX_TXFAULT_IN             : in  std_logic_vector(1 downto 0);
        OTRX_TXDIS_OUT              : out std_logic_vector(1 downto 0);
        OTRX_BH_RS_OUT              : out std_logic_array2(1 downto 0);

--------------------------------------------------------------------------------
-- SYSCTRL_TOP
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------
        ECPRI_GT_RESET_RX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_GT_RESET_TX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_BLOCK_LOCK    : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_LOCAL_FAULT   : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_RATE_10G_25GN : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_REMOTE_FAULT  : in  std_logic_vector(1 downto 0);
        ECPRI_GT_RXLPMEN            : out std_logic_vector(1 downto 0);
        ECPRI_GT_TXDIFFCTRL         : out std_logic_array5(1 downto 0);
        ECPRI_TXPRECURSOR           : out std_logic_array5(1 downto 0);
        ECPRI_TXPOSTCUSOR           : out std_logic_array5(1 downto 0);
        MODE_CHANGE_25N_10H         : out std_logic_vector(1 downto 0);                     -- Low : 25G, High : 10G
        RX_WDT_RESET                : out std_logic_vector(1 downto 0);
        MAC_SYS_RESET               : out std_logic;
        DMA_BLOCK_RESET             : out std_logic;
--------------------------------------------------------------------------------
-- PROPAGATION signal
--------------------------------------------------------------------------------
        ECPRI_FAULT_PROPA           : out std_logic_vector(2 downto 0);                     --[2]: BLOCK UNLOCK, [1]:REMOTE FAULT, [0]:LOCAL FAULT        

--------------------------------------------------------------------------------
-- CPU_TOP
--------------------------------------------------------------------------------

        CLK_CPUIF                   : in  std_logic;
        RST_CPUIF                   : in  std_logic;

--------------------------------------------------------------------------------
-- CPUIF_TOP
--------------------------------------------------------------------------------

        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        RDVAL_CPUIF_OUT             : out std_logic
    );
end ECPRIPHY_TOP;

architecture Behavioral of ECPRIPHY_TOP is

    component PHY_MPI is
    generic (
        TILE_NUM                    : natural := 1;
        CHANNEL_NUM                 : natural := 2
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RESET                       : in  std_logic;

--------------------------------------------------------------------------------
-- PHY channel
--------------------------------------------------------------------------------

        OTRX_DEL                    : in  std_logic_vector(1 downto 0);
        OTRX_LOS                    : in  std_logic_vector(1 downto 0);
        OTRX_TXFAULT                : in  std_logic_vector(1 downto 0);
        OTRX_DISABLE                : out std_logic_vector(1 downto 0);
        OTRX_BH_RS_OUT              : out std_logic_array2(1 downto 0);

        ECPRI_GT_RESET_RX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_GT_RESET_TX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_BLOCK_LOCK    : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_LOCAL_FAULT   : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_RATE_10G_25GN : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_REMOTE_FAULT  : in  std_logic_vector(1 downto 0); 
        ECPRI_GT_RXLPMEN            : out std_logic_vector(1 downto 0);
        ECPRI_GT_TXDIFFCTRL         : out std_logic_array5(1 downto 0);
        ECPRI_TXPRECURSOR           : out std_logic_array5(1 downto 0);
        ECPRI_TXPOSTCUSOR           : out std_logic_array5(1 downto 0);
        MODE_CHANGE_25N_10H         : out std_logic_vector(1 downto 0);                     -- Low : 25G, High : 10G
        RX_WDT_ENABLE               : out std_logic_vector(1 downto 0);
        MAC_SYS_RESET               : out std_logic;
        DMA_BLOCK_RESET             : out std_logic;
                
--------------------------------------------------------------------------------
-- CPU
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
    end component;

    component serdes_rx_wdt
    port(
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        WDT_EN                      : in  std_logic;
        RX_ERROR                    : in  std_logic;
        WDT_RESET                   : out std_logic
    );
    end component;

    component csl_synchronizer
    port(
        clk                         : in  std_logic;
        data_in                     : in  std_logic;
        data_out                    : out std_logic
    );
    end component;

signal wdt_rx_error                 : std_logic_vector(1 downto 0);
signal wdt_rx_error_sync            : std_logic_vector(1 downto 0);
signal rx_wdt_enable                : std_logic_vector(1 downto 0);
--signal ecpri_fault_propa            : std_logic_vector(2 downto 0);

begin

ECPRI_FAULT_PROPA         <= (not ECPRI_STAT_RX_BLOCK_LOCK(0)) & ECPRI_STAT_RX_REMOTE_FAULT(0) & ECPRI_STAT_RX_LOCAL_FAULT(0);
u_wdt_reset_gen : for i in 1 downto 0 generate

    wdt_rx_error(i) <= OTRX_LOS_IN(i) or (not ECPRI_STAT_RX_BLOCK_LOCK(i));

    u_wdt_rx_error_sync : csl_synchronizer port map(CLK_CPUIF, wdt_rx_error(i), wdt_rx_error_sync(i));

    u_serdes_rx_wdt_i : serdes_rx_wdt
    port map(
        RESET                       => RST_CPUIF                                ,--: in  std_logic;
        CLK                         => CLK_CPUIF                                ,--: in  std_logic;

        WDT_EN                      => rx_wdt_enable(i)                         ,--: in  std_logic;
        RX_ERROR                    => wdt_rx_error_sync(i)                     ,--: in  std_logic;
        WDT_RESET                   => RX_WDT_RESET(i)                           --: out std_logic
    );

end generate;

    u_MPI : PHY_MPI
    port map(
        CLK                         => CLK_CPUIF                                ,--: in  std_logic;
        RESET                       => RST_CPUIF                                ,--: in  std_logic;

--------------------------------------------------------------------------------
-- PHY channel
--------------------------------------------------------------------------------

        OTRX_DEL                    => OTRX_DEL_IN                              ,--: in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_LOS                    => OTRX_LOS_IN                              ,--: in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_TXFAULT                => OTRX_TXFAULT_IN                          ,--: in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_DISABLE                => OTRX_TXDIS_OUT                           ,--: out std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_BH_RS_OUT              => OTRX_BH_RS_OUT                           ,--: out std_logic_array2(CHANNEL_NUM-1 downto 0);

        ECPRI_GT_RESET_RX_DONE      => ECPRI_GT_RESET_RX_DONE                   ,--: in  std_logic_vector(1 downto 0);
        ECPRI_GT_RESET_TX_DONE      => ECPRI_GT_RESET_TX_DONE                   ,--: in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_BLOCK_LOCK    => ECPRI_STAT_RX_BLOCK_LOCK                 ,--: in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_LOCAL_FAULT   => ECPRI_STAT_RX_LOCAL_FAULT                ,--: in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_RATE_10G_25GN => ECPRI_STAT_RX_RATE_10G_25GN              ,--: in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_REMOTE_FAULT  => ECPRI_STAT_RX_REMOTE_FAULT               ,--: in  std_logic_vector(1 downto 0);
        ECPRI_GT_RXLPMEN            => ECPRI_GT_RXLPMEN                         ,--: out std_logic_vector(1 downto 0);
        ECPRI_GT_TXDIFFCTRL         => ECPRI_GT_TXDIFFCTRL                      ,--: out std_logic_array5(1 downto 0);
        ECPRI_TXPRECURSOR           => ECPRI_TXPRECURSOR                        ,--: out std_logic_array5(1 downto 0);
        ECPRI_TXPOSTCUSOR           => ECPRI_TXPOSTCUSOR                        ,--: out std_logic_array5(1 downto 0);
        MODE_CHANGE_25N_10H         => MODE_CHANGE_25N_10H                      ,--: out std_logic_vector(1 downto 0);                     -- Low : 25G, High : 10G
        RX_WDT_ENABLE               => rx_wdt_enable                            ,--: out std_logic_vector(1 downto 0);
        MAC_SYS_RESET               => MAC_SYS_RESET                            ,--: out std_logic;
        DMA_BLOCK_RESET             => DMA_BLOCK_RESET                          ,--: out std_logic;                     


--------------------------------------------------------------------------------
-- CPU
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               => WREN_CPUIF_IN                            ,--: in  std_logic;
        RDEN_CPUIF_IN               => RDEN_CPUIF_IN                            ,--: in  std_logic;
        ADDR_CPUIF_IN               => ADDR_CPUIF_IN                            ,--: in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              => WDATA_CPUIF_IN                           ,--: in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             => RDATA_CPUIF_OUT                          ,--: out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             => RDVAL_CPUIF_OUT                           --: out std_logic
    );

end Behavioral;
