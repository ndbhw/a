-----------------------------------------------------------------------
-- $RCSfile: synchronizer_vhd.ejava,v $
-- $Revision: 1.1 $
-- $Date: 2011/02/15 16:14:42 $
-- Title      : Synchronizer
-- Project    : cpri_v8_1
-----------------------------------------------------------------------
-- File       : csl_synchronizer.vhd
-- Author     : Xilinx
-----------------------------------------------------------------------
-- Description:
-- Utility synchronizer circuit
-----------------------------------------------------------------------
-- (c) Copyright 2004 - 2012 Xilinx, Inc. All rights reserved. 
--
-- This file contains confidential and proprietary information
-- of Xilinx, Inc. and is protected under U.S. and
-- international copyright and other intellectual property
-- laws.
--
-- DISCLAIMER
-- This disclaimer is not a license and does not grant any
-- rights to the materials distributed herewith. Except as
-- otherwise provided in a valid license issued to you by
-- Xilinx, and to the maximum extent permitted by applicable
-- law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
-- WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
-- AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
-- BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
-- INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
-- (2) Xilinx shall not be liable (whether in contract or tort,
-- including negligence, or under any other theory of
-- liability) for any loss or damage of any kind or nature
-- related to, arising under or in connection with these
-- materials, including for any direct, or any indirect,
-- special, incidental, or consequential loss or damage
-- (including loss of data, profits, goodwill, or any type of
-- loss or damage suffered as a result of any action brought
-- by a third party) even if such damage or loss was
-- reasonably foreseeable or Xilinx had been advised of the
-- possibility of the same.
--
-- CRITICAL APPLICATIONS
-- Xilinx products are not designed or intended to be fail-
-- safe, or for use in any application requiring fail-safe
-- performance, such as life-support or safety devices or
-- systems, Class III medical devices, nuclear facilities,
-- applications related to the deployment of airbags, or any
-- other applications that could lead to death, personal
-- injury, or severe property or environmental damage
-- (individually and collectively, "Critical
-- Applications"). Customer assumes the sole risk and
-- liability of any use of Xilinx products in Critical
-- Applications, subject only to applicable laws and
-- regulations governing limitations on product liability.
--
-- THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
-- PART OF THIS FILE AT ALL TIMES.
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

library unisim;
use unisim.vcomponents.all;

entity csl_synchronizer is
  generic (
    RESET_VALUE : std_logic := '0');
  port (
    clk          : in  std_logic;
    data_in      : in  std_logic;
--    reset : in  std_logic;
    data_out     : out std_logic);

end csl_synchronizer;

architecture rtl of csl_synchronizer is
  -- Internal Signals
  signal data_sync0 : std_logic;
  signal data_sync1 : std_logic;
  signal data_sync2 : std_logic;
  signal data_sync3 : std_logic;
  signal data_sync4 : std_logic;

  -- These ATTRIBUTES will stop timing errors being reported in back annotated SDF simulation.
  attribute async_reg               : string;
  attribute shreg_extract           : string;
  attribute async_reg of data_sync0_i : label is "true";
  attribute async_reg of data_sync1_i : label is "true";
  attribute async_reg of data_sync2_i : label is "true";
  attribute async_reg of data_sync3_i : label is "true";
  attribute async_reg of data_sync4_i : label is "true";
  attribute shreg_extract of data_sync0_i : label is "no";
  attribute shreg_extract of data_sync1_i : label is "no";
  attribute shreg_extract of data_sync2_i : label is "no";
  attribute shreg_extract of data_sync3_i : label is "no";
  attribute shreg_extract of data_sync4_i : label is "no";
  
  function convert_to_bit(C_RESET_VALUE : std_logic)
    return bit is
    variable ret_val :  bit;
  begin
    if(C_RESET_VALUE = '0') then
      ret_val := '0';
    else
      ret_val := '1';
    end if;
    return ret_val;
  end convert_to_bit;
  
begin  -- rtl

  data_sync0_i : FD
  generic map (
    INIT => convert_to_bit(RESET_VALUE)
  )
  port map (
    C    => clk,
    D    => data_in,
    Q    => data_sync0
  );
    
  data_sync1_i : FD
  generic map (
    INIT => convert_to_bit(RESET_VALUE)
  )
  port map (
    C    => clk,
    D    => data_sync0,
    Q    => data_sync1
  );
    
  data_sync2_i : FD
  generic map (
    INIT => convert_to_bit(RESET_VALUE)
  )
  port map (
    C    => clk,
    D    => data_sync1,
    Q    => data_sync2
  );
    
  data_sync3_i : FD
  generic map (
    INIT => convert_to_bit(RESET_VALUE)
  )
  port map (
    C    => clk,
    D    => data_sync2,
    Q    => data_sync3
  );
    
  data_sync4_i : FD
  generic map (
    INIT => convert_to_bit(RESET_VALUE)
  )
  port map (
    C    => clk,
    D    => data_sync3,
    Q    => data_sync4
  );
    
  data_out <= data_sync4;

end rtl;
