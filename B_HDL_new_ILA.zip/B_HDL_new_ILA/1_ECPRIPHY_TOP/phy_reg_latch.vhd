--------------------------------------------------------------------------------
--                                                                            --
-- Copyright (C) 2013, Samsung Electronics Co., LTD. All Right Reserved.      --
--                                                                            --
-- Function   : Latch-up Register (Component, 32-bit)                         --
--                                                                            --
-- Author     : jaekyu.no (jaekyu.no@samsung.com)                             --
-- Department : SHT Lab. (Network Division)                                   --
-- Release    : 2013.09.05 (2014.03.28)                                       --
--                                                                            --
--------------------------------------------------------------------------------
-- Revision History                                                           --
--------------------------------------------------------------------------------
--   v1.0 - initial release                                                   --
--   v1.1 - decrease warning messages when synthesize                         --
--   v1.2 - logic optimized                                                   --
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity PHY_LATCH is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0);
        FLAG_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
end PHY_LATCH;

architecture BEHAVE of PHY_LATCH is

    signal data                     : std_logic_vector(BIT_WIDTH-1 downto 0);
    signal data_ret                 : std_logic_vector(BIT_WIDTH-1 downto 0);
    signal flag_ret                 : std_logic_vector(BIT_WIDTH-1 downto 0);

begin

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            data     <= (others => '0');
            data_ret <= (others => '0');
            flag_ret <= (others => '0');
            FLAG_OUT <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            for i in BIT_WIDTH-1 downto 0 loop
            data(i)     <= DATA_IN(i);
            data_ret(i) <= data(i);
            if (data_ret(i) = '1') then
                flag_ret(i) <= '1';
            elsif (EN = '1' and ADDR = REG_ADDR) then
                flag_ret(i) <= '0';
            end if;
            if (EN = '1' and ADDR = REG_ADDR) then
                FLAG_OUT(i) <= flag_ret(i);
            end if;
            end loop;
        end if;
    end process;

    DATA_OUT <= data_ret;

end BEHAVE;
