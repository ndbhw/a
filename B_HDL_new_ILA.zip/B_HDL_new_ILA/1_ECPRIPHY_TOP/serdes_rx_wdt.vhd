----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date: 07/20/2016 03:44:46 PM
-- Design Name:
-- Module Name: serdes_rx_wdt - Behavioral
-- Project Name:
-- Target Devices:
-- Tool Versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity serdes_rx_wdt is
    generic (
        SERDES_TYPE                         : string := "CPRI_SERDES"  --CPRI_SERDES, SBIF_SERDES
    );
    port(
        RESET                               : in  std_logic;
        CLK                                 : in  std_logic;

        WDT_EN                              : in  std_logic;
        RX_ERROR                            : in  std_logic;
        WDT_RESET                           : out std_logic
    );
end serdes_rx_wdt;

architecture Behavioral of serdes_rx_wdt is

type WDT_STATE is (LINK_IDLE, LINK_UP_WAIT, LINK_MON, WDT_RX_RESET);
signal serdes_wdt_state  : WDT_STATE;

signal link_up_wait_cnt            : std_logic_vector(23 downto 0); --40ms count
signal link_mon_cnt                : std_logic_vector(23 downto 0); --10ms count
signal error_cnt                   : std_logic_vector(3 downto 0);
signal reset_cnt                   : std_logic_vector(3 downto 0);
signal watchdog_reset              : std_logic;

signal link_up_wait_cnt_constant   : std_logic_vector(23 downto 0) := x"3D0900";    --40ms
signal link_mon_cnt_constant       : std_logic_vector(23 downto 0) := x"0F4240";    --10ms

begin

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            WDT_RESET <= '0';
        elsif(CLK'event and CLK = '1')then
            if(WDT_EN = '1')then
                WDT_RESET <= watchdog_reset;
            else
                WDT_RESET <= '0';
            end if;
        end if;
    end process;

    process(RESET, CLK)
    begin
        if(RESET = '1')then
            serdes_wdt_state <= LINK_IDLE;
            link_up_wait_cnt <= (others => '0');
            link_mon_cnt <= (others => '0');
            error_cnt <= (others => '0');
            reset_cnt <= (others => '0');
            watchdog_reset <= '0';
        elsif(CLK'event and CLK = '1')then
            case serdes_wdt_state is
                when LINK_IDLE =>
                    if(RX_ERROR = '1')then
--                    if(error_cnt >= 4)then
                        serdes_wdt_state <= LINK_UP_WAIT;
                    else
                        serdes_wdt_state <= LINK_IDLE;
                    end if;
                    if(RX_ERROR = '1')then
                        error_cnt <= error_cnt + 1;
                    end if;
                    link_up_wait_cnt <= (others => '0');
                    link_mon_cnt <= (others => '0');
                    reset_cnt <= (others => '0');
                    watchdog_reset <= '0';
                when LINK_UP_WAIT =>
                    if(link_up_wait_cnt = link_up_wait_cnt_constant)then --40ms
                        serdes_wdt_state <= LINK_MON;
                    else
                        serdes_wdt_state <= LINK_UP_WAIT;
                    end if;
                    if(link_up_wait_cnt = link_up_wait_cnt_constant)then
                        link_up_wait_cnt <= link_up_wait_cnt;
                    else
                        link_up_wait_cnt <= link_up_wait_cnt + 1;
                    end if;
                    error_cnt <= (others => '0');
                    link_mon_cnt <= (others => '0');
                    reset_cnt <= (others => '0');
                    watchdog_reset <= '0';
                when LINK_MON =>
                    if(RX_ERROR = '1')then
                        serdes_wdt_state <= WDT_RX_RESET;
                    elsif(link_mon_cnt = link_mon_cnt_constant)then --10ms
                        serdes_wdt_state <= LINK_IDLE;
                    else
                        serdes_wdt_state <= LINK_MON;
                    end if;
                    if(link_mon_cnt = link_mon_cnt_constant)then
                        link_mon_cnt <= link_mon_cnt;
                    else
                        link_mon_cnt <= link_mon_cnt + 1;
                    end if;
                    error_cnt <= (others => '0');
                    link_up_wait_cnt <= (others => '0');
                    reset_cnt <= (others => '0');
                    watchdog_reset <= '0';
                when WDT_RX_RESET =>
                    if(reset_cnt = x"f")then --16clk
                        serdes_wdt_state <= LINK_IDLE;
                    else
                        serdes_wdt_state <= WDT_RX_RESET;
                    end if;
                    if(reset_cnt = x"f")then
                        reset_cnt <= reset_cnt;
                    else
                        reset_cnt <= reset_cnt + 1;
                    end if;
                    error_cnt <= (others => '0');
                    link_up_wait_cnt <= (others => '0');
                    link_mon_cnt <= (others => '0');
                    watchdog_reset <= '1';
                when others =>
                    serdes_wdt_state <= LINK_IDLE;
                    error_cnt <= (others => '0');
                    link_up_wait_cnt <= (others => '0');
                    link_mon_cnt <= (others => '0');
                    reset_cnt <= (others => '0');
                    watchdog_reset <= '0';
            end case;
        end if;
    end process;

end Behavioral;
