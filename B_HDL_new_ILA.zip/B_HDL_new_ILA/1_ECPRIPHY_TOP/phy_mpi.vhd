----------------------------------------------------------------------------------
-- Company:
-- Engineer:
--
-- Create Date: 03/02/2021 01:17:47 PM
-- Design Name:
-- Module Name: phy_mpi - Behavioral
-- Project Name:
-- Target Devices:
-- Tool Versions:
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;
use WORK.ARRAY_TYPE.ALL;

entity phy_mpi is
    generic (
        TILE_NUM                    : natural := 1;
        CHANNEL_NUM                 : natural := 2
    );
    port (
--------------------------------------------------------------------------------
-- Clock & Reset
--------------------------------------------------------------------------------

        CLK                         : in  std_logic;
        RESET                       : in  std_logic;

--------------------------------------------------------------------------------
-- PHY channel
--------------------------------------------------------------------------------

        OTRX_DEL                    : in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_LOS                    : in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_TXFAULT                : in  std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_DISABLE                : out std_logic_vector(CHANNEL_NUM-1 downto 0);
        OTRX_BH_RS_OUT              : out std_logic_array2(CHANNEL_NUM-1 downto 0);

        ECPRI_GT_RESET_RX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_GT_RESET_TX_DONE      : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_BLOCK_LOCK    : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_LOCAL_FAULT   : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_RATE_10G_25GN : in  std_logic_vector(1 downto 0);
        ECPRI_STAT_RX_REMOTE_FAULT  : in  std_logic_vector(1 downto 0);          
        ECPRI_GT_RXLPMEN            : out std_logic_vector(1 downto 0);
        ECPRI_GT_TXDIFFCTRL         : out std_logic_array5(1 downto 0);
        ECPRI_TXPRECURSOR           : out std_logic_array5(1 downto 0);
        ECPRI_TXPOSTCUSOR           : out std_logic_array5(1 downto 0);
        MODE_CHANGE_25N_10H         : out std_logic_vector(1 downto 0);                     -- Low : 25G, High : 10G
        RX_WDT_ENABLE               : out std_logic_vector(1 downto 0);
        MAC_SYS_RESET               : out std_logic;
        DMA_BLOCK_RESET             : out std_logic;

--------------------------------------------------------------------------------
-- CPU
--------------------------------------------------------------------------------

        WREN_CPUIF_IN               : in  std_logic;
        RDEN_CPUIF_IN               : in  std_logic;
        ADDR_CPUIF_IN               : in  std_logic_vector(15 downto 0);
        WDATA_CPUIF_IN              : in  std_logic_vector(31 downto 0);
        RDATA_CPUIF_OUT             : out std_logic_vector(31 downto 0);
        RDVAL_CPUIF_OUT             : out std_logic
    );
end phy_mpi;

architecture Behavioral of phy_mpi is

    signal we_buf                   : std_logic;
    signal we                       : std_logic_vector(15 downto 0);
    signal we_long                  : std_logic_vector(15 downto 0);
    signal oe_buf                   : std_logic;
    signal oe                       : std_logic_vector(15 downto 0);
    signal oe_long                  : std_logic_vector(15 downto 0);
    signal addr_msb                 : std_logic_vector(3 downto 0);
    signal addr_lsb                 : std_logic_vector(7 downto 0);
    signal valid                    : std_logic_vector(3 downto 0);

    component PHY_WRITE is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0');
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
    end component;

    component PHY_CDC is
    generic (
        REG_DATA                    : std_logic_vector(31 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK_IN                      : in  std_logic;
        CLK_OUT                     : in  std_logic;

        DATA_IN                     : in  std_logic_vector(31 downto 0);
        DATA_OUT                    : out std_logic_vector(31 downto 0)
    );
    end component;

    component PHY_LATCH is
    generic (
        BIT_WIDTH                   : natural := 32;
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_IN                     : in  std_logic_vector(BIT_WIDTH-1 downto 0);
        DATA_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0);
        FLAG_OUT                    : out std_logic_vector(BIT_WIDTH-1 downto 0)
    );
    end component;

    component PHY_CLEAR is
    generic (
        REG_ADDR                    : std_logic_vector(7 downto 0) := (others => '0')
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        CLK_TARGET                  : in  std_logic;

        EN                          : in  std_logic;
        ADDR                        : in  std_logic_vector(7 downto 0);
        DATA_OUT                    : out std_logic
    );
    end component;

    -- ..._w : write
    -- ..._r : read
    -- ..._c : CDC
    -- ..._s : status
    -- ..._f : flag

    signal test_ctrl0_w             : std_logic_vector(31 downto 0);
    signal test_ctrl0_r             : std_logic_vector(31 downto 0) := (others => '0');

    signal optic_disable_w          : std_logic_vector(31 downto 0);
    signal optic_disable_r          : std_logic_vector(31 downto 0) := (others => '0');
    signal optic_bh_rs_w            : std_logic_vector(31 downto 0);
    signal optic_bh_rs_r            : std_logic_vector(31 downto 0) := (others => '0');

    signal phy_status_r             : std_logic_array32(7 downto 0) := (others => (others => '0'));
    signal phy_status_s             : std_logic_array32(7 downto 0);
    signal phy_status_f             : std_logic_array32(7 downto 0);

    signal tx_precursor0_w          : std_logic_vector(31 downto 0);
    signal tx_precursor0_r          : std_logic_vector(31 downto 0) := (others => '0');
    signal tx_precursor1_w          : std_logic_vector(31 downto 0);
    signal tx_precursor1_r          : std_logic_vector(31 downto 0) := (others => '0');
    signal tx_postcursor0_w         : std_logic_vector(31 downto 0);
    signal tx_postcursor0_r         : std_logic_vector(31 downto 0) := (others => '0');
    signal tx_postcursor1_w         : std_logic_vector(31 downto 0);
    signal tx_postcursor1_r         : std_logic_vector(31 downto 0) := (others => '0');
    signal tx_diffctrl0_w           : std_logic_vector(31 downto 0);
    signal tx_diffctrl0_r           : std_logic_vector(31 downto 0) := (others => '0');
    signal tx_diffctrl1_w           : std_logic_vector(31 downto 0);
    signal tx_diffctrl1_r           : std_logic_vector(31 downto 0) := (others => '0');
    signal rx_lpm_en_w              : std_logic_vector(31 downto 0);
    signal rx_lpm_en_r              : std_logic_vector(31 downto 0) := (others => '0');
    signal mode_change_25n_10h_w    : std_logic_vector(31 downto 0);
    signal mode_change_25n_10h_r    : std_logic_vector(31 downto 0) := (others => '0');
    signal mac_sys_reset_w          : std_logic_vector(31 downto 0);
    signal mac_sys_reset_r          : std_logic_vector(31 downto 0) := (others => '0');
    signal dma_block_reset_w        : std_logic_vector(31 downto 0);
    signal dma_block_reset_r        : std_logic_vector(31 downto 0) := (others => '0');
    signal rx_wdt_enable_w          : std_logic_vector(31 downto 0);
    signal rx_wdt_enable_r          : std_logic_vector(31 downto 0) := (others => '0');
    signal ecpri_current_rate_r     : std_logic_vector(31 downto 0) := (others => '0');

begin

--------------------------------------------------------------------------------
-- WE/OE, address decoding
--------------------------------------------------------------------------------

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            we_buf <= '0';
            oe_buf <= '0';
        elsif (CLK'event and CLK = '1') then
            we_buf <= WREN_CPUIF_IN;
            oe_buf <= RDEN_CPUIF_IN;
        end if;
    end process;

    -- read/write (short pulse)
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            we <= (others => '0');
            oe <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            for i in 15 downto 0 loop
            if (ADDR_CPUIF_IN(15 downto 12) = x"1") and (addr_msb = i) then
                if (WREN_CPUIF_IN = '1') and (we_buf = '0') then        we(i) <= '1';
                else                                                    we(i) <= '0';
                end if;
                if (RDEN_CPUIF_IN = '1') and (oe_buf = '0') then        oe(i) <= '1';
                else                                                    oe(i) <= '0';
                end if;
            end if;
            end loop;
        end if;
    end process;

    -- read/write (long pulse)
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            we_long <= (others => '0');
            oe_long <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            for i in 15 downto 0 loop
            if (ADDR_CPUIF_IN(15 downto 12) = x"1") and (addr_msb = i) then
                we_long(i) <= WREN_CPUIF_IN;
                oe_long(i) <= RDEN_CPUIF_IN;
            else
                we_long(i) <= '0';
                oe_long(i) <= '0';
            end if;
            end loop;
        end if;
    end process;

    addr_msb <= ADDR_CPUIF_IN(11 downto 8);
    addr_lsb <= ADDR_CPUIF_IN(7 downto 0);

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            valid           <= (others => '0');
            RDVAL_CPUIF_OUT <= '0';
        elsif (CLK'event and CLK = '1') then
            valid           <= valid(2 downto 0) & RDEN_CPUIF_IN;
            if (valid(3 downto 2) = "01") then
                RDVAL_CPUIF_OUT <= '1';
            else
                RDVAL_CPUIF_OUT <= '0';
            end if;
        end if;
    end process;

--------------------------------------------------------------------------------
-- Read Mux
--------------------------------------------------------------------------------

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            RDATA_CPUIF_OUT <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            case addr_msb is
            when x"0"   =>
                case addr_lsb is
                when x"00"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"01"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"02"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"03"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"04"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"05"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"06"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"07"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"08"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"09"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"0A"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"0B"  => RDATA_CPUIF_OUT <= (others => '0');
                when x"0C"  => RDATA_CPUIF_OUT <= test_ctrl0_r;

                when x"10"  => RDATA_CPUIF_OUT <= optic_disable_r;
                when x"11"  => RDATA_CPUIF_OUT <= optic_bh_rs_r;

                when x"40"  => RDATA_CPUIF_OUT <= phy_status_f(0);
                when x"41"  => RDATA_CPUIF_OUT <= phy_status_s(0);
                when x"42"  => RDATA_CPUIF_OUT <= phy_status_f(1);
                when x"43"  => RDATA_CPUIF_OUT <= phy_status_s(1);
                when x"44"  => RDATA_CPUIF_OUT <= phy_status_f(2);
                when x"45"  => RDATA_CPUIF_OUT <= phy_status_s(2);
                when x"46"  => RDATA_CPUIF_OUT <= phy_status_f(3);
                when x"47"  => RDATA_CPUIF_OUT <= phy_status_s(3);
                when x"48"  => RDATA_CPUIF_OUT <= phy_status_f(4);
                when x"49"  => RDATA_CPUIF_OUT <= phy_status_s(4);
                when x"4A"  => RDATA_CPUIF_OUT <= phy_status_f(5);
                when x"4B"  => RDATA_CPUIF_OUT <= phy_status_s(5);
                when x"4C"  => RDATA_CPUIF_OUT <= phy_status_f(6);
                when x"4D"  => RDATA_CPUIF_OUT <= phy_status_s(6);
                when x"4E"  => RDATA_CPUIF_OUT <= phy_status_f(7);
                when x"4F"  => RDATA_CPUIF_OUT <= phy_status_s(7);

                when others => RDATA_CPUIF_OUT <= (others => '0');
                end case;
            when x"1"   =>
                case addr_lsb is
                when x"02"  => RDATA_CPUIF_OUT <= tx_precursor0_r;
                when x"03"  => RDATA_CPUIF_OUT <= tx_precursor1_r;
                when x"04"  => RDATA_CPUIF_OUT <= tx_postcursor0_r;
                when x"05"  => RDATA_CPUIF_OUT <= tx_postcursor1_r;
                when x"06"  => RDATA_CPUIF_OUT <= tx_diffctrl0_r;
                when x"07"  => RDATA_CPUIF_OUT <= tx_diffctrl1_r;
                when x"08"  => RDATA_CPUIF_OUT <= rx_lpm_en_r;
                when x"09"  => RDATA_CPUIF_OUT <= mode_change_25n_10h_r;
                when x"0A"  => RDATA_CPUIF_OUT <= mac_sys_reset_r;
                when x"0B"  => RDATA_CPUIF_OUT <= dma_block_reset_r;
                when x"0C"  => RDATA_CPUIF_OUT <= rx_wdt_enable_r;
                when x"0D"  => RDATA_CPUIF_OUT <= ecpri_current_rate_r;
                when others => RDATA_CPUIF_OUT <= (others => '0');
                end case;
            when others =>
                RDATA_CPUIF_OUT <= (others => '0');
            end case;
        end if;
    end process;

--------------------------------------------------------------------------------
-- In/output port mapping
--------------------------------------------------------------------------------
    MAC_SYS_RESET            <= mac_sys_reset_w(0);
    DMA_BLOCK_RESET          <= dma_block_reset_w(0);

    u_CHANNEL : for i in CHANNEL_NUM-1 downto 0 generate
    OTRX_DISABLE(i)          <= optic_disable_w(i*4);
    OTRX_BH_RS_OUT(i)(0)     <= optic_bh_rs_w(i*4);
    OTRX_BH_RS_OUT(i)(1)     <= optic_bh_rs_w(i*4+1);
    ECPRI_GT_RXLPMEN(i)      <= rx_lpm_en_w(i*4);
    MODE_CHANGE_25N_10H(i)   <= mode_change_25n_10h_w(i*4);
    RX_WDT_ENABLE(i)         <= rx_wdt_enable_w(i*4);
    end generate;

    u_CHANNEL_0_to_3 : if CHANNEL_NUM < 4 generate
    u_CHANNEL : for i in CHANNEL_NUM-1 downto 0 generate
    ECPRI_TXPRECURSOR(i)     <= tx_precursor0_w((i+1)*8-4 downto i*8);
    ECPRI_TXPOSTCUSOR(i)     <= tx_postcursor0_w((i+1)*8-4 downto i*8);
    ECPRI_GT_TXDIFFCTRL(i)   <= tx_diffctrl0_w((i+1)*8-4 downto i*8);
    end generate;
    end generate;

    u_CHANNEL_0_to_7 : if CHANNEL_NUM < 8 and CHANNEL_NUM > 3 generate
    u_CHANNEL_0_to_3 : for i in 3 downto 0 generate
    ECPRI_TXPRECURSOR(i)     <= tx_precursor0_w((i+1)*8-4 downto i*8);
    ECPRI_TXPOSTCUSOR(i)     <= tx_postcursor0_w((i+1)*8-4 downto i*8);
    ECPRI_GT_TXDIFFCTRL(i)   <= tx_diffctrl0_w((i+1)*8-4 downto i*8);
    end generate;
    u_CHANNEL_0_to_7 : for i in CHANNEL_NUM-5 downto 4 generate
    ECPRI_TXPRECURSOR(i+4)   <= tx_precursor1_w((i+1)*8-4 downto i*8);
    ECPRI_TXPOSTCUSOR(i+4)   <= tx_postcursor1_w((i+1)*8-4 downto i*8);
    ECPRI_GT_TXDIFFCTRL(i+4) <= tx_diffctrl1_w((i+1)*8-4 downto i*8);
    end generate;
    end generate;

--------------------------------------------------------------------------------
-- Read register
--------------------------------------------------------------------------------

    test_ctrl0_r        	<= test_ctrl0_w;
    mac_sys_reset_r     	<= mac_sys_reset_w;
    dma_block_reset_r   	<= dma_block_reset_w;
    optic_disable_r  		<= optic_disable_w;
    optic_bh_rs_r    		<= optic_bh_rs_w;
    rx_lpm_en_r      		<= rx_lpm_en_w;
    mode_change_25n_10h_r 	<= mode_change_25n_10h_w;
    rx_wdt_enable_r			<= rx_wdt_enable_w;

    u_REGISTER_READ : for i in CHANNEL_NUM-1 downto 0 generate
    phy_status_r(i)(0)  <= OTRX_DEL(i);
    phy_status_r(i)(4)  <= '0';
    phy_status_r(i)(5)  <= '0';
    phy_status_r(i)(6)  <= '0';

    phy_status_r(i)(8)  <= OTRX_LOS(i);
    phy_status_r(i)(9)  <= '0';
    phy_status_r(i)(10) <= '0';
    phy_status_r(i)(12) <= (not ECPRI_GT_RESET_RX_DONE(i));
    phy_status_r(i)(13) <= (not ECPRI_STAT_RX_BLOCK_LOCK(i));
    phy_status_r(i)(14) <= ECPRI_STAT_RX_LOCAL_FAULT(i);
    phy_status_r(i)(15) <= ECPRI_STAT_RX_REMOTE_FAULT(i);      

    phy_status_r(i)(16) <= OTRX_TXFAULT(i);
    phy_status_r(i)(17) <= '0';
    phy_status_r(i)(18) <= '0';
    phy_status_r(i)(19) <= '0';
    phy_status_r(i)(20) <= (not ECPRI_GT_RESET_TX_DONE(i));
    phy_status_r(i)(21) <= '0';

    phy_status_r(i)(24) <= '0';
    phy_status_r(i)(25) <= '0';
    phy_status_r(i)(26) <= '0';
    phy_status_r(i)(27) <= '0';
    phy_status_r(i)(28) <= '0';

    ecpri_current_rate_r(i*4) <= ECPRI_STAT_RX_RATE_10G_25GN(i);
    end generate;

    u_READ_REGISTER_0_to_3 : if CHANNEL_NUM < 4 generate
    u_READ_REGISTER : for i in CHANNEL_NUM-1 downto 0 generate
    tx_precursor0_r(i*8+0)       <= tx_precursor0_w(i*8+0);
    tx_precursor0_r(i*8+1)       <= tx_precursor0_w(i*8+1);
    tx_precursor0_r(i*8+2)       <= tx_precursor0_w(i*8+2);
    tx_precursor0_r(i*8+3)       <= tx_precursor0_w(i*8+3);
    tx_precursor0_r(i*8+4)       <= tx_precursor0_w(i*8+4);
    tx_postcursor0_r(i*8+0)      <= tx_postcursor0_w(i*8+0);
    tx_postcursor0_r(i*8+1)      <= tx_postcursor0_w(i*8+1);
    tx_postcursor0_r(i*8+2)      <= tx_postcursor0_w(i*8+2);
    tx_postcursor0_r(i*8+3)      <= tx_postcursor0_w(i*8+3);
    tx_postcursor0_r(i*8+4)      <= tx_postcursor0_w(i*8+4);
    tx_diffctrl0_r(i*8+0)        <= tx_diffctrl0_w(i*8+0);
    tx_diffctrl0_r(i*8+1)        <= tx_diffctrl0_w(i*8+1);
    tx_diffctrl0_r(i*8+2)        <= tx_diffctrl0_w(i*8+2);
    tx_diffctrl0_r(i*8+3)        <= tx_diffctrl0_w(i*8+3);
    tx_diffctrl0_r(i*8+4)        <= tx_diffctrl0_w(i*8+4);
    end generate;
    end generate;

    u_READ_REGISTER_0_to_7 : if CHANNEL_NUM < 8 and CHANNEL_NUM > 3 generate
    u_READ_REGISTER_0_to_3 : for i in 3 downto 0 generate
    tx_precursor0_r(i*8+0)       <= tx_precursor0_w(i*8+0);
    tx_precursor0_r(i*8+1)       <= tx_precursor0_w(i*8+1);
    tx_precursor0_r(i*8+2)       <= tx_precursor0_w(i*8+2);
    tx_precursor0_r(i*8+3)       <= tx_precursor0_w(i*8+3);
    tx_precursor0_r(i*8+4)       <= tx_precursor0_w(i*8+4);
    tx_postcursor0_r(i*8+0)      <= tx_postcursor0_w(i*8+0);
    tx_postcursor0_r(i*8+1)      <= tx_postcursor0_w(i*8+1);
    tx_postcursor0_r(i*8+2)      <= tx_postcursor0_w(i*8+2);
    tx_postcursor0_r(i*8+3)      <= tx_postcursor0_w(i*8+3);
    tx_postcursor0_r(i*8+4)      <= tx_postcursor0_w(i*8+4);
    tx_diffctrl0_r(i*8+0)        <= tx_diffctrl0_w(i*8+0);
    tx_diffctrl0_r(i*8+1)        <= tx_diffctrl0_w(i*8+1);
    tx_diffctrl0_r(i*8+2)        <= tx_diffctrl0_w(i*8+2);
    tx_diffctrl0_r(i*8+3)        <= tx_diffctrl0_w(i*8+3);
    tx_diffctrl0_r(i*8+4)        <= tx_diffctrl0_w(i*8+4);
    end generate;
    u_READ_REGISTER_4_to_7 : for i in CHANNEL_NUM-5 downto 4 generate
    tx_precursor1_r(i*8+0)       <= tx_precursor1_w(i*8+0);
    tx_precursor1_r(i*8+1)       <= tx_precursor1_w(i*8+1);
    tx_precursor1_r(i*8+2)       <= tx_precursor1_w(i*8+2);
    tx_precursor1_r(i*8+3)       <= tx_precursor1_w(i*8+3);
    tx_precursor1_r(i*8+4)       <= tx_precursor1_w(i*8+4);
    tx_postcursor1_r(i*8+0)      <= tx_postcursor1_w(i*8+0);
    tx_postcursor1_r(i*8+1)      <= tx_postcursor1_w(i*8+1);
    tx_postcursor1_r(i*8+2)      <= tx_postcursor1_w(i*8+2);
    tx_postcursor1_r(i*8+3)      <= tx_postcursor1_w(i*8+3);
    tx_postcursor1_r(i*8+4)      <= tx_postcursor1_w(i*8+4);
    tx_diffctrl1_r(i*8+0)        <= tx_diffctrl1_w(i*8+0);
    tx_diffctrl1_r(i*8+1)        <= tx_diffctrl1_w(i*8+1);
    tx_diffctrl1_r(i*8+2)        <= tx_diffctrl1_w(i*8+2);
    tx_diffctrl1_r(i*8+3)        <= tx_diffctrl1_w(i*8+3);
    tx_diffctrl1_r(i*8+4)        <= tx_diffctrl1_w(i*8+4);
    end generate;
    end generate;

--------------------------------------------------------------------------------
-- Write register
--------------------------------------------------------------------------------

    u_0x100C_WRITE : PHY_WRITE generic map(x"0C", x"00000000") port map(RESET, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, test_ctrl0_w );
    u_0x1010_WRITE : PHY_WRITE generic map(x"10", x"00000011") port map(RESET, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, optic_disable_w );
    u_0x1011_WRITE : PHY_WRITE generic map(x"11", x"00000033") port map(RESET, CLK, we(0), addr_lsb, WDATA_CPUIF_IN, optic_bh_rs_w );

    u_0x1102_WRITE : PHY_WRITE generic map(x"02", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_precursor0_w );
    u_0x1103_WRITE : PHY_WRITE generic map(x"03", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_precursor1_w );
    u_0x1104_WRITE : PHY_WRITE generic map(x"04", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_postcursor0_w );
    u_0x1105_WRITE : PHY_WRITE generic map(x"05", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_postcursor1_w );
    u_0x1106_WRITE : PHY_WRITE generic map(x"06", x"07070707") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_diffctrl0_w );
    u_0x1107_WRITE : PHY_WRITE generic map(x"07", x"07070707") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, tx_diffctrl1_w );
    u_0x1108_WRITE : PHY_WRITE generic map(x"08", x"00000011") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_lpm_en_w );
    u_0x1109_WRITE : PHY_WRITE generic map(x"09", x"11111111") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, mode_change_25n_10h_w );
    u_0x110A_WRITE : PHY_WRITE generic map(x"0A", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, mac_sys_reset_w );
    u_0x110B_WRITE : PHY_WRITE generic map(x"0B", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, dma_block_reset_w );
    u_0x110C_WRITE : PHY_WRITE generic map(x"0C", x"00000000") port map(RESET, CLK, we(1), addr_lsb, WDATA_CPUIF_IN, rx_wdt_enable_w );

--------------------------------------------------------------------------------
-- CDC register
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Flag/status register
--------------------------------------------------------------------------------
-- link status registers for PTP
    u_0x1040_LATCH : PHY_LATCH generic map(32, x"40") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(0), phy_status_s(0), phy_status_f(0) );
    u_0x1042_LATCH : PHY_LATCH generic map(32, x"42") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(1), phy_status_s(1), phy_status_f(1) );
    u_0x1044_LATCH : PHY_LATCH generic map(32, x"44") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(2), phy_status_s(2), phy_status_f(2) );
    u_0x1046_LATCH : PHY_LATCH generic map(32, x"46") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(3), phy_status_s(3), phy_status_f(3) );
-- link status registers for RCM
    u_0x1048_LATCH : PHY_LATCH generic map(32, x"48") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(0), phy_status_s(4), phy_status_f(4) );
    u_0x104A_LATCH : PHY_LATCH generic map(32, x"4A") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(1), phy_status_s(5), phy_status_f(5) );
    u_0x104C_LATCH : PHY_LATCH generic map(32, x"4C") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(2), phy_status_s(6), phy_status_f(6) );
    u_0x104E_LATCH : PHY_LATCH generic map(32, x"4E") port map(RESET, CLK, oe(0), addr_lsb, phy_status_r(3), phy_status_s(7), phy_status_f(7) );

--------------------------------------------------------------------------------
-- Clear register
--------------------------------------------------------------------------------

end Behavioral;
