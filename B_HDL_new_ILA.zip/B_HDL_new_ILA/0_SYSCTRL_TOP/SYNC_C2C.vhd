library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_unsigned.ALL;


entity SYNC_C2C is
    port(
        RESET                               : in  std_logic;
        SYSCLK                              : in  std_logic;                     -- 245.76MHz
        SFN_SCALE                           : in  std_logic_vector(3 downto 0);
        FRAME_SYNC                          : in  std_logic;                    -- active high, 1 pulse @3.84 MHz
        SFN_NUM                             : in  std_logic_vector(11 downto 0);  
        TICK_10MS                           : out std_logic;                     -- active high(10ms -PROC_DLY @ 245.76 MHz)@SFN_NUM#0
        SFN_NUM_C2C                         : out std_logic_vector(11 downto 0);
        PROC_DLY                            : out std_logic_vector(31 downto 0);
        
        SYNC_ERR_CNT_CLR                    : in  std_logic;
        SYNC_ERR                            : out std_logic;
        SYNC_ERR_CNT                        : out std_logic_vector(15 downto 0)
    );
end SYNC_C2C;

architecture Behavioral of SYNC_C2C is

    signal   frame_sync_sft          : std_logic_vector(63 downto 0) :=(others => '0') ;
    signal   frame_sync_re_gen       : std_logic;
    signal   frame_sync_retime       : std_logic_vector( 3 downto 0) :=(others => '0') ;
    signal   sfn_rt                  : std_logic_vector(11 downto 0) :=(others =>'0') ;
    signal   c2c_enable              : std_logic :='0';
    signal   frame_sync_cnt          : std_logic_vector( 21 downto 0) :=(others =>'0') ;
    signal   sync_err_cnt_clr_sft    : std_logic_vector(2 downto 0);
    signal   err_cnt                 : std_logic_vector(15 downto 0)  :=(others =>'0');
    signal   err                     : std_logic:='0';
    signal   scale                   : integer range 0 to 11 ; 
begin
    scale <= conv_integer(SFN_SCALE) ;

    PROC_DLY   <= x"0000_0006"; 


    process (SYSCLK)
    begin
        if (SYSCLK'event and SYSCLK = '1') then
            frame_sync_sft <= frame_sync_sft(62 downto 0) & FRAME_SYNC ;
        end if;
    end process;

    process (SYSCLK)
    begin
        if (SYSCLK'event and SYSCLK = '1') then
            sfn_rt <= SFN_NUM(11 downto 0) ;
            SFN_NUM_C2C <= sfn_rt ; 
        end if;
    end process;

    process (SYSCLK)
    begin
        if (SYSCLK'event and SYSCLK = '1') then
            if frame_sync_sft(0) = '1' then
                frame_sync_re_gen <= '1';
            elsif frame_sync_sft(63) = '1' then
                frame_sync_re_gen <= '0';
            end if;
        end if;
    end process;



    process (SYSCLK)
    begin
        if (SYSCLK'event and SYSCLK = '1') then
            frame_sync_retime <= frame_sync_retime(2 downto 0) & frame_sync_re_gen  ;
        end if;
    end process;


    TICK_10MS <= frame_sync_retime (3) ;

--    process (SYSCLK)
--    begin
--        if (SYSCLK'event and SYSCLK = '1') then
--            if frame_sync_sft(2 downto 1) = "01" and SFN_NUM(scale downto 0) = 0 then
--                c2c_enable <= '1';
--            else
--                if SFN_NUM(scale downto 0) /= 0 then
--                    c2c_enable <= '0';
--                else
--                    c2c_enable <= c2c_enable ;
--                end if;
--            end if;
--        end if;
--    end process;
--
--    TICK_10MS <= c2c_enable ;
--
--    process (SYSCLK)
--    begin
--        if (SYSCLK'event and SYSCLK = '1') then
--            if frame_sync_sft(2 downto 1) = "01" or (frame_sync_cnt = 2457599)  then
--                frame_sync_cnt <= (others =>'0'); 
--            else
--                frame_sync_cnt <= frame_sync_cnt + 1; 
--            end if;
--         end if;
--    end process;
--
--    process (SYSCLK)
--    begin
--        if (SYSCLK'event and SYSCLK = '1') then
--            sync_err_cnt_clr_sft <= sync_err_cnt_clr_sft(1 downto 0) & SYNC_ERR_CNT_CLR ; 
--            if sync_err_cnt_clr_sft(2) = '1' then
--                err_cnt <= (others =>'0')  ;
--                err     <= '0'  ;
--            else
--                if frame_sync_sft (2 downto 1) = "01" then 
--                    if frame_sync_cnt = 2457599 then
--                        err_cnt <= err_cnt;
--                        err     <= '0'; 
--                    else
--                        err_cnt <= err_cnt + '1' ;
--                        err     <= '1';
--                    end if;
--                end if; 
--            end if; 
--       end if;
--    end process;
--
--SYNC_ERR     <= err ; 
--SYNC_ERR_CNT <= err_cnt ;

end Behavioral ;

