--======================================================================
--Title              :   Retriggered System Frame Sync 
--Project            :   
--Designed by        :   
--Last Update        :   
--======================================================================

library ieee;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;

entity GLBFS is
    generic(
        latency                : natural := 6   --5
    );
port (  
          RESET                             : in std_logic;
          PLL_LOCK                          : in std_logic; -- sys_pll lock
          CLK                               : in std_logic; -- sys_hclk,122.88MHz
          BFN_STRB                          : in std_logic; 
          BFN_NR                            : in std_logic_vector(11 downto 0); 
                                            
          BFN_FAIL                          : out std_logic;
          BFN_NR_FAIL                       : out std_logic;
                                            
          T80MS                             : out std_logic; -- active high
          T10MS                             : out std_logic; -- active high
          BFN_STRB_OUT                      : out std_logic; -- active high
          BFN_NR_OUT                        : out std_logic_vector(11 downto 0)
);
end GLBFS;

architecture arc_GLBFS of GLBFS is

    component RST_SYNC
    generic (
        DLY_NUM        : natural := 4;    -- Number of delay.
        MAX_FANOUT_NUM : integer := 200   -- Number of maximum fanout
    );
    port (
        RST_IN  : in  std_logic;          -- Active high asynchronous reset
        CLK     : in  std_logic;          -- clock to be sync'ed to
        RST_OUT : out std_logic           -- "Synchronised" reset signal
    );         
    end component;

    component reset_synchronizer  -- ksk 20131120
    port (
             reset_in                      : in  std_logic;          -- Active high asynchronous reset
             clk                           : in  std_logic;          -- clock to be sync'ed to
             reset_out                     : out std_logic);         -- "Synchronised" reset signal
    end component;
    
   signal i_sync_reset                  : std_logic; -- ksk 20131120
                                        
   signal temp                          : std_logic_vector(2 downto 0);
                                        
   signal bfn_strb_0                    : std_logic;
   signal bfn_sync_0                    : std_logic;
   signal bcnt_0                        : std_logic_vector(5 downto 0);
                                        
   signal local_nrcnt_0                 : std_logic_vector(12 downto 0);
                                        
   signal i_80ms                        : std_logic;
   signal bfnhigh_0                     : std_logic;
                                        
   signal bcnt_c                        : std_logic_vector(5 downto 0);
   signal bsync_c                       : std_logic;
   signal bfncnt_c                      : std_logic_vector(16 downto 0); -- 76800
                                        
   signal ibfn_lf                       : std_logic;
   signal ibfn_hf                       : std_logic;
   signal ibfn_fail                     : std_logic;
   signal reset_s0                      :std_logic;
   signal reset_s1                      :std_logic;
   signal free_bfn_strobe_pulse         : std_logic;
   signal free_bfn_strobe               : std_logic;
   signal i_80ms_dly                    : std_logic_vector(45 downto 0);
   signal i_80ms_100ns                  : std_logic;
                                        
   signal i_80ms_cnt                    : std_logic_vector(2 downto 0);  
   
begin

   BFN_NR_OUT  <= BFN_NR;

    u_reset_glbfs : RST_SYNC 
    generic map(
        DLY_NUM                         => 4                     ,    --: natural := 4; 
        MAX_FANOUT_NUM                  => 200                
    )    
    port map(
         RST_IN                         => RESET, 
         CLK                            => CLK, 
         RST_OUT                        => i_sync_reset
    ); 

   -- CPRI BFN/FS/EVEN Gen. -------------------------------
   -- latch bfn_strobe & gen bfn_sync
   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         temp       <= (others=>'0');
         bfn_strb_0 <= '0';
         bfn_sync_0 <= '0';
      elsif CLK'event and CLK='1' then 
         temp       <= temp(1 downto 0)&BFN_STRB;	-- BFN_STRB = 10ms
         bfn_strb_0 <= temp(1);
         bfn_sync_0 <= temp(1) and (not temp(2));
      end if;
   end process;

   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         bcnt_0  <= (others=>'0');
         local_nrcnt_0 <= (others => '0');
      elsif CLK'event and CLK='1' then 
         if bfn_sync_0='1' or bcnt_0=63 then
            bcnt_0  <= (others => '0');
         else 
            bcnt_0 <= bcnt_0 + 1;
         end if;
         if(bcnt_0 = (conv_std_logic_vector(0, 5)-1 - latency)) then 
             local_nrcnt_0 <= (others => '0');
         else 
             local_nrcnt_0 <= local_nrcnt_0 + 1;
         end if;
      end if;
   end process;

   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         i_80ms  <= '0';
         i_80ms_cnt <= (others => '0');
      elsif CLK'event and CLK='1' then 
            if free_bfn_strobe_pulse='1' then                         -- 10ms * 8 = 80ms			
               if(i_80ms_cnt = 7) then 
                   i_80ms_cnt <= (others => '0');
               else
                   i_80ms_cnt <= i_80ms_cnt + '1';
               end if;
            end if;
            if free_bfn_strobe_pulse='1' and  i_80ms_cnt=7 then       -- 10ms * 8 = 80ms			   
                i_80ms  <= '1';   
            else
                i_80ms  <= '0';
            end if;
      end if;
   end process;

   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         i_80ms_dly  <= (others => '0');
         i_80ms_100ns <= '0';
      elsif CLK'event and CLK='1' then 
         i_80ms_dly  <= i_80ms_dly(44 downto 0) & i_80ms;
         if(i_80ms = '1') then 
             i_80ms_100ns <= '1';
         elsif(i_80ms_dly(45) = '1') then 
             i_80ms_100ns <= '0';
         end if;
      end if;
   end process;

   -- 10ms
   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         bfnhigh_0  <= '1';
      elsif CLK'event and CLK='1' then 
         bfnhigh_0  <= free_bfn_strobe_pulse;                         -- bfn_sync_0 = 10ms
      end if;
   end process;

   -- BFN Fail Check ----------------------------
   -- basic frame(1/3.84MHz)
   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         bcnt_c   <= (others=>'0');
         bsync_c  <= '0';
      elsif CLK'event and CLK='1' then 
         if bfn_sync_0='1' or bcnt_c=63  then 
             bcnt_c   <= (others=>'0');
             bsync_c  <= '1';                                          -- basic frame = 1/3.84MHz = 32/122.88MHz
         else
             bcnt_c   <= bcnt_c + 1;
             bsync_c  <= '0';
         end if;
      end if;
   end process;

   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         bfncnt_c  <= (others=>'0');
      elsif CLK'event and CLK='1' then 
         if bsync_c='1' then
            if bfncnt_c=38399 or bfn_strb_0='1' then                  -- 256(bf) * 150(hf) = 38400 = 10ms bfn
               bfncnt_c <= (others=>'0');
            else
               bfncnt_c <= bfncnt_c + 1;
            end if;
         end if;
      end if;
   end process;
   
   process(i_sync_reset,CLK)
   begin
      if i_sync_reset='1' then
         ibfn_fail <= '0';
         ibfn_lf  <= '0';
         ibfn_hf  <= '0';
         free_bfn_strobe_pulse <= '0';
         free_bfn_strobe <= '0';
      elsif CLK'event and CLK='1' then
         if bsync_c='1'and bfncnt_c=38399 then
            if bfn_strb_0='1' then
               ibfn_lf <= '0';
            else
               ibfn_lf <= '1';
            end if;
         end if;

         if local_nrcnt_0=30 and bfncnt_c=38399 then
            free_bfn_strobe_pulse <= '1';
         else 
            free_bfn_strobe_pulse <= '0';         
         end if;

         if bfncnt_c=38399 and local_nrcnt_0 = 32 then
            free_bfn_strobe <= '1';
         else 
              if bfncnt_c=0 and local_nrcnt_0 = 32 then
                  free_bfn_strobe <= '0';         
              else
                  free_bfn_strobe <= free_bfn_strobe;
              end if;
         end if;

         if bsync_c='1'and bfn_strb_0='1' then
            if bfncnt_c=38399 then
               ibfn_hf <= '0';
            else
               ibfn_hf <= '1';
            end if;
         end if;
         
         ibfn_fail <= ibfn_lf or ibfn_hf;

      end if;
   end process;
  
   BFN_FAIL <= ibfn_fail; 
      
   BFN_NR_FAIL <= '0'; 
   ------------------------------------------------

    process(i_sync_reset,clk)
    begin
        if i_sync_reset = '1' then
            reset_s0 <= '1';
            reset_s1 <= '1';
        elsif clk'event and clk = '1' then
            reset_s0 <= not PLL_LOCK;
            reset_s1 <= reset_s0 ;
        end if;
    end process;


   process(reset_s1,CLK)
   begin
      if reset_s1='1' then
         T80MS        <= '1';
         T10MS        <= '1';
         BFN_STRB_OUT <= '0';
      elsif CLK'event and CLK='1' then 
            T80MS        <= i_80ms_100ns;
            T10MS        <= bfnhigh_0;
            BFN_STRB_OUT <= free_bfn_strobe;
      end if;
   end process;

end arc_GLBFS;