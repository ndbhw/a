-- RFIC Power Control.
-- Voltage, Temperature Measure by XADC
--------------
---- 2014.04.05 : KDDI Duablband
--------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity WATCHDOG is
port(
    RESET                       : in  std_logic;                        -- Synchronous Reset		
    CLK                         : in  std_logic;                        -- 100MHz Clock

    WATCHDOG_EN                 : in  std_logic;                        -- Async. Watchdog Enable
    WATCHDOG_CLR                : in  std_logic;                        -- Async. Watchdog Clear
    WDT_TIMER_SEC               : in  std_logic_vector(15 downto 0);    -- Watchdog timer (unit : second)
    CPU_FAIL                    : out std_logic
);
end WATCHDOG;

architecture Behavioral of WATCHDOG is

signal watchdog_en_d            : std_logic;    
signal watchdog_en_dd           : std_logic;    
signal watchdog_clr_d           : std_logic;    
signal watchdog_clr_dd          : std_logic;    

signal cnt_1ns                  : std_logic_vector(20 downto 0); 
signal tick_1ms                 : std_logic;
signal cnt_1ms                  : std_logic_vector(9 downto 0); 
signal tick_1sec                : std_logic;
signal cnt_sec                  : std_logic_vector(15 downto 0); 

begin
    
    process(RESET, CLK) 
    begin
        if RESET = '1' then
            watchdog_en_d  <= '0';
            watchdog_en_dd <= '0';
            watchdog_clr_d <= '0';
            watchdog_clr_dd<= '0';
        elsif rising_edge(CLK) then
            watchdog_en_d  <= WATCHDOG_EN;
            watchdog_en_dd <= watchdog_en_d;
            watchdog_clr_d <= WATCHDOG_CLR;
            watchdog_clr_dd<= watchdog_clr_d;
        end if;
    end process;

    -- 1 ms counter
    process(RESET, CLK) 
    begin
        if RESET = '1' then
            cnt_1ns     <= (others => '0'); 
            tick_1ms    <= '0';
        elsif rising_edge(CLK) then
            if cnt_1ns = 99999 then
                cnt_1ns     <= (others => '0'); 
                tick_1ms    <= '1';
            else
                cnt_1ns     <= cnt_1ns + 1;
                tick_1ms    <= '0';
            end if;
        end if;
    end process;

    -- 1 sec counter
    process(RESET, CLK) 
    begin
        if RESET = '1' then
            cnt_1ms     <= (others => '0'); 
            tick_1sec   <= '0';
        elsif rising_edge(CLK) then
            if tick_1ms = '1' then
                if cnt_1ms = 999 then
                    cnt_1ms     <= (others => '0'); 
                    tick_1sec   <= '1';
                else
                    cnt_1ms     <= cnt_1ms + 1;
                    tick_1sec   <= '0';
                end if;
            else
                tick_1sec   <= '0';
            end if;
        end if;
    end process;

    -- 60 sec counter
    process(RESET, CLK) 
    begin
        if RESET = '1' then
            cnt_sec    <= (others => '0'); 
        elsif rising_edge(CLK) then
            if watchdog_en_dd = '1' and watchdog_clr_dd = '0' then
                if tick_1sec = '1' then
                    if cnt_sec = WDT_TIMER_SEC then
                        cnt_sec <= cnt_sec; 
                    else
                        cnt_sec <= cnt_sec + 1;
                    end if;
                end if;
            else
                cnt_sec    <= (others => '0'); 
            end if;
        end if;
    end process;

    -- Watchdog 
    process(RESET, CLK) 
    begin
        if RESET = '1' then
            CPU_FAIL <= '0';
        elsif rising_edge(CLK) then
            if cnt_sec >= WDT_TIMER_SEC then
                CPU_FAIL <= '1';
            else
                CPU_FAIL <= '0';
            end if;
        end if;
    end process;

end Behavioral;






