----------------------------------------------------------------------------------
-- Company: SEC
-- Engineer:
--
-- Create Date: 2016-10-08 AM 09:40:53
-- Design Name: jinoo.bae
-- Module Name: CPUIF_SYSCTRL - Behavioral
-- Project Name: FD-MIMO
-- Target Devices: ZYNQ035_2LI
-- Tool versions: vivado20162
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
use work.ARRAY_TYPE.all;
use work.RU_FPGA_FNC.all;
use work.RU_FPGA_CONFIG.all;

entity CPUIF_SYSCTRL is
generic(
        LED_NUM                         : natural:= 4;
        CPRI_NUM                        : natural:= 6;
        IQCOMP_NUM                      : natural:= 6;
        SBIF_NUM                        : natural:= 6;
        TX_ANT_NUM                      : natural:= 8;
        CSREF_NUM                       : natural:= 6;
        JSREF_NUM                       : natural:= 6;
        SSREF_NUM                       : natural:= 6;
        C_SYSCTRL_IMG_DATE              : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"2016_1010";
        C_SYSCTRL_IMG_VER               : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0001";
        C_SYSCTRL_SYSTEM_INFO0          : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0002";     -- air_tech[3:0]
        C_SYSCTRL_SYSTEM_INFO1          : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";     -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO2          : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";     -- freq_band[7:0]
        C_SYSCTRL_SYSTEM_INFO3          : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0232_3206";     -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
        C_SYSCTRL_PBA_INFO              : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";
        C_SYSCTRL_DEV_INFO              : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";
        C_SYSCTRL_MODULE_INFO           : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0001";
        C_SYSCTRL_STRUCT_INFO           : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"0000_0000";
        C_SYSCTRL_MODULE_DATE           : STD_LOGIC_VECTOR(31 DOWNTO 0):= X"2016_1010"
    );
port(

    FPGA_ID                                 : in  std_logic_vector(3 downto 0);
    FPGA_PCB_VER                            : in  std_logic_vector(2 downto 0);

	PSU_VER                                 : in  std_logic;

    BIAST_3P3V_EN                           : out std_logic;

-- COMMON_FPGA
    CLK_CPUIF                               : in  std_logic;
    RST_CPUIF                               : in  std_logic;

    ADDR_CPUIF_SYSCTRL                      : in  std_logic_vector(15 downto 0);
    WDATA_CPUIF_SYSCTRL                     : in  std_logic_vector(31 downto 0);
    RDATA_CPUIF_SYSCTRL                     : out std_logic_vector(31 downto 0);
    WREN_CPUIF_SYSCTRL                      : in  std_logic;
    RDEN_CPUIF_SYSCTRL                      : in  std_logic;
    RDVAL_CPUIF_SYSCTRL                     : out std_logic;

-- COMMON_FPGA
    SYSCTRL_IPLL_RST                        : out std_logic_vector(2 downto 0);

-- CTRL_FPGA
    SYSCTRL_IQCOMP_RST                      : out std_logic_vector(IQCOMP_NUM - 1 downto 0);
    SYSCTRL_ETHMUX_RST                      : out std_logic;
    SYSCTRL_SBIF_RST                        : out std_logic_vector(SBIF_NUM - 1 downto 0);
    SYSCTRL_SBIFPHY_RST                     : out std_logic_vector(SBIF_NUM - 1 downto 0);

    SYSCTRL_PIM_RST                         : out std_logic;
    SYSCTRL_PIM_SBIF_RST                    : out std_logic;
    SYSCTRL_PIM_SBIF_PHY_RST                : out std_logic;

-- DSP_FPGA
    SYSCTRL_BBCTRL_RST                      : out std_logic;
--    SYSCTRL_DSP_RST                         : out std_logic;
    SYSCTRL_DDUC_RST                        : out std_logic;
    SYSCTRL_CFR_RST                         : out std_logic;
    SYSCTRL_DPD_RST                         : out std_logic;
    SYSCTRL_DCIF_RST                        : out std_logic;

---- CTRL_FPGA
    VSS_RMT_RST_CPRI                        : in  std_logic_vector(CPRI_NUM - 1 downto 0);
    SYSCTRL_FUNC_FAIL_TRIG                  : in  std_logic_vector(1 downto 0);   -- need to check

-- COMMON_FPGA
    SYSCTRL_CLK_FAIL_TRIG                   : in  std_logic_vector(31 downto 0);
    EXT_SYSPLL_INTERRUPT_IN                 : in  std_logic;
    
---- CTRL_FPGA
    SYSCTRL_LED_CTRL                        : out std_logic_array4(LED_NUM - 1 downto 0);
    SYSCTRL_HW_WDT_CTRL                     : out std_logic_vector(31 downto 0);

---- CTRL_FPGA
    SYSCTRL_BFN_STRB_CTRL                   : out std_logic_array32(CPRI_NUM - 1 downto 0);

    DL_INNER_FRAME_OFFSET                   : out std_logic_array19(CPRI_NUM - 1 downto 0);
    DL_INNER_ON                             : out std_logic_array15(CPRI_NUM - 1 downto 0);
    DL_INNER_OFF                            : out std_logic_array15(CPRI_NUM - 1 downto 0);

    -- UL Nta offset
    UL_INNER_FRAME_OFFSET                   : out std_logic_vector(18 downto 0);    -- UL-DL frame timing(624 Ts)
    UL_INNER_ON                             : out std_logic_vector(14 downto 0);
    UL_INNER_OFF                            : out std_logic_vector(14 downto 0);

    TDD_AND_CTRL                            : out std_logic_array32(1 downto 0);
    TDD_OR_CTRL                             : out std_logic_array32(1 downto 0);

    RX_BFN_FAIL                             : in  std_logic_vector(CPRI_NUM - 1 downto 0);
    RX_ABN_CNT                              : in  std_logic_array8(CPRI_NUM - 1 downto 0);

    SYSCTRL_TDD_CTRL                        : out std_logic_vector(31 downto 0);

    VSS_RMT_RST                             : out std_logic;
    
    NR_SSB_PERIOD                           : out std_logic_vector(4 downto 0);
    NR_SSB_OFFSET                           : out std_logic_vector(3 downto 0);
    
    SECTOR_MODE                             : out std_logic_vector(1 downto 0); 
    eMTC_SEL                                : out std_logic_vector(1 downto 0); 
-- COMMON_FPGA
    SYSCTRL_RUID                            : out std_logic_vector(3 downto 0);
    SYSCTRL_RU_FF                           : out std_logic;
    SYSCTRL_MISC_RST                        : out std_logic;

--    SYSCTRL_ECPRIPHY_RST                    : out std_logic_vector( ECPRIPHY_NUM -1 downto 0 )  ; 
    SYSCTRL_ORAN_FRAMER_RST                 : out std_logic_vector( DL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_ORAN_DEFRAMER_RST               : out std_logic_vector( UL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_LPHY_TOP_RST                    : out std_logic_vector( DL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_DLFE_RST                        : out std_logic_vector( DL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_ULFE_RST                        : out std_logic_vector( UL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_RAFE_RST                        : out std_logic_vector( UL_NUM_CC    -1 downto 0 )  ; 
    SYSCTRL_AURORA_RST                      : out std_logic;

	DL_CC0_SYNC_ADVANCE                     : out std_logic_vector(21 downto 0);
    DL_CC1_SYNC_ADVANCE                     : out std_logic_vector(21 downto 0);
    UL_CC0_SYNC_RETARD                      : out std_logic_vector(21 downto 0);
    UL_CC1_SYNC_RETARD                      : out std_logic_vector(21 downto 0);
    N_TA_OFFSET_CC0                         : out  std_logic_vector(15 downto 0);
    N_TA_OFFSET_CC1                         : out  std_logic_vector(15 downto 0);
    
    TP_CON_SEL                              : out std_logic_vector(7 downto 0);

    SFN_SCALE                               : out std_logic_vector(3 downto 0);
    C2C_SYNC_PROC_DLY                       : in  std_logic_vector(31 downto 0);
    SYNC_ERR_CNT_CLR                        : out std_logic;
    SYNC_ERR                                : in  std_logic;
    SYNC_ERR_CNT                            : in  std_logic_vector(15 downto 0)

    );
end CPUIF_SYSCTRL;

architecture ARC_CPUIF_OTHERS of CPUIF_SYSCTRL is

    component REG32_WRITE is
    generic (
        BIT_ENABLE                        : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                          : std_logic_vector( 7 downto 0) := (others => '0'); -- Register address
        REG_DATA                          : std_logic_vector(31 downto 0) := (others => '0')  -- Default value
    );
    port (
        RST                               : in  std_logic;                                    -- reset, '1': reset
        CLK                               : in  std_logic;                                    -- clock

        EN                                : in  std_logic;                                    -- Write enable
        ADDR                              : in  std_logic_vector( 7 downto 0);                -- Input Address
        DATA_IN                           : in  std_logic_vector(31 downto 0);                -- Data input
        DATA_OUT                          : out std_logic_vector(31 downto 0)                 -- Data output
    );
    end component;

    component REG32_LATCH
    generic(
        BIT_ENABLE                        : std_logic_vector(31 downto 0) := (others => '1');
        REG_ADDR                          : std_logic_vector( 7 downto 0) := (others => '0')
        );
    port(
        RST                               : in  std_logic;
        CLK                               : in  std_logic;

        CLR_IN                            : in  std_logic;                                        -- Clear input, falling edge detection
        ADDR_IN                           : in  std_logic_vector( 7 downto 0);                    -- Address input
        DATA_IN                           : in  std_logic_vector(31 downto 0);
        DATA_OUT                          : out std_logic_vector(31 downto 0);
        FLAG_OUT                          : out std_logic_vector(31 downto 0)
        );
    end component;

signal rden_dly                             : std_logic_vector(7 downto 0);   -- Read Enable Signal Delay
signal addrl8b                              : std_logic_vector(7 downto 0);   -- Address Low 8Bit
signal wdata                                : std_logic_vector(31 downto 0);  -- CPU Write Data
signal rdata                                : std_logic_vector(31 downto 0);  -- CPU Read Data
signal wren_d1                              : std_logic;                      -- 1-Clock Delayed Write Enable
signal wren_d2                              : std_logic;                      -- 2-Clock Delayed Write Enable
signal wren_pls                             : std_logic;                      -- Write Enable 1-Clock Pulse
signal rden_d1                              : std_logic;                      -- 1-Clock Delayed Read Enable
signal rden_strobe                          : std_logic;                      -- 2-Clock Delayed Read Strobe
signal rdval_pls                            : std_logic;                      -- Read Data Valud Pulse

signal wren_pls_00                          : std_logic;
signal wren_pls_01                          : std_logic;
signal wren_pls_02                          : std_logic;
signal wren_pls_03                          : std_logic;
signal wren_pls_04                          : std_logic;
signal wren_pls_05                          : std_logic;
signal wren_pls_06                          : std_logic;
signal wren_pls_07                          : std_logic;
signal wren_pls_08                          : std_logic;
signal wren_pls_09                          : std_logic;

signal rden_pls_02                          : std_logic;
--signal rden_pls_00                          : std_logic;
--signal rden_pls_01                          : std_logic;
--signal rden_pls_03                          : std_logic;
--signal rden_pls_04                          : std_logic;
signal rden_pls_05                          : std_logic;
--signal rden_pls_06                          : std_logic;
--signal rden_pls_07                          : std_logic;
--signal rden_pls_08                          : std_logic;
--signal rden_pls_09                          : std_logic;

---- CTRL_FPGA
signal func_fail_flag_oring                 : std_logic;
signal func_fail_flag_d                     : std_logic_vector(1 downto 0);
signal vss_remote_rst_oring                 : std_logic;                    -- vss reset oring
signal vss_remote_rst_d                     : std_logic_vector(1 downto 0);

-- COMMOM_FPGA
signal sysctrl_img_date                     : std_logic_vector(31 downto 0);
signal sysctrl_img_ver                      : std_logic_vector(31 downto 0);

signal sysctrl_system_info0                 : std_logic_vector(31 downto 0);     -- air_tech[3:0]
signal sysctrl_system_info1                 : std_logic_vector(31 downto 0);     -- freq_band[7:0]
signal sysctrl_system_info2                 : std_logic_vector(31 downto 0);     -- freq_band[7:0]
signal sysctrl_system_info3                 : std_logic_vector(31 downto 0);     -- fb_path_num, rx_ant_num, tx_ant_num,cpri_num
signal sysctrl_system_info4                 : std_logic_vector(31 downto 0);     -- fpga_id
signal sysctrl_system_info5                 : std_logic_vector(31 downto 0);     -- PSU_VER
signal sysctrl_system_info6                 : std_logic_vector(31 downto 0);     -- BIAST_3P3V_EN

signal sysctrl_pba_info                     : std_logic_vector(31 downto 0);
signal sysctrl_dev_info                     : std_logic_vector(31 downto 0);

signal sysctrl_module_info                  : std_logic_vector(31 downto 0);
signal sysctrl_struct_info                  : std_logic_vector(31 downto 0);
signal sysctrl_module_date                  : std_logic_vector(31 downto 0);

signal sysctrl_ipll_rst_r                   : std_logic_vector(31 downto 0);     -- number of internal DCM
---- CTRL_FPGA
signal sysctrl_cpriphy_rst_r                : std_logic_vector(31 downto 0);
signal sysctrl_cpri_rst_r                   : std_logic_vector(31 downto 0);
-- common fpga
signal sysctrl_iqcomp_rst_r                 : std_logic_vector(31 downto 0);
signal sysctrl_ethmux_rst_r                 : std_logic_vector(31 downto 0);
signal sysctrl_sbif_rst_r                   : std_logic_vector(31 downto 0);
signal sysctrl_sbifphy_rst_r                : std_logic_vector(31 downto 0);

signal sysctrl_pim_rst_r                    : std_logic_vector(31 downto 0);
signal sysctrl_pim_sbif_rst_r               : std_logic_vector(31 downto 0);
signal sysctrl_pim_sbif_phy_rst_r           : std_logic_vector(31 downto 0);

signal sysctrl_oran_l0_rx_r                 : std_logic_vector(31 downto 0); 
signal sysctrl_oran_l0_tx_r                 : std_logic_vector(31 downto 0); 
signal sysctrl_oran_l1_rx_r                 : std_logic_vector(31 downto 0); 
signal sysctrl_oran_l1_tx_r                 : std_logic_vector(31 downto 0); 

-- DSP_FPGA
signal sysctrl_bbctrl_rst_r                 : std_logic_vector(31 downto 0);
--signal sysctrl_dsp_rst_r                    : std_logic_vector(31 downto 0);
signal sysctrl_dduc_rst_r                    : std_logic_vector(31 downto 0);
signal sysctrl_cfr_rst_r                    : std_logic_vector(31 downto 0);
signal sysctrl_dpd_rst_r                    : std_logic_vector(31 downto 0);
signal sysctrl_dcif_rst_r                   : std_logic_vector(31 downto 0);
-- COMMON_FPGA
signal sysctrl_ruid_r                       : std_logic_vector(31 downto 0);
signal sysctrl_misc_rst_r                   : std_logic_vector(31 downto 0);

signal sysctrl_clk_fail_flag_r              : std_logic_vector(31 downto 0);
signal sysctrl_clk_fail_sts_r               : std_logic_vector(31 downto 0);
---- CTRL_FPGA
signal i_func_fail_flag_d                   : std_logic_vector(31 downto 0);
signal sysctrl_func_fail_flag_r             : std_logic_vector(31 downto 0);
signal sysctrl_func_fail_sts_r              : std_logic_vector(31 downto 0);

signal sysctrl_led_ctrl_r                   : std_logic_vector(31 downto 0);   -- init -0x1111
signal sysctrl_hw_wdt_ctrl_r                : std_logic_vector(31 downto 0);   -- check inital value

signal sysctrl_bfn_strb_ctrl_r              : std_logic_array32(7 downto 0);

signal sysctrl_vss_rst_ctrl_r                : std_logic_vector(31 downto 0);
signal sysctrl_tdd_ctrl_r                   : std_logic_vector(31 downto 0);   -- ul_dl_config, ssf_config, dl_cp_extended, ul_cp_extended

signal dl_frame_off_r                       : std_logic_array32(7 downto 0);
signal dl_tdd_onoff_r                       : std_logic_array32(7 downto 0);

signal ul_frame_off_r                       : std_logic_vector(31 downto 0);
signal ul_tdd_onoff_r                       : std_logic_vector(31 downto 0);

signal sysctrl_test_reg_ctrl0               : std_logic_vector(31 downto 0);
signal sysctrl_test_reg_ctrl1               : std_logic_vector(31 downto 0);

signal tdd_and_ctrl0_r                      : std_logic_vector(31 downto 0);
signal tdd_and_ctrl1_r                      : std_logic_vector(31 downto 0);
signal tdd_or_ctrl0_r                       : std_logic_vector(31 downto 0);
signal tdd_or_ctrl1_r                       : std_logic_vector(31 downto 0);

signal nr_ssb_period_r                      : std_logic_vector(31 downto 0);
signal nr_ssb_offset_r                      : std_logic_vector(31 downto 0);

signal sysctrl_sector_mode_r                : std_logic_vector(31 downto 0);
signal sysctrl_emtc_sel_r                   : std_logic_vector(31 downto 0);
-- DSP_FPGA
signal sysctrl_pa_enb_r                     : std_logic_vector(31 downto 0);

signal zeros32                              : std_logic_vector(31 downto 0) := (others => '0');

signal i_vss_rmt_rst_cpri                   : std_logic_vector(31 downto 0);
signal sysctrl_vss_rst_flag                 : std_logic_vector(31 downto 0);
signal sysctrl_vss_rst_sts                  : std_logic_vector(31 downto 0);

signal i_syspll_interrupt_in                : std_logic_vector(31 downto 0);
signal i_syspll_interrupt_flag              : std_logic_vector(31 downto 0);
signal i_syspll_interrupt_sts               : std_logic_vector(31 downto 0);


signal rx_bfn_fail_r                        : std_logic_array32(7 downto 0);
signal rx_abn_cnt_r                         : std_logic_array32(7 downto 0);

signal sysctrl_ecpriphy_rst_r               : std_logic_vector(31 downto 0); 
signal sysctrl_oran_framer_rst_r            : std_logic_vector(31 downto 0); 
signal sysctrl_oran_deframer_rst_r          : std_logic_vector(31 downto 0); 
signal sysctrl_lphy_top_rst_r                 : std_logic_vector(31 downto 0); 
signal sysctrl_dlfe_rst_r                   : std_logic_vector(31 downto 0); 
signal sysctrl_ulfe_rst_r                   : std_logic_vector(31 downto 0); 
signal sysctrl_rafe_rst_r                   : std_logic_vector(31 downto 0); 
signal sysctrl_aurora_rst_r                 : std_logic_vector(31 downto 0); 

signal sysctlr_dl_cc0_sync_advance_r        : std_logic_vector(31 downto 0);     
signal sysctlr_dl_cc1_sync_advance_r        : std_logic_vector(31 downto 0);
signal sysctlr_ul_cc0_sync_retard_r         : std_logic_vector(31 downto 0);
signal sysctlr_ul_cc1_sync_retard_r         : std_logic_vector(31 downto 0);
signal sysctrl_n_ta_offset_cc0_r            : std_logic_vector(31 downto 0);
signal sysctrl_n_ta_offset_cc1_r            : std_logic_vector(31 downto 0);
signal sysctrl_1588_lock_sts_r              : std_logic_vector(31 downto 0);

signal sysctrl_sfn_scale_r                  : std_logic_vector(31 downto 0);
signal sysctrl_sync_err_cnt_clr_r           : std_logic_vector(31 downto 0);

signal i_sync_err_in                        : std_logic_vector(31 downto 0)  ;
signal i_sync_err_sts                       : std_logic_vector(31 downto 0)  ;
signal i_sync_err_flag                      : std_logic_vector(31 downto 0)  ;

signal tp_con_sel_r                         : std_logic_vector(31 downto 0);


begin


SFN_SCALE               <=  sysctrl_sfn_scale_r         (3 downto 0)   ;
SYNC_ERR_CNT_CLR        <=  sysctrl_sync_err_cnt_clr_r  (0)            ;






sysctrl_img_date        <= C_SYSCTRL_IMG_DATE;
sysctrl_img_ver         <= C_SYSCTRL_IMG_VER;

sysctrl_system_info0    <= C_SYSCTRL_SYSTEM_INFO0;
sysctrl_system_info1    <= C_SYSCTRL_SYSTEM_INFO1;
sysctrl_system_info2    <= C_SYSCTRL_SYSTEM_INFO2;
sysctrl_system_info3    <= C_SYSCTRL_SYSTEM_INFO3;
sysctrl_system_info4    <= x"0000000" & FPGA_ID;
sysctrl_system_info5    <= x"0000000" & "000" & PSU_VER;
BIAST_3P3V_EN           <= sysctrl_system_info6(0);

sysctrl_pba_info        <= C_SYSCTRL_PBA_INFO;
sysctrl_dev_info        <= C_SYSCTRL_DEV_INFO;

sysctrl_module_info     <= C_SYSCTRL_MODULE_INFO;
sysctrl_struct_info     <= C_SYSCTRL_STRUCT_INFO;
sysctrl_module_date     <= C_SYSCTRL_MODULE_DATE;

-- port mapping   need check dsp_fpga incase
SYSCTRL_IPLL_RST    <= sysctrl_ipll_rst_r(2 downto 0);
-- CTRL_FPGA
SYSCTRL_IQCOMP_RST  <= sysctrl_iqcomp_rst_r(IQCOMP_NUM -1 downto 0);
SYSCTRL_ETHMUX_RST  <= sysctrl_ethmux_rst_r(0);


SYSCTRL_ORAN_FRAMER_RST     <=  sysctrl_oran_framer_rst_r    ( DL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_ORAN_DEFRAMER_RST   <=  sysctrl_oran_deframer_rst_r  ( UL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_LPHY_TOP_RST        <=  sysctrl_lphy_top_rst_r       ( DL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_DLFE_RST            <=  sysctrl_dlfe_rst_r           ( DL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_ULFE_RST            <=  sysctrl_ulfe_rst_r           ( UL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_RAFE_RST            <=  sysctrl_rafe_rst_r           ( UL_NUM_CC    -1 downto 0 )  ; 
SYSCTRL_AURORA_RST          <=  sysctrl_aurora_rst_r         (0)                           ; 

U_SBIF_GEN: for I in 0 to (SBIF_NUM - 1) generate
    SYSCTRL_SBIF_RST(I)    <= sysctrl_sbif_rst_r(I);
    SYSCTRL_SBIFPHY_RST(I) <= sysctrl_sbifphy_rst_r(I);
end generate;

SYSCTRL_PIM_RST          <= sysctrl_pim_rst_r(0);
SYSCTRL_PIM_SBIF_RST     <= sysctrl_pim_sbif_rst_r(0);
SYSCTRL_PIM_SBIF_PHY_RST <= sysctrl_pim_sbif_phy_rst_r(0);

--DSP_FPGA
SYSCTRL_BBCTRL_RST  <= sysctrl_bbctrl_rst_r(0);
--SYSCTRL_DSP_RST     <= sysctrl_dsp_rst_r(0);
SYSCTRL_DDUC_RST    <= sysctrl_dduc_rst_r(0);
SYSCTRL_CFR_RST     <= sysctrl_cfr_rst_r(0);
SYSCTRL_DPD_RST     <= sysctrl_dpd_rst_r(0);
SYSCTRL_DCIF_RST    <= sysctrl_dcif_rst_r(0);

-- COMMON_FPGA
SYSCTRL_RUID             <= sysctrl_ruid_r(3 downto 0);
SYSCTRL_RU_FF            <= sysctrl_func_fail_sts_r(0);
SYSCTRL_MISC_RST         <= sysctrl_misc_rst_r(0);

 -- CTRL_FPGA
U_LED_ASSIGN_GEN: for I in 0 to (LED_NUM - 1) generate
    SYSCTRL_LED_CTRL(I) <= sysctrl_led_ctrl_r(4*I+3 downto I*4);
end generate;

SYSCTRL_HW_WDT_CTRL <= sysctrl_hw_wdt_ctrl_r;        -- need to check

-- CTRL_FPGA
BFN_STRB_GEN: for I in 0 to (CPRI_NUM - 1) generate
    SYSCTRL_BFN_STRB_CTRL(I)    <= sysctrl_bfn_strb_ctrl_r(I);
end generate;

SYSCTRL_TDD_CTRL                <= sysctrl_tdd_ctrl_r;

NR_SSB_PERIOD                   <= nr_ssb_period_r       (4 downto 0);
NR_SSB_OFFSET                   <= nr_ssb_offset_r       (3 downto 0);

SECTOR_MODE                     <= sysctrl_sector_mode_r (4) & sysctrl_sector_mode_r (0);
eMTC_SEL                        <= sysctrl_emtc_sel_r    (4) & sysctrl_emtc_sel_r    (0);


DL_INNER_GEN: for I in 0 to (CPRI_NUM - 1) generate
    DL_INNER_FRAME_OFFSET(I)    <= dl_frame_off_r(I)(18 downto 0);
    DL_INNER_ON(I)              <= dl_tdd_onoff_r(I)(14 downto 0);
    DL_INNER_OFF(I)             <= dl_tdd_onoff_r(I)(30 downto 16);
end generate;

    UL_INNER_FRAME_OFFSET       <= ul_frame_off_r(18 downto 0);     -- UL-DL frame timing(624 Ts)
    UL_INNER_ON                 <= ul_tdd_onoff_r(14 downto 0);
    UL_INNER_OFF                <= ul_tdd_onoff_r(30 downto 16);

    TDD_AND_CTRL(0)             <= tdd_and_ctrl0_r;
    TDD_OR_CTRL(0)              <= tdd_or_ctrl0_r;

    TDD_AND_CTRL(1)             <= tdd_and_ctrl1_r;
    TDD_OR_CTRL(1)              <= tdd_or_ctrl1_r;


	DL_CC0_SYNC_ADVANCE         <= sysctlr_dl_cc0_sync_advance_r (21 downto 0) ;    
    DL_CC1_SYNC_ADVANCE         <= sysctlr_dl_cc1_sync_advance_r (21 downto 0) ;    
    UL_CC0_SYNC_RETARD          <= sysctlr_ul_cc0_sync_retard_r  (21 downto 0) ;    
    UL_CC1_SYNC_RETARD          <= sysctlr_ul_cc1_sync_retard_r  (21 downto 0) ;    

    N_TA_OFFSET_CC0             <= sysctrl_n_ta_offset_cc0_r(15 downto 0) ;
    N_TA_OFFSET_CC1             <= sysctrl_n_ta_offset_cc1_r(15 downto 0) ;
-------------------------------------------------------------------- function fail
func_fail_flag_oring <= '1' when (SYSCTRL_FUNC_FAIL_TRIG = "11") else '0';

process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        func_fail_flag_d <= "00";
    elsif (CLK_CPUIF = '1' and CLK_CPUIF'event) then
        func_fail_flag_d <= func_fail_flag_d(0) & func_fail_flag_oring;
    end if;
end process;

---------------------------------------------------------------------- vss remote reset
vss_remote_rst_oring <= '1' when (VSS_RMT_RST_CPRI /= zeros32(CPRI_NUM-1 downto 0)) else '0';

process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        vss_remote_rst_d <= "00";
    elsif (CLK_CPUIF = '1' and CLK_CPUIF'event) then
        vss_remote_rst_d <= vss_remote_rst_d(0) & vss_remote_rst_oring;
    end if;
end process;

VSS_RMT_RST <= vss_remote_rst_d(1) when sysctrl_vss_rst_ctrl_r(0) = '0' else '0';

-- COMMON_FPGA
addrl8b  <= ADDR_CPUIF_SYSCTRL(7 downto 0);
wdata    <= WDATA_CPUIF_SYSCTRL;
----------------------------------------------------------------------------------------------
-- Read Data Valid Signal Generation, 5 Clock Latency
----------------------------------------------------------------------------------------------
process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        rden_dly <= (others => '0');
        rdval_pls <= '0';
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        rden_dly <= rden_dly(6 downto 0) & RDEN_CPUIF_SYSCTRL;
        if (rden_dly(3) = '1' and rden_dly(4) = '0') then                       -- 1 Clock Duration
            rdval_pls <= '1';
        else
            rdval_pls <= '0';
        end if;
    end if;
end process;

RDVAL_CPUIF_SYSCTRL <= rdval_pls;

----------------------------------------------------------------------------------------------
-- Register Write
----------------------------------------------------------------------------------------------
-- Write Enable Pulse Signal Generation
process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        wren_d1 <= '0';
        wren_d2 <= '0';
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        wren_d1 <= WREN_CPUIF_SYSCTRL;
        wren_d2 <= wren_d1;
    end if;
end process;

process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
        wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        if (wren_d1 = '1' and wren_d2 = '0') then -- rising edge
            case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                when x"00"  => wren_pls_00 <= '1'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"01"  => wren_pls_00 <= '0'; wren_pls_01 <= '1'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"02"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '1'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"03"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '1'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"04"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '1';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"05"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '1'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"06"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '1'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"07"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '1'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
                when x"08"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '1'; wren_pls_09 <= '0';
                when x"09"  => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '1';
                when others => wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
                               wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
            end case;
        else
            wren_pls_00 <= '0'; wren_pls_01 <= '0'; wren_pls_02 <= '0'; wren_pls_03 <= '0'; wren_pls_04 <= '0';
            wren_pls_05 <= '0'; wren_pls_06 <= '0'; wren_pls_07 <= '0'; wren_pls_08 <= '0'; wren_pls_09 <= '0';
        end if;
    end if;
end process;

---- ctrl_fpga
REG32_WRITE_0X0002 : REG32_WRITE generic map(x"0000_000F", x"02", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_00, addrl8b, wdata, sysctrl_ruid_r);

---- ctrl_fpga
REG32_WRITE_0X000a : REG32_WRITE generic map(x"0000_0001", x"0a", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_00, addrl8b, wdata, sysctrl_system_info6);


-- common_fpga
REG32_WRITE_0X0110 : REG32_WRITE generic map(x"0000_00FF", x"10", x"000000FF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ipll_rst_r);

---- ctrl_fpga
-- common fpga
REG32_WRITE_0X0131 : REG32_WRITE generic map(x"0000_00FF", x"31", x"000000FF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_iqcomp_rst_r);
REG32_WRITE_0X0132 : REG32_WRITE generic map(x"0000_0001", x"32", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ethmux_rst_r);

-- dsp_fpga
REG32_WRITE_0X0140 : REG32_WRITE generic map(x"0000_0001", x"40", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_bbctrl_rst_r);
--REG32_WRITE_0X0150 : REG32_WRITE generic map(x"0000_0001", x"50", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dsp_rst_r);
REG32_WRITE_0X0151 : REG32_WRITE generic map(x"0000_0001", x"51", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dduc_rst_r);
REG32_WRITE_0X0152 : REG32_WRITE generic map(x"0000_0001", x"52", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_cfr_rst_r);
REG32_WRITE_0X0153 : REG32_WRITE generic map(x"0000_0001", x"53", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dpd_rst_r);
REG32_WRITE_0X0160 : REG32_WRITE generic map(x"0000_0001", x"60", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dcif_rst_r);

-- common_fpga
REG32_WRITE_0X0170 : REG32_WRITE generic map(x"0000_0001", x"70", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_misc_rst_r);

--required toggle reset
REG32_WRITE_0X0190 : REG32_WRITE generic map(x"0000_0007", x"90", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_oran_framer_rst_r);
REG32_WRITE_0X0191 : REG32_WRITE generic map(x"0000_0007", x"91", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_oran_deframer_rst_r);
REG32_WRITE_0X01A0 : REG32_WRITE generic map(x"0000_0007", x"A0", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_lphy_top_rst_r);
REG32_WRITE_0X01A1 : REG32_WRITE generic map(x"0000_0007", x"A1", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_dlfe_rst_r);
REG32_WRITE_0X01A2 : REG32_WRITE generic map(x"0000_0007", x"A2", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_ulfe_rst_r);
REG32_WRITE_0X01A3 : REG32_WRITE generic map(x"0000_0007", x"A3", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_rafe_rst_r);
REG32_WRITE_0X01B0 : REG32_WRITE generic map(x"0000_0007", x"B0", x"00000007") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_aurora_rst_r);

-- common_fpga
REG32_WRITE_0X01C0 : REG32_WRITE generic map(x"0000_003F", x"C0", x"0000003F") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_sbif_rst_r);
REG32_WRITE_0X01C1 : REG32_WRITE generic map(x"0000_003F", x"C1", x"0000003F") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_sbifphy_rst_r);

REG32_WRITE_0X01D0 : REG32_WRITE generic map(x"0000_0001", x"D0", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_pim_rst_r);
REG32_WRITE_0X01D1 : REG32_WRITE generic map(x"0000_0001", x"D1", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_pim_sbif_rst_r);
REG32_WRITE_0X01D2 : REG32_WRITE generic map(x"0000_0001", x"D2", x"00000001") port map(RST_CPUIF, CLK_CPUIF, wren_pls_01, addrl8b, wdata, sysctrl_pim_sbif_phy_rst_r);

---- ctrl_fpga (modified by chany.lee 20170623)
REG32_WRITE_0X0202 : REG32_WRITE generic map(x"0000_0001", x"02", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, sysctrl_vss_rst_ctrl_r);
REG32_WRITE_0X020A : REG32_WRITE generic map(x"0000_0003", x"0A", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, sysctrl_1588_lock_sts_r);

REG32_WRITE_0X0230 : REG32_WRITE generic map(x"FFFFFFFF", x"30", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_02, addrl8b, wdata, tp_con_sel_r);

REG32_WRITE_0X0300 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"00001111") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_led_ctrl_r);
REG32_WRITE_0X0304 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"00010078") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_hw_wdt_ctrl_r);
-- DSP FPGA
REG32_WRITE_0X0320 : REG32_WRITE generic map(x"FFFF_FFFF", x"20", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_03, addrl8b, wdata, sysctrl_pa_enb_r);



---- CTRL_fgap
-- depend on cpri num
BFN_STROBE_CTRL_GEN0 : if CPRI_NUM = 1 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
                  rx_bfn_fail_r(I)  <= x"00000000";
                  rx_abn_cnt_r(I)   <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN1 : if CPRI_NUM = 2 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
                  rx_bfn_fail_r(I)  <= x"00000000";
                  rx_abn_cnt_r(I)   <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN2 : if CPRI_NUM = 3 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
                  rx_bfn_fail_r(I)  <= x"00000000";
                  rx_abn_cnt_r(I)   <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN3 : if CPRI_NUM = 4 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0403 : REG32_WRITE generic map(x"FFFF_FFFF", x"03", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(3));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
REG32_WRITE_0X0516 : REG32_WRITE generic map(x"FFFF_FFFF", x"16", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(3));
REG32_WRITE_0X0517 : REG32_WRITE generic map(x"FFFF_FFFF", x"17", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(3));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
rx_bfn_fail_r(3)(0)         <= RX_BFN_FAIL(3);
rx_abn_cnt_r(3)(7 downto 0) <= RX_ABN_CNT(3);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
                  rx_bfn_fail_r(I)  <= x"00000000";
                  rx_abn_cnt_r(I)   <= x"00000000";
    end generate;
end generate;




BFN_STROBE_CTRL_GEN4 : if CPRI_NUM = 5 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0403 : REG32_WRITE generic map(x"FFFF_FFFF", x"03", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(3));
REG32_WRITE_0X0404 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(4));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
REG32_WRITE_0X0516 : REG32_WRITE generic map(x"FFFF_FFFF", x"16", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(3));
REG32_WRITE_0X0517 : REG32_WRITE generic map(x"FFFF_FFFF", x"17", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(3));
REG32_WRITE_0X0518 : REG32_WRITE generic map(x"FFFF_FFFF", x"18", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(4));
REG32_WRITE_0X0519 : REG32_WRITE generic map(x"FFFF_FFFF", x"19", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(4));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
rx_bfn_fail_r(3)(0)         <= RX_BFN_FAIL(3);
rx_abn_cnt_r(3)(7 downto 0) <= RX_ABN_CNT(3);
rx_bfn_fail_r(4)(0)         <= RX_BFN_FAIL(4);
rx_abn_cnt_r(4)(7 downto 0) <= RX_ABN_CNT(4);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN5 : if CPRI_NUM = 6 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0403 : REG32_WRITE generic map(x"FFFF_FFFF", x"03", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(3));
REG32_WRITE_0X0404 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(4));
REG32_WRITE_0X0405 : REG32_WRITE generic map(x"FFFF_FFFF", x"05", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(5));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
REG32_WRITE_0X0516 : REG32_WRITE generic map(x"FFFF_FFFF", x"16", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(3));
REG32_WRITE_0X0517 : REG32_WRITE generic map(x"FFFF_FFFF", x"17", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(3));
REG32_WRITE_0X0518 : REG32_WRITE generic map(x"FFFF_FFFF", x"18", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(4));
REG32_WRITE_0X0519 : REG32_WRITE generic map(x"FFFF_FFFF", x"19", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(4));
REG32_WRITE_0X051A : REG32_WRITE generic map(x"FFFF_FFFF", x"1A", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(5));
REG32_WRITE_0X051B : REG32_WRITE generic map(x"FFFF_FFFF", x"1B", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(5));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
rx_bfn_fail_r(3)(0)         <= RX_BFN_FAIL(3);
rx_abn_cnt_r(3)(7 downto 0) <= RX_ABN_CNT(3);
rx_bfn_fail_r(4)(0)         <= RX_BFN_FAIL(4);
rx_abn_cnt_r(4)(7 downto 0) <= RX_ABN_CNT(4);
rx_bfn_fail_r(5)(0)         <= RX_BFN_FAIL(5);
rx_abn_cnt_r(5)(7 downto 0) <= RX_ABN_CNT(5);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN6 : if CPRI_NUM = 7 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0403 : REG32_WRITE generic map(x"FFFF_FFFF", x"03", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(3));
REG32_WRITE_0X0404 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(4));
REG32_WRITE_0X0405 : REG32_WRITE generic map(x"FFFF_FFFF", x"05", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(5));
REG32_WRITE_0X0406 : REG32_WRITE generic map(x"FFFF_FFFF", x"06", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(6));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
REG32_WRITE_0X0516 : REG32_WRITE generic map(x"FFFF_FFFF", x"16", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(3));
REG32_WRITE_0X0517 : REG32_WRITE generic map(x"FFFF_FFFF", x"17", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(3));
REG32_WRITE_0X0518 : REG32_WRITE generic map(x"FFFF_FFFF", x"18", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(4));
REG32_WRITE_0X0519 : REG32_WRITE generic map(x"FFFF_FFFF", x"19", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(4));
REG32_WRITE_0X051A : REG32_WRITE generic map(x"FFFF_FFFF", x"1A", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(5));
REG32_WRITE_0X051B : REG32_WRITE generic map(x"FFFF_FFFF", x"1B", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(5));
REG32_WRITE_0X051C : REG32_WRITE generic map(x"FFFF_FFFF", x"1C", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(6));
REG32_WRITE_0X051D : REG32_WRITE generic map(x"FFFF_FFFF", x"1D", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(6));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
rx_bfn_fail_r(3)(0)         <= RX_BFN_FAIL(3);
rx_abn_cnt_r(3)(7 downto 0) <= RX_ABN_CNT(3);
rx_bfn_fail_r(4)(0)         <= RX_BFN_FAIL(4);
rx_abn_cnt_r(4)(7 downto 0) <= RX_ABN_CNT(4);
rx_bfn_fail_r(5)(0)         <= RX_BFN_FAIL(5);
rx_abn_cnt_r(5)(7 downto 0) <= RX_ABN_CNT(5);
rx_bfn_fail_r(6)(0)         <= RX_BFN_FAIL(6);
rx_abn_cnt_r(6)(7 downto 0) <= RX_ABN_CNT(6);
    MAPPING_GEN : for I in CPRI_NUM to 7 generate
                  sysctrl_bfn_strb_ctrl_r(I) <= x"00000000";
                  dl_frame_off_r(I) <= x"00000000";
                  dl_tdd_onoff_r(I) <= x"00000000";
    end generate;
end generate;

BFN_STROBE_CTRL_GEN7 : if CPRI_NUM = 8 generate
REG32_WRITE_0X0400 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(0));
REG32_WRITE_0X0401 : REG32_WRITE generic map(x"FFFF_FFFF", x"01", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(1));
REG32_WRITE_0X0402 : REG32_WRITE generic map(x"FFFF_FFFF", x"02", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(2));
REG32_WRITE_0X0403 : REG32_WRITE generic map(x"FFFF_FFFF", x"03", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(3));
REG32_WRITE_0X0404 : REG32_WRITE generic map(x"FFFF_FFFF", x"04", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(4));
REG32_WRITE_0X0405 : REG32_WRITE generic map(x"FFFF_FFFF", x"05", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(5));
REG32_WRITE_0X0406 : REG32_WRITE generic map(x"FFFF_FFFF", x"06", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(6));
REG32_WRITE_0X0407 : REG32_WRITE generic map(x"FFFF_FFFF", x"07", x"01000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_04, addrl8b, wdata, sysctrl_bfn_strb_ctrl_r(7));
REG32_WRITE_0X0510 : REG32_WRITE generic map(x"FFFF_FFFF", x"10", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(0));
REG32_WRITE_0X0511 : REG32_WRITE generic map(x"FFFF_FFFF", x"11", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(0));
REG32_WRITE_0X0512 : REG32_WRITE generic map(x"FFFF_FFFF", x"12", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(1));
REG32_WRITE_0X0513 : REG32_WRITE generic map(x"FFFF_FFFF", x"13", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(1));
REG32_WRITE_0X0514 : REG32_WRITE generic map(x"FFFF_FFFF", x"14", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(2));
REG32_WRITE_0X0515 : REG32_WRITE generic map(x"FFFF_FFFF", x"15", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(2));
REG32_WRITE_0X0516 : REG32_WRITE generic map(x"FFFF_FFFF", x"16", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(3));
REG32_WRITE_0X0517 : REG32_WRITE generic map(x"FFFF_FFFF", x"17", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(3));
REG32_WRITE_0X0518 : REG32_WRITE generic map(x"FFFF_FFFF", x"18", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(4));
REG32_WRITE_0X0519 : REG32_WRITE generic map(x"FFFF_FFFF", x"19", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(4));
REG32_WRITE_0X051A : REG32_WRITE generic map(x"FFFF_FFFF", x"1A", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(5));
REG32_WRITE_0X051B : REG32_WRITE generic map(x"FFFF_FFFF", x"1B", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(5));
REG32_WRITE_0X051C : REG32_WRITE generic map(x"FFFF_FFFF", x"1C", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(6));
REG32_WRITE_0X051D : REG32_WRITE generic map(x"FFFF_FFFF", x"1D", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(6));
REG32_WRITE_0X051E : REG32_WRITE generic map(x"FFFF_FFFF", x"1E", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_frame_off_r(7));
REG32_WRITE_0X051F : REG32_WRITE generic map(x"FFFF_FFFF", x"1F", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, dl_tdd_onoff_r(7));
rx_bfn_fail_r(0)(0)         <= RX_BFN_FAIL(0);
rx_abn_cnt_r(0)(7 downto 0) <= RX_ABN_CNT(0);
rx_bfn_fail_r(1)(0)         <= RX_BFN_FAIL(1);
rx_abn_cnt_r(1)(7 downto 0) <= RX_ABN_CNT(1);
rx_bfn_fail_r(2)(0)         <= RX_BFN_FAIL(2);
rx_abn_cnt_r(2)(7 downto 0) <= RX_ABN_CNT(2);
rx_bfn_fail_r(3)(0)         <= RX_BFN_FAIL(3);
rx_abn_cnt_r(3)(7 downto 0) <= RX_ABN_CNT(3);
rx_bfn_fail_r(4)(0)         <= RX_BFN_FAIL(4);
rx_abn_cnt_r(4)(7 downto 0) <= RX_ABN_CNT(4);
rx_bfn_fail_r(5)(0)         <= RX_BFN_FAIL(5);
rx_abn_cnt_r(5)(7 downto 0) <= RX_ABN_CNT(5);
rx_bfn_fail_r(6)(0)         <= RX_BFN_FAIL(6);
rx_abn_cnt_r(6)(7 downto 0) <= RX_ABN_CNT(6);
rx_bfn_fail_r(7)(0)         <= RX_BFN_FAIL(7);
rx_abn_cnt_r(7)(7 downto 0) <= RX_ABN_CNT(7);
end generate;

REG32_WRITE_0X0500 : REG32_WRITE generic map(x"FFFF_FFFF", x"00", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, sysctrl_tdd_ctrl_r);

-- ctrl_fpga
REG32_WRITE_0X0530 : REG32_WRITE generic map(x"FFFF_FFFF", x"30", x"00000270") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, ul_frame_off_r);
REG32_WRITE_0X0531 : REG32_WRITE generic map(x"FFFF_FFFF", x"31", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, ul_tdd_onoff_r);

REG32_WRITE_0X0540 : REG32_WRITE generic map(x"FFFF_FFFF", x"40", x"FFFFFFFF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, tdd_and_ctrl0_r);
REG32_WRITE_0X0541 : REG32_WRITE generic map(x"FFFF_FFFF", x"41", x"FFFFFFFF") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, tdd_and_ctrl1_r);
REG32_WRITE_0X0545 : REG32_WRITE generic map(x"FFFF_FFFF", x"45", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, tdd_or_ctrl0_r);
REG32_WRITE_0X0546 : REG32_WRITE generic map(x"FFFF_FFFF", x"46", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, tdd_or_ctrl1_r);


REG32_WRITE_0X056B : REG32_WRITE generic map(x"0000_0001", x"6B", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, sysctrl_sync_err_cnt_clr_r) ; 
REG32_WRITE_0X056C : REG32_WRITE generic map(x"0000_000F", x"6C", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, sysctrl_sfn_scale_r ); 

REG32_WRITE_0X0580 : REG32_WRITE generic map(x"FFFF_FFFF", x"80", x"00000004") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, nr_ssb_period_r);
REG32_WRITE_0X0581 : REG32_WRITE generic map(x"FFFF_FFFF", x"81", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, nr_ssb_offset_r);

REG32_WRITE_0X05B0 : REG32_WRITE generic map(x"FFFF_FFFF", x"B0", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, sysctrl_sector_mode_r);
REG32_WRITE_0X05B1 : REG32_WRITE generic map(x"FFFF_FFFF", x"B1", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_05, addrl8b, wdata, sysctrl_emtc_sel_r);

REG32_WRITE_0X0980 : REG32_WRITE generic map(x"FFFF_FFFF", x"80", x"00252E8A") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctlr_dl_cc0_sync_advance_r);
REG32_WRITE_0X0981 : REG32_WRITE generic map(x"FFFF_FFFF", x"81", x"002550CA") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctlr_dl_cc1_sync_advance_r);
REG32_WRITE_0X0990 : REG32_WRITE generic map(x"FFFF_FFFF", x"90", x"00252E8A") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctlr_ul_cc0_sync_retard_r );
REG32_WRITE_0X0991 : REG32_WRITE generic map(x"FFFF_FFFF", x"91", x"00252ECA") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctlr_ul_cc1_sync_retard_r );

REG32_WRITE_0X09C0 : REG32_WRITE generic map(x"FFFF_FFFF", x"C0", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctrl_n_ta_offset_cc0_r );
REG32_WRITE_0X09C1 : REG32_WRITE generic map(x"FFFF_FFFF", x"C1", x"00000000") port map(RST_CPUIF, CLK_CPUIF, wren_pls_09, addrl8b, wdata, sysctrl_n_ta_offset_cc1_r );
-- COMMON_FPGA
----------------------------------------------------------------------------------------------
-- Register Read
----------------------------------------------------------------------------------------------
-- Clock Domain Change for Control Signals
RDEN_DLY_GEN0: process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        rden_d1 <= '0';
        rden_strobe <= '0';
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        rden_d1 <= RDEN_CPUIF_SYSCTRL;
        rden_strobe <= rden_d1;
    end if;
end process;


RDEN_LATCH_GEN0: process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        rden_pls_02 <= '0';
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        if (RDEN_DLY(1) = '1' and RDEN_DLY(2) = '0') then
            case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                when x"02" => rden_pls_02 <= '1';
                when others  => rden_pls_02 <= '0';
            end case;
        else
            rden_pls_02 <= '0';
       end if;

        if (RDEN_DLY(1) = '1' and RDEN_DLY(2) = '0') then
            case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                when x"05"   => rden_pls_05 <= '1';
                when others  => rden_pls_05 <= '0';
            end case;
        else
            rden_pls_05 <= '0';
       end if;


    end if;
end process;

-- ctrl_fpga
i_vss_rmt_rst_cpri <= zeros32(31 downto CPRI_NUM) & VSS_RMT_RST_CPRI;
i_func_fail_flag_d <= zeros32(31 downto 1) & func_fail_flag_d(1);
i_syspll_interrupt_in <= zeros32(31 downto 1) & EXT_SYSPLL_INTERRUPT_IN;
REG_LATCH_0x0200 : REG32_LATCH generic map(x"0000_FFFF", x"00") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, i_vss_rmt_rst_cpri, sysctrl_vss_rst_sts, sysctrl_vss_rst_flag );
REG_LATCH_0x0204 : REG32_LATCH generic map(x"0000_0001", x"04") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, i_func_fail_flag_d, sysctrl_func_fail_sts_r, sysctrl_func_fail_flag_r );
-- common_fpga
REG_LATCH_0x0206 : REG32_LATCH generic map(x"FFFF_FFFF", x"06") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, SYSCTRL_CLK_FAIL_TRIG, sysctrl_clk_fail_sts_r, sysctrl_clk_fail_flag_r );      -- need to clk_fail check

REG_LATCH_0x0208 : REG32_LATCH generic map(x"0000_0001", x"08") port map(RST_CPUIF, CLK_CPUIF, rden_pls_02, addrl8b, i_syspll_interrupt_in, i_syspll_interrupt_sts, i_syspll_interrupt_flag );

REG_LATCH_0x0568 : REG32_LATCH generic map(x"0000_0001", x"68") port map(RST_CPUIF, CLK_CPUIF, rden_pls_05, addrl8b, i_sync_err_in, i_sync_err_sts, i_sync_err_flag );
i_sync_err_in(0) <= SYNC_ERR  ;


TP_CON_SEL                  <= tp_con_sel_r(7 downto 0);

-- Read Data Multiplexing
RDATA_CPUIF_SYSCTRL <= rdata     when ADDR_CPUIF_SYSCTRL(15 downto 8) = x"00" else
                       rdata;

RDATA_MUX_PROC0: process(RST_CPUIF, CLK_CPUIF)
begin
    if (RST_CPUIF = '1') then
        rdata     <= (others => '0');
    elsif (CLK_CPUIF'event and CLK_CPUIF = '1') then
        if (rden_strobe     = '1') then
            case ADDR_CPUIF_SYSCTRL(15 downto 8) is
                when x"00"  =>
                    case addrl8b is
                        when x"00"  => rdata    <= sysctrl_img_date;
                        when x"01"  => rdata    <= sysctrl_img_ver;
                        when x"02"  => rdata    <= sysctrl_ruid_r;
                        when x"04"  => rdata    <= sysctrl_system_info0;
                        when x"05"  => rdata    <= sysctrl_system_info1;
                        when x"06"  => rdata    <= sysctrl_system_info2;
                        when x"07"  => rdata    <= sysctrl_system_info3;
                        when x"08"  => rdata    <= sysctrl_system_info4;
                        when x"09"  => rdata    <= sysctrl_system_info5;
                        when x"0a"  => rdata    <= sysctrl_system_info6;
                        --when x"0C"  => rdata    <= sysctrl_pba_info;
                        when x"0C"  => rdata    <= x"000" & '0' & FPGA_PCB_VER(2 downto 0) & x"0000";
                        when x"0D"  => rdata    <= sysctrl_dev_info;
                        when others => rdata    <= (others => '0');
                    end case;
                when x"01"  =>
                    case addrl8b is
                        when x"00"  => rdata    <= sysctrl_module_info;
                        when x"01"  => rdata    <= sysctrl_struct_info;
                        when x"02"  => rdata    <= sysctrl_module_date;
-- common_fpga
                        when x"10"  => rdata    <= sysctrl_ipll_rst_r;
---- ctrl_fpga
-- commono fpga
                        when x"31"  => rdata    <= sysctrl_iqcomp_rst_r;
                        when x"32"  => rdata    <= sysctrl_ethmux_rst_r;
-- dsp_fpga
                        when x"40"  => rdata    <= sysctrl_bbctrl_rst_r;
--                        when x"50"  => rdata    <= sysctrl_dsp_rst_r;
                        when x"51"  => rdata    <= sysctrl_dduc_rst_r;
                        when x"52"  => rdata    <= sysctrl_cfr_rst_r;
                        when x"53"  => rdata    <= sysctrl_dpd_rst_r;
                        when x"60"  => rdata    <= sysctrl_dcif_rst_r;
-- common_fpga
                        when x"70"  => rdata    <= sysctrl_misc_rst_r;
-- common_fpga

                        when x"90"  => rdata    <= sysctrl_oran_framer_rst_r  ;
                        when x"91"  => rdata    <= sysctrl_oran_deframer_rst_r;
                        when x"A0"  => rdata    <= sysctrl_lphy_top_rst_r       ;
                        when x"A1"  => rdata    <= sysctrl_dlfe_rst_r         ;
                        when x"A2"  => rdata    <= sysctrl_ulfe_rst_r         ;
                        when x"A3"  => rdata    <= sysctrl_rafe_rst_r         ;
                        when x"B1"  => rdata    <= sysctrl_aurora_rst_r       ;

                        when x"C0"  => rdata    <= sysctrl_sbif_rst_r;
                        when x"C1"  => rdata    <= sysctrl_sbifphy_rst_r;

                        when x"D0"  => rdata    <= sysctrl_pim_rst_r;
                        when x"D1"  => rdata    <= sysctrl_pim_sbif_rst_r;
                        when x"D2"  => rdata    <= sysctrl_pim_sbif_phy_rst_r;


--                        when x"F0"  => rdata    <= sysctrl_oran_l0_rx_r ;
--                        when x"F1"  => rdata    <= sysctrl_oran_l0_tx_r ;
--                        when x"F2"  => rdata    <= sysctrl_oran_l1_rx_r ;
--                        when x"F3"  => rdata    <= sysctrl_oran_l1_tx_r ;

                        when others => rdata    <= (others => '0');
                    end case;
                when x"02"  =>
                    case addrl8b is
---- ctrl_fpga
                        when x"00"  => rdata    <= sysctrl_vss_rst_flag;
                        when x"01"  => rdata    <= sysctrl_vss_rst_sts;
                        when x"02"  => rdata    <= sysctrl_vss_rst_ctrl_r;
                        when x"04"  => rdata    <= sysctrl_func_fail_flag_r;
                        when x"05"  => rdata    <= sysctrl_func_fail_sts_r;
                        
                        when x"30"  => rdata    <= tp_con_sel_r;
-- common_fpga
                        when x"06"  => rdata    <= sysctrl_clk_fail_flag_r;
                        when x"07"  => rdata    <= sysctrl_clk_fail_sts_r;
                        when x"08"  => rdata    <= i_syspll_interrupt_flag;
                        when x"09"  => rdata    <= i_syspll_interrupt_sts;
                        when x"0a"  => rdata    <= sysctrl_1588_lock_sts_r;
                        when others => rdata    <= (others => '0');
                    end case;
                when x"03"  =>
                    case addrl8b is
---- ctrl_fpga
                        when x"00"  => rdata    <= sysctrl_led_ctrl_r;
                        when x"04"  => rdata    <= sysctrl_hw_wdt_ctrl_r;
-- dsp_fpga ?????
                        when x"20"  => rdata    <= sysctrl_pa_enb_r;
                        when others => rdata    <= (others => '0');
                    end case;
                when x"04"  =>
                    case addrl8b is
-- ctrl_fpga
                        when x"00"  => rdata    <= sysctrl_bfn_strb_ctrl_r(0);
                        when x"01"  => rdata    <= sysctrl_bfn_strb_ctrl_r(1);
                        when x"02"  => rdata    <= sysctrl_bfn_strb_ctrl_r(2);
                        when x"03"  => rdata    <= sysctrl_bfn_strb_ctrl_r(3);
                        when x"04"  => rdata    <= sysctrl_bfn_strb_ctrl_r(4);
                        when x"05"  => rdata    <= sysctrl_bfn_strb_ctrl_r(5);
                        when x"06"  => rdata    <= sysctrl_bfn_strb_ctrl_r(6);
                        when x"07"  => rdata    <= sysctrl_bfn_strb_ctrl_r(7);
                        when others => rdata    <= (others => '0');
                    end case;

                when x"05"  =>
                    case addrl8b is
-- ctrl_fpga
                        when x"00"  => rdata    <= sysctrl_tdd_ctrl_r;
                        when x"10"  => rdata    <= dl_frame_off_r(0);
                        when x"11"  => rdata    <= dl_tdd_onoff_r(0);
                        when x"12"  => rdata    <= dl_frame_off_r(1);
                        when x"13"  => rdata    <= dl_tdd_onoff_r(1);
                        when x"14"  => rdata    <= dl_frame_off_r(2);
                        when x"15"  => rdata    <= dl_tdd_onoff_r(2);
                        when x"16"  => rdata    <= dl_frame_off_r(3);
                        when x"17"  => rdata    <= dl_tdd_onoff_r(3);
                        when x"18"  => rdata    <= dl_frame_off_r(4);
                        when x"19"  => rdata    <= dl_tdd_onoff_r(4);
                        when x"1A"  => rdata    <= dl_frame_off_r(5);
                        when x"1B"  => rdata    <= dl_tdd_onoff_r(5);
                        when x"1C"  => rdata    <= dl_frame_off_r(6);
                        when x"1D"  => rdata    <= dl_tdd_onoff_r(6);
                        when x"1E"  => rdata    <= dl_frame_off_r(7);
                        when x"1F"  => rdata    <= dl_tdd_onoff_r(7);
                        when x"30"  => rdata    <= ul_frame_off_r;
                        when x"31"  => rdata    <= ul_tdd_onoff_r;
                        when x"40"  => rdata    <= tdd_and_ctrl0_r;
                        when x"41"  => rdata    <= tdd_and_ctrl1_r;
                        when x"45"  => rdata    <= tdd_or_ctrl0_r;
                        when x"46"  => rdata    <= tdd_or_ctrl1_r;

                        when x"50"  => rdata    <= ul_frame_off_r;
                        when x"51"  => rdata    <= ul_tdd_onoff_r;
                        when x"52"  => rdata    <= tdd_and_ctrl0_r;
                        when x"53"  => rdata    <= tdd_and_ctrl1_r;
                        when x"54"  => rdata    <= tdd_or_ctrl0_r;
                        when x"55"  => rdata    <= tdd_or_ctrl1_r;
                        when x"60"  => rdata    <= rx_bfn_fail_r(0);
                        when x"61"  => rdata    <= rx_bfn_fail_r(1);
                        when x"62"  => rdata    <= rx_bfn_fail_r(2);
                        when x"63"  => rdata    <= rx_bfn_fail_r(3);
                        when x"64"  => rdata    <= rx_bfn_fail_r(4);
                        when x"65"  => rdata    <= rx_bfn_fail_r(5);
                        when x"66"  => rdata    <= rx_bfn_fail_r(6);
                        when x"67"  => rdata    <= rx_bfn_fail_r(7);
                        when x"68"  => rdata    <= i_sync_err_flag(15 downto 0) & i_sync_err_sts(15 downto 0) ;
                        when x"69"  => rdata    <= x"0000" &  SYNC_ERR_CNT ;
                        when x"6A"  => rdata    <= C2C_SYNC_PROC_DLY;
                        when x"6B"  => rdata    <= sysctrl_sync_err_cnt_clr_r ;
                        when x"6C"  => rdata    <= sysctrl_sfn_scale_r ;
                        when x"70"  => rdata    <= rx_abn_cnt_r(0);
                        when x"71"  => rdata    <= rx_abn_cnt_r(1);
                        when x"72"  => rdata    <= rx_abn_cnt_r(2);
                        when x"73"  => rdata    <= rx_abn_cnt_r(3);
                        when x"74"  => rdata    <= rx_abn_cnt_r(4);
                        when x"75"  => rdata    <= rx_abn_cnt_r(5);
                        when x"76"  => rdata    <= rx_abn_cnt_r(6);
                        when x"77"  => rdata    <= rx_abn_cnt_r(7);
                        
                        when x"80"  => rdata    <= nr_ssb_period_r;
                        when x"81"  => rdata    <= nr_ssb_offset_r;
                        when x"B0"  => rdata    <= sysctrl_sector_mode_r;
                        when x"B1"  => rdata    <= sysctrl_emtc_sel_r ;
                        when others => rdata    <= (others => '0');
                    end case;

                when x"09"  =>
                    case addrl8b is
                        when x"80"  => rdata    <= sysctlr_dl_cc0_sync_advance_r;
                        when x"81"  => rdata    <= sysctlr_dl_cc1_sync_advance_r;
                        when x"90"  => rdata    <= sysctlr_ul_cc0_sync_retard_r ;
                        when x"91"  => rdata    <= sysctlr_ul_cc1_sync_retard_r ;
                        when x"C0"  => rdata    <= sysctrl_n_ta_offset_cc0_r ;
                        when x"C1"  => rdata    <= sysctrl_n_ta_offset_cc1_r ;
                        when others => rdata    <= (others => '0');
                    end case;


                when others => rdata     <= (others => '0');
            end case;
        else
            rdata     <= (others => '0');
        end if;
    end if;
end process;

end ARC_CPUIF_OTHERS;
