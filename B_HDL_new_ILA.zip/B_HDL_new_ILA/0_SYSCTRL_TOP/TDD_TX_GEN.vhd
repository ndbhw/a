----------------------------------------------------------------------------------
-- Company: samsung electoric
-- Engineer: jinoo.bae 
--
-- Create Date: 2015-07-02 ���� 8:50:21
-- Design Name:
-- Module Name: TDD_TX_GEN_GEN - Behavioral
-- Project Name: KDDI 3.5G low power
-- Target Devices: Zynq045-2LI
-- Tool Versions: vivado20144
-- Description:
--
-- Dependencies:
--
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
----------------------------------------------------------------------------------

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;
--
--library UNISIM;
--use UNISIM.VComponents.all;
--
--use work.pkg_func.all;

entity TDD_TX_GEN is
    generic(
        latency                : natural := 5   --5
    ); 
port(
    RESET                                   : in  std_logic;
    CLK                                     : in  std_logic;                        -- 245.76MHZ
    
    IN_BFN_STROBE                           : in  std_logic;                        -- recoved 
    
----------------------------------------------------------------------
--  output signal 
----------------------------------------------------------------------
    OUT_TX_TDD                              : out std_logic;
    OUT_BFN_STROBE                          : out std_logic;

    BFN_FAIL                                : out std_logic;
    BFN_ABNORMAL_CNT                        : out std_logic_vector(7 downto 0);
    
--------------------------------------------------------------------------------
-- Main MPI
--------------------------------------------------------------------------------   
    UL_DL_CONFIG                            : in  std_logic_vector(2 downto 0);     -- Uplink-downlink configuration    
    SSF_CONFIG                              : in  std_logic_vector(3 downto 0);     -- DwPTS/UpPTS configuration    
    DL_CP_EXTENDED                          : in  std_logic;
    
    DL_OFFSET                               : in  std_logic_vector(18 downto 0);
    DL_TDD_ON                               : in  std_logic_vector(14 downto 0);
    DL_TDD_OFF                              : in  std_logic_vector(14 downto 0)
    );
end TDD_TX_GEN;

architecture Behavioral of TDD_TX_GEN is

signal cdc_ref_10ms                     : std_logic_vector(2 downto 0);
signal ref_check                        : std_logic_vector(2 downto 0);
signal ref_invalid                      : std_logic;
signal cnt_abnormal                     : std_logic_vector(7 downto 0);

signal cnt_base                         : std_logic_vector(2 downto 0);
signal cnt_sample_dl                    : std_logic_vector(18 downto 0);

signal ref_cnt_base                     : std_logic_vector(2 downto 0);
signal ref_cnt_sample_dl                : std_logic_vector(14 downto 0);
signal ref_cnt_subframe_dl              : std_logic_vector(3 downto 0);
signal ref_cnt_frame                    : std_logic_vector(6 downto 0);
signal ref_gen_tdd                      : std_logic;
                                                                       
signal info_dl                          : std_logic_vector(9 downto 0);

signal cnt_dl_tdd_on                    : std_logic_vector(14 downto 0);
signal cnt_dl_tdd_off                   : std_logic_vector(14 downto 0);

signal update_trig                      : std_logic;

signal i_ul_dl_config                   : std_logic_vector(2 downto 0);     -- uplink-downlink configuration    
signal i_ssf_config                     : std_logic_vector(3 downto 0);     -- dwpts/uppts configuration    
signal i_dl_cp_extended                 : std_logic;
 
signal i_adv_dl_offset                  : std_logic_vector(18 downto 0);
signal i_dl_tdd_on                      : std_logic_vector(14 downto 0);
signal i_dl_tdd_off                     : std_logic_vector(14 downto 0);

begin

    BFN_FAIL                            <= ref_invalid;
    BFN_ABNORMAL_CNT                    <= cnt_abnormal;

----------------------------------------------------------------------
-- validation of bfn 
----------------------------------------------------------------------
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            cdc_ref_10ms <= (others => '0');
            update_trig  <= '0';
        elsif (CLK'event and CLK = '1') then
            cdc_ref_10ms <= cdc_ref_10ms(1 downto 0) & IN_BFN_STROBE;
            update_trig <= cdc_ref_10ms(1) and (not cdc_ref_10ms(2));
        end if;
    end process;
    
----------------------------------------------------------------------
-- TDD 10ms update configration 
----------------------------------------------------------------------    
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            i_ul_dl_config    <= (others => '0');
            i_ssf_config      <= (others => '0');
            i_dl_cp_extended  <= '0';
                  
            i_adv_dl_offset   <= (others => '0');
            i_dl_tdd_on       <= (others => '0');
            i_dl_tdd_off      <= (others => '0');           
        elsif (CLK'event and CLK = '1') then
            if (update_trig = '1') then 
                i_ul_dl_config    <= UL_DL_CONFIG;
                i_ssf_config      <= SSF_CONFIG;
                i_dl_cp_extended  <= DL_CP_EXTENDED;
                  
                i_adv_dl_offset   <= DL_OFFSET;
                i_dl_tdd_on       <= DL_TDD_ON;
                i_dl_tdd_off      <= DL_TDD_OFF;       
            else 
                i_ul_dl_config    <= i_ul_dl_config;    
                i_ssf_config      <= i_ssf_config;      
                i_dl_cp_extended  <= i_dl_cp_extended;  
                                                      
                i_adv_dl_offset   <= i_adv_dl_offset;   
                i_dl_tdd_on       <= i_dl_tdd_on;       
                i_dl_tdd_off      <= i_dl_tdd_off;      
            end if;
        end if;
    end process;

    -- generate the check point
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ref_check <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (cdc_ref_10ms(2 downto 1) = "01") then
                if (ref_invalid = '0') then
                    ref_check <= "111";
                else
                    ref_check <= "010";
                end if;
            else
                ref_check <= ref_check(1 downto 0) & '0';
            end if;
        end if;
    end process;    
    
    
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ref_invalid  <= '1';
            cnt_abnormal <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if ((cnt_base = 8-1) and (cnt_sample_dl = 307200-1)) then            
                if (ref_check(2) = '1') then
                    ref_invalid  <= '0';
                else
                    ref_invalid  <= '1';
                    cnt_abnormal <= cnt_abnormal + 1;
                end if;
            end if;
        end if;
    end process;

----------------------------------------------------------------------
-- generate the counter
----------------------------------------------------------------------
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            cnt_base        <= (others => '0');
            cnt_sample_dl   <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (ref_invalid = '1' and ref_check(2) = '1') then
                cnt_base        <= (others => '0');
                cnt_sample_dl   <= (others => '0');
            else
                cnt_base        <= cnt_base + 1;
                if (cnt_base = 8-1) then
                    if (cnt_sample_dl = 307200-1) then
                        cnt_sample_dl   <= (others => '0');
                    else
                        cnt_sample_dl   <= cnt_sample_dl + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

----------------------------------------------------------------------
-- generate the counter
----------------------------------------------------------------------
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ref_cnt_base        <= (others => '0');
            ref_cnt_sample_dl   <= (others => '0');
            ref_cnt_subframe_dl <= (others => '0');
            ref_cnt_frame       <= (others => '0');
            OUT_BFN_STROBE      <= '0';
        elsif (CLK'event and CLK = '1') then
            if ((cnt_base = 8-1-(latency)) and (cnt_sample_dl = 307200-1-(i_adv_dl_offset))) then            
                ref_cnt_base        <= (others => '0');
                ref_cnt_sample_dl   <= (others => '0');
                ref_cnt_subframe_dl <= (others => '0');
                ref_cnt_frame       <= (others => '0');
            else 
                ref_cnt_base        <= ref_cnt_base + 1;
                if (ref_cnt_base = 8-1) then
                    if (ref_cnt_sample_dl = 30720-1) then
                        ref_cnt_sample_dl   <= (others => '0');
                        if (ref_cnt_subframe_dl = 10-1) then
                            ref_cnt_subframe_dl <= (others => '0');
                            if (ref_cnt_frame = 100-1) then
                                ref_cnt_frame    <= (others => '0');
                            else
                                ref_cnt_frame    <= ref_cnt_frame + 1;
                            end if;
                        else
                            ref_cnt_subframe_dl <= ref_cnt_subframe_dl + 1;
                        end if;
                    else
                        ref_cnt_sample_dl   <= ref_cnt_sample_dl + 1;
                    end if;
                end if;
            end if;
            if(ref_cnt_sample_dl = 0 and ref_cnt_subframe_dl = 0) then 
                OUT_BFN_STROBE <= '1';
            else 
                if(ref_cnt_sample_dl = 8 and ref_cnt_subframe_dl = 0) then 
                    OUT_BFN_STROBE <= '0';
                end if;
            end if;
        end if;
    end process;

----------------------------------------------------------------------
-- generate TDD information for downlink
----------------------------------------------------------------------
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            info_dl <= (others => '0');
        elsif (CLK'event and CLK = '1') then
            if (ref_cnt_base = 8-1) then
                if (ref_cnt_sample_dl = 30720-1) then
                    if (ref_cnt_subframe_dl = 9) then
                        case i_ul_dl_config is
                        when "000"  => info_dl <= "1000010000";
                        when "001"  => info_dl <= "1000110001";
                        when "010"  => info_dl <= "1001110011";
                        when "011"  => info_dl <= "1000011111";
                        when "100"  => info_dl <= "1000111111";
                        when "101"  => info_dl <= "1001111111";
                        when "110"  => info_dl <= "1000010001";
                        when others => info_dl <= (others => '0');
                        end case;
                    else
                        info_dl <= info_dl(8 downto 0) & info_dl(9);
                    end if;
                end if;
            end if;
        end if;
    end process;


    -- TDD
    cnt_dl_tdd_on <= conv_std_logic_vector(30720-1, 15) - i_dl_tdd_on;


    --inner delay
    process (i_ssf_config, i_dl_cp_extended, i_dl_tdd_off)
    begin
        if (i_dl_cp_extended = '1') then
            case i_ssf_config is
            when x"1"   => cnt_dl_tdd_off <= conv_std_logic_vector(20480-1, 15) + i_dl_tdd_off;
            when x"2"   => cnt_dl_tdd_off <= conv_std_logic_vector(23040-1, 15) + i_dl_tdd_off;
            when x"3"   => cnt_dl_tdd_off <= conv_std_logic_vector(25600-1, 15) + i_dl_tdd_off;
--            when x"4"   => cnt_dl_tdd_off <= conv_std_logic_vector( 7680-1, 15) + i_dl_tdd_off;
            when x"5"   => cnt_dl_tdd_off <= conv_std_logic_vector(20480-1, 15) + i_dl_tdd_off;
            when x"6"   => cnt_dl_tdd_off <= conv_std_logic_vector(23040-1, 15) + i_dl_tdd_off; 
            when others => cnt_dl_tdd_off <= conv_std_logic_vector( 7680-1, 15) + i_dl_tdd_off;
            end case;
        else
            case i_ssf_config is
            when x"1"   => cnt_dl_tdd_off <= conv_std_logic_vector(19760-1, 15) + i_dl_tdd_off;
            when x"2"   => cnt_dl_tdd_off <= conv_std_logic_vector(21952-1, 15) + i_dl_tdd_off;
            when x"3"   => cnt_dl_tdd_off <= conv_std_logic_vector(24144-1, 15) + i_dl_tdd_off;
            when x"4"   => cnt_dl_tdd_off <= conv_std_logic_vector(26336-1, 15) + i_dl_tdd_off;
--            when x"5"   => cnt_dl_tdd_off <= conv_std_logic_vector( 6592-1, 15) + i_dl_tdd_off;
            when x"6"   => cnt_dl_tdd_off <= conv_std_logic_vector(19760-1, 15) + i_dl_tdd_off; 
            when x"7"   => cnt_dl_tdd_off <= conv_std_logic_vector(21952-1, 15) + i_dl_tdd_off;
            when x"8"   => cnt_dl_tdd_off <= conv_std_logic_vector(24144-1, 15) + i_dl_tdd_off; 
            when others => cnt_dl_tdd_off <= conv_std_logic_vector( 6592-1, 15) + i_dl_tdd_off;
            end case;
        end if;
    end process;
    
    process (RESET, CLK)
    begin
        if (RESET = '1') then
            ref_gen_tdd <= '0';
        elsif (CLK'event and CLK = '1') then
            if (info_dl(9) = '0') then
                if (info_dl(8) = '1') then                                      -- to DL
                    if (ref_cnt_sample_dl = cnt_dl_tdd_on) then
                        if(ref_cnt_base = 7) then 
                            ref_gen_tdd <= '1';
                        end if;
                    end if;
                else                                                            -- to UL
                    if (ref_cnt_sample_dl = cnt_dl_tdd_off) then
                        if(ref_cnt_base = 7) then 
                            ref_gen_tdd <= '0';
                        end if;
                    end if;
                end if;
            else                                                                -- at DL
                ref_gen_tdd <= '1';
            end if;
        end if;
    end process;


----------------------------------------------------------------------
-- re timing 
----------------------------------------------------------------------

    process (RESET, CLK)
    begin
        if (RESET = '1') then
            OUT_TX_TDD <= '0';
        elsif (CLK'event and CLK = '1') then
            OUT_TX_TDD <= ref_gen_tdd;
        end if;   
    end process;


end Behavioral;
