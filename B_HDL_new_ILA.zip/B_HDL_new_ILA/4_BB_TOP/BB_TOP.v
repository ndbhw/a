////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : DCM RT4419/RT4422
//  Module       : BB_TOP 
//  Author       : jyzoo.lee@samsung.com
//  Description  : Baseband LPHY TOP for RT4419/RT4422
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.30 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2020.12.15 | jyzoo.lee     | Updated from the latest Design (top, core)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "BB_TOP.vh"

module BB_TOP
#(
    parameter   NUM_CC              =  `NUM_CC          
   ,parameter   MAX_CC              =  `MAX_CC
   ,parameter   DL_NUM_LAYER        =  `DL_NUM_LAYER 
   ,parameter   DL_NUM_ANT          =  `DL_NUM_ANT    
   ,parameter   UL_NUM_PATH         =  `UL_NUM_PATH 
   ,parameter   UL_NUM_ANT          =  `UL_NUM_ANT
   ,parameter   TOP_DIO_BW          =   16
   ,parameter   CPUIF_ADDR_BW       =   16 
   ,parameter   CPUIF_DATA_BW       =   32
)(
    //--- From SYSCTRL_TOP
        input   wire                                                i_core_clk  
    ,   input   wire    [MAX_CC-1:0]                                i_core_arst_bbtop
    ,   input   wire    [MAX_CC-1:0]                                i_core_arst_dlfe
    ,   input   wire    [MAX_CC-1:0]                                i_core_arst_ulfe
    ,   input   wire    [MAX_CC-1:0]                                i_core_arst_rafe

    //--- From/To CPU IF
    ,   input   wire                                                i_cpu_clk  
    ,   input   wire                                                i_cpu_arst
    ,   input   wire    [00:0]                                      i_bb_cpu_cs
    ,   input   wire    [CPUIF_ADDR_BW-1:0]                         i_bb_cpu_addr
    ,   input   wire    [00:0]                                      i_bb_cpu_wren
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_bb_cpu_wdata
    ,   input   wire    [00:0]                                      i_bb_cpu_rden
    ,   output  wire    [CPUIF_DATA_BW-1:0]                         o_bb_cpu_rdata
    ,   output  wire    [00:0]                                      o_bb_cpu_rd_valid

    //--- From/To ORAN_TOP(DL)
    ,   input   wire    [01*MAX_CC-1:0]                             i_din_frame_sync  
    ,   input   wire    [08*MAX_CC-1:0]                             i_din_frame_idx   
    ,   input   wire    [01*DL_NUM_LAYER*MAX_CC-1:0]                i_din_en          
    ,   input   wire    [01*DL_NUM_LAYER*MAX_CC-1:0]                i_din_re_mask     
    ,   input   wire    [2*TOP_DIO_BW*DL_NUM_LAYER*MAX_CC-1:0]      i_din_iq          
    ,   output  wire    [01*MAX_CC-1:0]                             o_dout_dl_sys_mode      //ccx dl output system mode 
    ,   output  wire    [12*MAX_CC-1:0]                             o_dout_dl_ntone   
    ,   output  wire    [02*MAX_CC-1:0]                             o_dout_dl_fft_type
    ,   output  wire    [12*MAX_CC-1:0]                             o_dout_dl_k0

    //--- To ORAN_TOP (PUxCH)
    ,   output  wire    [01*MAX_CC-1:0]                             o_uout_frame_sync
    ,   output  wire    [08*MAX_CC-1:0]                             o_uout_frame_idx        
    ,   output  wire    [04*MAX_CC-1:0]                             o_uout_subfrm_idx       
    ,   output  wire    [06*MAX_CC-1:0]                             o_uout_slot_idx         
    ,   output  wire    [06*MAX_CC-1:0]                             o_uout_symbol_idx       
    ,   output  wire    [16*UL_NUM_PATH*MAX_CC-1:0]                 o_uout_start_re_idx     
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_uout_en               
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_uout_start_re         
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_uout_last_re          
    ,   output  wire    [2*TOP_DIO_BW*UL_NUM_PATH*MAX_CC-1:0]       o_uout_iq            

    //--- From/To ORAN_TOP (PRACH)
    ,   input   wire	[01*MAX_CC-1:0]                             i_rin_frame_sync   
    ,   input   wire	[04*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_filter_idx   
    ,   input   wire  	[16*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_time_offset  
    ,   input   wire  	[08*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_frame_struct 
    ,   input   wire  	[16*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_cp_length    
    ,   input   wire  	[24*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_freq_offset  
    ,   input   wire  	[04*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_num_psymbol  
    ,   input   wire  	[03*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_num_ro       
    ,   input   wire  	[08*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_num_prbc
    ,   input   wire  	[10*UL_NUM_PATH*MAX_CC-1:0]                 i_rin_start_prbc
    
    ,   output  wire    [MAX_CC-1:0]                                o_rout_frame_sync 
    ,   output  wire    [08*MAX_CC-1:0]                             o_rout_frame_idx        
    ,   output  wire    [04*MAX_CC-1:0]                             o_rout_subfrm_idx       
    ,   output  wire    [06*MAX_CC-1:0]                             o_rout_slot_idx         
    ,   output  wire    [06*MAX_CC-1:0]                             o_rout_symbol_idx       
    ,   output  wire    [16*UL_NUM_PATH*MAX_CC-1:0]                 o_rout_start_re_idx     
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_rout_en               
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_rout_start_re         
    ,   output  wire    [01*UL_NUM_PATH*MAX_CC-1:0]                 o_rout_last_re          
    ,   output  wire    [2*TOP_DIO_BW*UL_NUM_PATH*MAX_CC-1:0]       o_rout_iq                

    //--- To BBCTRL(DL)
    ,   output  wire    [01*NUM_CC-1:0]                             o_dout_frame_sync
    ,   output  reg     [01*DL_NUM_ANT*MAX_CC-1:0]                  o_dout_en        
    ,   output  reg     [TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]          o_dout_i        
    ,   output  reg     [TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]          o_dout_q        

    //--- FROM BBCTRL(UL)
    ,   input   wire    [01*NUM_CC-1:0]                             i_uin_frame_sync 
    ,   input   wire    [01*UL_NUM_ANT*MAX_CC-1:0]                  i_uin_en         
    ,   input   wire    [TOP_DIO_BW*UL_NUM_ANT*MAX_CC-1:0]          i_uin_i         
    ,   input   wire    [TOP_DIO_BW*UL_NUM_ANT*MAX_CC-1:0]          i_uin_q         
    
    // dbg ulfe_input
    ,   output   wire                                               o_dbg_uin_frame_sync 
    ,   output   wire                                               o_dbg_uin_en         
    ,   output   wire    [TOP_DIO_BW - 1:0]                         o_dbg_uin_i         
    ,   output   wire    [TOP_DIO_BW - 1:0]                         o_dbg_uin_q
    
);

//local parameter
localparam  DLY_RST                 =       4                                                       ;
localparam  CPUIF_BB_ADDR_BW        =       20                                                      ;
localparam  DUMP_MEM_ADDR_BW        =       15                                                      ;
localparam  DLY_REG_RD              =       5                                                       ;
localparam  CC_OFFSET               =       20'h10000                                               ;  
localparam  DLFE_ADDR_OFFSET        =       20'h00000                                               ;           
localparam  ULFE_ADDR_OFFSET        =       20'h05000                                               ;           
localparam  RAFE_ADDR_OFFSET        =       20'h09000                                               ;           
localparam  MAX_ANT                 =       DL_NUM_ANT>UL_NUM_ANT ? DL_NUM_ANT : UL_NUM_ANT         ;
localparam  CORE_CLK_FRAME          =       2457600                                                 ;
localparam  VENDOR                  =       "Xilinx"                                                ;

//logic variable
genvar  gcc, gant ;
integer ant ;

//module signal declaration
//u00_dlfe_core_cc
wire    [12-1:0]                                w_cc_din_bfn            [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_din_frame_sync     [MAX_CC-1:0]                ; 
wire    [08-1:0]                                w_cc_din_frame_idx      [MAX_CC-1:0]                ; 
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_en             [MAX_CC-1:0]                ;
wire    [08*DL_NUM_ANT-1:0]                     w_cc_din_frame_struct   [MAX_CC-1:0]                ;        
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_sys_mode_dss   [MAX_CC-1:0]                ;            
wire    [01*DL_NUM_ANT-1:0]                     w_cc_din_re_mask        [MAX_CC-1:0]                ;            
wire    [2*TOP_DIO_BW*DL_NUM_ANT-1:0]           w_cc_din_iq             [MAX_CC-1:0]                ; 
wire    [15*DL_NUM_ANT-1:0]                     w_cc_din_beam_id        [MAX_CC-1:0]                ;            
wire    [10*DL_NUM_ANT-1:0]                     w_cc_din_start_prbu     [MAX_CC-1:0]                ;            
wire    [08*DL_NUM_ANT-1:0]                     w_cc_din_num_prbu       [MAX_CC-1:0]                ;            
wire    [24*DL_NUM_ANT-1:0]                     w_cc_din_freq_offset    [MAX_CC-1:0]                ;            
wire    [05-1:0]                                w_cc_din_nlayer         [MAX_CC-1:0]                ;            
wire    [01-1:0]                                w_cc_dout_bfn_strb      [MAX_CC-1:0]                ;
wire    [12-1:0]                                w_cc_dout_bfn           [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_dout_frame_sync    [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_dout_subfrm_sync   [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_dout_slot_sync     [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_dout_symbol_sync   [MAX_CC-1:0]                ; 
wire    [08-1:0]                                w_cc_dout_frame_idx     [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_dout_subfrm_idx    [MAX_CC-1:0]                ; 
wire    [06-1:0]                                w_cc_dout_slot_idx      [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_dout_symbol_idx    [MAX_CC-1:0]                ;
wire    [01*DL_NUM_ANT-1:0]                     w_cc_dout_en            [MAX_CC-1:0]                ;             
wire    [2*TOP_DIO_BW*DL_NUM_ANT-1:0]           w_cc_dout_iq            [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_dout_dl_bw_idx     [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_dout_dl_sys_mode   [MAX_CC-1:0]                ;
wire    [12-1:0]                                w_cc_dout_dl_ntone      [MAX_CC-1:0]                ;
wire    [02-1:0]                                w_cc_dout_dl_fft_type   [MAX_CC-1:0]                ;
wire    [12-1:0]                                w_cc_dout_dl_k0         [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_dout_bcf_en        [MAX_CC-1:0]                ;
reg     [01-1:0]                                r_cc_dout_frame_sync    [MAX_CC-1:0]                ; 

//u01_ulfe_core_cc
wire    [01-1:0]                                w_cc_uin_frame_sync     [MAX_CC-1:0]                ; 
wire    [08-1:0]                                w_cc_uin_frame_idx      [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uin_en             [MAX_CC-1:0]                ; 
reg     [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           r_cc_uin_iq             [MAX_CC-1:0]                ;

wire     [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           r_cc_uin_iq_dly         [MAX_CC-1:0]                ; 
 
wire    [01-1:0]                                w_cc_uout_frame_sync    [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_uout_symbol_sync   [MAX_CC-1:0]                ; 
wire    [08-1:0]                                w_cc_uout_frame_idx     [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_uout_subfrm_idx    [MAX_CC-1:0]                ; 
wire    [06-1:0]                                w_cc_uout_slot_idx      [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_uout_symbol_idx    [MAX_CC-1:0]                ;
wire    [16*UL_NUM_ANT-1:0]                     w_cc_uout_start_re_idx  [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_en            [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_start_re      [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_uout_last_re       [MAX_CC-1:0]                ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_uout_iq            [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_uout_ul_bw_idx     [MAX_CC-1:0]                ;
reg     [01-1:0]                                r_cc_uin_frame_sync     [MAX_CC-1:0]                ; 

//u02_rafe_core_cc
wire    [01-1:0]                                w_cc_rin_frame_sync     [MAX_CC-1:0]                ; 
wire    [04*UL_NUM_ANT-1:0]                     w_cc_rin_filter_idx     [MAX_CC-1:0]                ; 
wire    [16*UL_NUM_ANT-1:0]                     w_cc_rin_time_offset    [MAX_CC-1:0]                ; 
wire    [08*UL_NUM_ANT-1:0]                     w_cc_rin_frame_struct   [MAX_CC-1:0]                ; 
wire    [16*UL_NUM_ANT-1:0]                     w_cc_rin_cp_length      [MAX_CC-1:0]                ;
wire    [24*UL_NUM_ANT-1:0]                     w_cc_rin_freq_offset    [MAX_CC-1:0]                ; 
wire    [04*UL_NUM_ANT-1:0]                     w_cc_rin_num_psymbol    [MAX_CC-1:0]                ; 
wire    [03*UL_NUM_ANT-1:0]                     w_cc_rin_num_ro         [MAX_CC-1:0]                ; 
wire    [08*UL_NUM_ANT-1:0]                     w_cc_rin_num_prbc       [MAX_CC-1:0]                ; 
wire    [10*UL_NUM_ANT-1:0]                     w_cc_rin_start_prbc     [MAX_CC-1:0]                ; 
wire    [01-1:0]                                w_cc_rout_frame_sync    [MAX_CC-1:0]                ; 
wire    [08-1:0]                                w_cc_rout_frame_idx     [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_rout_subfrm_idx    [MAX_CC-1:0]                ; 
wire    [06-1:0]                                w_cc_rout_slot_idx      [MAX_CC-1:0]                ; 
wire    [04-1:0]                                w_cc_rout_symbol_idx    [MAX_CC-1:0]                ;
wire    [16*UL_NUM_ANT-1:0]                     w_cc_rout_start_re_idx  [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_rout_en            [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_rout_start_re      [MAX_CC-1:0]                ; 
wire    [01*UL_NUM_ANT-1:0]                     w_cc_rout_last_re       [MAX_CC-1:0]                ; 
wire    [2*TOP_DIO_BW*UL_NUM_ANT-1:0]           w_cc_rout_iq            [MAX_CC-1:0]                ; 

//u03_bb_top_cpu_if
wire    [CPUIF_BB_ADDR_BW*MAX_CC-1:0]           w_core_addr                                         ;
wire    [01*MAX_CC-1:0]                         w_core_wren                                         ;
wire    [CPUIF_DATA_BW*MAX_CC-1:0]              w_core_wdata                                        ;
wire    [01*MAX_CC-1:0]                         w_core_rden                                         ;
wire    [CPUIF_DATA_BW*MAX_CC-1:0]              w_core_rdata                                        ;
wire    [01*MAX_CC-1:0]                         w_core_rd_valid                                     ;
wire    [CPUIF_BB_ADDR_BW-1:0]                  w_cc_s_core_addr        [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_s_core_wren        [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_core_wdata       [MAX_CC-1:0]                ;
wire    [01-1:0]                                w_cc_s_core_rden        [MAX_CC-1:0]                ;
reg     [CPUIF_DATA_BW-1:0]                     r_cc_s_core_rdata       [MAX_CC-1:0]                ;
reg     [01-1:0]                                r_cc_s_core_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_dlfe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_dlfe_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_ulfe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_ulfe_rd_valid    [MAX_CC-1:0]                ;
wire    [CPUIF_DATA_BW-1:0]                     w_cc_s_rafe_rdata       [MAX_CC-1:0]                ;
wire    [00:0]                                  w_cc_s_rafe_rd_valid    [MAX_CC-1:0]                ;
wire    [32-1:0]                                w_bb_top_par_100000                                 ;
wire    [22-1:0]                                w_bb_top_par_100004                                 ;
wire    [01-1:0]                                w_sigcap_par_110000                                 ;
wire    [01-1:0]                                w_sigcap_par_110004                                 ;
wire    [02-1:0]                                w_sigcap_par_110008                                 ;
wire    [03-1:0]                                w_sigcap_par_11000c                                 ;
wire    [06-1:0]                                w_sigcap_par_110010                                 ;
wire    [04-1:0]                                w_sigcap_par_110014                                 ;
wire    [03-1:0]                                w_sigcap_par_110018                                 ;
wire    [03-1:0]                                w_sigcap_par_11001c                                 ;
wire    [03-1:0]                                w_sigcap_par_110020                                 ;
wire    [03-1:0]                                w_sigcap_par_110024                                 ;

wire     [31 :0]                                 ulfe_data_dly         [MAX_CC-1:0]                                 ;
//u05_cpu_rst_sync
wire                                            w_cpu_rst                                           ; 

//u06_bb_top_rst_sync
wire    [MAX_CC-1:0]                            w_core_rst_bbtop                                    ; 
wire    [MAX_CC-1:0]                            w_core_rst_dlfe                                     ; 
wire    [MAX_CC-1:0]                            w_core_rst_ulfe                                     ;
wire    [MAX_CC-1:0]                            w_core_rst_rafe                                     ;

//u07_sig_cap
wire    [00:0]                                  w_dump_wr_en                                        ;
wire    [DUMP_MEM_ADDR_BW-1:0]                  w_dump_wr_addr                                      ; 
wire    [CPUIF_DATA_BW-1:0]                     w_dump_wr_data                                      ; 
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_dl_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW*MAX_ANT-1:0]              w_nr_ra_cp_data_cc      [MAX_CC-1:0]                ;
wire    [2*TOP_DIO_BW-1:0]                      w_nr_dl_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
wire    [2*TOP_DIO_BW-1:0]                      w_nr_ra_cp_data_cc_ant  [MAX_CC-1:0][MAX_ANT-1:0]   ;   
reg     [12*MAX_CC-1:0]                         r_sig_cap_bfn                                       ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_din_frame_sync                            ; 
reg     [01*DL_NUM_ANT*MAX_CC-1:0]              r_sig_cap_din_en                                    ;             
reg     [2*TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]    r_sig_cap_din_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_dout_frame_sync                           ; 
reg     [01*DL_NUM_ANT*MAX_CC-1:0]              r_sig_cap_dout_en                                   ;             
reg     [2*TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]    r_sig_cap_dout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_uout_frame_sync                           ; 
reg     [01*DL_NUM_ANT*MAX_CC-1:0]              r_sig_cap_uout_en                                   ;             
reg     [2*TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]    r_sig_cap_uout_iq                                   ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_uin_frame_sync                            ; 
reg     [01*DL_NUM_ANT*MAX_CC-1:0]              r_sig_cap_uin_en                                    ;             
reg     [2*TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]    r_sig_cap_uin_iq                                    ; 
reg     [01*MAX_CC-1:0]                         r_sig_cap_rout_frame_sync                           ; 
reg     [01*DL_NUM_ANT*MAX_CC-1:0]              r_sig_cap_rout_en                                   ;             
reg     [2*TOP_DIO_BW*DL_NUM_ANT*MAX_CC-1:0]    r_sig_cap_rout_iq                                   ; 
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_dl_cp_data                             ;
reg     [2*TOP_DIO_BW*MAX_ANT*MAX_CC-1:0]       r_sig_cap_nr_ra_cp_data                             ;
reg     [01-1:0]                                r_sigcap_par_110000                                 ;
reg     [01-1:0]                                r_sigcap_par_110004                                 ;
reg     [02-1:0]                                r_sigcap_par_110008                                 ;
reg     [03-1:0]                                r_sigcap_par_11000c                                 ;
reg     [06-1:0]                                r_sigcap_par_110010                                 ;
reg     [04-1:0]                                r_sigcap_par_110014                                 ;
reg     [03-1:0]                                r_sigcap_par_110018                                 ;
reg     [03-1:0]                                r_sigcap_par_11001c                                 ;
reg     [03-1:0]                                r_sigcap_par_110020                                 ;
reg     [03-1:0]                                r_sigcap_par_110024                                 ;

`ifndef DLFE_CORE_DISABLE
//u00_dlfe_cc(dl_cpu if + dl oran if + nr pdxch + nr ssb)
generate for(gcc=0; gcc<NUM_CC/`DLFE_NUM_CC_MUX; gcc=gcc+1) begin : g00_dlfe_core_cc
    localparam  DLFE_CC_ADDR_OFFSET = gcc ? (DLFE_ADDR_OFFSET + CC_OFFSET) : DLFE_ADDR_OFFSET;
dlfe_cc 
`ifndef NSIM
#(  .CC_IDX                 (gcc                    )
    ,.NUM_CC                (`DLFE_NUM_CC_MUX       )          
    ,.NUM_LAYER             ( DL_NUM_LAYER          )          
    ,.NUM_ANT               ( DL_NUM_ANT            )          
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-4          )
    ,.ADDR_OFFSET           ( DLFE_CC_ADDR_OFFSET   )
    ,.VENDOR                ( VENDOR                ))
`endif //NSIM
u00_dlfe_core_cc
(
    .i_clk                  ( i_core_clk                    ) 
   ,.i_rst                  ( w_core_rst_dlfe       [gcc]   ) 
   ,.i_cpu_addr             ( w_cc_s_core_addr      [gcc]   ) 
   ,.i_cpu_wren             ( w_cc_s_core_wren      [gcc]   ) 
   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [gcc]   ) 
   ,.i_cpu_rden             ( w_cc_s_core_rden      [gcc]   ) 
   ,.o_cpu_rdata            ( w_cc_s_dlfe_rdata     [gcc]   ) 
   ,.o_cpu_rd_valid         ( w_cc_s_dlfe_rd_valid  [gcc]   ) 
   ,.i_din_bfn              ( w_cc_din_bfn          [gcc]   ) 
   ,.i_din_frame_sync       ( w_cc_din_frame_sync   [gcc]   ) 
   ,.i_din_frame_idx        ( w_cc_din_frame_idx    [gcc]   ) 
   ,.i_din_en               ( w_cc_din_en           [gcc]   ) 
   ,.i_din_frame_struct     ( w_cc_din_frame_struct [gcc]   ) 
   ,.i_din_sys_mode_dss     ( w_cc_din_sys_mode_dss [gcc]   )          
   ,.i_din_re_mask          ( w_cc_din_re_mask      [gcc]   ) 
   ,.i_din_iq               ( w_cc_din_iq           [gcc]   ) 
   ,.i_din_beam_id          ( w_cc_din_beam_id      [gcc]   ) 
   ,.i_din_start_prbu       ( w_cc_din_start_prbu   [gcc]   ) 
   ,.i_din_num_prbu         ( w_cc_din_num_prbu     [gcc]   ) 
   ,.i_din_freq_offset      ( w_cc_din_freq_offset  [gcc]   ) 
   ,.i_din_nlayer           ( w_cc_din_nlayer       [gcc]   ) 
   ,.o_dout_bfn_strb        ( w_cc_dout_bfn_strb    [gcc]   ) 
   ,.o_dout_bfn             ( w_cc_dout_bfn         [gcc]   ) 
   ,.o_dout_frame_sync      ( w_cc_dout_frame_sync  [gcc]   ) 
   ,.o_dout_subfrm_sync     ( w_cc_dout_subfrm_sync [gcc]   ) 
   ,.o_dout_slot_sync       ( w_cc_dout_slot_sync   [gcc]   ) 
   ,.o_dout_symbol_sync     ( w_cc_dout_symbol_sync [gcc]   ) 
   ,.o_dout_frame_idx       ( w_cc_dout_frame_idx   [gcc]   ) 
   ,.o_dout_subfrm_idx      ( w_cc_dout_subfrm_idx  [gcc]   ) 
   ,.o_dout_slot_idx        ( w_cc_dout_slot_idx    [gcc]   ) 
   ,.o_dout_symbol_idx      ( w_cc_dout_symbol_idx  [gcc]   ) 
   ,.o_dout_en              ( w_cc_dout_en          [gcc]   ) 
   ,.o_dout_iq              ( w_cc_dout_iq          [gcc]   ) 
   ,.o_dout_dl_bw_idx       ( w_cc_dout_dl_bw_idx   [gcc]   ) 
   ,.o_dout_dl_sys_mode     ( w_cc_dout_dl_sys_mode [gcc]   )
   ,.o_dout_dl_ntone        ( w_cc_dout_dl_ntone    [gcc]   ) 
   ,.o_dout_dl_fft_type     ( w_cc_dout_dl_fft_type [gcc]   ) 
   ,.o_dout_dl_k0           ( w_cc_dout_dl_k0       [gcc]   ) 
   ,.o_dout_bcf_en          ( w_cc_dout_bcf_en      [gcc]   )
);
end
endgenerate
`endif //DLFE_CORE_DISABLE 

`ifndef ULFE_CORE_DISABLE
//u01_ulfe_cc(ul cpu if + nr puxch)

assign o_uout_frame_sync[0] = w_cc_uout_frame_sync[0];

assign o_dbg_uin_frame_sync = w_cc_uin_frame_sync[0];
assign o_dbg_uin_en         = w_cc_uin_en[0];
//assign o_dbg_uin_i          = r_cc_uin_iq[0][31:16];
//assign o_dbg_uin_q          = r_cc_uin_iq[0][15:0];
assign o_dbg_uin_i          = r_cc_uin_iq_dly[0][31:16];
assign o_dbg_uin_q          = r_cc_uin_iq_dly[0][15:0];

generate for(gcc=0; gcc<NUM_CC; gcc=gcc+1) begin : g01_ulfe_core_cc
    localparam  ULFE_CC_ADDR_OFFSET = gcc ? (ULFE_ADDR_OFFSET + CC_OFFSET) : ULFE_ADDR_OFFSET;
ulfe_cc_oru 
`ifndef NSIM
#(   .NUM_ANT               ( UL_NUM_ANT            )   
    //,.NUM_CHAIN             ( 2                     )         
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    //,.DLY_REG_RD            ( DLY_REG_RD-3          )
    ,.ADDR_OFFSET           ( ULFE_CC_ADDR_OFFSET   )
    ,.CPUIF_BB_ADDR_BW      ( 20                    )
    //,.VENDOR                ( VENDOR                )
)
`endif //NSIM
u01_ulfe_core_cc_oru
(                                                               
    .i_clk                  ( i_core_clk                    )          
   ,.i_rst                  ( w_core_rst_ulfe         [gcc] )          
   ,.i_cpu_addr             ( w_cc_s_core_addr        [gcc] )          
   ,.i_cpu_wren             ( w_cc_s_core_wren        [gcc] )          
   ,.i_cpu_wdata            ( w_cc_s_core_wdata       [gcc] )          
   ,.i_cpu_rden             ( w_cc_s_core_rden        [gcc] )          
   ,.o_cpu_rdata            ( w_cc_s_ulfe_rdata       [gcc] )          
   ,.o_cpu_rd_valid         ( w_cc_s_ulfe_rd_valid    [gcc] )          
   ,.i_uin_frame_sync       ( w_cc_uin_frame_sync     [gcc] )          
   ,.i_uin_frame_idx        ( w_cc_uin_frame_idx      [gcc] )          
   ,.i_uin_en               ( w_cc_uin_en             [gcc] )          
//   ,.i_uin_iq               ( r_cc_uin_iq             [gcc] )
   ,.i_uin_iq               ( r_cc_uin_iq_dly         [gcc] )          
   ,.o_uout_frame_sync      ( w_cc_uout_frame_sync    [gcc] )
   ,.o_uout_frame_idx       ( w_cc_uout_frame_idx     [gcc] ) 
   ,.o_uout_subfrm_idx      ( w_cc_uout_subfrm_idx    [gcc] )   
   ,.o_uout_slot_idx        ( w_cc_uout_slot_idx      [gcc] )             
   ,.o_uout_symbol_sync     ( w_cc_uout_symbol_sync   [gcc] )             
   ,.o_uout_symbol_idx      ( w_cc_uout_symbol_idx    [gcc] )          
   ,.o_uout_en              ( w_cc_uout_en            [gcc] )          
   ,.o_uout_iq              ( w_cc_uout_iq            [gcc] )          
   ,.o_uout_start_re_idx    ( w_cc_uout_start_re_idx  [gcc] )          
   ,.o_uout_start_re        ( w_cc_uout_start_re      [gcc] )          
   ,.o_uout_last_re         ( w_cc_uout_last_re       [gcc] )          
   //,.o_uout_ul_bw_idx       ( w_cc_uout_ul_bw_idx     [gcc] )         
);

data_dly
#(  
    .MAX_DATA_DELAY (15360 * 2)     // lte scs 15k 10M
)
u_012_ulfe_data_dly
(
     .RESET                ( w_core_rst_ulfe        )       //  : in  std_logic;
    ,.CLK                  ( i_core_clk             )       //  : in  std_logic;
    
    ,.DATA_DELAY_VALUE     ( ulfe_data_dly [gcc]         )       //  : in  std_logic_vector(31 downto 0);
    
    ,.IN_DATA              ( r_cc_uin_iq  [gcc]     )       //  : in  std_logic_vector(63 downto 0);
    ,.OUT_DATA             ( r_cc_uin_iq_dly[gcc]   )       //  : out std_logic_vector(63 downto 0)
);

end
endgenerate
`endif //ULFE_CORE_DISABLE

`ifndef RAFE_CORE_DISABLE
//u02_rafe_cc(ra cpu if + nr prach)

assign o_rout_frame_sync = w_cc_rout_frame_sync[0];

generate for(gcc=0; gcc<NUM_CC; gcc=gcc+1) begin : g02_rafe_core_cc
    localparam  RAFE_CC_ADDR_OFFSET = gcc ? (RAFE_ADDR_OFFSET + CC_OFFSET) : RAFE_ADDR_OFFSET;
rafe_cc 
`ifndef NSIM
#(   .NUM_ANT               ( UL_NUM_ANT            )          
    ,.NUM_CHAIN             ( 1                     )
    ,.MAX_OBW               ( `MAX_OBW              )
    ,.TOP_DIO_BW            ( TOP_DIO_BW            ) 
    ,.DLY_REG_RD            ( DLY_REG_RD-3          )
    ,.ADDR_OFFSET           ( RAFE_CC_ADDR_OFFSET   )
    ,.VENDOR                ( VENDOR                ))
`endif //NSIM
u02_rafe_core_cc
(                                                               
    .i_clk                  ( i_core_clk                    )          
   ,.i_rst                  ( w_core_rst_rafe       [gcc]   )          
   ,.i_cpu_addr             ( w_cc_s_core_addr      [gcc]   )          
   ,.i_cpu_wren             ( w_cc_s_core_wren      [gcc]   )          
   ,.i_cpu_wdata            ( w_cc_s_core_wdata     [gcc]   )          
   ,.i_cpu_rden             ( w_cc_s_core_rden      [gcc]   )          
   ,.o_cpu_rdata            ( w_cc_s_rafe_rdata     [gcc]   )          
   ,.o_cpu_rd_valid         ( w_cc_s_rafe_rd_valid  [gcc]   )          
   ,.i_rin_frame_sync       ( w_cc_uin_frame_sync   [gcc]   )          
   ,.i_rin_frame_idx        ( w_cc_uin_frame_idx    [gcc]   )          
   ,.i_rin_en               ( w_cc_uin_en           [gcc]   )          
   ,.i_rin_iq               ( r_cc_uin_iq           [gcc]   )          
   ,.i_rin_filter_idx       ( w_cc_rin_filter_idx   [gcc]   )          
   ,.i_rin_time_offset      ( w_cc_rin_time_offset  [gcc]   )          
   ,.i_rin_frame_struct     ( w_cc_rin_frame_struct [gcc]   )          
   ,.i_rin_cp_length        ( w_cc_rin_cp_length    [gcc]   )          
   ,.i_rin_num_psymbol      ( w_cc_rin_num_psymbol  [gcc]   )          
   ,.i_rin_freq_offset      ( w_cc_rin_freq_offset  [gcc]   )          
   ,.i_rin_num_ro           ( w_cc_rin_num_ro       [gcc]   )          
   ,.i_rin_num_prbc         ( w_cc_rin_num_prbc     [gcc]   )          
   ,.i_rin_start_prbc       ( w_cc_rin_start_prbc   [gcc]   )    
   ,.o_rout_frame_sync      ( w_cc_rout_frame_sync  [gcc]   )          
   ,.o_rout_frame_idx       ( w_cc_rout_frame_idx   [gcc]   )          
   ,.o_rout_subfrm_idx      ( w_cc_rout_subfrm_idx  [gcc]   )          
   ,.o_rout_slot_idx        ( w_cc_rout_slot_idx    [gcc]   )          
   ,.o_rout_symbol_idx      ( w_cc_rout_symbol_idx  [gcc]   )          
   ,.o_rout_start_re_idx    ( w_cc_rout_start_re_idx[gcc]   )          
   ,.o_rout_en              ( w_cc_rout_en          [gcc]   )          
   ,.o_rout_start_re        ( w_cc_rout_start_re    [gcc]   )          
   ,.o_rout_last_re         ( w_cc_rout_last_re     [gcc]   )          
   ,.o_rout_iq              ( w_cc_rout_iq          [gcc]   )          
);
end
endgenerate
`endif //RAFE_CORE_DISABLE

generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g03_ul_sync
ylib_pshift_s #(
     .BW_SHIFT  (   $clog2(CORE_CLK_FRAME)  ))
u03_ul_sync
(
    .i_clk        ( i_core_clk                  )          
   ,.i_rst        ( w_core_rst_ulfe[gcc]        )
   ,.i_shift      ( w_bb_top_par_100004         )
   ,.i_in         ( i_uin_frame_sync            )
   ,.o_out        ( w_cc_uin_frame_sync[gcc]    )
);
assign  w_cc_uin_frame_idx [gcc]    =   w_cc_din_frame_idx [gcc]  ;
end
endgenerate

assign ulfe_data_dly [1] = ulfe_data_dly [0];

//u04_bb_top_cpu_if(cpu/oran)
bb_top_cpu_if #(
     .NUM_CC                ( MAX_CC                )
    ,.CPUIF_ADDR_BW         ( CPUIF_ADDR_BW         )
    ,.CPUIF_BB_ADDR_BW      ( CPUIF_BB_ADDR_BW      )
    ,.CPUIF_DATA_BW         ( CPUIF_DATA_BW         )
    ,.DUMP_MEM_ADDR_BW      ( DUMP_MEM_ADDR_BW      )
    ,.DLY_REG_RD            ( DLY_REG_RD-1          )
    ,.P4V_VERSION           (`P4V_VERSION           )
    ,.VENDOR                ( VENDOR                ))
u04_bb_top_cpu_if
(                                                               
    .i_rst                  ( w_core_rst_bbtop[0]           )          
   ,.i_clk                  ( i_core_clk                    )          
   ,.i_cpu_clk              ( i_cpu_clk                     )          
   ,.i_cpu_rst              ( w_cpu_rst                     )          
   ,.i_cpu_cs               ( i_bb_cpu_cs                   )          
   ,.i_cpu_addr             ( i_bb_cpu_addr                 )          
   ,.i_cpu_wren             ( i_bb_cpu_wren                 )          
   ,.i_cpu_wdata            ( i_bb_cpu_wdata                )          
   ,.i_cpu_rden             ( i_bb_cpu_rden                 )          
   ,.o_cpu_rdata            ( o_bb_cpu_rdata                )          
   ,.o_cpu_rd_valid         ( o_bb_cpu_rd_valid             )          
   ,.o_core_addr            ( w_core_addr                   )          
   ,.o_core_wren            ( w_core_wren                   )          
   ,.o_core_wdata           ( w_core_wdata                  )          
   ,.o_core_rden            ( w_core_rden                   )          
   ,.i_core_rdata           ( w_core_rdata                  )          
   ,.i_core_rd_valid        ( w_core_rd_valid               )          
   ,.o_bb_top_par_100000    ( w_bb_top_par_100000           )          
   ,.o_bb_top_par_100004    ( w_bb_top_par_100004           )
   ,.o_bb_top_par_100008_ulfe_data_dly    ( ulfe_data_dly [0]  )                    
   ,.o_sigcap_par_110000    ( w_sigcap_par_110000           )          
   ,.o_sigcap_par_110004    ( w_sigcap_par_110004           )          
   ,.o_sigcap_par_110008    ( w_sigcap_par_110008           )          
   ,.o_sigcap_par_11000c    ( w_sigcap_par_11000c           )          
   ,.o_sigcap_par_110010    ( w_sigcap_par_110010           )          
   ,.o_sigcap_par_110014    ( w_sigcap_par_110014           )          
   ,.o_sigcap_par_110018    ( w_sigcap_par_110018           )          
   ,.o_sigcap_par_11001c    ( w_sigcap_par_11001c           )          
   ,.o_sigcap_par_110020    ( w_sigcap_par_110020           )          
   ,.o_sigcap_par_110024    ( w_sigcap_par_110024           )          
   ,.i_dump_wr_en           ( w_dump_wr_en                  )          
   ,.i_dump_wr_addr         ( w_dump_wr_addr                )          
   ,.i_dump_wr_data         ( w_dump_wr_data                )          
   ,.i_din_fsync            ( w_cc_din_frame_sync  [0]      )
   ,.i_dout_fsync           ( r_cc_dout_frame_sync [0]      )
   ,.i_uin_fsync            ( r_cc_uin_frame_sync  [0]      )
   ,.i_uout_fsync           ( w_cc_uout_frame_sync [0]      )
   ,.i_rin_fsync            ( r_cc_uin_frame_sync  [0]      )
   ,.i_rout_fsync           ( w_cc_rout_frame_sync [0]      )
);
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g05_core_reg_mux
always@(posedge i_core_clk) begin
    if(w_cc_s_dlfe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_dlfe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_dlfe_rd_valid[gcc] ;
    end
    else if(w_cc_s_ulfe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_ulfe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_ulfe_rd_valid[gcc] ;
    end
    else if(w_cc_s_rafe_rd_valid[gcc]) begin
        r_cc_s_core_rdata   [gcc]  <=  w_cc_s_rafe_rdata[gcc]    ;
        r_cc_s_core_rd_valid[gcc]  <=  w_cc_s_rafe_rd_valid[gcc] ;
    end
    else begin
        r_cc_s_core_rd_valid[gcc]  <=  1'd0    ;
    end
end
end
endgenerate

//u05_cpu_rst_sync
RST_SYNC #(
     .DLY_NUM       (   DLY_RST         ))
u05_cpu_rst_sync
(
     .RST_IN                ( i_cpu_arst                    )
    ,.CLK                   ( i_cpu_clk                     )
    ,.RST_OUT               ( w_cpu_rst                     )
);

//u06_bb_top_rst_sync
bb_top_rst_sync #(
     .NUM_RST       (   MAX_CC          )
    ,.DLY_RST       (   DLY_RST         ))
u06_bb_top_rst_sync
(                                                               
    .i_clk                  ( i_core_clk                    )
   ,.i_arst_top             ( i_core_arst_bbtop             )
   ,.i_arst_dlfe            ( i_core_arst_dlfe              )
   ,.i_arst_ulfe            ( i_core_arst_ulfe              )
   ,.i_arst_rafe            ( i_core_arst_rafe              )
   ,.o_rst_top              ( w_core_rst_bbtop              )
   ,.o_rst_dlfe             ( w_core_rst_dlfe               )
   ,.o_rst_ulfe             ( w_core_rst_ulfe               )
   ,.o_rst_rafe             ( w_core_rst_rafe               )
);

////u07_sig_cap(signal, parameter capture hub)
//sig_cap #(   
//    .CC_NUM                 ( MAX_CC                ))
//u06_sig_cap
//(
//    .i_clk                  ( i_core_clk                    )          
//   ,.i_nr_bfn               ( r_sig_cap_bfn                 )
//   ,.i_nr_dl_fd_fsync       ( r_sig_cap_din_frame_sync      )
//   ,.i_nr_dl_fd_val         ( r_sig_cap_din_en              )
//   ,.i_nr_dl_fd_data        ( r_sig_cap_din_iq              )
//   ,.i_nr_dl_td_fsync       ( r_sig_cap_dout_frame_sync     )
//   ,.i_nr_dl_td_val         ( r_sig_cap_dout_en             )
//   ,.i_nr_dl_td_data        ( r_sig_cap_dout_iq             )
//   ,.i_nr_dl_cp_fsync       ( r_sig_cap_din_frame_sync      )
//   ,.i_nr_dl_cp_val         ( r_sig_cap_din_en              )
//   ,.i_nr_dl_cp_data        ( r_sig_cap_nr_dl_cp_data       )
//   ,.i_nr_ul_fd_fsync       ( r_sig_cap_uout_frame_sync     )
//   ,.i_nr_ul_fd_val         ( r_sig_cap_uout_en             )
//   ,.i_nr_ul_fd_data        ( r_sig_cap_uout_iq             )
//   ,.i_nr_ul_td_fsync       ( r_sig_cap_uin_frame_sync      )
//   ,.i_nr_ul_td_val         ( r_sig_cap_uin_en              )
//   ,.i_nr_ul_td_data        ( r_sig_cap_uin_iq              )
//   ,.i_nr_ra_fd_fsync       ( r_sig_cap_rout_frame_sync     )
//   ,.i_nr_ra_fd_val         ( r_sig_cap_rout_en             )
//   ,.i_nr_ra_fd_data        ( r_sig_cap_rout_iq             )
//   ,.i_nr_ra_cp_fsync       ( r_sig_cap_uin_frame_sync      )
//   ,.i_nr_ra_cp_val         ( r_sig_cap_uin_en              )
//   ,.i_nr_ra_cp_data        ( r_sig_cap_nr_ra_cp_data       )
//   ,.i_dump_en              ( r_sigcap_par_110000           )
//   ,.i_dump_cc_set          ( r_sigcap_par_110004           )
//   ,.i_dump_ant_set         ( r_sigcap_par_110008           )
//   ,.i_dump_frm_set         ( r_sigcap_par_11000c           )
//   ,.i_dump_slt_set         ( r_sigcap_par_110010           )
//   ,.i_dump_sym_set         ( r_sigcap_par_110014           )
//   ,.i_dump_idx_set         ( r_sigcap_par_110018           )
//   ,.i_dump_mode            ( r_sigcap_par_11001c           )
//   ,.i_mu                   ( r_sigcap_par_110020           )
//   ,.i_sr                   ( r_sigcap_par_110024           )
//   ,.o_dump_val             ( w_dump_wr_en                  )
//   ,.o_dump_addr            ( w_dump_wr_addr                )
//   ,.o_dump_data            ( w_dump_wr_data                )
//);
//always@(posedge i_core_clk) begin
//    r_sigcap_par_110000 <=  w_sigcap_par_110000   ; 
//    r_sigcap_par_110004 <=  w_sigcap_par_110004   ;             
//    r_sigcap_par_110008 <=  w_sigcap_par_110008   ; 
//    r_sigcap_par_11000c <=  w_sigcap_par_11000c   ; 
//    r_sigcap_par_110010 <=  w_sigcap_par_110010   ;             
//    r_sigcap_par_110014 <=  w_sigcap_par_110014   ; 
//    r_sigcap_par_110018 <=  w_sigcap_par_110018   ; 
//    r_sigcap_par_11001c <=  w_sigcap_par_11001c   ;             
//    r_sigcap_par_110020 <=  w_sigcap_par_110020   ; 
//    r_sigcap_par_110024 <=  w_sigcap_par_110024   ; 
//end

//--- IO-Signal Mapping
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g06_io_map
//oran_top to dlfe : pdxch uplane
assign w_cc_din_bfn             [gcc]   =   {4'd0,i_din_frame_idx   [((08                     )*(gcc+1)-1)-:(08                     )]} ;   
assign w_cc_din_frame_sync      [gcc]   =   i_din_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )]  ;   
assign w_cc_din_frame_idx       [gcc]   =   i_din_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  ;   
assign w_cc_din_en              [gcc]   =   i_din_en                [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )]  ;   
assign w_cc_din_iq              [gcc]   =   i_din_iq                [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)]  ;   
assign w_cc_din_frame_struct    [gcc]   =   {{08*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_re_mask         [gcc]   =   i_din_re_mask           [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )]  ;   
assign w_cc_din_beam_id         [gcc]   =   {{15*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_start_prbu      [gcc]   =   {{10*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_num_prbu        [gcc]   =   {{08*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_freq_offset     [gcc]   =   {{24*DL_NUM_ANT}{1'b0}}                                                                     ;
assign w_cc_din_nlayer          [gcc]   =   5'd0                                                                                        ;
//oran_top to rafe : rach cplane
assign w_cc_rin_frame_sync      [gcc]   =   i_rin_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )]  ;   
assign w_cc_rin_filter_idx      [gcc]   =   i_rin_filter_idx        [((04*UL_NUM_ANT          )*(gcc+1)-1)-:(04*UL_NUM_ANT          )]  ;   
assign w_cc_rin_time_offset     [gcc]   =   i_rin_time_offset       [((16*UL_NUM_ANT          )*(gcc+1)-1)-:(16*UL_NUM_ANT          )]  ;   
assign w_cc_rin_frame_struct    [gcc]   =   i_rin_frame_struct      [((08*UL_NUM_ANT          )*(gcc+1)-1)-:(08*UL_NUM_ANT          )]  ;   
assign w_cc_rin_cp_length       [gcc]   =   i_rin_cp_length         [((16*UL_NUM_ANT          )*(gcc+1)-1)-:(16*UL_NUM_ANT          )]  ;   
assign w_cc_rin_freq_offset     [gcc]   =   i_rin_freq_offset       [((24*UL_NUM_ANT          )*(gcc+1)-1)-:(24*UL_NUM_ANT          )]  ;   
assign w_cc_rin_num_psymbol     [gcc]   =   i_rin_num_psymbol       [((04*UL_NUM_ANT          )*(gcc+1)-1)-:(04*UL_NUM_ANT          )]  ;   
assign w_cc_rin_num_ro          [gcc]   =   i_rin_num_ro            [((03*UL_NUM_ANT          )*(gcc+1)-1)-:(03*UL_NUM_ANT          )]  ;   
assign w_cc_rin_num_prbc        [gcc]   =   i_rin_num_prbc          [((08*UL_NUM_ANT          )*(gcc+1)-1)-:(08*UL_NUM_ANT          )]  ;   
assign w_cc_rin_start_prbc      [gcc]   =   i_rin_start_prbc        [((10*UL_NUM_ANT          )*(gcc+1)-1)-:(10*UL_NUM_ANT          )]  ;   
//dlfe to oran_top : k0
assign o_dout_dl_ntone          [((12                     )*(gcc+1)-1)-:(12                     )]  =   w_cc_dout_dl_ntone       [gcc]  ;
assign o_dout_dl_sys_mode       [((01                     )*(gcc+1)-1)-:(01                     )]  =   w_cc_dout_dl_sys_mode    [gcc]  ;

assign o_dout_dl_fft_type       [((02                     )*(gcc+1)-1)-:(02                     )]  =   w_cc_dout_dl_fft_type    [gcc]  ;
assign o_dout_dl_k0             [((12                     )*(gcc+1)-1)-:(12                     )]  =   w_cc_dout_dl_k0          [gcc]  ;
//ulfe to oran_top : puxch uplane
assign o_uout_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  =   w_cc_uout_frame_idx      [gcc]  ;   
assign o_uout_subfrm_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  =   w_cc_uout_subfrm_idx     [gcc]  ;   
assign o_uout_slot_idx          [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_uout_slot_idx       [gcc]  ;   
assign o_uout_symbol_idx        [((06                     )*(gcc+1)-1)-:(06                     )]  =   {2'd0,w_cc_uout_symbol_idx[gcc]};   
assign o_uout_start_re_idx      [((16*UL_NUM_ANT          )*(gcc+1)-1)-:(16*UL_NUM_ANT          )]  =   w_cc_uout_start_re_idx   [gcc]  ;   
assign o_uout_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_en             [gcc]  ;   
assign o_uout_start_re          [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_start_re       [gcc]  ;   
assign o_uout_last_re           [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_uout_last_re        [gcc]  ;   
assign o_uout_iq                [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)]  =   w_cc_uout_iq             [gcc]  ;   
//rafe to oran_top : rach uplane
assign o_rout_frame_idx         [((08                     )*(gcc+1)-1)-:(08                     )]  =   w_cc_rout_frame_idx      [gcc]  ;     
assign o_rout_subfrm_idx        [((04                     )*(gcc+1)-1)-:(04                     )]  =   w_cc_rout_subfrm_idx     [gcc]  ;     
assign o_rout_slot_idx          [((06                     )*(gcc+1)-1)-:(06                     )]  =   w_cc_rout_slot_idx       [gcc]  ;     
assign o_rout_symbol_idx        [((06                     )*(gcc+1)-1)-:(06                     )]  =   {2'd0,w_cc_rout_symbol_idx[gcc]};     
assign o_rout_start_re_idx      [((16*UL_NUM_ANT          )*(gcc+1)-1)-:(16*UL_NUM_ANT          )]  =   w_cc_rout_start_re_idx   [gcc]  ;     
assign o_rout_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_rout_en             [gcc]  ;     
assign o_rout_start_re          [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_rout_start_re       [gcc]  ;     
assign o_rout_last_re           [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  =   w_cc_rout_last_re        [gcc]  ;     
assign o_rout_iq                [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)]  =   w_cc_rout_iq             [gcc]  ;      
end
endgenerate

//--- CPU IF Mapping
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g07_cpu_if_map
assign w_cc_s_core_addr         [gcc]   =   w_core_addr             [((CPUIF_BB_ADDR_BW       )*(gcc+1)-1)-:(CPUIF_BB_ADDR_BW       )]  ;   
assign w_cc_s_core_wren         [gcc]   =   w_core_wren             [((1                      )*(gcc+1)-1)-:(1                      )]  ;   
assign w_cc_s_core_wdata        [gcc]   =   w_core_wdata            [((CPUIF_DATA_BW          )*(gcc+1)-1)-:(CPUIF_DATA_BW          )]  ;   
assign w_cc_s_core_rden         [gcc]   =   w_core_rden             [((1                      )*(gcc+1)-1)-:(1                      )]  ;   
assign w_core_rdata             [((CPUIF_DATA_BW          )*(gcc+1)-1)-:(CPUIF_DATA_BW          )]  =   r_cc_s_core_rdata        [gcc]  ;   
assign w_core_rd_valid          [((1                      )*(gcc+1)-1)-:(1                      )]  =   r_cc_s_core_rd_valid     [gcc]  ;   
end
endgenerate

//--- From/To BBCTRL : TD DL UL
generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g09_if_sig_map
assign o_dout_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )]  =   w_cc_dout_frame_sync     [gcc]  ;
assign w_cc_uin_en              [gcc]   =   i_uin_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )]  ;
always@(*) begin
    for(ant=0;ant<UL_NUM_ANT;ant=ant+1) begin
		r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              <= i_uin_i [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
        r_cc_uin_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   <= i_uin_q [(((TOP_DIO_BW)*(gcc*UL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)]  ;
    end
end
always@(posedge i_core_clk) begin
    o_dout_en         [((01*DL_NUM_ANT)*(gcc+1)-1)-:(01*DL_NUM_ANT)] <= w_cc_dout_en        [gcc]   ;    
    for(ant=0;ant<DL_NUM_ANT;ant=ant+1) begin        
//        if(w_cc_dout_en[gcc][ant]) begin
            o_dout_i    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= w_cc_dout_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1)-:(TOP_DIO_BW)]              ;
            o_dout_q    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= w_cc_dout_iq [gcc][((2*TOP_DIO_BW)*(ant+1)-1-TOP_DIO_BW)-:(TOP_DIO_BW)]   ;
//        end
//        else if(~w_cc_dout_en[gcc][ant]&o_dout_en[(((01)*(gcc*DL_NUM_ANT+ant+1)-1))-:(01)]) begin
//            o_dout_i    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= {{TOP_DIO_BW}{1'b0}} ;
//            o_dout_q    [(((TOP_DIO_BW)*(gcc*DL_NUM_ANT+ant+1)-1))-:(TOP_DIO_BW)] <= {{TOP_DIO_BW}{1'b0}} ;
//        end
    end
    r_cc_dout_frame_sync[gcc] <= w_cc_dout_frame_sync[gcc] ;
    r_cc_uin_frame_sync [gcc] <= w_cc_uin_frame_sync [gcc] ;
end
end
endgenerate

generate for(gcc=0; gcc<MAX_CC; gcc=gcc+1) begin : g10_sig_cap_map
always@(posedge i_core_clk) begin
    r_sig_cap_bfn                    [((12                     )*(gcc+1)-1)-:(12                     )] <=  w_cc_din_bfn            [gcc]  ;
    r_sig_cap_din_frame_sync         [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_din_frame_sync     [gcc]  ;
    r_sig_cap_din_en                 [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )] <=  w_cc_din_en             [gcc]  ;
    r_sig_cap_din_iq                 [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_cc_din_iq             [gcc]  ;
    r_sig_cap_uout_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_uout_frame_sync    [gcc]  ;
    r_sig_cap_uout_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )] <=  w_cc_uout_en            [gcc]  ;
    r_sig_cap_uout_iq                [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  w_cc_uout_iq            [gcc]  ;
    r_sig_cap_rout_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_rout_frame_sync    [gcc]  ;
    r_sig_cap_rout_en                [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )] <=  w_cc_rout_en            [gcc]  ;
    r_sig_cap_rout_iq                [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  w_cc_rout_iq            [gcc]  ;
    r_sig_cap_dout_frame_sync        [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_dout_frame_sync    [gcc]  ;
    r_sig_cap_dout_en                [((01*DL_NUM_ANT          )*(gcc+1)-1)-:(01*DL_NUM_ANT          )] <=  w_cc_dout_en            [gcc]  ;
    r_sig_cap_dout_iq                [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_cc_dout_iq            [gcc]  ;
    r_sig_cap_nr_dl_cp_data          [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_nr_dl_cp_data_cc      [gcc]  ;
    r_sig_cap_nr_ra_cp_data          [((2*TOP_DIO_BW*DL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*DL_NUM_ANT)] <=  w_nr_ra_cp_data_cc      [gcc]  ;
    r_sig_cap_uin_frame_sync         [((01                     )*(gcc+1)-1)-:(01                     )] <=  w_cc_uin_frame_sync     [gcc]  ;
    r_sig_cap_uin_en                 [((01*UL_NUM_ANT          )*(gcc+1)-1)-:(01*UL_NUM_ANT          )] <=  w_cc_uin_en             [gcc]  ;
    r_sig_cap_uin_iq                 [((2*TOP_DIO_BW*UL_NUM_ANT)*(gcc+1)-1)-:(2*TOP_DIO_BW*UL_NUM_ANT)] <=  r_cc_uin_iq             [gcc]  ;
end
end
endgenerate

//--- C-Plane Internal Mapping
generate for(gcc=0;gcc<MAX_CC;gcc=gcc+1) begin : g11_cp_cap_map
for(gant=0;gant<MAX_ANT;gant=gant+1) begin : g10_cp_sig_map_ant
assign  w_nr_dl_cp_data_cc_ant [gcc][gant]  =   {w_cc_din_frame_idx[gcc],{3'd0,w_cc_din_en[gcc][gant]},w_cc_din_iq[gcc][((gant+1)*2*TOP_DIO_BW-1)-:8],{3'd0,w_cc_din_re_mask[gcc][(1*(gant+1)-1)-:1]},w_cc_din_frame_struct[gcc][(8*(gant+1)-1)-:8]} ;   
if(gant==0) begin    
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {{3'd0,w_cc_uin_en[gcc][gant]},w_cc_rin_freq_offset[gcc][(24*(gant+1)-1)-:24],{1'd0,w_cc_rin_num_ro[gcc][(3*(gant+1)-1)-:3]}} ;   
end
else if(gant==1) begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {w_cc_rin_filter_idx[gcc][(4*(gant+1)-1)-:4],w_cc_rin_frame_struct[gcc][(8*(gant+1)-1)-:8],w_cc_rin_cp_length[gcc][(16*(gant+1)-1)-:16],w_cc_rin_num_psymbol[gcc][(4*(gant+1)-1)-:4]} ;   
end
else if(gant==2) begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {w_cc_uin_frame_idx[gcc],8'd0,w_cc_rin_time_offset[gcc][(16*(gant+1)-1)-:16]}   ;   
end
else begin
assign  w_nr_ra_cp_data_cc_ant [gcc][gant]  =   {{3'd0,r_cc_uin_frame_sync[gcc]},{3'd0,w_cc_rin_frame_sync[gcc]},4'd0,{3'd0,w_cc_uout_frame_sync[gcc]},{3'd0,w_cc_rout_frame_sync[gcc]},4'd0,{3'd0,w_cc_din_frame_sync[gcc]},{3'd0,w_cc_dout_frame_sync[gcc]}}   ;   
end
assign  w_nr_dl_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_dl_cp_data_cc_ant[gcc][gant];   
assign  w_nr_ra_cp_data_cc [gcc][((2*TOP_DIO_BW           )*(gant+1)-1)-:(2*TOP_DIO_BW          )]  =   w_nr_ra_cp_data_cc_ant[gcc][gant];   
end
end
endgenerate

endmodule
