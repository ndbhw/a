////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_vfft_wrapper
//  Author       : jyzoo.lee@samsung.com
//  Description  : Intel/Xilinx FFT Wrapper
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.10 |jyzoo.lee      | Initial Release
//  ------------+---------------+-----------------------------------------------
//   2020.07.31 |jyzoo.lee      | Add tuser port for Xilinx IP
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 |jyzoo.lee      | Supports Variable MAX_NFFT (Xilinx)
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_vfft_wrapper #(
    parameter   MAX_NFFT  =   2048 
   ,parameter   VENDOR    =   "Intel" 
)(
     input  wire                            clk                    
    ,input  wire                            reset_n            
    ,input  wire                            sink_valid      
    ,output wire                            sink_ready      
    ,input  wire [1:0]                      sink_error      
    ,input  wire                            sink_sop          
    ,input  wire                            sink_eop          
    ,input  wire [15:0]                     sink_real        
    ,input  wire [15:0]                     sink_imag        
    ,input  wire [$clog2(MAX_NFFT):0]       fftpts_in        
    ,input  wire [0:0]                      inverse            
    ,output wire                            source_valid  
    ,input  wire                            source_ready  
    ,output wire [1:0]                      source_error  
    ,output wire                            source_sop      
    ,output wire                            source_eop      
    ,output wire [27:0]                     source_real    
    ,output wire [27:0]                     source_imag    
    ,output wire [$clog2(MAX_NFFT):0]       fftpts_out    
);

generate if(VENDOR == "Intel") begin
zip_vfft_bb_top u00_zip_vfft
(
     .clk          (    clk             ) 
    ,.reset_n      (    reset_n         ) 
    ,.sink_valid   (    sink_valid      ) 
    ,.sink_ready   (    sink_ready      ) 
    ,.sink_error   (    sink_error      ) 
    ,.sink_sop     (    sink_sop        ) 
    ,.sink_eop     (    sink_eop        ) 
    ,.sink_real    (    sink_real       ) 
    ,.sink_imag    (    sink_imag       ) 
    ,.fftpts_in    (    fftpts_in       ) 
    ,.inverse      (    inverse         ) 
    ,.source_valid (    source_valid    ) 
    ,.source_ready (    source_ready    ) 
    ,.source_error (    source_error    ) 
    ,.source_sop   (    source_sop      ) 
    ,.source_eop   (    source_eop      ) 
    ,.source_real  (    source_real     ) 
    ,.source_imag  (    source_imag     ) 
    ,.fftpts_out   (    fftpts_out      )  
);
end
else begin //Xilinx
reg [00:0] r_s_axis_config_tvalid ; 
reg [15:0] r_s_axis_config_tdata ; 
always@(posedge clk) begin
    if(!reset_n) begin
        r_s_axis_config_tvalid <= 1'd0  ; 
        r_s_axis_config_tdata  <= 16'd0 ; 
    end
    else if(sink_sop) begin
        r_s_axis_config_tvalid <= sink_sop  ; 
        case(fftpts_in) 
            'd512       :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01001}   ;
            'd1024      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01010}   ;
            'd2048      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01011}   ;
            'd4096      :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01100}   ;
            default     :   r_s_axis_config_tdata  <=  {7'd0,~inverse,3'd0,5'b01010}   ;
        endcase
    end
    else begin
        r_s_axis_config_tvalid <= 1'd0  ; 
    end
end

reg [00:0] r_s_axis_data_tvalid ; 
reg [31:0] r_s_axis_data_tdata  ; 
reg [00:0] r_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(sink_valid) begin
        r_s_axis_data_tvalid    <= sink_valid  ; 
        r_s_axis_data_tdata     <= {sink_imag,sink_real}   ; 
        r_s_axis_data_tlast     <= sink_eop  ; 
    end
    else begin
        r_s_axis_data_tvalid    <= 1'd0  ; 
        r_s_axis_data_tlast     <= 1'd0  ; 
    end
end
reg [00:0] rr_s_axis_data_tvalid ; 
reg [31:0] rr_s_axis_data_tdata  ; 
reg [00:0] rr_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(r_s_axis_data_tvalid) begin
        rr_s_axis_data_tvalid   <= r_s_axis_data_tvalid ;
        rr_s_axis_data_tdata    <= r_s_axis_data_tdata  ;   
        rr_s_axis_data_tlast    <= r_s_axis_data_tlast  ;
    end
    else begin
        rr_s_axis_data_tvalid   <= 1'd0  ; 
        rr_s_axis_data_tlast    <= 1'd0  ; 
    end
end
reg [00:0] rrr_s_axis_data_tvalid ; 
reg [31:0] rrr_s_axis_data_tdata  ; 
reg [00:0] rrr_s_axis_data_tlast  ; 
always@(posedge clk) begin
    if(rr_s_axis_data_tvalid) begin
        rrr_s_axis_data_tvalid   <= rr_s_axis_data_tvalid ;
        rrr_s_axis_data_tdata    <= rr_s_axis_data_tdata  ;   
        rrr_s_axis_data_tlast    <= rr_s_axis_data_tlast  ;
    end
    else begin
        rrr_s_axis_data_tvalid   <= 1'd0  ; 
        rrr_s_axis_data_tlast    <= 1'd0  ; 
    end
end

wire w_s_axis_config_tready     ; 
wire w_s_axis_data_tready       ; 
wire [3:0]  source_real_dummy   ;
wire [3:0]  source_imag_dummy   ;
wire event_tlast_unexpected     ;
wire event_tlast_missing        ;
wire event_status_channel_halt  ;
wire event_data_in_channel_halt ;
wire event_data_out_channel_halt;
if(MAX_NFFT==512) begin
xip_vfft_bb_top_512 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
else if(MAX_NFFT==1024) begin
xip_vfft_bb_top_1024 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
else if(MAX_NFFT==2048) begin
xip_vfft_bb_top_2048 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
else if(MAX_NFFT==4096) begin
xip_vfft_bb_top_4096 u00_xip_vfft
(
     .aclk                          (   clk                                                             )   
    ,.aresetn                       (   reset_n                                                         )
    ,.s_axis_config_tdata           (   r_s_axis_config_tdata                                           )
    ,.s_axis_config_tvalid          (   r_s_axis_config_tvalid                                          )   
    ,.s_axis_config_tready          (   w_s_axis_config_tready                                          )   
    ,.s_axis_data_tdata             (   rrr_s_axis_data_tdata                                           )   
    ,.s_axis_data_tvalid            (   rrr_s_axis_data_tvalid                                          )   
    ,.s_axis_data_tready            (   w_s_axis_data_tready                                            )   
    ,.s_axis_data_tlast             (   rrr_s_axis_data_tlast                                           )   
    ,.m_axis_data_tdata             (   {source_imag_dummy,source_imag,source_real_dummy,source_real}   )   
    ,.m_axis_data_tvalid            (   source_valid                                                    )
    ,.m_axis_data_tready            (   source_ready                                                    )
    ,.m_axis_data_tlast             (   source_eop                                                      )
    ,.event_frame_started           (   source_sop                                                      )
    ,.event_tlast_unexpected        (   event_tlast_unexpected                                          )   
    ,.event_tlast_missing           (   event_tlast_missing                                             )   
    ,.event_status_channel_halt     (   event_status_channel_halt                                       )   
    ,.event_data_in_channel_halt    (   event_data_in_channel_halt                                      )   
    ,.event_data_out_channel_halt   (   event_data_out_channel_halt                                     )   
); 
end
assign  source_error = event_tlast_unexpected|event_tlast_missing|event_status_channel_halt|event_data_in_channel_halt|event_data_out_channel_halt   ; 
assign  fftpts_out = fftpts_in ;
end
endgenerate
endmodule
