////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_inter_leav
//  Author       : jyzoo.lee@samsung.com 
//  Description  : input interleaving
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.24 | taeyeong      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.07.08 | dg0110.jo     | Structural change for synthesis
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_inter_leav 
#(
     parameter WIDTH   = 16   // IQ bit width  
    ,parameter NUM_ANT =  2   // number of antenna
    //,parameter RATIO   =  8   // operation clock / sampling rate
    ,parameter DLY     =  1   // output delay   1 ~
    //,parameter OFFSET  =  4   // trans offset
)
(
     input   wire                                  i_clk
    ,input   wire                                  i_sync
    ,input   wire    [6                  -1:0]     i_ratio
    ,input   wire    [NUM_ANT            -1:0]     i_en
    ,input   wire    [2*WIDTH*NUM_ANT    -1:0]     i_in
    ,output  wire                                  o_sync
    ,output  wire    [NUM_ANT            -1:0]     o_vld
    ,output  wire    [2*WIDTH            -1:0]     o_out
);

// signal
genvar i;

reg  [5               -1:0]   r_cnt   ;
wire                          w_sync  ;
reg  [8               -1:0]   r_vld   ;
reg  [2*WIDTH         -1:0]   r_out   ; 
wire [2*WIDTH*8       -1:0]   w_in    ;

// counter
always @(posedge i_clk) begin
    if(i_sync) 
        r_cnt   <= 0        ;
    else if(r_cnt==(i_ratio-1)) 
        r_cnt   <= 0        ;
    else
        r_cnt   <= r_cnt + 1;
end

// input extention

wire [(8-NUM_ANT)*2*WIDTH   -1:0] w_pre;

assign w_pre= {((8-NUM_ANT)*2*WIDTH){1'b0}};
assign w_in = {w_pre,i_in};
//assign w_in = {{((8-NUM_ANT)*2*WIDTH){1'b0}},i_in};

// p2s

always @(posedge i_clk) begin
    if(|i_en) begin
        case(r_cnt[4:0]) 
            5'd0    : begin r_vld <= 8'b0000_0001; r_out <= w_in [2*WIDTH*1 -1:2*WIDTH*0]; end 
            5'd1    : begin r_vld <= 8'b0000_0010; r_out <= w_in [2*WIDTH*2 -1:2*WIDTH*1]; end 
            5'd2    : begin r_vld <= 8'b0000_0100; r_out <= w_in [2*WIDTH*3 -1:2*WIDTH*2]; end 
            5'd3    : begin r_vld <= 8'b0000_1000; r_out <= w_in [2*WIDTH*4 -1:2*WIDTH*3]; end 
            5'd4    : begin r_vld <= 8'b0001_0000; r_out <= w_in [2*WIDTH*5 -1:2*WIDTH*4]; end 
            5'd5    : begin r_vld <= 8'b0010_0000; r_out <= w_in [2*WIDTH*6 -1:2*WIDTH*5]; end 
            5'd6    : begin r_vld <= 8'b0100_0000; r_out <= w_in [2*WIDTH*7 -1:2*WIDTH*6]; end 
            5'd7    : begin r_vld <= 8'b1000_0000; r_out <= w_in [2*WIDTH*8 -1:2*WIDTH*7]; end 
            default : begin r_vld <= 8'b0000_0000; r_out <= {2*WIDTH{1'b0}}; end 
        endcase
    end
    else begin
        r_vld <=      8'b0000_0000; 
        r_out <= {(2*WIDTH){1'b0}};
    end
end


// always @(posedge i_clk)
// begin
//     if(OFFSET == 0)
//     begin
//         if(r_cnt >= NUM_ANT)
//         begin
//             r_vld <= 0;
//             r_out <= 0;
//         end
//         else
//         begin
//             r_vld   <= (1'b1 << r_cnt)  ;
//             r_out   <= (i_in>>r_cnt*2*WIDTH)    ;
//         end
//     end
//     else
//     begin
//         if(r_cnt == 0)
//         begin
//             r_vld   <= 0  ;
//             r_out   <= 0  ;
//         end
//         else if(r_cnt >= OFFSET && r_cnt < OFFSET+NUM_ANT)
//         begin
//             r_vld   <= (1'b1 << (r_cnt-OFFSET)) ;
//             r_out   <= (i_in>>(r_cnt-OFFSET)*2*WIDTH)            ;            
//         end
//         else if(r_cnt >= OFFSET+NUM_ANT)
//         begin
//             r_vld   <= 0    ;
//             r_out   <= 0    ;  
//         end
//         else
//         begin
//             r_vld   <= 0    ;
//             r_out   <= 0    ;              
//         end
//     end
// end
    
// output
    
ylib_reg #(.WIDTH(1) ,.DEPTH(1)) u0_out_reg(
     .i_clk      ( i_clk      )
    ,.i_in       ( i_sync     )
    ,.o_out      ( w_sync     )
);

ylib_reg #(.WIDTH(WIDTH*2+NUM_ANT+1) ,.DEPTH(DLY)) u1_out_reg(
    .i_clk      ( i_clk                                )
   ,.i_in       ( {w_sync,r_vld[NUM_ANT-1:0],r_out}    )
   ,.o_out      ( {o_sync,o_vld,o_out}                 )
);


// if (DLY == 1) begin : one_dly
//     assign o_sync= w_sync;
//     assign o_out = r_out ; 
//     assign o_vld = r_vld[NUM_ANT-1:0] ;
// end
// else begin : fix_dly
//     ylib_reg #(.WIDTH(WIDTH*2+NUM_ANT+1) ,.DEPTH(DLY)) u1_out_reg(
//          .i_clk      ( i_clk            )
//         ,.i_in       ( {w_sync,r_vld[NUM_ANT-1:0],r_out}    )
//         ,.o_out      ( {o_sync,o_vld,o_out}    )
//      );
// end

//endgenerate

endmodule
