////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20
//  Module       : ylib_axc_map_16b
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Map NR TD Signal to CPRI 16b AxC
//                 Feature : 4T,CBW 20/15/10/5M 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.08.12 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//   2020.08.24 |jyzoo.lee      | Designed in Detail : Real Format, Align
//  ------------+---------------+-----------------------------------------------
//   2020.10.08 |jyzoo.lee      | Supports Mapping Signal with up to 245.76 SR
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_axc_map_16b
#(
        parameter   NUM_ANT     =    4
   ,    parameter   DIO_BW      =    16
)(
        input   wire                                i_clk
    ,   input   wire    [4-1:0]                     i_bw_idx
    ,   input   wire    [01-1:0]                    i_bfn_strb
    ,   input   wire    [12-1:0]                    i_bfn
    ,   input   wire    [01-1:0]                    i_fsync
    ,   input   wire    [01*NUM_ANT-1:0]            i_en
    ,   input   wire    [2*DIO_BW*NUM_ANT-1:0]      i_iq
    ,   output  reg     [01-1:0]                    o_bfn_strb
    ,   output  reg     [12-1:0]                    o_bfn
    ,   output  reg     [01-1:0]                    o_ssync
    ,   output  reg     [01-1:0]                    o_en
    ,   output  reg     [DIO_BW-1:0]                o_iq
);

genvar  gidx    ;

localparam      NUM_AXC             =           64                  ;
localparam      BW_NUM_ANT          =           $clog2(NUM_ANT)     ;
localparam      IDX_BW_020          =           4'd3                ;
localparam      IDX_BW_015          =           4'd2                ;
localparam      IDX_BW_010          =           4'd1                ;
localparam      IDX_BW_005          =           4'd0                ;
localparam      BW_SR_BW_020        =           $clog2(08)          ;
localparam      BW_SR_BW_015        =           $clog2(08)          ;
localparam      BW_SR_BW_010        =           $clog2(16)          ;
localparam      BW_SR_BW_005        =           $clog2(32)          ;
localparam      DLY_SYNC            =           5                   ;

reg [5:0] r_axc_cnt ;
always@(posedge i_clk) begin
    if(i_fsync) begin
        r_axc_cnt <= 6'd0 ;
    end
    else begin
        r_axc_cnt <= r_axc_cnt+1'd1 ;
    end
end
reg r_ssync ;
always@(posedge i_clk) begin
    case(i_bw_idx)
        IDX_BW_020  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_020-1:0] ;
        IDX_BW_015  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_015-1:0] ;
        IDX_BW_010  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_010-1:0] ;
        IDX_BW_005  : r_ssync  <= ~|r_axc_cnt[BW_SR_BW_005-1:0] ;
        default     : r_ssync  <= {{2*DIO_BW}{1'd0}} ; 
    endcase
end
reg [01-1:0]    r_bfn_strb      ;
reg [01-1:0]    rr_bfn_strb     ;
reg [01-1:0]    rrr_bfn_strb    ;
reg [01-1:0]    rrrr_bfn_strb   ;
always@(posedge i_clk) begin
    r_bfn_strb      <= i_bfn_strb   ;
    rr_bfn_strb     <= r_bfn_strb   ;
    rrr_bfn_strb    <= rr_bfn_strb  ;
    rrrr_bfn_strb   <= rrr_bfn_strb ;
end
reg [01*NUM_ANT-1:0] r_en   ;   
reg [01*NUM_ANT-1:0] rr_en  ;   
reg [01*NUM_ANT-1:0] rrr_en  ;   
reg [2*DIO_BW-1:0]   r_iq     [NUM_ANT-1:0]  ;   
reg [2*DIO_BW-1:0]   rr_iq    [NUM_ANT-1:0]  ;   
reg [2*DIO_BW-1:0]   rrr_iq   [NUM_ANT-1:0]  ;   
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_ant_split
always@(posedge i_clk) begin
    r_en[gidx]  <=  i_en[gidx] ;
    if(i_en[gidx]) begin
        r_iq[gidx]  <=  i_iq[((2*DIO_BW)*(gidx+1)-1)-:(2*DIO_BW)] ;
    end
end
always@(posedge i_clk) begin
    rr_en[gidx]  <=  r_en[gidx] ;
    if(r_en[gidx]) begin
        rr_iq[gidx]  <=  r_iq[gidx] ;
    end
end
always@(posedge i_clk) begin
    rrr_en[gidx]  <=  rr_en[gidx] ;
    if(rr_en[gidx]&r_ssync) begin
        rrr_iq[gidx]  <=  rr_iq[gidx] ;
    end
end
end
endgenerate
reg [5:0] rrr_axc_cnt ;
always@(posedge i_clk) begin
    if(rr_bfn_strb&~rrr_bfn_strb) begin
        rrr_axc_cnt <= 6'd0 ;
    end
    else begin
        rrr_axc_cnt <= rrr_axc_cnt+1'd1 ;
    end
end
reg rr_ssync ;
reg rrr_ssync ;
always@(posedge i_clk) begin
    rr_ssync    <= r_ssync  ;
    rrr_ssync   <= rr_ssync ;
end
reg [1-1:0]     r_map_en   ;
reg [DIO_BW-1:0] r_map_iq  ;   
always@(posedge i_clk) begin
    r_map_en    <= |rrr_en  ;
    if(|rrr_en) begin
        case(i_bw_idx)
            IDX_BW_020  : r_map_iq  <= rrr_axc_cnt[BW_SR_BW_020-1:0]<NUM_ANT*2 ? rrr_axc_cnt[0] ? {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*1-1)-:DIO_BW]} : {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*2-1)-:DIO_BW]} : {{DIO_BW}{1'd0}} ;
            IDX_BW_015  : r_map_iq  <= rrr_axc_cnt[BW_SR_BW_015-1:0]<NUM_ANT*2 ? rrr_axc_cnt[0] ? {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*1-1)-:DIO_BW]} : {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*2-1)-:DIO_BW]} : {{DIO_BW}{1'd0}} ;
            IDX_BW_010  : r_map_iq  <= rrr_axc_cnt[BW_SR_BW_010-1:0]<NUM_ANT*2 ? rrr_axc_cnt[0] ? {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*1-1)-:DIO_BW]} : {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*2-1)-:DIO_BW]} : {{DIO_BW}{1'd0}} ;
            IDX_BW_005  : r_map_iq  <= rrr_axc_cnt[BW_SR_BW_005-1:0]<NUM_ANT*2 ? rrr_axc_cnt[0] ? {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*1-1)-:DIO_BW]} : {rrr_iq[rrr_axc_cnt[BW_NUM_ANT:1]][(DIO_BW*2-1)-:DIO_BW]} : {{DIO_BW}{1'd0}} ;
            default     : r_map_iq  <= {{DIO_BW}{1'd0}} ; 
        endcase
    end
    else begin
        r_map_iq <= {{DIO_BW}{1'd0}} ; 
    end
end
always@(posedge i_clk) begin
    o_bfn_strb  <=  rrrr_bfn_strb ;
    o_ssync     <=  rrr_ssync&r_map_en ;
    o_en        <=  r_map_en ;
    o_iq        <=  r_map_iq ;
    if(rrrr_bfn_strb&~o_bfn_strb) begin
        o_bfn <= i_bfn ;
    end
end
endmodule
