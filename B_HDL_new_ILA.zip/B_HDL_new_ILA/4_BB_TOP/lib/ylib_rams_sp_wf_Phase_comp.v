////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2018 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU
//  Module       : ylib_rams_sp_wf
//  Author       : jyzoo.lee@samsung.com 
//  Description  : Single-Port Block RAM Write-First Mode (recommended template)
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.6.09  |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module ylib_rams_sp_wf_Phase_comp 
#(
     parameter WIDTH  = 32
    ,parameter DEPTH  = 10
    ,parameter VENDOR = "Intel"            // Xilinx or Intel
) 
(clk, we, en, addr, di, dout);
input clk;
input we;
input en;
input [$clog2(DEPTH)-1:0] addr;
input [WIDTH-1:0] di;
output [WIDTH-1:0] dout;

integer i;


// generate
// 
// if (VENDOR == "Xilinx") begin: Xilinx
// 
// //reg [WIDTH-1:0] dout;
// //
// //(*ram_style="block"*)reg [WIDTH-1:0] RAM [DEPTH-1:0];
// //
// //always @(posedge clk)
// //    begin
// //        if (en)
// //            begin
// //                if (we)
// //                    begin
// //                        RAM[addr] <= di;
// //                        dout <= di;
// //                    end
// //                else
// //                dout <= RAM[addr];
// //        end
// //    end
// end


// else begin : Intel
// 
//     wire    [WIDTH  -1:0]              dout;    
// 
//     // intel memory example     
// 
//     reg     [WIDTH  -1:0]                 q;
//     wire                                wei;
//     reg     [WIDTH  -1:0] mem [DEPTH-1:0]  ;
// 
//     always @ (posedge clk) 
//     begin
//         if (wei)
//             mem[addr] <= di;
//         q <= mem[addr]; // q doesn't get d in this clock cycle
//     end
// 
// 
//     // wrapper
//     reg                                     o_en;
// 
//     assign  wei = en & we;    
// 
//     always @ (posedge clk) begin
//         if(wei) 
//             o_en <= 1'b0   ;
//         else if(en)
//             o_en <= 1'b1   ;
//         else
//             o_en <= 1'b0   ;
//     end
// 
// assign dout = (o_en) ? q : {WIDTH{1'b0}};



// else begin : Intel

    wire    [WIDTH  -1:0]              dout;    

    // intel memory example     

    reg     [WIDTH  -1:0]                 q;
    wire                                wei;
    reg     [WIDTH  -1:0] mem [DEPTH-1:0]  ;

    always @ (posedge clk) 
    begin
        if (wei)
            mem[addr] <= di;
        q <= mem[addr]; // q doesn't get d in this clock cycle
    end


    // wrapper
    reg                                     o_en;

    assign  wei = en & we;    

    always @ (posedge clk) begin
        if(wei) 
            o_en <= 1'b0   ;
        else if(en)
            o_en <= 1'b1   ;
        else
            o_en <= 1'b0   ;
    end

    assign dout = q; //(o_en) ? q : {WIDTH{1'b0}};
    // always @(posedge clk) begin
    //     if(o_en)
    //         dout    <= q;
    //     else
    //         dout    <= {WIDTH{1'b0}};
    // end



// end
// endgenerate

endmodule
