////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : VzW FSU20 
//  Module       : bb_top_rst_sync
//  Author       : jyzoo.lee@samsung.com
//  Description  : Reset Synchronizer for BB_TOP
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.07.22 |jyzoo.lee      | Initial Draft
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

module bb_top_rst_sync
#(
    parameter   NUM_RST                 =    6          
   ,parameter   DLY_RST                 =    4  
)(
        input   wire                        i_clk  
    ,   input   wire    [NUM_RST-1:0]       i_arst_top 
    ,   input   wire    [NUM_RST-1:0]       i_arst_dlfe
    ,   input   wire    [NUM_RST-1:0]       i_arst_ulfe
    ,   input   wire    [NUM_RST-1:0]       i_arst_rafe
    ,   output  wire    [NUM_RST-1:0]       o_rst_top 
    ,   output  wire    [NUM_RST-1:0]       o_rst_dlfe
    ,   output  wire    [NUM_RST-1:0]       o_rst_ulfe
    ,   output  wire    [NUM_RST-1:0]       o_rst_rafe
);
genvar  gidx    ;
generate for(gidx=0;gidx<NUM_RST;gidx=gidx+1) begin
RST_SYNC #(
    .DLY_NUM       (   DLY_RST         ))
u00_top_rst_sync
(
    .CLK                    ( i_clk                 )
   ,.RST_IN                 ( i_arst_top    [gidx]  )
   ,.RST_OUT                ( o_rst_top     [gidx]  )
);
RST_SYNC #(
    .DLY_NUM       (   DLY_RST         ))
u01_dlfe_rst_sync
(
    .CLK                    ( i_clk                 )
   ,.RST_IN                 ( i_arst_dlfe   [gidx]  )
   ,.RST_OUT                ( o_rst_dlfe    [gidx]  )
);
RST_SYNC #(
    .DLY_NUM       (   DLY_RST         ))
u03_ulfe_rst_sync
(
    .CLK                    ( i_clk                 )
   ,.RST_IN                 ( i_arst_ulfe   [gidx]  )
   ,.RST_OUT                ( o_rst_ulfe    [gidx]  )
);
RST_SYNC #(
    .DLY_NUM       (   DLY_RST         ))
u03_rafe_rst_sync
(
    .CLK                    ( i_clk                 )
   ,.RST_IN                 ( i_arst_rafe   [gidx]  )
   ,.RST_OUT                ( o_rst_rafe    [gidx]  )
);
end
endgenerate
endmodule
