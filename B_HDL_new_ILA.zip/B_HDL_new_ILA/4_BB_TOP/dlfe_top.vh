////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : DCM RT4422 21B
//  Module       : BB_TOP 
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe_cc_top Configuration header
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.30 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2021.01.15 | jyzoo.lee     | apart from BB_TOP.vh
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////
`define DLFE_AIE_DISABLE
`define DLFE_BF_DISABLE
`define DLFE_CAL_DISABLE
`define DLFE_IFFT_MAP_DISABLE
//`define DLFE_CELL_MUX_DISABLE
//`define DLFE_DSS_DISABLE
//`define DLFE_LSSI_DISABLE
//`define DLFE_TSSI_DISABLE
`define DLFE_EXT_BFCAL_DISABLE
`define DLFE_MAX_MU                 0    
`define DLFE_MAX_NIFFT              2048 
`define DLFE_DO_BW_IN_IF            16        
`define DLFE_DO_BW_BFW_MULT         16        
`define DLFE_DO_BW_CAL_SCHDLR       16        
`define DLFE_DO_BW_CALW_MULT        16        
`define DLFE_DO_BW_PHASE_COMP       16        
`define DLFE_DO_BW_IFFT_MAP_BUF     16        
`define DLFE_DO_BW_OFDM_MOD         16        
`define DLFE_DO_BW_ANT_SCALE        15        
`define DLFE_DO_BW_CDD_CP_BUF       15        
`define DLFE_NUM_CHAIN_IN_IF        4 //2       
`define DLFE_NUM_CHAIN_BFW_MULT     4 //2
`define DLFE_NUM_CHAIN_CAL_SCHDLR   4 //2
`define DLFE_NUM_CHAIN_CALW_MULT    4 //2
`define DLFE_NUM_CHAIN_PHASE_COMP   4 //2
`define DLFE_NUM_CHAIN_IFFT_MAP_BUF 4 //2
`define DLFE_NUM_CHAIN_OFDM_MOD     4 //2
`define DLFE_NUM_CHAIN_ANT_SCALE    4 //2
`define DLFE_NUM_CC_MUX             1
`define DLFE_TARGET_DLY             22'h2af7
`define DLFE_NUM_FRAME_XSSI         7'd16    