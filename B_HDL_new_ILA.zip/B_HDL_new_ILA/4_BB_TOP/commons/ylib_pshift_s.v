module ylib_pshift_s #(
    parameter   BW_SHIFT    =   8
)(
        input   wire                        i_clk
    ,   input   wire                        i_rst
    ,   input   wire    [BW_SHIFT-1:0]      i_shift
    ,   input   wire    [0:0]               i_in
    ,   output  wire    [0:0]               o_out
);

reg     [0:0] r_shr_en;
reg     [BW_SHIFT-1:0] r_shr;
always@(posedge i_clk) begin
    if(i_rst == 'b1) begin
        r_shr_en <= 'd0;
    end
    else if(i_in) begin
        r_shr_en <=  1'd1   ;
    end 
    else if(r_shr==i_shift-1) begin
        r_shr_en <=  1'd0   ;
    end
end
always@(posedge i_clk) begin
    if(i_rst == 'b1) begin
        r_shr <= 'd0;
    end
    else if(i_in) begin
        r_shr <=  0     ;
    end
    else if(r_shr_en) begin
        r_shr <=  (r_shr==i_shift-1) ? 0 : r_shr+1'd1    ;
    end 
end

assign o_out = (i_shift=={{BW_SHIFT}{1'd0}}) ? i_in : r_shr_en&&(r_shr==i_shift-1) ;

endmodule