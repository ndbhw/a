library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use WORK.ARRAY_TYPE.ALL;

entity data_dly is
    generic (
        MAX_DATA_DELAY              : natural := 32768                          -- Buffer depth
    );
    port (
        RESET                       : in  std_logic;
        CLK                         : in  std_logic;
        
        DATA_DELAY_VALUE            : in  std_logic_vector(31 downto 0);
        
        IN_DATA                     : in  std_logic_vector(127 downto 0);
        OUT_DATA                    : out std_logic_vector(127 downto 0)
    );
end data_dly;

architecture BEHAVE of data_dly is

    constant MAX_DATA_ADDR          : natural := MAX_DATA_DELAY;
        
    function log2 (data_value : integer)
    return integer is
	variable result      : integer := 0;
	variable cnt         : integer := 1;
    begin
	if (data_value <= 1) then
	    result     := 0;
	else
	    while (cnt < data_value) loop
		result := result + 1;
		cnt    := cnt *2;
	    end loop;
	end if;
	return result;
    end log2;
    
    signal limit_data               : std_logic_vector(31 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-17, 32);
    
    component bb_buf is
    generic(
	STYLE                       : string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
	NPIPE                       : integer := 6;
	DEPTH                       : integer := 16384;
	WIDTH                       : integer := 72
    );
    port(
	WCLK                        : in  std_logic;
	RCLK                        : in  std_logic;
	WE                          : in  std_logic;
	ENB                         : in  std_logic;
	WADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
	RADDR                       : in  std_logic_vector(log2(DEPTH)-1 downto 0);
	WDATA                       : in  std_logic_vector(WIDTH-1 downto 0);
	RDATA                       : out std_logic_vector(WIDTH-1 downto 0)
    );
    end component;

    signal r_din             : std_logic_vector(127 downto 0);
    signal r_dout            : std_logic_vector(127 downto 0);
    signal r_wea             : std_logic;
    signal r_oea             : std_logic;
    signal r_addra           : std_logic_vector(log2(MAX_DATA_ADDR)-1 downto 0) := (others => '0');
    signal r_addrb           : std_logic_vector(log2(MAX_DATA_ADDR)-1 downto 0) := conv_std_logic_vector(MAX_DATA_DELAY-17, log2(MAX_DATA_ADDR));    
    
begin

    -- delay saturation
    process (CLK)
    begin
	if (CLK'event and CLK = '1') then
	    if (DATA_DELAY_VALUE >= MAX_DATA_DELAY) then
            limit_data <= conv_std_logic_vector(MAX_DATA_DELAY, 32);
	    else
            limit_data <= DATA_DELAY_VALUE;
	    end if;
	end if;
    end process;

--------------------------------------------------------------------------------
-- Coarse delay
--------------------------------------------------------------------------------
    
    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    r_din <= IN_DATA; 
        r_wea <= '1';
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    if(r_wea = '1') then
            if (r_addra = MAX_DATA_ADDR-1) then
                r_addra <= (others => '0');
            else
                r_addra <= r_addra + 1;
            end if;
	    else
            r_addra <= r_addra;
	    end if;
	end if;
    end process;

    process (CLK)
    begin
	if(CLK'event and CLK = '1') then
	    if(r_wea = '1') then
            if (r_addra = limit_data) then 
                r_addrb <= (others => '0');
            else
                if (r_addrb = MAX_DATA_ADDR-1) then
                    r_addrb <= (others => '0');
                else
                    r_addrb <= r_addrb + 1;
                end if;
            end if;
	    else
            r_addrb <= r_addrb;
	    end if;
	end if;
    end process;


--------------------------------------------------------------------------------
-- Component mapping
--------------------------------------------------------------------------------

    u_DELAY_BUFFER_opt : bb_buf
    generic map(
        STYLE                       => "ultra"                                , --: string  := "ultra"; --"DISTRIBUTED","BLOCK","ultra","M20K"
        NPIPE                       => 6                                      , --: integer := 6;
        DEPTH                       => MAX_DATA_ADDR                          , --: integer := 8192;
        WIDTH                       => 128                                       --: integer := 72
    )
    port map(
        WCLK                        => CLK                                    , --: in  std_logic;
        RCLK                        => CLK                                    , --: in  std_logic;
        WE                          => r_wea                           , --: in  std_logic;
        ENB                         => '1'                                    , --: in  std_logic;
        WADDR                       => r_addra                         , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        RADDR                       => r_addrb                         , --: in  std_logic_vector(log2(DEPTH)-1 downto 0);
        WDATA                       => r_din                           , --: in  std_logic_vector(WIDTH-1 downto 0);
        RDATA                       => r_dout                           --: out std_logic_vector(WIDTH-1 downto 0)
    );
    
    OUT_DATA <= r_dout;
end BEHAVE;