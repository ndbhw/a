////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : DCM RT4419 21B
//  Module       : BB_TOP 
//  Author       : jyzoo.lee@samsung.com
//  Description  : LPHY Configuration
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.30 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

//////VERSION
`define P4V_VERSION  32'h6315065

//////CAPACITY
`define MAX_CC          2
`define NUM_CC          2
`define DL_NUM_LAYER    4
`define DL_NUM_ANT      4
`define UL_NUM_PATH     4
`define UL_NUM_ANT      4

//////LPHY DISABLE
//`define DLFE_CORE_DISABLE
//`define ULFE_CORE_DISABLE
//`define RAFE_CORE_DISABLE

//////BB_TOP CONFIGURATION
////DLFE
`include "dlfe_top.vh"

////ULFE////
`include "ulfe_cc.vh"

////RAFE
`define MAX_OBW                 15
