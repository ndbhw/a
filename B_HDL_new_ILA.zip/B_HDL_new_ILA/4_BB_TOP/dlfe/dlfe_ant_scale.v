////////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10, FSU20
//                 oRU : DCM RT44xx, VzW RT8808
//                 RU  : Telus RT8809
//  Module       : dlfe_ant_scale
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe antenna gain scale (configurable cell multiplexing) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.16 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.11.13 | jyzoo.lee     | Supports Gain Scale for Calibraion Symbols
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_ant_scale
#(
    parameter  NUM_CC               =   1           
   ,parameter  NUM_ANT              =   4
   ,parameter  NUM_CHAIN            =   1
   ,parameter  DI_BW                =   16           
   ,parameter  DO_BW                =   16           
   ,parameter  MAX_MU               =   0           
)(
    //--- reset & clk
        input   wire                                            i_clk                  
            
    //--- from dlfe_param_if
    ,   input   wire    [04*NUM_CC-1:0]                         i_dlfe_par_1218
    ,   input   wire    [14*NUM_CC-1:0]                         i_dlfe_par_121c
    ,   input   wire    [14*NUM_CC-1:0]                         i_dlfe_par_1280
    ,   input   wire    [14*NUM_CC-1:0]                         i_dlfe_par_1284
    ,   input   wire    [04*NUM_CC-1:0]                         i_dlfe_par_1288
    ,   input   wire    [04*NUM_CC-1:0]                         i_dlfe_par_128c

    //--- from dlfe_ofdm_mod
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [04-1:0]                                i_din_symbol_idx
    ,   input   wire    [01*NUM_CHAIN-1:0]                      i_din_en        
    ,   input   wire    [2*DI_BW*NUM_CHAIN-1:0]                 i_din_iq        
    ,   input   wire    [01*NUM_CHAIN-1:0]                      i_din_cc_id    
    ,   input   wire    [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         i_din_ant_id    
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_cddcp_dly_buf
    ,   output  reg     [01-1:0]                                o_dout_frame_sync
    ,   output  reg     [01-1:0]                                o_dout_symbol_sync
    ,   output  reg     [04-1:0]                                o_dout_symbol_idx
    ,   output  wire    [01*NUM_CHAIN-1:0]                      o_dout_en        
    ,   output  wire    [2*DO_BW*NUM_CHAIN-1:0]                 o_dout_iq        
    ,   output  reg     [01*NUM_CHAIN-1:0]                      o_dout_cc_id    
    ,   output  reg     [$clog2(NUM_ANT)*NUM_CHAIN-1:0]         o_dout_ant_id    
    ,   output  reg     [02-1:0]                                o_dout_cal_en
);

//Parameter Local Logic
localparam          CHAIN_REF           =       0                   ;
localparam          ID_CAL_DL           =       2'd1                ;
localparam          ID_CAL_UL           =       2'd2                ;
localparam          ID_CAL_UL_PUNC      =       2'd3                ;
localparam          BW_SCALE_ANT_GAIN   =       4                   ;
localparam          BW_ANT_GAIN         =       14                  ;
localparam          NUM_SLOT_FRAME      =       10*(2**MAX_MU)      ;
localparam          NUM_SYMBOL_SLOT     =       14                  ;
localparam          DLY_SYNC            =       5                   ;   

//Logic Variable
genvar gidx ;
integer i   ;

reg [13:0]  r_ant_gain              [NUM_CC-1:0]    ;
reg [13:0]  r_dlCalSymbolGain       [NUM_CC-1:0]    ;
reg [13:0]  r_ulCalSymbolGain       [NUM_CC-1:0]    ;
reg [03:0]  r_scale_ant_gain        [NUM_CC-1:0]    ;
reg [03:0]  r_scaleDlCalSymbolGain  [NUM_CC-1:0]    ;
reg [03:0]  r_scaleUlCalSymbolGain  [NUM_CC-1:0]    ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_ant_gain              [i] =  i_dlfe_par_121c[((14)*(i+1)-1)-:(14)]   ;
        r_dlCalSymbolGain       [i] =  i_dlfe_par_1280[((14)*(i+1)-1)-:(14)]   ;
        r_ulCalSymbolGain       [i] =  i_dlfe_par_1284[((14)*(i+1)-1)-:(14)]   ;
        r_scale_ant_gain        [i] =  i_dlfe_par_1218[((04)*(i+1)-1)-:(04)]   ;
        r_scaleDlCalSymbolGain  [i] =  i_dlfe_par_1288[((04)*(i+1)-1)-:(04)]   ;
        r_scaleUlCalSymbolGain  [i] =  i_dlfe_par_128c[((04)*(i+1)-1)-:(04)]   ;
    end
end
reg [13:0]      r_mux_ant_gain          [NUM_CC-1:0]    ;
reg [03:0]      r_mux_scale_ant_gain    [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            if(i_din_cal_en==ID_CAL_DL) begin
                r_mux_ant_gain          [i]  <=  r_dlCalSymbolGain      [i] ;
                r_mux_scale_ant_gain    [i]  <=  r_scaleDlCalSymbolGain [i] ;
            end
            else if(i_din_cal_en==ID_CAL_UL||i_din_cal_en==ID_CAL_UL_PUNC) begin
                r_mux_ant_gain          [i]  <=  r_ulCalSymbolGain      [i] ;
                r_mux_scale_ant_gain    [i]  <=  r_scaleUlCalSymbolGain [i] ;
            end
            else begin
                r_mux_ant_gain          [i]  <=  r_ant_gain             [i] ;
                r_mux_scale_ant_gain    [i]  <=  r_scale_ant_gain       [i] ;
            end
        end
    end
end
reg     [1-1:0]                     r_en            [NUM_CHAIN-1:0] ;
reg     [2*DI_BW-1:0]               r_iq            [NUM_CHAIN-1:0] ;   
reg     [1-1:0]                     r_en_s          [NUM_CHAIN-1:0] ;
reg     [2*(DI_BW+BW_ANT_GAIN)-1:0] r_iq_s          [NUM_CHAIN-1:0] ;   
reg     [1-1:0]                     rr_en_s         [NUM_CHAIN-1:0] ;
reg     [2*(DI_BW+BW_ANT_GAIN)-1:0] rr_iq_s         [NUM_CHAIN-1:0] ;   
wire    [1-1:0]                     w_ant_ds_r_en   [NUM_CHAIN-1:0] ;   
wire    [2*(DI_BW+BW_ANT_GAIN)-1:0] w_ant_ds_r_iq   [NUM_CHAIN-1:0] ;   
generate for(gidx=0;gidx<NUM_CHAIN;gidx=gidx+1) begin : g00_ant_scale_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    end
end
always@(posedge i_clk) begin
    r_en_s[gidx] <= r_en[gidx] ;
    if(r_en[gidx]) begin
`ifndef DLFE_AIE_DISABLE
        r_iq_s[gidx][((DI_BW+BW_ANT_GAIN)*2-1)-:(DI_BW+BW_ANT_GAIN)] <= $signed({{{BW_ANT_GAIN}{r_iq[gidx][DI_BW*2-1]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<1)*$signed({{{DI_BW}{1'd0}},r_mux_ant_gain[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]]}) ;
        r_iq_s[gidx][((DI_BW+BW_ANT_GAIN)*1-1)-:(DI_BW+BW_ANT_GAIN)] <= $signed({{{BW_ANT_GAIN}{r_iq[gidx][DI_BW*1-1]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<1)*$signed({{{DI_BW}{1'd0}},r_mux_ant_gain[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]]}) ;
`else// DLFE_AIE_DISABLE
        r_iq_s[gidx][((DI_BW+BW_ANT_GAIN)*2-1)-:(DI_BW+BW_ANT_GAIN)] <= $signed({{{BW_ANT_GAIN}{r_iq[gidx][DI_BW*2-1]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]})*$signed({{{DI_BW}{1'd0}},r_mux_ant_gain[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]]}) ;
        r_iq_s[gidx][((DI_BW+BW_ANT_GAIN)*1-1)-:(DI_BW+BW_ANT_GAIN)] <= $signed({{{BW_ANT_GAIN}{r_iq[gidx][DI_BW*1-1]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]})*$signed({{{DI_BW}{1'd0}},r_mux_ant_gain[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]]}) ;
`endif//DLFE_AIE_DISABLE
    end
end
always@(posedge i_clk) begin
    rr_en_s[gidx] <= r_en_s[gidx] ;
    if(r_en_s[gidx]) begin
        rr_iq_s[gidx] <=  r_iq_s[gidx]  ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                   )
 ,.SHIFTD_BW    (   BW_SCALE_ANT_GAIN   )
 ,.IO_BW        (   DI_BW+BW_ANT_GAIN   ))
u00_as_shiftd_rnd 
(
     .i_clk     (   i_clk                                                       )
    ,.i_in_en   (   rr_en_s[gidx]                                               )
    ,.i_in      (   rr_iq_s[gidx]                                               )
    ,.i_shiftd  (   r_mux_scale_ant_gain[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]]  )
    ,.o_out_en  (   w_ant_ds_r_en[gidx]                                         )
    ,.o_out     (   w_ant_ds_r_iq[gidx]                                         )
);
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_ANT_GAIN   )
 ,.DO_BW        (   DO_BW               ))
u01_as_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_ant_ds_r_en[gidx]                             )
    ,.i_in      (   w_ant_ds_r_iq[gidx]                             )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
always@(posedge i_clk) begin
    if(w_ant_ds_r_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)]) begin
        o_dout_cc_id  [((01)*(gidx+1)-1)-:(01)]  <=  i_din_cc_id  [((01)*(gidx+1)-1)-:(01)]   ;
        o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]  <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]   ;
    end
end
end
endgenerate//g00_ant_scale_chain

wire        w_frame_sync     ;
wire        w_symbol_sync    ;
ylib_reg #(
     .WIDTH(    2               ) 
    ,.DEPTH(    DLY_SYNC        )) 
u02_sync
(
     .i_clk      (  i_clk               )
    ,.i_in       (  {i_din_frame_sync,i_din_symbol_sync  }   )
    ,.o_out      (  {w_frame_sync    ,w_symbol_sync      }   )
);

always@(posedge i_clk) begin
    o_dout_frame_sync   <=  w_frame_sync    ;     
    o_dout_symbol_sync  <=  w_symbol_sync   ;
    if(w_symbol_sync) begin
        o_dout_symbol_idx   <=  i_din_symbol_idx    ;  
        o_dout_cal_en       <=  i_din_cal_en        ;
    end
end

endmodule
