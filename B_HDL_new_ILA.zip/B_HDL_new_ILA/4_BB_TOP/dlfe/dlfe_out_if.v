//////////////////////////////////////////////////////////////////////////////// // 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10, FSU20
//                 oRU : DCM RT44xx, VzW RT8808
//                 RU  : Telus RT8809
//  Module       : dlfe_out_if
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe output interface
//                 Output Control, TSSI (configurable cell multiplexing) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.16 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.10.20 | jyzoo.lee     | TSSI Enable from header
//  ------------+---------------+-----------------------------------------------
//   2020.12.01 | jyzoo.lee     | Add nTone, FFTType Ports for ORAN_TOP IF
//  ------------+---------------+-----------------------------------------------
//   2021.03.15 | jyzoo.lee     | Add system mode for interfacing with ORAN_TOP
//  ------------+---------------+-----------------------------------------------
//   2021.06.04 | jyzoo.lee     | BCF Enable Signal Forwarding 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_out_if
#(
    parameter  NUM_ANT              =   4           
   ,parameter  DI_BW                =   15           
   ,parameter  DO_BW                =   16           
)(
    //--- reset & clk
        input   wire                                    i_clk                  
    ,   input   wire                                    i_rst                
            
    //--- from dlfe_param_if
    ,   input   wire    [02-1:0]                        i_dlfe_par_1004
    ,   input   wire    [32-1:0]                        i_dlfe_par_1110
    ,   input   wire    [32-1:0]                        i_dlfe_par_1200
    ,   input   wire    [12-1:0]                        i_dlfe_par_1204
    ,   input   wire    [12-1:0]                        i_dlfe_par_120c
    ,   input   wire    [02-1:0]                        i_dlfe_par_1210
    ,   input   wire    [NUM_ANT-1:0]                   i_dlfe_par_124c
    
    //--- from dlfe_cc
    ,   input   wire    [12-1:0]                        i_din_bfn
    ,   input   wire    [01-1:0]                        i_din_bcf_en

    //--- from dlfe_cdd_cp_buf
    ,   input   wire    [01-1:0]                        i_din_frame_sync
    ,   input   wire    [01-1:0]                        i_din_subfrm_sync
    ,   input   wire    [01-1:0]                        i_din_slot_sync  
    ,   input   wire    [01-1:0]                        i_din_symbol_sync
    ,   input   wire    [08-1:0]                        i_din_frame_idx  
    ,   input   wire    [04-1:0]                        i_din_subfrm_idx
    ,   input   wire    [06-1:0]                        i_din_slot_idx  
    ,   input   wire    [04-1:0]                        i_din_symbol_idx
    ,   input   wire    [01*NUM_ANT-1:0]                i_din_en        
    ,   input   wire    [2*DI_BW*NUM_ANT-1:0]           i_din_iq        

    //--- to dss
    ,   output  reg     [01-1:0]                        o_dout_bfn_strb
    ,   output  reg     [12-1:0]                        o_dout_bfn     
    ,   output  reg     [01-1:0]                        o_dout_frame_sync 
    ,   output  reg     [01-1:0]                        o_dout_subfrm_sync
    ,   output  reg     [01-1:0]                        o_dout_slot_sync  
    ,   output  reg     [01-1:0]                        o_dout_symbol_sync
    ,   output  reg     [08-1:0]                        o_dout_frame_idx  
    ,   output  reg     [04-1:0]                        o_dout_subfrm_idx 
    ,   output  reg     [06-1:0]                        o_dout_slot_idx   
    ,   output  reg     [04-1:0]                        o_dout_symbol_idx 
    ,   output  reg     [01*NUM_ANT-1:0]                o_dout_en
    ,   output  reg     [2*DO_BW*NUM_ANT-1:0]           o_dout_iq

    //--- to bb_if/bb_ctrl
    ,   output  reg     [04-1:0]                        o_dout_dl_bw_idx
    ,   output  reg     [01-1:0]                        o_dout_bcf_en

    //--- to oran_top
    ,   output  reg     [01-1:0]                        o_dout_dl_sys_mode   
    ,   output  reg     [12-1:0]                        o_dout_dl_ntone   
    ,   output  reg     [02-1:0]                        o_dout_dl_fft_type
    ,   output  reg     [12-1:0]                        o_dout_dl_k0      

    //--- to dlfe_param_if
    ,   output  wire    [32-1:0]                        o_dlfe_rpt_1128
    ,   output  wire    [32-1:0]                        o_dlfe_rpt_112c
    ,   output  wire    [22-1:0]                        o_dlfe_rpt_1134
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1140 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1144 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1148 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_114c 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1150 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1154 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_1158 
    ,   output  reg     [32-1:0]                        o_dlfe_rpt_115c 
);

//Parameter Local Logic
localparam      DLY_SYNC            =           2                       ;   
localparam      NTONE_BW_020_015K   =           12'd106*12              ;
localparam      NTONE_BW_015_015K   =           12'd79 *12              ;
localparam      NTONE_BW_010_015K   =           12'd52 *12              ;
localparam      NTONE_BW_005_015K   =           12'd25 *12              ;
localparam      NTONE_BW_020_LTE    =           12'd100*12              ;
localparam      NTONE_BW_015_LTE    =           12'd75 *12              ;
localparam      NTONE_BW_010_LTE    =           12'd50 *12              ;
localparam      NTONE_BW_005_LTE    =           12'd25 *12              ;
localparam      IDX_BW_020          =           4'd3                    ;
localparam      IDX_BW_015          =           4'd2                    ;
localparam      IDX_BW_010          =           4'd1                    ;
localparam      IDX_BW_005          =           4'd0                    ;
localparam      CLK_STROBE          =           64                      ;
localparam      NUM_FRAME_TSSI      =           `DLFE_NUM_FRAME_XSSI    ; //7'd4                    ;

//Logic Variable
genvar gidx ;
integer i   ;

reg [1-1:0]         r_iq_swap   ;
reg [NUM_ANT-1:0]   r_ant_gate  ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        r_iq_swap   <=  i_dlfe_par_1004[1]  ;
        r_ant_gate  <=  i_dlfe_par_124c     ;
    end
end
reg [1-1:0]             r_en    [NUM_ANT-1:0]  ;
reg [2*DI_BW-1:0]       r_iq    [NUM_ANT-1:0]  ;   
reg [1-1:0]             rr_en   [NUM_ANT-1:0]  ;
reg [2*DO_BW-1:0]       rr_iq   [NUM_ANT-1:0]  ;   
reg [1-1:0]             rrr_en  [NUM_ANT-1:0]  ;
reg [2*DO_BW-1:0]       rrr_iq  [NUM_ANT-1:0]  ;   

wire [01-1:0]           w_frame_sync     ;
wire [01-1:0]           w_subfrm_sync    ;
wire [01-1:0]           w_slot_sync      ;
wire [01-1:0]           w_symbol_sync    ;

reg  [31:0]             dl_valid_pulse   ; 
reg  [01-1:0]           o_dout_frame_sync_d;

generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g00_out_ctrl
always@(posedge i_clk) begin
    r_en[gidx]  <=  i_din_en [gidx] ;
    if(i_din_en[gidx]) begin
        r_iq[gidx]  <=  i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
    end
end
always@(posedge i_clk) begin
    rr_en[gidx]  <=  r_en[gidx] ;
    if(r_en[gidx]) begin
        if(r_iq_swap) begin
            rr_iq[gidx] <=  {{{DO_BW-DI_BW}{r_iq[gidx][DI_BW*1-1]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW],{{DO_BW-DI_BW}{r_iq[gidx][DI_BW*2-1]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}   ; 
        end
        else begin
            rr_iq[gidx] <=  {{{DO_BW-DI_BW}{r_iq[gidx][DI_BW*2-1]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW],{{DO_BW-DI_BW}{r_iq[gidx][DI_BW*1-1]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}   ;   
        end
    end
end

//always@(posedge i_clk) begin
//    if(i_rst == 'b1) begin
//        dl_valid_pulse <= 'b0000000000000000;
//    end
//    else begin
//        if(w_frame_sync == 'b1) begin
//            if(i_dlfe_par_1210 == 'd3) begin // 122.88 MSps
//                dl_valid_pulse <= 'b0101010101010101;
//            end 
//            else if(i_dlfe_par_1210 == 'd2) begin // 61.44 MSps
//                dl_valid_pulse <= 'b0001000100010001;
//            end 
//            else if(i_dlfe_par_1210 == 'd1) begin // 30.72 MSps
//                dl_valid_pulse <= 'b0000000100000001;
//            end 
//            else begin // 15.36 MSps
//                dl_valid_pulse <= 'b0000000000000001;
//            end
//        end 
//        else begin
//            dl_valid_pulse <= {dl_valid_pulse[0], dl_valid_pulse[15:1]};
//        end
//    end
//end

// rf2240-11B: lte scs15k
always@(posedge i_clk) begin
    if(i_rst == 'b1) begin
        dl_valid_pulse <= 'b00000000000000000000000000000000;
    end
    else begin
        if(w_frame_sync == 'b1) begin
            if(i_dlfe_par_1210 == 'd2) begin // 30.72 
                dl_valid_pulse <= 'b00000001000000010000000100000001;
            end 
            else if(i_dlfe_par_1210 == 'd1) begin // 15.36 MSps
                dl_valid_pulse <= 'b00000000000000010000000000000001;
            end 
            else if(i_dlfe_par_1210 == 'd0) begin // 7.68 MSps
                dl_valid_pulse <= 'b00000000000000000000000000000001;
            end 
            else begin // 7.68, not support fft 4096 with lte 
                dl_valid_pulse <= 'b00000000000000000000000000000001;
            end
        end 
        else begin
            dl_valid_pulse <= {dl_valid_pulse[0], dl_valid_pulse[31:1]};
        end
    end
end

//always@(posedge i_clk) begin

always@(posedge i_clk) begin
    rrr_en[gidx] <=  rr_en[gidx] ;
    if(rr_en[gidx]&r_ant_gate[gidx]) begin
        rrr_iq[gidx] <= rr_iq[gidx] ;
    end
    else begin
        rrr_iq[gidx] <= {{2*DO_BW}{1'b0}} ;
    end
end
always@(*) begin
    //o_dout_en[gidx] =  dl_valid_pulse[0] ;
    //o_dout_en[gidx] =  rrr_en[gidx] ;
    o_dout_iq[(2*DO_BW*(gidx+1)-1)-:2*DO_BW] <= rrr_iq[gidx] ;
end
end
endgenerate

always@(posedge i_clk) begin
    if(i_rst == 'b1) begin
        o_dout_en <= 'b0000;
    end
    else begin
        if(w_frame_sync == 'b1) begin
            o_dout_en <= 'b1111;
        end
    end
end

ylib_reg #(
     .WIDTH(    4               ) 
    ,.DEPTH(    DLY_SYNC        )) 
u03_sync
(
     .i_clk      (  i_clk               )
    ,.i_in       (  {i_din_frame_sync   ,i_din_subfrm_sync  ,i_din_slot_sync    ,i_din_symbol_sync  }   )
    ,.o_out      (  {w_frame_sync       ,w_subfrm_sync      ,w_slot_sync        ,w_symbol_sync      }   )
);

always@(posedge i_clk) begin
    o_dout_frame_sync_d   <=  w_frame_sync  ;
    o_dout_frame_sync   <=  o_dout_frame_sync_d    ;     
    o_dout_subfrm_sync  <=  w_subfrm_sync   ;
    o_dout_slot_sync    <=  w_slot_sync     ;
    o_dout_symbol_sync  <=  w_symbol_sync   ;
    if(w_frame_sync) begin
        o_dout_frame_idx    <=  i_din_frame_idx ;  
        o_dout_bfn          <=  i_din_bfn   ; 
        case(i_dlfe_par_120c)
            NTONE_BW_020_015K,NTONE_BW_020_LTE  : o_dout_dl_bw_idx <= IDX_BW_020 ; 
            NTONE_BW_015_015K,NTONE_BW_015_LTE  : o_dout_dl_bw_idx <= IDX_BW_015 ; 
            NTONE_BW_010_015K,NTONE_BW_010_LTE  : o_dout_dl_bw_idx <= IDX_BW_010 ; 
            NTONE_BW_005_015K,NTONE_BW_005_LTE  : o_dout_dl_bw_idx <= IDX_BW_005 ; 
            default                             : o_dout_dl_bw_idx <= IDX_BW_010 ; 
        endcase
        o_dout_dl_sys_mode  <=  i_dlfe_par_1200[28] ;      
        o_dout_dl_ntone     <=  i_dlfe_par_120c     ;      
        o_dout_dl_fft_type  <=  i_dlfe_par_1210     ;      
        o_dout_dl_k0        <=  i_dlfe_par_1204     ;      
    end
    if(w_subfrm_sync) begin
        o_dout_subfrm_idx   <=  i_din_subfrm_idx    ;  
    end
    if(w_slot_sync) begin
        o_dout_slot_idx     <=  i_din_slot_idx      ;  
    end
    if(w_symbol_sync) begin
        o_dout_symbol_idx   <=  i_din_symbol_idx    ;  
    end
end

reg [CLK_STROBE:0] r_dl_bfn ;
always@(*) begin 
    r_dl_bfn[0] = w_frame_sync ;        
    o_dout_bfn_strb = |r_dl_bfn[CLK_STROBE:1] ; 
end
always@(posedge i_clk) begin
    for(i=1;i<=CLK_STROBE;i=i+1) begin
        r_dl_bfn[i] <= r_dl_bfn[i-1];
    end
end

ylib_mon_smp #(
     .NUM_STREAM    (  2           ) 
    ,.DIO_BW        (  DO_BW       )) 
u04_td_mon_smp
(
     .i_clk         (  i_clk                                )
    ,.i_target      (  i_dlfe_par_1110                      )
    ,.i_frame       (  o_dout_frame_idx                     )
    ,.i_slot        ( {2'd0,o_dout_slot_idx}                )
    ,.i_symbol      ( {4'd0,o_dout_symbol_idx}              )
    ,.i_rsync       (  i_dlfe_par_1110[31]                  )
    ,.i_en          (  rrr_en[i_dlfe_par_1110[27:24]]       )
    ,.i_in          (  rrr_iq[i_dlfe_par_1110[27:24]]       )
    ,.o_max         (  o_dlfe_rpt_1128                      )
    ,.o_min         (  o_dlfe_rpt_112c                      )
);

`ifndef  DLFE_TSSI_DISABLE
wire    [0:0]   w_nr_tssi_en   [NUM_ANT-1:0]   ;
wire    [6:0]   w_nr_tssi_id   [NUM_ANT-1:0]   ;
wire    [31:0]  w_nr_tssi      [NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g01_nr_tssi
ylib_xssi #(
     .NUM_FRAME     (    NUM_FRAME_TSSI     ) 
    ,.RPT_FRAME     (    7'd0               ) 
    ,.BW_SIG        (    15                 ) 
    ,.ID_XSSI       (    gidx               )) 
u05_nr_tssi
(
      .i_rst            (     i_rst                                     )
     ,.i_clk            (     i_clk                                     )
     ,.i_frame_sync     (     w_frame_sync                              )
     ,.i_sig_en         (     rr_en[gidx]                               )
     ,.i_sig_i          (     rr_iq[gidx][((DO_BW*2-1)-1)-:DI_BW]       )
     ,.i_sig_q          (     rr_iq[gidx][((DO_BW*1-1)-1)-:DI_BW]       )
     ,.o_xssi_en        (     w_nr_tssi_en[gidx]                        )
     ,.o_xssi_id        (     w_nr_tssi_id[gidx]                        )
     ,.o_xssi           (     w_nr_tssi   [gidx]                        )
);
end
endgenerate
if(NUM_ANT==4) begin
always@(*) begin
    o_dlfe_rpt_1140    =   w_nr_tssi[0] ;                 
    o_dlfe_rpt_1144    =   w_nr_tssi[1] ;                 
    o_dlfe_rpt_1148    =   w_nr_tssi[2] ;                 
    o_dlfe_rpt_114c    =   w_nr_tssi[3] ;                 
    o_dlfe_rpt_1150    =   32'd0        ;                 
    o_dlfe_rpt_1154    =   32'd0        ;                 
    o_dlfe_rpt_1158    =   32'd0        ;                 
    o_dlfe_rpt_115c    =   32'd0        ;                 
end
end//NUM_ANT
else if(NUM_ANT==2) begin
always@(*) begin
    o_dlfe_rpt_1140    =   w_nr_tssi[0]   ;                 
    o_dlfe_rpt_1144    =   w_nr_tssi[1]   ;                 
    o_dlfe_rpt_1148    =   32'd0        ;                 
    o_dlfe_rpt_114c    =   32'd0        ;                 
    o_dlfe_rpt_1150    =   32'd0        ;                 
    o_dlfe_rpt_1154    =   32'd0        ;                 
    o_dlfe_rpt_1158    =   32'd0        ;                 
    o_dlfe_rpt_115c    =   32'd0        ;                 
end
end//NUM_ANT
else if(NUM_ANT==8) begin
always@(*) begin
    o_dlfe_rpt_1140    =   w_nr_tssi[0]   ;                 
    o_dlfe_rpt_1144    =   w_nr_tssi[1]   ;                 
    o_dlfe_rpt_1148    =   w_nr_tssi[2]   ;                 
    o_dlfe_rpt_114c    =   w_nr_tssi[3]   ;                 
    o_dlfe_rpt_1150    =   w_nr_tssi[4]   ;                 
    o_dlfe_rpt_1154    =   w_nr_tssi[5]   ;                 
    o_dlfe_rpt_1158    =   w_nr_tssi[6]   ;                 
    o_dlfe_rpt_115c    =   w_nr_tssi[7]   ;                 
end
end//NUM_ANT
`else //DLFE_TSSI_DISABLE
always@(*) begin
    o_dlfe_rpt_1140    =   32'd0    ;                 
    o_dlfe_rpt_1144    =   32'd0    ;                 
    o_dlfe_rpt_1148    =   32'd0    ;                 
    o_dlfe_rpt_114c    =   32'd0    ;                 
    o_dlfe_rpt_1150    =   32'd0    ;                 
    o_dlfe_rpt_1154    =   32'd0    ;                 
    o_dlfe_rpt_1158    =   32'd0    ;                 
    o_dlfe_rpt_115c    =   32'd0    ;                 
end
`endif //DLFE_TSSI_DISABLE

ylib_mon_time_stamp #(
     .WIDTH         (  22           )) 
u06_mon_time_stamp
(
     .i_clk         (  i_clk                )
    ,.i_sync        (  w_frame_sync         )
    ,.o_time_stamp  (  o_dlfe_rpt_1134      )
);

always@(posedge i_clk) begin
    if(w_frame_sync) begin
        o_dout_bcf_en <=  i_din_bcf_en ;  
    end
end
endmodule
