////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2021 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : VzW RT8808
//                 RU  : Telus RT88xx
//  Module       : dlfe_bfw_mult
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe Opt7-2b beamforming weight multiplication 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.12.10 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2021.01.14 | jyzoo.lee     | Supports multiplexing
//  ------------+---------------+-----------------------------------------------
//   2021.05.03 | jyzoo.lee     | Cals Processing for Versal Optimization
//  ------------+---------------+-----------------------------------------------
//   2021.05.10 | jyzoo.lee     | Xilinx Cmult Support for Resource Reduction
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Merge the CPRI dedicated module
//  ------------+---------------+-----------------------------------------------
//   2021.06.28 | jyzoo.lee     | Indirect CPRI BF Weight Interface Support 
//  ------------+---------------+-----------------------------------------------
//   2021.06.29 | jyzoo.lee     | Memory Optimized for CPRI
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_bfw_mult
#(
    parameter   NUM_CC              =   1
   ,parameter   NUM_LAYER           =   1
   ,parameter   NUM_ANT             =   1
`ifndef DLFE_ORAN_DISABLE
   ,parameter   NUM_I_CHAIN         =   1
`else //DLFE_ORAN_DISABLE
   ,parameter   NUM_LANE_CC         =   4
   ,parameter   NUM_LAYER_LANE      =   2
`endif //DLFE_ORAN_DISABLE
   ,parameter   NUM_O_CHAIN         =   1
   ,parameter   MAX_NIFFT           =   2048 
   ,parameter   DI_BW               =   16           
   ,parameter   DO_BW               =   16           
   ,parameter   ADDR_OFFSET         =   'h00000           
   ,parameter   BFCB_ADDR_OFFSET    =   'h00000           
   ,parameter   VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  
            
    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid

    //--- from dlfe_param_if
    ,   input   wire    [$clog2(NUM_LAYER)-1:0]                 i_dlfe_par_3c00
    ,   input   wire    [$clog2(NUM_ANT  )-1:0]                 i_dlfe_par_3c04
    ,   input   wire    [$clog2(NUM_LAYER)-1:0]                 i_dlfe_par_3c08

    //--- from bb_cal_schdlr
    ,   input   wire    [02-1:0]                                i_cals_cal_en
    ,   input   wire    [01*NUM_ANT-1:0]                        i_cals_pat_en 
    ,   input   wire    [2*DI_BW-1:0]                           i_cals_pat_iq 

    //--- from dlfe_in_if
    ,   input   wire    [01-1:0]                                i_din_frame_sync 
    ,   input   wire    [01-1:0]                                i_din_subfrm_sync
    ,   input   wire    [01-1:0]                                i_din_slot_sync  
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [03-1:0]                                i_din_mu
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
`ifndef DLFE_ORAN_DISABLE
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en        
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq                
    ,   input   wire    [15*NUM_I_CHAIN-1:0]                    i_din_beam_id       
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_cc_id
    ,   input   wire    [$clog2(NUM_LAYER)*NUM_I_CHAIN-1:0]     i_din_lyr_id
    ,   input   wire    [05-1:0]                                i_din_nlayer
`else //DLFE_ORAN_DISABLE
    ,   input   wire    [01*NUM_LAYER_LANE*NUM_LANE_CC-1:0]     i_din_en        
    ,   input   wire    [2*DI_BW*NUM_LANE_CC-1:0]               i_din_iq                
    ,   input   wire    [12-1:0]                                i_din_cb_idx
    ,   input   wire    [05-1:0]                                i_din_nmusul
    ,   input   wire    [06-1:0]                                i_din_re_map
    ,   input   wire    [01*NUM_LANE_CC-1:0]                    i_din_cc_id
    ,   input   wire    [$clog2(NUM_LAYER)*NUM_LANE_CC-1:0]     i_din_lyr_id
`endif //DLFE_ORAN_DISABLE

    //--- to dlfe_ifft_map_buf
    ,   output  wire    [01-1:0]                                o_dout_frame_sync 
    ,   output  wire    [01-1:0]                                o_dout_subfrm_sync
    ,   output  wire    [01-1:0]                                o_dout_slot_sync  
    ,   output  wire    [01-1:0]                                o_dout_symbol_sync
    ,   output  wire    [01*NUM_ANT-1:0]                        o_dout_en        
    ,   output  wire    [2*DO_BW*NUM_ANT-1:0]                   o_dout_iq                
    ,   output  reg     [01*NUM_ANT-1:0]                        o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_ANT-1:0]           o_dout_ant_id
    ,   output  reg     [03-1:0]                                o_dout_mu
    ,   output  reg     [04*NUM_CC-1:0]                         o_dout_fft_size
    ,   output  reg     [02-1:0]                                o_dout_cal_en
);

//Parameter Local Logic
`ifndef DLFE_ORAN_DISABLE
localparam                      CHAIN_REF               =       0                                               ;
localparam                      BW_WGT                  =       12                                              ;
localparam                      BW_ISQRT                =       13                                              ;
localparam  [13-1:00]           DLY_SYNC                =       NUM_I_CHAIN<NUM_LAYER ? MAX_NIFFT+305 : 15      ;   
localparam                      DLY_WGT_RD              =       3                                               ;   
localparam                      DLY_IQ                  =       3                                               ;   
localparam                      DLY_BUF_SYNC            =       2                                               ;   
localparam                      DLY_NLAYER              =       10                                              ;   
localparam  [15-1:00]           NUM_BF_CBW              =       2**13                                           ;   
localparam  [15-1:00]           NUM_SU_CBW              =       2**13                                           ;   
localparam  [15-1:00]           NUM_MU_CBW              =       2**13                                           ;   
localparam  [15-1:00]           BID_BASE_BF_CBW         =       0*NUM_BF_CBW                                    ;   
localparam  [15-1:00]           BID_BASE_SU_CBW         =       1*NUM_SU_CBW                                    ;   
localparam  [15-1:00]           BID_BASE_MU_CBW         =       2*NUM_MU_CBW                                    ;   
localparam  [20-1:00]           BF_CB_START_ADDR        =       'h10000                                         ;
localparam  [20-1:00]           BF_CB_ADDR_OFFSET       =       NUM_BF_CBW*4                                    ;
localparam  [20-1:00]           SU_CB_START_ADDR        =       'h50000                                         ;
localparam  [20-1:00]           SU_CB_ADDR_OFFSET       =       NUM_SU_CBW*4                                    ;
localparam  [20-1:00]           MU_CB_START_ADDR        =       'h90000                                         ;
localparam  [20-1:00]           MU_CB_ADDR_OFFSET       =       NUM_MU_CBW*4                                    ;
`else //DLFE_ORAN_DISABLE
localparam                              LANE_REF                    =       0                                                               ;
localparam                              IDX_LANE00                  =       0                                                               ;
localparam                              IDX_LANE01                  =       1                                                               ;
localparam                              IDX_LANE02                  =       2                                                               ;
localparam                              IDX_LANE03                  =       3                                                               ;
localparam                              CC_REF                      =       0                                                               ;
localparam                              BW_WGT                      =       12                                                              ;
localparam                              BW_ISQRT                    =       13                                                              ;
localparam  [06-1:00]                   IDX_REMAP_MUCB              =       0                                                               ;
localparam  [06-1:00]                   IDX_REMAP_SUCB              =       1                                                               ;
localparam  [06-1:00]                   IDX_REMAP_WPREDEF           =       2                                                               ;
localparam                              NUM_LAYER_R1                =       1                                                               ;
localparam                              NUM_LAYER_R2                =       2                                                               ;
localparam                              NUM_LAYER_R3                =       3                                                               ;
localparam                              NUM_LAYER_R4                =       4                                                               ;
localparam                              DLY_SYNC                    =       5'd19                                                           ;
localparam                              DLY_WGT_RD                  =       2                                                               ;
localparam                              DLY_IN                      =       5                                                               ;
localparam                              DLY_BUF_SYNC                =       2                                                               ;
localparam                              DLY_NLAYER                  =       6                                                               ;
localparam                              NUM_BFCB_PORT8_R1           =       256                                                             ;
localparam                              NUM_BFCB_PORT8_R2           =       512                                                             ;
localparam                              NUM_BFCB_PORT8_R3           =       384                                                             ;
localparam                              NUM_BFCB_PORT8_R4           =       384                                                             ;
localparam                              NUM_BFCB_PORT4_R1           =       32                                                              ;
localparam                              NUM_BFCB_PORT4_R2           =       32                                                              ;
localparam                              NUM_BFCB_PORT4_R3           =       16                                                              ;
localparam                              NUM_BFCB_PORT4_R4           =       16                                                              ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK01                  =       0                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK02                  =       1                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK03                  =       2                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_RANK04                  =       3                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER00                 =       0                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER01                 =       1                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER02                 =       2                                                               ;
localparam  [$clog2(NUM_LAYER)-1:0]     IDX_LAYER03                 =       3                                                               ;
localparam                              NUM_CBIDX                   =       2592                                                            ;
localparam                              NUM_PREDEF_BEAM             =       62                                                              ;
localparam  [20-1:00]                   SUCB_START_ADDR             =       BFCB_ADDR_OFFSET                                                ;
localparam  [20-1:00]                   SUCB_END_ADDR               =       BFCB_ADDR_OFFSET+NUM_CBIDX*4                                    ;
localparam  [20-1:00]                   PREDEFW_START_ADDR          =       ADDR_OFFSET+20'h08008                                           ;
localparam  [20-1:00]                   PREDEFW_END_ADDR            =       PREDEFW_START_ADDR+NUM_PREDEF_BEAM*4                            ;
localparam  [20-1:00]                   BFCB0_R1_L0_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB0_R2_L0_START_ADDR      =       BFCB0_R1_L0_START_ADDR+NUM_BFCB_PORT8_R1+NUM_BFCB_PORT4_R1      ;
localparam  [20-1:00]                   BFCB0_R3_L0_START_ADDR      =       BFCB0_R2_L0_START_ADDR+NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2      ;
localparam  [20-1:00]                   BFCB0_R4_L0_START_ADDR      =       BFCB0_R3_L0_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB0_PD_L0_START_ADDR      =       BFCB0_R4_L0_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB0_R2_L1_START_ADDR      =       BFCB0_PD_L0_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB0_R3_L1_START_ADDR      =       BFCB0_R2_L1_START_ADDR+NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2      ;
localparam  [20-1:00]                   BFCB0_R4_L1_START_ADDR      =       BFCB0_R3_L1_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB0_PD_L1_START_ADDR      =       BFCB0_R4_L1_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB0_END_ADDR              =       BFCB0_PD_L1_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB1_R3_L2_START_ADDR      =       0                                                               ;
localparam  [20-1:00]                   BFCB1_R4_L2_START_ADDR      =       BFCB1_R3_L2_START_ADDR+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3      ;
localparam  [20-1:00]                   BFCB1_PD_L2_START_ADDR      =       BFCB1_R4_L2_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB1_R4_L3_START_ADDR      =       BFCB1_PD_L2_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam  [20-1:00]                   BFCB1_PD_L3_START_ADDR      =       BFCB1_R4_L3_START_ADDR+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4      ;
localparam  [20-1:00]                   BFCB1_END_ADDR              =       BFCB1_PD_L3_START_ADDR+NUM_PREDEF_BEAM                          ;
localparam                              BW_MEM_DATA                 =       72                                                              ;
localparam  integer                     NUM_BFCB_MEM                =       $ceil((2.0*BW_WGT*NUM_ANT)/BW_MEM_DATA)                         ;
localparam                              BW_BFCB_MEM_DATA            =       BW_MEM_DATA*NUM_BFCB_MEM                                        ;
localparam                              SIZE_MAX_BFMEM              =       NUM_BFCB_PORT8_R1+NUM_BFCB_PORT4_R1+(NUM_BFCB_PORT8_R2+NUM_BFCB_PORT4_R2+NUM_BFCB_PORT8_R3+NUM_BFCB_PORT4_R3+NUM_BFCB_PORT8_R4+NUM_BFCB_PORT4_R4)*2 ;
localparam  [20-1:00]                   NPREDEFL_START_ADDR         =       ADDR_OFFSET+'h3000                                              ;
localparam  [20-1:00]                   NPREDEFL_END_ADDR           =       NPREDEFL_START_ADDR+NUM_PREDEF_BEAM*4                           ;
localparam  [2*BW_WGT-1:00]             BYPASS_BFW_CALS             =      'h100000                                                         ;
localparam  [05-1:00]                   NLAYER_CALS                 =      'h1                                                              ;
`endif //DLFE_ORAN_DISABLE

//Logic Variable
integer i ;
genvar gidx ;

`ifndef DLFE_ORAN_DISABLE
reg [01-1:0]        r_en        [NUM_I_CHAIN-1:0][DLY_IQ:0] ;
reg [2*DI_BW-1:0]   r_iq        [NUM_I_CHAIN-1:0][DLY_IQ:0] ;   
reg [32-1:0]        r_cpu_wdata [NUM_CC-1:0];
reg [2*BW_WGT-1:0]  r_cpu_wgt   [NUM_CC-1:0];
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cpu_wdata [i] = i_cpu_wdata[((32)*(i+1)-1)-:(32)] ;
        r_cpu_wgt   [i] = {r_cpu_wdata[i][16+BW_WGT-1:16],r_cpu_wdata[i][00+BW_WGT-1:00]};
    end
end

reg [01-1:0]        r_bfcb_buf_en       [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        r_bfcb_buf_wren     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [20-1:0]        r_bfcb_buf_addr     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [2*BW_WGT-1:0]  r_bfcb_buf_wdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        r_bfcb_buf_rden     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
wire[2*BW_WGT-1:0]  w_bfcb_buf_rdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        rr_bfcb_buf_rden    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [2*BW_WGT-1:0]  rr_bfcb_buf_rdata   [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [01-1:0]        rr_bfcb_buf_en      [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
generate for(gidx=0;gidx<NUM_I_CHAIN*NUM_ANT*NUM_CC;gidx=gidx+1) begin : g00_0_bfcb_mem
always@(posedge i_clk) begin
    if(i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_bfcb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_bfcb_buf_wren  [gidx]  <=  i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
        r_bfcb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_bfcb_buf_wdata [gidx]  <=  r_cpu_wgt[gidx/(NUM_I_CHAIN*NUM_ANT)]  ;
        r_bfcb_buf_rden  [gidx]  <=  1'd0                                                        ;
    end
    else if(i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_bfcb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_bfcb_buf_wren  [gidx]  <=  1'd0                                                        ;
        r_bfcb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(BF_CB_START_ADDR+BF_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_bfcb_buf_rden  [gidx]  <=  i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
    end
    else if((r_en[gidx/(NUM_ANT*NUM_CC)][0])&&(i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]>=BID_BASE_BF_CBW&&i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]<BID_BASE_BF_CBW+NUM_BF_CBW)&&(i_din_cc_id[((01)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(01)]==(gidx/(NUM_I_CHAIN*NUM_ANT)))) begin
        r_bfcb_buf_en    [gidx]  <=  1'd1   ;
        r_bfcb_buf_wren  [gidx]  <=  1'd0   ;
        r_bfcb_buf_rden  [gidx]  <=  1'd0   ;
        r_bfcb_buf_addr  [gidx]  <= {1'd0,i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]} - BID_BASE_BF_CBW    ;  
    end
    else begin
        r_bfcb_buf_en    [gidx]  <=  1'd0   ;
        r_bfcb_buf_wren  [gidx]  <=  1'd0   ;
        r_bfcb_buf_rden  [gidx]  <=  1'd0   ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   2*BW_WGT            )
   ,.DEPTH  (   NUM_BF_CBW          )
   ,.VENDOR (   VENDOR              )) 
u00_0_bfcb_mem (
    .clk    (i_clk                                                              )
   ,.we     (r_bfcb_buf_wren[gidx]                                              )
   ,.en     (r_bfcb_buf_en[gidx]|r_bfcb_buf_wren[gidx]|r_bfcb_buf_rden[gidx]    )
   ,.addr   (r_bfcb_buf_addr[gidx][$clog2(NUM_BF_CBW)-1:0]                      )
   ,.di     (r_bfcb_buf_wdata[gidx]                                             )
   ,.dout   (w_bfcb_buf_rdata[gidx]                                             )
);
always@(posedge i_clk) begin
    rr_bfcb_buf_en[gidx]      <= r_bfcb_buf_en[gidx]    ;
    rr_bfcb_buf_rden[gidx][0] <= r_bfcb_buf_rden[gidx]  ;
end
always@(*) begin
    rr_bfcb_buf_rdata[gidx][0] = w_bfcb_buf_rdata[gidx]  ;
end
if(DLY_WGT_RD>1) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb_buf_rden[gidx][i]   <=  rr_bfcb_buf_rden[gidx][i-1]   ;
        if(rr_bfcb_buf_rden[gidx][i-1]) begin
            rr_bfcb_buf_rdata[gidx][i]  <=  rr_bfcb_buf_rdata[gidx][i-1]  ;
        end
    end
end
end//if(DLY_WGT_RD>1)
end
endgenerate

reg [01-1:0]        r_sucb_buf_en       [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        r_sucb_buf_wren     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
reg [20-1:0]        r_sucb_buf_addr     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
reg [2*BW_WGT-1:0]  r_sucb_buf_wdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        r_sucb_buf_rden     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
wire[2*BW_WGT-1:0]  w_sucb_buf_rdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0] ;
reg [01-1:0]        rr_sucb_buf_rden    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [2*BW_WGT-1:0]  rr_sucb_buf_rdata   [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [01-1:0]        rr_sucb_buf_en      [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
`ifndef DLFE_SU_PC_DISABLE
generate for(gidx=0;gidx<NUM_I_CHAIN*NUM_ANT*NUM_CC;gidx=gidx+1) begin : g00_1_sucb_mem
always@(posedge i_clk) begin
    if(i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_sucb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_sucb_buf_wren  [gidx]  <=  i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
        r_sucb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_sucb_buf_wdata [gidx]  <=  r_cpu_wgt[gidx/(NUM_I_CHAIN*NUM_ANT)]  ;
        r_sucb_buf_rden  [gidx]  <=  1'd0                                                        ;
    end
    else if(i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_sucb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_sucb_buf_wren  [gidx]  <=  1'd0                                                        ;
        r_sucb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(SU_CB_START_ADDR+SU_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_sucb_buf_rden  [gidx]  <=  i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
    end
    else if((r_en[gidx/(NUM_ANT*NUM_CC)][0])&&(i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]>=BID_BASE_SU_CBW&&i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]<BID_BASE_SU_CBW+NUM_SU_CBW)&&(i_din_cc_id[((01)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(01)]==(gidx/(NUM_I_CHAIN*NUM_ANT)))) begin
        r_sucb_buf_en    [gidx]  <=  1'd1   ;
        r_sucb_buf_wren  [gidx]  <=  1'd0   ;
        r_sucb_buf_rden  [gidx]  <=  1'd0   ;
        r_sucb_buf_addr  [gidx]  <= {1'd0,i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]} - BID_BASE_SU_CBW    ;  
    end
    else begin
        r_sucb_buf_en    [gidx]  <=  1'd0   ;
        r_sucb_buf_wren  [gidx]  <=  1'd0   ;
        r_sucb_buf_rden  [gidx]  <=  1'd0   ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   2*BW_WGT            )
   ,.DEPTH  (   NUM_SU_CBW          )
   ,.VENDOR (   VENDOR              )) 
u00_1_sucb_mem (
    .clk    (i_clk                                                              )
   ,.we     (r_sucb_buf_wren[gidx]                                              )
   ,.en     (r_sucb_buf_en[gidx]|r_sucb_buf_wren[gidx]|r_sucb_buf_rden[gidx]    )
   ,.addr   (r_sucb_buf_addr[gidx][$clog2(NUM_SU_CBW)-1:0]                      )
   ,.di     (r_sucb_buf_wdata[gidx]                                             )
   ,.dout   (w_sucb_buf_rdata[gidx]                                             )
);
always@(posedge i_clk) begin
    rr_sucb_buf_en[gidx]      <= r_sucb_buf_en[gidx]    ;
    rr_sucb_buf_rden[gidx][0] <= r_sucb_buf_rden[gidx]  ;
end
always@(*) begin
    rr_sucb_buf_rdata[gidx][0] = w_sucb_buf_rdata[gidx]  ;
end
if(DLY_WGT_RD>1) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_sucb_buf_rden[gidx][i]   <=  rr_sucb_buf_rden[gidx][i-1]   ;
        if(rr_sucb_buf_rden[gidx][i-1]) begin
            rr_sucb_buf_rdata[gidx][i]  <=  rr_sucb_buf_rdata[gidx][i-1]  ;
        end
    end
end
end//if(DLY_WGT_RD>1)
end
endgenerate
`endif// DLFE_SU_PC_DISABLE

reg [01-1:0]        r_mucb_buf_en       [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        r_mucb_buf_wren     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [20-1:0]        r_mucb_buf_addr     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [2*BW_WGT-1:0]  r_mucb_buf_wdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        r_mucb_buf_rden     [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
wire[2*BW_WGT-1:0]  w_mucb_buf_rdata    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
reg [01-1:0]        rr_mucb_buf_rden    [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [2*BW_WGT-1:0]  rr_mucb_buf_rdata   [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0][DLY_WGT_RD:0] ;
reg [01-1:0]        rr_mucb_buf_en      [NUM_I_CHAIN*NUM_ANT*NUM_CC-1:0]    ;
`ifndef DLFE_MU_PC_DISABLE
generate for(gidx=0;gidx<NUM_I_CHAIN*NUM_ANT*NUM_CC;gidx=gidx+1) begin : g00_2_mucb_mem
always@(posedge i_clk) begin
    if(i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_mucb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_mucb_buf_wren  [gidx]  <=  i_cpu_wren[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
        r_mucb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_mucb_buf_wdata [gidx]  <=  r_cpu_wgt[gidx/(NUM_I_CHAIN*NUM_ANT)]  ;
        r_mucb_buf_rden  [gidx]  <=  1'd0                                                        ;
    end
    else if(i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]>=(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*(gidx%NUM_ANT))&&i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]<(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*((gidx%NUM_ANT)+1))) begin
        r_mucb_buf_en    [gidx]  <=  1'd0                                                        ;
        r_mucb_buf_wren  [gidx]  <=  1'd0                                                        ;
        r_mucb_buf_addr  [gidx]  <= (i_cpu_addr[((20)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(20)]-(MU_CB_START_ADDR+MU_CB_ADDR_OFFSET*(gidx%NUM_ANT)))>>2    ; 
        r_mucb_buf_rden  [gidx]  <=  i_cpu_rden[((01)*(gidx/(NUM_I_CHAIN*NUM_ANT)+1)-1)-:(01)]   ;
    end
    else if((r_en[gidx/(NUM_ANT*NUM_CC)][0])&&(i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]>=BID_BASE_MU_CBW&&i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]<BID_BASE_MU_CBW+NUM_MU_CBW)&&(i_din_cc_id[((01)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(01)]==(gidx/(NUM_I_CHAIN*NUM_ANT)))) begin
        r_mucb_buf_en    [gidx]  <=  1'd1    ;
        r_mucb_buf_wren  [gidx]  <=  1'd0    ;
        r_mucb_buf_rden  [gidx]  <=  1'd0    ;
        r_mucb_buf_addr  [gidx]  <= {1'd0,i_din_beam_id[((15)*((gidx/(NUM_ANT*NUM_CC))+1)-1)-:(15)]} - BID_BASE_MU_CBW    ;  
    end
    else begin
        r_mucb_buf_en    [gidx]  <=  1'd0 ;
        r_mucb_buf_wren  [gidx]  <=  1'd0 ;
        r_mucb_buf_rden  [gidx]  <=  1'd0 ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   2*BW_WGT            )
   ,.DEPTH  (   NUM_MU_CBW          )
   ,.VENDOR (   VENDOR              )) 
u00_2_mucb_mem (
    .clk    (i_clk                                                              )
   ,.we     (r_mucb_buf_wren[gidx]                                              )
   ,.en     (r_mucb_buf_en[gidx]|r_mucb_buf_wren[gidx]|r_mucb_buf_rden[gidx]    )
   ,.addr   (r_mucb_buf_addr[gidx][$clog2(NUM_MU_CBW)-1:0]                      )
   ,.di     (r_mucb_buf_wdata[gidx]                                             )
   ,.dout   (w_mucb_buf_rdata[gidx]                                             )
);
always@(posedge i_clk) begin
    rr_mucb_buf_en[gidx]      <= r_mucb_buf_en[gidx]    ;
    rr_mucb_buf_rden[gidx][0] <= r_mucb_buf_rden[gidx]  ;
end
always@(*) begin
    rr_mucb_buf_rdata[gidx][0] = w_mucb_buf_rdata[gidx]  ;
end
if(DLY_WGT_RD>1) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_mucb_buf_rden[gidx][i]   <=  rr_mucb_buf_rden[gidx][i-1]   ;
        if(rr_mucb_buf_rden[gidx][i-1]) begin
            rr_mucb_buf_rdata[gidx][i]  <=  rr_mucb_buf_rdata[gidx][i-1]  ;
        end
    end
end
end//if(DLY_WGT_RD>1)
end
endgenerate
`endif// DLFE_MU_PC_DISABLE

reg [01-1:0]        r_mux_bfw_mat_en    [NUM_I_CHAIN*NUM_ANT-1:0]    ;
reg [2*BW_WGT-1:0]  r_mux_bfw_mat       [NUM_I_CHAIN*NUM_ANT-1:0]    ;
generate for(gidx=0;gidx<NUM_I_CHAIN*NUM_ANT;gidx=gidx+1) begin : g00_3_mux_bfw_mat
if(NUM_CC>1) begin
always@(posedge i_clk) begin
    if(rr_bfcb_buf_en[gidx]|rr_bfcb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]) begin
        if(i_din_cc_id[((01)*((gidx/NUM_ANT)+1)-1)-:(01)]==1'd0) begin
            r_mux_bfw_mat_en[gidx]   <= rr_bfcb_buf_en[gidx]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_bfcb_buf_rdata[gidx][DLY_WGT_RD]   ;  
        end
        else begin
            r_mux_bfw_mat_en[gidx]   <= rr_bfcb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_bfcb_buf_rdata[gidx+NUM_I_CHAIN*NUM_ANT][DLY_WGT_RD]   ;  
        end
    end
    else if(rr_sucb_buf_en[gidx]|rr_sucb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]) begin
        if(i_din_cc_id[((01)*((gidx/NUM_ANT)+1)-1)-:(01)]==1'd0) begin
            r_mux_bfw_mat_en[gidx]   <= rr_sucb_buf_en[gidx]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_sucb_buf_rdata[gidx][DLY_WGT_RD]   ;  
        end
        else begin
            r_mux_bfw_mat_en[gidx]   <= rr_sucb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_sucb_buf_rdata[gidx+NUM_I_CHAIN*NUM_ANT][DLY_WGT_RD]   ;  
        end
    end
    else if(rr_mucb_buf_en[gidx]|rr_mucb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]) begin
        if(i_din_cc_id[((01)*((gidx/NUM_ANT)+1)-1)-:(01)]==1'd0) begin
            r_mux_bfw_mat_en[gidx]   <= rr_mucb_buf_en[gidx]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_mucb_buf_rdata[gidx][DLY_WGT_RD]   ;  
        end
        else begin
            r_mux_bfw_mat_en[gidx]   <= rr_mucb_buf_en[gidx+NUM_I_CHAIN*NUM_ANT]    ; 
            r_mux_bfw_mat   [gidx]   <= rr_mucb_buf_rdata[gidx+NUM_I_CHAIN*NUM_ANT][DLY_WGT_RD]   ;  
        end
    end
    else begin
        r_mux_bfw_mat_en[gidx]   <=  1'd0 ;  
    end
end
end//(NUM_CC>1)
else begin//(NUM_CC>1)
always@(posedge i_clk) begin
    if(rr_bfcb_buf_en[gidx]) begin
        r_mux_bfw_mat_en[gidx]   <= rr_bfcb_buf_en[gidx]    ; 
        r_mux_bfw_mat   [gidx]   <= rr_bfcb_buf_rdata[gidx][DLY_WGT_RD]   ;  
    end
    else if(rr_sucb_buf_en[gidx]) begin
        r_mux_bfw_mat_en[gidx]   <= rr_sucb_buf_en[gidx]    ; 
        r_mux_bfw_mat   [gidx]   <= rr_sucb_buf_rdata[gidx][DLY_WGT_RD]   ;  
    end
    else if(rr_mucb_buf_en[gidx]) begin
        r_mux_bfw_mat_en[gidx]   <= rr_mucb_buf_en[gidx]    ; 
        r_mux_bfw_mat   [gidx]   <= rr_mucb_buf_rdata[gidx][DLY_WGT_RD]   ;  
    end
    else begin
        r_mux_bfw_mat_en[gidx]   <=  1'd0 ;  
    end
end
end//(NUM_CC>1)
end
endgenerate

reg [01-1:0]    r_bfcb_cpu_rd_valid  [NUM_CC-1:0]    ;
reg [32-1:0]    r_bfcb_cpu_rdata     [NUM_CC-1:0]    ;
reg [01-1:0]    r_sucb_cpu_rd_valid  [NUM_CC-1:0]    ;
reg [32-1:0]    r_sucb_cpu_rdata     [NUM_CC-1:0]    ;
reg [01-1:0]    r_mucb_cpu_rd_valid  [NUM_CC-1:0]    ;
reg [32-1:0]    r_mucb_cpu_rdata     [NUM_CC-1:0]    ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_4_cb_cpu_rd //Multiplexing Stage depends on NUM_ANT
always@(posedge i_clk) begin
    if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
    end
`ifdef DLFE_ANT_PORT_8            
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
    end
    else if(rr_bfcb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD]) begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  rr_bfcb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
        r_bfcb_cpu_rdata     [gidx]   <=  rr_bfcb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
    end
`endif//DLFE_ANT_PORT_8            
    else begin
        r_bfcb_cpu_rd_valid  [gidx]   <=  1'd0 ;
    end
end
`ifndef DLFE_SU_PC_DISABLE
always@(posedge i_clk) begin
    if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD]) begin
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
    end                                                                                                
`ifdef DLFE_ANT_PORT_8            
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_sucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD]) begin                                       
        r_sucb_cpu_rd_valid  [gidx]   <=  rr_sucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
        r_sucb_cpu_rdata     [gidx]   <=  rr_sucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
    end
`endif//DLFE_ANT_PORT_8            
    else begin
        r_sucb_cpu_rd_valid  [gidx]   <=  1'd0 ;
    end
end
`endif// DLFE_SU_PC_DISABLE
`ifndef DLFE_MU_PC_DISABLE
always@(posedge i_clk) begin
    if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD]) begin
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+00][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+01][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+02][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+03][DLY_WGT_RD] ;
    end                                                                                                
`ifdef DLFE_ANT_PORT_8            
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+04][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+05][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+06][DLY_WGT_RD] ;
    end                                                                                                
    else if(rr_mucb_buf_rden[NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD]) begin                                       
        r_mucb_cpu_rd_valid  [gidx]   <=  rr_mucb_buf_rden  [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
        r_mucb_cpu_rdata     [gidx]   <=  rr_mucb_buf_rdata [NUM_I_CHAIN*NUM_ANT*gidx+07][DLY_WGT_RD] ;
    end
`endif//DLFE_ANT_PORT_8            
    else begin
        r_mucb_cpu_rd_valid  [gidx]   <=  1'd0 ;
    end
end
`endif// DLFE_MU_PC_DISABLE
always@(posedge i_clk) begin
    if(r_bfcb_cpu_rd_valid[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  r_bfcb_cpu_rd_valid  [gidx] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},r_bfcb_cpu_rdata [gidx][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},r_bfcb_cpu_rdata [gidx][(1*BW_WGT-1)-:BW_WGT]} ;
    end
`ifndef DLFE_SU_PC_DISABLE
    else if(r_sucb_cpu_rd_valid[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  r_sucb_cpu_rd_valid  [gidx] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},r_sucb_cpu_rdata [gidx][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},r_sucb_cpu_rdata [gidx][(1*BW_WGT-1)-:BW_WGT]} ;
    end
`endif //DLFE_SU_PC_DISABLE
`ifndef DLFE_MU_PC_DISABLE
    else if(r_mucb_cpu_rd_valid[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  r_mucb_cpu_rd_valid  [gidx] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},r_mucb_cpu_rdata [gidx][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},r_mucb_cpu_rdata [gidx][(1*BW_WGT-1)-:BW_WGT]} ;
    end
`endif //DLFE_MU_PC_DISABLE
    else begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  1'd0 ;
    end
end
end
endgenerate

generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g01_din_chain
always@(*) begin
    r_en[gidx][0]       = i_din_en      [((01)*(gidx+1)-1)-:(01)]           ;
    r_iq[gidx][0]       = i_din_iq      [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IQ;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1] ;
        if(r_en[gidx][i-1]) begin
            r_iq      [gidx][i] <= r_iq     [gidx][i-1] ;
        end
    end
end
end
endgenerate

reg [01-1:0]    r_nlayer_en [DLY_NLAYER:0]  ;
reg [05-1:0]    r_nlayer    [DLY_NLAYER:0]  ;
always@(*) begin
    r_nlayer_en [0] =   |i_din_en       ;
    r_nlayer    [0] =   i_din_nlayer    ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_NLAYER;i=i+1) begin
        r_nlayer_en[i]  <= r_nlayer_en[i-1] ;
        if(r_nlayer_en[i-1]) begin
            r_nlayer[i]   <=  r_nlayer[i-1] ;
        end
    end
end
reg [BW_ISQRT-1:0]    r_isqrt ;
always@(posedge i_clk) begin
    if(r_nlayer_en[DLY_NLAYER]) begin
        case(r_nlayer[DLY_NLAYER]) 
            5'd1    :   r_isqrt <= 'd4096  ;
            5'd2    :   r_isqrt <= 'd2896  ;
            5'd3    :   r_isqrt <= 'd2365  ;
            5'd4    :   r_isqrt <= 'd2048  ;
            5'd5    :   r_isqrt <= 'd1832  ;
            5'd6    :   r_isqrt <= 'd1672  ;
            5'd7    :   r_isqrt <= 'd1548  ;
            5'd8    :   r_isqrt <= 'd1448  ;
            default :   r_isqrt <= NUM_LAYER==4 ? 'd2048 : 'd1448   ;
        endcase
    end
end

wire [NUM_I_CHAIN*NUM_ANT-1:0]  w_bfw_mult_en    ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_i    [NUM_I_CHAIN*NUM_ANT-1:0]   ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_q    [NUM_I_CHAIN*NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_I_CHAIN*NUM_ANT;gidx=gidx+1) begin : g02_bfw_mult_chain
ylib_cmult #(
    .AWIDTH     (   DI_BW       )
   ,.BWIDTH     (   BW_WGT      ))
u01_bfw_mult
(
    .clk    (   i_clk                                               )
   ,.en     (   r_en[gidx/NUM_ANT][DLY_IQ]&r_mux_bfw_mat_en[gidx]   )
   ,.ar     (   r_iq[gidx/NUM_ANT][DLY_IQ][(DI_BW*2-1)-:DI_BW]      )
   ,.ai     (   r_iq[gidx/NUM_ANT][DLY_IQ][(DI_BW*1-1)-:DI_BW]      )
   ,.br     (   r_mux_bfw_mat[gidx][(BW_WGT*2-1)-:BW_WGT]           )
   ,.bi     (   r_mux_bfw_mat[gidx][(BW_WGT*1-1)-:BW_WGT]           )
   ,.pen    (   w_bfw_mult_en[gidx]                                 )
   ,.pr     (   w_bfw_mult_i[gidx]                                  )
   ,.pi     (   w_bfw_mult_q[gidx]                                  )
);
end
endgenerate

wire [0:0]                                              w_mem_en            [NUM_ANT-1:0]   ;
wire [0:0]                                              w_mem_wr_en         [NUM_ANT-1:0]   ;
reg  [$clog2(MAX_NIFFT)-1:0]                            r_mem_addr          [NUM_ANT-1:0]   ;
wire [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             w_mem_dout_i        [NUM_ANT-1:0]   ;
wire [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             w_mem_dout_q        [NUM_ANT-1:0]   ;
reg  [0:0]                                              r_mem_rd_en         [NUM_ANT-1:0]   ;
reg  [0:0]                                              rr_mem_rd_en        [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             rr_mem_dout_i       [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             rr_mem_dout_q       [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           r_bf_mat_mult_en    [NUM_ANT-1:0][DLY_BUF_SYNC:0]  ;
reg  [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             r_bf_mat_mult_i     [NUM_ANT-1:0][DLY_BUF_SYNC:0]  ;
reg  [DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1:0]             r_bf_mat_mult_q     [NUM_ANT-1:0][DLY_BUF_SYNC:0]  ;
reg  [01-1:0]                                           rr_bf_mat_mult_en   [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               rr_bf_mat_mult_i    [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               rr_bf_mat_mult_q    [NUM_ANT-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER))-1:0]           rr_bf_mat_mult_iq   [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           r_bf_mat_mult_s_en  [NUM_ANT-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  r_bf_mat_mult_s_iq  [NUM_ANT-1:0]   ;
wire [NUM_ANT-1:0]                                      w_bf_mat_mult_sr_en                 ;
wire [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  w_bf_mat_mult_sr_iq [NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g02_0_bfw_chain_buf
always@(posedge i_clk) begin 
    r_bf_mat_mult_en[gidx][0] <= w_bfw_mult_en[gidx] ;
    if(w_bfw_mult_en[gidx]) begin
        r_bf_mat_mult_i[gidx][0]    <= (NUM_I_CHAIN==2) ? 
                                     $signed({{{(DI_BW+BW_WGT+$clog2(NUM_I_CHAIN))-(DI_BW+BW_WGT+1)}{w_bfw_mult_i[gidx+NUM_ANT*0][(DI_BW+BW_WGT+1)-1]}},w_bfw_mult_i[gidx+NUM_ANT*0]})
                                    +$signed({{{(DI_BW+BW_WGT+$clog2(NUM_I_CHAIN))-(DI_BW+BW_WGT+1)}{w_bfw_mult_i[gidx+NUM_ANT*1][(DI_BW+BW_WGT+1)-1]}},w_bfw_mult_i[gidx+NUM_ANT*1]})
                                    : {{DI_BW+BW_WGT+1+$clog2(NUM_ANT)}{1'd0}} ;    
        r_bf_mat_mult_q[gidx][0]    <= (NUM_I_CHAIN==2) ? 
                                     $signed({{{(DI_BW+BW_WGT+$clog2(NUM_I_CHAIN))-(DI_BW+BW_WGT+1)}{w_bfw_mult_q[gidx+NUM_ANT*0][(DI_BW+BW_WGT+1)-1]}},w_bfw_mult_q[gidx+NUM_ANT*0]})
                                    +$signed({{{(DI_BW+BW_WGT+$clog2(NUM_I_CHAIN))-(DI_BW+BW_WGT+1)}{w_bfw_mult_q[gidx+NUM_ANT*1][(DI_BW+BW_WGT+1)-1]}},w_bfw_mult_q[gidx+NUM_ANT*1]})
                                    : {{DI_BW+BW_WGT+1+$clog2(NUM_ANT)}{1'd0}} ;    
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_BUF_SYNC;i=i+1) begin
        r_bf_mat_mult_en[gidx][i]   <=  r_bf_mat_mult_en[gidx][i-1]   ;
        if(r_bf_mat_mult_en[gidx][i-1]) begin
            r_bf_mat_mult_i[gidx][i]  <=  r_bf_mat_mult_i[gidx][i-1]  ;
            r_bf_mat_mult_q[gidx][i]  <=  r_bf_mat_mult_q[gidx][i-1]  ;
        end
    end
end
always@(posedge i_clk) begin 
    if(w_bfw_mult_en[gidx]&~r_bf_mat_mult_en[gidx][0]) begin
        r_mem_addr[gidx]    <=  {{$clog2(MAX_NIFFT)}{1'd0}} ;
    end
    else if(r_bf_mat_mult_en[gidx][0]) begin
        r_mem_addr[gidx]    <=  r_mem_addr[gidx]+1'd1 ;
    end
end
assign  w_mem_en    [gidx]  =  r_bf_mat_mult_en[gidx][0] ; 
assign  w_mem_wr_en [gidx]  =  r_bf_mat_mult_en[gidx][0]&(!i_din_lyr_id[0])    ; 
ylib_rams_sp_wf #(
     .WIDTH     (   2*(DI_BW+BW_WGT+$clog2(NUM_I_CHAIN))    )
    ,.DEPTH     (   MAX_NIFFT                               )
    ,.VENDOR    (   VENDOR                                  ))
u01_00_bfw_buf
(
     .clk       (i_clk                                              )     
    ,.en        (w_mem_en[gidx]                                     ) 
    ,.we        (w_mem_wr_en[gidx]                                  ) 
    ,.addr      (r_mem_addr[gidx]                                   ) 
    ,.di        ({r_bf_mat_mult_i[gidx][0],r_bf_mat_mult_q[gidx][0]}) 
    ,.dout      ({w_mem_dout_i[gidx],w_mem_dout_q[gidx]}            ) 
);
always@(posedge i_clk) begin
    r_mem_rd_en[gidx] <= r_bf_mat_mult_en[gidx][0]&(i_din_lyr_id[0]) ;
    rr_mem_rd_en[gidx] <= r_mem_rd_en[gidx] ;
    if(r_mem_rd_en[gidx]) begin
        rr_mem_dout_i[gidx] <= w_mem_dout_i[gidx] ;
        rr_mem_dout_q[gidx] <= w_mem_dout_q[gidx] ;
    end
end
always@(posedge i_clk) begin 
    rr_bf_mat_mult_en[gidx] <= rr_mem_rd_en[gidx] ;
    if(rr_mem_rd_en[gidx]) begin
        rr_bf_mat_mult_i[gidx]  <=  (NUM_I_CHAIN==2) ? 
                                     $signed({{{$clog2(NUM_LAYER)-$clog2(NUM_I_CHAIN)}{r_bf_mat_mult_i[gidx][DLY_BUF_SYNC][DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1]}},r_bf_mat_mult_i[gidx][DLY_BUF_SYNC]})
                                    +$signed({{{$clog2(NUM_LAYER)-$clog2(NUM_I_CHAIN)}{rr_mem_dout_i[gidx][DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1]}},rr_mem_dout_i[gidx]})
                                   : {{DI_BW+BW_WGT+$clog2(NUM_LAYER)}{1'd0}} ;    
        rr_bf_mat_mult_q[gidx]  <=  (NUM_I_CHAIN==2) ? 
                                     $signed({{{$clog2(NUM_LAYER)-$clog2(NUM_I_CHAIN)}{r_bf_mat_mult_q[gidx][DLY_BUF_SYNC][DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1]}},r_bf_mat_mult_q[gidx][DLY_BUF_SYNC]})
                                    +$signed({{{$clog2(NUM_LAYER)-$clog2(NUM_I_CHAIN)}{rr_mem_dout_q[gidx][DI_BW+BW_WGT+$clog2(NUM_I_CHAIN)-1]}},rr_mem_dout_q[gidx]})
                                   : {{DI_BW+BW_WGT+$clog2(NUM_LAYER)}{1'd0}} ;    
    end
end
always@(*) begin
    rr_bf_mat_mult_iq[gidx] = {rr_bf_mat_mult_i[gidx],rr_bf_mat_mult_q[gidx]} ;
end

always@(posedge i_clk) begin
    r_bf_mat_mult_s_en[gidx] <=  rr_bf_mat_mult_en[gidx]  ;
    if(rr_bf_mat_mult_en[gidx]) begin
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*2-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)]   <=  $signed(rr_bf_mat_mult_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER))*2-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER))]) * $signed({1'd0,r_isqrt})  ;
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*1-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)]   <=  $signed(rr_bf_mat_mult_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER))*1-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER))]) * $signed({1'd0,r_isqrt})  ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                                       )
 ,.SHIFTD_BW    (   5                                       )
 ,.IO_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT ))
u02_bfw_shiftd_rnd 
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   r_bf_mat_mult_s_en[gidx]    )
    ,.i_in      (   r_bf_mat_mult_s_iq[gidx]    )
    ,.i_shiftd  (   5'd20                       )
    ,.o_out_en  (   w_bf_mat_mult_sr_en[gidx]   )
    ,.o_out     (   w_bf_mat_mult_sr_iq[gidx]   )
);
ylib_sat #(
  .NUM_STREAM   (   2                                       )
 ,.DI_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT )
 ,.DO_BW        (   DO_BW                                   ))
u03_bfw_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_bf_mat_mult_sr_en[gidx]                       )
    ,.i_in      (   w_bf_mat_mult_sr_iq[gidx]                       )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_bf_mat_mult_sr_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((01)*(gidx+1)-1)-:(01)] <= i_din_cc_id [((01)*(gidx%NUM_I_CHAIN+1)-1)-:(01)] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= gidx&{{$clog2(NUM_ANT)}{1'b1}} ;
    end
end
end
endgenerate

ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_0_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_frame_sync ),.o_out(o_dout_frame_sync ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_1_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_subfrm_sync),.o_out(o_dout_subfrm_sync));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_2_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_slot_sync  ),.o_out(o_dout_slot_sync  ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_3_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_symbol_sync),.o_out(o_dout_symbol_sync));

always@(posedge i_clk) begin
    if(i_din_frame_sync||(|w_bf_mat_mult_sr_en&~|o_dout_en)) begin
        o_dout_mu           <=  i_din_mu            ;
        o_dout_fft_size     <=  i_din_fft_size      ;
    end
end

//reg [NUM_O_CHAIN-1:0]                                   r_bf_mat_mult_en                            ;
//reg [2*(DI_BW+BW_WGT+1+$clog2(NUM_ANT))-1:0]            r_bf_mat_mult_iq        [NUM_O_CHAIN-1:0]   ;
//reg [NUM_O_CHAIN-1:0]                                   rr_bf_mat_mult_en                           ;
//reg [2*(DI_BW+BW_WGT+1+$clog2(NUM_ANT))-1:0]            rr_bf_mat_mult_iq       [NUM_O_CHAIN-1:0]   ;
//reg [NUM_O_CHAIN-1:0]                                   r_bf_mat_mult_s_en                          ;
//reg [2*(DI_BW+BW_WGT+1+$clog2(NUM_ANT)+BW_ISQRT)-1:0]   r_bf_mat_mult_s_iq      [NUM_O_CHAIN-1:0]   ;
//wire[NUM_O_CHAIN-1:0]                                   w_bf_mat_mult_sr_en                         ;
//wire[2*(DI_BW+BW_WGT+1+$clog2(NUM_ANT)+BW_ISQRT)-1:0]   w_bf_mat_mult_sr_iq     [NUM_O_CHAIN-1:0]   ;
//generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g02_bf_mat_mult_chain
//always@(posedge i_clk) begin 
//    r_bf_mat_mult_en[gidx] <= w_bfw_mult_en[gidx] ;
//    if(w_bfw_mult_en[gidx]) begin
//        r_bf_mat_mult_iq[gidx][((DI_BW+BW_WGT+1+$clog2(NUM_ANT))*2-1)-:(DI_BW+BW_WGT+1+$clog2(NUM_ANT))]  <= (NUM_LAYER==4) ? 
//                                                                                                             $signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                           : (NUM_LAYER==8) ?
//                                                                                                             $signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*4][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*4][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*5][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*5][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*6][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*6][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*7][((DI_BW+BW_WGT+1)*2-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*7][((DI_BW+BW_WGT+1)*2-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                           : {{DI_BW+BW_WGT+1+$clog2(NUM_ANT)}{1'd0}} ;    
//        r_bf_mat_mult_iq[gidx][((DI_BW+BW_WGT+1+$clog2(NUM_ANT))*1-1)-:(DI_BW+BW_WGT+1+$clog2(NUM_ANT))]  <= (NUM_LAYER==4) ? 
//                                                                                                             $signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                           : (NUM_LAYER==8) ?
//                                                                                                             $signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*0][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*1][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*2][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*3][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*4][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*4][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*5][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*5][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*6][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*6][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                            +$signed({{{$clog2(NUM_ANT)}{w_bfw_mult_iq[gidx+NUM_ANT*7][((DI_BW+BW_WGT+1)*1-1)]}},w_bfw_mult_iq[gidx+NUM_ANT*7][((DI_BW+BW_WGT+1)*1-1)-:(DI_BW+BW_WGT+1)]})
//                                                                                                           : {{DI_BW+BW_WGT+1+$clog2(NUM_ANT)}{1'd0}} ;    
//    end
//end
//always@(posedge i_clk) begin
//    rr_bf_mat_mult_en[gidx] <=  r_bf_mat_mult_en[gidx]  ;
//    if(r_bf_mat_mult_en[gidx]) begin
//        rr_bf_mat_mult_iq[gidx] <=  r_bf_mat_mult_iq[gidx]  ;
//    end
//end
`else //DLFE_ORAN_DISABLE
reg [01-1:0] r_cpu_wren   ;
reg [01-1:0] r_cpu_rden   ;
reg [20-1:0] r_cpu_addr   ;
reg [32-1:0] r_cpu_wdata  ;
always@(*) begin
    r_cpu_wren   =  i_cpu_wren   [CC_REF]  ;
    r_cpu_rden   =  i_cpu_rden   [CC_REF]  ;
    r_cpu_addr   =  i_cpu_addr   [((20)*(CC_REF+1)-1)-:(20)] ;
    r_cpu_wdata  =  i_cpu_wdata  [((32)*(CC_REF+1)-1)-:(32)] ;
end
reg [01*NUM_LAYER_LANE-1:0] r_en [NUM_LANE_CC-1:0][DLY_IN:0] ;
reg [2*DI_BW-1:0]           r_iq [NUM_LANE_CC-1:0][DLY_IN:0] ;   
generate for(gidx=0;gidx<NUM_LANE_CC;gidx=gidx+1) begin : g00_din_lane
always@(*) begin
    r_en[gidx][0] = |i_cals_cal_en ? {{NUM_LAYER_LANE}{|i_cals_pat_en}} : i_din_en [((01*NUM_LAYER_LANE)*(gidx+1)-1)-:(01*NUM_LAYER_LANE)] ;
    if(gidx==0) begin
        r_iq[gidx][0] = |i_cals_cal_en ?  i_cals_pat_iq : i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
    end
    else begin
        r_iq[gidx][0] = |i_cals_cal_en ? {{2*DI_BW}{1'b0}} : i_din_iq [((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1] ;
        if(r_en[gidx][i-1]) begin
            r_iq[gidx][i] <= r_iq[gidx][i-1] ;
        end
    end
end
end
endgenerate
reg [$clog2(NUM_LAYER)-1:0] r_lyr_buf_sel   ;
reg [$clog2(NUM_ANT  )-1:0] r_ant_buf_sel   ;
reg [$clog2(NUM_LAYER)-1:0] r_rank_buf_sel  ;
always@(*) begin
    r_lyr_buf_sel   = i_dlfe_par_3c00 [(($clog2(NUM_LAYER))*(CC_REF+1)-1)-:($clog2(NUM_LAYER))] ;
    r_ant_buf_sel   = i_dlfe_par_3c04 [(($clog2(NUM_ANT  ))*(CC_REF+1)-1)-:($clog2(NUM_ANT  ))] ;
    r_rank_buf_sel  = i_dlfe_par_3c08 [(($clog2(NUM_LAYER))*(CC_REF+1)-1)-:($clog2(NUM_LAYER))] ;
end
reg [12-1:0]    r_cb_idx    [DLY_IN:0]  ;   
reg [05-1:0]    r_nmusul    [DLY_IN:0]  ;   
reg [06-1:0]    r_re_map    [DLY_IN:0]  ;   
always@(*) begin
    r_cb_idx[0] = i_din_cb_idx ;
    r_nmusul[0] = i_din_nmusul ;
    r_re_map[0] = i_din_re_map ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_IN;i=i+1) begin
        if(r_en[LANE_REF][i-1]) begin
            r_cb_idx[i] <= r_cb_idx[i-1] ;
            r_nmusul[i] <= r_nmusul[i-1] ;
            r_re_map[i] <= r_re_map[i-1] ;
        end
    end
end
reg [NUM_ANT-1:0] r_cals_pat_en ;
always@(posedge i_clk) begin
    if(r_en[LANE_REF][DLY_IN-1]&~r_en[LANE_REF][DLY_IN]) begin
        r_cals_pat_en <= |i_cals_cal_en ? i_cals_pat_en : {{NUM_ANT}{1'b0}} ;
    end
end
reg [2*BW_WGT-1:0]  r_cpu_wgt   ;
always@(*) begin
    r_cpu_wgt = {r_cpu_wdata[16+BW_WGT-1:16],r_cpu_wdata[00+BW_WGT-1:00]};
end
`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_en     ;
(* keep = "true" *) reg [NUM_ANT-1:0]   r_bfcb0_buf_wren   ;
(* keep = "true" *) reg [20-1:0]        r_bfcb0_buf_addr   ;
(* keep = "true" *) reg [2*BW_WGT-1:0]  r_bfcb0_buf_wdata  ;
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_rden   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb0_buf_null   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb0_buf_en     ;
reg [NUM_ANT-1:0]   r_bfcb0_buf_wren   ;
reg [20-1:0]        r_bfcb0_buf_addr   ;
reg [2*BW_WGT-1:0]  r_bfcb0_buf_wdata  ;
reg [1-1:0]         r_bfcb0_buf_rden   ;
reg [1-1:0]         r_bfcb0_buf_null   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb0_buf_rdata                 ;
reg [2*BW_WGT-1:0]              rr_bfcb0_buf_rdata [NUM_ANT-1:0]  ;
reg [1-1:0]                     rr_bfcb0_buf_rden  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb0_buf_en                   ;
reg [1-1:0]                     rr_bfcb0_cpu_rden  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb0_cpu_en                   ;
reg [1-1:0]                     rr_bfcb0_buf_zpen  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb0_buf_null                 ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb0_buf_byte_wren_byte ;
always@(posedge i_clk) begin : l00_bfcb_mem_ctrl
    if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR)) begin
        r_bfcb0_buf_en      <=  1'b0 ;
        r_bfcb0_buf_wdata   <=  r_cpu_wgt ;
        case({r_rank_buf_sel,r_lyr_buf_sel}) 
            {IDX_RANK01,IDX_LAYER00} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R1_L0_START_ADDR ; end 
            {IDX_RANK02,IDX_LAYER00} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R2_L0_START_ADDR ; end 
            {IDX_RANK03,IDX_LAYER00} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R3_L0_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER00} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R4_L0_START_ADDR ; end 
            {IDX_RANK02,IDX_LAYER01} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R2_L1_START_ADDR ; end 
            {IDX_RANK03,IDX_LAYER01} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R3_L1_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER01} : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB0_R4_L1_START_ADDR ; end 
            default                  : begin r_bfcb0_buf_wren <=  {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb0_buf_rden <= 1'b0 ; end 
        endcase
    end
    else if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        r_bfcb0_buf_en      <=  1'b0 ;
        r_bfcb0_buf_wdata   <=  r_cpu_wgt ;
        case(r_lyr_buf_sel) 
            IDX_LAYER00 : begin r_bfcb0_buf_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB0_PD_L0_START_ADDR ; end 
            IDX_LAYER01 : begin r_bfcb0_buf_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb0_buf_rden <= r_cpu_rden ; r_bfcb0_buf_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB0_PD_L1_START_ADDR ; end 
            default     : begin r_bfcb0_buf_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb0_buf_rden <= 1'b0 ; end
        endcase
    end
    else if(|r_en[LANE_REF][0]) begin
        r_bfcb0_buf_en      <=  1'b1 ;
        r_bfcb0_buf_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb0_buf_rden    <=  1'b0 ;
        if(r_re_map[0]==IDX_REMAP_SUCB) begin
            if(r_en[LANE_REF][0][0]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R1  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R1_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R2  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R2_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R3_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R4_L0_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb0_buf_null <= 1'b1 ; end 
                endcase
            end
            else if(r_en[LANE_REF][0][1]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R2  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R2_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R3_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb0_buf_null <= 1'b0 ; r_bfcb0_buf_addr <= BFCB0_R4_L1_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb0_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]>IDX_REMAP_SUCB) begin
            r_bfcb0_buf_null    <=   1'd0 ;
            if(r_en[LANE_REF][0][0]) begin
                r_bfcb0_buf_addr    <=  BFCB0_PD_L0_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else if(r_en[LANE_REF][0][1]) begin
                r_bfcb0_buf_addr    <=  BFCB0_PD_L1_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
    end
    else begin
        r_bfcb0_buf_en      <=  1'b0 ;
        r_bfcb0_buf_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb0_buf_rden    <=  1'b0 ;
        r_bfcb0_buf_null    <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb0_buf_byte_wren_byte[i] = r_bfcb0_buf_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb0_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_sdpram #(
    .ADDR_WIDTH_A            ($clog2(SIZE_MAX_BFMEM)        ) 
   ,.ADDR_WIDTH_B            ($clog2(SIZE_MAX_BFMEM)        ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(SIZE_MAX_BFMEM))   ) 
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_B            ("write_first"                 )  
)
u00_0_bfcb_mem (
    .dbiterrb           (                                                                                   )
   ,.doutb              (   w_bfcb0_buf_rdata                                                               )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb0_buf_addr  [$clog2(SIZE_MAX_BFMEM)-1:0]                                  )
   ,.addrb              (   r_bfcb0_buf_addr  [$clog2(SIZE_MAX_BFMEM)-1:0]                                  )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_bfcb0_buf_wdata }}}     )
   ,.ena                (  |r_bfcb0_buf_byte_wren_byte                                                      )
   ,.enb                (   r_bfcb0_buf_en | r_bfcb0_buf_rden                                               )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb0_buf_byte_wren_byte                                                      )
);
always@(posedge i_clk) begin
    rr_bfcb0_buf_en     <= r_bfcb0_buf_en   ;
    rr_bfcb0_buf_null   <= r_bfcb0_buf_null ;
    rr_bfcb0_cpu_en     <= r_bfcb0_buf_rden ;
end
always@(*) begin
    rr_bfcb0_buf_rden [0] = rr_bfcb0_buf_en     ;
    rr_bfcb0_buf_zpen [0] = rr_bfcb0_buf_null   ;
    rr_bfcb0_cpu_rden [0] = rr_bfcb0_cpu_en     ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb0_buf_rdata[i] = w_bfcb0_buf_rdata [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb0_buf_rden[i] <= rr_bfcb0_buf_rden[i-1] ;
        rr_bfcb0_buf_zpen[i] <= rr_bfcb0_buf_zpen[i-1] ;
        rr_bfcb0_cpu_rden[i] <= rr_bfcb0_cpu_rden[i-1] ;
    end
end

`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_en     ;
(* keep = "true" *) reg [NUM_ANT-1:0]   r_bfcb1_buf_wren   ;
(* keep = "true" *) reg [20-1:0]        r_bfcb1_buf_addr   ;
(* keep = "true" *) reg [2*BW_WGT-1:0]  r_bfcb1_buf_wdata  ;
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_rden   ;
(* keep = "true" *) reg [01-1:0]        r_bfcb1_buf_null   ;
`else// DLFE_XILINX_VERSAL
reg [1-1:0]         r_bfcb1_buf_en     ;
reg [NUM_ANT-1:0]   r_bfcb1_buf_wren   ;
reg [20-1:0]        r_bfcb1_buf_addr   ;
reg [2*BW_WGT-1:0]  r_bfcb1_buf_wdata  ;
reg [1-1:0]         r_bfcb1_buf_rden   ;
reg [1-1:0]         r_bfcb1_buf_null   ;
`endif// DLFE_XILINX_VERSAL
wire[BW_BFCB_MEM_DATA-1:0]      w_bfcb1_buf_rdata                 ;
reg [2*BW_WGT-1:0]              rr_bfcb1_buf_rdata [NUM_ANT-1:0]  ;
reg [1-1:0]                     rr_bfcb1_buf_rden  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb1_buf_en                   ;
reg [1-1:0]                     rr_bfcb1_cpu_rden  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb1_cpu_en                   ;
reg [1-1:0]                     rr_bfcb1_buf_zpen  [DLY_WGT_RD:0] ;
reg [1-1:0]                     rr_bfcb1_buf_null                 ;
reg [BW_BFCB_MEM_DATA/8-1:0]    r_bfcb1_buf_byte_wren_byte ;
always@(posedge i_clk) begin : l01_bfcb_mem_ctrl
    if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=SUCB_START_ADDR&&r_cpu_addr<SUCB_END_ADDR)) begin
        r_bfcb1_buf_en      <=  1'b0 ;
        r_bfcb1_buf_wdata   <=  r_cpu_wgt ;
        case({r_rank_buf_sel,r_lyr_buf_sel}) 
            {IDX_RANK03,IDX_LAYER02} : begin r_bfcb1_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_rden <= r_cpu_rden ; r_bfcb1_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R3_L2_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER02} : begin r_bfcb1_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_rden <= r_cpu_rden ; r_bfcb1_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R4_L2_START_ADDR ; end 
            {IDX_RANK04,IDX_LAYER03} : begin r_bfcb1_buf_wren <=  {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_rden <= r_cpu_rden ; r_bfcb1_buf_addr <= ((r_cpu_addr-SUCB_START_ADDR)>>2)+BFCB1_R4_L3_START_ADDR ; end 
            default                  : begin r_bfcb1_buf_wren <=  {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb1_buf_rden <= 1'b0 ; end 
        endcase
    end
    else if((r_cpu_wren||r_cpu_rden)&&(r_cpu_addr>=PREDEFW_START_ADDR&&r_cpu_addr<PREDEFW_END_ADDR)) begin
        r_bfcb1_buf_en      <=  1'b0 ;
        r_bfcb1_buf_wdata   <=  r_cpu_wgt ;
        case(r_lyr_buf_sel) 
            IDX_LAYER02 : begin r_bfcb1_buf_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_rden <= r_cpu_rden ; r_bfcb1_buf_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB1_PD_L2_START_ADDR ; end 
            IDX_LAYER03 : begin r_bfcb1_buf_wren <= {{{NUM_ANT-1}{1'b0}},r_cpu_wren}<<r_ant_buf_sel ; r_bfcb1_buf_rden <= r_cpu_rden ; r_bfcb1_buf_addr <=  ((r_cpu_addr-PREDEFW_START_ADDR)>>2)+BFCB1_PD_L3_START_ADDR ; end 
            default     : begin r_bfcb1_buf_wren <= {{{NUM_ANT-1}{1'b0}},1'b0} ; r_bfcb1_buf_rden <= 1'b0 ; end
        endcase
    end
    else if(|r_en[LANE_REF][0]) begin
        r_bfcb1_buf_en      <=  1'b1 ;
        r_bfcb1_buf_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb1_buf_rden    <=  1'b0 ;
        if(r_re_map[0]==IDX_REMAP_SUCB) begin
            if(r_en[LANE_REF][0][0]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R3  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R3_L2_START_ADDR+{4'd0,r_cb_idx[0]} ; end  
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R4_L2_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb1_buf_null <= 1'b1 ; end
                endcase
            end
            else if(r_en[LANE_REF][0][1]) begin
                case(r_nmusul[0]) 
                    {5{1'b1}}&NUM_LAYER_R4  : begin r_bfcb1_buf_null <= 1'b0 ; r_bfcb1_buf_addr <= BFCB1_R4_L3_START_ADDR+{4'd0,r_cb_idx[0]} ; end
                    default                 : begin r_bfcb1_buf_null <= 1'b1 ; end
                endcase
            end
        end
        else if(r_re_map[0]>IDX_REMAP_SUCB) begin
            r_bfcb1_buf_null    <=  1'b0    ;
            if(r_en[LANE_REF][0][0]) begin
                r_bfcb1_buf_addr    <=  BFCB1_PD_L2_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
            else if(r_en[LANE_REF][0][1]) begin
                r_bfcb1_buf_addr    <=  BFCB1_PD_L3_START_ADDR+(r_re_map[0]-IDX_REMAP_WPREDEF)   ;
            end
        end
    end
    else begin
        r_bfcb1_buf_en      <=  1'b0 ;
        r_bfcb1_buf_wren    <=  {{{NUM_ANT-1}{1'b0}},1'b0} ;
        r_bfcb1_buf_rden    <=  1'b0 ;
        r_bfcb1_buf_null    <=  1'b0 ;
    end
end
always@(*) begin
    for(i=0;i<BW_BFCB_MEM_DATA/8;i=i+1) begin
        if(i<2*BW_WGT*NUM_ANT/8) begin
            r_bfcb1_buf_byte_wren_byte[i] = r_bfcb1_buf_wren[i/(2*BW_WGT/8)] ;
        end
        else begin
            r_bfcb1_buf_byte_wren_byte[i] = 1'b0 ;
        end
    end
end
xpm_memory_sdpram #(
    .ADDR_WIDTH_A            ($clog2(SIZE_MAX_BFMEM)        ) 
   ,.ADDR_WIDTH_B            ($clog2(SIZE_MAX_BFMEM)        ) 
   ,.AUTO_SLEEP_TIME         (0                             ) 
   ,.BYTE_WRITE_WIDTH_A      (8                             ) 
   ,.CASCADE_HEIGHT          (0                             ) 
   ,.CLOCKING_MODE           ("common_clock"                ) 
   ,.ECC_MODE                ("no_ecc"                      ) 
   ,.MEMORY_INIT_FILE        ("none"                        ) 
   ,.MEMORY_INIT_PARAM       ("0"                           ) 
   ,.MEMORY_OPTIMIZATION     ("true"                        ) 
   ,.MEMORY_PRIMITIVE        ("ultra"                       ) 
   ,.MEMORY_SIZE             (BW_BFCB_MEM_DATA*(2**$clog2(SIZE_MAX_BFMEM))   ) 
   ,.MESSAGE_CONTROL         (0                             ) 
   ,.READ_DATA_WIDTH_B       (BW_BFCB_MEM_DATA              ) 
   ,.READ_LATENCY_B          (3                             ) 
   ,.READ_RESET_VALUE_B      ("0"                           ) 
   ,.RST_MODE_A              ("SYNC"                        ) 
   ,.RST_MODE_B              ("SYNC"                        ) 
   ,.SIM_ASSERT_CHK          (0                             ) 
   ,.USE_EMBEDDED_CONSTRAINT (0                             ) 
   ,.USE_MEM_INIT            (1                             ) 
   ,.WAKEUP_TIME             ("disable_sleep"               ) 
   ,.WRITE_DATA_WIDTH_A      (BW_BFCB_MEM_DATA              ) 
   ,.WRITE_MODE_B            ("write_first"                 )  
)
u00_1_bfcb_mem (
    .dbiterrb           (                                                                                   )
   ,.doutb              (   w_bfcb1_buf_rdata                                                               )
   ,.sbiterrb           (                                                                                   )
   ,.addra              (   r_bfcb1_buf_addr  [$clog2(SIZE_MAX_BFMEM)-1:0]                                  )
   ,.addrb              (   r_bfcb1_buf_addr  [$clog2(SIZE_MAX_BFMEM)-1:0]                                  )
   ,.clka               (   i_clk                                                                           )
   ,.clkb               (   i_clk                                                                           )
   ,.dina               ( {{{BW_BFCB_MEM_DATA-2*BW_WGT*NUM_ANT}{1'b0}},{{NUM_ANT}{r_bfcb1_buf_wdata }}}     )
   ,.ena                (  |r_bfcb1_buf_byte_wren_byte                                                      )
   ,.enb                (   r_bfcb1_buf_en | r_bfcb1_buf_rden                                               )
   ,.injectdbiterra     (   1'b0                                                                            )
   ,.injectsbiterra     (   1'b0                                                                            )
   ,.regceb             (   1'b1                                                                            )
   ,.rstb               (   i_rst                                                                           )
   ,.sleep              (   1'b0                                                                            )
   ,.wea                (   r_bfcb1_buf_byte_wren_byte                                                      )
);
always@(posedge i_clk) begin
    rr_bfcb1_buf_en     <= r_bfcb1_buf_en   ;
    rr_bfcb1_buf_null   <= r_bfcb1_buf_null ;
    rr_bfcb1_cpu_en     <= r_bfcb1_buf_rden ;
end
always@(*) begin
    rr_bfcb1_buf_rden [0] = rr_bfcb1_buf_en     ;
    rr_bfcb1_buf_zpen [0] = rr_bfcb1_buf_null   ;
    rr_bfcb1_cpu_rden [0] = rr_bfcb1_cpu_en     ;
    for(i=0;i<NUM_ANT;i=i+1) begin
        rr_bfcb1_buf_rdata[i] = w_bfcb1_buf_rdata [((2*BW_WGT)*(i+1)-1)-:(2*BW_WGT)] ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_WGT_RD;i=i+1) begin
        rr_bfcb1_buf_rden[i] <= rr_bfcb1_buf_rden[i-1] ;
        rr_bfcb1_buf_zpen[i] <= rr_bfcb1_buf_zpen[i-1] ;
        rr_bfcb1_cpu_rden[i] <= rr_bfcb1_cpu_rden[i-1] ;
    end
end

`ifdef DLFE_XILINX_VERSAL
(* keep = "true" *) reg     [01-1:0]    r_npredefl_en    ;
(* keep = "true" *) reg     [01-1:0]    r_npredefl_wren  ;
(* keep = "true" *) reg     [20-1:0]    r_npredefl_addr  ;
(* keep = "true" *) reg     [05-1:0]    r_npredefl_wdata ;
(* keep = "true" *) reg     [01-1:0]    r_npredefl_rden  ;
`else// DLFE_XILINX_VERSAL
reg     [01-1:0]    r_npredefl_en       ;
reg     [01-1:0]    r_npredefl_wren     ;
reg     [20-1:0]    r_npredefl_addr     ;
reg     [05-1:0]    r_npredefl_wdata    ;
reg     [01-1:0]    r_npredefl_rden     ;
`endif// DLFE_XILINX_VERSAL
reg     [01-1:0]    rr_npredefl_rden    ;
wire    [05-1:0]    w_npredefl_rdata    ;
always@(posedge i_clk) begin
    if(r_cpu_wren&&r_cpu_addr>=NPREDEFL_START_ADDR&&r_cpu_addr<=NPREDEFL_END_ADDR) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  r_cpu_wren ;
        r_npredefl_addr    <= (r_cpu_addr-NPREDEFL_START_ADDR)>>2 ; 
        r_npredefl_wdata   <=  r_cpu_wdata ;
        r_npredefl_rden    <=  1'd0 ;
    end
    else if(r_cpu_rden&&r_cpu_addr>=NPREDEFL_START_ADDR&&r_cpu_addr<=NPREDEFL_END_ADDR) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_addr    <= (r_cpu_addr-NPREDEFL_START_ADDR)>>2 ; 
        r_npredefl_rden    <=  r_cpu_rden ;
    end
    else if(|r_en[LANE_REF][DLY_IN-2]&&r_re_map[DLY_IN-2]>IDX_REMAP_SUCB) begin
        r_npredefl_en      <=  1'd1 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_rden    <=  1'd0 ;
        r_npredefl_addr    <= {14'd0,(r_re_map[DLY_IN-2]-IDX_REMAP_WPREDEF)} ;  
    end
    else begin
        r_npredefl_en      <=  1'd0 ;
        r_npredefl_wren    <=  1'd0 ;
        r_npredefl_rden    <=  1'd0 ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   5                           )
   ,.DEPTH  (   2**$clog2(NUM_PREDEF_BEAM)  )
   ,.VENDOR (   VENDOR                      )) 
u01_npredefl_mem (
    .clk    (   i_clk                                           )
   ,.we     (   r_npredefl_wren                                 )
   ,.en     (   r_npredefl_en                                   )
   ,.addr   (   r_npredefl_addr[$clog2(NUM_PREDEF_BEAM)-1:0]    )
   ,.di     (   r_npredefl_wdata                                )
   ,.dout   (   w_npredefl_rdata                                )
);
always@(posedge i_clk) begin
    rr_npredefl_rden   <=  r_npredefl_rden    ;
end

generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g01_bfw_cpu_rd
always@(posedge i_clk) begin
    if(rr_bfcb0_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb0_cpu_rden[DLY_WGT_RD] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb0_buf_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
    end
    else if(rr_bfcb1_cpu_rden[DLY_WGT_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_bfcb1_cpu_rden[DLY_WGT_RD] ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_rdata[r_ant_buf_sel][(2*BW_WGT-1)-:BW_WGT],{{16-BW_WGT}{1'd0}},rr_bfcb1_buf_rdata[r_ant_buf_sel][(1*BW_WGT-1)-:BW_WGT]} ;
    end
    else if(rr_npredefl_rden[gidx]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  rr_npredefl_rden ;
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)]   <=  {27'd0,w_npredefl_rdata} ;
    end
    else begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)]   <=  1'd0 ;
    end
end
end
endgenerate
reg [2*BW_WGT-1:0]  r_mux_bfw_mat   [NUM_LANE_CC*NUM_ANT-1:0]    ;
generate for(gidx=0;gidx<NUM_LANE_CC*NUM_ANT;gidx=gidx+1) begin : g01_mux_bfw_mat
if((gidx/NUM_ANT)==IDX_LANE00) begin
always@(posedge i_clk) begin
    if(rr_bfcb0_buf_rden[DLY_WGT_RD]||rr_bfcb1_buf_rden[DLY_WGT_RD]) begin
        if(rr_bfcb0_buf_rden[DLY_WGT_RD]) begin
            if(rr_bfcb0_buf_zpen[DLY_WGT_RD]) begin
                r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
            end
            else begin
                r_mux_bfw_mat   [gidx]   <= rr_bfcb0_buf_rdata[gidx%NUM_ANT]  ;  
            end
        end
        else begin
            r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
        end
    end
end
end//(gidx/NUM_ANT)==IDX_LANE00
else if((gidx/NUM_ANT)==IDX_LANE01) begin
always@(posedge i_clk) begin
    if(rr_bfcb0_buf_rden[DLY_WGT_RD]||rr_bfcb1_buf_rden[DLY_WGT_RD]) begin
        if(rr_bfcb1_buf_rden[DLY_WGT_RD]) begin
            if(rr_bfcb1_buf_zpen[DLY_WGT_RD]) begin
                r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
            end
            else begin
                r_mux_bfw_mat   [gidx]   <= rr_bfcb1_buf_rdata[gidx%NUM_ANT]  ;  
            end
        end
        else begin
            r_mux_bfw_mat   [gidx]   <= {{2*BW_WGT}{1'd0}}  ;
        end
    end
end
end//(gidx/NUM_ANT)==IDX_LANE01
end
endgenerate
reg [01-1:0]    r_nlayer_en ;
reg [05-1:0]    r_nlayer    ;
always@(posedge i_clk) begin
    r_nlayer_en <= |r_en[LANE_REF][DLY_IN]  ;
    if(|r_en[LANE_REF][DLY_IN]) begin
        if(|r_cals_pat_en) begin
            r_nlayer <= NLAYER_CALS ;
        end
        else begin
            if(r_re_map[DLY_IN]==IDX_REMAP_SUCB) begin
                r_nlayer <=  r_nmusul[DLY_IN]    ;
            end
            else if(r_re_map[DLY_IN]>IDX_REMAP_SUCB) begin
                r_nlayer <=  w_npredefl_rdata ;
            end
        end
    end
end
reg [01-1:0] r_dly_nlayer_en [DLY_NLAYER:0]  ;
reg [05-1:0] r_dly_nlayer    [DLY_NLAYER:0]  ;
always@(*) begin
    r_dly_nlayer_en [0] = r_nlayer_en ;
    r_dly_nlayer    [0] = r_nlayer    ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_NLAYER;i=i+1) begin
        r_dly_nlayer_en[i] <= r_dly_nlayer_en[i-1] ;
        if(r_dly_nlayer_en[i-1]) begin
            r_dly_nlayer[i] <=  r_dly_nlayer[i-1] ;
        end
    end
end
reg [BW_ISQRT-1:0]    r_isqrt ;
always@(posedge i_clk) begin
    if(r_dly_nlayer_en[DLY_NLAYER]) begin
        case(r_dly_nlayer[DLY_NLAYER]) 
            5'd1    :   r_isqrt <= 13'd4096  ;
            5'd2    :   r_isqrt <= 13'd2896  ;
            5'd3    :   r_isqrt <= 13'd2365  ;
            5'd4    :   r_isqrt <= 13'd2048  ;
            5'd5    :   r_isqrt <= 13'd1832  ;
            5'd6    :   r_isqrt <= 13'd1672  ;
            5'd7    :   r_isqrt <= 13'd1548  ;
            5'd8    :   r_isqrt <= 13'd1448  ;
            default :   r_isqrt <= 13'd0     ;
        endcase
    end
end
reg  [2*BW_WGT-1:0]             r_mux_cals_bfw_mat  [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [0:0]                      w_bfw_mult_en       [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_i        [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [(DI_BW+BW_WGT+1)-1:0]     w_bfw_mult_q        [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_bfw_mult_i_dummy  [NUM_LANE_CC*NUM_ANT-1:0]   ;
wire [40-(DI_BW+BW_WGT+1)-1:0]  w_bfw_mult_q_dummy  [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [0:0]                      r_bfw_mult_en       [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [(DI_BW+BW_WGT+1)-1:0]     r_bfw_mult_i        [NUM_LANE_CC*NUM_ANT-1:0]   ;
reg  [(DI_BW+BW_WGT+1)-1:0]     r_bfw_mult_q        [NUM_LANE_CC*NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_LANE_CC*NUM_ANT;gidx=gidx+1) begin : g02_bfw_mult_lane
always@(*) begin
    if(gidx<NUM_ANT) begin
        r_mux_cals_bfw_mat [gidx] = |i_cals_cal_en ? {{2*BW_WGT}{r_cals_pat_en[gidx%NUM_ANT]}}&BYPASS_BFW_CALS : r_mux_bfw_mat[gidx]  ;
    end
    else begin
        r_mux_cals_bfw_mat [gidx] = |i_cals_cal_en ? {{2*BW_WGT}{1'b0}} : r_mux_bfw_mat[gidx]  ;
    end
end
if(VENDOR=="Xilinx_Versal") begin
xip_cmult_bb_top_c16
u01_bfw_mult
(
    .aclk                   (   i_clk                                                                                                       )
   ,.s_axis_a_tvalid        (  |r_en[gidx/NUM_ANT][DLY_IN]                                                                                  )
   ,.s_axis_a_tdata         (  {{{{16-DI_BW}{r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)]}},r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)-:DI_BW]}
                               ,{{{16-DI_BW}{r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)]}},r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)-:DI_BW]}}     )
   ,.s_axis_b_tvalid        (  |r_en[gidx/NUM_ANT][DLY_IN]                                                                                  )
   ,.s_axis_b_tdata         (  {{{{16-BW_WGT}{r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)]}},r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)-:BW_WGT]}
                               ,{{{16-BW_WGT}{r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)]}},r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)-:BW_WGT]}}     )
   ,.m_axis_dout_tvalid     (   w_bfw_mult_en[gidx]                                                                                         )
   ,.m_axis_dout_tdata      (  {w_bfw_mult_q_dummy[gidx],w_bfw_mult_q[gidx],w_bfw_mult_i_dummy[gidx],w_bfw_mult_i[gidx]}                    )
);                  
end
else begin //(VENDOR=="Xilinx_Versal")
ylib_cmult #(
    .AWIDTH     (   DI_BW       )
   ,.BWIDTH     (   BW_WGT      ))
u01_bfw_mult
(
    .clk    (   i_clk                                               )
   ,.en     (  |r_en[gidx/NUM_ANT][DLY_IN]                          )
   ,.ar     (   r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*2-1)-:DI_BW]      )
   ,.ai     (   r_iq[gidx/NUM_ANT][DLY_IN][(DI_BW*1-1)-:DI_BW]      )
   ,.br     (   r_mux_cals_bfw_mat[gidx][(BW_WGT*2-1)-:BW_WGT]      )
   ,.bi     (   r_mux_cals_bfw_mat[gidx][(BW_WGT*1-1)-:BW_WGT]      )
   ,.pen    (   w_bfw_mult_en[gidx]                                 )
   ,.pr     (   w_bfw_mult_i[gidx]                                  )
   ,.pi     (   w_bfw_mult_q[gidx]                                  )
);
end //(VENDOR=="Xilinx_Versal")
always@(posedge i_clk) begin 
    r_bfw_mult_en[gidx] <=  w_bfw_mult_en[gidx]  ;
    if(w_bfw_mult_en[gidx]) begin
        r_bfw_mult_i[gidx]  <=  w_bfw_mult_i[gidx]  ;
        r_bfw_mult_q[gidx]  <=  w_bfw_mult_q[gidx]  ;
    end
end
end
endgenerate

reg  [01-1:0]                                           r_bf_mat_lyr_cnt    [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           r_bf_mat_mult_en    [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               r_bf_mat_mult_i     [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               r_bf_mat_mult_q     [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           rr_bf_mat_mult_en   [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               rr_bf_mat_mult_i    [NUM_ANT-1:0]   ;
reg  [DI_BW+BW_WGT+$clog2(NUM_LAYER)-1:0]               rr_bf_mat_mult_q    [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           r_bf_mat_mult_s_en  [NUM_ANT-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  r_bf_mat_mult_s_iq  [NUM_ANT-1:0]   ;
reg  [01-1:0]                                           rr_bf_mat_mult_s_en [NUM_ANT-1:0]   ;
reg  [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  rr_bf_mat_mult_s_iq [NUM_ANT-1:0]   ;
wire [NUM_ANT-1:0]                                      w_bf_mat_mult_sr_en                 ;
wire [2*(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)-1:0]  w_bf_mat_mult_sr_iq [NUM_ANT-1:0]   ;
generate for(gidx=0;gidx<NUM_ANT;gidx=gidx+1) begin : g03_0_bf_mat_lane_buf
always@(posedge i_clk) begin
    if(|i_cals_cal_en) begin
        r_bf_mat_mult_en[gidx] <= r_bfw_mult_en[gidx] ;
        if(r_bfw_mult_en[gidx%NUM_ANT]) begin
            r_bf_mat_mult_i[gidx] <= $signed(r_bfw_mult_i[NUM_ANT*00+gidx])+$signed(r_bfw_mult_i[NUM_ANT*01+gidx]) ;
            r_bf_mat_mult_q[gidx] <= $signed(r_bfw_mult_q[NUM_ANT*00+gidx])+$signed(r_bfw_mult_q[NUM_ANT*01+gidx]) ;
        end
    end
    else begin
        r_bf_mat_mult_en[gidx] <= r_bfw_mult_en[gidx]&&r_bf_mat_lyr_cnt[gidx]==1'd0 ;
        if(w_bfw_mult_en[gidx%NUM_ANT]&~r_bfw_mult_en[gidx]) begin
            r_bf_mat_lyr_cnt[gidx] <= 1'd0 ;
        end
        else if(r_bfw_mult_en[gidx%NUM_ANT]) begin
            r_bf_mat_lyr_cnt[gidx] <= r_bf_mat_lyr_cnt[gidx] + 1'd1 ;
            r_bf_mat_mult_i[gidx] <= $signed(w_bfw_mult_i[NUM_ANT*00+gidx])+$signed(w_bfw_mult_i[NUM_ANT*01+gidx])+$signed(r_bfw_mult_i[NUM_ANT*00+gidx])+$signed(r_bfw_mult_i[NUM_ANT*01+gidx])    ;
            r_bf_mat_mult_q[gidx] <= $signed(w_bfw_mult_q[NUM_ANT*00+gidx])+$signed(w_bfw_mult_q[NUM_ANT*01+gidx])+$signed(r_bfw_mult_q[NUM_ANT*00+gidx])+$signed(r_bfw_mult_q[NUM_ANT*01+gidx])    ;
        end
    end
end
always@(posedge i_clk) begin
    rr_bf_mat_mult_en[gidx] <=  r_bf_mat_mult_en[gidx]  ;
    if(r_bf_mat_mult_en[gidx]) begin
        rr_bf_mat_mult_i[gidx] <= r_bf_mat_mult_i[gidx] ;
        rr_bf_mat_mult_q[gidx] <= r_bf_mat_mult_q[gidx] ;
    end
end
always@(posedge i_clk) begin
    r_bf_mat_mult_s_en[gidx] <=  rr_bf_mat_mult_en[gidx]  ;
    if(rr_bf_mat_mult_en[gidx]) begin
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*2-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)] <= $signed(rr_bf_mat_mult_i[gidx]) * $signed({1'd0,r_isqrt}) ;
        r_bf_mat_mult_s_iq[gidx][((DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)*1-1)-:(DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT)] <= $signed(rr_bf_mat_mult_q[gidx]) * $signed({1'd0,r_isqrt}) ;
    end
end
always@(posedge i_clk) begin
    rr_bf_mat_mult_s_en[gidx] <=  r_bf_mat_mult_s_en[gidx]  ;
    if(r_bf_mat_mult_s_en[gidx]) begin
        rr_bf_mat_mult_s_iq[gidx] <= r_bf_mat_mult_s_iq[gidx] ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2                                       )
 ,.SHIFTD_BW    (   5                                       )
 ,.IO_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT ))
u02_bfw_shiftd_rnd 
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   rr_bf_mat_mult_s_en[gidx]   )
    ,.i_in      (   rr_bf_mat_mult_s_iq[gidx]   )
    ,.i_shiftd  (   5'd20                       )
    ,.o_out_en  (   w_bf_mat_mult_sr_en[gidx]   )
    ,.o_out     (   w_bf_mat_mult_sr_iq[gidx]   )
);
ylib_sat #(
  .NUM_STREAM   (   2                                       )
 ,.DI_BW        (   DI_BW+BW_WGT+$clog2(NUM_LAYER)+BW_ISQRT )
 ,.DO_BW        (   DO_BW                                   ))
u03_bfw_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   w_bf_mat_mult_sr_en[gidx]                       )
    ,.i_in      (   w_bf_mat_mult_sr_iq[gidx]                       )
    ,.o_out_en  (   o_dout_en[((01)*(gidx+1)-1)-:(01)]              )
    ,.o_out     (   o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]    )
);
always@(posedge i_clk) begin
    if(i_din_frame_sync||(w_bf_mat_mult_sr_en[gidx]&~o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((01)*(gidx+1)-1)-:(01)] <= i_din_cc_id [((01)*(gidx%NUM_LANE_CC+1)-1)-:(01)] ;
        o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] <= gidx&{{$clog2(NUM_ANT)}{1'b1}} ;
    end
end
end
endgenerate
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_0_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_frame_sync ),.o_out(o_dout_frame_sync ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_1_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_subfrm_sync),.o_out(o_dout_subfrm_sync));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_2_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_slot_sync  ),.o_out(o_dout_slot_sync  ));
ylib_pshift #(.BW_SHIFT($clog2(DLY_SYNC))) u04_3_fsync_dly (.i_clk(i_clk),.i_shift(DLY_SYNC),.i_in(i_din_symbol_sync),.o_out(o_dout_symbol_sync));
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        o_dout_mu       <=  i_din_mu        ;   
        o_dout_fft_size <=  i_din_fft_size  ;
        o_dout_cal_en   <=  i_cals_cal_en   ;
    end
end
`endif //DLFE_ORAN_DISABLE
endmodule
