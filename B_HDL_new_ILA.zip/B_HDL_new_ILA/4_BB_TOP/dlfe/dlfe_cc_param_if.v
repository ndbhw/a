////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU
//                 oRU : DCM RT44xx, VzW RT8808,RF4440d
//                 RU  : Telus RT88xx
//  Module       : dlfe_cc_param_if
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe cc parameter interface
//
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.06.21 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2020.07.30 | jyzoo.lee     | LTE TSSI Removed, DSS Delay Removed
//  ------------+---------------+-----------------------------------------------
//   2020.11.11 | jyzoo.lee     | cpu if for Phase Coeffients separated 
//  ------------+---------------+-----------------------------------------------
//   2020.12.08 | jyzoo.lee     | add cpu if for beamforming codebook
//  ------------+---------------+-----------------------------------------------
//   2020.12.28 | jyzoo.lee     | add an header if for cdd_cp_dly init value  
//  ------------+---------------+-----------------------------------------------
//   2020.12.28 | jyzoo.lee     | Supports NUM_ANT==8 
//  ------------+---------------+-----------------------------------------------
//   2021.01.06 | jyzoo.lee     | add cpu if for calibration weight 
//  ------------+---------------+-----------------------------------------------
//   2021.03.30 | jyzoo.lee     | add Registers for AIE 
//  ------------+---------------+-----------------------------------------------
//   2021.04.08 | jyzoo.lee     | Changed Address Offset for cddValue Capacity 
//  ------------+---------------+-----------------------------------------------
//   2021.04.29 | jyzoo.lee     | cpu if for CDD separated 
//  ------------+---------------+-----------------------------------------------
//   2021.06.25 | jyzoo.lee     | Indirect BF/CAL Weight Interface Support
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_cc_param_if
#(
    parameter   ADDR_OFFSET         =       0           
   ,parameter   NUM_LAYER           =       4           
   ,parameter   NUM_ANT             =       4           
   ,parameter   DLY_REG_RD          =       5           
)(
    //--- reset & clk
        input   wire                                i_clk
    ,   input   wire                                i_rst
            
    //--- from bb_top_cpu_if
    ,   input   wire    [19:0]                      i_cpu_addr
    ,   input   wire    [0:0]                       i_cpu_wren
    ,   input   wire    [31:0]                      i_cpu_wdata
    ,   input   wire    [0:0]                       i_cpu_rden
    ,   output  wire    [31:0]                      o_cpu_rdata
    ,   output  wire    [0:0]                       o_cpu_rd_valid

    //--- from bfw_buf_mult
    ,   input   wire    [31:0]                      i_bfw_rdata
    ,   input   wire    [0:0]                       i_bfw_rd_valid

    //--- from calw_buf_mult
    ,   input   wire    [31:0]                      i_calw_rdata
    ,   input   wire    [0:0]                       i_calw_rd_valid

    //--- from phase_comp
    ,   input   wire    [31:0]                      i_pc_rdata
    ,   input   wire    [0:0]                       i_pc_rd_valid

    //--- from cal_schdlr
    ,   input   wire    [31:0]                      i_cals_rdata
    ,   input   wire    [0:0]                       i_cals_rd_valid

    //--- from cdd_cp 
    ,   input   wire    [31:0]                      i_cdd_cp_rdata
    ,   input   wire    [0:0]                       i_cdd_cp_rd_valid

    //--- to dlfe subblock
    ,   output  reg     [02-1:0]                    o_dlfe_par_1004
    ,   output  reg     [01-1:0]                    o_dlfe_par_1008
    ,   output  reg     [22-1:0]                    o_dlfe_par_100c
    ,   output  reg     [22-1:0]                    o_dlfe_par_1050
    ,   output  reg     [01-1:0]                    o_dlfe_par_10c0
    ,   output  reg     [02-1:0]                    o_dlfe_par_1100
    ,   output  reg     [01-1:0]                    o_dlfe_par_1104
    ,   output  reg     [08-1:0]                    o_dlfe_par_1108
    ,   output  reg     [32-1:0]                    o_dlfe_par_110c
    ,   output  reg     [32-1:0]                    o_dlfe_par_1110
    ,   output  reg     [04-1:0]                    o_dlfe_par_1114
    ,   output  reg     [32-1:0]                    o_dlfe_par_1200
    ,   output  reg     [12-1:0]                    o_dlfe_par_1204
    ,   output  reg     [03-1:0]                    o_dlfe_par_1208
    ,   output  reg     [12-1:0]                    o_dlfe_par_120c
    ,   output  reg     [02-1:0]                    o_dlfe_par_1210
    ,   output  reg     [01-1:0]                    o_dlfe_par_1214
    ,   output  reg     [04-1:0]                    o_dlfe_par_1218
    ,   output  reg     [14-1:0]                    o_dlfe_par_121c
    ,   output  reg     [03-1:0]                    o_dlfe_par_1240
    ,   output  reg     [NUM_LAYER-1:0]             o_dlfe_par_1244
    ,   output  reg     [NUM_ANT  -1:0]             o_dlfe_par_124c
    ,   output  reg     [03-1:0]                    o_dlfe_par_1254
    ,   output  reg     [14-1:0]                    o_dlfe_par_1280
    ,   output  reg     [14-1:0]                    o_dlfe_par_1284
    ,   output  reg     [04-1:0]                    o_dlfe_par_1288
    ,   output  reg     [04-1:0]                    o_dlfe_par_128c
    ,   output  reg     [04-1:0]                    o_dlfe_par_1290
`ifndef DLFE_BF_DISABLE
    ,   output  reg     [$clog2(NUM_LAYER)-1:0]     o_dlfe_par_3c00
    ,   output  reg     [$clog2(NUM_ANT  )-1:0]     o_dlfe_par_3c04
    ,   output  reg     [$clog2(NUM_LAYER)-1:0]     o_dlfe_par_3c08
`endif//DLFE_BF_DISABLE           
`ifndef DLFE_CAL_DISABLE
    ,   output  reg     [01-1:0]                    o_dlfe_par_0050
    ,   output  reg     [01-1:0]                    o_dlfe_par_3880
    ,   output  reg     [02-1:0]                    o_dlfe_par_d000
    ,   output  reg     [02-1:0]                    o_dlfe_par_d010
    ,   output  reg     [10-1:0]                    o_dlfe_par_d020
    ,   output  reg     [01-1:0]                    o_dlfe_par_d024
    ,   output  reg     [06-1:0]                    o_dlfe_par_d028
    ,   output  reg     [06-1:0]                    o_dlfe_par_d02c
    ,   output  reg     [04-1:0]                    o_dlfe_par_d030
    ,   output  reg     [07-1:0]                    o_dlfe_par_d034
    ,   output  reg     [07-1:0]                    o_dlfe_par_d038
    ,   output  reg     [07-1:0]                    o_dlfe_par_d03c
    ,   output  reg     [32-1:0]                    o_dlfe_par_d040
    ,   output  reg     [08-1:0]                    o_dlfe_par_d044
    ,   output  reg     [32-1:0]                    o_dlfe_par_d048
    ,   output  reg     [08-1:0]                    o_dlfe_par_d04c
    ,   output  reg     [14-1:0]                    o_dlfe_par_d050
    ,   output  reg     [14-1:0]                    o_dlfe_par_d054
    ,   output  reg     [07-1:0]                    o_dlfe_par_d058
    ,   output  reg     [07-1:0]                    o_dlfe_par_d05c
    ,   output  reg     [07-1:0]                    o_dlfe_par_d060
    ,   output  reg     [07-1:0]                    o_dlfe_par_d064
    ,   output  reg     [12-1:0]                    o_dlfe_par_d068
`endif //DLFE_CAL_DISABLE
    ,   input   wire    [22-1:0]                    i_dlfe_rpt_1040
    ,   input   wire    [22-1:0]                    i_dlfe_rpt_1044
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1080
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1084
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1088
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_108c
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1090
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1094
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1098
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_109c
    ,   input   wire    [02-1:0]                    i_dlfe_rpt_10c4
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_10c8
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_10cc
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_10d0
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1120
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1124
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1128
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_112c
    ,   input   wire    [22-1:0]                    i_dlfe_rpt_1130
    ,   input   wire    [22-1:0]                    i_dlfe_rpt_1134
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1140
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1144
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1148
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_114c
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1150
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1154
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_1158
    ,   input   wire    [32-1:0]                    i_dlfe_rpt_115c

    ,   output   reg   [1		-1:0] 	            o_counter_rst					       
	,   output   reg   [2		-1:0] 	            o_sig_susp_en					 /* 0 = disable, 1 = common_threshold, 2 = sym per threshold */    
	,   output   reg   [32*14	-1:0] 	            o_sym_per_thrshld_val			
//	,   output   reg   [12		-1:0] 	            o_reg_ntone
    ,   output   reg   [32		-1:0]	            o_comm_thrshld_val
  
    ,   input  wire     [32*14	-1:0] 	            i_upper_threshold_cnt			
	,   input  wire     [32*14	-1:0] 	            i_max_pwr_per_sym	
    
);

//Logic Variable
integer i ;

reg [  19:0]  r_cpu_addr    ;    
reg [   0:0]  r_cpu_wren    ;
reg [  31:0]  r_cpu_wdata   ;
reg [   0:0]  r_cpu_rden    ;
always@(posedge i_clk) begin
    if(i_cpu_wren) begin
        r_cpu_wren      <=    i_cpu_wren    ;
        r_cpu_wdata     <=    i_cpu_wdata   ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else if(i_cpu_rden) begin
        r_cpu_rden      <=    i_cpu_rden    ;
        r_cpu_addr      <=    i_cpu_addr    ;    
    end
    else begin
        r_cpu_wren      <=    1'd0    ;
        r_cpu_rden      <=    1'd0    ;
    end
end

//demux & parsing
always@(posedge i_clk) begin
    if(i_rst) begin
        o_dlfe_par_100c <=  `DLFE_TARGET_DLY ;   
        o_dlfe_par_1244 <=  {{NUM_LAYER}{1'b1}} ;   
        o_dlfe_par_124c <=  {{NUM_ANT  }{1'b1}} ;   
`ifndef DLFE_AIE_DISABLE
        o_dlfe_par_1050 <=  `DLFE_AIE_IFFT_TARGET_DLY ;   
`endif //DLFE_AIE_DISABLE
`ifndef DLFE_CAL_DISABLE
        o_dlfe_par_1290 <=  4'd8 ;   
        o_dlfe_par_0050 <=  1'b1 ;   
        o_dlfe_par_3880 <=  1'b1 ;   
`endif //DLFE_CAL_DISABLE
    end
    else if(r_cpu_wren) begin
        case(r_cpu_addr)
            ADDR_OFFSET+16'h1004    :   o_dlfe_par_1004     <=  r_cpu_wdata[02-1:0] ;  
            ADDR_OFFSET+16'h1008    :   o_dlfe_par_1008     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h100c    :   o_dlfe_par_100c     <=  r_cpu_wdata[22-1:0] ;  
            ADDR_OFFSET+16'h1050    :   o_dlfe_par_1050     <=  r_cpu_wdata[22-1:0] ;  
            ADDR_OFFSET+16'h10c0    :   o_dlfe_par_10c0     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h1100    :   o_dlfe_par_1100     <=  r_cpu_wdata[02-1:0] ;  
            ADDR_OFFSET+16'h1104    :   o_dlfe_par_1104     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h1108    :   o_dlfe_par_1108     <=  r_cpu_wdata[08-1:0] ;  
            ADDR_OFFSET+16'h110c    :   o_dlfe_par_110c     <=  r_cpu_wdata[32-1:0] ;  
            ADDR_OFFSET+16'h1110    :   o_dlfe_par_1110     <=  r_cpu_wdata[32-1:0] ;  
            ADDR_OFFSET+16'h1114    :   o_dlfe_par_1114     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'h1200    :   o_dlfe_par_1200     <=  r_cpu_wdata[32-1:0] ;  
            ADDR_OFFSET+16'h1204    :   o_dlfe_par_1204     <=  r_cpu_wdata[12-1:0] ;  
            ADDR_OFFSET+16'h1208    :   o_dlfe_par_1208     <=  r_cpu_wdata[03-1:0] ;  
            ADDR_OFFSET+16'h120c    :   o_dlfe_par_120c     <=  r_cpu_wdata[12-1:0] ;  
            ADDR_OFFSET+16'h1210    :   o_dlfe_par_1210     <=  r_cpu_wdata[02-1:0] ;  
            ADDR_OFFSET+16'h1214    :   o_dlfe_par_1214     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h1218    :   o_dlfe_par_1218     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'h121c    :   o_dlfe_par_121c     <=  r_cpu_wdata[14-1:0] ;  
            ADDR_OFFSET+16'h1240    :   o_dlfe_par_1240     <=  r_cpu_wdata[03-1:0] ;  
            ADDR_OFFSET+16'h1244    :   o_dlfe_par_1244     <=  r_cpu_wdata[NUM_LAYER-1:0] ;  
            ADDR_OFFSET+16'h124c    :   o_dlfe_par_124c     <=  r_cpu_wdata[NUM_ANT-1:0] ;  
            ADDR_OFFSET+16'h1254    :   o_dlfe_par_1254     <=  r_cpu_wdata[03-1:0] ;  
            
            ADDR_OFFSET+16'h1670    :   o_counter_rst       <=  r_cpu_wdata[01-1:0] ;
            ADDR_OFFSET+16'h1674    :   o_sig_susp_en       <=  r_cpu_wdata[02-1:0] ;
            ADDR_OFFSET+16'h1678    :   o_comm_thrshld_val  <=  r_cpu_wdata[32-1:0] ;
            
            ADDR_OFFSET+16'h167C    :   o_sym_per_thrshld_val[(32*1-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1680    :   o_sym_per_thrshld_val[(32*2-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1684    :   o_sym_per_thrshld_val[(32*3-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1688    :   o_sym_per_thrshld_val[(32*4-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h168C    :   o_sym_per_thrshld_val[(32*5-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1690    :   o_sym_per_thrshld_val[(32*6-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1694    :   o_sym_per_thrshld_val[(32*7-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h1698    :   o_sym_per_thrshld_val[(32*8-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h169C    :   o_sym_per_thrshld_val[(32*9-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h16A0    :   o_sym_per_thrshld_val[(32*10-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h16A4    :   o_sym_per_thrshld_val[(32*11-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h16A8    :   o_sym_per_thrshld_val[(32*12-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h16AC    :   o_sym_per_thrshld_val[(32*13-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
            ADDR_OFFSET+16'h16B0    :   o_sym_per_thrshld_val[(32*14-1)-:32]       <=  r_cpu_wdata[32-1:0] ;
                        
            
`ifndef DLFE_BF_DISABLE
            ADDR_OFFSET+16'h3c00    :   o_dlfe_par_3c00     <=  r_cpu_wdata[$clog2(NUM_LAYER)-1:0] ;  
            ADDR_OFFSET+16'h3c04    :   o_dlfe_par_3c04     <=  r_cpu_wdata[$clog2(NUM_ANT  )-1:0] ;  
            ADDR_OFFSET+16'h3c08    :   o_dlfe_par_3c08     <=  r_cpu_wdata[$clog2(NUM_LAYER)-1:0] ;  
`endif//DLFE_BF_DISABLE           
`ifndef DLFE_CAL_DISABLE        
            ADDR_OFFSET+16'h0050    :   o_dlfe_par_0050     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h3880    :   o_dlfe_par_3880     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'h1280    :   o_dlfe_par_1280     <=  r_cpu_wdata[14-1:0] ;  
            ADDR_OFFSET+16'h1284    :   o_dlfe_par_1284     <=  r_cpu_wdata[14-1:0] ;  
            ADDR_OFFSET+16'h1288    :   o_dlfe_par_1288     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'h128c    :   o_dlfe_par_128c     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'h1290    :   o_dlfe_par_1290     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'hd000    :   o_dlfe_par_d000     <=  r_cpu_wdata[02-1:0] ;  
            ADDR_OFFSET+16'hd010    :   o_dlfe_par_d010     <=  r_cpu_wdata[02-1:0] ;  
            ADDR_OFFSET+16'hd020    :   o_dlfe_par_d020     <=  r_cpu_wdata[10-1:0] ;  
            ADDR_OFFSET+16'hd024    :   o_dlfe_par_d024     <=  r_cpu_wdata[01-1:0] ;  
            ADDR_OFFSET+16'hd028    :   o_dlfe_par_d028     <=  r_cpu_wdata[06-1:0] ;  
            ADDR_OFFSET+16'hd02c    :   o_dlfe_par_d02c     <=  r_cpu_wdata[06-1:0] ;  
            ADDR_OFFSET+16'hd030    :   o_dlfe_par_d030     <=  r_cpu_wdata[04-1:0] ;  
            ADDR_OFFSET+16'hd034    :   o_dlfe_par_d034     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd038    :   o_dlfe_par_d038     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd03c    :   o_dlfe_par_d03c     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd040    :   o_dlfe_par_d040     <=  r_cpu_wdata[32-1:0] ;  
            ADDR_OFFSET+16'hd044    :   o_dlfe_par_d044     <=  r_cpu_wdata[08-1:0] ;  
            ADDR_OFFSET+16'hd048    :   o_dlfe_par_d048     <=  r_cpu_wdata[32-1:0] ;  
            ADDR_OFFSET+16'hd04c    :   o_dlfe_par_d04c     <=  r_cpu_wdata[08-1:0] ;  
            ADDR_OFFSET+16'hd050    :   o_dlfe_par_d050     <=  r_cpu_wdata[14-1:0] ;  
            ADDR_OFFSET+16'hd054    :   o_dlfe_par_d054     <=  r_cpu_wdata[14-1:0] ;  
            ADDR_OFFSET+16'hd058    :   o_dlfe_par_d058     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd05c    :   o_dlfe_par_d05c     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd060    :   o_dlfe_par_d060     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd064    :   o_dlfe_par_d064     <=  r_cpu_wdata[07-1:0] ;  
            ADDR_OFFSET+16'hd068    :   o_dlfe_par_d068     <=  r_cpu_wdata[12-1:0] ;  
`endif //DLFE_CAL_DISABLE
        endcase                                                      
    end                                                               
end                                                                   
reg [0:0]   r_mux_reg_rd_en    ;
reg [31:0]  r_mux_reg_rd_data  ;
always@(posedge i_clk) begin
    if(r_cpu_rden) begin
        case(r_cpu_addr)
            ADDR_OFFSET+16'h1004    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},o_dlfe_par_1004} ; end    
            ADDR_OFFSET+16'h1008    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_1008} ; end    
            ADDR_OFFSET+16'h100c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},o_dlfe_par_100c} ; end    
            ADDR_OFFSET+16'h1040    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},i_dlfe_rpt_1040} ; end    
            ADDR_OFFSET+16'h1044    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},i_dlfe_rpt_1044} ; end    
            ADDR_OFFSET+16'h1050    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},o_dlfe_par_1050} ; end    
`ifndef DLFE_LSSI_DISABLE       
            ADDR_OFFSET+16'h1080    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1080} ; end    
            ADDR_OFFSET+16'h1084    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1084} ; end    
            ADDR_OFFSET+16'h1088    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1088} ; end    
            ADDR_OFFSET+16'h108c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_108c} ; end    
            ADDR_OFFSET+16'h1090    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1090} ; end    
            ADDR_OFFSET+16'h1094    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1094} ; end    
            ADDR_OFFSET+16'h1098    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1098} ; end    
            ADDR_OFFSET+16'h109c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_109c} ; end    
            ADDR_OFFSET+16'h10c0    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_10c0} ; end    
            ADDR_OFFSET+16'h10c4    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},i_dlfe_rpt_10c4} ; end    
            ADDR_OFFSET+16'h10c8    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_10c8} ; end    
            ADDR_OFFSET+16'h10cc    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_10cc} ; end    
            ADDR_OFFSET+16'h10d0    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_10d0} ; end    
`endif //DLFE_LSSI_DISABLE      
            ADDR_OFFSET+16'h1100    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},o_dlfe_par_1100} ; end    
            ADDR_OFFSET+16'h1104    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_1104} ; end    
            ADDR_OFFSET+16'h1108    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(08-1+1)}{1'd0}},o_dlfe_par_1108} ; end    
            ADDR_OFFSET+16'h110c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},o_dlfe_par_110c} ; end    
            ADDR_OFFSET+16'h1110    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},o_dlfe_par_1110} ; end    
            ADDR_OFFSET+16'h1114    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_1114} ; end
            ADDR_OFFSET+16'h1120    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1120} ; end    
            ADDR_OFFSET+16'h1124    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1124} ; end    
            ADDR_OFFSET+16'h1128    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1128} ; end    
            ADDR_OFFSET+16'h112c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_112c} ; end    
            ADDR_OFFSET+16'h1130    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},i_dlfe_rpt_1130} ; end    
            ADDR_OFFSET+16'h1134    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(22-1+1)}{1'd0}},i_dlfe_rpt_1134} ; end
`ifndef DLFE_TSSI_DISABLE       
            ADDR_OFFSET+16'h1140    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1140} ; end    
            ADDR_OFFSET+16'h1144    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1144} ; end    
            ADDR_OFFSET+16'h1148    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1148} ; end    
            ADDR_OFFSET+16'h114c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_114c} ; end    
`ifdef DLFE_ANT_PORT_8            
            ADDR_OFFSET+16'h1150    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1150} ; end    
            ADDR_OFFSET+16'h1154    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1154} ; end    
            ADDR_OFFSET+16'h1158    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_1158} ; end    
            ADDR_OFFSET+16'h115c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},i_dlfe_rpt_115c} ; end    
`endif//DLFE_ANT_PORT_8            
`endif //DLFE_TSSI_DISABLE      
            ADDR_OFFSET+16'h1200    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},o_dlfe_par_1200} ; end    
            ADDR_OFFSET+16'h1204    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(12-1+1)}{1'd0}},o_dlfe_par_1204} ; end    
            ADDR_OFFSET+16'h1208    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(03-1+1)}{1'd0}},o_dlfe_par_1208} ; end    
            ADDR_OFFSET+16'h120c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(12-1+1)}{1'd0}},o_dlfe_par_120c} ; end    
            ADDR_OFFSET+16'h1210    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},o_dlfe_par_1210} ; end    
            ADDR_OFFSET+16'h1214    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_1214} ; end    
            ADDR_OFFSET+16'h1218    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_1218} ; end    
            ADDR_OFFSET+16'h121c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(14-1+1)}{1'd0}},o_dlfe_par_121c} ; end    
            ADDR_OFFSET+16'h1240    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(03-1+1)}{1'd0}},o_dlfe_par_1240} ; end    
            ADDR_OFFSET+16'h1244    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(NUM_LAYER-1+1)}{1'd0}},o_dlfe_par_1244} ; end    
            ADDR_OFFSET+16'h124c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(NUM_ANT  -1+1)}{1'd0}},o_dlfe_par_124c} ; end    
            ADDR_OFFSET+16'h1254    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(03-1+1)}{1'd0}},o_dlfe_par_1254} ; end    
`ifndef DLFE_BF_DISABLE
            ADDR_OFFSET+16'h3c00    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-($clog2(NUM_LAYER)-1+1)}{1'd0}},o_dlfe_par_3c00} ; end    
            ADDR_OFFSET+16'h3c04    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-($clog2(NUM_ANT  )-1+1)}{1'd0}},o_dlfe_par_3c04} ; end    
            ADDR_OFFSET+16'h3c08    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-($clog2(NUM_LAYER)-1+1)}{1'd0}},o_dlfe_par_3c08} ; end    
`endif//DLFE_BF_DISABLE           
`ifndef DLFE_CAL_DISABLE        
            ADDR_OFFSET+16'h0050    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_0050} ; end    
            ADDR_OFFSET+16'h3880    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_3880} ; end    
            ADDR_OFFSET+16'h1280    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(14-1+1)}{1'd0}},o_dlfe_par_1280} ; end    
            ADDR_OFFSET+16'h1284    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(14-1+1)}{1'd0}},o_dlfe_par_1284} ; end    
            ADDR_OFFSET+16'h1288    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_1288} ; end    
            ADDR_OFFSET+16'h128c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_128c} ; end    
            ADDR_OFFSET+16'h1290    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_1290} ; end    
            ADDR_OFFSET+16'hd000    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},o_dlfe_par_d000} ; end    
            ADDR_OFFSET+16'hd010    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(02-1+1)}{1'd0}},o_dlfe_par_d010} ; end    
            ADDR_OFFSET+16'hd020    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(10-1+1)}{1'd0}},o_dlfe_par_d020} ; end    
            ADDR_OFFSET+16'hd024    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(01-1+1)}{1'd0}},o_dlfe_par_d024} ; end    
            ADDR_OFFSET+16'hd028    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(06-1+1)}{1'd0}},o_dlfe_par_d028} ; end    
            ADDR_OFFSET+16'hd02c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(06-1+1)}{1'd0}},o_dlfe_par_d02c} ; end    
            ADDR_OFFSET+16'hd030    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(04-1+1)}{1'd0}},o_dlfe_par_d030} ; end    
            ADDR_OFFSET+16'hd034    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d034} ; end    
            ADDR_OFFSET+16'hd038    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d038} ; end    
            ADDR_OFFSET+16'hd03c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d03c} ; end    
            ADDR_OFFSET+16'hd040    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},o_dlfe_par_d040} ; end    
            ADDR_OFFSET+16'hd044    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(08-1+1)}{1'd0}},o_dlfe_par_d044} ; end    
            ADDR_OFFSET+16'hd048    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},o_dlfe_par_d048} ; end    
            ADDR_OFFSET+16'hd04c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(08-1+1)}{1'd0}},o_dlfe_par_d04c} ; end    
            ADDR_OFFSET+16'hd050    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(14-1+1)}{1'd0}},o_dlfe_par_d050} ; end    
            ADDR_OFFSET+16'hd054    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(14-1+1)}{1'd0}},o_dlfe_par_d054} ; end    
            ADDR_OFFSET+16'hd058    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d058} ; end    
            ADDR_OFFSET+16'hd05c    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d05c} ; end    
            ADDR_OFFSET+16'hd060    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d060} ; end    
            ADDR_OFFSET+16'hd064    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(07-1+1)}{1'd0}},o_dlfe_par_d064} ; end    
            ADDR_OFFSET+16'hd068    :   begin r_mux_reg_rd_en <= 1'd1; r_mux_reg_rd_data <= {{{32-(12-1+1)}{1'd0}},o_dlfe_par_d068} ; end    
`endif //DLFE_CAL_DISABLE
            default                 :   begin r_mux_reg_rd_en <= 1'd0; r_mux_reg_rd_data <= {{{32-(32-1+1)}{1'd0}},32'd0          } ; end    
        endcase                                                      
    end
    else begin
        r_mux_reg_rd_en <= 1'd0 ;
    end
end
reg [0:0]   r_mux_mem_rd_en    ;
reg [31:0]  r_mux_mem_rd_data  ;
always@(posedge i_clk) begin
    if(i_bfw_rd_valid) begin
        r_mux_mem_rd_en   <=  1'd1         ;    
        r_mux_mem_rd_data <=  i_bfw_rdata  ;
    end
`ifndef DLFE_CAL_DISABLE
    else if(i_calw_rd_valid) begin
        r_mux_mem_rd_en   <=  1'd1         ;    
        r_mux_mem_rd_data <=  i_calw_rdata ;
    end
    else if(i_cals_rd_valid) begin
        r_mux_mem_rd_en   <=  1'd1         ;    
        r_mux_mem_rd_data <=  i_cals_rdata ;
    end
`endif // DLFE_CAL_DISABLE
    else if(i_pc_rd_valid) begin
        r_mux_mem_rd_en   <=  1'd1         ;    
        r_mux_mem_rd_data <=  i_pc_rdata   ;
    end
    else if(i_cdd_cp_rd_valid) begin
        r_mux_mem_rd_en   <=  1'd1         ;    
        r_mux_mem_rd_data <=  i_cdd_cp_rdata ;
    end
    else begin
        r_mux_mem_rd_en   <=  1'd0 ;    
    end
end
reg [0:0]   r_mux_rd_en    [DLY_REG_RD:0]  ;
reg [31:0]  r_mux_rd_data  [DLY_REG_RD:0]  ;
always@(posedge i_clk) begin
    if(r_mux_reg_rd_en) begin
        r_mux_rd_en    [0] <= r_mux_reg_rd_en    ;
        r_mux_rd_data  [0] <= r_mux_reg_rd_data  ;
    end
    else if(r_mux_mem_rd_en) begin
        r_mux_rd_en    [0] <= r_mux_mem_rd_en    ;
        r_mux_rd_data  [0] <= r_mux_mem_rd_data  ;
    end
    else begin
        r_mux_rd_en    [0] <= 1'd0    ;
    end
end
generate if(DLY_REG_RD>0) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_REG_RD;i=i+1) begin 
        r_mux_rd_en[i]  <=  r_mux_rd_en[i-1] ;    
        if(r_mux_rd_en[i-1]) begin
            r_mux_rd_data[i]  <=  r_mux_rd_data[i-1] ;    
        end  
    end
end                            
end
endgenerate
assign  o_cpu_rd_valid  =   r_mux_rd_en   [DLY_REG_RD]   ;   
assign  o_cpu_rdata     =   r_mux_rd_data [DLY_REG_RD]   ;   

endmodule
