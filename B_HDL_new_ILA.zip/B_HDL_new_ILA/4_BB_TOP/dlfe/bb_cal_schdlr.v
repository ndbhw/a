////////////////////////////////////////////////////////////////////////////////
// 
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : oRU : VzW RT8808
//                 RU  : Telus RT8809/RT8811
//  Module       : bb_cal_schdlr
//  Author       : jyzoo.lee@samsung.com
//  Description  : Baseband Calibration Scheduler
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2021.05.20 | jyzoo.lee     | Support 12 Bit Xcal  
//  ------------+---------------+-----------------------------------------------
//   2021.06.09 | jyzoo.lee     | Support External BFCAL & BFC_FRSYNC_MON
//  ------------+---------------+-----------------------------------------------
//   2021.06.23 | jyzoo.lee     | 4-bit Down Shift for 16 Bit Xcal 
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module bb_cal_schdlr
#(
     parameter  NUM_CC               =   1
    ,parameter  CC_ID                =   0
    ,parameter  NUM_ANT              =   1
    ,parameter  DO_BW                =   16           
    ,parameter  MAX_MU               =   0           
    ,parameter  ADDR_OFFSET          =   'h00000           
    ,parameter  VENDOR               =  "Intel"           
)(
    //--- reset & clk
        input   wire                                            i_rst
    ,   input   wire                                            i_clk
`ifdef DLFE_EXT_BFCAL_DISABLE
    //--- from cpu_if
    ,   input   wire    [20*NUM_CC-1:0]                         i_cpu_addr
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_wren
    ,   input   wire    [32*NUM_CC-1:0]                         i_cpu_wdata
    ,   input   wire    [01*NUM_CC-1:0]                         i_cpu_rden
    ,   output  reg     [32*NUM_CC-1:0]                         o_cpu_rdata
    ,   output  reg     [01*NUM_CC-1:0]                         o_cpu_rd_valid
    //--- from dlfe_param_if
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_120c
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_d000
    ,   input   wire    [02*NUM_CC-1:0]                         i_dlfe_par_d010
    ,   input   wire    [10*NUM_CC-1:0]                         i_dlfe_par_d020
    ,   input   wire    [01*NUM_CC-1:0]                         i_dlfe_par_d024
    ,   input   wire    [06*NUM_CC-1:0]                         i_dlfe_par_d028
    ,   input   wire    [06*NUM_CC-1:0]                         i_dlfe_par_d02c
    ,   input   wire    [04*NUM_CC-1:0]                         i_dlfe_par_d030
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d034
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d038
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d03c
    ,   input   wire    [32*NUM_CC-1:0]                         i_dlfe_par_d040
    ,   input   wire    [08*NUM_CC-1:0]                         i_dlfe_par_d044
    ,   input   wire    [32*NUM_CC-1:0]                         i_dlfe_par_d048
    ,   input   wire    [08*NUM_CC-1:0]                         i_dlfe_par_d04c
    ,   input   wire    [14*NUM_CC-1:0]                         i_dlfe_par_d050
    ,   input   wire    [14*NUM_CC-1:0]                         i_dlfe_par_d054
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d058
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d05c
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d060
    ,   input   wire    [07*NUM_CC-1:0]                         i_dlfe_par_d064
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_d068
`else //DLFE_EXT_BFCAL_DISABLE
    //--- from dlfe_param_if
    ,   input   wire    [01*NUM_CC-1:0]                         i_dlfe_par_10c0
    ,   input   wire    [12*NUM_CC-1:0]                         i_dlfe_par_120c
    //--- from SYSCTRL
    ,   input   wire    [01-1:0]                                i_bcf_lte_tech               
    ,   input   wire    [01-1:0]                                i_bcf_en                
    ,   input   wire    [01-1:0]                                i_bcf_bfn_strb               
    ,   input   wire    [01-1:0]                                i_bcf_cal_path_sel       
    ,   input   wire    [08-1:0]                                i_bcf_cal_main_path_num  
    ,   input   wire    [08-1:0]                                i_bcf_cal_redun_path_num 
    ,   input   wire    [08-1:0]                                i_bcf_cal_sfnblk_frm_num 
    ,   input   wire    [08-1:0]                                i_bcf_dl_cal_frm_num     
    ,   input   wire    [20-1:0]                                i_bcf_dl_cal_slot_map    
    ,   input   wire    [14-1:0]                                i_bcf_dl_cal_symbol_map  
    ,   input   wire    [08-1:0]                                i_bcf_dl_cal_acc_num     
    ,   input   wire    [08-1:0]                                i_bcf_dl_cal_num_per_2sym
    ,   input   wire    [08-1:0]                                i_bcf_dl_cal_num_per_frm 
    ,   input   wire    [08-1:0]                                i_bcf_ul_cal_frm_num     
    ,   input   wire    [20-1:0]                                i_bcf_ul_cal_slot_map    
    ,   input   wire    [14-1:0]                                i_bcf_ul_cal_symbol_map  
    ,   input   wire    [08-1:0]                                i_bcf_ul_cal_acc_num     
    ,   input   wire    [08-1:0]                                i_bcf_ul_cal_num_per_2sym
    ,   input   wire    [08-1:0]                                i_bcf_ul_cal_num_per_frm 
    ,   input   wire    [12-1:0]                                i_bcf_ul_punc_length 
    //--- to BF_CAL_PAT_BUF
    ,   output  reg     [01-1:0]                                o_cal_pat_buf_rden 
    ,   output  reg     [32-1:0]                                o_cal_pat_buf_addr 
    //--- from BF_CAL_PAT_BUF
    ,   input   wire    [32-1:0]                                i_cal_pat_buf_rdata
    //--- to dlfe_param_if
    ,   output  wire    [02-1:0]                                o_bcf_fs_err_flag_blkclk_out
    ,   output  wire    [32-1:0]                                o_bcf_en_fscnt_blkclk_out   
    ,   output  wire    [32-1:0]                                o_bcf_rpls_clkcnt_blkclk_out
    ,   output  wire    [32-1:0]                                o_bcf_en_sfncnt_blkclk_out  
`endif //DLFE_EXT_BFCAL_DISABLE
    //--- from dlfe_bfw_mult
    ,   input   wire    [12-1:0]                                i_din_bfn
    ,   input   wire    [01-1:0]                                i_cals_frame_sync 
    ,   input   wire    [01-1:0]                                i_cals_pat_symbol_sync 
    //--- to dlfe_calw_mult 
`ifdef DLFE_XILINX_VERSAL
    ,   (* mark_debug = "true" *) output reg     [01*NUM_CC-1:0]      o_cals_bcf_en
    ,   (* mark_debug = "true" *) output reg     [02-1:0]             o_cals_cal_en
    ,   (* mark_debug = "true" *) output reg     [01*NUM_ANT-1:0]     o_cals_pat_en 
    ,   (* mark_debug = "true" *) output reg     [2*DO_BW-1:0]        o_cals_pat_iq 
    ,   (* mark_debug = "true" *) output reg     [12*NUM_CC-1:0]      o_cals_punc_len
`else// DLFE_XILINX_VERSAL
    ,   output  reg     [01*NUM_CC-1:0]                         o_cals_bcf_en
    ,   output  reg     [02-1:0]                                o_cals_cal_en
    ,   output  reg     [01*NUM_ANT-1:0]                        o_cals_pat_en 
    ,   output  reg     [2*DO_BW-1:0]                           o_cals_pat_iq 
    ,   output  reg     [12*NUM_CC-1:0]                         o_cals_punc_len
`endif// DLFE_XILINX_VERSAL
);

//Parameter Local Logic
localparam              CC_ID_REF                   =       0                               ;
localparam              ID_CC00                     =       1'd0                            ;
localparam              ID_CC01                     =       1'd1                            ;
localparam              DLY_CAL_PAT                 =       3                               ;   
localparam              DLY_RD                      =       1                               ;   
localparam              NUM_SLOT_FRAME              =       10*(2**MAX_MU)                  ;
localparam              NUM_SYMBOL_SLOT             =       14                              ;
localparam              MAX_RB                      =       273                             ;
localparam              NUM_RE_RB                   =       12                              ;
localparam              NUM_CAL_SYM                 =       2                               ;
localparam  [13-1:00]   NUM_CAL_PAT                 =       MAX_RB*NUM_RE_RB*NUM_CAL_SYM    ;   
localparam  [20-1:00]   CAL_PAT_START_ADDR          =       ADDR_OFFSET                     ;
localparam  [20-1:00]   CAL_PAT_ADDR_OFFSET         =       NUM_CAL_PAT*4                   ;
localparam              BW_CALP                     =       16                              ;
localparam              DLY_CAL_EN                  =       22'd1                           ;
localparam              SHIFT_A_COMP_XCAL           =       4                               ;
`ifndef DLFE_EXT_BFCAL_DISABLE
localparam              DLY_EXT_PAT_BUF             =       1                               ;
localparam              EXT_PAT_BUF_BASE_ADDR       =      `EXT_CAL_PAT_BUF_BASE_ADDR       ;
localparam              EXT_PAT_BUF_CELL_OFFSET     =      `EXT_CAL_PAT_BUF_ADDR_OFFSET     ;
localparam              EXT_PAT_BUF_SYMBOL_OFFSET   =       32'h4000                        ;
`endif// DLFE_EXT_BFCAL_DISABLE

//Logic Variable
integer i ;
genvar gidx ;

`ifdef DLFE_EXT_BFCAL_DISABLE
reg [01-1:0] r_cpu_wren  [NUM_CC-1:0] ;
reg [01-1:0] r_cpu_rden  [NUM_CC-1:0] ;
reg [20-1:0] r_cpu_addr  [NUM_CC-1:0] ;
reg [32-1:0] r_cpu_wdata [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cpu_wren  [i] = i_cpu_wren[i]  ;
        r_cpu_rden  [i] = i_cpu_rden[i]  ;
        r_cpu_addr  [i] = i_cpu_addr [((20)*(i+1)-1)-:(20)] ;
        r_cpu_wdata [i] = i_cpu_wdata[((32)*(i+1)-1)-:(32)] ;
    end
end
reg [01-1:0]                r_frame_sync                                ;
reg [01-1:0]                r_cals_frame_sync                           ;
reg [01-1:0]                r_cals_pat_symbol_sync                      ;
reg [10-1:0]                r_sfn                                       ;
reg [12-1:0]                r_ntone                     [NUM_CC-1:0]    ;
reg [02-1:0]                r_calScsType                [NUM_CC-1:0]    ;
reg [10-1:0]                r_calStartSfn               [NUM_CC-1:0]    ;
reg [01-1:0]                r_calPath                   [NUM_CC-1:0]    ;
reg [06-1:0]                r_mainPath                  [NUM_CC-1:0]    ;
reg [06-1:0]                r_redundancyPath            [NUM_CC-1:0]    ;
reg [04-1:0]                r_nCalBlock                 [NUM_CC-1:0]    ;
reg [07-1:0]                r_nFramePerCalBlock         [NUM_CC-1:0]    ;
reg [07-1:0]                r_nDlCalFramePerCalBlock    [NUM_CC-1:0]    ;
reg [07-1:0]                r_nUlCalFramePerCalBlock    [NUM_CC-1:0]    ;
reg [40-1:0]                r_dlCalSlotMap              [NUM_CC-1:0]    ;
reg [40-1:0]                r_ulCalSlotMap              [NUM_CC-1:0]    ;
reg [NUM_SYMBOL_SLOT-1:0]   r_dlCalSymbolMap            [NUM_CC-1:0]    ;
reg [NUM_SYMBOL_SLOT-1:0]   r_ulCalSymbolMap            [NUM_CC-1:0]    ;
reg [07-1:0]                r_nDlCalAntPer2Syms         [NUM_CC-1:0]    ;
reg [07-1:0]                r_nUlCalAntPer2Syms         [NUM_CC-1:0]    ;
reg [07-1:0]                r_nDlCalAntPerCalBlock      [NUM_CC-1:0]    ;
reg [07-1:0]                r_nUlCalAntPerCalBlock      [NUM_CC-1:0]    ;
reg [02-1:0]                r_calRequest                [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    r_cals_frame_sync   <=  i_cals_frame_sync    ;
    r_frame_sync        <=  i_cals_frame_sync&~r_cals_frame_sync ;
    r_cals_pat_symbol_sync    <=  i_cals_pat_symbol_sync    ;
    if(i_cals_frame_sync&~r_cals_frame_sync) begin
        r_sfn   <=  i_din_bfn[10-1:0]   ;
        for(i=0;i<NUM_CC;i=i+1) begin
            r_ntone                     [i]  <=  i_dlfe_par_120c[((12)*(i+1)-1)-:(12)]    ;
            r_calScsType                [i]  <=  i_dlfe_par_d010[((02)*(i+1)-1)-:(02)]    ;
            r_calStartSfn               [i]  <=  i_dlfe_par_d020[((10)*(i+1)-1)-:(10)]    ;
            r_calPath                   [i]  <=  i_dlfe_par_d024[((01)*(i+1)-1)-:(01)]    ;
            r_mainPath                  [i]  <=  i_dlfe_par_d028[((06)*(i+1)-1)-:(06)]    ;
            r_redundancyPath            [i]  <=  i_dlfe_par_d02c[((06)*(i+1)-1)-:(06)]    ;
            r_nCalBlock                 [i]  <=  i_dlfe_par_d030[((04)*(i+1)-1)-:(04)]    ;
            r_nFramePerCalBlock         [i]  <=  i_dlfe_par_d034[((07)*(i+1)-1)-:(07)]    ;
            r_nDlCalFramePerCalBlock    [i]  <=  i_dlfe_par_d038[((07)*(i+1)-1)-:(07)]    ;
            r_nUlCalFramePerCalBlock    [i]  <=  i_dlfe_par_d03c[((07)*(i+1)-1)-:(07)]    ;
            r_dlCalSlotMap              [i]  <= {i_dlfe_par_d044[((08)*(i+1)-1)-:(08)],i_dlfe_par_d040[((32)*(i+1)-1)-:(32)]};
            r_ulCalSlotMap              [i]  <= {i_dlfe_par_d04c[((08)*(i+1)-1)-:(08)],i_dlfe_par_d048[((32)*(i+1)-1)-:(32)]};
            r_dlCalSymbolMap            [i]  <=  i_dlfe_par_d050[((14)*(i+1)-1)-:(14)]    ;
            r_ulCalSymbolMap            [i]  <=  i_dlfe_par_d054[((14)*(i+1)-1)-:(14)]    ;
            r_nDlCalAntPer2Syms         [i]  <=  i_dlfe_par_d058[((07)*(i+1)-1)-:(07)]    ;
            r_nUlCalAntPer2Syms         [i]  <=  i_dlfe_par_d05c[((07)*(i+1)-1)-:(07)]    ;
            r_nDlCalAntPerCalBlock      [i]  <=  i_dlfe_par_d060[((07)*(i+1)-1)-:(07)]    ;
            r_nUlCalAntPerCalBlock      [i]  <=  i_dlfe_par_d064[((07)*(i+1)-1)-:(07)]    ;
        end
    end
end

reg r_cals_pat_rd_en [NUM_CC-1:0]     ;
reg [$clog2(MAX_RB*NUM_RE_RB)-1:0] r_cals_pat_rd_cnt [NUM_CC-1:0]    ;
reg r_en [NUM_CC-1:0][DLY_CAL_PAT:0] ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_0_cal_pat_req
always@(posedge i_clk) begin
    if(r_cals_pat_symbol_sync) begin
        r_cals_pat_rd_en[gidx]    <=  1'd0    ;
        r_cals_pat_rd_cnt[gidx]   <=  {{$clog2(MAX_RB*NUM_RE_RB)}{1'd0}}    ;
    end
    else if(r_cals_pat_rd_cnt[gidx]<r_ntone[gidx]) begin
        r_cals_pat_rd_en[gidx]    <=  1'd1    ;
        r_cals_pat_rd_cnt[gidx]   <=  r_cals_pat_rd_cnt[gidx] + 1'd1 ;
    end
    else if(r_cals_pat_rd_cnt[gidx]==r_ntone[gidx]) begin
        r_cals_pat_rd_en[gidx]    <=  1'd0    ;
    end
end
always@(*) begin
    r_en[gidx][0] <= r_cals_pat_rd_en[gidx] ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_CAL_PAT;i=i+1) begin
        r_en[gidx][i] <= r_en[gidx][i-1] ;
    end
end
end
endgenerate

reg [01-1:0] r_cal_trig         [NUM_CC-1:0]    ;
reg [01-1:0] r_cal_done         [NUM_CC-1:0]    ;
reg [01-1:0] r_cal_en           [NUM_CC-1:0]    ;
reg [02-1:0] rr_calRequest      [NUM_CC-1:0]    ;
reg [01-1:0] r_cal_mem_init     [NUM_CC-1:0]    ;
reg [01-1:0] r_cal_mem_init_en  [NUM_CC-1:0]    ;
reg [$clog2(NUM_CAL_PAT)-1:0] r_cal_mem_init_addr[NUM_CC-1:0]    ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_calRequest    [i] =  i_dlfe_par_d000[((02)*(i+1)-1)-:(02)]  ;
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        rr_calRequest   [i] <=  r_calRequest[i] ;
        r_cal_trig      [i] <=  r_calRequest[i][0] & ~rr_calRequest[i][0] ;
        r_cal_done      [i] <= ~r_calRequest[i][0] &  rr_calRequest[i][0] ;
        r_cal_mem_init  [i] <=(~r_calRequest[i][0] &  rr_calRequest[i][0])&&(rr_calRequest[i][1]==1'd0) ;
        if(r_cal_trig[i]) begin
            r_cal_en    [i] <=  1'd1    ; 
        end
        else if(r_cal_done[i]) begin
            r_cal_en    [i] <=  1'd0    ; 
        end
    end
end
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(r_cal_mem_init[i]) begin
            r_cal_mem_init_en   [i] <=  1'd1 ;
            r_cal_mem_init_addr [i] <=  20'd0 ;
        end
        else if(r_cal_mem_init_en[i]) begin
            r_cal_mem_init_addr [i] <= r_cal_mem_init_addr [i] + 1'd1   ;
            if(r_cal_mem_init_addr [i]=={{$clog2(NUM_CAL_PAT)}{1'b1}}) begin
                r_cal_mem_init_en [i] <=  1'd0 ;
            end
        end
    end
end
reg [01-1:0] r_cal_blk_frame_sync   [NUM_CC-1:0] ;
reg [07-1:0] r_cal_blk_frame_cnt    [NUM_CC-1:0] ;
reg [01-1:0] r_cal_blk_en           [NUM_CC-1:0] ;
reg [04-1:0] r_cal_blk_cnt          [NUM_CC-1:0] ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        if(r_cal_trig[i]) begin
            r_cal_blk_cnt       [i] <= 4'd0 ; 
            r_cal_blk_frame_cnt [i] <= 7'd0 ; 
        end
        else if(r_cal_en[i]) begin
            r_cal_blk_frame_sync[i] <= r_frame_sync    ;
            if(r_frame_sync) begin
                if(r_sfn==r_calStartSfn[i]) begin
                    r_cal_blk_en[i] <= 1'd1 ; 
                end
                else if(r_cal_blk_en[i]) begin
                    if(r_cal_blk_frame_cnt[i]==r_nFramePerCalBlock[i]-1'd1) begin
                        r_cal_blk_cnt       [i] <= r_cal_blk_cnt[i] + 1'd1 ; 
                        r_cal_blk_frame_cnt [i] <= 7'd0 ;
                        if(r_cal_blk_cnt[i]==(r_nCalBlock[i]<<1)-1'd1) begin
                            r_cal_blk_en  [i] <= 1'd0 ; 
                            r_cal_blk_cnt [i] <= 4'd0 ;
                        end
                    end
                    else begin
                        r_cal_blk_frame_cnt [i] <= r_cal_blk_frame_cnt [i] + 1'd1  ;
                    end
                end
            end
        end
    end
end
reg [01-1:0] rr_cal_blk_frame_sync   [NUM_CC-1:0]    ;
reg [07-1:0] rrr_cal_blk_frame_cnt   [NUM_CC-1:0]    ;
reg [01-1:0] rrr_cal_blk_en          [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        rr_cal_blk_frame_sync[i]  <= r_cal_blk_frame_sync[i]    ;
        if(rr_cal_blk_frame_sync[i]) begin
            rrr_cal_blk_en[i] <= r_cal_blk_en[i]   ;
            rrr_cal_blk_frame_cnt[i] <= r_cal_blk_frame_cnt[i]   ;
        end
    end
end

wire        w_cal_blk_frame_sync    [NUM_CC-1:0]    ;
wire        w_cal_blk_subfrm_sync   [NUM_CC-1:0]    ;
wire        w_cal_blk_slot_sync     [NUM_CC-1:0]    ;
wire        w_cal_blk_symbol_sync   [NUM_CC-1:0]    ;
wire [3:0]  w_cal_blk_subfrm        [NUM_CC-1:0]    ;
wire [7:0]  w_cal_blk_slot          [NUM_CC-1:0]    ;
wire [3:0]  w_cal_blk_symbol        [NUM_CC-1:0]    ;
reg         r_cal_blk_symbol_sync   [NUM_CC-1:0]    ;
reg [3:0]   r_cal_blk_symbol        [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_cal_blk_symbol_sync[i]  <= w_cal_blk_symbol_sync[i]    ;
        if(w_cal_blk_symbol_sync[i]) begin
            r_cal_blk_symbol[i] <= w_cal_blk_symbol[i]   ;
        end
    end
end
reg [01-1:0]                    r_dl_cal_en             [NUM_CC-1:0]    ;
reg [01-1:0]                    r_ul_cal_en             [NUM_CC-1:0]    ;
reg [01-1:0]                    rr_dl_cal_en            [NUM_CC-1:0]    ;
reg [01-1:0]                    rr_ul_cal_en            [NUM_CC-1:0]    ;
reg [NUM_ANT-1:0]               rr_dl_cal_tx_en         [NUM_CC-1:0]    ;
reg [NUM_ANT-1:0]               rr_ul_cal_tx_en         [NUM_CC-1:0]    ;
reg [01-1:0]                    rr_ul_cal_punc_en       [NUM_CC-1:0]    ;
reg [$clog2(NUM_CAL_PAT)-1:0]   r_cal_pat_buf_re_cnt    [NUM_CC-1:0]    ;
reg [01-1:0]                    r_cal_pat_buf_en        [NUM_CC-1:0]    ;
reg [01-1:0]                    r_cal_pat_buf_wren      [NUM_CC-1:0]    ;
reg [20-1:0]                    r_cal_pat_buf_addr      [NUM_CC-1:0]    ;
reg [2*BW_CALP-1:0]             r_cal_pat_buf_wdata     [NUM_CC-1:0]    ;
reg [01-1:0]                    r_cal_pat_buf_rden      [NUM_CC-1:0]    ;
wire[2*BW_CALP-1:0]             w_cal_pat_buf_rdata     [NUM_CC-1:0]            ;
reg [01-1:0]                    rr_cal_pat_buf_rden     [NUM_CC-1:0][DLY_RD:0]  ;
reg [2*BW_CALP-1:0]             rr_cal_pat_buf_rdata    [NUM_CC-1:0][DLY_RD:0]  ;
reg [01-1:0]                    rr_cal_pat_buf_en       [NUM_CC-1:0][DLY_RD:0]  ;
reg [2*BW_CALP-1:0]             rr_cal_pat_cpu_rdata    [NUM_CC-1:0][DLY_RD:0]  ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_1_cal_pat_mem
always@(posedge i_clk) begin
    if(r_cpu_wren[gidx]&&r_cpu_addr[gidx]>=(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*gidx)&&r_cpu_addr[gidx]<(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*(gidx+1))) begin
        r_cal_pat_buf_en    [gidx]  <=  1'd0                                                        ;
        r_cal_pat_buf_wren  [gidx]  <=  r_cpu_wren[gidx]   ;
        r_cal_pat_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*gidx))>>2    ; 
        r_cal_pat_buf_wdata [gidx]  <=  r_cpu_wdata[gidx]  ;
        r_cal_pat_buf_rden  [gidx]  <=  1'd0                                                        ;
    end
    else if(r_cpu_rden[gidx]&&r_cpu_addr[gidx]>=(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*gidx)&&r_cpu_addr[gidx]<(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*(gidx+1))) begin
        r_cal_pat_buf_en    [gidx]  <=  1'd0                                                        ;
        r_cal_pat_buf_wren  [gidx]  <=  1'd0                                                        ;
        r_cal_pat_buf_addr  [gidx]  <= (r_cpu_addr[gidx]-(CAL_PAT_START_ADDR+CAL_PAT_ADDR_OFFSET*gidx))>>2    ; 
        r_cal_pat_buf_rden  [gidx]  <=  r_cpu_rden[gidx]   ;
    end
    else if(r_dl_cal_en[gidx]||r_ul_cal_en[gidx]) begin
        r_cal_pat_buf_wren  [gidx]  <=  1'd0  ;
        r_cal_pat_buf_rden  [gidx]  <=  1'd0  ;
        r_cal_pat_buf_en    [gidx]  <= |r_en[gidx][DLY_CAL_PAT-1]  ;
        if(r_cal_blk_symbol_sync[gidx]) begin
            r_cal_pat_buf_addr  [gidx]  <= r_cal_blk_symbol[gidx][0] ? {7'd0,{NUM_CAL_PAT>>1}} : 20'd0 ;
        end
        else if(|r_en[gidx][DLY_CAL_PAT]) begin
            r_cal_pat_buf_addr  [gidx]  <=  r_cal_pat_buf_addr[gidx] + 1'd1 ;
        end
    end
    else if(r_cal_mem_init[gidx]) begin
        r_cal_pat_buf_wren  [gidx]  <=  r_cal_mem_init_en[gidx]     ;
        r_cal_pat_buf_addr  [gidx]  <= {{{20-$clog2(NUM_CAL_PAT)}{1'd0}},r_cal_mem_init_addr[gidx]} ;
        r_cal_pat_buf_wdata [gidx]  <=  {{2*DO_BW}{1'd0}}           ;
    end
    else begin
        r_cal_pat_buf_en    [gidx]  <=  1'd0  ;
        r_cal_pat_buf_wren  [gidx]  <=  1'd0  ;
        r_cal_pat_buf_rden  [gidx]  <=  1'd0  ;
    end
end
ylib_rams_sp_wf #(
    .WIDTH  (   2*BW_CALP               )
   ,.DEPTH  (   2**$clog2(NUM_CAL_PAT)  )
   ,.VENDOR (   VENDOR                  )) 
u00_0_cal_pat_mem (
    .clk    (i_clk                                                                      )
   ,.we     (r_cal_pat_buf_wren[gidx]                                                   )
   ,.en     (r_cal_pat_buf_en[gidx]|r_cal_pat_buf_wren[gidx]|r_cal_pat_buf_rden[gidx]   )
   ,.addr   (r_cal_pat_buf_addr[gidx][$clog2(NUM_CAL_PAT)-1:0]                          )
   ,.di     (r_cal_pat_buf_wdata[gidx]                                                  )
   ,.dout   (w_cal_pat_buf_rdata[gidx]                                                  )
);
always@(posedge i_clk) begin
    rr_cal_pat_buf_en[gidx][0] <= r_cal_pat_buf_en[gidx]  ;
    rr_cal_pat_buf_rden[gidx][0] <= r_cal_pat_buf_rden[gidx]  ;
end
always@(*) begin
    rr_cal_pat_cpu_rdata[gidx][0] = w_cal_pat_buf_rdata[gidx] ;
    rr_cal_pat_cpu_rdata[gidx][0] = w_cal_pat_buf_rdata[gidx] ;
    rr_cal_pat_buf_rdata[gidx][0][(BW_CALP*(1+1)-1)-:BW_CALP] = $signed(w_cal_pat_buf_rdata[gidx][(BW_CALP*(1+1)-1)-:BW_CALP])>>>SHIFT_A_COMP_XCAL  ;
    rr_cal_pat_buf_rdata[gidx][0][(BW_CALP*(0+1)-1)-:BW_CALP] = $signed(w_cal_pat_buf_rdata[gidx][(BW_CALP*(0+1)-1)-:BW_CALP])>>>SHIFT_A_COMP_XCAL  ;
end
if(DLY_RD>0) begin
always@(posedge i_clk) begin
    for(i=1;i<=DLY_RD;i=i+1) begin
        rr_cal_pat_buf_en[gidx][i] <= rr_cal_pat_buf_en[gidx][i-1]  ;
        if(rr_cal_pat_buf_en[gidx][i-1]) begin
            rr_cal_pat_buf_rdata[gidx][i]  <=  rr_cal_pat_buf_rdata[gidx][i-1]  ;
        end
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_RD;i=i+1) begin
        rr_cal_pat_buf_rden[gidx][i] <= rr_cal_pat_buf_rden[gidx][i-1]   ;
        if(rr_cal_pat_buf_rden[gidx][i-1]) begin
            rr_cal_pat_cpu_rdata[gidx][i] <= rr_cal_pat_cpu_rdata[gidx][i-1]  ;
        end
    end
end
end//if(DLY_RD>1)
always@(posedge i_clk) begin
    if(rr_cal_pat_buf_rden[gidx][DLY_RD]) begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)] <= rr_cal_pat_buf_rden [gidx][DLY_RD] ; 
        o_cpu_rdata     [((32)*(gidx+1)-1)-:(32)] <= rr_cal_pat_cpu_rdata[gidx][DLY_RD] ;
    end
    else begin
        o_cpu_rd_valid  [((01)*(gidx+1)-1)-:(01)] <= 1'd0 ;
    end
end
end
endgenerate// g00_0_cal_pat_mem

reg  [$clog2(NUM_ANT):0]        r_dl_cal_tx_cnt      [NUM_CC-1:0] ;
reg  [$clog2(NUM_ANT):0]        r_ul_cal_tx_cnt      [NUM_CC-1:0] ;
reg  [$clog2(NUM_ANT)-1:0]      r_dl_cal_tx_2sym_cnt [NUM_CC-1:0] ;
reg  [02-1:0]                   r_cals_cal_en        [NUM_CC-1:0] ;
reg  [NUM_ANT-1:0]              r_cals_pat_en        [NUM_CC-1:0] ; 
reg  [2*DO_BW-1:0]              r_cals_pat_iq        [NUM_CC-1:0] ; 
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g01_cal_schlr
ref_vsync_gen u01_cals_rtg
(
     .i_clk                 ( i_clk                             )          
    ,.i_mu                  ({1'd0,r_calScsType     [gidx]}     )
    ,.i_retard              ( DLY_CAL_EN                        )
    ,.i_frame_sync          ( r_cal_blk_frame_sync  [gidx]      )
    ,.i_en                  ( r_cal_blk_en          [gidx]      )          
    ,.o_frame_sync          ( w_cal_blk_frame_sync  [gidx]      )   
    ,.o_subfrm_sync         ( w_cal_blk_subfrm_sync [gidx]      )   
    ,.o_slot_sync           ( w_cal_blk_slot_sync   [gidx]      )   
    ,.o_symbol_sync         ( w_cal_blk_symbol_sync [gidx]      )   
    ,.o_subfrm              ( w_cal_blk_subfrm      [gidx]      )          
    ,.o_slot                ( w_cal_blk_slot        [gidx]      )          
    ,.o_symbol              ( w_cal_blk_symbol      [gidx]      )          
);
always@(posedge i_clk) begin
    if(rrr_cal_blk_en[gidx]) begin
        r_dl_cal_en[gidx] <=  ((|(({{{NUM_SLOT_FRAME-1}{1'b0}},1'b1}<<w_cal_blk_slot[gidx])&r_dlCalSlotMap[gidx][NUM_SLOT_FRAME-1:0])) & (|(({{{NUM_SYMBOL_SLOT-1}{1'b0}},1'b1}<<w_cal_blk_symbol[gidx])&r_dlCalSymbolMap[gidx])))    ;
        r_ul_cal_en[gidx] <=  ((|(({{{NUM_SLOT_FRAME-1}{1'b0}},1'b1}<<w_cal_blk_slot[gidx])&r_ulCalSlotMap[gidx][NUM_SLOT_FRAME-1:0])) & (|(({{{NUM_SYMBOL_SLOT-1}{1'b0}},1'b1}<<w_cal_blk_symbol[gidx])&r_ulCalSymbolMap[gidx])))    ;
    end
end
always@(posedge i_clk) begin
    if(r_dl_cal_en[gidx]&&(rrr_cal_blk_frame_cnt[gidx]<r_nDlCalFramePerCalBlock[gidx])) begin
        rr_dl_cal_en[gidx] <=  r_dl_cal_en[gidx] ;
    end
    else begin
        rr_dl_cal_en[gidx] <=  1'd0 ;
    end
    if(r_ul_cal_en[gidx]&&(rrr_cal_blk_frame_cnt[gidx]<r_nUlCalFramePerCalBlock[gidx])) begin
        rr_ul_cal_en[gidx] <=  r_ul_cal_en[gidx] ;
    end
    else begin
        rr_ul_cal_en[gidx] <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(r_cal_trig[gidx]||(w_cal_blk_frame_sync[gidx]&&r_cal_blk_frame_cnt[gidx]==7'd0)) begin
        r_dl_cal_tx_cnt     [gidx]  <= {{$clog2(NUM_ANT+1)}{1'b0}} ; 
        r_dl_cal_tx_2sym_cnt[gidx]  <= {{$clog2(NUM_ANT)}{1'b0}} ; 
    end
    else if((r_dl_cal_en[gidx]&w_cal_blk_symbol_sync[gidx])&&(rrr_cal_blk_frame_cnt[gidx]<r_nDlCalFramePerCalBlock[gidx])) begin
        r_dl_cal_tx_cnt[gidx] <= r_dl_cal_tx_cnt[gidx] + 1'd1 ; 
        if(r_dl_cal_tx_cnt[gidx][0]) begin
            if(r_dl_cal_tx_2sym_cnt[gidx]==r_nDlCalAntPerCalBlock[gidx]-1'd1) begin
                r_dl_cal_tx_2sym_cnt[gidx]  <= {{$clog2(NUM_ANT)}{1'b0}} ; 
            end
            else begin
                r_dl_cal_tx_2sym_cnt[gidx] <= r_dl_cal_tx_2sym_cnt[gidx] + r_nDlCalAntPer2Syms[gidx] ; 
            end
        end
    end
end
always@(posedge i_clk) begin
    if(r_dl_cal_en[gidx]&&(rrr_cal_blk_frame_cnt[gidx]<r_nDlCalFramePerCalBlock[gidx])) begin
        if(r_nDlCalAntPer2Syms[gidx]==7'd0) begin
            rr_dl_cal_tx_en[gidx] <= {{$clog2(NUM_ANT)}{1'b0}} ; 
        end
        else if(r_nDlCalAntPer2Syms[gidx]==7'd1) begin
            rr_dl_cal_tx_en[gidx] <= {{{NUM_ANT-1}{1'b0}},1'b1}<<r_dl_cal_tx_2sym_cnt[gidx] ; 
        end
        else begin
            rr_dl_cal_tx_en[gidx] <= (({{{NUM_ANT-1}{1'b0}},1'b1}<<r_nDlCalAntPer2Syms[gidx])-1'd1)<<r_dl_cal_tx_2sym_cnt[gidx] ; 
        end
    end
    else begin
        rr_dl_cal_tx_en[gidx] <= {{$clog2(NUM_ANT)}{1'b0}} ; 
    end
end
always@(posedge i_clk) begin
    if(r_cal_trig[gidx]||(w_cal_blk_frame_sync[gidx]&&r_cal_blk_frame_cnt[gidx]==7'd0)) begin
        r_ul_cal_tx_cnt   [gidx] <= {{$clog2(NUM_ANT+1)}{1'b0}}  ; 
        rr_ul_cal_tx_en   [gidx] <= {{$clog2(NUM_ANT)}{1'b0}}    ; 
        rr_ul_cal_punc_en [gidx] <=  1'd0    ;
    end
    else if(r_ul_cal_en[gidx]&&(rrr_cal_blk_frame_cnt[gidx]<r_nUlCalFramePerCalBlock[gidx])) begin
        if(w_cal_blk_symbol_sync[gidx]) begin
            r_ul_cal_tx_cnt [gidx] <= r_ul_cal_tx_cnt[gidx] + 1'd1 ;
        end
        if(r_calPath[gidx]==1'd0) begin
            rr_ul_cal_tx_en[gidx] <= {{{NUM_ANT-1}{1'b0}},1'b1}<<r_mainPath[gidx] ; 
        end
        else begin
            rr_ul_cal_tx_en[gidx] <= {{{NUM_ANT-1}{1'b0}},1'b1}<<r_redundancyPath[gidx] ; 
        end
        rr_ul_cal_punc_en [gidx] <= r_ul_cal_tx_cnt[gidx][0] ;
    end
    else begin
        rr_ul_cal_tx_en   [gidx] <= {{$clog2(NUM_ANT)}{1'b0}} ; 
        rr_ul_cal_punc_en [gidx] <= 1'd0    ;
    end
end
always@(posedge i_clk) begin
    r_cals_cal_en [gidx] <= {rr_ul_cal_en[gidx],rr_dl_cal_en[gidx]|rr_ul_cal_punc_en[gidx]} ;  
end
always@(posedge i_clk) begin
    if(rr_cal_pat_buf_en[gidx][DLY_RD]) begin
        if(|rr_dl_cal_tx_en[gidx]) begin
            r_cals_pat_en [gidx] <= rr_dl_cal_tx_en[gidx] ;
            r_cals_pat_iq [gidx][(DO_BW*(1+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[gidx][DLY_RD][(BW_CALP*(1+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;
            r_cals_pat_iq [gidx][(DO_BW*(0+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[gidx][DLY_RD][(BW_CALP*(0+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;
        end
        else if(|rr_ul_cal_tx_en[gidx]) begin
            r_cals_pat_en [gidx][i] <= rr_ul_cal_tx_en[gidx] ;
            r_cals_pat_iq [gidx][(DO_BW*(1+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[gidx][DLY_RD][(BW_CALP*(1+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;
            r_cals_pat_iq [gidx][(DO_BW*(0+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[gidx][DLY_RD][(BW_CALP*(0+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;
        end
        else begin
            r_cals_pat_en [gidx][i] <= {{NUM_ANT}{1'b0}} ;
        end
    end
end
always@(*) begin
    o_cals_bcf_en[gidx] = r_cal_en [gidx] ;
end
end
endgenerate// g01_cal_schlr
always@(*) begin
    o_cals_cal_en   = r_cals_cal_en [CC_ID_REF] ;
    o_cals_pat_en   = r_cals_pat_en [CC_ID_REF] ;
    o_cals_pat_iq   = r_cals_pat_iq [CC_ID_REF] ;
    o_cals_punc_len = i_dlfe_par_d068 ;
end
`else// DLFE_EXT_BFCAL_DISABLE
reg [01-1:0]    r_frame_sync            ;
reg [01-1:0]    r_cals_frame_sync       ;
reg [01-1:0]    r_cals_pat_symbol_sync  ;
reg [12-1:0]    r_ntone                 ;
always@(posedge i_clk) begin
    r_cals_frame_sync       <=  i_cals_frame_sync ;
    r_frame_sync            <=  i_cals_frame_sync&~r_cals_frame_sync ;
    r_cals_pat_symbol_sync  <=  i_cals_pat_symbol_sync ;
    if(i_cals_frame_sync&~r_cals_frame_sync) begin
        r_ntone <=  i_dlfe_par_120c ;
    end
end
reg r_cals_pat_rd_en ;
reg [$clog2(MAX_RB*NUM_RE_RB)-1:0] r_cals_pat_rd_cnt ;
reg r_en [DLY_CAL_PAT:0] ;
always@(posedge i_clk) begin
    if(r_cals_pat_symbol_sync) begin
        r_cals_pat_rd_en    <=  1'd0 ;
        r_cals_pat_rd_cnt   <=  {{$clog2(MAX_RB*NUM_RE_RB)}{1'd0}} ;
    end
    else if(r_cals_pat_rd_cnt<r_ntone) begin
        r_cals_pat_rd_en    <=  1'd1 ;
        r_cals_pat_rd_cnt   <=  r_cals_pat_rd_cnt + 1'd1 ;
    end
    else if(r_cals_pat_rd_cnt==r_ntone) begin
        r_cals_pat_rd_en    <=  1'd0 ;
    end
end
always@(*) begin
    r_en[0] = r_cals_pat_rd_en ;
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_CAL_PAT;i=i+1) begin
        r_en[i] <= r_en[i-1] ;
    end
end
wire [01-1:0]       w_ext_dl_cal_en             ;
wire [01-1:0]       w_ext_ul_cal_en             ;
wire [01-1:0]       w_ext_ul_cal_punc_en        ;
wire [NUM_ANT-1:0]  w_ext_dl_cal_tx_en          ;
wire [NUM_ANT-1:0]  w_ext_ul_cal_tx_en          ;
wire [16-1:0]       w_ext_dl_cal_buf_sel        ;
wire [16-1:0]       w_ext_ul_cal_buf_sel        ;
wire [08-1:0]       w_ext_dl_cal_wght_idx       ;
wire [01-1:0]       w_ext_ul_cal_wght_idx       ;
wire [01-1:0]       w_ext_dl_cal_acc_en         ;
wire [01-1:0]       w_ext_ul_cal_acc_en         ;
wire [01-1:0]       w_ext_dl_cal_last_symbol    ;
wire [01-1:0]       w_ext_ul_cal_last_symbol    ;
wire [01-1:0]       w_ext_dl_cal_slot_en        ;
wire [01-1:0]       w_ext_ul_cal_slot_en        ;
wire [16-1:0]       w_ext_ul_cal_rx_en          ;
BF_CAL_CTRL #(
     .ANT_NUM   (   NUM_ANT     )
    ,.LCP_POS   (   0           ))
u00_BF_CAL_CTRL
(
    .RESET                          (   i_rst                               )
   ,.CLK                            (   i_clk                               )
   ,.LTE_tech                       (   i_bcf_lte_tech                      )
   ,.BCF_ENB                        (   i_bcf_en                            )
   ,.BFN_STRB                       (   i_bcf_bfn_strb                      )
   ,.BCF_CAL_PATH_SEL               (   i_bcf_cal_path_sel                  )
   ,.BCF_CAL_MAIN_PATH_NUM          (   i_bcf_cal_main_path_num             )
   ,.BCF_CAL_REDUN_PATH_NUM         (   i_bcf_cal_redun_path_num            )
   ,.BCF_CAL_SFNBLK_FRM_NUM         (   i_bcf_cal_sfnblk_frm_num            )
   ,.BCF_DL_CAL_FRM_NUM             (   i_bcf_dl_cal_frm_num                )
   ,.BCF_DL_CAL_SLOT_MAP            (   i_bcf_dl_cal_slot_map               )
   ,.BCF_DL_CAL_SYMBOL_MAP          (   i_bcf_dl_cal_symbol_map             )
   ,.BCF_DL_CAL_ACC_NUM             (   i_bcf_dl_cal_acc_num                )
   ,.BCF_DL_CAL_NUM_PER_2SYM        (   i_bcf_dl_cal_num_per_2sym           )
   ,.BCF_DL_CAL_NUM_PER_FRM         (   i_bcf_dl_cal_num_per_frm            )
   ,.BCF_UL_CAL_FRM_NUM             (   i_bcf_ul_cal_frm_num                )
   ,.BCF_UL_CAL_SLOT_MAP            (   i_bcf_ul_cal_slot_map               )
   ,.BCF_UL_CAL_SYMBOL_MAP          (   i_bcf_ul_cal_symbol_map             )
   ,.BCF_UL_CAL_ACC_NUM             (   i_bcf_ul_cal_acc_num                )
   ,.BCF_UL_CAL_NUM_PER_2SYM        (   i_bcf_ul_cal_num_per_2sym           )
   ,.BCF_UL_CAL_NUM_PER_FRM         (   i_bcf_ul_cal_num_per_frm            )
   ,.DL_CAL_EN                      (   w_ext_dl_cal_en                     )
   ,.UL_CAL_EN                      (   w_ext_ul_cal_en                     )
   ,.UL_CAL_PUNC_EN                 (   w_ext_ul_cal_punc_en                )
   ,.DL_CAL_TX_EN                   (   w_ext_dl_cal_tx_en                  )
   ,.UL_CAL_TX_EN                   (   w_ext_ul_cal_tx_en                  )
   ,.DL_CAL_BUF_SEL                 (   w_ext_dl_cal_buf_sel                )
   ,.UL_CAL_BUF_SEL                 (   w_ext_ul_cal_buf_sel                )
   ,.DL_CAL_WGHT_IDX                (   w_ext_dl_cal_wght_idx               )
   ,.UL_CAL_WGHT_IDX                (   w_ext_ul_cal_wght_idx               )
   ,.DL_CAL_ACC_EN                  (   w_ext_dl_cal_acc_en                 )
   ,.UL_CAL_ACC_EN                  (   w_ext_ul_cal_acc_en                 )
   ,.DL_CAL_LAST_SYMBOL             (   w_ext_dl_cal_last_symbol            )
   ,.UL_CAL_LAST_SYMBOL             (   w_ext_ul_cal_last_symbol            )
   ,.DL_CAL_SLOT_EN                 (   w_ext_dl_cal_slot_en                )
   ,.UL_CAL_SLOT_EN                 (   w_ext_ul_cal_slot_en                )
   ,.UL_CAL_RX_EN                   (   w_ext_ul_cal_rx_en                  )
);
reg r_cal_sym_cnt ;
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        r_cal_sym_cnt <= 1'd0 ;
    end
    else if((|w_ext_dl_cal_tx_en)||(|w_ext_ul_cal_tx_en)) begin
        if(~r_en[DLY_CAL_PAT-DLY_EXT_PAT_BUF]&r_en[DLY_CAL_PAT]) begin
            r_cal_sym_cnt <= ~r_cal_sym_cnt ;
        end
    end
end
always@(posedge i_clk) begin
    if((|w_ext_dl_cal_tx_en)||(|w_ext_ul_cal_tx_en)) begin
        o_cal_pat_buf_rden <= r_en[DLY_CAL_PAT-DLY_EXT_PAT_BUF-1] ;
        if(r_en[DLY_CAL_PAT-DLY_EXT_PAT_BUF-1]&~r_en[DLY_CAL_PAT-DLY_EXT_PAT_BUF]) begin
            if(r_cal_sym_cnt==1'd0) begin
                o_cal_pat_buf_addr <= EXT_PAT_BUF_BASE_ADDR+(EXT_PAT_BUF_CELL_OFFSET*CC_ID) ;
            end
            else begin
                o_cal_pat_buf_addr <= EXT_PAT_BUF_BASE_ADDR+(EXT_PAT_BUF_CELL_OFFSET*CC_ID)+EXT_PAT_BUF_SYMBOL_OFFSET ;
            end
        end
        else if(r_en[DLY_CAL_PAT-DLY_EXT_PAT_BUF]) begin
            o_cal_pat_buf_addr <= o_cal_pat_buf_addr + 32'd4 ;
        end
    end
end
always@(posedge i_clk) begin
    o_cals_cal_en <= {w_ext_ul_cal_en,w_ext_dl_cal_en|w_ext_ul_cal_punc_en} ;  
end
reg [2*BW_CALP-1:0] rr_cal_pat_buf_rdata ;
always@(*) begin
    rr_cal_pat_buf_rdata[(BW_CALP*(1+1)-1)-:BW_CALP] = $signed(i_cal_pat_buf_rdata[(BW_CALP*(1+1)-1)-:BW_CALP])>>>SHIFT_A_COMP_XCAL ;
    rr_cal_pat_buf_rdata[(BW_CALP*(0+1)-1)-:BW_CALP] = $signed(i_cal_pat_buf_rdata[(BW_CALP*(0+1)-1)-:BW_CALP])>>>SHIFT_A_COMP_XCAL ;
end
always@(posedge i_clk) begin
    if(|w_ext_dl_cal_tx_en&r_en[DLY_CAL_PAT]) begin
        o_cals_pat_en <= w_ext_dl_cal_tx_en ;  
        o_cals_pat_iq[(DO_BW*(1+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[(BW_CALP*(1+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;  
        o_cals_pat_iq[(DO_BW*(0+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[(BW_CALP*(0+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;  
    end
    else if(|w_ext_ul_cal_tx_en&r_en[DLY_CAL_PAT]) begin
        o_cals_pat_en <= w_ext_ul_cal_tx_en ;  
        o_cals_pat_iq[(DO_BW*(1+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[(BW_CALP*(1+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;  
        o_cals_pat_iq[(DO_BW*(0+1)-1)-:DO_BW] <= rr_cal_pat_buf_rdata[(BW_CALP*(0+1)-(BW_CALP-DO_BW)-1)-:DO_BW] ;  
    end
    else begin
        o_cals_pat_en <= {{NUM_ANT}{1'b0}} ;  
    end
end
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        o_cals_bcf_en[i] = i_bcf_en ;
        o_cals_punc_len[((12)*(i+1)-1)-:(12)] = i_bcf_ul_punc_length ;
    end
end
BCF_FRSYNC_MON u01_BCF_FRSYNC_MON
(
    .CLK_BLK                          ( i_clk                           )
   ,.BCF_EN_BLKCLK_IN                 ( i_bcf_en                        )
   ,.FRSYNC_BLKCLK_IN                 ( i_bcf_bfn_strb                  )
   ,.BCF_EN_FSCNT_CLR_EN_IN           ( i_dlfe_par_10c0                 )
   ,.BCF_FS_ERR_FLAG_BLKCLK_OUT       ( o_bcf_fs_err_flag_blkclk_out    )
   ,.BCF_EN_FSCNT_BLKCLK_OUT          ( o_bcf_en_fscnt_blkclk_out       )
   ,.BCF_RPLS_CLKCNT_BLKCLK_OUT       ( o_bcf_rpls_clkcnt_blkclk_out    )
   ,.BCF_EN_SFNCNT_BLKCLK_OUT         ( o_bcf_en_sfncnt_blkclk_out      )
   ,.CLK_CPU                          (                                 )
   ,.BCF_FS_ERR_FLAG_CPUCLK_OUT       (                                 )
   ,.BCF_EN_FSCNT_CPUCLK_OUT          (                                 )
   ,.BCF_RPLS_CLKCNT_CPUCLK_OUT       (                                 )
   ,.BCF_EN_SFNCNT_CPUCLK_OUT         (                                 )
);
`endif// DLFE_EXT_BFCAL_DISABLE
endmodule
