////////////////////////////////////////////////////////////////////////////////
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10, FSU20
//                 oRU : DCM RT44xx, VzW RT8808
//                 RU  : Telus RT8809
//  Module       : dlfe_ofdm_mod
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe OFDM Modulation (configurable cell multiplexing) 
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.15 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.10.19 | jyzoo.lee     | Xilinx Support
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.12.16 | jyzoo.lee     | Supports Xilinx 4k IFFT
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Supports Processing for Calibraion Symbol
//  ------------+---------------+-----------------------------------------------
//   2021.03.30 | jyzoo.lee     | AIE IFFT Support
//  ------------+---------------+-----------------------------------------------
//   2021.05.18 | jyzoo.lee     | Optimized Memory for AIE IFFT Interface 
//  ------------+---------------+-----------------------------------------------
//   2021.06.01 | jyzoo.lee     | Add the Watchdog for AIE IFFT
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_ofdm_mod
#(
     parameter  NUM_CC              =   1           
    ,parameter  NUM_ANT             =   4
    ,parameter  NUM_I_CHAIN         =   1
    ,parameter  NUM_O_CHAIN         =   1
    ,parameter  MAX_NIFFT           =   2048 
    ,parameter  DI_BW               =   16           
    ,parameter  DO_BW               =   16           
`ifndef DLFE_AIE_DISABLE
    ,parameter  DIO_BW_AIE          =  `DLFE_DIO_BW_AIE
    ,parameter  DIO_NB_AIE          =  `DLFE_DIO_NB_AIE
`endif //DLFE_AIE_DISABLE
    ,parameter  VENDOR              =   "Intel"
)(
    //--- reset & clk
        input   wire                                            i_rst                
    ,   input   wire                                            i_clk                  
            
    //--- from dlfe_param_if
    ,   input   wire    [22*NUM_CC-1:0]                         i_dlfe_par_1050
    ,   input   wire    [03*NUM_CC-1:0]                         i_dlfe_par_1208
    
    //--- from dlfe_ifft_mapper
    ,   input   wire    [01-1:0]                                i_din_frame_sync
    ,   input   wire    [01-1:0]                                i_din_symbol_sync
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_en        
    ,   input   wire    [2*DI_BW*NUM_I_CHAIN-1:0]               i_din_iq                
    ,   input   wire    [01*NUM_I_CHAIN-1:0]                    i_din_cc_id
    ,   input   wire    [$clog2(NUM_ANT)*NUM_I_CHAIN-1:0]       i_din_ant_id
    ,   input   wire    [03-1:0]                                i_din_mu      
    ,   input   wire    [04*NUM_CC-1:0]                         i_din_fft_size
    ,   input   wire    [02-1:0]                                i_din_cal_en

    //--- to dlfe_ant_scale
    ,   output  reg     [01-1:0]                                o_dout_frame_sync
    ,   output  reg     [01-1:0]                                o_dout_symbol_sync
    ,   output  reg     [04-1:0]                                o_dout_symbol_idx
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_en
    ,   output  reg     [2*DO_BW*NUM_O_CHAIN-1:0]               o_dout_iq        
    ,   output  reg     [01*NUM_O_CHAIN-1:0]                    o_dout_cc_id
    ,   output  reg     [$clog2(NUM_ANT)*NUM_O_CHAIN-1:0]       o_dout_ant_id
    ,   output  reg     [02-1:0]                                o_dout_cal_en

`ifndef DLFE_AIE_DISABLE
    ,   input   wire                                            i_aie_clk
    ,   input   wire    [01*NUM_CC-1:0]                         i_aie_rst
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tready
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tvalid
    ,   output  wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]             o_aie_ifft_tdata
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tlast
    ,   output  wire    [DIO_BW_AIE/8*DIO_NB_AIE-1:0]           o_aie_ifft_tkeep
    ,   output  wire    [01*DIO_NB_AIE-1:0]                     o_aie_ifft_tready
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tvalid
    ,   input   wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]             i_aie_ifft_tdata
    ,   input   wire    [01*DIO_NB_AIE-1:0]                     i_aie_ifft_tlast
`endif// DLFE_AIE_DISABLE
    ,   output  wire    [22*NUM_CC-1:0]                         o_dlfe_rpt_1040
    ,   output  wire    [22*NUM_CC-1:0]                         o_dlfe_rpt_1044
);

//Parameter Local Logic
localparam      CC_REF                      =       0                                                                   ;
localparam      CHAIN_REF                   =       0                                                                   ;
localparam      BW_IFFT_IN                  =       16                                                                  ;
localparam      BW_IFFT_OUT                 =       28                                                                  ;
localparam      BW_SCALE_A                  =       35                                                                  ;
localparam      BW_SHIFTA                   =       6                                                                   ;
localparam      NFFT_0512                   =       13'd512                                                             ;
localparam      NFFT_1024                   =       13'd1024                                                            ;
localparam      NFFT_2048                   =       13'd2048                                                            ;
localparam      NFFT_4096                   =       13'd4096                                                            ;
localparam      DLY_THIS                    =       22'd3                                                               ;
localparam      ORAN_FFT0512                =       4'h9                                                                ;
localparam      ORAN_FFT1024                =       4'ha                                                                ;
localparam      ORAN_FFT2048                =       4'hb                                                                ;
localparam      ORAN_FFT4096                =       4'hc                                                                ;
localparam      DLY_RST                     =       3                                                                   ;
localparam      DLY_NIFFT_0512              =       VENDOR=="Intel" ? 22'd666 +DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd1158+22'd3-NFFT_0512+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd1152-NFFT_0512+DLY_THIS : 22'd0   ;
localparam      DLY_NIFFT_1024              =       VENDOR=="Intel" ? 22'd1169+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd2182+22'd3-NFFT_1024+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd2195-NFFT_1024+DLY_THIS : 22'd0   ;
localparam      DLY_NIFFT_2048              =       VENDOR=="Intel" ? 22'd2214+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd4249+22'd3-NFFT_2048+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd4243-NFFT_2048+DLY_THIS : 22'd0   ;
localparam      DLY_NIFFT_4096              =       VENDOR=="Intel" ? 22'd2214+DLY_THIS : (MAX_NIFFT==NFFT_4096) ? 22'd8345+22'd3-NFFT_4096+DLY_THIS : (MAX_NIFFT==NFFT_2048) ? 22'd0                       : 22'd0   ;
localparam      DLY_MAX_NIFFT               =       DLY_NIFFT_4096                                                      ;
localparam      SHIFT_A_XCAL                =       4                                                                   ;

`ifndef DLFE_AIE_DISABLE
localparam      AIE_IFFT_AXIS00_D00         =       32'h0                           ;
localparam      AIE_IFFT_AXIS00_D01         =       32'h1                           ;
localparam      AIE_IFFT_AXIS00_D02         =       32'h2                           ; 
localparam      AIE_IFFT_AXIS00_D03         =       32'h0                           ;
localparam      AIE_IFFT_AXIS00_D04         =       32'h1                           ;
localparam      PL_SIZE_PACKET_AAI          =       1027                            ;
localparam      AIE_SIZE_PACKET_AAI         =       1024                            ;
localparam      PL2AIE_ASYNC_FIFO_DEPTH     =       16                              ;
localparam      PL2AIE_SYNC_FIFO_DEPTH      =       16                              ;
localparam      AIE2PL_ASYNC_FIFO_DEPTH     =       256                             ;
localparam      AIE2PL_SYNC_FIFO_DEPTH      =       16                              ;
localparam      VALID_STATE_WDOG_PL2AIE     =       2'd0                            ;
localparam      INVALID_STATE_WDOG_PL2AIE   =       2'd1                            ;
localparam      CIN_NFFT_0512               =       {{DIO_NB_AIE/2}{1'b1}}&'d3      ;
localparam      CIN_NFFT_1024               =       {{DIO_NB_AIE/2}{1'b1}}&'d2      ;
localparam      CIN_NFFT_2048               =       {{DIO_NB_AIE/2}{1'b1}}&'d1      ;
localparam      CIN_NFFT_4096               =       {{DIO_NB_AIE/2}{1'b1}}&'d0      ;
`endif//DLFE_AIE_DISABLE

//Logic Variable
genvar gidx ;
integer i   ;

reg [0:0]   r_frame_sync  ;
reg [0:0]   rr_frame_sync ;
reg [8:0]   r_scale_a     ;
reg [2:0]   r_shift_a   [NUM_CC-1:0]    ;
reg [2:0]   r_mu          ;
always@(posedge i_clk) begin
    r_frame_sync    <=  i_din_frame_sync    ;
    rr_frame_sync   <=  r_frame_sync        ;
    if(i_din_frame_sync) begin 
        r_mu    <=  i_din_mu    ;
        for(i=0;i<NUM_CC;i=i+1) begin
            r_shift_a[i] <= i_dlfe_par_1208[((03)*(i+1)-1)-:(03)]   ;
        end
    end
end
reg [3:0] r_fft_size [NUM_CC-1:0] ;
always@(*) begin
    for(i=0;i<NUM_CC;i=i+1) begin
        r_fft_size[i]  =   i_din_fft_size[((04)*(i+1)-1)-:(04)] ;
    end
end
reg [$clog2(MAX_NIFFT)-1:0] r_dly_cnt ;
always@(posedge i_clk) begin
    if(r_frame_sync) begin
        r_dly_cnt <= {{$clog2(MAX_NIFFT)}{1'd0}} ;
    end
    else begin
        r_dly_cnt <= r_dly_cnt + 1'd1 ;
    end
end
reg  [02-1:0]                   r_cal_en                                ;
reg  [$clog2(MAX_NIFFT):0]      r_fft_pts                               ;
reg  [21:0]                     r_ifft_dly                              ;
reg  [21:0]                     r_ifft_dly_comp                         ;
reg  [0:0]                      r_en                [NUM_I_CHAIN-1:0]   ;
reg  [2*DI_BW-1:0]              r_iq                [NUM_I_CHAIN-1:0]   ;   
reg  [0:0]                      r_cc_id             [NUM_I_CHAIN-1:0]   ;
reg  [$clog2(NUM_ANT)-1:0]      r_ant_id            [NUM_I_CHAIN-1:0]   ;   
reg  [0:0]                      r_shift_a_en        [NUM_I_CHAIN-1:0]   ;   
reg  [DI_BW+BW_SHIFTA-1:0]      r_shift_a_i         [NUM_I_CHAIN-1:0]   ;
reg  [DI_BW+BW_SHIFTA-1:0]      r_shift_a_q         [NUM_I_CHAIN-1:0]   ;   
wire [0:0]                      w_shift_a_sat_en    [NUM_I_CHAIN-1:0]   ;   
wire [BW_IFFT_IN-1:0]           w_shift_a_sat_i     [NUM_I_CHAIN-1:0]   ;
wire [BW_IFFT_IN-1:0]           w_shift_a_sat_q     [NUM_I_CHAIN-1:0]   ;   
always@(posedge i_clk) begin
    if(i_din_frame_sync||(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF])) begin
        case(r_fft_size[i_din_cc_id[CHAIN_REF]]) 
            ORAN_FFT0512 :  begin r_fft_pts <= NFFT_0512 ; r_scale_a <= 9'd362 ; r_ifft_dly <= NUM_CC==2 ? DLY_NIFFT_2048 : DLY_NIFFT_0512 ; r_ifft_dly_comp <= DLY_MAX_NIFFT-DLY_NIFFT_0512 ;end
            ORAN_FFT1024 :  begin r_fft_pts <= NFFT_1024 ; r_scale_a <= 9'd256 ; r_ifft_dly <= NUM_CC==2 ? DLY_NIFFT_2048 : DLY_NIFFT_1024 ; r_ifft_dly_comp <= DLY_MAX_NIFFT-DLY_NIFFT_1024 ;end
            ORAN_FFT2048 :  begin r_fft_pts <= NFFT_2048 ; r_scale_a <= 9'd181 ; r_ifft_dly <= NUM_CC==2 ? DLY_NIFFT_2048 : DLY_NIFFT_2048 ; r_ifft_dly_comp <= DLY_MAX_NIFFT-DLY_NIFFT_2048 ;end
            ORAN_FFT4096 :  begin r_fft_pts <= NFFT_4096 ; r_scale_a <= 9'd128 ; r_ifft_dly <= NUM_CC==2 ? DLY_NIFFT_2048 : DLY_NIFFT_4096 ; r_ifft_dly_comp <= DLY_MAX_NIFFT-DLY_NIFFT_4096 ;end
            default      :  begin r_fft_pts <= NFFT_1024 ; r_scale_a <= 9'd256 ; r_ifft_dly <= NUM_CC==2 ? DLY_NIFFT_2048 : DLY_NIFFT_1024 ; r_ifft_dly_comp <= DLY_MAX_NIFFT-DLY_NIFFT_1024 ;end
        endcase
    end
end
always@(posedge i_clk) begin
    if(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF]) begin
        r_cal_en <=  i_din_cal_en ;
    end
end
`ifndef DLFE_AIE_DISABLE
reg  [22-1:0]   r_aie_ifft_proc_dly   [NUM_CC-1:0]    ;
always@(posedge i_clk) begin
    if(i_din_frame_sync) begin 
        for(i=0;i<NUM_CC;i=i+1) begin
            r_aie_ifft_proc_dly[i] <= i_dlfe_par_1050[((22)*(i+1)-1)-:(22)]   ;
        end
    end
end
reg  [DIO_NB_AIE/2-1:0] r_fft_cin   ;
always@(posedge i_clk) begin
    if(i_din_frame_sync||(i_din_en[((01)*(CHAIN_REF+1)-1)-:(01)]&~r_en[CHAIN_REF])) begin
        case(r_fft_size[i_din_cc_id[CHAIN_REF]]) 
            ORAN_FFT0512 :  r_fft_cin <= CIN_NFFT_0512 ;
            ORAN_FFT1024 :  r_fft_cin <= CIN_NFFT_1024 ;
            ORAN_FFT2048 :  r_fft_cin <= CIN_NFFT_2048 ;
            ORAN_FFT4096 :  r_fft_cin <= CIN_NFFT_4096 ;
            default      :  r_fft_cin <= CIN_NFFT_1024 ;
        endcase
    end
end
reg  [1-1:0]            r_shift_a_sat_en    [NUM_I_CHAIN-1:0] ;
reg  [2*BW_IFFT_IN-1:0] r_shift_a_sat_qi    [NUM_I_CHAIN-1:0] ;
reg  [04-1:0]           r_aie_pkt_id        [NUM_I_CHAIN-1:0] ;
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_ofdm_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    end
end
always@(posedge i_clk) begin
    if(~i_din_en[((01)*(gidx+1)-1)-:(01)]&r_en[gidx]) begin
        r_cc_id  [gidx] <=  i_din_cc_id  [((01)*(gidx+1)-1)-:(01)]  ;
        r_ant_id [gidx] <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]  ;
    end
end
always@(posedge i_clk) begin
    r_shift_a_en[gidx]  <=  r_en[gidx]  ;
    if(r_en[gidx]) begin
        if(|r_cal_en) begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
        end
        else begin
          r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]] ; 
          r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]] ; 
        end
    end
end
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_SHIFTA     )
 ,.DO_BW        (   BW_IFFT_IN          ))
u00_shifta_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   r_shift_a_en[gidx]                              )
    ,.i_in      (   {r_shift_a_i[gidx],r_shift_a_q[gidx]}           )
    ,.o_out_en  (   w_shift_a_sat_en[gidx]                          )
    ,.o_out     (   {w_shift_a_sat_i[gidx],w_shift_a_sat_q[gidx]}   )
);
if(gidx==0||gidx==1) begin
always@(*) begin
    r_shift_a_sat_en[gidx] =  w_shift_a_sat_en [gidx] ;
    r_shift_a_sat_qi[gidx] =  {w_shift_a_sat_q[gidx], w_shift_a_sat_i[gidx]} ;
end
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin 
        r_aie_pkt_id[gidx] <=  4'd0 ;
    end
    else if(~r_shift_a_en[gidx]&r_shift_a_sat_en[gidx]) begin
        r_aie_pkt_id[gidx] <=  r_aie_pkt_id[gidx] + 1'd1 ;
    end
end
end//(gidx==0||gidx==1)
else begin //(gidx==0||gidx==1)
always@(posedge i_clk) begin
    r_shift_a_sat_en[gidx] <=  w_shift_a_sat_en [gidx] ;
    if(w_shift_a_sat_en[gidx]) begin
        r_shift_a_sat_qi[gidx] <=  {w_shift_a_sat_q[gidx], w_shift_a_sat_i[gidx]} ;
    end
end
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin 
        r_aie_pkt_id[gidx] <=  4'd0 ;
    end
    else if(~w_shift_a_sat_en[gidx]&r_shift_a_sat_en[gidx]) begin
        r_aie_pkt_id[gidx] <=  r_aie_pkt_id[gidx] + 1'd1 ;
    end
end
end//(gidx==0||gidx==1)
end
endgenerate

reg [DIO_NB_AIE-1:0]    r_aai_in_axis_tvalid ;   
reg [DIO_BW_AIE-1:0]    r_aai_in_axis_tdata  [DIO_NB_AIE-1:0] ;
reg [DIO_NB_AIE-1:0]    r_aai_in_axis_tlast  ;   
reg [DIO_BW_AIE/8-1:0]  r_aai_in_axis_tkeep  [DIO_NB_AIE-1:0] ;   
always@(posedge i_clk) begin : l00_axis0_tvalid_tdata
    if((r_shift_a_en[00]&~r_shift_a_sat_en[00])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_fft_cin,AIE_IFFT_AXIS00_D02} ;
    end
    else if((r_shift_a_sat_en[00]&~r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],AIE_IFFT_AXIS00_D01} ;
    end
    else if(r_shift_a_sat_en[02]&&r_aie_pkt_id[2][0]==1'b0) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],r_shift_a_sat_qi[02]} ;
    end
    else if((r_shift_a_sat_en[00]&~r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b1) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],AIE_IFFT_AXIS00_D00} ;
    end
    else if(r_shift_a_sat_en[02]&&r_aie_pkt_id[2][0]==1'b1) begin
        r_aai_in_axis_tvalid[00] <= 1'd1 ;
        r_aai_in_axis_tdata [00] <= {r_shift_a_sat_qi[00],r_shift_a_sat_qi[02]} ;
    end
    else begin
        r_aai_in_axis_tvalid[00] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l01_axis1_tvalid_tdata
    if((r_shift_a_sat_en[01]&~r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b0) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],AIE_IFFT_AXIS00_D04} ;
    end
    else if(r_shift_a_sat_en[03]&&r_aie_pkt_id[3][0]==1'b0) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],r_shift_a_sat_qi[03]} ;
    end
    else if((r_shift_a_sat_en[01]&~r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],AIE_IFFT_AXIS00_D03} ;
    end
    else if(r_shift_a_sat_en[03]&&r_aie_pkt_id[3][0]==1'b1) begin
        r_aai_in_axis_tvalid[01] <= 1'd1 ;
        r_aai_in_axis_tdata [01] <= {r_shift_a_sat_qi[01],r_shift_a_sat_qi[03]} ;
    end
    else begin
        r_aai_in_axis_tvalid[01] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l02_axis0_tlast_tkeep
    if((r_shift_a_en[00]&~r_shift_a_sat_en[00])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hff;
    end
    else if((~r_shift_a_sat_en[00]&r_shift_a_sat_en[02])&&r_aie_pkt_id[0][0]==1'b0) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hf ;
    end
    else if((~r_shift_a_sat_en[00]&r_shift_a_sat_en[02])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tlast[00] <= 1'd1 ;
        r_aai_in_axis_tkeep[00] <= 8'hf ;
    end
    else begin
        r_aai_in_axis_tlast[00] <= 1'd0 ;
    end
end
always@(posedge i_clk) begin : l03_axis1_tlast_tkeep
    if((~r_shift_a_sat_en[01]&r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b0) begin
        r_aai_in_axis_tlast[01] <= 1'd1 ;
        r_aai_in_axis_tkeep[01] <= 8'hf ;
    end
    else if((~r_shift_a_sat_en[01]&r_shift_a_sat_en[03])&&r_aie_pkt_id[1][0]==1'b1) begin
        r_aai_in_axis_tlast[01] <= 1'd1 ;
        r_aai_in_axis_tkeep[01] <= 8'hf ;
    end
    else begin
        r_aai_in_axis_tlast[01] <= 1'd0 ;
    end
end
wire            w_frame_sync    ;
wire            w_subfrm_sync   ;
wire            w_slot_sync     ;
wire            w_symbol_sync   ;
wire [3:0]      w_subfrm        ;
wire [7:0]      w_slot          ;
wire [3:0]      w_symbol        ;
ref_vsync_gen u01_ifft_rtg
(
     .i_clk                 ( i_clk                         )          
    ,.i_mu                  ( r_mu                          )
    ,.i_retard              ( r_aie_ifft_proc_dly[CC_REF]   )
    ,.i_frame_sync          ( rr_frame_sync                 )          
    ,.i_en                  ( 1'd1                          )          
    ,.o_frame_sync          ( w_frame_sync                  )   
    ,.o_subfrm_sync         ( w_subfrm_sync                 )   
    ,.o_slot_sync           ( w_slot_sync                   )   
    ,.o_symbol_sync         ( w_symbol_sync                 )   
    ,.o_subfrm              ( w_subfrm                      )          
    ,.o_slot                ( w_slot                        )          
    ,.o_symbol              ( w_symbol                      )          
);
wire [01-1:0]                           w_aai_out_axis_tready   [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_aai_out_axis_tvalid   [DIO_NB_AIE-1:0]    ; 
wire [DIO_BW_AIE-1:0]                   w_aai_out_axis_tdata    [DIO_NB_AIE-1:0]    ;
wire [01-1:0]                           w_aai_out_axis_tlast    [DIO_NB_AIE-1:0]    ; 
wire [01-1:0]                           w_aai_out_axis_hd_en    [DIO_NB_AIE-1:0]    ; 
wire [DIO_BW_AIE-1:0]                   w_aai_out_axis_hd       [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           r_aai_out_axis_tvalid   [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           rr_aai_in_axis_tvalid   [DIO_NB_AIE-1:0]    ; 
wire [22-1:0]                           w_aai_inout_proc_dly    [DIO_NB_AIE-1:0]    ; 
reg  [$clog2(NUM_ANT):0]                r_aai_in_blk_id         [DIO_NB_AIE-1:0]    ; 
reg  [$clog2(NUM_ANT)-1:0]              r_aai_out_blk_id        [DIO_NB_AIE-1:0]    ; 
reg  [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_aai_in_wdog_cnt       [DIO_NB_AIE-1:0]    ; 
reg  [02-1:0]                           r_aai_in_wdog_chk       [DIO_NB_AIE-1:0]    ;    
reg  [$clog2(PL_SIZE_PACKET_AAI)-1:0]   r_aai_in_wdog_chk_cnt   [DIO_NB_AIE-1:0]    ; 
reg  [01-1:0]                           r_aai_in_rec_tvalid     [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_in_rec_tlast      [DIO_NB_AIE-1:0]    ;
reg  [01-1:0]                           r_aai_in_rec_done       [DIO_NB_AIE-1:0]    ;
generate for(gidx=0;gidx<DIO_NB_AIE;gidx=gidx+1) begin : g01_aai_aie_ifft_chain
always@(posedge i_clk) begin 
    if(i_rst) begin
        r_aai_in_wdog_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        r_aai_in_rec_tvalid[gidx] <= 1'd0 ;
        r_aai_in_rec_tlast [gidx] <= 1'd0 ;
        r_aai_in_rec_done  [gidx] <= 1'd0 ;
    end
    else if(r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE) begin
        r_aai_in_rec_tvalid[gidx] <= r_aai_in_wdog_cnt[gidx]<=({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&AIE_SIZE_PACKET_AAI) ;
        if(i_din_symbol_sync) begin
            r_aai_in_rec_tvalid[gidx] <= 1'd0 ;
            r_aai_in_rec_tlast [gidx] <= 1'd0 ;
            r_aai_in_rec_done  [gidx] <= 1'd0 ;
        end
        else if(r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI))) begin
            r_aai_in_rec_tlast[gidx] <= 1'd1 ;
            r_aai_in_rec_done [gidx] <= 1'd1 ;
        end
        else begin
            r_aai_in_rec_tlast[gidx] <= 1'd0 ;
        end
        if(i_din_symbol_sync&r_aai_in_rec_done[gidx]) begin
            r_aai_in_wdog_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        end
        else if(r_aai_in_wdog_cnt[gidx]<=({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&AIE_SIZE_PACKET_AAI)) begin
            r_aai_in_wdog_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] + 1'd1 ;
        end
    end
    else if(r_aai_in_wdog_chk[gidx]==VALID_STATE_WDOG_PL2AIE) begin
        if(r_aai_in_axis_tvalid[gidx]) begin
            if(r_aai_in_axis_tlast[gidx]) begin
                if(r_aai_in_wdog_cnt[gidx]==({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))) begin
                    r_aai_in_wdog_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
                end
            end
            else begin
                r_aai_in_wdog_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] + 1'd1 ;
            end
        end
    end
end
always@(posedge i_clk) begin
    if(i_rst) begin
        r_aai_in_wdog_chk_cnt[gidx] <= {{$clog2(PL_SIZE_PACKET_AAI)}{1'd0}} ;
        r_aai_in_wdog_chk[gidx] <= VALID_STATE_WDOG_PL2AIE ;
    end
    else if(i_din_symbol_sync) begin
        r_aai_in_wdog_chk[gidx] <= VALID_STATE_WDOG_PL2AIE ;
    end
    else if(&r_aai_in_axis_tvalid) begin
        if(&r_aai_in_axis_tlast) begin
            if(r_aai_in_wdog_cnt[gidx]!=({{$clog2(PL_SIZE_PACKET_AAI)}{1'd1}}&(AIE_SIZE_PACKET_AAI/2))) begin
                r_aai_in_wdog_chk[gidx] <= INVALID_STATE_WDOG_PL2AIE ;
                if(r_aai_in_wdog_chk[gidx]==VALID_STATE_WDOG_PL2AIE) begin
                    r_aai_in_wdog_chk_cnt[gidx] <= r_aai_in_wdog_cnt[gidx] ;
                end
            end
        end
    end
end
assign  w_aai_out_axis_tready [gidx] = ~r_aai_in_rec_done [gidx] ;
AAI_TOP #(
     .BYPASS_MODE               ( 1                         )
    ,.PL2AIE_EN                 ( 1                         )
    ,.AIE2PL_EN                 ( 1                         )
    ,.PL2AIE_DATA_SIZE          ( DIO_BW_AIE                )
    ,.AIE2PL_DATA_SIZE          ( DIO_BW_AIE                )
    ,.TKEEP_SIZE                ( DIO_BW_AIE/8              )
    ,.PL_HEADER_EN              ( 0                         )
    ,.AIE_HEADER_EN             ( 0                         )
    ,.PL_HEADER_SIZE            ( 8                         )
    ,.AIE_HEADER_SIZE           ( 8                         )
    ,.PL_DATA_PACKET_SIZE       ( PL_SIZE_PACKET_AAI-gidx   )
    ,.AIE_DATA_PACKET_SIZE      ( AIE_SIZE_PACKET_AAI       )
    ,.PL2AIE_ASYNC_FIFO_DEPTH   ( PL2AIE_ASYNC_FIFO_DEPTH   )
    ,.PL2AIE_SYNC_FIFO_DEPTH    ( PL2AIE_SYNC_FIFO_DEPTH    )
    ,.AIE2PL_ASYNC_FIFO_DEPTH   ( AIE2PL_ASYNC_FIFO_DEPTH   )
    ,.AIE2PL_SYNC_FIFO_DEPTH    ( AIE2PL_SYNC_FIFO_DEPTH    ))
u02_aai_axis
(
     .pl2aie_pl_clk             ( i_clk                                                                 )
    ,.pl2aie_aie_clk            ( i_aie_clk                                                             )
    ,.aie2pl_pl_clk             ( i_clk                                                                 )
    ,.aie2pl_aie_clk            ( i_aie_clk                                                             )
    ,.pl_reset                  ( i_rst                                                                 )
    ,.aie_reset                 ( i_aie_rst                                                             )
    ,.cpu_wen                   ( 1'd0                                                                  )
    ,.cpu_waddr                 ( 16'd0                                                                 )
    ,.cpu_wdata                 ( 32'd0                                                                 )
    ,.i_pl_data                 ( r_aai_in_axis_tdata   [gidx]                                          )
    ,.i_pl_dvld                 ( r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE ? r_aai_in_rec_tvalid  [gidx] : r_aai_in_axis_tvalid  [gidx] )
    ,.i_pl_last                 ( r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE ? r_aai_in_rec_tlast   [gidx] : r_aai_in_axis_tlast   [gidx] )
    ,.i_pl_keep                 ( r_aai_in_wdog_chk[gidx]==INVALID_STATE_WDOG_PL2AIE ? 8'hf                        : r_aai_in_axis_tkeep   [gidx] )
    ,.i_head_valid              ( 1'b0                                                                  )
    ,.i_head_data               ( {{DIO_BW_AIE}{1'b0}}                                                  )
    ,.i_p2a_ready               ( i_aie_ifft_tready     [((01)*(gidx+1)-1)-:(01)]                       )
    ,.o_p2a_valid               ( o_aie_ifft_tvalid     [((01)*(gidx+1)-1)-:(01)]                       )
    ,.o_p2a_data                ( o_aie_ifft_tdata      [((DIO_BW_AIE)*(gidx+1)-1)-:(DIO_BW_AIE)]       )
    ,.o_p2a_last                ( o_aie_ifft_tlast      [((01)*(gidx+1)-1)-:(01)]                       )
    ,.o_p2a_keep                ( o_aie_ifft_tkeep      [((DIO_BW_AIE/8)*(gidx+1)-1)-:(DIO_BW_AIE/8)]   )
    ,.o_a2p_ready               ( o_aie_ifft_tready     [((01)*(gidx+1)-1)-:(01)]                       )
    ,.i_a2p_valid               ( i_aie_ifft_tvalid     [((01)*(gidx+1)-1)-:(01)]                       )
    ,.i_a2p_data                ( i_aie_ifft_tdata      [((DIO_BW_AIE)*(gidx+1)-1)-:(DIO_BW_AIE)]       )
    ,.i_a2p_last                ( i_aie_ifft_tlast      [((01)*(gidx+1)-1)-:(01)]                       )
    ,.i_a2p_ready               ( w_aai_out_axis_tready [gidx]                                          )
    ,.o_a2p_dvld                ( w_aai_out_axis_tvalid [gidx]                                          )
    ,.o_a2p_data                ( w_aai_out_axis_tdata  [gidx]                                          )
    ,.o_a2p_last                ( w_aai_out_axis_tlast  [gidx]                                          )
    ,.o_a2p_head_valid          ( w_aai_out_axis_hd_en  [gidx]                                          )
    ,.o_a2p_head_data           ( w_aai_out_axis_hd     [gidx]                                          )
);
always@(posedge i_clk) begin 
    rr_aai_in_axis_tvalid[gidx] <= r_aai_in_axis_tvalid[gidx]  ;
    if(rr_frame_sync) begin
        r_aai_in_blk_id[gidx] <= {{$clog2(NUM_ANT+1)}{1'b0}};
    end
    else if(~r_aai_in_axis_tvalid[gidx]&rr_aai_in_axis_tvalid[gidx]) begin
        r_aai_in_blk_id[gidx]<= r_aai_in_blk_id[gidx]+1'd1;
    end
end
always@(posedge i_clk) begin 
    r_aai_out_axis_tvalid[gidx] <= w_aai_out_axis_tvalid[gidx]  ;
    if(w_frame_sync) begin
        r_aai_out_blk_id[gidx] <= {{$clog2(NUM_ANT)}{1'b0}};
    end
    else if(~w_aai_out_axis_tvalid[gidx]&r_aai_out_axis_tvalid[gidx]) begin
        r_aai_out_blk_id[gidx]<= r_aai_out_blk_id[gidx]+1'd1;
    end
end
ylib_mon_sync_diff #(
    .WIDTH(22)) 
u03_aie_proc_dly
(
     .i_clk     (i_clk                      )
    ,.i_sync0   ((~r_aai_in_axis_tvalid [gidx]&rr_aai_in_axis_tvalid [gidx])&&r_aai_in_blk_id [gidx]=={{$clog2(NUM_ANT+1)}{1'b1}})
    ,.i_sync1   ((~w_aai_out_axis_tvalid[gidx]&r_aai_out_axis_tvalid [gidx])&&r_aai_out_blk_id[gidx]=={{$clog2(NUM_ANT+0)}{1'b1}})
    ,.o_diff    (w_aai_inout_proc_dly[gidx] )
);
end
endgenerate
reg r_sig_det ;
always@(posedge i_clk) begin
    if(i_din_symbol_sync) begin
        r_sig_det <= 1'b0 ;
    end
    else if(|i_din_en) begin
        r_sig_det <= 1'b1 ;
    end
end
reg r_sig_exist ;
always@(posedge i_clk) begin
    if(w_symbol_sync) begin
        r_sig_exist  <= r_sig_det  ;
    end
end
generate for(gidx=0;gidx<NUM_O_CHAIN;gidx=gidx+1) begin : g02_out_chain
always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)] <= w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&r_sig_exist ;
    if(w_frame_sync||(~w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&o_dout_en[((01)*(gidx+1)-1)-:(01)])) begin
        o_dout_cc_id [((01)*(gidx+1)-1)-:(01)] <= r_cc_id [gidx] ;  
    end
    else if(w_aai_out_axis_tvalid[gidx/DIO_NB_AIE]&r_sig_exist) begin
        o_dout_iq[((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)] <= {w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(0+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW],w_aai_out_axis_tdata[gidx/DIO_NB_AIE][(2+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW-1:(1+(gidx%DIO_NB_AIE)*DIO_NB_AIE)*DO_BW]} ;
    end
end
always@(*) begin
    o_dout_ant_id[(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))] = r_aai_out_blk_id[gidx/DIO_NB_AIE] ;
end
end
endgenerate
assign o_dlfe_rpt_1040[((22)*(0+1)-1)-:(22)] = w_aai_inout_proc_dly[0] ;
assign o_dlfe_rpt_1044[((22)*(0+1)-1)-:(22)] = w_aai_inout_proc_dly[1] ;
`else// DLFE_AIE_DISABLE
reg  [1-1:0]                    r_shift_a_sat_en    [NUM_I_CHAIN-1:0]               ;   
wire [0:0]                      w_ifft_rstn         [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_ready        [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_out_en       [NUM_I_CHAIN-1:0]               ;
wire [1:0]                      w_ifft_out_err      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_out_sop      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_out_eop      [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]          w_ifft_out_i        [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]          w_ifft_out_q        [NUM_I_CHAIN-1:0]               ;
wire [$clog2(MAX_NIFFT):0]      w_ifft_out_pts      [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                      r_ifft_rstn         [NUM_I_CHAIN-1:0][DLY_RST:0]    ;
wire [0:0]                      w_ifft_out_r_en     [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]          w_ifft_out_r_i      [NUM_I_CHAIN-1:0]               ;
wire [BW_IFFT_OUT-1:0]          w_ifft_out_r_q      [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                      r_ifft_out_s_en     [NUM_I_CHAIN-1:0]               ;
reg  [BW_SCALE_A-1:0]           r_ifft_out_s_i      [NUM_I_CHAIN-1:0]               ;
reg  [BW_SCALE_A-1:0]           r_ifft_out_s_q      [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_out_sr_en    [NUM_I_CHAIN-1:0]               ;
wire [2*BW_SCALE_A-1:0]         w_ifft_out_sr_iq    [NUM_I_CHAIN-1:0]               ;
wire [0:0]                      w_ifft_out_sat_en   [NUM_I_CHAIN-1:0]               ;
wire [2*DO_BW-1:0]              w_ifft_out_sat_iq   [NUM_I_CHAIN-1:0]               ;
reg  [0:0]                      rr_cc_id            [NUM_I_CHAIN-1:0]               ;
reg  [$clog2(NUM_ANT)-1:0]      rr_ant_id           [NUM_I_CHAIN-1:0]               ;   
wire [01-1:0]                   w_dout_en           [NUM_I_CHAIN-1:0]               ;
wire [2*DO_BW-1:0]              w_dout_iq           [NUM_I_CHAIN-1:0]               ;
wire [01-1:0]                   w_dout_cc_id        [NUM_I_CHAIN-1:0]               ;
wire [02-1:0]                   w_dout_ant_id       [NUM_I_CHAIN-1:0]               ;   
wire                            w_frame_sync                                        ;
wire                            w_subfrm_sync                                       ;
wire                            w_slot_sync                                         ;
wire                            w_symbol_sync                                       ;
wire [3:0]                      w_subfrm                                            ;
wire [7:0]                      w_slot                                              ;
wire [3:0]                      w_symbol                                            ;
generate for(gidx=0;gidx<NUM_I_CHAIN;gidx=gidx+1) begin : g00_ofdm_chain
always@(posedge i_clk) begin
    r_en[gidx] <= i_din_en[((01)*(gidx+1)-1)-:(01)] ;
    if(i_din_en[((01)*(gidx+1)-1)-:(01)]) begin
        r_iq[gidx] <= i_din_iq[((2*DI_BW)*(gidx+1)-1)-:(2*DI_BW)]   ;
    end
end
always@(posedge i_clk) begin
    if(~i_din_en[((01)*(gidx+1)-1)-:(01)]&r_en[gidx]) begin
        r_cc_id  [gidx] <=  i_din_cc_id  [((01)*(gidx+1)-1)-:(01)]  ;
        r_ant_id [gidx] <=  i_din_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]  ;
    end
end
always@(posedge i_clk) begin
    r_shift_a_en[gidx]  <=  r_en[gidx]  ;
    if(r_en[gidx]) begin
        if(|r_cal_en) begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<SHIFT_A_XCAL ; 
        end
        else begin
            r_shift_a_i[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*2-1)]}},r_iq[gidx][(DI_BW*2-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]] ; 
            r_shift_a_q[gidx] <=  {{{BW_SHIFTA}{r_iq[gidx][(DI_BW*1-1)]}},r_iq[gidx][(DI_BW*1-1)-:DI_BW]}<<<r_shift_a[i_din_cc_id[((01)*(gidx+1)-1)-:(01)]] ; 
        end
    end
end
ylib_sat #(
  .NUM_STREAM   (   2                   )
 ,.DI_BW        (   DI_BW+BW_SHIFTA     )
 ,.DO_BW        (   BW_IFFT_IN          ))
u00_shifta_sat
(
     .i_clk     (   i_clk                                           )
    ,.i_in_en   (   r_shift_a_en[gidx]                              )
    ,.i_in      (   {r_shift_a_i[gidx],r_shift_a_q[gidx]}           )
    ,.o_out_en  (   w_shift_a_sat_en[gidx]                          )
    ,.o_out     (   {w_shift_a_sat_i[gidx],w_shift_a_sat_q[gidx]}   )
);
always@(posedge i_clk) begin
    r_shift_a_sat_en[gidx]  <=  w_shift_a_sat_en[gidx]  ;
end
always@(posedge i_clk) begin
    if(i_rst) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else if(w_ifft_out_err[gidx]) begin
        r_ifft_rstn[gidx][0] <=  1'd0 ;
    end
    else begin
        r_ifft_rstn[gidx][0] <=  1'b1 ;
    end
end
always@(posedge i_clk) begin
    for(i=1;i<=DLY_RST;i=i+1) begin
        r_ifft_rstn[gidx][i] <=  r_ifft_rstn[gidx][i-1] ;
    end
end
assign w_ifft_rstn[gidx] = r_ifft_rstn[gidx][DLY_RST-1]&r_ifft_rstn[gidx][DLY_RST]  ;
ylib_vfft_wrapper #(
     .MAX_NFFT   (    MAX_NIFFT         )
    ,.VENDOR     (    VENDOR            ))
u01_ifft 
(
     .clk               (   i_clk                                           )
    ,.reset_n           (   w_ifft_rstn     [gidx]                          )
    ,.sink_valid        (   w_shift_a_sat_en[gidx]                          )
    ,.sink_ready        (   w_ifft_ready    [gidx]                          )
    ,.sink_error        (   2'd0                                            ) 
    ,.sink_sop          (   w_shift_a_sat_en[gidx]&~r_shift_a_sat_en[gidx]  ) 
    ,.sink_eop          (   ~r_shift_a_en[gidx]&w_shift_a_sat_en[gidx]      ) 
    ,.sink_real         (   w_shift_a_sat_i [gidx]                          ) 
    ,.sink_imag         (   w_shift_a_sat_q [gidx]                          ) 
    ,.fftpts_in         (   r_fft_pts                                       ) 
    ,.inverse           (   1'd1                                            ) 
    ,.source_valid      (   w_ifft_out_en   [gidx]                          ) 
    ,.source_ready      (   1'd1                                            ) 
    ,.source_error      (   w_ifft_out_err  [gidx]                          ) 
    ,.source_sop        (   w_ifft_out_sop  [gidx]                          ) 
    ,.source_eop        (   w_ifft_out_eop  [gidx]                          ) 
    ,.source_real       (   w_ifft_out_i    [gidx]                          ) 
    ,.source_imag       (   w_ifft_out_q    [gidx]                          ) 
    ,.fftpts_out        (   w_ifft_out_pts  [gidx]                          ) 
);
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2               )
 ,.SHIFTD_BW    (   2               )
 ,.IO_BW        (   BW_IFFT_OUT     ))
u02_ifft_out_r
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   w_ifft_out_en[gidx]                         )
    ,.i_in      (   {w_ifft_out_i[gidx],w_ifft_out_q[gidx]}     )
    ,.i_shiftd  (   2'd3                                        )
    ,.o_out_en  (   w_ifft_out_r_en[gidx]                       )
    ,.o_out     (   {w_ifft_out_r_i[gidx],w_ifft_out_r_q[gidx]} )
);
always@(posedge i_clk) begin
    r_ifft_out_s_en[gidx]   <=  w_ifft_out_r_en[gidx] ;
    if(w_ifft_out_r_en[gidx]) begin
        r_ifft_out_s_i[gidx] <=  $signed($signed({{{BW_SCALE_A-BW_IFFT_OUT}{w_ifft_out_r_i[gidx][BW_IFFT_OUT-1]}},w_ifft_out_r_i[gidx]})*r_scale_a)  ;
        r_ifft_out_s_q[gidx] <=  $signed($signed({{{BW_SCALE_A-BW_IFFT_OUT}{w_ifft_out_r_q[gidx][BW_IFFT_OUT-1]}},w_ifft_out_r_q[gidx]})*r_scale_a)  ;
    end
end
ylib_shiftd_rnd #(
  .NUM_STREAM   (   2               )
 ,.SHIFTD_BW    (   4               )
 ,.IO_BW        (   BW_SCALE_A      ))
u03_ifft_out_sr
(
     .i_clk     (   i_clk                                       )
    ,.i_in_en   (   r_ifft_out_s_en[gidx]                       )
    ,.i_in      (   {r_ifft_out_s_i[gidx],r_ifft_out_s_q[gidx]} )
    ,.i_shiftd  (   4'd10                                       )
    ,.o_out_en  (   w_ifft_out_sr_en[gidx]                      )
    ,.o_out     (   w_ifft_out_sr_iq[gidx]                      )
);
ylib_sat #(
  .NUM_STREAM   (   2               )
 ,.DI_BW        (   BW_SCALE_A      )
 ,.DO_BW        (   DO_BW           ))
u04_ifft_out_sat
(
     .i_clk     (   i_clk                       )
    ,.i_in_en   (   w_ifft_out_sr_en  [gidx]    )
    ,.i_in      (   w_ifft_out_sr_iq  [gidx]    )
    ,.o_out_en  (   w_ifft_out_sat_en [gidx]    )
    ,.o_out     (   w_ifft_out_sat_iq [gidx]    )
);
always@(posedge i_clk) begin
    o_dout_en[((01)*(gidx+1)-1)-:(01)]   <=  w_ifft_out_sat_en [gidx]    ;  
    if(w_ifft_out_sr_en[gidx]&~w_ifft_out_sat_en[gidx]) begin
        o_dout_cc_id [((01)*(gidx+1)-1)-:(01)]                              <=  r_cc_id  [gidx]    ;  
        o_dout_ant_id [(($clog2(NUM_ANT))*(gidx+1)-1)-:($clog2(NUM_ANT))]   <=  r_ant_id [gidx]    ;  
    end
    else if(w_ifft_out_sat_en[gidx]) begin
        o_dout_iq [((2*DO_BW)*(gidx+1)-1)-:(2*DO_BW)]   <=  w_ifft_out_sat_iq[gidx]    ;  
    end
end
end
endgenerate //g00_ofdm_chain
ref_vsync_gen u05_ifft_rtg
(
     .i_clk                 ( i_clk                     )          
    ,.i_mu                  ( r_mu                      )
    ,.i_retard              ( r_ifft_dly                )
    ,.i_frame_sync          ( rr_frame_sync             )          
    ,.i_en                  ( 1'd1                      )          
    ,.o_frame_sync          ( w_frame_sync              )   
    ,.o_subfrm_sync         ( w_subfrm_sync             )   
    ,.o_slot_sync           ( w_slot_sync               )   
    ,.o_symbol_sync         ( w_symbol_sync             )   
    ,.o_subfrm              ( w_subfrm                  )          
    ,.o_slot                ( w_slot                    )          
    ,.o_symbol              ( w_symbol                  )          
);
`endif// DLFE_AIE_DISABLE
always@(posedge i_clk) begin
    o_dout_frame_sync   <= w_frame_sync     ;
    o_dout_symbol_sync  <= w_symbol_sync    ;
    if(w_symbol_sync) begin
        o_dout_symbol_idx   <=  w_symbol        ;
        o_dout_cal_en       <=  i_din_cal_en    ;
    end
end
endmodule
