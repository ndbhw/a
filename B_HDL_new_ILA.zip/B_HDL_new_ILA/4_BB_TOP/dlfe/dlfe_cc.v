//////////////////////////////////////////////////////////////////////////////// 
//
// CONFIDENTIAL AND SAMSUNG PROPRIETARY
//
// NATIONAL CORE TECHNOLOGY INCLUDED 
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : FSU : VzW FSU10/FSU20
//                 oRU : DCM RT4419/RT4422, VzW RT8808/RF4440d
//                 RU  : Telus RT8809/RT8811
//  Module       : dlfe_cc
//  Author       : jyzoo.lee@samsung.com
//  Description  : dlfe cc top 
//                 1.configurable structure : cell multiplexing 
//                 2.configurable structure : multiple chain 
//                 3.supports external re2subcarrier mapping
//                 4.supports function split option 7-2 category b
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.09.16 | jyzoo.lee     | Create Initial Design 
//  ------------+---------------+-----------------------------------------------
//   2020.11.04 | jyzoo.lee     | Add an Option to enable IFFT Mapper
//  ------------+---------------+-----------------------------------------------
//   2020.11.20 | jyzoo.lee     | Supports Multiple Chain
//  ------------+---------------+-----------------------------------------------
//   2020.12.01 | jyzoo.lee     | Add nTone, FFTType Ports for ORAN_TOP IF
//  ------------+---------------+-----------------------------------------------
//   2020.12.02 | jyzoo.lee     | Add bfw_mult block
//  ------------+---------------+-----------------------------------------------
//   2021.01.06 | jyzoo.lee     | Add calw_mult block
//  ------------+---------------+-----------------------------------------------
//   2021.01.13 | jyzoo.lee     | Add calibarion scheduler
//  ------------+---------------+-----------------------------------------------
//   2022.02.01 | jyzoo.lee     | Add CPRI Interface
//  ------------+---------------+-----------------------------------------------
//   2022.03.10 | jyzoo.lee     | Address Offset Parameterzied
//  ------------+---------------+-----------------------------------------------
//   2021.03.15 | jyzoo.lee     | Add system mode for interfacing with ORAN_TOP
//  ------------+---------------+-----------------------------------------------
//   2021.05.20 | jyzoo.lee     | Forward IFFT Mapper Structure  
//  ------------+---------------+-----------------------------------------------
//   2021.06.02 | jyzoo.lee     | External BF_CAL Integrated
//  ------------+---------------+-----------------------------------------------
//   2021.06.07 | jyzoo.lee     | Merge CPRI dedicated modules 
//  ------------+---------------+-----------------------------------------------
//   2021.06.10 | jyzoo.lee     | DSS Support
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////

`include "dlfe_top.vh"

module dlfe_cc
#(
     parameter  CC_IDX              =   0
    ,parameter  NUM_CC              =   1          
    ,parameter  CC_ID               =   0          
    ,parameter  NUM_LAYER           =   4
    ,parameter  NUM_ANT             =   8
`ifdef DLFE_ORAN_DISABLE
    ,parameter  NUM_LANE_CC         =   2
    ,parameter  NUM_LAYER_LANE      =   2
`endif //DLFE_ORAN_DISABLE
`ifndef DLFE_AIE_DISABLE
    ,parameter  DIO_BW_AIE          =  `DLFE_DIO_BW_AIE
    ,parameter  DIO_NB_AIE          =  `DLFE_DIO_NB_AIE
`endif //DLFE_AIE_DISABLE
    ,parameter  TOP_DIO_BW          =   16 
    ,parameter  DLY_REG_RD          =   2
    ,parameter  ADDR_OFFSET         =   20'h20000           
    ,parameter  VENDOR              =   "Xilinx"
)(
    //--- reset & clk
        input   wire                                                i_clk                       //core clock 245.76MHz 
    ,   input   wire    [01*NUM_CC-1:0]                             i_rst                       //core active high sync reset
            
    //--- from cpu interface
    ,   input   wire    [20*NUM_CC-1:0]                             i_cpu_addr                  //address of dlfe_cc registers
    ,   input   wire    [01*NUM_CC-1:0]                             i_cpu_wren                  //write enable of dlfe_cc registers 
    ,   input   wire    [32*NUM_CC-1:0]                             i_cpu_wdata                 //write data of dlfe_cc registers 
    ,   input   wire    [01*NUM_CC-1:0]                             i_cpu_rden                  //read enable of dlfe_cc registers 
    ,   output  wire    [32*NUM_CC-1:0]                             o_cpu_rdata                 //read data of dlfe_cc registers 
    ,   output  wire    [01*NUM_CC-1:0]                             o_cpu_rd_valid              //read data vaild of dlfe_cc registers 

    ,   input   wire    [12*NUM_CC-1:0]                             i_din_bfn                   //dl input bfn
`ifndef DLFE_ORAN_DISABLE
    //--- from oran_top
    ,    input   wire    [01*NUM_CC-1:0]                             i_din_frame_sync            //dl input frame sync (1 pulse of 245.76MHz every 10mst
    ,    input   wire    [08*NUM_CC-1:0]                             i_din_frame_idx             //dl input frame index (oran)
    ,    input   wire    [01*NUM_LAYER*NUM_CC-1:0]                   i_din_en                    //dl input u-plane data valid (oran)
    ,    input   wire    [08*NUM_LAYER*NUM_CC-1:0]                   i_din_frame_struct          //dl input frame structure (oran)
    ,    input   wire    [01*NUM_LAYER*NUM_CC-1:0]                   i_din_sys_mode_dss          //dl input system mode bitmap for dss (oran)
    ,    input   wire    [01*NUM_LAYER*NUM_CC-1:0]                   i_din_re_mask               //dl input re mask (oran)
    ,    input   wire    [2*TOP_DIO_BW*NUM_LAYER*NUM_CC-1:0]         i_din_iq                    //dl input u-plane data (oran)
    ,    input   wire    [15*NUM_LAYER*NUM_CC-1:0]                   i_din_beam_id               //dl input re beam id (oran)    
    ,    input   wire    [10*NUM_LAYER*NUM_CC-1:0]                   i_din_start_prbu            //dl input start prbu (oran)    
    ,    input   wire    [08*NUM_LAYER*NUM_CC-1:0]                   i_din_num_prbu              //dl input num prbu (oran)    
    ,    input   wire    [24*NUM_LAYER*NUM_CC-1:0]                   i_din_freq_offset           //dl input frequency offset (oran)    
    ,    input   wire    [05*NUM_CC-1:0]                             i_din_nlayer                //dl input layer number (oran)    
`else //DLFE_ORAN_DISABLE
    //--- from cpri_top
    ,   input   wire    [01-1:0]                                    i_din_tdd_cfg               //dl input tdd configuration indicator
    ,   input   wire    [01*NUM_LANE_CC-1:0]                        i_din_rts0                  //dl input data lane rts0
    ,   input   wire    [01*NUM_LANE_CC-1:0]                        i_din_rts1                  //dl input data lane rts1
    ,   input   wire    [01*NUM_LANE_CC-1:0]                        i_din_fsync                 //dl input data lane frame sync
    ,   input   wire    [01*NUM_LANE_CC-1:0]                        i_din_csync                 //dl input data lane chip sync
    ,   input   wire    [2*TOP_DIO_BW*NUM_LANE_CC-1:0]              i_din_cdata                 //dl input data lane data
    ,   input   wire    [01-1:0]                                    i_pin0_rts0                 //dl input param0 lane rts0
    ,   input   wire    [01-1:0]                                    i_pin0_rts1                 //dl input param0 lane rts1
    ,   input   wire    [01-1:0]                                    i_pin0_fsync                //dl input param0 lane frame sync
    ,   input   wire    [01-1:0]                                    i_pin0_csync                //dl input param0 lane chip sync
    ,   input   wire    [2*TOP_DIO_BW-1:0]                          i_pin0_cdata                //dl input param0 lane data
    ,   output  wire    [01-1:0]                                    o_dbg_in_cpri_fsync                            
    ,   output  wire    [01*NUM_LAYER_LANE*NUM_LANE_CC-1:0]         o_dbg_in_cpri_en                            
    ,   output  wire    [2*TOP_DIO_BW*NUM_LANE_CC-1:0]              o_dbg_in_cpri_iq                            
    ,   output  wire    [12-1:0]                                    o_dbg_in_cpri_cb_idx                        
    ,   output  wire    [05-1:0]                                    o_dbg_in_cpri_nmusul                        
    ,   output  wire    [06-1:0]                                    o_dbg_in_cpri_re_map                        
    ,   output  wire    [$clog2(NUM_LAYER)*NUM_LANE_CC-1:0]         o_dbg_in_cpri_lyr_id                        
    ,   output  reg     [01-1:0]                                    o_dbg_sig_fsync
    ,   output  reg     [01*NUM_ANT-1:0]                            o_dbg_sig_en   
    ,   output  reg     [2*TOP_DIO_BW*NUM_ANT-1:0]                  o_dbg_sig_iq   
`ifndef DLFE_EXT_BFCAL_DISABLE
    //--- from CTRL_TOP
    ,   input   wire    [01-1:0]                                    i_bcf_en                 
    ,   input   wire    [01-1:0]                                    i_bcf_bfn_strb
    //--- from SYSCTRL
    ,   input   wire    [01-1:0]                                    i_bcf_lte_tech               
    ,   input   wire    [01-1:0]                                    i_bcf_cal_path_sel       
    ,   input   wire    [08-1:0]                                    i_bcf_cal_main_path_num  
    ,   input   wire    [08-1:0]                                    i_bcf_cal_redun_path_num 
    ,   input   wire    [08-1:0]                                    i_bcf_cal_sfnblk_frm_num 
    ,   input   wire    [08-1:0]                                    i_bcf_dl_cal_frm_num     
    ,   input   wire    [20-1:0]                                    i_bcf_dl_cal_slot_map    
    ,   input   wire    [14-1:0]                                    i_bcf_dl_cal_symbol_map  
    ,   input   wire    [08-1:0]                                    i_bcf_dl_cal_acc_num     
    ,   input   wire    [08-1:0]                                    i_bcf_dl_cal_num_per_2sym
    ,   input   wire    [08-1:0]                                    i_bcf_dl_cal_num_per_frm 
    ,   input   wire    [08-1:0]                                    i_bcf_ul_cal_frm_num     
    ,   input   wire    [20-1:0]                                    i_bcf_ul_cal_slot_map    
    ,   input   wire    [14-1:0]                                    i_bcf_ul_cal_symbol_map  
    ,   input   wire    [08-1:0]                                    i_bcf_ul_cal_acc_num     
    ,   input   wire    [08-1:0]                                    i_bcf_ul_cal_num_per_2sym
    ,   input   wire    [08-1:0]                                    i_bcf_ul_cal_num_per_frm 
    ,   input   wire    [12-1:0]                                    i_bcf_ul_punc_length
    //--- from/to BF_CAL_PAT_BUF
    ,   output  wire    [01-1:0]                                    o_cal_pat_buf_rden 
    ,   output  wire    [32-1:0]                                    o_cal_pat_buf_addr 
    ,   input   wire    [32-1:0]                                    i_cal_pat_buf_rdata
`endif //DLFE_EXT_BFCAL_DISABLE
`endif //DLFE_ORAN_DISABLE
    ,    output  wire    [01*NUM_CC-1:0]                             o_dout_bfn_strb             //dl output bfn strobe (1 pulse of 3.84MHz every 10ms)
    ,    output  wire    [12*NUM_CC-1:0]                             o_dout_bfn                  //dl output bfn 
    ,    output  wire    [01*NUM_CC-1:0]                             o_dout_frame_sync           //dl output frame sync (1 pulse of 245.76MHz every 10ms)
    ,    output  wire    [01*NUM_CC-1:0]                             o_dout_subfrm_sync          //dl output subframe sync (1 pulse of 245.76MHz every 10ms)
    ,    output  wire    [01*NUM_CC-1:0]                             o_dout_slot_sync            //dl output slot sync (1 pulse of 245.76MHz every 10ms)
    ,    output  wire    [01*NUM_CC-1:0]                             o_dout_symbol_sync          //dl output symbol sync (1 pulse of 245.76MHz every 10ms)
    ,    output  wire    [08*NUM_CC-1:0]                             o_dout_frame_idx            //dl output frame index 
    ,    output  wire    [04*NUM_CC-1:0]                             o_dout_subfrm_idx           //dl output subframe index
    ,    output  wire    [06*NUM_CC-1:0]                             o_dout_slot_idx             //dl output slot index
    ,    output  wire    [04*NUM_CC-1:0]                             o_dout_symbol_idx           //dl output symbol index 
    ,    output  wire    [01*NUM_ANT*NUM_CC-1:0]                     o_dout_en                   //dl output data valid
    ,    output  wire    [2*TOP_DIO_BW*NUM_ANT*NUM_CC-1:0]           o_dout_iq                   //dl output data 
    //--- to bb_if/bb_ctrl
    ,   output  wire    [04*NUM_CC-1:0]                             o_dout_dl_bw_idx            //dl output bandwidth index 
    ,   output  wire    [01*NUM_CC-1:0]                             o_dout_bcf_en               //dl output data beamforming calibration frame enable
    //--- to oran_top
    ,   output  wire    [01*NUM_CC-1:0]                             o_dout_dl_sys_mode          //dl system mode for pre-processing in oran_top
    ,   output  wire    [12*NUM_CC-1:0]                             o_dout_dl_ntone             //dl ntone for pre-processing in oran_top
    ,   output  wire    [02*NUM_CC-1:0]                             o_dout_dl_fft_type          //dl fft_type for pre-processing in oran_top
    ,   output  wire    [12*NUM_CC-1:0]                             o_dout_dl_k0                //dl ifft k0 for pre-processing in oran_top
`ifndef DLFE_AIE_DISABLE
    ,   input   wire                                                i_aie_clk                   //dl aie interface clock (307.2MHz)
    ,   input   wire    [01*NUM_CC-1:0]                             i_aie_rst                   //dl aie interface active high sync reset
    ,   input   wire    [01*DIO_NB_AIE-1:0]                         i_aie_ifft_tready           //dl axi tready for pl to aie
    ,   output  wire    [01*DIO_NB_AIE-1:0]                         o_aie_ifft_tvalid           //dl axi tvalid for pl to aie
    ,   output  wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]                 o_aie_ifft_tdata            //dl axi tdata  for pl to aie
    ,   output  wire    [01*DIO_NB_AIE-1:0]                         o_aie_ifft_tlast            //dl axi tlast  for pl to aie
    ,   output  wire    [DIO_BW_AIE/8*DIO_NB_AIE-1:0]               o_aie_ifft_tkeep            //dl axi tkeep  for pl to aie
    ,   output  wire    [01*DIO_NB_AIE-1:0]                         o_aie_ifft_tready           //dl axi tready for aie to pl
    ,   input   wire    [01*DIO_NB_AIE-1:0]                         i_aie_ifft_tvalid           //dl axi tvalid for aie to pl
    ,   input   wire    [DIO_BW_AIE*DIO_NB_AIE-1:0]                 i_aie_ifft_tdata            //dl axi tdata  for aie to pl
    ,   input   wire    [01*DIO_NB_AIE-1:0]                         i_aie_ifft_tlast            //dl axi tlast  for aie to pl
`endif //DLFE_AIE_DISABLE
);

//PARAMETER DLFE CC
localparam      MAX_MU                      =          `DLFE_MAX_MU                     ;           
localparam      MAX_NIFFT                   =          `DLFE_MAX_NIFFT                  ;           
localparam      DO_BW_IN_IF                 =          `DLFE_DO_BW_IN_IF                ;           
localparam      DO_BW_BFW_MULT              =          `DLFE_DO_BW_BFW_MULT             ;           
localparam      DO_BW_CAL_SCHDLR            =          `DLFE_DO_BW_CAL_SCHDLR           ;           
localparam      DO_BW_CALW_MULT             =          `DLFE_DO_BW_CALW_MULT            ;           
localparam      DO_BW_PHASE_COMP            =          `DLFE_DO_BW_PHASE_COMP           ;           
localparam      DO_BW_IFFT_MAP_BUF          =          `DLFE_DO_BW_IFFT_MAP_BUF         ;           
localparam      DO_BW_OFDM_MOD              =          `DLFE_DO_BW_OFDM_MOD             ;           
localparam      DO_BW_ANT_SCALE             =          `DLFE_DO_BW_ANT_SCALE            ;           
localparam      DO_BW_CDD_CP_BUF            =          `DLFE_DO_BW_CDD_CP_BUF           ;           
localparam      NUM_CHAIN_IN_IF             =          `DLFE_NUM_CHAIN_IN_IF            ;           
localparam      NUM_CHAIN_BFW_MULT          =          `DLFE_NUM_CHAIN_BFW_MULT         ;           
localparam      NUM_CHAIN_CALW_MULT         =          `DLFE_NUM_CHAIN_CALW_MULT        ;           
localparam      NUM_CHAIN_PHASE_COMP        =          `DLFE_NUM_CHAIN_PHASE_COMP       ;           
localparam      NUM_CHAIN_IFFT_MAP_BUF      =          `DLFE_NUM_CHAIN_IFFT_MAP_BUF     ;           
localparam      NUM_CHAIN_OFDM_MOD          =          `DLFE_NUM_CHAIN_OFDM_MOD         ;           
localparam      NUM_CHAIN_ANT_SCALE         =          `DLFE_NUM_CHAIN_ANT_SCALE        ;           
localparam      DLFE_BASE_ADDR              =           ADDR_OFFSET+20'h00000           ;
localparam      CALW_BASE_ADDR              =           ADDR_OFFSET+20'h0C000           ;
localparam      CALP_BASE_ADDR              =           ADDR_OFFSET+20'h08000           ;
localparam      BFCB_BASE_ADDR              =           ADDR_OFFSET+20'h04000           ;
localparam      CHAIN_REF                   =           0                               ;

//Logic Variable
integer i   ;
genvar gidx ;

//u00_dlfe_in_if
wire    [01-1:0]                                            w_in_if_frame_sync                      ;
wire    [01-1:0]                                            w_in_if_subfrm_sync                     ;
wire    [01-1:0]                                            w_in_if_slot_sync                       ;
wire    [01-1:0]                                            w_in_if_symbol_sync                     ;
wire    [03-1:0]                                            w_in_if_mu                              ;
wire    [04*NUM_CC-1:0]                                     w_in_if_fft_size                        ;
wire    [02-1:0]                                            w_in_if_cals_cal_en                     ;
wire    [01*NUM_ANT-1:0]                                    w_in_if_cals_pat_en                     ;
wire    [2*DO_BW_IN_IF-1:0]                                 w_in_if_cals_pat_iq                     ;
`ifndef DLFE_ORAN_DISABLE
 wire    [01*NUM_CHAIN_IN_IF-1:0]                            w_in_if_en                              ;
 wire    [2*DO_BW_IN_IF*NUM_CHAIN_IN_IF-1:0]                 w_in_if_iq                              ;
 wire    [15*NUM_CHAIN_IN_IF-1:0]                            w_in_if_beam_id                         ;
 wire    [01*NUM_CHAIN_IN_IF-1:0]                            w_in_if_sys_mode_dss                    ;
 wire    [01*NUM_CHAIN_IN_IF-1:0]                            w_in_if_cc_id                           ;
 wire    [$clog2(NUM_LAYER)*NUM_CHAIN_IN_IF-1:0]             w_in_if_lyr_id                          ;
 wire    [05-1:0]                                            w_in_if_nlayer                          ;
`else //DLFE_ORAN_DISABLE
wire    [01*NUM_LAYER_LANE*NUM_LANE_CC-1:0]                 w_in_if_en                              ;
wire    [2*DO_BW_IN_IF*NUM_LANE_CC-1:0]                     w_in_if_iq                              ;
wire    [12-1:0]                                            w_in_if_cb_idx                          ;
wire    [05-1:0]                                            w_in_if_nmusul                          ;
wire    [06-1:0]                                            w_in_if_re_map                          ;
wire    [01*NUM_LANE_CC-1:0]                                w_in_if_cc_id                           ;
wire    [$clog2(NUM_LAYER)*NUM_LANE_CC-1:0]                 w_in_if_lyr_id                          ;
reg     [DO_BW_IN_IF-1:0]                                   r_in_if_el_dbg    [2*NUM_LANE_CC-1:0]   ;
reg     [2*TOP_DIO_BW-1:0]                                  r_in_if_iq_dbg    [NUM_LANE_CC-1:0]     ;
`endif //DLFE_ORAN_DISABLE
 wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi0                          ; 
 wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi1                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi2                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi3                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi4                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi5                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi6                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_lssi7                          ; 
wire    [22*NUM_CC-1:0]                                     w_din_fsync_ts                          ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_max                            ; 
wire    [32*NUM_CC-1:0]                                     w_din_nr_min                            ; 

//u01_dlfe_bfw_mult
wire    [01-1:0]                                            w_bfw_frame_sync                        ;
wire    [01-1:0]                                            w_bfw_subfrm_sync                       ;
wire    [01-1:0]                                            w_bfw_slot_sync                         ;
wire    [01-1:0]                                            w_bfw_symbol_sync                       ;
wire    [01*NUM_CHAIN_BFW_MULT-1:0]                         w_bfw_en                                ;
wire    [2*DO_BW_BFW_MULT*NUM_CHAIN_BFW_MULT-1:0]           w_bfw_iq                                ;
wire    [01-1:0]                                            w_bfw_sys_mode_dss                      ;
wire    [01*NUM_CHAIN_BFW_MULT-1:0]                         w_bfw_cc_id                             ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_BFW_MULT-1:0]            w_bfw_ant_id                            ;
wire    [03-1:0]                                            w_bfw_mu                                ;
wire    [04*NUM_CC-1:0]                                     w_bfw_fft_size                          ;
wire    [02-1:0]                                            w_bfw_cal_en                            ;
wire    [01-1:0]                                            w_bfw_muen                              ;
wire    [32*NUM_CC-1:0]                                     w_bfw_rdata                             ;
wire    [01*NUM_CC-1:0]                                     w_bfw_rd_valid                          ;

//u02_bb_cal_schdlr
wire    [01*NUM_CC-1:0]                                     w_cals_bcf_en                           ;
wire    [02-1:0]                                            w_cals_cal_en                           ;
wire    [01*NUM_ANT-1:0]                                    w_cals_pat_en                           ;
wire    [2*DO_BW_CAL_SCHDLR-1:0]                            w_cals_pat_iq                           ;
wire    [32*NUM_CC-1:0]                                     w_cals_rdata                            ;
wire    [01*NUM_CC-1:0]                                     w_cals_rd_valid                         ;
wire    [12*NUM_CC-1:0]                                     w_cals_punc_len                         ;
wire    [02*NUM_CC-1:0]                                     w_bcf_fs_err_flag_blkclk_out            ;
wire    [32*NUM_CC-1:0]                                     w_bcf_en_fscnt_blkclk_out               ;
wire    [32*NUM_CC-1:0]                                     w_bcf_rpls_clkcnt_blkclk_out            ;
wire    [32*NUM_CC-1:0]                                     w_bcf_en_sfncnt_blkclk_out              ;

//u03_dlfe_calw_mult
wire    [01-1:0]                                            w_calw_frame_sync                       ;
wire    [01-1:0]                                            w_calw_slot_sync                        ;
wire    [01-1:0]                                            w_calw_symbol_sync                      ;
wire    [01*NUM_CHAIN_CALW_MULT-1:0]                        w_calw_en                               ;
wire    [2*DO_BW_CALW_MULT*NUM_CHAIN_CALW_MULT-1:0]         w_calw_iq                               ;
wire    [01-1:0]                                            w_calw_sys_mode_dss                     ;
wire    [01*NUM_CHAIN_CALW_MULT-1:0]                        w_calw_cc_id                            ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_CALW_MULT-1:0]           w_calw_ant_id                           ;
wire    [03-1:0]                                            w_calw_mu                               ;
wire    [04*NUM_CC-1:0]                                     w_calw_fft_size                         ;
wire    [02-1:0]                                            w_calw_cal_en                           ;
wire    [32*NUM_CC-1:0]                                     w_calw_rdata                            ;
wire    [01*NUM_CC-1:0]                                     w_calw_rd_valid                         ;

//u04_dlfe_ifft_map_buf
wire    [01-1:0]                                            w_ifft_map_frame_sync                   ;
wire    [01-1:0]                                            w_ifft_map_subfrm_sync                  ;
wire    [01-1:0]                                            w_ifft_map_symbol_sync                  ;
wire    [01*NUM_CHAIN_IFFT_MAP_BUF-1:0]                     w_ifft_map_en                           ;
wire    [2*DO_BW_IFFT_MAP_BUF*NUM_CHAIN_IFFT_MAP_BUF-1:0]   w_ifft_map_iq                           ;
wire    [01-1:0]                                            w_ifft_map_sys_mode_dss                 ;
wire    [01*NUM_CHAIN_IFFT_MAP_BUF-1:0]                     w_ifft_map_cc_id                        ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_IFFT_MAP_BUF-1:0]        w_ifft_map_ant_id                       ;
wire    [03-1:0]                                            w_ifft_map_mu                           ;
wire    [04*NUM_CC-1:0]                                     w_ifft_map_fft_size                     ;
wire    [02-1:0]                                            w_ifft_map_cal_en                       ;

//u05_dlfe_phase_comp
wire    [01-1:0]                                            w_pc_frame_sync                         ;
wire    [01-1:0]                                            w_pc_symbol_sync                        ;
wire    [01*NUM_CHAIN_PHASE_COMP-1:0]                       w_pc_en                                 ;
wire    [2*DO_BW_PHASE_COMP*NUM_CHAIN_PHASE_COMP-1:0]       w_pc_iq                                 ;
wire    [01*NUM_CHAIN_PHASE_COMP-1:0]                       w_pc_cc_id                              ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_PHASE_COMP-1:0]          w_pc_ant_id                             ;
wire    [03-1:0]                                            w_pc_mu                                 ;
wire    [04*NUM_CC-1:0]                                     w_pc_fft_size                           ;
wire    [02-1:0]                                            w_pc_cal_en                             ;
wire    [32*NUM_CC-1:0]                                     w_pc_rdata                              ;
wire    [01*NUM_CC-1:0]                                     w_pc_rd_valid                           ;

//u06_dlfe_ofdm_mod
wire    [01-1:0]                                            w_ofdm_mod_frame_sync                   ;
wire    [01-1:0]                                            w_ofdm_mod_symbol_sync                  ;
wire    [04-1:0]                                            w_ofdm_mod_symbol_idx                   ;
wire    [01*NUM_CHAIN_OFDM_MOD-1:0]                         w_ofdm_mod_en                           ;
wire    [2*DO_BW_OFDM_MOD*NUM_CHAIN_OFDM_MOD-1:0]           w_ofdm_mod_iq                           ;
wire    [01*NUM_CHAIN_OFDM_MOD-1:0]                         w_ofdm_mod_cc_id                        ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_OFDM_MOD-1:0]            w_ofdm_mod_ant_id                       ;
wire    [02-1:0]                                            w_ofdm_mod_cal_en                       ;
wire    [22*NUM_CC-1:0]                                     w_aie_axi0_pdly                         ; 
wire    [22*NUM_CC-1:0]                                     w_aie_axi1_pdly                         ; 

//u07_dlfe_ant_scale
wire    [01-1:0]                                            w_ant_scale_frame_sync                  ;
wire    [01-1:0]                                            w_ant_scale_symbol_sync                 ;
wire    [04-1:0]                                            w_ant_scale_symbol_idx                  ;
wire    [01*NUM_CHAIN_ANT_SCALE-1:0]                        w_ant_scale_en                          ;
wire    [2*DO_BW_ANT_SCALE*NUM_CHAIN_ANT_SCALE-1:0]         w_ant_scale_iq                          ;
wire    [01*NUM_CHAIN_ANT_SCALE-1:0]                        w_ant_scale_cc_id                       ;
wire    [$clog2(NUM_ANT)*NUM_CHAIN_ANT_SCALE-1:0]           w_ant_scale_ant_id                      ;
wire    [02-1:0]                                            w_ant_scale_cal_en                      ;

//u08_dlfe_cdd_cp_buf
wire    [32*NUM_CC-1:0]                                     w_cdd_cp_rdata                          ;
wire    [01*NUM_CC-1:0]                                     w_cdd_cp_rd_valid                       ;
wire    [01*NUM_CC-1:0]                                     w_cdd_cp_buf_frame_sync                 ;     
wire    [01*NUM_CC-1:0]                                     w_cdd_cp_buf_subfrm_sync                ;
wire    [01*NUM_CC-1:0]                                     w_cdd_cp_buf_slot_sync                  ;
wire    [01*NUM_CC-1:0]                                     w_cdd_cp_buf_symbol_sync                ;
wire    [04*NUM_CC-1:0]                                     w_cdd_cp_buf_subfrm_idx                 ;
wire    [06*NUM_CC-1:0]                                     w_cdd_cp_buf_slot_idx                   ;
wire    [04*NUM_CC-1:0]                                     w_cdd_cp_buf_symbol_idx                 ;
wire    [1*NUM_ANT*NUM_CC-1:0]                              w_cdd_cp_buf_en                         ;
wire    [2*DO_BW_CDD_CP_BUF*NUM_ANT*NUM_CC-1:0]             w_cdd_cp_buf_iq                         ;

wire    [1*NUM_CC			-1:0] 	                        w_counter_rst			;		       
wire    [2*NUM_CC			-1:0] 	                        w_sig_susp_en			;		 /* 0 = disable, 1 = common_threshold, 2 = sym per threshold */    
wire    [32*14*NUM_CC		-1:0] 	                        w_sym_per_thrshld_val	;		
                                                                                   
wire    [12*NUM_CC			-1:0] 	                        w_reg_ntone            ;
wire    [32*NUM_CC			-1:0]	                        w_comm_thrshld_val     ;
                                                                                   
wire    [32*14*NUM_CC		-1:0] 	                        w_upper_threshold_cnt	;		
wire    [32*14*NUM_CC		-1:0] 	                        w_max_pwr_per_sym	    ;

//u09_dlfe_out_if
wire    [32*NUM_CC-1:0]                                     w_dout_nr_max                           ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_min                           ; 
wire    [22*NUM_CC-1:0]                                     w_dout_fsync_ts                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi0                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi1                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi2                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi3                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi4                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi5                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi6                         ; 
wire    [32*NUM_CC-1:0]                                     w_dout_nr_tssi7                         ; 

//u10_dlfe_cc_param_if
wire    [02*NUM_CC-1:0]                                     w_dlfe_par_1004                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_1008                         ;
wire    [22*NUM_CC-1:0]                                     w_dlfe_par_100c                         ;
wire    [22*NUM_CC-1:0]                                     w_dlfe_par_1050                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_10c0                         ;
wire    [02*NUM_CC-1:0]                                     w_dlfe_par_1100                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_1104                         ;
wire    [08*NUM_CC-1:0]                                     w_dlfe_par_1108                         ;
wire    [32*NUM_CC-1:0]                                     w_dlfe_par_110c                         ;
wire    [32*NUM_CC-1:0]                                     w_dlfe_par_1110                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_1114                         ;
wire    [32*NUM_CC-1:0]                                     w_dlfe_par_1200                         ;
wire    [12*NUM_CC-1:0]                                     w_dlfe_par_1204                         ;
wire    [03*NUM_CC-1:0]                                     w_dlfe_par_1208                         ;
wire    [12*NUM_CC-1:0]                                     w_dlfe_par_120c                         ;
wire    [02*NUM_CC-1:0]                                     w_dlfe_par_1210                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_1214                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_1218                         ;
wire    [14*NUM_CC-1:0]                                     w_dlfe_par_121c                         ;
wire    [03*NUM_CC-1:0]                                     w_dlfe_par_1240                         ;
wire    [NUM_LAYER*NUM_CC-1:0]                              w_dlfe_par_1244                         ;
wire    [NUM_ANT  *NUM_CC-1:0]                              w_dlfe_par_124c                         ;
wire    [03*NUM_CC-1:0]                                     w_dlfe_par_1254                         ;
wire    [14*NUM_CC-1:0]                                     w_dlfe_par_1280                         ;
wire    [14*NUM_CC-1:0]                                     w_dlfe_par_1284                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_1288                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_128c                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_1290                         ;
wire    [$clog2(NUM_LAYER)*NUM_CC-1:0]                      w_dlfe_par_3c00                         ;
wire    [$clog2(NUM_ANT  )*NUM_CC-1:0]                      w_dlfe_par_3c04                         ;
wire    [$clog2(NUM_LAYER)*NUM_CC-1:0]                      w_dlfe_par_3c08                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_0050                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_3880                         ;
wire    [02*NUM_CC-1:0]                                     w_dlfe_par_d000                         ;
wire    [02*NUM_CC-1:0]                                     w_dlfe_par_d010                         ;
wire    [10*NUM_CC-1:0]                                     w_dlfe_par_d020                         ;
wire    [01*NUM_CC-1:0]                                     w_dlfe_par_d024                         ;
wire    [06*NUM_CC-1:0]                                     w_dlfe_par_d028                         ;
wire    [06*NUM_CC-1:0]                                     w_dlfe_par_d02c                         ;
wire    [04*NUM_CC-1:0]                                     w_dlfe_par_d030                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d034                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d038                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d03c                         ;
wire    [32*NUM_CC-1:0]                                     w_dlfe_par_d040                         ;
wire    [08*NUM_CC-1:0]                                     w_dlfe_par_d044                         ;
wire    [32*NUM_CC-1:0]                                     w_dlfe_par_d048                         ;
wire    [08*NUM_CC-1:0]                                     w_dlfe_par_d04c                         ;
wire    [14*NUM_CC-1:0]                                     w_dlfe_par_d050                         ;
wire    [14*NUM_CC-1:0]                                     w_dlfe_par_d054                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d058                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d05c                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d060                         ;
wire    [07*NUM_CC-1:0]                                     w_dlfe_par_d064                         ;
wire    [12*NUM_CC-1:0]                                     w_dlfe_par_d068                         ;

//sub block
dlfe_in_if #(
     .CC_IDX            ( CC_IDX                )
    ,.NUM_CC            ( NUM_CC                )
    ,.NUM_LAYER         ( NUM_LAYER             )
`ifndef DLFE_ORAN_DISABLE
    ,.NUM_O_CHAIN       ( NUM_CHAIN_IN_IF       )
`else //DLFE_ORAN_DISABLE
    ,.NUM_LANE_CC       ( NUM_LANE_CC           )
    ,.NUM_LAYER_LANE    ( NUM_LAYER_LANE        )
`endif //DLFE_ORAN_DISABLE
    ,.DI_BW             ( TOP_DIO_BW            )
    ,.DO_BW             ( DO_BW_IN_IF           )
    ,.VENDOR            ( VENDOR                ))
u00_dlfe_in_if
(
    .i_clk                          ( i_clk                         ) 
   ,.i_rst                          (|i_rst                         )          
   ,.i_dlfe_par_1004                ( w_dlfe_par_1004               ) 
   ,.i_dlfe_par_1100                ( w_dlfe_par_1100               ) 
   ,.i_dlfe_par_1108                ( w_dlfe_par_1108               ) 
   ,.i_dlfe_par_110c                ( w_dlfe_par_110c               ) 
   ,.i_dlfe_par_1110                ( w_dlfe_par_1110               ) 
   ,.i_dlfe_par_120c                ( w_dlfe_par_120c               )          
   ,.i_dlfe_par_1210                ( w_dlfe_par_1210               ) 
   ,.i_dlfe_par_1240                ( w_dlfe_par_1240               ) 
   ,.i_dlfe_par_1244                ( w_dlfe_par_1244               ) 
`ifndef DLFE_ORAN_DISABLE
   ,.i_dlfe_par_1008                ( w_dlfe_par_1008               ) 
   ,.i_dlfe_par_1104                ( w_dlfe_par_1104               ) 
   ,.i_dlfe_par_1254                ( w_dlfe_par_1254               ) 
   ,.i_din_frame_sync               ( i_din_frame_sync              ) 
   ,.i_din_frame_idx                ( i_din_frame_idx               ) 
   ,.i_din_en                       ( i_din_en                      ) 
   ,.i_din_iq                       ( i_din_iq                      ) 
   ,.i_din_frame_struct             ( i_din_frame_struct            ) 
   ,.i_din_sys_mode_dss             ( i_din_sys_mode_dss            ) 
   ,.i_din_re_mask                  ( i_din_re_mask                 ) 
   ,.i_din_beam_id                  ( i_din_beam_id                 ) 
   ,.i_din_nlayer                   ( i_din_nlayer                  ) 
   ,.o_dout_en                      ( w_in_if_en                    ) 
   ,.o_dout_iq                      ( w_in_if_iq                    ) 
   ,.o_dout_beam_id                 ( w_in_if_beam_id               ) 
   ,.o_dout_sys_mode_dss            ( w_in_if_sys_mode_dss          ) 
   ,.o_dout_cc_id                   ( w_in_if_cc_id                 ) 
   ,.o_dout_lyr_id                  ( w_in_if_lyr_id                ) 
   ,.o_dout_nlayer                  ( w_in_if_nlayer                ) 
`else //DLFE_ORAN_DISABLE
   ,.i_din_tdd_cfg                  ( i_din_tdd_cfg                 )          
   ,.i_din_rts0                     ( i_din_rts0                    )          
   ,.i_din_rts1                     ( i_din_rts1                    )          
   ,.i_din_fsync                    ( i_din_fsync                   )          
   ,.i_din_csync                    ( i_din_csync                   )          
   ,.i_din_cdata                    ( i_din_cdata                   )          
   ,.i_pin0_rts0                    ( i_pin0_rts0                   )          
   ,.i_pin0_rts1                    ( i_pin0_rts1                   )          
   ,.i_pin0_fsync                   ( i_pin0_fsync                  )          
   ,.i_pin0_csync                   ( i_pin0_csync                  )          
   ,.i_pin0_cdata                   ( i_pin0_cdata                  )          
   ,.o_dout_en                      ( w_in_if_en                    ) 
   ,.o_dout_iq                      ( w_in_if_iq                    ) 
   ,.o_dout_cb_idx                  ( w_in_if_cb_idx                ) 
   ,.o_dout_nmusul                  ( w_in_if_nmusul                ) 
   ,.o_dout_re_map                  ( w_in_if_re_map                ) 
   ,.o_dout_cc_id                   ( w_in_if_cc_id                 ) 
   ,.o_dout_lyr_id                  ( w_in_if_lyr_id                ) 
`endif //DLFE_ORAN_DISABLE
   ,.o_dout_frame_sync              ( w_in_if_frame_sync            ) 
   ,.o_dout_subfrm_sync             ( w_in_if_subfrm_sync           ) 
   ,.o_dout_slot_sync               ( w_in_if_slot_sync             ) 
   ,.o_dout_symbol_sync             ( w_in_if_symbol_sync           ) 
   ,.o_dout_mu                      ( w_in_if_mu                    ) 
   ,.o_dout_fft_size                ( w_in_if_fft_size              ) 
   ,.o_dlfe_rpt_1080                ( w_din_nr_lssi0                )          
   ,.o_dlfe_rpt_1084                ( w_din_nr_lssi1                )          
   ,.o_dlfe_rpt_1088                ( w_din_nr_lssi2                )          
   ,.o_dlfe_rpt_108c                ( w_din_nr_lssi3                )          
   ,.o_dlfe_rpt_1090                ( w_din_nr_lssi4                )          
   ,.o_dlfe_rpt_1094                ( w_din_nr_lssi5                )          
   ,.o_dlfe_rpt_1098                ( w_din_nr_lssi6                )          
   ,.o_dlfe_rpt_109c                ( w_din_nr_lssi7                )          
   ,.o_dlfe_rpt_1120                ( w_din_nr_max                  )          
   ,.o_dlfe_rpt_1124                ( w_din_nr_min                  )          
   ,.o_dlfe_rpt_1130                ( w_din_fsync_ts                )          
);
`ifndef DLFE_CAL_DISABLE 
assign  w_in_if_cals_cal_en   =   w_cals_cal_en     ;
assign  w_in_if_cals_pat_en   =   w_cals_pat_en     ;
assign  w_in_if_cals_pat_iq   =  {w_cals_pat_iq[((DO_BW_CAL_SCHDLR)*(1+1)-(DO_BW_CAL_SCHDLR-DO_BW_IN_IF)-1)-:(DO_BW_IN_IF)]
                                   ,w_cals_pat_iq[((DO_BW_CAL_SCHDLR)*(0+1)-(DO_BW_CAL_SCHDLR-DO_BW_IN_IF)-1)-:(DO_BW_IN_IF)]} ;
`else //DLFE_CAL_DISABLE 
assign  w_in_if_cals_cal_en   =   2'd0                        ;
assign  w_in_if_cals_pat_en   =   {{NUM_ANT}{1'b0}}           ;
assign  w_in_if_cals_pat_iq   =   {{2*DO_BW_IN_IF}{1'b0}}     ;
`endif //DLFE_CAL_DISABLE 

`ifdef DLFE_ORAN_DISABLE
always@(*) begin
    for(i=0;i<2*NUM_LANE_CC;i=i+1) begin
        r_in_if_el_dbg[i] = w_in_if_iq[((DO_BW_IN_IF)*(i+1)-1)-:(DO_BW_IN_IF)] ;
    end
    for(i=0;i<NUM_LANE_CC;i=i+1) begin
        r_in_if_iq_dbg[i] = {4'd0,r_in_if_el_dbg[2*i+1],4'd0,r_in_if_el_dbg[2*i+0]} ;
    end
end
assign  o_dbg_in_cpri_fsync     =   w_in_if_frame_sync                      ;
assign  o_dbg_in_cpri_en        =   w_in_if_en                              ;
assign  o_dbg_in_cpri_iq        =   {r_in_if_iq_dbg[1],r_in_if_iq_dbg[0]}   ;
assign  o_dbg_in_cpri_cb_idx    =   w_in_if_cb_idx                          ;
assign  o_dbg_in_cpri_nmusul    =   w_in_if_nmusul                          ;
assign  o_dbg_in_cpri_re_map    =   w_in_if_re_map                          ;
assign  o_dbg_in_cpri_lyr_id    =   w_in_if_lyr_id                          ;
`endif //DLFE_ORAN_DISABLE

`ifndef DLFE_BF_DISABLE
dlfe_bfw_mult #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_LAYER         ( NUM_LAYER             )
    ,.NUM_ANT           ( NUM_ANT               )
`ifndef DLFE_ORAN_DISABLE
    ,.NUM_I_CHAIN       ( NUM_CHAIN_IN_IF       )
`else //DLFE_ORAN_DISABLE
    ,.NUM_LANE_CC       ( NUM_LANE_CC           )
    ,.NUM_LAYER_LANE    ( NUM_LAYER_LANE        )
`endif //DLFE_ORAN_DISABLE
    ,.NUM_O_CHAIN       ( NUM_CHAIN_BFW_MULT    )
    ,.MAX_NIFFT         ( MAX_NIFFT             )
    ,.DI_BW             ( DO_BW_IN_IF           )
    ,.DO_BW             ( DO_BW_BFW_MULT        )
    ,.ADDR_OFFSET       ( DLFE_BASE_ADDR        )
    ,.BFCB_ADDR_OFFSET  ( BFCB_BASE_ADDR        )
    ,.VENDOR            ( VENDOR                ))
u01_dlfe_bfw_mult
(
    .i_clk                          ( i_clk                         )
   ,.i_rst                          (|i_rst                         ) 
   ,.i_cpu_addr                     ( i_cpu_addr                    )
   ,.i_cpu_wren                     ( i_cpu_wren                    )
   ,.i_cpu_wdata                    ( i_cpu_wdata                   )
   ,.i_cpu_rden                     ( i_cpu_rden                    )
   ,.o_cpu_rdata                    ( w_bfw_rdata                   )
   ,.o_cpu_rd_valid                 ( w_bfw_rd_valid                )
   ,.i_dlfe_par_3c00                ( w_dlfe_par_3c00               )
   ,.i_dlfe_par_3c04                ( w_dlfe_par_3c04               )
   ,.i_dlfe_par_3c08                ( w_dlfe_par_3c08               )
   ,.i_din_frame_sync               ( w_in_if_frame_sync            )
   ,.i_din_subfrm_sync              ( w_in_if_subfrm_sync           )
   ,.i_din_slot_sync                ( w_in_if_slot_sync             )
   ,.i_din_symbol_sync              ( w_in_if_symbol_sync           )
   ,.i_din_mu                       ( w_in_if_mu                    )
   ,.i_din_fft_size                 ( w_in_if_fft_size              )
   ,.i_cals_cal_en                  ( w_in_if_cals_cal_en           )
   ,.i_cals_pat_en                  ( w_in_if_cals_pat_en           )
   ,.i_cals_pat_iq                  ( w_in_if_cals_pat_iq           )
`ifndef DLFE_ORAN_DISABLE
   ,.i_din_en                       ( w_in_if_en                    )
   ,.i_din_iq                       ( w_in_if_iq                    )
   ,.i_din_beam_id                  ( w_in_if_beam_id               )
   ,.i_din_nlayer                   ( w_in_if_nlayer                )
   ,.i_din_cc_id                    ( w_in_if_cc_id                 )
   ,.i_din_lyr_id                   ( w_in_if_lyr_id                )
`else //DLFE_ORAN_DISABLE
   ,.i_din_en                       ( w_in_if_en                    )
   ,.i_din_iq                       ( w_in_if_iq                    )
   ,.i_din_cb_idx                   ( w_in_if_cb_idx                )
   ,.i_din_nmusul                   ( w_in_if_nmusul                )
   ,.i_din_re_map                   ( w_in_if_re_map                )
   ,.i_din_cc_id                    ( w_in_if_cc_id                 )
   ,.i_din_lyr_id                   ( w_in_if_lyr_id                )
`endif //DLFE_ORAN_DISABLE
   ,.o_dout_frame_sync              ( w_bfw_frame_sync              )
   ,.o_dout_subfrm_sync             ( w_bfw_subfrm_sync             )
   ,.o_dout_slot_sync               ( w_bfw_slot_sync               )
   ,.o_dout_symbol_sync             ( w_bfw_symbol_sync             )
   ,.o_dout_en                      ( w_bfw_en                      )
   ,.o_dout_iq                      ( w_bfw_iq                      )
   ,.o_dout_cc_id                   ( w_bfw_cc_id                   )
   ,.o_dout_ant_id                  ( w_bfw_ant_id                  )
   ,.o_dout_mu                      ( w_bfw_mu                      )
   ,.o_dout_fft_size                ( w_bfw_fft_size                )
   ,.o_dout_cal_en                  ( w_bfw_cal_en                  )
);
`else // DLFE_BF_DISABLE
assign  w_bfw_rdata         =   {{32*NUM_CC}{1'd0}}             ;
assign  w_bfw_rd_valid      =   {{01*NUM_CC}{1'd0}}             ;
assign  w_bfw_frame_sync    =   w_in_if_frame_sync              ;
assign  w_bfw_subfrm_sync   =   w_in_if_subfrm_sync             ;
assign  w_bfw_slot_sync     =   w_in_if_slot_sync               ;
assign  w_bfw_symbol_sync   =   w_in_if_symbol_sync             ;
assign  w_bfw_en            =   w_in_if_en                      ;
assign  w_bfw_iq            =   w_in_if_iq                      ;
assign  w_bfw_sys_mode_dss  =   w_in_if_sys_mode_dss[CHAIN_REF] ;
assign  w_bfw_cc_id         =   w_in_if_cc_id                   ;
assign  w_bfw_ant_id        =   w_in_if_lyr_id                  ;
assign  w_bfw_mu            =   w_in_if_mu                      ;
assign  w_bfw_fft_size      =   w_in_if_fft_size                ;
assign  w_bfw_cal_en        =   2'd0                            ;
`endif // DLFE_BF_DISABLE

`ifndef DLFE_CAL_DISABLE
bb_cal_schdlr #(
     .NUM_CC            ( NUM_CC                )
    ,.CC_ID             ( CC_ID                 )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.DO_BW             ( DO_BW_CAL_SCHDLR      )
    ,.MAX_MU            ( MAX_MU                )
    ,.ADDR_OFFSET       ( CALP_BASE_ADDR        )
    ,.VENDOR            ( VENDOR                ))
u02_bb_cal_schdlr
(
    .i_clk                          ( i_clk                         ) 
   ,.i_rst                          (|i_rst                         ) 
`ifdef DLFE_EXT_BFCAL_DISABLE
   ,.i_cpu_addr                     ( i_cpu_addr                    )
   ,.i_cpu_wren                     ( i_cpu_wren                    )
   ,.i_cpu_wdata                    ( i_cpu_wdata                   )
   ,.i_cpu_rden                     ( i_cpu_rden                    )
   ,.o_cpu_rdata                    ( w_cals_rdata                  )
   ,.o_cpu_rd_valid                 ( w_cals_rd_valid               )
   ,.i_dlfe_par_120c                ( w_dlfe_par_120c               )          
   ,.i_dlfe_par_d000                ( w_dlfe_par_d000               )
   ,.i_dlfe_par_d010                ( w_dlfe_par_d010               )
   ,.i_dlfe_par_d020                ( w_dlfe_par_d020               )
   ,.i_dlfe_par_d024                ( w_dlfe_par_d024               )
   ,.i_dlfe_par_d028                ( w_dlfe_par_d028               )
   ,.i_dlfe_par_d02c                ( w_dlfe_par_d02c               )
   ,.i_dlfe_par_d030                ( w_dlfe_par_d030               )
   ,.i_dlfe_par_d034                ( w_dlfe_par_d034               )
   ,.i_dlfe_par_d038                ( w_dlfe_par_d038               )
   ,.i_dlfe_par_d03c                ( w_dlfe_par_d03c               )
   ,.i_dlfe_par_d040                ( w_dlfe_par_d040               )
   ,.i_dlfe_par_d044                ( w_dlfe_par_d044               )
   ,.i_dlfe_par_d048                ( w_dlfe_par_d048               )
   ,.i_dlfe_par_d04c                ( w_dlfe_par_d04c               )
   ,.i_dlfe_par_d050                ( w_dlfe_par_d050               )
   ,.i_dlfe_par_d054                ( w_dlfe_par_d054               )
   ,.i_dlfe_par_d058                ( w_dlfe_par_d058               )
   ,.i_dlfe_par_d05c                ( w_dlfe_par_d05c               )
   ,.i_dlfe_par_d060                ( w_dlfe_par_d060               )
   ,.i_dlfe_par_d064                ( w_dlfe_par_d064               )
   ,.i_dlfe_par_d068                ( w_dlfe_par_d068               )
`else //DLFE_EXT_BFCAL_DISABLE
`ifndef DLFE_ORAN_DISABLE
   //TO DO : ORAN EXT_BFCAL
`else //DLFE_ORAN_DISABLE
   ,.i_dlfe_par_10c0                ( w_dlfe_par_10c0               )          
   ,.i_dlfe_par_120c                ( w_dlfe_par_120c               )          
   ,.i_bcf_en                       ( i_bcf_en                      )
   ,.i_bcf_lte_tech                 ( i_bcf_lte_tech                )
   ,.i_bcf_bfn_strb                 ( i_bcf_bfn_strb                )
   ,.i_bcf_cal_path_sel             ( i_bcf_cal_path_sel            )
   ,.i_bcf_cal_main_path_num        ( i_bcf_cal_main_path_num       )
   ,.i_bcf_cal_redun_path_num       ( i_bcf_cal_redun_path_num      )
   ,.i_bcf_cal_sfnblk_frm_num       ( i_bcf_cal_sfnblk_frm_num      )
   ,.i_bcf_dl_cal_frm_num           ( i_bcf_dl_cal_frm_num          )
   ,.i_bcf_dl_cal_slot_map          ( i_bcf_dl_cal_slot_map         )
   ,.i_bcf_dl_cal_symbol_map        ( i_bcf_dl_cal_symbol_map       )
   ,.i_bcf_dl_cal_acc_num           ( i_bcf_dl_cal_acc_num          )
   ,.i_bcf_dl_cal_num_per_2sym      ( i_bcf_dl_cal_num_per_2sym     )
   ,.i_bcf_dl_cal_num_per_frm       ( i_bcf_dl_cal_num_per_frm      )
   ,.i_bcf_ul_cal_frm_num           ( i_bcf_ul_cal_frm_num          )
   ,.i_bcf_ul_cal_slot_map          ( i_bcf_ul_cal_slot_map         )
   ,.i_bcf_ul_cal_symbol_map        ( i_bcf_ul_cal_symbol_map       )
   ,.i_bcf_ul_cal_acc_num           ( i_bcf_ul_cal_acc_num          )
   ,.i_bcf_ul_cal_num_per_2sym      ( i_bcf_ul_cal_num_per_2sym     )
   ,.i_bcf_ul_cal_num_per_frm       ( i_bcf_ul_cal_num_per_frm      )
   ,.i_bcf_ul_punc_length           ( i_bcf_ul_punc_length          )
   ,.o_cal_pat_buf_rden             ( o_cal_pat_buf_rden            )
   ,.o_cal_pat_buf_addr             ( o_cal_pat_buf_addr            )
   ,.i_cal_pat_buf_rdata            ( i_cal_pat_buf_rdata           )
   ,.o_bcf_fs_err_flag_blkclk_out   ( w_bcf_fs_err_flag_blkclk_out  )
   ,.o_bcf_en_fscnt_blkclk_out      ( w_bcf_en_fscnt_blkclk_out     )
   ,.o_bcf_rpls_clkcnt_blkclk_out   ( w_bcf_rpls_clkcnt_blkclk_out  )
   ,.o_bcf_en_sfncnt_blkclk_out     ( w_bcf_en_sfncnt_blkclk_out    )
`endif //DLFE_ORAN_DISABLE
`endif //DLFE_EXT_BFCAL_DISABLE
`ifndef DLFE_ORAN_DISABLE
   ,.i_din_bfn                      ({4'd0,i_din_frame_idx}         )
   ,.i_cals_frame_sync              ( i_din_frame_sync              ) 
`else //DLFE_ORAN_DISABLE
   ,.i_din_bfn                      ( i_din_bfn                     )
   ,.i_cals_frame_sync              ( i_din_fsync[CHAIN_REF]        ) 
`endif //DLFE_ORAN_DISABLE
   ,.i_cals_pat_symbol_sync         ( w_in_if_symbol_sync           ) 
   ,.o_cals_bcf_en                  ( w_cals_bcf_en                 )
   ,.o_cals_cal_en                  ( w_cals_cal_en                 )
   ,.o_cals_pat_en                  ( w_cals_pat_en                 )
   ,.o_cals_pat_iq                  ( w_cals_pat_iq                 )
   ,.o_cals_punc_len                ( w_cals_punc_len               )
);

dlfe_calw_mult #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_CHAIN         ( NUM_CHAIN_CALW_MULT   )
    ,.DI_BW             ( DO_BW_IFFT_MAP_BUF    )
    ,.DO_BW             ( DO_BW_CALW_MULT       )
    ,.ADDR_OFFSET       ( CALW_BASE_ADDR        )
    ,.VENDOR            ( VENDOR                ))
u03_dlfe_calw_mult
(
    .i_clk                          ( i_clk                         )
   ,.i_cpu_addr                     ( i_cpu_addr                    )
   ,.i_cpu_wren                     ( i_cpu_wren                    )
   ,.i_cpu_wdata                    ( i_cpu_wdata                   )
   ,.i_cpu_rden                     ( i_cpu_rden                    )
   ,.o_cpu_rdata                    ( w_calw_rdata                  )
   ,.o_cpu_rd_valid                 ( w_calw_rd_valid               )
   ,.i_dlfe_par_0050                ( w_dlfe_par_0050               )
   ,.i_dlfe_par_3880                ( w_dlfe_par_3880               ) 
   ,.i_dlfe_par_3c04                ( w_dlfe_par_3c04               ) 
   ,.i_dlfe_par_1290                ( w_dlfe_par_1290               )
   ,.i_din_frame_sync               ( w_bfw_frame_sync              )          
   ,.i_din_slot_sync                ( w_bfw_slot_sync               )          
   ,.i_din_symbol_sync              ( w_bfw_symbol_sync             )          
   ,.i_din_en                       ( w_bfw_en                      )
   ,.i_din_iq                       ( w_bfw_iq                      )
   ,.i_din_cc_id                    ( w_bfw_cc_id                   )
   ,.i_din_ant_id                   ( w_bfw_ant_id                  )
   ,.i_din_mu                       ( w_bfw_mu                      )
   ,.i_din_fft_size                 ( w_bfw_fft_size                )
   ,.i_din_cal_en                   ( w_bfw_cal_en                  )
   ,.o_dout_frame_sync              ( w_calw_frame_sync             )          
   ,.o_dout_slot_sync               ( w_calw_slot_sync              )          
   ,.o_dout_symbol_sync             ( w_calw_symbol_sync            )          
   ,.o_dout_en                      ( w_calw_en                     )
   ,.o_dout_iq                      ( w_calw_iq                     )
   ,.o_dout_cc_id                   ( w_calw_cc_id                  )
   ,.o_dout_ant_id                  ( w_calw_ant_id                 )
   ,.o_dout_mu                      ( w_calw_mu                     )
   ,.o_dout_fft_size                ( w_calw_fft_size               )
   ,.o_dout_cal_en                  ( w_calw_cal_en                 )
);
`else // DLFE_CAL_DISABLE
assign  w_cals_rdata        =   {{32*NUM_CC}{1'd0}}             ;
assign  w_cals_rd_valid     =   {{01*NUM_CC}{1'd0}}             ;
assign  w_cals_cal_en       =   2'd0                            ;
assign  w_cals_pat_en       =   {{01*NUM_ANT}{1'd0}}            ;
assign  w_cals_pat_iq       =   {{2*DO_BW_CAL_SCHDLR}{1'd0}}    ;
assign  w_calw_rdata        =   {{32*NUM_CC}{1'd0}}             ;
assign  w_calw_rd_valid     =   {{01*NUM_CC}{1'd0}}             ;
assign  w_calw_frame_sync   =   w_bfw_frame_sync                ;
assign  w_calw_slot_sync    =   w_bfw_slot_sync                 ;
assign  w_calw_symbol_sync  =   w_bfw_symbol_sync               ;
assign  w_calw_en           =   w_bfw_en                        ;
assign  w_calw_iq           =   w_bfw_iq                        ;
assign  w_calw_sys_mode_dss =   w_bfw_sys_mode_dss              ;
assign  w_calw_cc_id        =   w_bfw_cc_id                     ;
assign  w_calw_ant_id       =   w_bfw_ant_id                    ;
assign  w_calw_mu           =   w_bfw_mu                        ;
assign  w_calw_fft_size     =   w_bfw_fft_size                  ;
assign  w_calw_cal_en       =   2'd0                            ;
assign  w_cals_punc_len     =   12'd0                           ;
`endif // DLFE_CAL_DISABLE

`ifndef DLFE_IFFT_MAP_DISABLE
dlfe_ifft_map_buf #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_I_CHAIN       ( NUM_CHAIN_BFW_MULT    )
    ,.NUM_O_CHAIN       ( NUM_CHAIN_IFFT_MAP_BUF)
    ,.MAX_NIFFT         ( MAX_NIFFT             )
    ,.DI_BW             ( DO_BW_BFW_MULT        )
    ,.DO_BW             ( DO_BW_IFFT_MAP_BUF    )
    ,.VENDOR            ( VENDOR                ))
u04_dlfe_ifft_map_buf
(
    .i_clk                          ( i_clk                         )          
   ,.i_rst                          (|i_rst                         )          
   ,.i_dlfe_par_1204                ( w_dlfe_par_1204               )          
   ,.i_dlfe_par_120c                ( w_dlfe_par_120c               )          
   ,.i_dlfe_par_124c                ( w_dlfe_par_124c               )
   ,.i_din_frame_sync               ( w_calw_frame_sync             )          
   ,.i_din_slot_sync                ( w_calw_slot_sync              )          
   ,.i_din_symbol_sync              ( w_calw_symbol_sync            )          
   ,.i_din_en                       ( w_calw_en                     )          
   ,.i_din_iq                       ( w_calw_iq                     )          
   ,.i_din_cc_id                    ( w_calw_cc_id                  ) 
   ,.i_din_ant_id                   ( w_calw_ant_id                 ) 
   ,.i_din_mu                       ( w_calw_mu                     ) 
   ,.i_din_fft_size                 ( w_calw_fft_size               ) 
   ,.i_din_cal_en                   ( w_calw_cal_en                 ) 
   ,.o_dout_frame_sync              ( w_ifft_map_frame_sync         )          
   ,.o_dout_subfrm_sync             ( w_ifft_map_subfrm_sync        )          
   ,.o_dout_symbol_sync             ( w_ifft_map_symbol_sync        )          
   ,.o_dout_en                      ( w_ifft_map_en                 )          
   ,.o_dout_iq                      ( w_ifft_map_iq                 )          
   ,.o_dout_cc_id                   ( w_ifft_map_cc_id              )          
   ,.o_dout_ant_id                  ( w_ifft_map_ant_id             )          
   ,.o_dout_mu                      ( w_ifft_map_mu                 )          
   ,.o_dout_fft_size                ( w_ifft_map_fft_size           )          
   ,.o_dout_cal_en                  ( w_ifft_map_cal_en             )          
);
`else //DLFE_IFFT_MAP_DISABLE
assign  w_ifft_map_frame_sync   =   w_bfw_frame_sync    ;
assign  w_ifft_map_subfrm_sync  =   w_bfw_subfrm_sync   ;
assign  w_ifft_map_symbol_sync  =   w_bfw_symbol_sync   ;
assign  w_ifft_map_en           =   w_bfw_en            ;
assign  w_ifft_map_iq           =   w_bfw_iq            ;
assign  w_ifft_map_sys_mode_dss =   w_bfw_sys_mode_dss  ;
assign  w_ifft_map_cc_id        =   w_bfw_cc_id         ;
assign  w_ifft_map_ant_id       =   w_bfw_ant_id        ;
assign  w_ifft_map_mu           =   w_bfw_mu            ;
assign  w_ifft_map_fft_size     =   w_bfw_fft_size      ;
assign  w_ifft_map_cal_en       =   w_bfw_cal_en        ;
`endif //DLFE_IFFT_MAP_DISABLE

dlfe_phase_comp #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_CHAIN         ( NUM_CHAIN_PHASE_COMP  )
    ,.DI_BW             ( DO_BW_CALW_MULT       )
    ,.DO_BW             ( DO_BW_PHASE_COMP      )
    ,.MAX_MU            ( MAX_MU                )
    ,.ADDR_OFFSET       ( DLFE_BASE_ADDR        )
    ,.VENDOR            ( VENDOR                ))
u05_dlfe_phase_comp
(
    .i_clk                          ( i_clk                         )          
   ,.i_cpu_addr                     ( i_cpu_addr                    )          
   ,.i_cpu_wren                     ( i_cpu_wren                    )          
   ,.i_cpu_wdata                    ( i_cpu_wdata                   )          
   ,.i_cpu_rden                     ( i_cpu_rden                    )          
   ,.o_cpu_rdata                    ( w_pc_rdata                    )          
   ,.o_cpu_rd_valid                 ( w_pc_rd_valid                 )          
   ,.i_dlfe_par_1200                ( w_dlfe_par_1200               )
   ,.i_din_frame_sync               ( w_ifft_map_frame_sync         )          
   ,.i_din_subfrm_sync              ( w_ifft_map_subfrm_sync        )          
   ,.i_din_symbol_sync              ( w_ifft_map_symbol_sync        )          
   ,.i_din_en                       ( w_ifft_map_en                 )          
   ,.i_din_iq                       ( w_ifft_map_iq                 )          
   ,.i_din_sys_mode_dss             ( w_ifft_map_sys_mode_dss       )          
   ,.i_din_cc_id                    ( w_ifft_map_cc_id              )          
   ,.i_din_ant_id                   ( w_ifft_map_ant_id             )          
   ,.i_din_mu                       ( w_ifft_map_mu                 )          
   ,.i_din_fft_size                 ( w_ifft_map_fft_size           )          
   ,.i_din_cal_en                   ( w_ifft_map_cal_en             )          
   ,.o_dout_frame_sync              ( w_pc_frame_sync               )          
   ,.o_dout_symbol_sync             ( w_pc_symbol_sync              )          
   ,.o_dout_en                      ( w_pc_en                       )          
   ,.o_dout_iq                      ( w_pc_iq                       )          
   ,.o_dout_cc_id                   ( w_pc_cc_id                    )          
   ,.o_dout_ant_id                  ( w_pc_ant_id                   )          
   ,.o_dout_mu                      ( w_pc_mu                       )          
   ,.o_dout_fft_size                ( w_pc_fft_size                 )          
   ,.o_dout_cal_en                  ( w_pc_cal_en                   )          
);

`ifndef DLFE_OFDM_MOD_DISABLE
dlfe_ofdm_mod #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_I_CHAIN       ( NUM_CHAIN_IFFT_MAP_BUF)
    ,.NUM_O_CHAIN       ( NUM_CHAIN_OFDM_MOD    )
    ,.MAX_NIFFT         ( MAX_NIFFT             )
`ifndef DLFE_IFFT_MAP_DISABLE
    ,.DI_BW             ( DO_BW_PHASE_COMP      )
`else //DLFE_IFFT_MAP_DISABLE
    ,.DI_BW             ( DO_BW_IFFT_MAP_BUF    )
`endif //DLFE_IFFT_MAP_DISABLE
    ,.DO_BW             ( DO_BW_OFDM_MOD        )
`ifndef DLFE_AIE_DISABLE
    ,.DIO_BW_AIE        ( DIO_BW_AIE            ) 
    ,.DIO_NB_AIE        ( DIO_NB_AIE            ) 
`endif //DLFE_AIE_DISABLE
    ,.VENDOR            ( VENDOR                ))
u06_dlfe_ofdm_mod
(
    .i_clk                          ( i_clk                         )          
   ,.i_rst                          (|i_rst                         )          
   ,.i_dlfe_par_1050                ( w_dlfe_par_1050               )          
   ,.i_dlfe_par_1208                ( w_dlfe_par_1208               )          
   ,.i_din_frame_sync               ( w_pc_frame_sync               )          
   ,.i_din_symbol_sync              ( w_pc_symbol_sync              )          
   ,.i_din_en                       ( w_pc_en                       )          
   ,.i_din_iq                       ( w_pc_iq                       )          
   ,.i_din_cc_id                    ( w_pc_cc_id                    )          
   ,.i_din_ant_id                   ( w_pc_ant_id                   )          
   ,.i_din_mu                       ( w_pc_mu                       )          
   ,.i_din_fft_size                 ( w_pc_fft_size                 )          
   ,.i_din_cal_en                   ( w_pc_cal_en                   )          
   ,.o_dout_frame_sync              ( w_ofdm_mod_frame_sync         )          
   ,.o_dout_symbol_sync             ( w_ofdm_mod_symbol_sync        )          
   ,.o_dout_symbol_idx              ( w_ofdm_mod_symbol_idx         )          
   ,.o_dout_en                      ( w_ofdm_mod_en                 )          
   ,.o_dout_iq                      ( w_ofdm_mod_iq                 )          
   ,.o_dout_cc_id                   ( w_ofdm_mod_cc_id              )          
   ,.o_dout_ant_id                  ( w_ofdm_mod_ant_id             )          
   ,.o_dout_cal_en                  ( w_ofdm_mod_cal_en             )          
`ifndef DLFE_AIE_DISABLE
   ,.i_aie_clk                      ( i_aie_clk                     )          
   ,.i_aie_rst                      ( i_aie_rst                     )          
   ,.i_aie_ifft_tready              ( i_aie_ifft_tready             )          
   ,.o_aie_ifft_tvalid              ( o_aie_ifft_tvalid             )          
   ,.o_aie_ifft_tdata               ( o_aie_ifft_tdata              )          
   ,.o_aie_ifft_tlast               ( o_aie_ifft_tlast              )          
   ,.o_aie_ifft_tkeep               ( o_aie_ifft_tkeep              )          
   ,.o_aie_ifft_tready              ( o_aie_ifft_tready             )          
   ,.i_aie_ifft_tvalid              ( i_aie_ifft_tvalid             )          
   ,.i_aie_ifft_tdata               ( i_aie_ifft_tdata              )          
   ,.i_aie_ifft_tlast               ( i_aie_ifft_tlast              )          
`endif //DLFE_AIE_DISABLE
   ,.o_dlfe_rpt_1040                ( w_aie_axi0_pdly               )
   ,.o_dlfe_rpt_1044                ( w_aie_axi1_pdly               )
);
`ifdef DLFE_ORAN_DISABLE
reg [01-1:0] r_bcf_bfn_strb ;
reg [01-1:0] r_bcf_frame_sync ;
always@(posedge i_clk) begin
    r_bcf_bfn_strb  <=  i_bcf_bfn_strb ;
    r_bcf_frame_sync  <=  i_bcf_en&(i_bcf_bfn_strb&~r_bcf_bfn_strb) ;
end
always@(posedge i_clk) begin
    if(w_dlfe_par_1114==4'd0) begin
        o_dbg_sig_fsync    <=  w_ifft_map_frame_sync ;                               
        o_dbg_sig_en       <=  {{{NUM_ANT-NUM_CHAIN_IFFT_MAP_BUF}{1'b0}},w_ifft_map_en} ;    
        o_dbg_sig_iq       <=  {{{2*TOP_DIO_BW*NUM_ANT-(NUM_CHAIN_IFFT_MAP_BUF*(2*DO_BW_IFFT_MAP_BUF))}{1'b0}},w_ifft_map_iq[NUM_CHAIN_IFFT_MAP_BUF*(2*DO_BW_IFFT_MAP_BUF)-1:2],w_ifft_map_cal_en};
    end
    else if(w_dlfe_par_1114==4'd1) begin
        o_dbg_sig_fsync    <=  w_ifft_map_frame_sync ;                               
        o_dbg_sig_en       <=  {{{NUM_ANT-NUM_CHAIN_OFDM_MOD-1}{1'b0}},w_ofdm_mod_frame_sync, w_ofdm_mod_en} ;    
        o_dbg_sig_iq       <=  {{{2*TOP_DIO_BW*NUM_ANT-(NUM_CHAIN_OFDM_MOD*(2*DO_BW_OFDM_MOD))}{1'b0}},w_ofdm_mod_iq[NUM_CHAIN_OFDM_MOD*(2*DO_BW_OFDM_MOD)-1:2],w_ofdm_mod_cal_en };
    end
    else if(w_dlfe_par_1114==4'd2) begin
        o_dbg_sig_fsync    <=  r_bcf_frame_sync ;                               
        o_dbg_sig_en       <=  {{NUM_ANT}{o_cal_pat_buf_rden}} ;    
        o_dbg_sig_iq       <=  {{{NUM_ANT/2}{o_cal_pat_buf_addr,i_cal_pat_buf_rdata}}} ;    
    end
    else if(w_dlfe_par_1114==4'd3) begin
        o_dbg_sig_fsync    <=  o_dout_frame_sync&o_dout_bcf_en ;                               
        o_dbg_sig_en       <=  o_dout_en ;
        o_dbg_sig_iq       <=  o_dout_iq ;
    end
end
`endif //DLFE_ORAN_DISABLE
`endif// DLFE_OFDM_MOD_DISABLE

dlfe_ant_scale #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_CHAIN         ( NUM_CHAIN_ANT_SCALE   )
    ,.DI_BW             ( DO_BW_OFDM_MOD        )
    ,.DO_BW             ( DO_BW_ANT_SCALE       )
    ,.MAX_MU            ( MAX_MU                ))
u07_dlfe_ant_scale
(
    .i_clk                          ( i_clk                         )          
   ,.i_dlfe_par_1218                ( w_dlfe_par_1218               )          
   ,.i_dlfe_par_121c                ( w_dlfe_par_121c               )          
   ,.i_dlfe_par_1280                ( w_dlfe_par_1280               )          
   ,.i_dlfe_par_1284                ( w_dlfe_par_1284               )          
   ,.i_dlfe_par_1288                ( w_dlfe_par_1288               )          
   ,.i_dlfe_par_128c                ( w_dlfe_par_128c               )          
   ,.i_din_frame_sync               ( w_ofdm_mod_frame_sync         )          
   ,.i_din_symbol_sync              ( w_ofdm_mod_symbol_sync        )          
   ,.i_din_symbol_idx               ( w_ofdm_mod_symbol_idx         )          
   ,.i_din_en                       ( w_ofdm_mod_en                 )          
   ,.i_din_iq                       ( w_ofdm_mod_iq                 )          
   ,.i_din_cc_id                    ( w_ofdm_mod_cc_id              )          
   ,.i_din_ant_id                   ( w_ofdm_mod_ant_id             )          
   ,.i_din_cal_en                   ( w_ofdm_mod_cal_en             )          
   ,.o_dout_frame_sync              ( w_ant_scale_frame_sync        )          
   ,.o_dout_symbol_sync             ( w_ant_scale_symbol_sync       )          
   ,.o_dout_symbol_idx              ( w_ant_scale_symbol_idx        )          
   ,.o_dout_en                      ( w_ant_scale_en                )          
   ,.o_dout_iq                      ( w_ant_scale_iq                )          
   ,.o_dout_cc_id                   ( w_ant_scale_cc_id             )          
   ,.o_dout_ant_id                  ( w_ant_scale_ant_id            )          
   ,.o_dout_cal_en                  ( w_ant_scale_cal_en            )          
);

dlfe_cdd_cp_buf #(
     .NUM_CC            ( NUM_CC                )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.NUM_I_CHAIN       ( NUM_CHAIN_ANT_SCALE   )
    ,.DI_BW             ( DO_BW_ANT_SCALE       )
    ,.DO_BW             ( DO_BW_CDD_CP_BUF      )
    ,.MAX_MU            ( MAX_MU                )
    ,.MAX_NIFFT         ( MAX_NIFFT             )
    ,.ADDR_OFFSET       ( DLFE_BASE_ADDR        )
    ,.VENDOR            ( VENDOR                ))
u08_dlfe_cdd_cp_buf
(
    .i_clk                          ( i_clk                         )          
   ,.i_cpu_addr                     ( i_cpu_addr                    )          
   ,.i_cpu_wren                     ( i_cpu_wren                    )          
   ,.i_cpu_wdata                    ( i_cpu_wdata                   )          
   ,.i_cpu_rden                     ( i_cpu_rden                    )          
   ,.o_cpu_rdata                    ( w_cdd_cp_rdata                )          
   ,.o_cpu_rd_valid                 ( w_cdd_cp_rd_valid             )          
   ,.i_dlfe_par_100c                ( w_dlfe_par_100c               )          
   ,.i_cals_punc_len                ( w_cals_punc_len               )
   ,.i_din_ref_frame_sync           ( w_in_if_frame_sync            )          
   ,.i_din_mu                       ( w_in_if_mu                    )          
   ,.i_din_fft_size                 ( w_in_if_fft_size              )          
   ,.i_din_frame_sync               ( w_ant_scale_frame_sync        )          
   ,.i_din_symbol_sync              ( w_ant_scale_symbol_sync       )          
   ,.i_din_symbol_idx               ( w_ant_scale_symbol_idx        )          
   ,.i_din_en                       ( w_ant_scale_en                )          
   ,.i_din_iq                       ( w_ant_scale_iq                )          
   ,.i_din_cc_id                    ( w_ant_scale_cc_id             )          
   ,.i_din_ant_id                   ( w_ant_scale_ant_id            )          
   ,.i_din_cal_en                   ( w_ant_scale_cal_en            )          
   ,.o_dout_frame_sync              ( w_cdd_cp_buf_frame_sync       )          
   ,.o_dout_subfrm_sync             ( w_cdd_cp_buf_subfrm_sync      )          
   ,.o_dout_slot_sync               ( w_cdd_cp_buf_slot_sync        )          
   ,.o_dout_symbol_sync             ( w_cdd_cp_buf_symbol_sync      )          
   ,.o_dout_subfrm_idx              ( w_cdd_cp_buf_subfrm_idx       )          
   ,.o_dout_slot_idx                ( w_cdd_cp_buf_slot_idx         )          
   ,.o_dout_symbol_idx              ( w_cdd_cp_buf_symbol_idx       )          
   ,.o_dout_en                      ( w_cdd_cp_buf_en               )          
   ,.o_dout_iq                      ( w_cdd_cp_buf_iq               )          
   
   ,.i_counter_rst                  ( w_counter_rst                 )          
   ,.i_sig_susp_en                  ( w_sig_susp_en                 )          
   ,.i_sym_per_thrshld_val          ( w_sym_per_thrshld_val         )          
   ,.i_reg_ntone                    ( w_dlfe_par_120c               ) //w_reg_ntone                   )           
   ,.i_comm_thrshld_val             ( w_comm_thrshld_val            )          
   ,.o_upper_threshold_cnt          ( w_upper_threshold_cnt         )          
   ,.o_max_pwr_per_sym              ( w_max_pwr_per_sym             ) 
           
);

generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g00_dlfe_out_if
dlfe_out_if #(
     .NUM_ANT           ( NUM_ANT               )
    ,.DI_BW             ( DO_BW_CDD_CP_BUF      )
    ,.DO_BW             ( TOP_DIO_BW            ))
u09_dlfe_out_if
(
    .i_clk                          ( i_clk                                                                                                 )
   ,.i_rst                          ( i_rst                     [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.i_dlfe_par_1004                ( w_dlfe_par_1004           [((02)*(gidx+1)-1)-:(02)]                                                   )
   ,.i_dlfe_par_1110                ( w_dlfe_par_1110           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.i_dlfe_par_1200                ( w_dlfe_par_1200           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.i_dlfe_par_1204                ( w_dlfe_par_1204           [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.i_dlfe_par_120c                ( w_dlfe_par_120c           [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.i_dlfe_par_1210                ( w_dlfe_par_1210           [((02)*(gidx+1)-1)-:(02)]                                                   )
   ,.i_dlfe_par_124c                ( w_dlfe_par_124c           [((01*NUM_ANT)*(gidx+1)-1)-:(01*NUM_ANT)]                                   )
   ,.i_din_bcf_en                   ( w_cals_bcf_en             [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.i_din_frame_sync               ( w_cdd_cp_buf_frame_sync   [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.i_din_subfrm_sync              ( w_cdd_cp_buf_subfrm_sync  [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.i_din_slot_sync                ( w_cdd_cp_buf_slot_sync    [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.i_din_symbol_sync              ( w_cdd_cp_buf_symbol_sync  [((01)*(gidx+1)-1)-:(01)]                                                   )
`ifndef DLFE_ORAN_DISABLE
   ,.i_din_bfn                      ({4'd0,i_din_frame_idx      [((08)*(gidx+1)-1)-:(08)]}                                                  )
   ,.i_din_frame_idx                ( i_din_frame_idx           [((08)*(gidx+1)-1)-:(08)]                                                   )
`else
   ,.i_din_bfn                      ( i_din_bfn                 [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.i_din_frame_idx                ( i_din_bfn                 [((12)*(gidx+1)-1-04)-:(12-04)]                                             )
`endif
   ,.i_din_subfrm_idx               ( w_cdd_cp_buf_subfrm_idx   [((04)*(gidx+1)-1)-:(04)]                                                   )
   ,.i_din_slot_idx                 ( w_cdd_cp_buf_slot_idx     [((06)*(gidx+1)-1)-:(06)]                                                   )
   ,.i_din_symbol_idx               ( w_cdd_cp_buf_symbol_idx   [((04)*(gidx+1)-1)-:(04)]                                                   )
   ,.i_din_en                       ( w_cdd_cp_buf_en           [((01*NUM_ANT)*(gidx+1)-1)-:(01*NUM_ANT)]                                   )
   ,.i_din_iq                       ( w_cdd_cp_buf_iq           [((2*DO_BW_CDD_CP_BUF*NUM_ANT)*(gidx+1)-1)-:(2*DO_BW_CDD_CP_BUF*NUM_ANT)]   )
   ,.o_dout_bfn_strb                ( o_dout_bfn_strb           [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_bfn                     ( o_dout_bfn                [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.o_dout_frame_sync              ( o_dout_frame_sync         [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_subfrm_sync             ( o_dout_subfrm_sync        [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_slot_sync               ( o_dout_slot_sync          [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_symbol_sync             ( o_dout_symbol_sync        [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_frame_idx               ( o_dout_frame_idx          [((08)*(gidx+1)-1)-:(08)]                                                   )
   ,.o_dout_subfrm_idx              ( o_dout_subfrm_idx         [((04)*(gidx+1)-1)-:(04)]                                                   )
   ,.o_dout_slot_idx                ( o_dout_slot_idx           [((06)*(gidx+1)-1)-:(06)]                                                   )
   ,.o_dout_symbol_idx              ( o_dout_symbol_idx         [((04)*(gidx+1)-1)-:(04)]                                                   )
   ,.o_dout_en                      ( o_dout_en                 [((01*NUM_ANT)*(gidx+1)-1)-:(01*NUM_ANT)]                                   )
   ,.o_dout_iq                      ( o_dout_iq                 [((2*TOP_DIO_BW*NUM_ANT)*(gidx+1)-1)-:(2*TOP_DIO_BW*NUM_ANT)]               )
   ,.o_dout_dl_bw_idx               ( o_dout_dl_bw_idx          [((04)*(gidx+1)-1)-:(04)]                                                   )
   ,.o_dout_dl_sys_mode             ( o_dout_dl_sys_mode        [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dout_dl_ntone                ( o_dout_dl_ntone           [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.o_dout_dl_fft_type             ( o_dout_dl_fft_type        [((02)*(gidx+1)-1)-:(02)]                                                   )
   ,.o_dout_dl_k0                   ( o_dout_dl_k0              [((12)*(gidx+1)-1)-:(12)]                                                   )
   ,.o_dout_bcf_en                  ( o_dout_bcf_en             [((01)*(gidx+1)-1)-:(01)]                                                   )
   ,.o_dlfe_rpt_1128                ( w_dout_nr_max             [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_112c                ( w_dout_nr_min             [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1134                ( w_dout_fsync_ts           [((22)*(gidx+1)-1)-:(22)]                                                   )
   ,.o_dlfe_rpt_1140                ( w_dout_nr_tssi0           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1144                ( w_dout_nr_tssi1           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1148                ( w_dout_nr_tssi2           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_114c                ( w_dout_nr_tssi3           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1150                ( w_dout_nr_tssi4           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1154                ( w_dout_nr_tssi5           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_1158                ( w_dout_nr_tssi6           [((32)*(gidx+1)-1)-:(32)]                                                   )
   ,.o_dlfe_rpt_115c                ( w_dout_nr_tssi7           [((32)*(gidx+1)-1)-:(32)]                                                   )
);
end
endgenerate

generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin : g01_dlfe_cc_param_if
dlfe_cc_param_if 
#(
     .ADDR_OFFSET       ( DLFE_BASE_ADDR        )
    ,.NUM_LAYER         ( NUM_LAYER             )
    ,.NUM_ANT           ( NUM_ANT               )
    ,.DLY_REG_RD        ( DLY_REG_RD            ))
u10_dlfe_cc_param_if
(                                                               
    .i_clk                          ( i_clk                                        )
   ,.i_rst                          ( i_rst             [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_cpu_addr                     ( i_cpu_addr        [((20)*(gidx+1)-1)-:(20)]  )
   ,.i_cpu_wren                     ( i_cpu_wren        [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_cpu_wdata                    ( i_cpu_wdata       [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_cpu_rden                     ( i_cpu_rden        [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_cpu_rdata                    ( o_cpu_rdata       [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_cpu_rd_valid                 ( o_cpu_rd_valid    [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_bfw_rdata                    ( w_bfw_rdata       [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_bfw_rd_valid                 ( w_bfw_rd_valid    [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_calw_rdata                   ( w_calw_rdata      [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_calw_rd_valid                ( w_calw_rd_valid   [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_pc_rdata                     ( w_pc_rdata        [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_pc_rd_valid                  ( w_pc_rd_valid     [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_cals_rdata                   ( w_cals_rdata      [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_cals_rd_valid                ( w_cals_rd_valid   [((01)*(gidx+1)-1)-:(01)]  )
   ,.i_cdd_cp_rdata                 ( w_cdd_cp_rdata    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_cdd_cp_rd_valid              ( w_cdd_cp_rd_valid [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_1004                ( w_dlfe_par_1004   [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_dlfe_par_1008                ( w_dlfe_par_1008   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_100c                ( w_dlfe_par_100c   [((22)*(gidx+1)-1)-:(22)]  )
   ,.o_dlfe_par_1050                ( w_dlfe_par_1050   [((22)*(gidx+1)-1)-:(22)]  )
   ,.o_dlfe_par_10c0                ( w_dlfe_par_10c0   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_1100                ( w_dlfe_par_1100   [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_dlfe_par_1104                ( w_dlfe_par_1104   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_1108                ( w_dlfe_par_1108   [((08)*(gidx+1)-1)-:(08)]  )
   ,.o_dlfe_par_110c                ( w_dlfe_par_110c   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_dlfe_par_1110                ( w_dlfe_par_1110   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_dlfe_par_1114                ( w_dlfe_par_1114   [((04)*(gidx+1)-1)-:(04)]  )
   ,.o_dlfe_par_1200                ( w_dlfe_par_1200   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_dlfe_par_1204                ( w_dlfe_par_1204   [((12)*(gidx+1)-1)-:(12)]  )
   ,.o_dlfe_par_1208                ( w_dlfe_par_1208   [((03)*(gidx+1)-1)-:(03)]  )
   ,.o_dlfe_par_120c                ( w_dlfe_par_120c   [((12)*(gidx+1)-1)-:(12)]  )
   ,.o_dlfe_par_1210                ( w_dlfe_par_1210   [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_dlfe_par_1214                ( w_dlfe_par_1214   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_1218                ( w_dlfe_par_1218   [((04)*(gidx+1)-1)-:(04)]  )
   ,.o_dlfe_par_121c                ( w_dlfe_par_121c   [((14)*(gidx+1)-1)-:(14)]  )
   ,.o_dlfe_par_1240                ( w_dlfe_par_1240   [((03)*(gidx+1)-1)-:(03)]  )
   ,.o_dlfe_par_1244                ( w_dlfe_par_1244   [((NUM_LAYER)*(gidx+1)-1)-:(NUM_LAYER)]  )
   ,.o_dlfe_par_124c                ( w_dlfe_par_124c   [((NUM_ANT  )*(gidx+1)-1)-:(NUM_ANT  )]  )
   ,.o_dlfe_par_1254                ( w_dlfe_par_1254   [((03)*(gidx+1)-1)-:(03)]  )
   ,.o_dlfe_par_1280                ( w_dlfe_par_1280   [((14)*(gidx+1)-1)-:(14)]  )
   ,.o_dlfe_par_1284                ( w_dlfe_par_1284   [((14)*(gidx+1)-1)-:(14)]  )
   ,.o_dlfe_par_1288                ( w_dlfe_par_1288   [((04)*(gidx+1)-1)-:(04)]  )
   ,.o_dlfe_par_128c                ( w_dlfe_par_128c   [((04)*(gidx+1)-1)-:(04)]  )
   ,.o_dlfe_par_1290                ( w_dlfe_par_1290   [((04)*(gidx+1)-1)-:(04)]  )
`ifndef DLFE_BF_DISABLE
   ,.o_dlfe_par_3c00                ( w_dlfe_par_3c00   [(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))]  )
   ,.o_dlfe_par_3c04                ( w_dlfe_par_3c04   [(($clog2(NUM_ANT  ))*(gidx+1)-1)-:($clog2(NUM_ANT  ))]  )
   ,.o_dlfe_par_3c08                ( w_dlfe_par_3c08   [(($clog2(NUM_LAYER))*(gidx+1)-1)-:($clog2(NUM_LAYER))]  )
`endif//DLFE_BF_DISABLE           
`ifndef DLFE_CAL_DISABLE
   ,.o_dlfe_par_0050                ( w_dlfe_par_0050   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_3880                ( w_dlfe_par_3880   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_d000                ( w_dlfe_par_d000   [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_dlfe_par_d010                ( w_dlfe_par_d010   [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_dlfe_par_d020                ( w_dlfe_par_d020   [((10)*(gidx+1)-1)-:(10)]  )
   ,.o_dlfe_par_d024                ( w_dlfe_par_d024   [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_dlfe_par_d028                ( w_dlfe_par_d028   [((06)*(gidx+1)-1)-:(06)]  )
   ,.o_dlfe_par_d02c                ( w_dlfe_par_d02c   [((06)*(gidx+1)-1)-:(06)]  )
   ,.o_dlfe_par_d030                ( w_dlfe_par_d030   [((04)*(gidx+1)-1)-:(04)]  )
   ,.o_dlfe_par_d034                ( w_dlfe_par_d034   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d038                ( w_dlfe_par_d038   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d03c                ( w_dlfe_par_d03c   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d040                ( w_dlfe_par_d040   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_dlfe_par_d044                ( w_dlfe_par_d044   [((08)*(gidx+1)-1)-:(08)]  )
   ,.o_dlfe_par_d048                ( w_dlfe_par_d048   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_dlfe_par_d04c                ( w_dlfe_par_d04c   [((08)*(gidx+1)-1)-:(08)]  )
   ,.o_dlfe_par_d050                ( w_dlfe_par_d050   [((14)*(gidx+1)-1)-:(14)]  )
   ,.o_dlfe_par_d054                ( w_dlfe_par_d054   [((14)*(gidx+1)-1)-:(14)]  )
   ,.o_dlfe_par_d058                ( w_dlfe_par_d058   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d05c                ( w_dlfe_par_d05c   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d060                ( w_dlfe_par_d060   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d064                ( w_dlfe_par_d064   [((07)*(gidx+1)-1)-:(07)]  )
   ,.o_dlfe_par_d068                ( w_dlfe_par_d068   [((12)*(gidx+1)-1)-:(12)]  )
`endif //DLFE_CAL_DISABLE
   ,.i_dlfe_rpt_1040                ( w_aie_axi0_pdly   [((22)*(gidx+1)-1)-:(22)]  )
   ,.i_dlfe_rpt_1044                ( w_aie_axi1_pdly   [((22)*(gidx+1)-1)-:(22)]  )
   ,.i_dlfe_rpt_1080                ( w_din_nr_lssi0    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1084                ( w_din_nr_lssi1    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1088                ( w_din_nr_lssi2    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_108c                ( w_din_nr_lssi3    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1090                ( w_din_nr_lssi4    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1094                ( w_din_nr_lssi5    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1098                ( w_din_nr_lssi6    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_109c                ( w_din_nr_lssi7    [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_10c4                ( w_bcf_fs_err_flag_blkclk_out  [((02)*(gidx+1)-1)-:(02)] )
   ,.i_dlfe_rpt_10c8                ( w_bcf_en_fscnt_blkclk_out     [((32)*(gidx+1)-1)-:(32)] )
   ,.i_dlfe_rpt_10cc                ( w_bcf_rpls_clkcnt_blkclk_out  [((32)*(gidx+1)-1)-:(32)] )
   ,.i_dlfe_rpt_10d0                ( w_bcf_en_sfncnt_blkclk_out    [((32)*(gidx+1)-1)-:(32)] )
   ,.i_dlfe_rpt_1120                ( w_din_nr_max      [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1124                ( w_din_nr_min      [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1128                ( w_dout_nr_max     [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_112c                ( w_dout_nr_min     [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1130                ( w_din_fsync_ts    [((22)*(gidx+1)-1)-:(22)]  )
   ,.i_dlfe_rpt_1134                ( w_dout_fsync_ts   [((22)*(gidx+1)-1)-:(22)]  )
   ,.i_dlfe_rpt_1140                ( w_dout_nr_tssi0   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1144                ( w_dout_nr_tssi1   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1148                ( w_dout_nr_tssi2   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_114c                ( w_dout_nr_tssi3   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1150                ( w_dout_nr_tssi4   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1154                ( w_dout_nr_tssi5   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_1158                ( w_dout_nr_tssi6   [((32)*(gidx+1)-1)-:(32)]  )
   ,.i_dlfe_rpt_115c                ( w_dout_nr_tssi7   [((32)*(gidx+1)-1)-:(32)]  )
   ,.o_counter_rst                ( w_counter_rst           [((01)*(gidx+1)-1)-:(01)]  )
   ,.o_sig_susp_en                ( w_sig_susp_en           [((02)*(gidx+1)-1)-:(02)]  )
   ,.o_sym_per_thrshld_val        ( w_sym_per_thrshld_val   [((32*14)*(gidx+1)-1)-:(32*14)]  )
//   ,.o_reg_ntone                  ( w_reg_ntone             [((12)*(gidx+1)-1)-:(12)]  )
   ,.o_comm_thrshld_val           ( w_comm_thrshld_val      [((32)*(gidx+1)-1)-:(32)]  )
   
   ,.i_upper_threshold_cnt        ( w_upper_threshold_cnt   [((32*14)*(gidx+1)-1)-:(32*14)]  )
   ,.i_max_pwr_per_sym            ( w_max_pwr_per_sym       [((32*14)*(gidx+1)-1)-:(32*14)]  ) 
);
end
endgenerate

endmodule
