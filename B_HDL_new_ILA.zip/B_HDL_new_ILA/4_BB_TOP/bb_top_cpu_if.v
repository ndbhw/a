////////////////////////////////////////////////////////////////////////////////
//
// Copyright(c) 2020 Samsung Electronics Inc. All rights reserved
//
//  Project      : DCM RT4419
//  Module       : bb_top_cpu_if
//  Author       : jyzoo.lee@samsung.com
//  Description  : Baseband LPHY TOP for DCM RT4419 SVR21B
//  Revision History
//  ------------+---------------+-----------------------------------------------
//     Date     |   Author      |   Description
//  ------------+---------------+-----------------------------------------------
//   2020.11.30 | jyzoo.lee     | Create Initial Design
//  ------------+---------------+-----------------------------------------------
//   2020.12.14 | jyzoo.lee     | Core Address Bitwidth 16 -> 20 
//  ------------+---------------+-----------------------------------------------
//   2020.12.21 | jyzoo.lee     | sig_cap support
//  ------------+---------------+-----------------------------------------------
//   2021.04.12 | jyzoo.lee     | Reduced Read Latency
//  ------------+---------------+-----------------------------------------------
//
////////////////////////////////////////////////////////////////////////////////


module bb_top_cpu_if 
#(
    parameter   NUM_CC                  =   18          
   ,parameter   BW_ADDR_HEAD            =    4  
   ,parameter   CPUIF_ADDR_BW           =   24  
   ,parameter   CPUIF_BB_ADDR_BW        =   20  
   ,parameter   CPUIF_DATA_BW           =   32
   ,parameter   DUMP_MEM_ADDR_BW        =   15 
   ,parameter   DLY_REG_RD              =   10 
   ,parameter   P4V_VERSION             =   32'hffff_ffff 
   ,parameter   VENDOR                  =   "Xilinx" 
)(
    //--- From SYSCTRL_TOP
        input   wire                                                i_clk  
    ,   input   wire                                                i_rst  

    //--- From/To CPU IF
    ,   input   wire                                                i_cpu_clk  
    ,   input   wire                                                i_cpu_rst  
    ,   input   wire    [0:0]                                       i_cpu_cs
    ,   input   wire    [CPUIF_ADDR_BW-1:0]                         i_cpu_addr
    ,   input   wire    [0:0]                                       i_cpu_wren
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_cpu_wdata
    ,   input   wire    [0:0]                                       i_cpu_rden
    ,   output  reg     [CPUIF_DATA_BW-1:0]                         o_cpu_rdata
    ,   output  wire    [0:0]                                       o_cpu_rd_valid

    //--- From/To DLFE,ULFE,RAFE
    ,   output  wire    [CPUIF_BB_ADDR_BW*NUM_CC-1:0]               o_core_addr
    ,   output  wire    [01*NUM_CC-1:0]                             o_core_wren
    ,   output  wire    [CPUIF_DATA_BW*NUM_CC-1:0]                  o_core_wdata
    ,   output  wire    [01*NUM_CC-1:0]                             o_core_rden
    ,   input   wire    [CPUIF_DATA_BW*NUM_CC-1:0]                  i_core_rdata
    ,   input   wire    [01*NUM_CC-1:0]                             i_core_rd_valid

    //--- From To BB_TOP
    ,   output  reg     [32-1:0]                                    o_bb_top_par_100000 
    ,   output  reg     [22-1:0]                                    o_bb_top_par_100004 
    ,   output  reg     [01-1:0]                                    o_sigcap_par_110000
    ,   output  reg     [01-1:0]                                    o_sigcap_par_110004
    ,   output  reg     [02-1:0]                                    o_sigcap_par_110008
    ,   output  reg     [03-1:0]                                    o_sigcap_par_11000c
    ,   output  reg     [06-1:0]                                    o_sigcap_par_110010
    ,   output  reg     [04-1:0]                                    o_sigcap_par_110014
    ,   output  reg     [03-1:0]                                    o_sigcap_par_110018
    ,   output  reg     [03-1:0]                                    o_sigcap_par_11001c
    ,   output  reg     [03-1:0]                                    o_sigcap_par_110020
    ,   output  reg     [03-1:0]                                    o_sigcap_par_110024
    
    ,   output  reg     [32-1:0]                                    o_bb_top_par_100008_ulfe_data_dly 
    
    //--- From DUMP
    ,   input   wire    [0:0]                                       i_dump_wr_en
    ,   input   wire    [DUMP_MEM_ADDR_BW-1:0]                      i_dump_wr_addr
    ,   input   wire    [CPUIF_DATA_BW-1:0]                         i_dump_wr_data

    //--- From ORAN_TOP/BB_TOP/ULFE/RAFE
    ,   input   wire    [0:0]                                       i_din_fsync            
    ,   input   wire    [0:0]                                       i_dout_fsync        
    ,   input   wire    [0:0]                                       i_uin_fsync            
    ,   input   wire    [0:0]                                       i_uout_fsync           
    ,   input   wire    [0:0]                                       i_rin_fsync            
    ,   input   wire    [0:0]                                       i_rout_fsync           
);

//local parameter
localparam  [CPUIF_BB_ADDR_BW-1:0]  BB_TOP_BASE_ADDR    =      'h00000              ;
localparam  [CPUIF_BB_ADDR_BW-1:0]  SIGCAP_BASE_ADDR    =      'h10000              ;
localparam  [CPUIF_BB_ADDR_BW-1:0]  DUMP_BASE_ADDR      =      'h14000              ;
localparam  [BW_ADDR_HEAD-1:0]      CC00_ADDR_OFFSET    =      'h0                  ;
localparam  [BW_ADDR_HEAD-1:0]      CC01_ADDR_OFFSET    =      'h1                  ;
localparam  [BW_ADDR_HEAD-1:0]      DUMP0_ADDR_OFFSET   =      'h1                  ;
localparam  [BW_ADDR_HEAD-1:0]      DUMP1_ADDR_OFFSET   =      'h2                  ;

localparam  CC00_DEMUX_INDEX    =       00                  ;
localparam  CC01_DEMUX_INDEX    =       01                  ;
localparam  DUMP_DEMUX_INDEX    =       NUM_CC              ;

localparam  CDC_CPU2BB_LEVEL    =       1                   ;
localparam  CDC_BB2CPU_LEVEL    =       1                   ;
localparam  DLY_REG_RD_DUMP     =       1                   ;
localparam  DEPTH_DUMP          =       2**14               ;   
localparam  BW_DEPTH_DUMP       =       $clog2(DEPTH_DUMP)  ;   

//Logic Variable
genvar gidx ;
integer i   ;

////bb_top report 
wire    [31:0]  w_bb_top_rpt_100010 ;
wire    [31:0]  w_bb_top_rpt_100014 ;
wire    [31:0]  w_bb_top_rpt_100018 ;
wire    [21:0]  w_bb_top_rpt_10001c ;
wire    [01:0]  w_bb_top_rpt_100020 ;

//cpu if cdc
reg [0:0]                   r_cpu2bb_wren    ;
reg [0:0]                   r_cpu2bb_rden    ;
reg [0:0]                   rr_cpu2bb_wren   ;
reg [0:0]                   rr_cpu2bb_rden   ;
reg [0:0]                   rrr_cpu2bb_wren  ;
reg [0:0]                   rrr_cpu2bb_rden  ;
reg [0:0]                   rrrr_cpu2bb_wren ;
reg [0:0]                   rrrr_cpu2bb_rden ;
reg [CPUIF_BB_ADDR_BW-1:0]  r_cpu2bb_addr    ;
reg [CPUIF_DATA_BW-1:0]     r_cpu2bb_wdata   ;
reg [0:0]                   r_bb_wren        ;
reg [CPUIF_BB_ADDR_BW-1:0]  r_bb_waddr       ;
reg [CPUIF_DATA_BW-1:0]     r_bb_wdata       ;
reg [0:0]                   r_bb_rden        ;
reg [CPUIF_BB_ADDR_BW-1:0]  r_bb_raddr       ;
always@(posedge i_cpu_clk) begin
    if(i_cpu_cs) begin
        r_cpu2bb_addr   <=  {4'd0,i_cpu_addr}<<2  ;
        r_cpu2bb_wdata  <=  i_cpu_wdata ;
        r_cpu2bb_wren   <=  i_cpu_wren  ;
        r_cpu2bb_rden   <=  i_cpu_rden  ;
    end
    else begin
        r_cpu2bb_wren   <=  1'd0    ;
        r_cpu2bb_rden   <=  1'd0    ;
    end
end
always@(posedge i_clk) begin
    rr_cpu2bb_wren      <=  r_cpu2bb_wren ;
    rr_cpu2bb_rden      <=  r_cpu2bb_rden ;
    rrr_cpu2bb_wren     <=  rr_cpu2bb_wren ;
    rrr_cpu2bb_rden     <=  rr_cpu2bb_rden ;
    rrrr_cpu2bb_wren    <=  rrr_cpu2bb_wren ;
    rrrr_cpu2bb_rden    <=  rrr_cpu2bb_rden ;
    r_bb_wren           <=  rrr_cpu2bb_wren & ~rrrr_cpu2bb_wren ;
    r_bb_rden           <=  rrr_cpu2bb_rden & ~rrrr_cpu2bb_rden ;
    if(rrr_cpu2bb_wren & ~rrrr_cpu2bb_wren) begin
        r_bb_waddr  <=  r_cpu2bb_addr  ;
        r_bb_wdata  <=  r_cpu2bb_wdata ;
    end
    else if(rrr_cpu2bb_rden & ~rrrr_cpu2bb_rden) begin
        r_bb_raddr  <=  r_cpu2bb_addr  ;
    end
end

reg [CPUIF_BB_ADDR_BW-1:0] r_demux_core_addr  [NUM_CC-1+1:0]    ; //CC+dump
reg [0:0]                  r_demux_core_wren  [NUM_CC-1+1:0]    ;
reg [CPUIF_DATA_BW-1:0]    r_demux_core_wdata [NUM_CC-1+1:0]    ;
reg [0:0]                  r_demux_core_rden  [NUM_CC-1+1:0]    ;
reg [CPUIF_BB_ADDR_BW-0:0] r_demux_dump_addr                    ; //Dump
reg [0:0]                  r_demux_dump_rden                    ;
always@(posedge i_clk) begin
    if(r_bb_wren) begin
        case(r_bb_waddr[(CPUIF_BB_ADDR_BW-1)-:BW_ADDR_HEAD]) 
            CC00_ADDR_OFFSET    :   begin r_demux_core_addr[CC00_DEMUX_INDEX] <= r_bb_waddr; r_demux_core_wren[CC00_DEMUX_INDEX] <= r_bb_wren ; r_demux_core_wdata[CC00_DEMUX_INDEX] <= r_bb_wdata ; end 
            CC01_ADDR_OFFSET    :   begin r_demux_core_addr[CC01_DEMUX_INDEX] <= r_bb_waddr; r_demux_core_wren[CC01_DEMUX_INDEX] <= r_bb_wren ; r_demux_core_wdata[CC01_DEMUX_INDEX] <= r_bb_wdata ; end
            
            default             :   for(i=0;i<NUM_CC+1;i=i+1) begin r_demux_core_wren [i] <= 1'd0 ; end 
        endcase
    end
    else if(r_bb_rden) begin
        case(r_bb_raddr[(CPUIF_BB_ADDR_BW-1)-:BW_ADDR_HEAD]) 
            CC00_ADDR_OFFSET    :   begin r_demux_core_addr[CC00_DEMUX_INDEX] <= r_bb_raddr; r_demux_core_rden[CC00_DEMUX_INDEX] <= r_bb_rden ; end 
            CC01_ADDR_OFFSET    :   begin r_demux_core_addr[CC01_DEMUX_INDEX] <= r_bb_raddr; r_demux_core_rden[CC01_DEMUX_INDEX] <= r_bb_rden ; end
//            DUMP0_ADDR_OFFSET   :   begin r_demux_core_addr[DUMP_DEMUX_INDEX] <= (r_bb_raddr-DUMP_BASE_ADDR)>>2; r_demux_core_rden[DUMP_DEMUX_INDEX] <= r_bb_rden ; end 
            DUMP1_ADDR_OFFSET   :   begin r_demux_core_addr[DUMP_DEMUX_INDEX] <= (r_bb_raddr-DUMP_BASE_ADDR)>>2; r_demux_core_rden[DUMP_DEMUX_INDEX] <= r_bb_rden ; end 
            default             :   for(i=0;i<NUM_CC+1;i=i+1) begin r_demux_core_rden [i] <= 1'd0 ; end 
        endcase
    end
    else begin
        for(i=0;i<NUM_CC+1;i=i+1) begin r_demux_core_wren [i] <= 1'd0 ; r_demux_core_rden [i] <= 1'd0 ; end
    end
end

wire [CPUIF_DATA_BW-1:0] w_cc_core_rdata     [NUM_CC-1:0]   ;
wire [01-1:0]            w_cc_core_rd_valid  [NUM_CC-1:0]   ;
generate for(gidx=0;gidx<NUM_CC;gidx=gidx+1) begin
assign  o_core_addr     [((CPUIF_BB_ADDR_BW )*(gidx+1)-1)-:(CPUIF_BB_ADDR_BW )]   =   r_demux_core_addr [gidx]  ;
assign  o_core_wren     [((01               )*(gidx+1)-1)-:(01               )]   =   r_demux_core_wren [gidx]  ;
assign  o_core_wdata    [((CPUIF_DATA_BW    )*(gidx+1)-1)-:(CPUIF_DATA_BW    )]   =   r_demux_core_wdata[gidx]  ;
assign  o_core_rden     [((01               )*(gidx+1)-1)-:(01               )]   =   r_demux_core_rden [gidx]  ;
assign  w_cc_core_rdata     [gidx]  =   i_core_rdata        [((CPUIF_DATA_BW )*(gidx+1)-1)-:(CPUIF_DATA_BW )]   ;
assign  w_cc_core_rd_valid  [gidx]  =   i_core_rd_valid     [((01            )*(gidx+1)-1)-:(01            )]   ;
end
endgenerate

//proc dly mon
wire [21:0]  w_dl_proc_dly  ;
wire [21:0]  w_ul_proc_dly  ;
wire [21:0]  w_ra_proc_dly  ;
wire [21:0]  w_du_diff      ;
ylib_mon_sync_diff  #(.WIDTH(22)) u00_0_dproc_dly(.i_clk(i_clk),.i_sync0(i_din_fsync),.i_sync1(i_dout_fsync),.o_diff(w_dl_proc_dly));
ylib_mon_sync_diff  #(.WIDTH(22)) u00_1_uproc_dly(.i_clk(i_clk),.i_sync0(i_uin_fsync),.i_sync1(i_uout_fsync),.o_diff(w_ul_proc_dly));
ylib_mon_sync_diff  #(.WIDTH(22)) u00_2_rproc_dly(.i_clk(i_clk),.i_sync0(i_rin_fsync),.i_sync1(i_rout_fsync),.o_diff(w_ra_proc_dly));
ylib_mon_sync_diff  #(.WIDTH(22)) u00_3_du_diff  (.i_clk(i_clk),.i_sync0(i_din_fsync),.i_sync1(i_uin_fsync ),.o_diff(w_du_diff    ));
assign  w_bb_top_rpt_100010 = {8'd8,2'd0,w_dl_proc_dly} ;
assign  w_bb_top_rpt_100014 = {8'd8,2'd0,w_ul_proc_dly} ;
assign  w_bb_top_rpt_100018 = {8'd8,2'd0,w_ra_proc_dly} ;
assign  w_bb_top_rpt_10001c = w_du_diff ;

//sync existence mon
reg [0:0] r_dl_sync_exist ;
reg [0:0] r_ul_sync_exist ;
always@(posedge i_clk) begin
    if(i_din_fsync) begin
        r_dl_sync_exist <=  1'd1 ;
    end
    else if(r_bb_rden&&r_bb_raddr==BB_TOP_BASE_ADDR+16'h0020) begin
        r_dl_sync_exist <=  1'd0 ;
    end
end
always@(posedge i_clk) begin
    if(i_uin_fsync) begin
        r_ul_sync_exist <=  1'd1 ;
    end
    else if(r_bb_rden&&r_bb_raddr==BB_TOP_BASE_ADDR+16'h0020) begin
        r_ul_sync_exist <=  1'd0 ;
    end
end
assign  w_bb_top_rpt_100020 = {r_ul_sync_exist, r_dl_sync_exist} ;

//sig_cap
reg    [00:0]                   r_dump_en_map       ;
reg    [00:0]                   r_dump_wen_map      ;
reg    [00:0]                   r_dump_ren_map      ;
reg    [BW_DEPTH_DUMP-1:0]      r_dump_addr_map     ;
reg    [31:0]                   r_dump_wdata_map    ;
always@(posedge i_clk) begin
    if(i_dump_wr_en) begin
        r_dump_en_map       <=  i_dump_wr_en                        ;    
        r_dump_wen_map      <=  i_dump_wr_en                        ;    
        r_dump_ren_map      <=  1'd0                                ;    
        r_dump_addr_map     <=  i_dump_wr_addr[BW_DEPTH_DUMP-1:0]   ;    
        r_dump_wdata_map    <=  i_dump_wr_data                      ;    
    end  
    else if(r_demux_core_rden[DUMP_DEMUX_INDEX]) begin
        r_dump_en_map       <=  r_demux_core_rden[DUMP_DEMUX_INDEX] ;   
        r_dump_wen_map      <=  1'd0              ;    
        r_dump_ren_map      <=  r_demux_core_rden[DUMP_DEMUX_INDEX] ;   
        r_dump_addr_map     <=  r_demux_core_addr[DUMP_DEMUX_INDEX][BW_DEPTH_DUMP-1:0] ;    
    end
    else begin
        r_dump_en_map       <=  1'd0            ;    
        r_dump_wen_map      <=  1'd0            ;    
        r_dump_ren_map      <=  1'd0            ;    
    end
end                              

wire [31:0] w_dump_rdata ;
ylib_rams_sp_wf #(
     .WIDTH      (   32             )
    ,.DEPTH      (   DEPTH_DUMP     )
    ,.VENDOR     (   VENDOR         ))
u01_zip_sig_dump_mem 
(
    .clk    (i_clk                      )
   ,.we     (r_dump_wen_map             )
   ,.en     (r_dump_en_map              )
   ,.addr   (r_dump_addr_map            )
   ,.di     (r_dump_wdata_map           )   
   ,.dout   (w_dump_rdata               )
);

reg [0:0]   r_mux_dump_rd_en    [DLY_REG_RD_DUMP-1:0]   ;
reg [31:0]  r_mux_dump_rd_data  [0:0]                   ;
always@(posedge i_clk) begin
    r_mux_dump_rd_en[0]  <=  r_dump_ren_map ;    
end                              
always@(*) begin
    r_mux_dump_rd_data[0] <= w_dump_rdata  ;
end
always@(posedge i_clk) begin
    for(i=1;i<DLY_REG_RD_DUMP;i=i+1) begin 
        r_mux_dump_rd_en[i]  <=  r_mux_dump_rd_en[i-1]    ;    
    end
end                               

//bb top parameter wr demux
reg [04-1:0] r_bb_top_par_100100 ;
always@(posedge i_clk) begin
    if(i_rst) begin
        r_bb_top_par_100100 <= 4'd7 ;
    end
    else if(r_bb_wren) begin
        case(r_bb_waddr)
            BB_TOP_BASE_ADDR+16'h0000   :   o_bb_top_par_100000 <=  P4V_VERSION         ;
            BB_TOP_BASE_ADDR+16'h0004   :   o_bb_top_par_100004 <=  r_bb_wdata[22-1:0]  ;
            
            BB_TOP_BASE_ADDR+16'h0008   :   o_bb_top_par_100008_ulfe_data_dly <=  r_bb_wdata[32-1:0]  ;
            
            BB_TOP_BASE_ADDR+16'h0100   :   r_bb_top_par_100100 <=  r_bb_wdata[04-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0000   :   o_sigcap_par_110000 <=  r_bb_wdata[01-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0004   :   o_sigcap_par_110004 <=  r_bb_wdata[01-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0008   :   o_sigcap_par_110008 <=  r_bb_wdata[02-1:0]  ;
            SIGCAP_BASE_ADDR+16'h000c   :   o_sigcap_par_11000c <=  r_bb_wdata[03-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0010   :   o_sigcap_par_110010 <=  r_bb_wdata[06-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0014   :   o_sigcap_par_110014 <=  r_bb_wdata[04-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0018   :   o_sigcap_par_110018 <=  r_bb_wdata[03-1:0]  ;
            SIGCAP_BASE_ADDR+16'h001c   :   o_sigcap_par_11001c <=  r_bb_wdata[03-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0020   :   o_sigcap_par_110020 <=  r_bb_wdata[03-1:0]  ;
            SIGCAP_BASE_ADDR+16'h0024   :   o_sigcap_par_110024 <=  r_bb_wdata[03-1:0]  ;
            default                     :   o_bb_top_par_100000 <=  P4V_VERSION         ;
        endcase                                                      
    end                                                               
end                                                                   

//bb top parameter rd mux
reg [0:0]   r_par_rd_en    [DLY_REG_RD-1:0]  ;
reg [31:0]  r_par_rd_data  [DLY_REG_RD-1:0]  ;
always@(posedge i_clk) begin
    if(r_bb_rden) begin
        case(r_bb_raddr)
            BB_TOP_BASE_ADDR+16'h0000   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},P4V_VERSION        }   ; end 
            BB_TOP_BASE_ADDR+16'h0004   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},o_bb_top_par_100004}   ; end
            
            BB_TOP_BASE_ADDR+16'h0008   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= o_bb_top_par_100008_ulfe_data_dly   ; end 
            
            BB_TOP_BASE_ADDR+16'h0010   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},w_bb_top_rpt_100010}   ; end 
            BB_TOP_BASE_ADDR+16'h0014   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},w_bb_top_rpt_100014}   ; end 
            BB_TOP_BASE_ADDR+16'h0018   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},w_bb_top_rpt_100018}   ; end 
            BB_TOP_BASE_ADDR+16'h001c   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(22-1+1)}{1'd0}},w_bb_top_rpt_10001c}   ; end 
            BB_TOP_BASE_ADDR+16'h0020   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(02-1+1)}{1'd0}},w_bb_top_rpt_100020}   ; end 
            BB_TOP_BASE_ADDR+16'h0100   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},r_bb_top_par_100100}   ; end 
            SIGCAP_BASE_ADDR+16'h0000   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(01-1+1)}{1'd0}},o_sigcap_par_110000}   ; end 
            SIGCAP_BASE_ADDR+16'h0004   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(01-1+1)}{1'd0}},o_sigcap_par_110004}   ; end 
            SIGCAP_BASE_ADDR+16'h0008   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(02-1+1)}{1'd0}},o_sigcap_par_110008}   ; end 
            SIGCAP_BASE_ADDR+16'h000c   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_11000c}   ; end 
            SIGCAP_BASE_ADDR+16'h0010   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(06-1+1)}{1'd0}},o_sigcap_par_110010}   ; end 
            SIGCAP_BASE_ADDR+16'h0014   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(04-1+1)}{1'd0}},o_sigcap_par_110014}   ; end 
            SIGCAP_BASE_ADDR+16'h0018   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_110018}   ; end 
            SIGCAP_BASE_ADDR+16'h001c   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_11001c}   ; end 
            SIGCAP_BASE_ADDR+16'h0020   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_110020}   ; end 
            SIGCAP_BASE_ADDR+16'h0024   :   begin r_par_rd_en[0] <= 1'd1; r_par_rd_data[0] <= {{{32-(03-1+1)}{1'd0}},o_sigcap_par_110024}   ; end 
            default                     :   begin r_par_rd_en[0] <= 1'd0; r_par_rd_data[0] <= {{{32-(32-1+1)}{1'd0}},32'd0              }   ; end 
        endcase
    end
    else begin
        r_par_rd_en[0] <= 1'd0;
    end
end                                                                   
always@(posedge i_clk) begin
    for(i=1;i<DLY_REG_RD;i=i+1) begin 
        r_par_rd_en [i]  <=  r_par_rd_en [i-1]  ;    
        if(r_par_rd_en[i-1]) begin
            r_par_rd_data  [i]  <=  r_par_rd_data  [i-1]  ;    
        end  
    end
end

reg [CPUIF_DATA_BW-1:0]    r_mux_rdata              ; 
reg [0:0]                  r_mux_rd_valid           ;
reg [CPUIF_DATA_BW-1:0]    r_dump_mem_rdata         ; 
reg [0:0]                  r_dump_mem_rd_valid      ;
always@(*) begin
    r_dump_mem_rdata    = r_mux_dump_rd_data[0]               ;
    r_dump_mem_rd_valid = r_mux_dump_rd_en[DLY_REG_RD_DUMP-1] ;
end

wire [0:0]   w_core_rd_init    ;
ylib_reg #(
     .WIDTH     (    1          ) 
    ,.DEPTH     (    10         )) 
u02_rd_init_dly
(
     .i_clk      ( i_clk                                )
    ,.i_in       ( ~rr_cpu2bb_rden & rrr_cpu2bb_rden    )
    ,.o_out      ( w_core_rd_init                       )
);
always@(posedge i_clk) begin
    if     (w_cc_core_rd_valid[CC00_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC00_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC00_DEMUX_INDEX]    ; end 
    else if(w_cc_core_rd_valid[CC01_DEMUX_INDEX])   begin r_mux_rdata <= w_cc_core_rdata[CC01_DEMUX_INDEX]  ; r_mux_rd_valid <= w_cc_core_rd_valid[CC01_DEMUX_INDEX]    ; end
    else if(r_dump_mem_rd_valid)                    begin r_mux_rdata <= r_dump_mem_rdata                   ; r_mux_rd_valid <= r_dump_mem_rd_valid                     ; end 
    else if(r_par_rd_en[DLY_REG_RD-1])              begin r_mux_rdata <= r_par_rd_data[DLY_REG_RD-1]        ; r_mux_rd_valid <= r_par_rd_en[DLY_REG_RD-1]               ; end
    else if(w_core_rd_init)                         begin r_mux_rdata <= 32'd0 ; end
    else begin r_mux_rd_valid <= 1'd0 ; end
end

reg [CPUIF_DATA_BW-1:0]    rr_cpu_mux_rdata         ; 
always@(posedge i_cpu_clk) begin
    rr_cpu_mux_rdata    <=  r_mux_rdata             ; 
    o_cpu_rdata <=  rr_cpu_mux_rdata ; 
end

reg [0:0] r_cpu_rden ;
always@(posedge i_cpu_clk) begin
    r_cpu_rden <= i_cpu_rden ;
end

ylib_pshift #(
     .BW_SHIFT  (   4   ))
u03_rd_valid_dly
(
    .i_clk       ( i_cpu_clk                )
   ,.i_shift     ( r_bb_top_par_100100      )
   ,.i_in        ( i_cpu_rden&~r_cpu_rden   )
   ,.o_out       ( o_cpu_rd_valid           )
);

endmodule
